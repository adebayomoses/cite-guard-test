# Splash Car Wash - Full-Stack Web Application

## Project Overview
Splash is a modern car wash booking platform built with React, Express, PostgreSQL, and Tailwind CSS. The application features a stunning homepage, RESTful API, and database persistence for users and bookings.

## Recent Changes (October 29, 2025)
- ✅ Complete MVP implementation with PostgreSQL database
- ✅ Backend API routes for users and bookings with validation
- ✅ Beautiful, responsive homepage following design guidelines
- ✅ Fixed price validation to accept numeric values
- ✅ Added booking status validation for state machine

## Project Architecture

### Tech Stack
- **Frontend**: React 18, Vite, Tailwind CSS, TanStack Query
- **Backend**: Node.js, Express, TypeScript
- **Database**: PostgreSQL (Neon)
- **ORM**: Drizzle ORM
- **Styling**: Tailwind CSS with custom design tokens
- **UI Components**: shadcn/ui components

### Directory Structure
```
├── client/              # Frontend React application
│   ├── src/
│   │   ├── pages/      # Page components (home.tsx)
│   │   ├── components/ # Reusable UI components
│   │   └── lib/        # Utilities and query client
│   └── index.html      # HTML template with SEO meta tags
├── server/              # Backend Express application
│   ├── routes.ts       # API route handlers
│   ├── storage.ts      # Database operations layer
│   ├── db.ts          # Database connection setup
│   └── index.ts       # Server entry point
├── shared/             # Shared TypeScript types and schemas
│   └── schema.ts      # Drizzle database schemas and Zod validation
└── design_guidelines.md # Design system documentation
```

## Database Schema

### Users Table
- `id`: UUID (varchar, auto-generated)
- `username`: Unique username
- `email`: Unique email address
- `phone`: Optional phone number
- `createdAt`: Timestamp

### Bookings Table
- `id`: UUID (varchar, auto-generated)
- `userId`: Reference to users table (optional)
- `serviceType`: Type of service (basic, premium, deluxe)
- `vehicleType`: Type of vehicle (sedan, suv, truck)
- `scheduledTime`: Appointment date/time
- `status`: Booking status (pending, confirmed, completed, cancelled)
- `price`: Decimal price
- `customerName`: Customer name
- `customerEmail`: Customer email
- `customerPhone`: Customer phone
- `notes`: Optional notes
- `createdAt`: Timestamp

## API Endpoints

### Test Route
- `GET /api/hello` - Health check endpoint
  - Returns: `{ status: "ok", message: "Splash Car Wash API is running!" }`

### Users
- `GET /api/users` - Get all users
- `GET /api/users/:id` - Get user by ID
- `POST /api/users` - Create new user
  - Body: `{ username, email, phone? }`

### Bookings
- `GET /api/bookings` - Get all bookings (ordered by creation date)
- `GET /api/bookings/:id` - Get booking by ID
- `POST /api/bookings` - Create new booking
  - Body: `{ serviceType, vehicleType, scheduledTime, price, customerName, customerEmail, customerPhone, status?, userId?, notes? }`
  - Note: `price` accepts both numbers and strings, validated 0 < price <= 10000
- `PATCH /api/bookings/:id/status` - Update booking status
  - Body: `{ status }` where status is one of: pending, confirmed, completed, cancelled

## Design System

### Typography
- **Headings**: Poppins (font-serif in Tailwind)
- **Body Text**: Inter (default font-sans)
- **Font Sizes**: Following design guidelines (text-5xl to text-sm)

### Colors
The application uses a carefully crafted color palette:
- **Primary**: Blue (#199 89% 48%) - Used for CTAs and branding
- **Background**: White (light mode) / Dark gray (dark mode)
- **Card**: Subtle elevated backgrounds
- **Muted**: Secondary text colors

### Spacing
Consistent spacing using Tailwind utilities:
- Component padding: p-4 (mobile), p-8 (desktop)
- Section spacing: py-12, py-16, py-20
- Element gaps: gap-4, gap-8, gap-12

## Key Features Implemented

### Homepage Sections
1. **Navigation**: Sticky header with logo and navigation links
2. **Hero Section**: Full-width background image with CTA and API test button
3. **Trust Signals**: Stats counter showing 10,000+ cars washed, 4.9★ rating
4. **Services Grid**: Three service packages (Basic $29, Premium $59, Deluxe $129)
5. **How It Works**: 4-step process visualization
6. **Features**: Why choose Splash (eco-friendly, fast, guaranteed, premium)
7. **Final CTA**: Book Now call-to-action
8. **Footer**: Multi-column footer with company info and links

### Test Functionality
- "Test API Connection" button in hero section
- Calls `/api/hello` and displays response
- Demonstrates frontend-backend integration

## Running the Application

### Development
The application runs with live reload:
```bash
npm run dev
```
This starts both:
- Express server on port 5000
- Vite dev server (integrated)

### Database Migrations
To push schema changes to the database:
```bash
npm run db:push
```

## Environment Variables

### Required
- `DATABASE_URL` - PostgreSQL connection string (automatically configured by Replit)
- `SESSION_SECRET` - Session encryption key (automatically configured)

### Optional (for future features)
- `STRIPE_SECRET_KEY` - Stripe secret key for payments
- `VITE_STRIPE_PUBLIC_KEY` - Stripe publishable key
- `MAPBOX_TOKEN` - Mapbox API token for location features

## Code Quality & Best Practices

### Validation
- All API endpoints use Zod schemas for request validation
- Price fields coerce numbers and validate ranges
- Booking status updates constrained to valid state machine

### Error Handling
- Consistent error responses across all endpoints
- Try-catch blocks in all route handlers
- Proper HTTP status codes (400, 404, 500)

### Type Safety
- Shared TypeScript types between frontend and backend
- Drizzle ORM for type-safe database queries
- Zod schemas for runtime validation

## Future Enhancements
1. Implement booking form for users to create appointments
2. Add Stripe payment integration for booking payments
3. Integrate Mapbox for location selection
4. Add user authentication and authorization
5. Implement admin dashboard for managing bookings
6. Add email notifications for booking confirmations
7. Create mobile app version

## Design Guidelines
See `design_guidelines.md` for comprehensive design system documentation including:
- Typography hierarchy
- Layout patterns
- Component specifications
- Color usage
- Spacing system
- Interactive elements

## Architecture Notes

### Schema-First Development
The project follows a schema-first approach:
1. Define data models in `shared/schema.ts`
2. Create storage interface in `server/storage.ts`
3. Implement API routes in `server/routes.ts`
4. Build frontend components consuming the API

### Database Layer
- **IStorage Interface**: Defines contract for data operations
- **DatabaseStorage**: PostgreSQL implementation using Drizzle
- **Centralized**: All database access goes through storage layer

### Frontend Patterns
- React Query for data fetching and caching
- shadcn/ui components for consistent UI
- Responsive design with mobile-first approach
- Accessibility with proper ARIA labels and semantic HTML

## Production Readiness
✅ Database schema and migrations set up
✅ API validation and error handling
✅ Type-safe data flow
✅ Responsive, accessible UI
✅ SEO meta tags configured
✅ Environment variables properly managed

The MVP is production-ready for deployment!
