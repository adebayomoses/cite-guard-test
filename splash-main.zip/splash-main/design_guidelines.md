# Splash Car Wash - Comprehensive Design Guidelines

## Design Approach & Philosophy

**Reference-Based Approach**: Drawing inspiration from service booking platforms (Airbnb, Uber) combined with modern SaaS aesthetics (Stripe, Linear). Create a premium yet approachable experience that builds trust through clean design, strategic imagery, and clear value communication.

**Core Principles**:
- Trust through transparency: Clear pricing, process visualization, immediate booking confirmation
- Mobile-first booking flow: Seamless experience across all devices
- Visual confidence: Professional photography showcasing service quality
- Frictionless interaction: Minimize steps from landing to booking confirmation

## Typography System

**Primary Font**: Inter (Google Fonts) - Clean, modern, excellent readability
**Secondary Font**: Poppins (Google Fonts) - Headings for friendly, approachable feel

**Hierarchy**:
- Hero Headline: Poppins Bold, text-5xl lg:text-7xl
- Section Headers: Poppins SemiBold, text-3xl lg:text-5xl
- Feature Titles: Poppins Medium, text-xl lg:text-2xl
- Body Text: Inter Regular, text-base lg:text-lg
- Buttons: Inter SemiBold, text-sm uppercase tracking-wide
- Form Labels: Inter Medium, text-sm
- Captions: Inter Regular, text-xs lg:text-sm

## Layout & Spacing System

**Tailwind Spacing Units**: Use 4, 8, 12, 16, 20 for consistent rhythm
- Component padding: p-4 (mobile), p-8 (desktop)
- Section spacing: py-12 md:py-20 lg:py-32
- Element gaps: gap-4, gap-8, gap-12
- Container max-width: max-w-7xl for main content
- Text content: max-w-3xl for optimal readability

**Grid System**:
- Hero: Single column centered
- Services: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Features: grid-cols-1 lg:grid-cols-2
- Testimonials: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Footer: grid-cols-2 md:grid-cols-4

## Component Library

### Navigation
- Sticky header with blur backdrop (backdrop-blur-lg)
- Logo + Navigation links + "Book Now" CTA button
- Mobile: Hamburger menu with slide-in drawer
- Desktop: Horizontal nav with hover underline effects

### Hero Section (Large Image)
- Full-width background image: Professional car being washed, water droplets, shine
- Overlay: subtle gradient (from-black/40 to-transparent)
- Centered content: Headline + Subheadline + Primary CTA
- CTA Button: backdrop-blur-md bg-white/20 border border-white/30 with clean hover state
- Height: min-h-[80vh] with proper vertical centering

### Service Cards
- Rounded corners: rounded-2xl
- Padding: p-8
- Border: border-2 with subtle shadow
- Hover: Transform scale-105 with smooth transition
- Structure: Service icon → Title → Description → Price → "Select" button
- Icon treatment: Large size (h-12 w-12), positioned top of card

### Booking Flow Components
- Step indicator: Horizontal progress bar with numbered steps
- Service selector: Radio cards with visual selection state
- Date/Time picker: Calendar grid + time slot buttons
- Vehicle input: Dropdown + text fields with icons
- Summary card: Sticky sidebar showing selected options and total

### Trust Signals
- Stats counter section: grid-cols-2 lg:grid-cols-4
- Numbers: Poppins Bold, text-4xl with counting animation
- Labels: Inter Regular, text-sm
- Examples: "10,000+ Cars Washed", "4.9★ Average Rating"

### Testimonial Cards
- Rounded: rounded-xl
- Quote marks: Decorative element
- Structure: Quote text → Customer photo (circular, h-16 w-16) → Name → Rating stars
- Shadow: shadow-lg with hover elevation

### Footer
- Multi-column layout with sections:
  - Company info & logo
  - Quick links (Services, Pricing, Locations, About)
  - Contact information with icons
  - Social media links
  - Newsletter signup (email input + submit button)
- Bottom bar: Copyright, Terms, Privacy

### Form Elements
- Input fields: rounded-lg, p-4, border-2
- Focus state: Ring treatment (ring-2 ring-offset-2)
- Labels: Above inputs with required indicator (*)
- Buttons: Full width on mobile, auto on desktop
- Error states: Red border + error message below

### CTA Sections
- Full-width colored backgrounds
- Centered content with max-w-4xl
- Headline + Supporting text + Button group (Primary + Secondary)
- Strategic placement: After services, before footer, mid-page breaks

## Images & Visual Assets

**Hero Image**: 
- Large, high-quality photo of luxury vehicle being detailed
- Bright, clean aesthetic with water effects and shine
- Image should convey premium service quality
- Dimensions: 1920x1080 minimum, optimized for web

**Service Section Images**:
- Before/after comparison sliders
- Close-up shots of detailing work
- Clean facility photos
- Happy customers with clean cars

**Icons**:
- Use Heroicons (via CDN) throughout
- Consistent line-weight (stroke-2)
- Size: h-6 w-6 for inline, h-12 w-12 for feature icons

**Additional Visual Elements**:
- Process infographic: Simple illustrated steps (1. Book → 2. Drop-off → 3. Wash → 4. Pickup)
- Location map: Embedded Mapbox integration
- Gallery: Masonry grid of service results

## Page Sections (Homepage)

1. **Hero**: Large image background + headline + CTA (80vh)
2. **Services Grid**: 3-column showcase of wash packages (py-20)
3. **How It Works**: 4-step process with icons and descriptions (py-16)
4. **Trust Signals**: Stats counter section (py-12)
5. **Features**: 2-column benefits (Eco-friendly, Mobile app, etc.) (py-20)
6. **Testimonials**: 3-column customer reviews (py-16)
7. **Locations**: Map + address cards (py-20)
8. **Final CTA**: "Book Your Wash Today" full-width section (py-16)
9. **Footer**: Comprehensive multi-column footer (py-12)

## Interactive Elements

**Buttons**:
- Primary: Solid, rounded-lg, px-8 py-4, bold text
- Secondary: Outline, same sizing
- Hover: Subtle transform scale-105 + shadow increase
- Disabled: Reduced opacity + cursor-not-allowed

**Transitions**: Use transition-all duration-300 ease-in-out for smooth interactions

**Loading States**: Skeleton screens for booking flow, spinner for async operations

## Responsive Breakpoints

- Mobile: Default (< 768px) - Single column, stacked navigation
- Tablet: md (768px+) - 2 columns where appropriate
- Desktop: lg (1024px+) - Full multi-column layouts
- Wide: xl (1280px+) - Maximum container widths engaged