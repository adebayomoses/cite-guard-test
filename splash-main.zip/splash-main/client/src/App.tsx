import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import Booking from "@/pages/booking";
import Register from "@/pages/register";
import Login from "@/pages/login";
import DashboardHome from "@/pages/dashboard/home";
import DashboardServices from "@/pages/dashboard/services";
import DashboardActivity from "@/pages/dashboard/activity";
import DashboardAccount from "@/pages/dashboard/account";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home}/>
      <Route path="/booking" component={Booking}/>
      <Route path="/register" component={Register}/>
      <Route path="/login" component={Login}/>
      <Route path="/dashboard" component={DashboardHome}/>
      <Route path="/dashboard/services" component={DashboardServices}/>
      <Route path="/dashboard/activity" component={DashboardActivity}/>
      <Route path="/dashboard/account" component={DashboardAccount}/>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
