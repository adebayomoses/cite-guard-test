import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Droplet, Calendar, Car, User, Mail, Phone, FileText, ArrowLeft, Check } from "lucide-react";
import { insertBookingSchema } from "@shared/schema";

// Extended schema for form validation
const bookingFormSchema = insertBookingSchema.extend({
  scheduledTime: z.string().min(1, "Please select a date and time"),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

const serviceOptions = [
  { value: "basic", label: "Basic Wash", price: 29, description: "Exterior hand wash, tire cleaning, windows" },
  { value: "premium", label: "Premium Wash", price: 59, description: "Basic + interior vacuum, dashboard, wax" },
  { value: "deluxe", label: "Deluxe Detail", price: 129, description: "Premium + engine bay, leather, paint protection" },
];

const vehicleOptions = [
  { value: "sedan", label: "Sedan" },
  { value: "suv", label: "SUV" },
  { value: "truck", label: "Truck" },
  { value: "van", label: "Van" },
  { value: "coupe", label: "Coupe" },
];

export default function Booking() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState<string>("");

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      serviceType: "",
      vehicleType: "",
      scheduledTime: "",
      price: 0,
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      status: "pending",
      notes: "",
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormValues) => {
      // Convert ISO string to Date object for API
      const bookingData = {
        ...data,
        scheduledTime: new Date(data.scheduledTime),
      };
      const response = await apiRequest("POST", "/api/bookings", bookingData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: "Your car wash appointment has been scheduled successfully.",
      });
      setStep(4); // Success step
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormValues) => {
    createBookingMutation.mutate(data);
  };

  const handleServiceSelect = (value: string) => {
    const service = serviceOptions.find(s => s.value === value);
    if (service) {
      setSelectedService(value);
      form.setValue("serviceType", value);
      form.setValue("price", service.price);
      setStep(2);
    }
  };

  const getMinDateTime = () => {
    const now = new Date();
    now.setHours(now.getHours() + 2); // Minimum 2 hours from now
    return now.toISOString().slice(0, 16);
  };

  if (step === 4) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full text-center">
          <CardHeader>
            <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Check className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-serif">Booking Confirmed!</CardTitle>
            <CardDescription>
              Your car wash appointment has been successfully scheduled.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              You will receive a confirmation email shortly with all the details.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setLocation("/dashboard")} data-testid="button-back-dashboard">
                Go to Dashboard
              </Button>
              <Button className="flex-1" onClick={() => { setStep(1); setSelectedService(""); }} data-testid="button-book-another">
                Book Another
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-lg sticky top-0 z-50">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Button variant="ghost" onClick={() => setLocation("/")} data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="flex items-center gap-2">
            <Droplet className="h-6 w-6 text-primary" />
            <span className="font-serif text-xl font-bold">Splash</span>
          </div>
          <div className="w-20" /> {/* Spacer for centering */}
        </div>
      </header>

      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Progress Steps */}
        <div className="mb-12">
          <div className="flex items-center justify-center gap-4">
            {[1, 2, 3].map((num) => (
              <div key={num} className="flex items-center">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center font-semibold transition-colors ${
                  step >= num ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}>
                  {num}
                </div>
                {num < 3 && (
                  <div className={`h-1 w-16 mx-2 transition-colors ${
                    step > num ? "bg-primary" : "bg-muted"
                  }`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-16 mt-4 text-sm">
            <span className={step >= 1 ? "font-medium" : "text-muted-foreground"}>Service</span>
            <span className={step >= 2 ? "font-medium" : "text-muted-foreground"}>Details</span>
            <span className={step >= 3 ? "font-medium" : "text-muted-foreground"}>Confirm</span>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            {/* Step 1: Service Selection */}
            {step === 1 && (
              <div className="space-y-8">
                <div className="text-center mb-8">
                  <h1 className="font-serif font-bold text-3xl lg:text-4xl mb-2">Choose Your Service</h1>
                  <p className="text-muted-foreground">Select the perfect wash package for your vehicle</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {serviceOptions.map((service) => (
                    <Card
                      key={service.value}
                      className={`cursor-pointer hover-elevate transition-all border-2 ${
                        selectedService === service.value ? "border-primary" : ""
                      }`}
                      onClick={() => handleServiceSelect(service.value)}
                      data-testid={`card-service-${service.value}`}
                    >
                      <CardHeader>
                        <CardTitle className="font-serif text-xl">{service.label}</CardTitle>
                        <CardDescription>{service.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold mb-4">${service.price}</div>
                        <Button 
                          type="button"
                          className="w-full" 
                          variant={selectedService === service.value ? "default" : "outline"}
                          data-testid={`button-select-${service.value}`}
                        >
                          Select
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Vehicle & Schedule Details */}
            {step === 2 && (
              <div className="max-w-2xl mx-auto space-y-8">
                <div className="text-center mb-8">
                  <h1 className="font-serif font-bold text-3xl lg:text-4xl mb-2">Vehicle & Schedule</h1>
                  <p className="text-muted-foreground">Tell us about your vehicle and preferred time</p>
                </div>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Car className="h-5 w-5" />
                      Vehicle Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="vehicleType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vehicle Type *</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-vehicle-type">
                                <SelectValue placeholder="Select vehicle type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {vehicleOptions.map((vehicle) => (
                                <SelectItem key={vehicle.value} value={vehicle.value}>
                                  {vehicle.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="scheduledTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Preferred Date & Time *</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Input
                                type="datetime-local"
                                min={getMinDateTime()}
                                className="pl-10"
                                {...field}
                                data-testid="input-scheduled-time"
                              />
                            </div>
                          </FormControl>
                          <FormDescription>
                            Select a time at least 2 hours from now
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(1)}
                    className="flex-1"
                    data-testid="button-previous"
                  >
                    Previous
                  </Button>
                  <Button
                    type="button"
                    onClick={() => {
                      const vehicleType = form.getValues("vehicleType");
                      const scheduledTime = form.getValues("scheduledTime");
                      if (vehicleType && scheduledTime) {
                        setStep(3);
                      } else {
                        toast({
                          title: "Missing Information",
                          description: "Please fill in all required fields",
                          variant: "destructive",
                        });
                      }
                    }}
                    className="flex-1"
                    data-testid="button-next"
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Customer Information */}
            {step === 3 && (
              <div className="max-w-2xl mx-auto space-y-8">
                <div className="text-center mb-8">
                  <h1 className="font-serif font-bold text-3xl lg:text-4xl mb-2">Contact Information</h1>
                  <p className="text-muted-foreground">How can we reach you?</p>
                </div>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Your Details
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="customerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name *</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} data-testid="input-customer-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="customerEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email *</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Input
                                type="email"
                                placeholder="john@example.com"
                                className="pl-10"
                                {...field}
                                data-testid="input-customer-email"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="customerPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number *</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Input
                                type="tel"
                                placeholder="(555) 123-4567"
                                className="pl-10"
                                {...field}
                                data-testid="input-customer-phone"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Special Requests (Optional)</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Textarea
                                placeholder="Any specific requests or concerns?"
                                className="pl-10 min-h-24"
                                {...field}
                                value={field.value || ""}
                                data-testid="input-notes"
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Booking Summary */}
                <Card className="border-primary/20 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="text-lg">Booking Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Service:</span>
                      <span className="font-medium">
                        {serviceOptions.find(s => s.value === form.getValues("serviceType"))?.label}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Vehicle:</span>
                      <span className="font-medium capitalize">{form.getValues("vehicleType")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date & Time:</span>
                      <span className="font-medium">
                        {form.getValues("scheduledTime") 
                          ? new Date(form.getValues("scheduledTime")).toLocaleString()
                          : "Not selected"}
                      </span>
                    </div>
                    <div className="pt-3 border-t flex justify-between text-lg">
                      <span className="font-semibold">Total:</span>
                      <span className="font-bold text-primary">${form.getValues("price")}</span>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep(2)}
                    className="flex-1"
                    data-testid="button-previous-step3"
                  >
                    Previous
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1"
                    disabled={createBookingMutation.isPending}
                    data-testid="button-confirm-booking"
                  >
                    {createBookingMutation.isPending ? "Confirming..." : "Confirm Booking"}
                  </Button>
                </div>
              </div>
            )}
          </form>
        </Form>
      </div>
    </div>
  );
}
