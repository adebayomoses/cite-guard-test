import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Droplet, Sparkles, Clock, Shield, Star, CheckCircle2, MapPin, Phone, Mail } from "lucide-react";
import heroImage from "@assets/generated_images/luxury_car_wash_hero_754dd333.png";

export default function Home() {
  const [, setLocation] = useLocation();
  const [apiTestResult, setApiTestResult] = useState<string>("");
  const [isTestingApi, setIsTestingApi] = useState(false);

  const testApiConnection = async () => {
    setIsTestingApi(true);
    try {
      const response = await fetch("/api/hello");
      const data = await response.json();
      setApiTestResult(`API Response: ${JSON.stringify(data, null, 2)}`);
    } catch (error) {
      setApiTestResult(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsTestingApi(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <header className="sticky top-0 z-50 w-full border-b backdrop-blur-lg bg-background/80">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Droplet className="h-8 w-8 text-primary" />
            <span className="font-serif text-2xl font-bold">Splash</span>
          </div>
          <nav className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-services">
              Services
            </a>
            <a href="#how-it-works" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-how-it-works">
              How It Works
            </a>
            <a href="#locations" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-locations">
              Locations
            </a>
            <a href="#contact" className="text-sm font-medium hover:text-primary transition-colors" data-testid="link-contact">
              Contact
            </a>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={() => setLocation("/login")} data-testid="button-login-header">Log In</Button>
            <Button onClick={() => setLocation("/booking")} data-testid="button-book-now-header">Book Now</Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 to-transparent"></div>
        </div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="font-serif font-bold text-5xl md:text-6xl lg:text-7xl text-white mb-6" data-testid="text-hero-title">
            Splash Car Wash
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
            Premium car detailing services that make your vehicle shine. Professional, eco-friendly, and fast.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="backdrop-blur-md bg-white/20 border border-white/30 hover:bg-white/30 text-white text-base font-semibold px-8 py-6"
              onClick={() => setLocation("/booking")}
              data-testid="button-book-wash"
            >
              Book Your Wash
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="backdrop-blur-md bg-white/10 border-white/40 hover:bg-white/20 text-white text-base font-semibold px-8 py-6"
              onClick={testApiConnection}
              disabled={isTestingApi}
              data-testid="button-test-api"
            >
              {isTestingApi ? "Testing..." : "Test API Connection"}
            </Button>
          </div>
          {apiTestResult && (
            <div className="mt-6 p-4 backdrop-blur-md bg-white/10 border border-white/30 rounded-lg">
              <pre className="text-white text-sm text-left overflow-x-auto" data-testid="text-api-result">
                {apiTestResult}
              </pre>
            </div>
          )}
        </div>
      </section>

      {/* Trust Signals */}
      <section className="py-12 bg-card border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="font-serif font-bold text-4xl text-primary mb-2" data-testid="text-stat-cars">10,000+</div>
              <div className="text-sm text-muted-foreground">Cars Washed</div>
            </div>
            <div className="text-center">
              <div className="font-serif font-bold text-4xl text-primary mb-2" data-testid="text-stat-rating">4.9★</div>
              <div className="text-sm text-muted-foreground">Average Rating</div>
            </div>
            <div className="text-center">
              <div className="font-serif font-bold text-4xl text-primary mb-2" data-testid="text-stat-customers">5,000+</div>
              <div className="text-sm text-muted-foreground">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="font-serif font-bold text-4xl text-primary mb-2" data-testid="text-stat-locations">8</div>
              <div className="text-sm text-muted-foreground">Locations</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section id="services" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-serif font-semibold text-3xl lg:text-5xl mb-4" data-testid="text-services-title">
              Our Services
            </h2>
            <p className="text-muted-foreground text-base lg:text-lg max-w-2xl mx-auto">
              Choose the perfect package for your vehicle
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Basic Wash */}
            <Card className="hover-elevate transition-all duration-300 border-2" data-testid="card-service-basic">
              <CardHeader className="space-y-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Droplet className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="font-serif text-xl lg:text-2xl">Basic Wash</CardTitle>
                <CardDescription>Essential cleaning for your vehicle</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Exterior hand wash</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Tire cleaning</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Window cleaning</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="text-3xl font-bold mb-4">$29</div>
                  <Button className="w-full" onClick={() => setLocation("/booking")} data-testid="button-select-basic">Select Package</Button>
                </div>
              </CardContent>
            </Card>

            {/* Premium Wash */}
            <Card className="hover-elevate transition-all duration-300 border-2 border-primary relative" data-testid="card-service-premium">
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">Most Popular</Badge>
              <CardHeader className="space-y-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="font-serif text-xl lg:text-2xl">Premium Wash</CardTitle>
                <CardDescription>Complete interior and exterior care</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Everything in Basic</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Interior vacuuming</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Dashboard cleaning</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Wax application</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="text-3xl font-bold mb-4">$59</div>
                  <Button className="w-full" onClick={() => setLocation("/booking")} data-testid="button-select-premium">Select Package</Button>
                </div>
              </CardContent>
            </Card>

            {/* Deluxe Detail */}
            <Card className="hover-elevate transition-all duration-300 border-2" data-testid="card-service-deluxe">
              <CardHeader className="space-y-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Star className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="font-serif text-xl lg:text-2xl">Deluxe Detail</CardTitle>
                <CardDescription>Ultimate luxury detailing experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Everything in Premium</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Engine bay cleaning</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Leather conditioning</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <span>Paint protection</span>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <div className="text-3xl font-bold mb-4">$129</div>
                  <Button className="w-full" onClick={() => setLocation("/booking")} data-testid="button-select-deluxe">Select Package</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-16 bg-card">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-serif font-semibold text-3xl lg:text-5xl mb-4">
              How It Works
            </h2>
            <p className="text-muted-foreground text-base lg:text-lg max-w-2xl mx-auto">
              Simple steps to a spotless car
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h3 className="font-serif font-medium text-xl">Book Online</h3>
              <p className="text-sm text-muted-foreground">
                Choose your service and schedule a convenient time
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <h3 className="font-serif font-medium text-xl">Drop Off</h3>
              <p className="text-sm text-muted-foreground">
                Bring your car to our location or use our pickup service
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <h3 className="font-serif font-medium text-xl">We Wash</h3>
              <p className="text-sm text-muted-foreground">
                Our professionals detail your vehicle with care
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">4</span>
              </div>
              <h3 className="font-serif font-medium text-xl">Pick Up</h3>
              <p className="text-sm text-muted-foreground">
                Collect your sparkling clean car and enjoy
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-serif font-semibold text-3xl lg:text-5xl mb-4">
              Why Choose Splash
            </h2>
            <p className="text-muted-foreground text-base lg:text-lg max-w-2xl mx-auto">
              Premium service you can trust
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="p-8">
              <div className="flex gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Droplet className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif font-medium text-xl mb-2">Eco-Friendly</h3>
                  <p className="text-muted-foreground">
                    We use environmentally safe products and water-saving techniques to protect our planet
                  </p>
                </div>
              </div>
            </Card>
            <Card className="p-8">
              <div className="flex gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif font-medium text-xl mb-2">Fast Service</h3>
                  <p className="text-muted-foreground">
                    Most services completed within 30-60 minutes so you can get back on the road
                  </p>
                </div>
              </div>
            </Card>
            <Card className="p-8">
              <div className="flex gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif font-medium text-xl mb-2">Satisfaction Guarantee</h3>
                  <p className="text-muted-foreground">
                    Not happy? We'll rewash your car for free or provide a full refund
                  </p>
                </div>
              </div>
            </Card>
            <Card className="p-8">
              <div className="flex gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Star className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif font-medium text-xl mb-2">Premium Products</h3>
                  <p className="text-muted-foreground">
                    We use only the highest quality cleaning products and equipment
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-serif font-bold text-3xl lg:text-5xl mb-4">
            Ready to Make Your Car Shine?
          </h2>
          <p className="text-lg lg:text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Book your appointment today and experience the Splash difference
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            className="text-base font-semibold px-8 py-6"
            onClick={() => setLocation("/booking")}
            data-testid="button-book-now-cta"
          >
            Book Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="py-12 border-t">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Press</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#services" className="hover:text-foreground transition-colors">Pricing</a></li>
                <li><a href="#services" className="hover:text-foreground transition-colors">Packages</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Membership</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>(555) 123-4567</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>info@splash.com</span>
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>8 Locations</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Droplet className="h-5 w-5 text-primary" />
              <span>© 2025 Splash Car Wash. All rights reserved.</span>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-foreground transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-foreground transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
