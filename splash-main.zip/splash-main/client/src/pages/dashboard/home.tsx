import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Car, Sparkles, MapPin, Home as HomeIcon } from "lucide-react";
import type { User } from "@shared/schema";
import DashboardLayout from "@/components/dashboard-layout";

export default function DashboardHome() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId");
    if (!storedUserId) {
      toast({
        title: "Not Logged In",
        description: "Please log in to view dashboard",
        variant: "destructive",
      });
      setLocation("/login");
    } else {
      setUserId(storedUserId);
    }
  }, [setLocation, toast]);

  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  if (!user) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Loading...</p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* What's New Section */}
        <div>
          <h2 className="text-xl font-bold mb-3">What's New!</h2>
          <div className="grid grid-cols-2 gap-3">
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white border-0">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <p className="text-xs font-medium">Get 50% off your</p>
                  <p className="text-lg font-bold leading-tight">First Car Wash!</p>
                  <div className="flex items-center gap-2 pt-2">
                    <Car className="h-8 w-8" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-pink-400 to-pink-500 text-white border-0">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <p className="text-xs font-medium">Premium members get</p>
                  <p className="text-lg font-bold leading-tight">$10 Discount</p>
                  <div className="flex items-center justify-end pt-2">
                    <Calendar className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Choose a Package Section */}
        <div>
          <h2 className="text-xl font-bold mb-3">Choose a Package</h2>
          
          {/* Mobile Wash */}
          <Card className="mb-3 overflow-hidden hover-elevate">
            <CardContent className="p-0">
              <div className="flex items-center">
                <div className="flex-1 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Car className="h-5 w-5 text-muted-foreground" />
                    <h3 className="font-semibold">Mobile Wash</h3>
                  </div>
                  <p className="text-xs text-muted-foreground">We come to you</p>
                </div>
                <div className="w-32 h-24 bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                  <Car className="h-12 w-12 text-slate-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Visit Wash Station */}
          <Card className="mb-3 overflow-hidden hover-elevate">
            <CardContent className="p-0">
              <div className="flex items-center">
                <div className="flex-1 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <h3 className="font-semibold">Visit Wash Station</h3>
                  </div>
                  <p className="text-xs text-muted-foreground">At our location</p>
                </div>
                <div className="w-32 h-24 bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  <MapPin className="h-12 w-12 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Household Hub */}
          <Card className="mb-3 overflow-hidden relative">
            <Badge 
              className="absolute top-2 left-2 z-10 bg-red-600 text-white border-0 text-xs px-2 py-0.5"
            >
              Coming Soon
            </Badge>
            <CardContent className="p-0 opacity-60">
              <div className="flex items-center">
                <div className="flex-1 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <HomeIcon className="h-5 w-5 text-muted-foreground" />
                    <h3 className="font-semibold">Household Hub</h3>
                  </div>
                  <p className="text-xs text-muted-foreground">Complete home care</p>
                </div>
                <div className="w-32 h-24 bg-gradient-to-br from-purple-100 to-purple-200 flex items-center justify-center">
                  <HomeIcon className="h-12 w-12 text-purple-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Book a Wash Button */}
        <div className="pt-2">
          <Button 
            className="w-full h-12 text-base font-semibold"
            onClick={() => setLocation("/booking")}
            data-testid="button-book-wash"
          >
            <Sparkles className="h-5 w-5 mr-2" />
            BOOK A WASH
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
}
