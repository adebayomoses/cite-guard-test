import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Sparkles } from "lucide-react";
import DashboardLayout from "@/components/dashboard-layout";

const serviceOptions = [
  {
    value: "basic",
    title: "Basic Wash",
    price: 29,
    description: "Perfect for regular maintenance",
    features: [
      "Exterior hand wash",
      "Tire cleaning",
      "Window cleaning",
      "Quick dry",
    ],
  },
  {
    value: "premium",
    title: "Premium Wash",
    price: 59,
    description: "Extra care for your vehicle",
    features: [
      "Everything in Basic",
      "Interior vacuum",
      "Dashboard cleaning",
      "Wax application",
    ],
    popular: true,
  },
  {
    value: "deluxe",
    title: "Deluxe Detail",
    price: 129,
    description: "Complete professional detailing",
    features: [
      "Everything in Premium",
      "Engine bay cleaning",
      "Leather conditioning",
      "Paint protection",
    ],
  },
];

export default function DashboardServices() {
  const [, setLocation] = useLocation();

  return (
    <DashboardLayout>
      <div className="container mx-auto px-4 py-6 space-y-6">
        <div>
          <h2 className="text-2xl font-serif font-bold mb-1">Our Services</h2>
          <p className="text-muted-foreground">Choose the perfect package for your vehicle</p>
        </div>

        <div className="space-y-4">
          {serviceOptions.map((service) => (
            <Card
              key={service.value}
              className={`hover-elevate transition-all ${
                service.popular ? "border-primary shadow-md" : ""
              }`}
              data-testid={`card-service-${service.value}`}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <CardTitle className="text-xl font-serif">{service.title}</CardTitle>
                      {service.popular && (
                        <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full font-medium">
                          Popular
                        </span>
                      )}
                    </div>
                    <CardDescription>{service.description}</CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold">${service.price}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
                <Button
                  className="w-full"
                  onClick={() => setLocation("/booking")}
                  data-testid={`button-book-${service.value}`}
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Book {service.title}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
