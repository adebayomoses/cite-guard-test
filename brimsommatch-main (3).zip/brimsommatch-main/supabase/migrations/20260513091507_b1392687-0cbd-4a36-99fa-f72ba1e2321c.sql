
CREATE OR REPLACE FUNCTION public.has_mod_permission(_user_id uuid, _section text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.moderator_permissions
    WHERE user_id = _user_id AND section = _section
  );
$$;

CREATE POLICY "Mods with careers perm can view job applications"
ON public.job_applications FOR SELECT TO authenticated
USING (public.has_mod_permission(auth.uid(), 'careers'));

CREATE POLICY "Mods with careers perm can update job applications"
ON public.job_applications FOR UPDATE TO authenticated
USING (public.has_mod_permission(auth.uid(), 'careers'));

CREATE POLICY "Mods with careers perm can delete job applications"
ON public.job_applications FOR DELETE TO authenticated
USING (public.has_mod_permission(auth.uid(), 'careers'));
