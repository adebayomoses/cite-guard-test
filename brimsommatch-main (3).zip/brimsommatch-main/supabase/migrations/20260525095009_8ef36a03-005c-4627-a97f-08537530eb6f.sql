
-- 1. Protect testimonial email column from public/anon exposure
REVOKE SELECT (email) ON public.testimonials FROM anon, authenticated;

-- Admin-only RPC to list testimonials including email
CREATE OR REPLACE FUNCTION public.admin_list_testimonials()
RETURNS TABLE (
  id uuid,
  name text,
  email text,
  message text,
  rating integer,
  image_url text,
  is_approved boolean,
  created_at timestamptz,
  published_at timestamptz
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT t.id, t.name, t.email, t.message, t.rating, t.image_url, t.is_approved, t.created_at, t.published_at
  FROM public.testimonials t
  WHERE public.has_role(auth.uid(), 'admin'::app_role)
  ORDER BY t.created_at DESC;
$$;

REVOKE EXECUTE ON FUNCTION public.admin_list_testimonials() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_list_testimonials() TO authenticated;

-- 2. Allow admins to audit email_send_log via the client (in addition to service role)
CREATE POLICY "Admins can read email send log"
ON public.email_send_log
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));
