-- Match Me analysis history (per user, capped at 10 most recent)
CREATE TABLE IF NOT EXISTS public.match_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  scholarship_text TEXT NOT NULL,
  result JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_match_history_user_created
  ON public.match_history(user_id, created_at DESC);

ALTER TABLE public.match_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own match history"
ON public.match_history FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users insert own match history"
ON public.match_history FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users delete own match history"
ON public.match_history FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins view all match history"
ON public.match_history FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Auto-prune: keep only the 10 most recent rows per user
CREATE OR REPLACE FUNCTION public.prune_match_history()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.match_history
  WHERE user_id = NEW.user_id
    AND id NOT IN (
      SELECT id FROM public.match_history
      WHERE user_id = NEW.user_id
      ORDER BY created_at DESC
      LIMIT 10
    );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prune_match_history ON public.match_history;
CREATE TRIGGER trg_prune_match_history
AFTER INSERT ON public.match_history
FOR EACH ROW EXECUTE FUNCTION public.prune_match_history();