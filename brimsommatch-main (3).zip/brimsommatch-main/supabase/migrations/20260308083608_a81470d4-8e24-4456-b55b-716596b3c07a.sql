-- Add created_by and updated_by columns to scholarships
ALTER TABLE public.scholarships ADD COLUMN created_by uuid;
ALTER TABLE public.scholarships ADD COLUMN updated_by uuid;

-- Allow admins to view all activity logs (for moderator tracking)
CREATE POLICY "Admins can view all activity"
ON public.activity_log
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));