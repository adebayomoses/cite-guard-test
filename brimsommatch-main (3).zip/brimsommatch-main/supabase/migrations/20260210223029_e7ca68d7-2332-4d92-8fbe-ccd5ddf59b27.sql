
-- Chat rooms
CREATE TABLE public.chat_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_rooms ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view rooms"
  ON public.chat_rooms FOR SELECT
  TO authenticated USING (true);

-- Chat messages
CREATE TABLE public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.chat_rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  user_name text NOT NULL DEFAULT '',
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view messages"
  ON public.chat_messages FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "Users can insert own messages"
  ON public.chat_messages FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;

-- Seed default rooms
INSERT INTO public.chat_rooms (name, description) VALUES
  ('General Discussion', 'Chat about anything scholarship-related'),
  ('Scholarship Tips', 'Share and discover tips for winning scholarships'),
  ('Interview Prep', 'Practice and discuss scholarship interview strategies'),
  ('Essay Writing', 'Get feedback and share essay writing advice');
