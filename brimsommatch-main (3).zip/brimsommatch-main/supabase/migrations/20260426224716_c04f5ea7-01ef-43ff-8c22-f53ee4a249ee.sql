
ALTER TABLE public.testimonials ADD COLUMN IF NOT EXISTS image_url TEXT;

INSERT INTO storage.buckets (id, name, public)
VALUES ('testimonial-images', 'testimonial-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can view testimonial images"
ON storage.objects FOR SELECT
USING (bucket_id = 'testimonial-images');

CREATE POLICY "Anyone can upload testimonial images"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'testimonial-images');

CREATE POLICY "Admins can delete testimonial images"
ON storage.objects FOR DELETE
USING (bucket_id = 'testimonial-images' AND has_role(auth.uid(), 'admin'::app_role));
