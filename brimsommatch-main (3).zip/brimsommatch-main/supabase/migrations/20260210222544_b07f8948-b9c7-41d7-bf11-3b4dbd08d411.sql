
-- saved_scholarships table
CREATE TABLE public.saved_scholarships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  scholarship_id uuid NOT NULL REFERENCES public.scholarships(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, scholarship_id)
);

ALTER TABLE public.saved_scholarships ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own saved scholarships"
ON public.saved_scholarships FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can save scholarships"
ON public.saved_scholarships FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unsave scholarships"
ON public.saved_scholarships FOR DELETE
USING (auth.uid() = user_id);

-- activity_log table
CREATE TABLE public.activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  action text NOT NULL,
  detail text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own activity"
ON public.activity_log FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activity"
ON public.activity_log FOR INSERT
WITH CHECK (auth.uid() = user_id);
