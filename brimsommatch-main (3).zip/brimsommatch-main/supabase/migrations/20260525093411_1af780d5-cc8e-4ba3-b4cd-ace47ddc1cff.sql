
-- Chat images: require uploader to own the folder path
DROP POLICY IF EXISTS "Authenticated users can upload chat images" ON storage.objects;
CREATE POLICY "Authenticated users can upload chat images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'chat-images'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Job applications: restrict to authenticated users uploading into their own folder
DROP POLICY IF EXISTS "Anyone can upload resumes" ON storage.objects;
CREATE POLICY "Authenticated users can upload job application resumes"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'job-applications'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Testimonial images: restrict to authenticated users uploading into their own folder
DROP POLICY IF EXISTS "Anyone can upload testimonial images" ON storage.objects;
CREATE POLICY "Authenticated users can upload testimonial images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'testimonial-images'
  AND (storage.foldername(name))[1] = auth.uid()::text
);
