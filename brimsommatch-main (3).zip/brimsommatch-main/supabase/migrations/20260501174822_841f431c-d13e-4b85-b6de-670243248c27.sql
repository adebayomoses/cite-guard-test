-- Phase 2: Vector embeddings for semantic essay retrieval

-- 1) Enable pgvector
CREATE EXTENSION IF NOT EXISTS vector;

-- 2) Add embedding column (768 dims = Google text-embedding-004)
ALTER TABLE public.winning_essays
  ADD COLUMN IF NOT EXISTS embedding vector(768),
  ADD COLUMN IF NOT EXISTS embedding_updated_at TIMESTAMPTZ;

-- 3) Approximate nearest-neighbor index (cosine distance)
CREATE INDEX IF NOT EXISTS winning_essays_embedding_idx
  ON public.winning_essays
  USING ivfflat (embedding vector_cosine_ops)
  WITH (lists = 50);

-- 4) Semantic match RPC — admin-only via SECURITY DEFINER + role check
CREATE OR REPLACE FUNCTION public.match_winning_essays(
  query_embedding vector(768),
  match_count int DEFAULT 5,
  filter_doc_type text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  title text,
  document_type text,
  scholarship_name text,
  country text,
  field_of_study text,
  degree_level text,
  year_won int,
  content text,
  tags text[],
  similarity float
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only admins (or the service role used by edge functions) may call this
  IF auth.uid() IS NOT NULL AND NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  RETURN QUERY
  SELECT
    w.id,
    w.title,
    w.document_type,
    w.scholarship_name,
    w.country,
    w.field_of_study,
    w.degree_level,
    w.year_won,
    w.content,
    w.tags,
    1 - (w.embedding <=> query_embedding) AS similarity
  FROM public.winning_essays w
  WHERE w.embedding IS NOT NULL
    AND (filter_doc_type IS NULL OR w.document_type = filter_doc_type)
  ORDER BY w.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;