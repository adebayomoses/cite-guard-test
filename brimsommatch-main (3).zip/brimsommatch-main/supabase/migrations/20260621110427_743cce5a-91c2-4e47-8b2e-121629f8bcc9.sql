
-- Hide internal staff UUIDs from anonymous users on public scholarships
REVOKE SELECT (created_by, updated_by, approved_by, assigned_reviewer_id) ON public.scholarships FROM anon;

-- Allow anonymous visitors to read intake cycles for publicly visible scholarships
DROP POLICY IF EXISTS "Anyone can view intakes for approved scholarships" ON public.scholarship_intakes;
CREATE POLICY "Anyone can view intakes for approved scholarships"
ON public.scholarship_intakes
FOR SELECT
TO anon, authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.scholarships s
    WHERE s.id = scholarship_intakes.scholarship_id
      AND s.status = 'approved'
      AND s.is_active = true
  )
);
GRANT SELECT ON public.scholarship_intakes TO anon;
