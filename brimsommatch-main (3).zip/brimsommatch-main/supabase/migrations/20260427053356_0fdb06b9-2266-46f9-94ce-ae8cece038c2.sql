CREATE TABLE public.scholarship_intakes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  scholarship_id uuid NOT NULL REFERENCES public.scholarships(id) ON DELETE CASCADE,
  term text NOT NULL CHECK (term IN ('fall','spring','summer','winter','custom')),
  custom_label text,
  open_date date,
  close_date date,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX idx_scholarship_intakes_scholarship_id ON public.scholarship_intakes(scholarship_id);
CREATE INDEX idx_scholarship_intakes_close_date ON public.scholarship_intakes(close_date);

ALTER TABLE public.scholarship_intakes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view intakes"
ON public.scholarship_intakes FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admins/mods/creators can insert intakes"
ON public.scholarship_intakes FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
  OR EXISTS (SELECT 1 FROM public.scholarships s WHERE s.id = scholarship_id AND s.created_by = auth.uid())
);

CREATE POLICY "Admins/mods/creators can update intakes"
ON public.scholarship_intakes FOR UPDATE
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
  OR EXISTS (SELECT 1 FROM public.scholarships s WHERE s.id = scholarship_id AND s.created_by = auth.uid())
);

CREATE POLICY "Admins/mods/creators can delete intakes"
ON public.scholarship_intakes FOR DELETE
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
  OR EXISTS (SELECT 1 FROM public.scholarships s WHERE s.id = scholarship_id AND s.created_by = auth.uid())
);

CREATE TRIGGER update_scholarship_intakes_updated_at
BEFORE UPDATE ON public.scholarship_intakes
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();