
CREATE TABLE public.advisor_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  title text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.advisor_conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own conversations" ON public.advisor_conversations
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own conversations" ON public.advisor_conversations
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own conversations" ON public.advisor_conversations
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own conversations" ON public.advisor_conversations
  FOR DELETE USING (auth.uid() = user_id);

CREATE INDEX idx_advisor_conv_user_updated ON public.advisor_conversations(user_id, updated_at DESC);

CREATE TRIGGER trg_advisor_conv_updated
  BEFORE UPDATE ON public.advisor_conversations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.advisor_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.advisor_conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user','assistant')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.advisor_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view messages in own conversations" ON public.advisor_messages
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM public.advisor_conversations c
    WHERE c.id = conversation_id AND c.user_id = auth.uid()
  ));
CREATE POLICY "Users insert messages in own conversations" ON public.advisor_messages
  FOR INSERT WITH CHECK (EXISTS (
    SELECT 1 FROM public.advisor_conversations c
    WHERE c.id = conversation_id AND c.user_id = auth.uid()
  ));
CREATE POLICY "Users delete messages in own conversations" ON public.advisor_messages
  FOR DELETE USING (EXISTS (
    SELECT 1 FROM public.advisor_conversations c
    WHERE c.id = conversation_id AND c.user_id = auth.uid()
  ));

CREATE INDEX idx_advisor_msg_conv_created ON public.advisor_messages(conversation_id, created_at);

CREATE OR REPLACE FUNCTION public.bump_advisor_conversation()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.advisor_conversations SET updated_at = now() WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_bump_advisor_conv
  AFTER INSERT ON public.advisor_messages
  FOR EACH ROW EXECUTE FUNCTION public.bump_advisor_conversation();
