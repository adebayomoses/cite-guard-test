
ALTER TABLE public.scholarships
  ADD COLUMN IF NOT EXISTS resubmitted_at timestamptz,
  ADD COLUMN IF NOT EXISTS resubmission_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS previous_rejection_reason text;

CREATE OR REPLACE FUNCTION public.enforce_scholarship_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
      NEW.status := 'pending';
      NEW.approved_by := NULL;
      NEW.approved_at := NULL;
      NEW.is_active := false;
    END IF;
    NEW.submitted_at := now();
  END IF;

  IF TG_OP = 'UPDATE' THEN
    -- If submitter (non-admin) edits their rejected item, flip it back to pending
    IF auth.uid() = NEW.created_by
       AND NOT public.has_role(auth.uid(), 'admin'::app_role)
       AND OLD.status = 'rejected' THEN
      NEW.status := 'pending';
      NEW.previous_rejection_reason := OLD.rejection_reason;
      NEW.rejection_reason := NULL;
      NEW.is_active := false;
      NEW.submitted_at := now();
      NEW.resubmitted_at := now();
      NEW.resubmission_count := COALESCE(OLD.resubmission_count, 0) + 1;
    END IF;

    -- Stamp approver when status flips to approved
    IF NEW.status = 'approved' AND OLD.status <> 'approved' THEN
      NEW.approved_by := auth.uid();
      NEW.approved_at := now();
      NEW.is_active := true;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;
