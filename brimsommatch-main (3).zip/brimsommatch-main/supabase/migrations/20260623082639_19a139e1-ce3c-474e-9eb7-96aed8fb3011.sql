
-- 1) Allow 'general' as a valid intake term
ALTER TABLE public.scholarship_intakes
  DROP CONSTRAINT IF EXISTS scholarship_intakes_term_check;

ALTER TABLE public.scholarship_intakes
  ADD CONSTRAINT scholarship_intakes_term_check
  CHECK (term = ANY (ARRAY['general'::text, 'fall'::text, 'spring'::text, 'summer'::text, 'winter'::text, 'custom'::text]));

-- 2) Backfill: for every scholarship that has a legacy deadline but no intakes,
--    create a single 'general' intake using that deadline as the close date.
INSERT INTO public.scholarship_intakes (scholarship_id, term, close_date, sort_order)
SELECT s.id, 'general', s.deadline, 0
FROM public.scholarships s
WHERE s.deadline IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM public.scholarship_intakes i WHERE i.scholarship_id = s.id
  );
