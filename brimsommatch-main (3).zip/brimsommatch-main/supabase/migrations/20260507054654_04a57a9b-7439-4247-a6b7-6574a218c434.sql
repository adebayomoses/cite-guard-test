-- Approval team: admins/moderators eligible to receive scholarship submissions for review
CREATE TABLE IF NOT EXISTS public.approval_team_members (
  user_id uuid PRIMARY KEY,
  added_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.approval_team_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage approval team"
ON public.approval_team_members
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Members can view approval team"
ON public.approval_team_members
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role) OR user_id = auth.uid() OR public.has_moderator_section(auth.uid(), 'scholarships'));