INSERT INTO public.quick_actions (label, icon_name, route, sort_order, is_enabled)
VALUES ('Match Me', 'Wand2', '/brim-ai-chat?match=1', 11, true);