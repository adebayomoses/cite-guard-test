CREATE OR REPLACE FUNCTION public.refresh_scholarship_next_dates(_scholarship_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _next_close date;
  _last_close date;
  _selected_close date;
  _selected_open date;
BEGIN
  SELECT min(close_date)
    INTO _next_close
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND close_date IS NOT NULL
    AND close_date >= current_date;

  SELECT max(close_date)
    INTO _last_close
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND close_date IS NOT NULL
    AND close_date < current_date;

  _selected_close := COALESCE(_next_close, _last_close);

  SELECT open_date
    INTO _selected_open
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND close_date IS NOT DISTINCT FROM _selected_close
  ORDER BY sort_order ASC, open_date NULLS LAST
  LIMIT 1;

  IF _selected_open IS NULL THEN
    SELECT COALESCE(
      (SELECT min(open_date)
       FROM public.scholarship_intakes
       WHERE scholarship_id = _scholarship_id
         AND open_date IS NOT NULL
         AND open_date >= current_date),
      (SELECT max(open_date)
       FROM public.scholarship_intakes
       WHERE scholarship_id = _scholarship_id
         AND open_date IS NOT NULL
         AND open_date < current_date)
    )
    INTO _selected_open;
  END IF;

  UPDATE public.scholarships
  SET next_close_date = _selected_close,
      next_open_date = _selected_open
  WHERE id = _scholarship_id;
END;
$$;

UPDATE public.scholarships s
SET next_close_date = computed.selected_close,
    next_open_date = COALESCE(selected_intake.open_date, fallback_open.open_date)
FROM (
  SELECT s2.id,
         COALESCE(
           (SELECT min(close_date)
            FROM public.scholarship_intakes i
            WHERE i.scholarship_id = s2.id
              AND i.close_date IS NOT NULL
              AND i.close_date >= current_date),
           (SELECT max(close_date)
            FROM public.scholarship_intakes i
            WHERE i.scholarship_id = s2.id
              AND i.close_date IS NOT NULL
              AND i.close_date < current_date)
         ) AS selected_close
  FROM public.scholarships s2
) computed
LEFT JOIN LATERAL (
  SELECT i.open_date
  FROM public.scholarship_intakes i
  WHERE i.scholarship_id = computed.id
    AND i.close_date IS NOT DISTINCT FROM computed.selected_close
  ORDER BY i.sort_order ASC, i.open_date NULLS LAST
  LIMIT 1
) selected_intake ON true
LEFT JOIN LATERAL (
  SELECT COALESCE(
    (SELECT min(open_date)
     FROM public.scholarship_intakes i
     WHERE i.scholarship_id = computed.id
       AND i.open_date IS NOT NULL
       AND i.open_date >= current_date),
    (SELECT max(open_date)
     FROM public.scholarship_intakes i
     WHERE i.scholarship_id = computed.id
       AND i.open_date IS NOT NULL
       AND i.open_date < current_date)
  ) AS open_date
) fallback_open ON true
WHERE s.id = computed.id;