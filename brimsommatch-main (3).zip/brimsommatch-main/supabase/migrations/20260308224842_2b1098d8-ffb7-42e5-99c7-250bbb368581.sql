
-- Create app_downloads table
CREATE TABLE public.app_downloads (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  platform text NOT NULL, -- 'android', 'ios', 'windows'
  file_url text,
  file_name text,
  version text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Unique constraint on platform
ALTER TABLE public.app_downloads ADD CONSTRAINT app_downloads_platform_unique UNIQUE (platform);

-- Enable RLS
ALTER TABLE public.app_downloads ENABLE ROW LEVEL SECURITY;

-- Anyone can read active downloads
CREATE POLICY "Anyone can view active downloads"
ON public.app_downloads
FOR SELECT
USING (is_active = true);

-- Admins can view all
CREATE POLICY "Admins can view all downloads"
ON public.app_downloads
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can manage downloads
CREATE POLICY "Admins can insert downloads"
ON public.app_downloads
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update downloads"
ON public.app_downloads
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete downloads"
ON public.app_downloads
FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Create storage bucket for app downloads
INSERT INTO storage.buckets (id, name, public) VALUES ('app-downloads', 'app-downloads', true);

-- Storage policies
CREATE POLICY "Anyone can download app files"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-downloads');

CREATE POLICY "Admins can upload app files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'app-downloads' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete app files"
ON storage.objects FOR DELETE
USING (bucket_id = 'app-downloads' AND public.has_role(auth.uid(), 'admin'));
