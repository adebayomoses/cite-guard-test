
-- blog_posts: allow moderators with 'blog' section
CREATE POLICY "Mods can view all blog posts"
ON public.blog_posts FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'blog'));

CREATE POLICY "Mods can insert blog posts"
ON public.blog_posts FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'blog'));

CREATE POLICY "Mods can update blog posts"
ON public.blog_posts FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'blog'));

CREATE POLICY "Mods can delete blog posts"
ON public.blog_posts FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'blog'));

-- resources: allow moderators with 'resources' section
CREATE POLICY "Mods can insert resources"
ON public.resources FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'resources'));

CREATE POLICY "Mods can update resources"
ON public.resources FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'resources'));

CREATE POLICY "Mods can delete resources"
ON public.resources FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'resources'));

-- resource_tabs: allow moderators with 'resources' section
CREATE POLICY "Mods can insert resource tabs"
ON public.resource_tabs FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'resources'));

CREATE POLICY "Mods can update resource tabs"
ON public.resource_tabs FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'resources'));

CREATE POLICY "Mods can delete resource tabs"
ON public.resource_tabs FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'resources'));

-- notifications: allow moderators with 'notifications' section
CREATE POLICY "Mods can insert notifications"
ON public.notifications FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'notifications'));

CREATE POLICY "Mods can delete notifications"
ON public.notifications FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'notifications'));

-- support_requests: allow moderators with 'support' section
CREATE POLICY "Mods can view all support requests"
ON public.support_requests FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'support'));

CREATE POLICY "Mods can update support requests"
ON public.support_requests FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'support'));

-- document_submissions: allow moderators with 'docreviews' section
CREATE POLICY "Mods can view all submissions"
ON public.document_submissions FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'docreviews'));

CREATE POLICY "Mods can update submissions"
ON public.document_submissions FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'docreviews'));

-- session_bookings: allow moderators with 'bookings' section
CREATE POLICY "Mods can view all bookings"
ON public.session_bookings FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'bookings'));

CREATE POLICY "Mods can update bookings"
ON public.session_bookings FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'bookings'));

-- chat_rooms: allow moderators with 'chatrooms' section
CREATE POLICY "Mods can insert rooms"
ON public.chat_rooms FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'chatrooms'));

CREATE POLICY "Mods can update rooms"
ON public.chat_rooms FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'chatrooms'));

CREATE POLICY "Mods can delete rooms"
ON public.chat_rooms FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'chatrooms'));

-- loan_providers: allow moderators with 'loans' section
CREATE POLICY "Mods can insert loans"
ON public.loan_providers FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'loans'));

CREATE POLICY "Mods can update loans"
ON public.loan_providers FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'loans'));

CREATE POLICY "Mods can delete loans"
ON public.loan_providers FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'loans'));

CREATE POLICY "Mods can view all loans"
ON public.loan_providers FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'loans'));

-- quick_actions: allow moderators with 'quickactions' section
CREATE POLICY "Mods can insert quick actions"
ON public.quick_actions FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'quickactions'));

CREATE POLICY "Mods can update quick actions"
ON public.quick_actions FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'quickactions'));

CREATE POLICY "Mods can delete quick actions"
ON public.quick_actions FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'quickactions'));

-- app_downloads: allow moderators with 'downloads' section
CREATE POLICY "Mods can insert downloads"
ON public.app_downloads FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'downloads'));

CREATE POLICY "Mods can update downloads"
ON public.app_downloads FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'downloads'));

CREATE POLICY "Mods can delete downloads"
ON public.app_downloads FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'downloads'));

CREATE POLICY "Mods can view all downloads"
ON public.app_downloads FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'downloads'));

-- room_announcements: allow moderators with 'chatrooms' section
CREATE POLICY "Mods can insert announcements"
ON public.room_announcements FOR INSERT TO authenticated
WITH CHECK (has_moderator_section(auth.uid(), 'chatrooms'));

CREATE POLICY "Mods can update announcements"
ON public.room_announcements FOR UPDATE TO authenticated
USING (has_moderator_section(auth.uid(), 'chatrooms'));

CREATE POLICY "Mods can delete announcements"
ON public.room_announcements FOR DELETE TO authenticated
USING (has_moderator_section(auth.uid(), 'chatrooms'));
