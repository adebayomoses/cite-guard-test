CREATE POLICY "Mods with careers can read job application resumes"
ON storage.objects FOR SELECT
USING (bucket_id = 'job-applications' AND public.has_mod_permission(auth.uid(), 'careers'));

CREATE POLICY "Mods with careers can delete job application resumes"
ON storage.objects FOR DELETE
USING (bucket_id = 'job-applications' AND public.has_mod_permission(auth.uid(), 'careers'));