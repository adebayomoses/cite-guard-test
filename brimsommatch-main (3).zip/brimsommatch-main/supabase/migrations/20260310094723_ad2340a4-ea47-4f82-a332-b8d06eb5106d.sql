
-- Create slider_images table
CREATE TABLE public.slider_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url text NOT NULL,
  alt_text text DEFAULT '',
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.slider_images ENABLE ROW LEVEL SECURITY;

-- Anyone can view active images
CREATE POLICY "Anyone can view active slider images"
ON public.slider_images FOR SELECT TO public
USING (is_active = true);

-- Admins can manage slider images
CREATE POLICY "Admins can insert slider images"
ON public.slider_images FOR INSERT TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update slider images"
ON public.slider_images FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete slider images"
ON public.slider_images FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can view all slider images"
ON public.slider_images FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('slider-images', 'slider-images', true);

-- Storage policies
CREATE POLICY "Anyone can view slider images" ON storage.objects FOR SELECT TO public USING (bucket_id = 'slider-images');
CREATE POLICY "Admins can upload slider images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'slider-images' AND has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can delete slider images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'slider-images' AND has_role(auth.uid(), 'admin'::app_role));
