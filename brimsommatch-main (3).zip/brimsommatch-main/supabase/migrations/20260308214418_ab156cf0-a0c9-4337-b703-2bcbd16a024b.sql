
CREATE TABLE public.info_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.info_sources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage info sources" ON public.info_sources
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Moderators can view active info sources" ON public.info_sources
  FOR SELECT TO authenticated
  USING (is_active = true AND public.has_role(auth.uid(), 'moderator'));
