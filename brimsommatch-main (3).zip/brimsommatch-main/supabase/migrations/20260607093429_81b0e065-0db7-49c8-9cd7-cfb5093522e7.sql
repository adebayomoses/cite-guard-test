CREATE OR REPLACE FUNCTION public.get_feature_usage_count(
  _user_id uuid,
  _feature text,
  _period text DEFAULT 'month'
)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::integer
  FROM public.feature_usage
  WHERE user_id = _user_id
    AND feature = _feature
    AND used_at >= (
      CASE
        WHEN _period = 'day' THEN date_trunc('day', now() AT TIME ZONE 'UTC')
        WHEN _period = '2month' THEN (date_trunc('month', now() AT TIME ZONE 'UTC') - INTERVAL '1 month')
        ELSE date_trunc('month', now() AT TIME ZONE 'UTC')
      END
    );
$$;