INSERT INTO public.site_settings (key, value) VALUES
  ('recommended_urgency_days', '60'),
  ('recommended_urgency_boost', '15')
ON CONFLICT (key) DO NOTHING;