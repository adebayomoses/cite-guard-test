
CREATE POLICY "Service role can delete send log"
  ON public.email_send_log FOR DELETE
  USING (auth.role() = 'service_role');

CREATE POLICY "Service role can delete tokens"
  ON public.email_unsubscribe_tokens FOR DELETE
  USING (auth.role() = 'service_role');
