
-- Enum for subscription plans
CREATE TYPE public.subscription_plan AS ENUM ('free', 'standard', 'pro');

-- User subscriptions table
CREATE TABLE public.user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  plan subscription_plan NOT NULL DEFAULT 'free',
  stripe_customer_id text,
  stripe_subscription_id text,
  started_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscription"
  ON public.user_subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage all subscriptions"
  ON public.user_subscriptions FOR ALL
  TO authenticated
  USING (auth.role() = 'service_role'::text)
  WITH CHECK (auth.role() = 'service_role'::text);

-- Feature usage tracking table
CREATE TABLE public.feature_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  feature text NOT NULL,
  used_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.feature_usage ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert own usage"
  ON public.feature_usage FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own usage"
  ON public.feature_usage FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to count feature usage for a period
CREATE OR REPLACE FUNCTION public.get_feature_usage_count(
  _user_id uuid,
  _feature text,
  _period text DEFAULT 'month'
)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*)::integer
  FROM public.feature_usage
  WHERE user_id = _user_id
    AND feature = _feature
    AND used_at >= (
      CASE
        WHEN _period = 'day' THEN date_trunc('day', now() AT TIME ZONE 'UTC')
        ELSE date_trunc('month', now() AT TIME ZONE 'UTC')
      END
    );
$$;

-- Auto-create subscription row for new users
CREATE OR REPLACE FUNCTION public.handle_new_user_subscription()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.user_subscriptions (user_id, plan)
  VALUES (NEW.id, 'free')
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_profile_created_subscription
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_subscription();
