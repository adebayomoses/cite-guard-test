CREATE POLICY "Admins can delete support requests"
  ON public.support_requests FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));