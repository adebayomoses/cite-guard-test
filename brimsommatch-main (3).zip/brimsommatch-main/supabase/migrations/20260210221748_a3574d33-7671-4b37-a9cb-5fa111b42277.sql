
CREATE TABLE public.score_results (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  readiness_score integer NOT NULL DEFAULT 0,
  readiness_summary text,
  tips jsonb DEFAULT '[]'::jsonb,
  scholarship_matches jsonb DEFAULT '[]'::jsonb,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.score_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own scores"
  ON public.score_results FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own scores"
  ON public.score_results FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own scores"
  ON public.score_results FOR DELETE
  USING (auth.uid() = user_id);

CREATE INDEX idx_score_results_user_id ON public.score_results (user_id);
