
-- 1. Add created_at to user_roles (needed to pick the "first admin" deterministically)
ALTER TABLE public.user_roles
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

-- 2. Add auto_publish_enabled flag to scholarships
ALTER TABLE public.scholarships
  ADD COLUMN IF NOT EXISTS auto_publish_enabled boolean NOT NULL DEFAULT false;

-- 3. is_main_admin() — earliest-assigned admin in user_roles
CREATE OR REPLACE FUNCTION public.is_main_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE role = 'admin'::app_role
      AND user_id = _user_id
    ORDER BY created_at ASC, id ASC
    LIMIT 1
  );
$$;

GRANT EXECUTE ON FUNCTION public.is_main_admin(uuid) TO authenticated;

-- 4. Trigger: only main admin may change auto_publish_enabled
CREATE OR REPLACE FUNCTION public.guard_scholarship_auto_publish()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.auto_publish_enabled IS TRUE AND NOT public.is_main_admin(auth.uid()) THEN
      NEW.auto_publish_enabled := false;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.auto_publish_enabled IS DISTINCT FROM OLD.auto_publish_enabled
       AND NOT public.is_main_admin(auth.uid()) THEN
      NEW.auto_publish_enabled := OLD.auto_publish_enabled;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_auto_publish ON public.scholarships;
CREATE TRIGGER trg_guard_auto_publish
BEFORE INSERT OR UPDATE ON public.scholarships
FOR EACH ROW EXECUTE FUNCTION public.guard_scholarship_auto_publish();

-- 5. RPC: run the auto-publish sweep (used by cron + manual invoke)
CREATE OR REPLACE FUNCTION public.run_auto_publish_sweep()
RETURNS TABLE(scholarship_id uuid, title text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  rec record;
BEGIN
  FOR rec IN
    SELECT s.id, s.title
    FROM public.scholarships s
    WHERE s.auto_publish_enabled = true
      AND s.is_active = false
      AND EXISTS (
        SELECT 1 FROM public.scholarship_intakes i
        WHERE i.scholarship_id = s.id
          AND i.open_date IS NOT NULL
          AND extract(month from i.open_date) = extract(month from current_date)
          AND extract(day   from i.open_date) = extract(day   from current_date)
      )
  LOOP
    UPDATE public.scholarship_intakes
       SET open_date  = open_date  + interval '1 year',
           close_date = CASE WHEN close_date IS NOT NULL THEN close_date + interval '1 year' ELSE NULL END
     WHERE scholarship_id = rec.id;

    UPDATE public.scholarships
       SET is_active = true,
           status = 'approved'
     WHERE id = rec.id;

    INSERT INTO public.activity_log (user_id, action, metadata)
    VALUES (NULL, 'auto_publish_scholarship',
            jsonb_build_object('scholarship_id', rec.id, 'title', rec.title, 'date', current_date));

    scholarship_id := rec.id;
    title := rec.title;
    RETURN NEXT;
  END LOOP;
END;
$$;

GRANT EXECUTE ON FUNCTION public.run_auto_publish_sweep() TO service_role;
