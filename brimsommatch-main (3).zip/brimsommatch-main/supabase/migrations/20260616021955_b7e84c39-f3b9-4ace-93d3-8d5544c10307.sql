
REVOKE SELECT (email) ON public.testimonials FROM anon;
REVOKE SELECT (email) ON public.testimonials FROM authenticated;
