CREATE TABLE public.essay_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  motivation TEXT,
  project_or_achievement TEXT,
  tools_software TEXT,
  research_interests TEXT,
  career_goals TEXT,
  why_study_abroad TEXT,
  academic_explanations TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.essay_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own essay profile" ON public.essay_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own essay profile" ON public.essay_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own essay profile" ON public.essay_profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own essay profile" ON public.essay_profiles FOR DELETE USING (auth.uid() = user_id);

CREATE TRIGGER update_essay_profiles_updated_at
BEFORE UPDATE ON public.essay_profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();