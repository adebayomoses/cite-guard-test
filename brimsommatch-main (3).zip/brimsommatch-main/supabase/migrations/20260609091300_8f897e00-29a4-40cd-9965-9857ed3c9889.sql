CREATE POLICY "Mods can review assigned own scholarships"
ON public.scholarships
FOR UPDATE
USING (
  has_moderator_section(auth.uid(), 'scholarships'::text)
  AND assigned_reviewer_id = auth.uid()
)
WITH CHECK (
  has_moderator_section(auth.uid(), 'scholarships'::text)
  AND assigned_reviewer_id = auth.uid()
);