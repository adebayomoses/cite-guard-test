
-- Add academic level to profiles
ALTER TABLE public.profiles ADD COLUMN academic_level text;

-- High school subjects table
CREATE TABLE public.high_school_subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  subject_name text NOT NULL,
  grade text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.high_school_subjects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subjects" ON public.high_school_subjects
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own subjects" ON public.high_school_subjects
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own subjects" ON public.high_school_subjects
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own subjects" ON public.high_school_subjects
  FOR DELETE USING (auth.uid() = user_id);
