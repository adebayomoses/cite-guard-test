
CREATE OR REPLACE FUNCTION public.notify_on_chat_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  preview text;
  room_name text;
BEGIN
  preview := COALESCE(NULLIF(trim(NEW.content), ''), CASE WHEN NEW.image_url IS NOT NULL THEN '📷 Photo' ELSE 'New message' END);
  IF length(preview) > 140 THEN
    preview := left(preview, 140);
  END IF;

  SELECT name INTO room_name FROM public.chat_rooms WHERE id = NEW.room_id;

  -- Broadcast notification (user_id NULL) so every user sees it via the notifications feed.
  -- The sender's own row is filtered out on the client using the sender id encoded in the URL.
  INSERT INTO public.notifications (user_id, title, body, url)
  VALUES (
    NULL,
    COALESCE(NULLIF(room_name, ''), 'Community chat'),
    left(COALESCE(NULLIF(NEW.user_name, ''), 'Someone') || ': ' || preview, 180),
    '/community?room=' || NEW.room_id::text || '&from=' || NEW.user_id::text
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_on_chat_message ON public.chat_messages;
CREATE TRIGGER trg_notify_on_chat_message
AFTER INSERT ON public.chat_messages
FOR EACH ROW
EXECUTE FUNCTION public.notify_on_chat_message();
