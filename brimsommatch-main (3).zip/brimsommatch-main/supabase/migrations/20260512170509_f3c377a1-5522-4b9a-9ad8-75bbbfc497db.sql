-- Enable pg_trgm for fuzzy text matching (trigram similarity)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- GIN index on title for fast similarity search
CREATE INDEX IF NOT EXISTS idx_scholarships_title_trgm
  ON public.scholarships USING gin (title gin_trgm_ops);

-- RPC: find scholarships whose title is similar to the given one
-- Used by the admin form to warn moderators about likely duplicates BEFORE submit.
CREATE OR REPLACE FUNCTION public.find_similar_scholarships(
  query_title text,
  query_provider text DEFAULT NULL,
  query_country text DEFAULT NULL,
  exclude_id uuid DEFAULT NULL,
  similarity_threshold real DEFAULT 0.45,
  max_results integer DEFAULT 5
)
RETURNS TABLE (
  id uuid,
  title text,
  provider text,
  country text,
  status text,
  is_active boolean,
  created_at timestamptz,
  similarity_score real,
  provider_match boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    s.id,
    s.title,
    s.provider,
    s.country,
    s.status,
    s.is_active,
    s.created_at,
    similarity(lower(s.title), lower(query_title)) AS similarity_score,
    (
      query_provider IS NOT NULL
      AND s.provider IS NOT NULL
      AND similarity(lower(s.provider), lower(query_provider)) > 0.5
    ) AS provider_match
  FROM public.scholarships s
  WHERE
    (exclude_id IS NULL OR s.id <> exclude_id)
    AND query_title IS NOT NULL
    AND length(trim(query_title)) >= 4
    AND similarity(lower(s.title), lower(query_title)) >= similarity_threshold
  ORDER BY similarity_score DESC, s.created_at DESC
  LIMIT max_results;
$$;

-- RPC: find clusters of likely-duplicate scholarships in the database.
-- Returns one row per pair (a,b) where a.id < b.id to avoid mirror duplicates.
-- Admin UI groups them into clusters client-side.
CREATE OR REPLACE FUNCTION public.find_duplicate_scholarship_clusters(
  similarity_threshold real DEFAULT 0.6,
  max_pairs integer DEFAULT 200
)
RETURNS TABLE (
  a_id uuid,
  a_title text,
  a_provider text,
  a_country text,
  a_status text,
  a_is_active boolean,
  a_created_at timestamptz,
  b_id uuid,
  b_title text,
  b_provider text,
  b_country text,
  b_status text,
  b_is_active boolean,
  b_created_at timestamptz,
  similarity_score real
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    a.id, a.title, a.provider, a.country, a.status, a.is_active, a.created_at,
    b.id, b.title, b.provider, b.country, b.status, b.is_active, b.created_at,
    similarity(lower(a.title), lower(b.title)) AS similarity_score
  FROM public.scholarships a
  JOIN public.scholarships b
    ON a.id < b.id
   AND similarity(lower(a.title), lower(b.title)) >= similarity_threshold
  ORDER BY similarity_score DESC
  LIMIT max_pairs;
$$;

-- Grant execute to authenticated users; the functions only read scholarships
-- which are already publicly readable, so no privilege escalation here.
GRANT EXECUTE ON FUNCTION public.find_similar_scholarships(text, text, text, uuid, real, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.find_duplicate_scholarship_clusters(real, integer) TO authenticated;