
CREATE OR REPLACE FUNCTION public.notify_on_direct_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  preview text;
BEGIN
  IF NEW.receiver_id IS NULL OR NEW.sender_id = NEW.receiver_id THEN
    RETURN NEW;
  END IF;

  preview := COALESCE(NULLIF(trim(NEW.content), ''), CASE WHEN NEW.image_url IS NOT NULL THEN '📷 Photo' ELSE 'Sent you a message' END);
  IF length(preview) > 140 THEN
    preview := left(preview, 140);
  END IF;

  INSERT INTO public.notifications (user_id, title, body, url)
  VALUES (
    NEW.receiver_id,
    COALESCE(NULLIF(NEW.sender_name, ''), 'New message'),
    preview,
    '/community?dm=' || NEW.sender_id::text
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_notify_on_direct_message ON public.direct_messages;
CREATE TRIGGER trg_notify_on_direct_message
AFTER INSERT ON public.direct_messages
FOR EACH ROW
EXECUTE FUNCTION public.notify_on_direct_message();
