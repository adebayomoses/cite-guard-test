CREATE OR REPLACE FUNCTION public.admin_feature_usage_monthly(_feature text)
RETURNS TABLE(user_id uuid, usage_count bigint)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT user_id, count(*)::bigint AS usage_count
  FROM public.feature_usage
  WHERE feature = _feature
    AND used_at >= date_trunc('month', now() AT TIME ZONE 'UTC')
    AND public.has_role(auth.uid(), 'admin'::app_role)
  GROUP BY user_id;
$$;