
-- Create resource_tabs table
CREATE TABLE public.resource_tabs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.resource_tabs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view resource tabs"
  ON public.resource_tabs FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can insert resource tabs"
  ON public.resource_tabs FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update resource tabs"
  ON public.resource_tabs FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete resource tabs"
  ON public.resource_tabs FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Create resources table
CREATE TABLE public.resources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tab_id uuid NOT NULL REFERENCES public.resource_tabs(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  youtube_url text,
  link_url text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view resources"
  ON public.resources FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can insert resources"
  ON public.resources FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update resources"
  ON public.resources FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete resources"
  ON public.resources FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Insert default General tab
INSERT INTO public.resource_tabs (name, sort_order, is_default) VALUES ('General', 0, true);
