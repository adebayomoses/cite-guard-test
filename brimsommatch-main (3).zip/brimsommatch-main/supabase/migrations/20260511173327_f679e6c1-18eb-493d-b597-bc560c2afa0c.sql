
-- Job applications table
CREATE TABLE public.job_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  position TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  experience TEXT NOT NULL,
  resume_path TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;

-- Anyone (incl anonymous) can submit
CREATE POLICY "Anyone can submit job applications"
  ON public.job_applications FOR INSERT
  WITH CHECK (true);

-- Only admins can view/update/delete
CREATE POLICY "Admins can view job applications"
  ON public.job_applications FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update job applications"
  ON public.job_applications FOR UPDATE
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete job applications"
  ON public.job_applications FOR DELETE
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_job_applications_updated_at
  BEFORE UPDATE ON public.job_applications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for resumes (private)
INSERT INTO storage.buckets (id, name, public)
  VALUES ('job-applications', 'job-applications', false)
  ON CONFLICT (id) DO NOTHING;

-- Anyone can upload a resume to this bucket
CREATE POLICY "Anyone can upload resumes"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'job-applications');

-- Only admins can read resumes
CREATE POLICY "Admins can read job application resumes"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'job-applications' AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete job application resumes"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'job-applications' AND public.has_role(auth.uid(), 'admin'::app_role));
