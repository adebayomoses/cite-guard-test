
-- 1. Remove push_subscriptions from realtime publication
ALTER PUBLICATION supabase_realtime DROP TABLE public.push_subscriptions;

-- 2. Lock down shared_advisor_messages: revoke public SELECT, expose via security-definer RPC by token
DROP POLICY IF EXISTS "Anyone can view shared advisor messages" ON public.shared_advisor_messages;

CREATE OR REPLACE FUNCTION public.get_shared_advisor_message(_token text)
RETURNS TABLE(content text, created_at timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT content, created_at
  FROM public.shared_advisor_messages
  WHERE token = _token
  LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION public.get_shared_advisor_message(text) TO anon, authenticated;
