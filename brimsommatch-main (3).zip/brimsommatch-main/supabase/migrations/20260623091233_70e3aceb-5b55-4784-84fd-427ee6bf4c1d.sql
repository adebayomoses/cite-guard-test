-- 1. Add the maintained column
ALTER TABLE public.scholarships ADD COLUMN IF NOT EXISTS next_close_date date;

-- 2. Refresh function
CREATE OR REPLACE FUNCTION public.refresh_scholarship_next_close_date(_scholarship_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE public.scholarships
  SET next_close_date = (
    SELECT min(close_date)
    FROM public.scholarship_intakes
    WHERE scholarship_id = _scholarship_id
      AND close_date IS NOT NULL
      AND close_date >= current_date
  )
  WHERE id = _scholarship_id;
$$;

-- 3. Trigger function on scholarship_intakes
CREATE OR REPLACE FUNCTION public.intake_refresh_next_close_date()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.refresh_scholarship_next_close_date(OLD.scholarship_id);
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' AND OLD.scholarship_id <> NEW.scholarship_id THEN
    PERFORM public.refresh_scholarship_next_close_date(OLD.scholarship_id);
    PERFORM public.refresh_scholarship_next_close_date(NEW.scholarship_id);
    RETURN NEW;
  ELSE
    PERFORM public.refresh_scholarship_next_close_date(NEW.scholarship_id);
    RETURN NEW;
  END IF;
END;
$$;

DROP TRIGGER IF EXISTS trg_intake_refresh_next_close_date ON public.scholarship_intakes;
CREATE TRIGGER trg_intake_refresh_next_close_date
AFTER INSERT OR UPDATE OR DELETE ON public.scholarship_intakes
FOR EACH ROW EXECUTE FUNCTION public.intake_refresh_next_close_date();

-- 4. Backfill every scholarship
UPDATE public.scholarships s
SET next_close_date = sub.min_close
FROM (
  SELECT scholarship_id, min(close_date) AS min_close
  FROM public.scholarship_intakes
  WHERE close_date IS NOT NULL AND close_date >= current_date
  GROUP BY scholarship_id
) sub
WHERE s.id = sub.scholarship_id;

-- 5. Drop the legacy column
ALTER TABLE public.scholarships DROP COLUMN IF EXISTS deadline;