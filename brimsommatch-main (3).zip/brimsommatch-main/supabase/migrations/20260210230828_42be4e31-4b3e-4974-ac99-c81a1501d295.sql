CREATE OR REPLACE FUNCTION public.admin_platform_metrics()
RETURNS json
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result json;
BEGIN
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  SELECT json_build_object(
    'total_users', (SELECT count(*) FROM profiles),
    'active_scholarships', (SELECT count(*) FROM scholarships WHERE is_active = true),
    'total_scholarships', (SELECT count(*) FROM scholarships),
    'total_saves', (SELECT count(*) FROM saved_scholarships),
    'scores_generated', (SELECT count(*) FROM score_results),
    'community_messages', (SELECT count(*) FROM chat_messages)
  ) INTO result;

  RETURN result;
END;
$$;