-- Community moderators table
CREATE TABLE public.community_moderators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE,
  appointed_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.community_moderators ENABLE ROW LEVEL SECURITY;

-- Chat bans table
CREATE TABLE public.chat_bans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  banned_by uuid NOT NULL,
  room_id uuid REFERENCES public.chat_rooms(id) ON DELETE CASCADE,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_bans ENABLE ROW LEVEL SECURITY;

-- Security definer: is_community_moderator
CREATE OR REPLACE FUNCTION public.is_community_moderator(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.community_moderators WHERE user_id = _user_id
  )
$$;

-- Security definer: is_chat_banned
CREATE OR REPLACE FUNCTION public.is_chat_banned(_user_id uuid, _room_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.chat_bans
    WHERE user_id = _user_id
      AND (room_id IS NULL OR room_id = _room_id)
  )
$$;

-- RLS for community_moderators
CREATE POLICY "Anyone authenticated can view community moderators"
  ON public.community_moderators FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Admins can insert community moderators"
  ON public.community_moderators FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete community moderators"
  ON public.community_moderators FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- RLS for chat_bans
CREATE POLICY "Admins and moderators can view all bans"
  ON public.chat_bans FOR SELECT TO authenticated
  USING (
    has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid()) OR user_id = auth.uid()
  );

CREATE POLICY "Admins and moderators can insert bans"
  ON public.chat_bans FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid())
  );

CREATE POLICY "Admins and moderators can delete bans"
  ON public.chat_bans FOR DELETE TO authenticated
  USING (
    has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid())
  );

-- Update chat_messages INSERT policy to block banned users
DROP POLICY IF EXISTS "Users can insert own messages" ON public.chat_messages;
CREATE POLICY "Users can insert own messages"
  ON public.chat_messages FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND NOT is_chat_banned(auth.uid(), room_id)
  );

-- Allow admins/community moderators to delete any messages
DROP POLICY IF EXISTS "Users can delete own messages" ON public.chat_messages;
CREATE POLICY "Users can delete own messages or mod/admin can delete"
  ON public.chat_messages FOR DELETE TO authenticated
  USING (
    auth.uid() = user_id OR has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid())
  );