
-- 1. Create security definer function to check moderator section permissions
CREATE OR REPLACE FUNCTION public.has_moderator_section(_user_id uuid, _section text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.moderator_permissions
    WHERE user_id = _user_id AND section = _section
  )
$$;

-- 2. Drop existing admin-only INSERT/UPDATE/DELETE policies on scholarships
DROP POLICY IF EXISTS "Admins can insert scholarships" ON public.scholarships;
DROP POLICY IF EXISTS "Admins can update scholarships" ON public.scholarships;
DROP POLICY IF EXISTS "Admins can delete scholarships" ON public.scholarships;

-- 3. Recreate policies allowing admin OR moderator with scholarships section
CREATE POLICY "Admins and mods can insert scholarships"
ON public.scholarships FOR INSERT TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
);

CREATE POLICY "Admins and mods can update scholarships"
ON public.scholarships FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
);

CREATE POLICY "Admins and mods can delete scholarships"
ON public.scholarships FOR DELETE TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_moderator_section(auth.uid(), 'scholarships')
);
