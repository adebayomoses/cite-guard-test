ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS intended_program text,
  ADD COLUMN IF NOT EXISTS intended_degree_level text,
  ADD COLUMN IF NOT EXISTS intended_field_of_study text;