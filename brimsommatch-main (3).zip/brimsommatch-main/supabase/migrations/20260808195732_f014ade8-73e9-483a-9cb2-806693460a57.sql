ALTER TABLE public.scholarships ADD COLUMN IF NOT EXISTS republished_at timestamptz;

CREATE OR REPLACE FUNCTION public.run_auto_publish_sweep()
 RETURNS TABLE(scholarship_id uuid, title text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  rec record;
  _new_title text;
  _earliest_open date;
  _start_year int;
  _end_year int;
  _year_range text;
BEGIN
  FOR rec IN
    SELECT s.id, s.title
    FROM public.scholarships s
    WHERE s.auto_publish_enabled = true
      AND s.is_active = false
      AND EXISTS (
        SELECT 1 FROM public.scholarship_intakes i
        WHERE i.scholarship_id = s.id
          AND i.open_date IS NOT NULL
          AND extract(month from i.open_date) = extract(month from current_date)
          AND extract(day   from i.open_date) = extract(day   from current_date)
      )
  LOOP
    UPDATE public.scholarship_intakes
       SET open_date  = open_date  + interval '1 year',
           close_date = CASE WHEN close_date IS NOT NULL THEN close_date + interval '1 year' ELSE NULL END
     WHERE scholarship_id = rec.id;

    SELECT min(open_date) INTO _earliest_open
    FROM public.scholarship_intakes
    WHERE scholarship_id = rec.id AND open_date IS NOT NULL;

    _start_year := extract(year from COALESCE(_earliest_open, current_date))::int;
    _end_year := _start_year + 1;
    _year_range := _start_year::text || '/' || _end_year::text;

    _new_title := rec.title;
    IF _new_title ~ '\d{4}[/\-]\d{4}' THEN
      _new_title := regexp_replace(_new_title, '\d{4}[/\-]\d{4}', _year_range);
    ELSIF _new_title ~ '\d{4}' THEN
      _new_title := regexp_replace(_new_title, '\d{4}', _year_range);
    ELSE
      _new_title := _new_title || ' ' || _year_range;
    END IF;

    UPDATE public.scholarships
       SET is_active = true,
           status = 'approved',
           title = _new_title,
           republished_at = now()
     WHERE id = rec.id;

    INSERT INTO public.activity_log (user_id, action, metadata)
    VALUES (NULL, 'auto_publish_scholarship',
            jsonb_build_object('scholarship_id', rec.id, 'title', _new_title, 'date', current_date));

    scholarship_id := rec.id;
    title := _new_title;
    RETURN NEXT;
  END LOOP;
END;
$function$;