CREATE POLICY "Mods can view all scholarships"
ON public.scholarships FOR SELECT TO authenticated
USING (has_moderator_section(auth.uid(), 'scholarships'));