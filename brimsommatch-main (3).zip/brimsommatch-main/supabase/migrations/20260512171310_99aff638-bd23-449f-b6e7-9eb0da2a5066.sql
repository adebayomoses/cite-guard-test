-- Table to remember pairs that an admin/mod confirmed are NOT duplicates
CREATE TABLE IF NOT EXISTS public.scholarship_duplicate_ignores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  a_id uuid NOT NULL,
  b_id uuid NOT NULL,
  ignored_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT scholarship_dup_ignores_ordered CHECK (a_id < b_id),
  CONSTRAINT scholarship_dup_ignores_unique UNIQUE (a_id, b_id)
);

ALTER TABLE public.scholarship_duplicate_ignores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and scholarship mods can view ignores"
  ON public.scholarship_duplicate_ignores FOR SELECT
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_moderator_section(auth.uid(), 'scholarships'::text));

CREATE POLICY "Admins and scholarship mods can insert ignores"
  ON public.scholarship_duplicate_ignores FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = ignored_by
    AND (has_role(auth.uid(), 'admin'::app_role) OR has_moderator_section(auth.uid(), 'scholarships'::text))
  );

CREATE POLICY "Admins and scholarship mods can delete ignores"
  ON public.scholarship_duplicate_ignores FOR DELETE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_moderator_section(auth.uid(), 'scholarships'::text));

-- Update cluster scanner to skip ignored pairs
CREATE OR REPLACE FUNCTION public.find_duplicate_scholarship_clusters(
  similarity_threshold real DEFAULT 0.6,
  max_pairs integer DEFAULT 200
)
RETURNS TABLE (
  a_id uuid,
  a_title text,
  a_provider text,
  a_country text,
  a_status text,
  a_is_active boolean,
  a_created_at timestamptz,
  b_id uuid,
  b_title text,
  b_provider text,
  b_country text,
  b_status text,
  b_is_active boolean,
  b_created_at timestamptz,
  similarity_score real
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    a.id, a.title, a.provider, a.country, a.status, a.is_active, a.created_at,
    b.id, b.title, b.provider, b.country, b.status, b.is_active, b.created_at,
    similarity(lower(a.title), lower(b.title)) AS similarity_score
  FROM public.scholarships a
  JOIN public.scholarships b
    ON a.id < b.id
   AND similarity(lower(a.title), lower(b.title)) >= similarity_threshold
  WHERE NOT EXISTS (
    SELECT 1 FROM public.scholarship_duplicate_ignores i
    WHERE i.a_id = a.id AND i.b_id = b.id
  )
  ORDER BY similarity_score DESC
  LIMIT max_pairs;
$$;