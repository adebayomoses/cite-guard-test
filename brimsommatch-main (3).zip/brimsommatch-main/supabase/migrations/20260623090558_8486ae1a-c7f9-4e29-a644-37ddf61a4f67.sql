INSERT INTO scholarship_intakes (scholarship_id, term, close_date, sort_order)
SELECT s.id, 'general', s.deadline, 0
FROM scholarships s
WHERE s.deadline IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM scholarship_intakes i WHERE i.scholarship_id = s.id);