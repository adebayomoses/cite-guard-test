ALTER TABLE public.scholarships
  ADD COLUMN IF NOT EXISTS next_open_date date;

CREATE OR REPLACE FUNCTION public.refresh_scholarship_next_dates(_scholarship_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _next_close date;
  _last_close date;
  _next_open date;
  _last_open date;
BEGIN
  SELECT min(close_date)
    INTO _next_close
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND close_date IS NOT NULL
    AND close_date >= current_date;

  SELECT max(close_date)
    INTO _last_close
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND close_date IS NOT NULL
    AND close_date < current_date;

  SELECT min(open_date)
    INTO _next_open
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND open_date IS NOT NULL
    AND open_date >= current_date;

  SELECT max(open_date)
    INTO _last_open
  FROM public.scholarship_intakes
  WHERE scholarship_id = _scholarship_id
    AND open_date IS NOT NULL
    AND open_date < current_date;

  UPDATE public.scholarships
  SET next_close_date = COALESCE(_next_close, _last_close),
      next_open_date = COALESCE(_next_open, _last_open)
  WHERE id = _scholarship_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.refresh_scholarship_next_close_date(_scholarship_id uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.refresh_scholarship_next_dates(_scholarship_id);
$$;

CREATE OR REPLACE FUNCTION public.intake_refresh_next_close_date()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.refresh_scholarship_next_dates(OLD.scholarship_id);
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' AND OLD.scholarship_id <> NEW.scholarship_id THEN
    PERFORM public.refresh_scholarship_next_dates(OLD.scholarship_id);
    PERFORM public.refresh_scholarship_next_dates(NEW.scholarship_id);
    RETURN NEW;
  ELSE
    PERFORM public.refresh_scholarship_next_dates(NEW.scholarship_id);
    RETURN NEW;
  END IF;
END;
$$;

UPDATE public.scholarships s
SET next_close_date = COALESCE(next_dates.next_close, last_dates.last_close),
    next_open_date = COALESCE(next_dates.next_open, last_dates.last_open)
FROM (
  SELECT id FROM public.scholarships
) target
LEFT JOIN LATERAL (
  SELECT min(close_date) AS next_close, min(open_date) AS next_open
  FROM public.scholarship_intakes
  WHERE scholarship_id = target.id
    AND (close_date >= current_date OR open_date >= current_date)
) next_dates ON true
LEFT JOIN LATERAL (
  SELECT max(close_date) AS last_close, max(open_date) AS last_open
  FROM public.scholarship_intakes
  WHERE scholarship_id = target.id
    AND (close_date < current_date OR open_date < current_date)
) last_dates ON true
WHERE s.id = target.id;