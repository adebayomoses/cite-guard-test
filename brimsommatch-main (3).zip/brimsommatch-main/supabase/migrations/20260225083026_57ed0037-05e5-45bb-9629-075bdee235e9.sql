CREATE TABLE public.quick_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  icon_name text NOT NULL,
  route text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.quick_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view quick actions"
  ON public.quick_actions FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can insert quick actions"
  ON public.quick_actions FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update quick actions"
  ON public.quick_actions FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete quick actions"
  ON public.quick_actions FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

INSERT INTO public.quick_actions (label, icon_name, route, sort_order) VALUES
  ('Find Scholarships', 'Search', '/scholarships', 1),
  ('Join Communities', 'Users', '/community', 2),
  ('Work Routes', 'Briefcase', '/scholarships', 3),
  ('Pathways', 'Route', '/pathways', 4),
  ('Documents', 'FileText', '/document_review', 5),
  ('Resources', 'BookOpen', '/resources', 6),
  ('Book Session', 'Calendar', '/book-session', 7),
  ('Secure Loan', 'Landmark', '/loans', 8),
  ('Brim Chat', 'Bot', '/brim-chat', 9);