
-- Fix: scholarship_intakes overly broad authenticated SELECT
DROP POLICY IF EXISTS "Authenticated users can view intakes" ON public.scholarship_intakes;

CREATE POLICY "Staff can view intakes for managed scholarships"
ON public.scholarship_intakes
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::app_role)
  OR public.has_moderator_section(auth.uid(), 'scholarships'::text)
  OR EXISTS (
    SELECT 1 FROM public.scholarships s
    WHERE s.id = scholarship_intakes.scholarship_id
      AND (s.created_by = auth.uid() OR s.assigned_reviewer_id = auth.uid())
  )
);

-- Fix: testimonials email column publicly readable
REVOKE SELECT (email) ON public.testimonials FROM anon, authenticated;
