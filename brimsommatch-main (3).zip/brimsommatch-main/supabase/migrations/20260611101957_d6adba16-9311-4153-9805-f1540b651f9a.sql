
-- 1) Hide testimonials.email from anonymous visitors (admins still see full row via admin SELECT policy).
REVOKE SELECT (email) ON public.testimonials FROM anon;

-- 2) Explicit user INSERT policy for document_submissions
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='document_submissions'
      AND policyname='Users can create their own submissions'
  ) THEN
    CREATE POLICY "Users can create their own submissions"
      ON public.document_submissions
      FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- 3) Explicitly deny UPDATE on job-applications bucket so resumes cannot be overwritten.
DROP POLICY IF EXISTS "Block updates to job application resumes" ON storage.objects;
CREATE POLICY "Block updates to job application resumes"
  ON storage.objects
  FOR UPDATE
  TO public
  USING (bucket_id = 'job-applications' AND false)
  WITH CHECK (false);
