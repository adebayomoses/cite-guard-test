
-- 1. Columns
ALTER TABLE public.scholarships
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS assigned_reviewer_id uuid,
  ADD COLUMN IF NOT EXISTS forwarded_to_admin boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS rejection_reason text,
  ADD COLUMN IF NOT EXISTS approved_by uuid,
  ADD COLUMN IF NOT EXISTS approved_at timestamptz,
  ADD COLUMN IF NOT EXISTS submitted_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE public.scholarships
  DROP CONSTRAINT IF EXISTS scholarships_status_check;
ALTER TABLE public.scholarships
  ADD CONSTRAINT scholarships_status_check CHECK (status IN ('pending','approved','rejected'));

-- 2. Backfill existing rows as approved so public site is unchanged
UPDATE public.scholarships
SET status = 'approved',
    approved_at = COALESCE(approved_at, created_at)
WHERE status IS NULL OR status = 'pending';

CREATE INDEX IF NOT EXISTS idx_scholarships_status ON public.scholarships(status);
CREATE INDEX IF NOT EXISTS idx_scholarships_assigned_reviewer ON public.scholarships(assigned_reviewer_id);

-- 3. Trigger: force moderator submissions to pending; allow admins to publish directly
CREATE OR REPLACE FUNCTION public.enforce_scholarship_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NOT public.has_role(auth.uid(), 'admin'::app_role) THEN
      NEW.status := 'pending';
      NEW.approved_by := NULL;
      NEW.approved_at := NULL;
      NEW.is_active := false;
    END IF;
    NEW.submitted_at := now();
  END IF;

  IF TG_OP = 'UPDATE' THEN
    -- If submitter (non-admin) edits their rejected item, flip it back to pending
    IF auth.uid() = NEW.created_by
       AND NOT public.has_role(auth.uid(), 'admin'::app_role)
       AND OLD.status = 'rejected' THEN
      NEW.status := 'pending';
      NEW.rejection_reason := NULL;
      NEW.is_active := false;
      NEW.submitted_at := now();
    END IF;

    -- Stamp approver when status flips to approved
    IF NEW.status = 'approved' AND OLD.status <> 'approved' THEN
      NEW.approved_by := auth.uid();
      NEW.approved_at := now();
      NEW.is_active := true;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_scholarship_status ON public.scholarships;
CREATE TRIGGER trg_enforce_scholarship_status
BEFORE INSERT OR UPDATE ON public.scholarships
FOR EACH ROW EXECUTE FUNCTION public.enforce_scholarship_status();

-- 4. RLS policies — replace existing public read with approval-aware policies
DO $$
DECLARE pol record;
BEGIN
  FOR pol IN SELECT polname FROM pg_policy
             WHERE polrelid = 'public.scholarships'::regclass LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.scholarships', pol.polname);
  END LOOP;
END $$;

ALTER TABLE public.scholarships ENABLE ROW LEVEL SECURITY;

-- Public + authenticated users see only approved & active
CREATE POLICY "Anyone can view approved active scholarships"
ON public.scholarships FOR SELECT
USING (status = 'approved' AND is_active = true);

-- Submitters can see their own (any status)
CREATE POLICY "Submitters can view own scholarships"
ON public.scholarships FOR SELECT
TO authenticated
USING (auth.uid() = created_by);

-- Admins see everything
CREATE POLICY "Admins can view all scholarships"
ON public.scholarships FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Moderators with scholarships section see everything
CREATE POLICY "Mods can view all scholarships"
ON public.scholarships FOR SELECT
TO authenticated
USING (public.has_moderator_section(auth.uid(), 'scholarships'));

-- INSERT: admins + scholarships-section moderators
CREATE POLICY "Admins can insert scholarships"
ON public.scholarships FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Mods can insert scholarships"
ON public.scholarships FOR INSERT
TO authenticated
WITH CHECK (public.has_moderator_section(auth.uid(), 'scholarships'));

-- UPDATE: admins anything
CREATE POLICY "Admins can update scholarships"
ON public.scholarships FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

-- UPDATE: moderators can review (approve/reject) others' submissions, but not their own,
-- and not items forwarded to admin
CREATE POLICY "Mods can review others scholarships"
ON public.scholarships FOR UPDATE
TO authenticated
USING (
  public.has_moderator_section(auth.uid(), 'scholarships')
  AND created_by <> auth.uid()
  AND forwarded_to_admin = false
)
WITH CHECK (
  public.has_moderator_section(auth.uid(), 'scholarships')
  AND created_by <> auth.uid()
);

-- UPDATE: submitters can edit their own when rejected (to resubmit)
CREATE POLICY "Submitters can edit own rejected scholarships"
ON public.scholarships FOR UPDATE
TO authenticated
USING (auth.uid() = created_by AND status = 'rejected')
WITH CHECK (auth.uid() = created_by);

-- DELETE: admins, or submitters of pending/rejected items
CREATE POLICY "Admins can delete scholarships"
ON public.scholarships FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Submitters can delete own pending scholarships"
ON public.scholarships FOR DELETE
TO authenticated
USING (auth.uid() = created_by AND status IN ('pending','rejected'));
