
CREATE TABLE public.loan_providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  requirements text,
  rates text,
  url text,
  logo_url text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.loan_providers ENABLE ROW LEVEL SECURITY;

-- Authenticated users can view active loans
CREATE POLICY "Authenticated users can view active loans"
ON public.loan_providers FOR SELECT TO authenticated
USING (is_active = true);

-- Admins full CRUD
CREATE POLICY "Admins can view all loans"
ON public.loan_providers FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert loans"
ON public.loan_providers FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update loans"
ON public.loan_providers FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete loans"
ON public.loan_providers FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Auto-update updated_at
CREATE TRIGGER update_loan_providers_updated_at
  BEFORE UPDATE ON public.loan_providers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
