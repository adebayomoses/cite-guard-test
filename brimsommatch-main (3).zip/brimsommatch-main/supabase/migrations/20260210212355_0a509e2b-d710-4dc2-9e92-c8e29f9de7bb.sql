
-- Education History
CREATE TABLE public.education_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  degree_level TEXT NOT NULL,
  institution TEXT NOT NULL,
  field_of_study TEXT,
  gpa NUMERIC(4,2),
  start_date DATE,
  end_date DATE,
  is_current BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.education_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own education" ON public.education_history FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own education" ON public.education_history FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own education" ON public.education_history FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own education" ON public.education_history FOR DELETE USING (auth.uid() = user_id);
CREATE TRIGGER update_education_history_updated_at BEFORE UPDATE ON public.education_history FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Test Scores
CREATE TABLE public.test_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  test_type TEXT NOT NULL,
  score NUMERIC(6,2) NOT NULL,
  max_score NUMERIC(6,2),
  date_taken DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.test_scores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own test scores" ON public.test_scores FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own test scores" ON public.test_scores FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own test scores" ON public.test_scores FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own test scores" ON public.test_scores FOR DELETE USING (auth.uid() = user_id);
CREATE TRIGGER update_test_scores_updated_at BEFORE UPDATE ON public.test_scores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Research Experience
CREATE TABLE public.research_experience (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  organization TEXT,
  description TEXT,
  start_date DATE,
  end_date DATE,
  publications TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.research_experience ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own research" ON public.research_experience FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own research" ON public.research_experience FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own research" ON public.research_experience FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own research" ON public.research_experience FOR DELETE USING (auth.uid() = user_id);
CREATE TRIGGER update_research_experience_updated_at BEFORE UPDATE ON public.research_experience FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Extracurriculars
CREATE TABLE public.extracurriculars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  category TEXT NOT NULL DEFAULT 'other',
  title TEXT NOT NULL,
  organization TEXT,
  description TEXT,
  date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.extracurriculars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own extracurriculars" ON public.extracurriculars FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own extracurriculars" ON public.extracurriculars FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own extracurriculars" ON public.extracurriculars FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own extracurriculars" ON public.extracurriculars FOR DELETE USING (auth.uid() = user_id);
CREATE TRIGGER update_extracurriculars_updated_at BEFORE UPDATE ON public.extracurriculars FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- User Documents
CREATE TABLE public.user_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  document_type TEXT NOT NULL,
  file_url TEXT NOT NULL,
  file_name TEXT NOT NULL,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.user_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own documents" ON public.user_documents FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own documents" ON public.user_documents FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own documents" ON public.user_documents FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own documents" ON public.user_documents FOR DELETE USING (auth.uid() = user_id);

-- SOP Entries
CREATE TABLE public.sop_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sop_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own sop" ON public.sop_entries FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own sop" ON public.sop_entries FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own sop" ON public.sop_entries FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own sop" ON public.sop_entries FOR DELETE USING (auth.uid() = user_id);
CREATE TRIGGER update_sop_entries_updated_at BEFORE UPDATE ON public.sop_entries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for user documents
INSERT INTO storage.buckets (id, name, public) VALUES ('user-documents', 'user-documents', false);

-- Storage RLS: users can upload to their own folder
CREATE POLICY "Users can upload own documents" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'user-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can view own documents" ON storage.objects FOR SELECT USING (bucket_id = 'user-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can delete own documents" ON storage.objects FOR DELETE USING (bucket_id = 'user-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users can update own documents" ON storage.objects FOR UPDATE USING (bucket_id = 'user-documents' AND auth.uid()::text = (storage.foldername(name))[1]);
