CREATE POLICY "Submitters can edit own pending scholarships"
ON public.scholarships
FOR UPDATE
TO authenticated
USING (auth.uid() = created_by AND status = 'pending')
WITH CHECK (auth.uid() = created_by);