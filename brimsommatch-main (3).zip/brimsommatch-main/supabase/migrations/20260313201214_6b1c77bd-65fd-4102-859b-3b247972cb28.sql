
-- Create user_reports table
CREATE TABLE public.user_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL,
  reported_user_id uuid NOT NULL,
  reported_message_id uuid,
  room_id uuid REFERENCES public.chat_rooms(id) ON DELETE SET NULL,
  reason text NOT NULL,
  details text,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  admin_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.user_reports ENABLE ROW LEVEL SECURITY;

-- Users can insert their own reports
CREATE POLICY "Users can submit reports"
  ON public.user_reports FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

-- Users can view their own reports
CREATE POLICY "Users can view own reports"
  ON public.user_reports FOR SELECT TO authenticated
  USING (auth.uid() = reporter_id);

-- Admins and community moderators can view all reports
CREATE POLICY "Staff can view all reports"
  ON public.user_reports FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid()));

-- Admins and community moderators can update reports (review)
CREATE POLICY "Staff can update reports"
  ON public.user_reports FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin') OR is_community_moderator(auth.uid()));

-- Admins can delete reports
CREATE POLICY "Admins can delete reports"
  ON public.user_reports FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));
