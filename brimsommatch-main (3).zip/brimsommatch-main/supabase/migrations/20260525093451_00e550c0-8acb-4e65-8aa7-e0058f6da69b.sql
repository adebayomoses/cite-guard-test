
-- Job applications: allow anon (public job board) but force "public/" prefix to prevent path abuse
DROP POLICY IF EXISTS "Authenticated users can upload job application resumes" ON storage.objects;
CREATE POLICY "Anyone can upload job application resumes under public/"
ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (
  bucket_id = 'job-applications'
  AND (storage.foldername(name))[1] = 'public'
);

-- Testimonial images: allow anon (guest testimonial submissions) but force "public/" prefix
DROP POLICY IF EXISTS "Authenticated users can upload testimonial images" ON storage.objects;
CREATE POLICY "Anyone can upload testimonial images under public/"
ON storage.objects FOR INSERT TO anon, authenticated
WITH CHECK (
  bucket_id = 'testimonial-images'
  AND (storage.foldername(name))[1] = 'public'
);
