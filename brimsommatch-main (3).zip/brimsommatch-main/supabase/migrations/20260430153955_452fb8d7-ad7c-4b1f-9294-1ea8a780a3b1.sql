-- Essay Library table
CREATE TABLE public.winning_essays (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  document_type TEXT NOT NULL DEFAULT 'sop',
  scholarship_name TEXT,
  country TEXT,
  field_of_study TEXT,
  degree_level TEXT,
  year_won INTEGER,
  author_name TEXT,
  is_anonymized BOOLEAN NOT NULL DEFAULT true,
  content TEXT NOT NULL,
  tags TEXT[] NOT NULL DEFAULT '{}',
  notes TEXT,
  file_url TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_winning_essays_doctype ON public.winning_essays(document_type);
CREATE INDEX idx_winning_essays_country ON public.winning_essays(country);
CREATE INDEX idx_winning_essays_field ON public.winning_essays(field_of_study);
CREATE INDEX idx_winning_essays_degree ON public.winning_essays(degree_level);
CREATE INDEX idx_winning_essays_tags ON public.winning_essays USING GIN(tags);

ALTER TABLE public.winning_essays ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view essays"
ON public.winning_essays FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert essays"
ON public.winning_essays FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role) AND auth.uid() = created_by);

CREATE POLICY "Admins can update essays"
ON public.winning_essays FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete essays"
ON public.winning_essays FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_winning_essays_updated_at
BEFORE UPDATE ON public.winning_essays
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Private storage bucket for original files
INSERT INTO storage.buckets (id, name, public)
VALUES ('winning-essays', 'winning-essays', false)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Admins can view essay files"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'winning-essays' AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can upload essay files"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'winning-essays' AND public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete essay files"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'winning-essays' AND public.has_role(auth.uid(), 'admin'::app_role));