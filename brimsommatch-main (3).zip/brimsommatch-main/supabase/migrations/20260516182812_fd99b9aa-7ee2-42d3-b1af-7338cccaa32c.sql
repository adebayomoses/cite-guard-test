-- Track guest chat usage by stable guest_id cookie
CREATE TABLE IF NOT EXISTS public.guest_chat_usage (
  guest_id TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  reset_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.guest_chat_usage ENABLE ROW LEVEL SECURITY;

-- No client access; only service role (edge function) reads/writes.
CREATE POLICY "No client access to guest_chat_usage"
ON public.guest_chat_usage
FOR ALL
USING (false)
WITH CHECK (false);

CREATE INDEX IF NOT EXISTS idx_guest_chat_usage_reset_at ON public.guest_chat_usage(reset_at);