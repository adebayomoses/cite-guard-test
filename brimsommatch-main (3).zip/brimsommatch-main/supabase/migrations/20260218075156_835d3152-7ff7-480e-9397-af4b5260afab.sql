ALTER TABLE public.scholarships
  ADD COLUMN min_cgpa_scale numeric,
  ADD COLUMN min_cgpa_percentage numeric;