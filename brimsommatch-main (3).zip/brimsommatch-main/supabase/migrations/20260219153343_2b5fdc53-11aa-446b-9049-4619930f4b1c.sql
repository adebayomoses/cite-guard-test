ALTER TABLE public.scholarships
  ADD COLUMN application_start_date date,
  ADD COLUMN funding_type text;