CREATE TABLE public.shared_advisor_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token text NOT NULL UNIQUE,
  content text NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX idx_shared_advisor_messages_token ON public.shared_advisor_messages(token);
CREATE INDEX idx_shared_advisor_messages_created_by ON public.shared_advisor_messages(created_by);

ALTER TABLE public.shared_advisor_messages ENABLE ROW LEVEL SECURITY;

-- Anyone with the link (including anonymous) can read
CREATE POLICY "Anyone can view shared advisor messages"
  ON public.shared_advisor_messages
  FOR SELECT
  USING (true);

-- Only signed-in users can create their own shares
CREATE POLICY "Users can create own shared messages"
  ON public.shared_advisor_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- Only owner can delete
CREATE POLICY "Users can delete own shared messages"
  ON public.shared_advisor_messages
  FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by);