
-- Create scholarships table
CREATE TABLE public.scholarships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  provider text,
  country text,
  field_of_study text,
  degree_level text,
  funding_amount text,
  deadline date,
  eligibility_criteria text,
  min_gpa numeric,
  url text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.scholarships ENABLE ROW LEVEL SECURITY;

-- SELECT: all authenticated users can view active scholarships
CREATE POLICY "Authenticated users can view active scholarships"
ON public.scholarships
FOR SELECT
TO authenticated
USING (is_active = true);

-- Admins can view ALL scholarships (including inactive)
CREATE POLICY "Admins can view all scholarships"
ON public.scholarships
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- INSERT: admin only
CREATE POLICY "Admins can insert scholarships"
ON public.scholarships
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- UPDATE: admin only
CREATE POLICY "Admins can update scholarships"
ON public.scholarships
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- DELETE: admin only
CREATE POLICY "Admins can delete scholarships"
ON public.scholarships
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Trigger for updated_at
CREATE TRIGGER update_scholarships_updated_at
BEFORE UPDATE ON public.scholarships
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
