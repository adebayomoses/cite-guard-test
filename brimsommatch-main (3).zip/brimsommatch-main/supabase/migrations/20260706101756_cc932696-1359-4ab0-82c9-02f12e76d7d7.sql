
CREATE TABLE public.funding_category_apply_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL UNIQUE,
  steps text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.funding_category_apply_steps TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.funding_category_apply_steps TO authenticated;
GRANT ALL ON public.funding_category_apply_steps TO service_role;

ALTER TABLE public.funding_category_apply_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read category apply steps"
  ON public.funding_category_apply_steps
  FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert category apply steps"
  ON public.funding_category_apply_steps
  FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update category apply steps"
  ON public.funding_category_apply_steps
  FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete category apply steps"
  ON public.funding_category_apply_steps
  FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_funding_category_apply_steps_updated_at
  BEFORE UPDATE ON public.funding_category_apply_steps
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.funding_category_apply_steps (category, steps) VALUES
  ('Government Scholarships', ''),
  ('University Scholarships', ''),
  ('Assistantships', ''),
  ('Fellowships', ''),
  ('External/Private Scholarships', '')
ON CONFLICT (category) DO NOTHING;
