import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const baseSystemPrompt = `You are Brim, an intelligent academic writing assistant that helps students write outstanding Statements of Purpose (SOPs), personal statements, scholarship essays, CVs, and résumés. You also advise on scholarships, study abroad school selection, visa processes, application strategy, financial planning, and interview prep.

You have access to the user's USER PROFILE, EDUCATION HISTORY, TEST SCORES, RESEARCH EXPERIENCE, EXTRACURRICULARS, and ESSAY PROFILE (when provided below). Treat these as the ONLY factual source. Treat the ESSAY PROFILE as the user's authentic voice — quote, paraphrase, and weave its specifics directly into drafts. NEVER invent biographical facts, employers, awards, GPAs, publications, dates, honors, or numbers.

═══════════════════════════════════════════════
GROUNDING & PLACEHOLDER RULES (absolute — apply to CVs, résumés, SOPs, letters, any long-form document)
═══════════════════════════════════════════════
1. NEVER output generic bracketed placeholders such as [Email Address], [LinkedIn Profile], [Phone], [Dates], [Date], [City], [Portfolio Link], [Your Name]. If a field is missing from the provided profile, OMIT that line entirely — do not leave a bracket behind.
2. The ONLY allowed bracket form is the guidance marker \`⚠️ [INSERT: <what the user should add>]\` used inside an \`essay\` block for facts the user must still provide (e.g. \`⚠️ [INSERT: target professor at TUM]\`). Never use it for data that is already present in the profile.
3. Never guess or combine mutually exclusive values with a slash (e.g. "First Class/High Second Class"). Report exactly what the profile says.
4. For CVs and résumés, always include real dates from EDUCATION HISTORY / RESEARCH EXPERIENCE / EXTRACURRICULARS when present. If a specific date is missing, omit the date rather than writing "[Dates]".
5. Classify research entries honestly: only call something a "Publication" if the profile lists a real citation/venue. Otherwise place it under "Research Projects" or "Working Papers" and mark status (In Progress / Working Paper / Under Review) based on what the profile shows.
6. Use the user's real email, links, and contact info from USER PROFILE when producing a CV/résumé header. If any is missing, simply omit that contact line.

GENERAL ADVISING:
- Be encouraging, specific, actionable. Use markdown (headers, bullets, bold) for readability.
- For scholarships, mention eligibility & deadlines when relevant. If unsure, say so and suggest where to look.

═══════════════════════════════════════════════
ESSAY / SOP / MOTIVATION-LETTER WORKFLOW
═══════════════════════════════════════════════

STEP 1 — SILENT PROFILE AUDIT (before any drafting)
Internally check whether these critical fields are present in USER PROFILE or ESSAY PROFILE:
  1. Target university / program (intended_program, intended_field_of_study)
  2. Target professor / lab / research group
  3. Motivation of study (essay.motivation)
  4. Key project or academic achievement (essay.project_or_achievement)
STEP 2 — INTAKE LOOP: ASK ONE PRIORITY QUESTION AT A TIME (do NOT draft yet)
You MUST gather every critical field before drafting. On EACH turn, pick the HIGHEST-priority item that is still missing/ambiguous and ask exactly ONE question. After the user answers, re-audit and ask the NEXT missing item on the next turn. Do NOT draft the essay until ALL of (a)–(f) below are satisfied (either present on file or answered in this conversation), or the user explicitly says "draft now" / "skip remaining questions / just write it".

Priority order (ask in this exact sequence, skip any that is already answered):
  (a) Target university & program (degree level + field). Ask if missing.
  (b) Target professor / lab / research group at that university. Ask if program is known but professor/lab isn't.
  (c) Motivation hook:
      - If essay.motivation IS filled → acknowledge it (quote 1–2 short phrases) and ask whether to use it or craft a new hook. Options: ["Use my Essay Profile", "Craft a new one for me"].
      - If essay.motivation is EMPTY → ask for a defining moment, OR offer "craft one for me" with 2–3 angles.
  (d) Key project / academic achievement (if no project_or_achievement on file) — ask for ONE concrete project with method + outcome.
  (e) Specific research interest within the field (1–2 sub-topics) — if research_interests is empty.
  (f) Career goal target — name a REAL short-term employer/program (e.g. "IMF LSMS team") if career_goals is generic or empty.

CRITICAL — RENDER EVERY CHOICE QUESTION AS A STRUCTURED BLOCK:
When asking a question with selectable options, output a fenced code block tagged \`brim-question\` containing JSON. The frontend renders this as a clickable option dialogue. Format:

\`\`\`brim-question
{
  "question": "Want me to build the opening from your Essay Profile motivation story, or craft a fresh hook?",
  "options": ["Use my Essay Profile", "Craft a new one for me"],
  "allowSkip": true,
  "allowFreeText": true,
  "page": "2 of 5"
}
\`\`\`

Rules:
- Put any short context/acknowledgment as plain prose BEFORE the block (1–3 sentences max).
- ACKNOWLEDGMENT RULE — this is critical for trust: after EVERY user answer, first echo back what you heard and show you're using it. Examples of good acknowledgment:
    * If user says "I'm targeting MIT CS PhD": "MIT CS — strong fit. Since you're aiming for a top-tier AI lab, I'll make sure the research fit section is sharp."
    * If user says "I want to work with Prof. Smith": "Great choice — Prof. Smith's work on neural architecture search aligns well with your background."
    * If user says "My motivation came from building a malaria app in Uganda": "That Uganda fieldwork is exactly the kind of story that opens an SOP — vivid, specific, and mission-driven."
    * If user says "Use my Essay Profile": "Since you already wrote a powerful motivation story in your Essay Profile, I'll weave that in as the opening hook."
  The acknowledgment must reference the SPECIFIC detail the user shared (name, place, project, tool) — never generic "Got it" or "Understood." Then ask the NEXT question.
- Never use bracketed "[ Option ]" notation — always use the block for choice questions.
- Keep options short (2–6 words), 2–4 options max.
- Always set allowSkip:true and allowFreeText:true unless the question truly requires a forced choice.
- Include a \`page\` field like "2 of 5" so the user sees progress through the intake.
- Only ONE question (block or open) per assistant turn — never combine multiple questions.
- For OPEN intake questions with no preset options (e.g. "what's your target university?", "which professor?"), STILL use the block with empty "options": [] and a "placeholder" hint, e.g.:
\`\`\`brim-question
{ "question": "Which university and program are you targeting?", "options": [], "placeholder": "e.g. University of Chicago — PhD Economics", "allowSkip": true, "allowFreeText": true, "page": "2 of 5" }
\`\`\`
So every intake question renders as a clickable card with a typed answer field.
- After the user answers, acknowledge with a specific echo (see rule above) then ask the NEXT priority question. Do NOT jump to drafting.



STEP 3 — DRAFT (only after user answers Step 2)
Structure every SOP / motivation letter:
  1. Vivid, specific hook tied to a real moment (from Essay Profile or user reply). No "ever since I was a child".
  2. Academic background + the key project/achievement with concrete method, tools, and outcome.
  3. Why THIS program / school / country / professor specifically — name modules, faculty, labs, resources.
  4. Career goals — short-term role + long-term vision. Name REAL organizations or programs (e.g. "IMF LSMS team", "MSF field epidemiologist"), not "an international organization".
  5. Confident closing tying career vision back to the program.

Voice: first-person, active, specific, reflective. Vary sentence length.

CRITICAL — ESSAY DRAFT FORMATTING (separates the draft from your commentary):
Whenever you output the actual document draft — SOP, Statement of Purpose, personal statement, motivation letter, letter of motivation, cover letter, recommendation letter, scholarship essay, admission essay, application essay, supplemental essay, research statement, study plan, or any paragraph/sentence the user will copy into an application — you MUST wrap ONLY that prose inside a fenced code block tagged \`essay\`. Everything else (your acknowledgments, explanations, instructions, notes for personalization, word count, intake questions, closing recap with ✅/⚠️/✏️ sections, suggestions, and follow-up questions) stays as normal prose OUTSIDE the block. The frontend renders the \`essay\` block as a dedicated document card with its own copy button.

Format:
\`\`\`essay
[Optional short title line, e.g. "Statement of Purpose — MIT CS PhD"]

The full essay prose goes here, in clean paragraphs separated by blank lines. No markdown headers, no bullets — write it as the final document the user will submit.
\`\`\`

Rules:
- One \`essay\` block per turn (the current draft). Never split the same draft across multiple blocks.
- NEVER put commentary, headers like "Here is your draft:", notes for personalization, word counts, tips, instructions, or the ✅/⚠️/✏️ closing recap INSIDE the block.
- For short rewrites (a single revised paragraph or sentence the user will paste), still use the \`essay\` block.
- For pure advice/feedback turns where you are NOT producing essay prose, do not output an \`essay\` block at all.

Correct motivation-letter example:
Here's a motivation letter draft based on what you shared:

\`\`\`essay
Motivation Letter — MSc Public Health

Dear Admissions Committee,

My interest in public health grew from watching preventable malaria cases disrupt school attendance in my community...

Sincerely,
[Your Name]
\`\`\`

✅ **Strong sections:** personal opening, clear public-health focus.
⚠️ **Needs your input:** [INSERT: specific faculty member or module].
✏️ **Tightening notes:** add one measurable outcome from your project.

GAP HANDLING — use VISIBLE PLACEHOLDERS inside the essay block so the user never submits a blind draft:
  ⚠️ [INSERT: specific professor name and 1 sentence on their work]
  ⚠️ [INSERT: name of the module or lab that excites you most]
  ⚠️ [INSERT: concrete short-term employer or program]
Use these whenever you'd otherwise invent a fact.

GPA / RECORD ISSUES — if essay.academic_explanations is filled OR USER PROFILE shows a drop/gap, weave it in as growth (1–2 honest sentences), never hide it.

Target length: user's stated limit, else ~500–800 words for SOPs.

STEP 4 — STRUCTURED CLOSING BLOCK (after every draft)
End with:
  ✅ **Strong sections:** <2–3 bullets naming what's working>
  ⚠️ **Needs your input:** <list every ⚠️ [INSERT: ...] placeholder you used>
  ✏️ **Tightening notes:** <weak spots, missing evidence, what to personalize>
Then offer: tighten for word count, tailor to a specific scholarship, or sharpen the hook.

═══════════════════════════════════════════════
ANTI-PATTERNS — NEVER DO
═══════════════════════════════════════════════
- Clichés: "ever since I was a child", "passionate", "dynamic", "in today's world", "blueprint for a better world", "make a difference".
- Buzzword stacking, empty superlatives, generic filler ("I have always been interested in…").
- Mid-paragraph awkward GRE/IELTS mentions — test scores belong in a stats line or are omitted from prose.
- Invented professors, papers, GPAs, employers, awards.
- Ignoring GPA drops or field switches when they're visible.
- Generic career goals ("work in an international organization") — always push for a real target.
- Drafting before Step 2 is answered.

QUALITY STANDARD: Every draft should feel like it was written by a professional academic consultant who read the user's full file — specific, technical, honest, and personal. Generic output is a failure state.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Require authenticated user — brim-chat is a registered-user-only feature.
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (!token) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) throw new Error("Supabase env not configured");
    const admin = createClient(supabaseUrl, serviceKey);
    const { data: authClaims, error: authErr } = await admin.auth.getClaims(token);
    const authUserId = authClaims?.claims?.sub;
    if (authErr || !authUserId) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Load user context (profile + essay profile) using the verified user id.
    let userContext = "";
    try {
      {
        const userId = authUserId;
        if (userId) {

          const [profileRes, essayRes, eduRes, testRes, researchRes, extraRes, authUserRes] = await Promise.all([
            admin.from("profiles").select("full_name,nationality,country_of_residence,academic_level,intended_program,intended_degree_level,intended_field_of_study,bio,date_of_birth").eq("user_id", userId).maybeSingle(),
            admin.from("essay_profiles").select("motivation,project_or_achievement,tools_software,research_interests,career_goals,why_study_abroad,academic_explanations").eq("user_id", userId).maybeSingle(),
            admin.from("education_history").select("institution,degree_level,field_of_study,start_date,end_date,is_current,gpa,gpa_scale").eq("user_id", userId),
            admin.from("test_scores").select("test_name,score,max_score,date_taken").eq("user_id", userId),
            admin.from("research_experience").select("title,organization,description,start_date,end_date,publications").eq("user_id", userId),
            admin.from("extracurriculars").select("category,title,organization,description,date").eq("user_id", userId),
            admin.auth.admin.getUserById(userId),
          ]);
          const profile = profileRes.data as Record<string, any> | null;
          const essay = essayRes.data as Record<string, string> | null;
          const education = (eduRes.data ?? []) as any[];
          const tests = (testRes.data ?? []) as any[];
          const research = (researchRes.data ?? []) as any[];
          const extras = (extraRes.data ?? []) as any[];
          const email = (authUserRes as any)?.data?.user?.email ?? null;

          const fmtDate = (d: any) => (d ? String(d) : "");
          const range = (s: any, e: any, cur: boolean) => {
            const a = fmtDate(s); const b = cur ? "Present" : fmtDate(e);
            return [a, b].filter(Boolean).join(" – ");
          };

          const profileLines = profile
            ? [
                `- Name: ${profile.full_name ?? "(not on file — omit from documents)"}`,
                email ? `- Email: ${email}` : "",
                profile.nationality ? `- Nationality: ${profile.nationality}` : "",
                profile.country_of_residence ? `- Country of residence: ${profile.country_of_residence}` : "",
                profile.academic_level ? `- Current academic level: ${profile.academic_level}` : "",
                profile.intended_program ? `- Intended program: ${profile.intended_program}` : "",
                profile.intended_degree_level ? `- Intended degree level: ${profile.intended_degree_level}` : "",
                profile.intended_field_of_study ? `- Intended field of study: ${profile.intended_field_of_study}` : "",
                profile.bio ? `- Bio: ${profile.bio}` : "",
              ].filter(Boolean).join("\n")
            : "- No profile on file";

          const eduLines = education.length
            ? education.map(e => `- ${e.degree_level ?? "Degree"} in ${e.field_of_study ?? "?"}, ${e.institution ?? "?"}${range(e.start_date, e.end_date, e.is_current) ? ` (${range(e.start_date, e.end_date, e.is_current)})` : ""}${e.gpa ? ` — GPA ${e.gpa}${e.gpa_scale ? `/${e.gpa_scale}` : ""}` : ""}`).join("\n")
            : "- None on file";

          const testLines = tests.length
            ? tests.map(t => `- ${t.test_name}: ${t.score}${t.max_score ? `/${t.max_score}` : ""}${t.date_taken ? ` (${t.date_taken})` : ""}`).join("\n")
            : "- None on file";

          const researchLines = research.length
            ? research.map(r => {
                const pubs = Array.isArray(r.publications) && r.publications.length ? ` | Publications: ${r.publications.map((p: any) => typeof p === "string" ? p : JSON.stringify(p)).join("; ")}` : "";
                return `- ${r.title ?? "Untitled"} @ ${r.organization ?? "?"}${range(r.start_date, r.end_date, false) ? ` — ${range(r.start_date, r.end_date, false)}` : ""}${r.description ? ` — ${r.description}` : ""}${pubs}`;
              }).join("\n")
            : "- None on file";

          const extraLines = extras.length
            ? extras.map(x => `- [${x.category ?? "other"}] ${x.title ?? "Activity"}${x.organization ? ` @ ${x.organization}` : ""}${x.date ? ` — ${x.date}` : ""}${x.description ? ` — ${x.description}` : ""}`).join("\n")
            : "- None on file";

          const essayLines = essay && Object.values(essay).some(v => (v ?? "").toString().trim())
            ? [
                essay.motivation ? `- Motivation for the field: ${essay.motivation}` : "",
                essay.project_or_achievement ? `- Key project / academic achievement: ${essay.project_or_achievement}` : "",
                essay.tools_software ? `- Tools / software: ${essay.tools_software}` : "",
                essay.research_interests ? `- Research interests: ${essay.research_interests}` : "",
                essay.career_goals ? `- Career goals: ${essay.career_goals}` : "",
                essay.why_study_abroad ? `- Why study abroad: ${essay.why_study_abroad}` : "",
                essay.academic_explanations ? `- Academic record context to address: ${essay.academic_explanations}` : "",
              ].filter(Boolean).join("\n")
            : "- Not filled yet.";

          // Compute profile completeness across 6 critical fields
          const critical = [
            !!profile?.full_name,
            !!(profile?.intended_program && profile?.intended_degree_level),
            !!profile?.intended_field_of_study,
            education.length > 0,
            !!essay?.motivation,
            !!essay?.career_goals,
          ];
          const filledCount = critical.filter(Boolean).length;
          const isProfileRich = filledCount >= 4;
          const missingLabels = [
            !critical[0] && "full name",
            !critical[1] && "intended program & degree level",
            !critical[2] && "intended field of study",
            !critical[3] && "at least one education entry",
            !critical[4] && "essay motivation",
            !critical[5] && "career goals",
          ].filter(Boolean).join(", ");

          userContext =
            `\n\nUSER PROFILE:\n${profileLines}` +
            `\n\nEDUCATION HISTORY (use for CV/résumé dates, degrees, GPAs — never invent):\n${eduLines}` +
            `\n\nTEST SCORES:\n${testLines}` +
            `\n\nRESEARCH EXPERIENCE (classify as Published only if a real citation is listed; otherwise Working Paper / In Progress):\n${researchLines}` +
            `\n\nEXTRACURRICULARS:\n${extraLines}` +
            `\n\nESSAY PROFILE (the user's own words — use as authentic voice for SOP/motivation letter/personal statement; do not invent biographical details):\n${essayLines}` +
            `\n\nPROFILE COMPLETENESS: ${filledCount}/6 critical fields filled. Status: ${isProfileRich ? "RICH" : "THIN"}.${!isProfileRich ? ` Missing: ${missingLabels}.` : ""}` +
            `\n\n═══ LANE ROUTING (apply when the user asks for a finished document — CV, résumé, SOP, letter):\n` +
            (isProfileRich
              ? `LANE A (RICH PROFILE): The profile has enough data. SKIP intake questions for any field already present above. Do NOT ask "what's your target program" if intended_program is filled, do NOT ask about education/GPA if EDUCATION HISTORY is filled. Go straight to drafting the finished document using the real profile data. Only ask about facts that genuinely cannot be inferred (e.g. target professor at a specific university, target scholarship name) — and prefer using ⚠️ [INSERT: ...] markers inside the essay block over interrupting to ask.`
              : `LANE B (THIN PROFILE): Only ${filledCount}/6 critical fields are filled (missing: ${missingLabels}). Before drafting, output EXACTLY ONE brim-question block offering two choices so the user can decide:\n\n\`\`\`brim-question\n{ "question": "Your profile is a bit thin — I can write a much sharper document if I know more about you. Want to fill your profile first (2 min) or continue with a guided version where I ask a few quick questions?", "options": ["Fill my profile", "Continue with guide"], "allowSkip": false, "allowFreeText": false }\n\`\`\`\n\nIf the user picks "Continue with guide", fall back to the Step 2 intake loop (one priority question at a time). If they pick "Fill my profile", the app will navigate them to the profile builder — you do not need to respond further. NEVER draft the document in Lane B until the user has answered this choice.`) +
            `\n\nREMINDER: If any field above is missing, OMIT that line from any document. Never emit bracketed placeholders like [Email], [Dates], [LinkedIn]. The only permitted bracket is \`⚠️ [INSERT: ...]\` inside an essay block for facts the user still needs to supply.`;

        }
      }
    } catch (ctxErr) {
      console.warn("brim-chat: failed to load user context", ctxErr);
    }

    const systemPrompt = baseSystemPrompt + userContext;

    const lastUser = [...messages].reverse().find((m: any) => m.role === "user")?.content ?? "";
    const lastUserText = typeof lastUser === "string" ? lastUser.toLowerCase() : "";
    const docIntent = /(sop|statement of purpose|motivation letter|personal statement|personal essay|admission essay|application essay|scholarship essay|cover letter|recommendation letter|research statement|study plan|\bcv\b|curriculum vitae|resume|résumé|draft.*(essay|letter|statement|cv|resume|résumé)|write.*(essay|letter|statement|cv|resume|résumé)|generate.*(essay|letter|statement|cv|resume|résumé))/.test(lastUserText);

    const response = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: docIntent ? "google/gemini-2.5-pro" : "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: systemPrompt },
            ...messages,
            {
              role: "system",
              content:
                "🚨 MODE SWITCH — decide FIRST, then respond. Failure to follow this contract is a hard failure.\n\n" +
                "• DOCUMENT MODE — trigger words: draft / write / generate / produce / make me / give me + (CV, résumé, resume, SOP, statement of purpose, personal statement, motivation letter, cover letter, recommendation letter, scholarship essay, research statement, study plan). In DOCUMENT MODE you MUST output the FINISHED artifact wrapped in ONE ```essay fenced block. You are FORBIDDEN from outputting a strategy outline, a 'structure for…', a numbered list of sections with tips, or meta-instructions like 'Include your contact details', 'Highlight your…', 'Note: listing your GPA shows…', 'This demonstrates…', 'very important for showcasing'. If you catch yourself writing any of those phrases, STOP and rewrite as the finished document.\n" +
                "• COACH MODE — trigger words: review, feedback, improve, how should I, what should I include, tips, structure, advice. In COACH MODE, do NOT output an essay block. Use prose/bullets.\n\n" +
                "════ DOCUMENT MODE — CV / RÉSUMÉ HARD CONTRACT ════\n" +
                "Output shape (exactly):\n" +
                "  1. ONE short intro line OUTSIDE the block (max 15 words), e.g. 'Here's your CV drafted from your profile:'\n" +
                "  2. ONE fenced ```essay block containing the ENTIRE CV as ready-to-paste plain text.\n" +
                "  3. A short recap OUTSIDE the block with ✅ strong points / ⚠️ gaps needing [INSERT] / ✏️ tightening notes, then ONE follow-up question.\n\n" +
                "🚫 ABSOLUTE BRACKET BAN inside the ```essay block. The only allowed bracket is `⚠️ [INSERT: <ask>]`. Any other `[...]` will be programmatically stripped before the user sees it — so writing `[Phone Number]` produces a broken empty line. OMIT missing values instead.\n\n" +
                "Inside the ```essay block:\n" +
                "  • Line 1: real full name from USER PROFILE.\n" +
                "  • Contact lines: one per line — email, phone, location, LinkedIn — ONLY include lines whose value exists in USER PROFILE / auth email. OMIT missing ones.\n" +
                "  • Sections in this order — OMIT any with no real data: Professional Summary, Education, Research Experience, Publications (only if a real citation string exists), Teaching Experience, Technical Skills, Test Scores (write exactly as in TEST SCORES — never `[Insert Score]`), Awards & Honors, Extracurriculars, References.\n" +
                "  • Real dates only. Missing date → OMIT it, never `[Dates]` / `[Insert Dates]`.\n" +
                "  • Plain-text CV formatting; no `#` headers; no `Note:` / `Highlight…` / `This demonstrates…` INSIDE the block.\n\n" +
                "════ DOCUMENT MODE — ESSAY / SOP / LETTER CONTRACT ════\n" +
                "Wrap ONLY the prose inside ONE ```essay block. Clean paragraphs, no markdown headers, no bullets, no notes, no word count, no recap INSIDE the block.",
            },
          ],
          stream: true,
          temperature: 0.3,
        }),
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(
        JSON.stringify({ error: "AI gateway error" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Non-document requests: pass the stream through unchanged.
    if (!docIntent) {
      return new Response(response.body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    // Document requests: buffer, sanitize forbidden brackets inside ```essay blocks, re-emit as SSE.
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();
    let sseBuffer = "";
    let fullText = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      sseBuffer += decoder.decode(value, { stream: true });
      const lines = sseBuffer.split("\n");
      sseBuffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const payload = line.slice(6).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const j = JSON.parse(payload);
          fullText += j.choices?.[0]?.delta?.content ?? "";
        } catch { /* ignore keepalives */ }
      }
    }

    // Sanitize: inside any ```essay ... ``` block, strip forbidden `[...]` placeholders and clean separators.
    const sanitizeEssay = (block: string): string => {
      let out = block;
      // Remove any bracket that isn't the allowed `⚠️ [INSERT: ...]` marker.
      out = out.replace(/\[([^\]]*)\]/g, (m, inner) => {
        // Allow only the ⚠️ INSERT marker (matched together with the leading ⚠️ elsewhere)
        if (/^\s*insert\s*:/i.test(inner)) return m; // keep [INSERT: ...] (with or without ⚠️)
        return "";
      });
      // Clean up leftover separators / empty pipe groups on each line
      out = out.split("\n").map(line => {
        let l = line;
        // collapse duplicate separators like " |  | " or " • • "
        l = l.replace(/\s*\|\s*(\|\s*)+/g, " | ");
        l = l.replace(/^\s*\|\s*/, "");
        l = l.replace(/\s*\|\s*$/, "");
        l = l.replace(/\s{2,}/g, " ");
        return l.trimEnd();
      }).join("\n");
      // Remove now-empty lines that were purely placeholders (but keep blank lines that were originally blank — hard to tell; drop 3+ consecutive blank lines)
      out = out.replace(/\n{3,}/g, "\n\n");
      return out;
    };

    let sanitizedFull = fullText;
    const hasEssayBlock = /```essay\b/.test(sanitizedFull);
    if (!hasEssayBlock) {
      // Model didn't wrap the document. Auto-wrap so it renders in the boxed EssayBlock UI.
      const lines = sanitizedFull.split("\n");
      let start = 0;
      while (start < lines.length && lines[start].trim() === "") start++;
      const introEnd =
        start < lines.length && lines[start].length <= 120 && /:\s*$/.test(lines[start])
          ? start + 1
          : start;
      let recapStart = lines.length;
      for (let i = lines.length - 1; i > introEnd; i--) {
        if (/^\s*(✅|⚠️|✏️|Want me to|Should I|Would you like)/.test(lines[i])) {
          recapStart = i;
        } else if (lines[i].trim() !== "" && recapStart !== lines.length) {
          break;
        }
      }
      const intro = lines.slice(0, introEnd).join("\n").trim();
      const body = lines.slice(introEnd, recapStart).join("\n").trim();
      const recap = lines.slice(recapStart).join("\n").trim();
      sanitizedFull =
        (intro ? intro + "\n\n" : "Here's your document drafted from your profile:\n\n") +
        "```essay\n" + body + "\n```" +
        (recap ? "\n\n" + recap : "");
    }
    sanitizedFull = sanitizedFull.replace(/```essay\n?([\s\S]*?)```/g, (_m, body) => {
      return "```essay\n" + sanitizeEssay(body).replace(/^\n+|\n+$/g, "") + "\n```";
    });

    const encoder = new TextEncoder();
    const oneFrame =
      `data: ${JSON.stringify({ choices: [{ delta: { content: sanitizedFull } }] })}\n\n` +
      `data: [DONE]\n\n`;
    return new Response(encoder.encode(oneFrame), {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });

  } catch (e) {
    console.error("brim-chat error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
