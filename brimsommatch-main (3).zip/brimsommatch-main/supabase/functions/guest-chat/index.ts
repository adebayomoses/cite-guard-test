import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";

const SYSTEM_PROMPT = `You are Brim, the AI scholarship advisor for Brimsom. You help students discover scholarships, improve applications (SOPs, essays), and understand eligibility for programs worldwide (Chevening, DAAD, Fulbright, Commonwealth, MEXT, etc.).

Keep answers concise (2-4 short paragraphs max), warm, and actionable. Use markdown formatting (bold, lists) when helpful. If the user asks about their personal chances, gently note that a full assessment requires building a profile on Brimsom — but still give them a useful general answer first.

You are talking to a guest visitor who hasn't signed up yet. Be helpful and impressive — this is their first taste of Brimsom.`;

const INTENT_PROMPT = `You are an intent classifier for a scholarship chat. Given the user's latest message and recent conversation, return STRICT JSON:
{"wants_scholarships": boolean, "country": string|null, "degree_level": string|null, "field_of_study": string|null}

Rules:
- "wants_scholarships" is true if the user is asking for scholarship listings/recommendations/suggestions to apply to.
- country: a single country name OR a region keyword from this allowed set: "Europe", "Asia", "Africa", "North America", "South America", "Oceania", "Middle East". Use null if unclear.
- degree_level: one of "Undergraduate", "Masters", "PhD", "Postdoc" or null.
- field_of_study: short topic like "Computer Science", "Public Health" or null.
Return ONLY the JSON, no prose.`;

const REGION_COUNTRIES: Record<string, string[]> = {
  europe: ["United Kingdom", "UK", "Germany", "France", "Netherlands", "Sweden", "Norway", "Denmark", "Finland", "Ireland", "Italy", "Spain", "Belgium", "Austria", "Switzerland", "Portugal", "Poland", "Czech Republic", "Hungary", "Greece", "Romania", "Estonia", "Iceland", "Luxembourg", "Slovenia", "Slovakia", "EU", "Europe"],
  asia: ["Japan", "China", "South Korea", "Singapore", "Hong Kong", "Taiwan", "India", "Malaysia", "Thailand", "Indonesia", "Vietnam", "Asia"],
  africa: ["South Africa", "Egypt", "Nigeria", "Kenya", "Ghana", "Morocco", "Rwanda", "Ethiopia", "Africa"],
  "north america": ["United States", "USA", "US", "Canada", "Mexico", "North America"],
  "south america": ["Brazil", "Argentina", "Chile", "Colombia", "Peru", "South America"],
  oceania: ["Australia", "New Zealand", "Oceania"],
  "middle east": ["UAE", "United Arab Emirates", "Saudi Arabia", "Qatar", "Israel", "Turkey", "Middle East"],
};

// Country name aliases — many DBs store one form ("United Kingdom") while users
// type another ("UK"). Expand to all known variants for ilike matching.
const COUNTRY_ALIASES: Record<string, string[]> = {
  uk: ["United Kingdom", "UK", "Britain", "Great Britain", "England"],
  "united kingdom": ["United Kingdom", "UK", "Britain", "Great Britain", "England"],
  britain: ["United Kingdom", "UK", "Britain"],
  england: ["United Kingdom", "UK", "England"],
  usa: ["USA", "United States", "US", "America"],
  us: ["USA", "United States", "US"],
  "united states": ["USA", "United States", "US", "America"],
  america: ["USA", "United States", "America"],
  uae: ["UAE", "United Arab Emirates"],
  "united arab emirates": ["UAE", "United Arab Emirates"],
  "south korea": ["South Korea", "Korea"],
  korea: ["South Korea", "Korea"],
  "hong kong": ["Hong Kong"],
};

// Degree-level aliases. DB uses short codes (MSC, PHD, BSC, MBA) while users
// say "Masters", "PhD", "Bachelors". Map to all variants for ilike matching.
const DEGREE_ALIASES: Record<string, string[]> = {
  masters: ["MSC", "MA", "MBA", "MPH", "MPA", "MEd", "LLM", "Master"],
  master: ["MSC", "MA", "MBA", "MPH", "MPA", "MEd", "LLM", "Master"],
  "master's": ["MSC", "MA", "MBA", "MPH", "MPA", "MEd", "LLM", "Master"],
  mba: ["MBA"],
  phd: ["PHD", "Doctorate"],
  doctorate: ["PHD", "Doctorate"],
  doctoral: ["PHD", "Doctorate"],
  bachelors: ["BSC", "BA", "Bachelor", "Undergraduate"],
  bachelor: ["BSC", "BA", "Bachelor", "Undergraduate"],
  "bachelor's": ["BSC", "BA", "Bachelor", "Undergraduate"],
  undergraduate: ["BSC", "BA", "Bachelor", "Undergraduate"],
  postdoc: ["Postdoc"],
  diploma: ["Diploma"],
  associate: ["Associate"],
};

async function extractIntent(messages: any[], apiKey: string) {
  try {
    const recent = messages.slice(-4);
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        messages: [
          { role: "system", content: INTENT_PROMPT },
          ...recent.map((m: any) => ({ role: m.role, content: m.content })),
        ],
        response_format: { type: "json_object" },
      }),
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    const txt = data.choices?.[0]?.message?.content || "{}";
    return JSON.parse(txt);
  } catch (e) {
    console.error("intent extract failed", e);
    return null;
  }
}

async function fetchScholarships(intent: any) {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  let query = supabase
    .from("scholarships")
    .select("id, title, provider, country, degree_level, next_close_date, funding_type, funding_amount, url")
    .eq("is_active", true);

  // Country / region filter
  if (intent?.country) {
    const key = String(intent.country).toLowerCase().trim();
    const regionList = REGION_COUNTRIES[key];
    const aliasList = COUNTRY_ALIASES[key];
    if (regionList && regionList.length > 0) {
      const orExpr = regionList.map((c) => `country.ilike.%${c}%`).join(",");
      query = query.or(orExpr);
    } else if (aliasList && aliasList.length > 0) {
      const orExpr = aliasList.map((c) => `country.ilike.%${c}%`).join(",");
      query = query.or(orExpr);
    } else {
      query = query.ilike("country", `%${intent.country}%`);
    }
  }
  if (intent?.degree_level) {
    const dkey = String(intent.degree_level).toLowerCase().trim();
    const dAliases = DEGREE_ALIASES[dkey];
    if (dAliases && dAliases.length > 0) {
      const orExpr = dAliases.map((d) => `degree_level.ilike.%${d}%`).join(",");
      query = query.or(orExpr);
    } else {
      query = query.ilike("degree_level", `%${intent.degree_level}%`);
    }
  }
  if (intent?.field_of_study) {
    query = query.ilike("field_of_study", `%${intent.field_of_study}%`);
  }

  query = query.order("next_close_date", { ascending: true, nullsFirst: false }).limit(6);

  const { data, error } = await query;
  if (error) {
    console.error("scholarship fetch error", error);
    return [];
  }
  return data || [];
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, guest_id } = await req.json();

    // Stable guest identifier (cookie) — required for fair limiting
    const guestId = typeof guest_id === "string" ? guest_id.trim().slice(0, 64) : "";
    if (!guestId || guestId.length < 8) {
      return new Response(JSON.stringify({ error: "Missing guest identifier" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const FREE_LIMIT = 2;
    const WINDOW_MS = 24 * 60 * 60 * 1000;
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Load existing usage row
    const { data: usageRow } = await admin
      .from("guest_chat_usage")
      .select("count, reset_at")
      .eq("guest_id", guestId)
      .maybeSingle();

    let currentCount = usageRow?.count ?? 0;
    let currentResetAt = usageRow?.reset_at ? new Date(usageRow.reset_at).getTime() : 0;
    const nowMs = Date.now();

    // Expired window → reset
    if (currentResetAt && nowMs >= currentResetAt) {
      currentCount = 0;
      currentResetAt = 0;
    }

    if (currentCount >= FREE_LIMIT) {
      return new Response(
        JSON.stringify({
          error: "Free preview limit reached. Please sign up to continue.",
          limit_reached: true,
          reset_at: currentResetAt || null,
          used: currentCount,
          limit: FREE_LIMIT,
        }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!Array.isArray(messages) || messages.length === 0) {
      return new Response(JSON.stringify({ error: "messages array is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (messages.length > 6) {
      return new Response(JSON.stringify({ error: "Too many messages" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    for (const m of messages) {
      if (typeof m?.content !== "string" || m.content.length > 2000) {
        return new Response(JSON.stringify({ error: "Invalid message content" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "AI not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Step A: extract intent
    const intent = await extractIntent(messages, LOVABLE_API_KEY);
    let scholarships: any[] = [];
    if (intent?.wants_scholarships) {
      scholarships = await fetchScholarships(intent);
    }

    // Build assistant context
    let extraSystem = "";
    if (scholarships.length > 0) {
      const list = scholarships
        .map((s, i) => `${i + 1}. ${s.title}${s.provider ? ` — ${s.provider}` : ""}${s.country ? ` (${s.country})` : ""}`)
        .join("\n");
      extraSystem = `\n\nThe UI is rendering ${scholarships.length} real scholarship cards from our database for this user (do NOT list them in markdown — the cards already show title, provider, country, deadline). Here is the list for your awareness:\n${list}\n\nWrite a short, warm 2-3 sentence intro acknowledging the picks (mention the region/level if relevant), then end with ONE friendly sentence inviting them to sign up free to get personalized matches with win-chance scoring. Do NOT repeat the scholarship details — the cards do that.`;
    } else if (intent?.wants_scholarships) {
      extraSystem = `\n\nThe user asked for scholarships but no exact matches were found in our database for their criteria. Acknowledge this gracefully, suggest broadening criteria or related options you know of generally (1-2 examples), and invite them to sign up free for the full database and personalized matching.`;
    }

    const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT + extraSystem },
          ...messages.map((m: any) => ({ role: m.role, content: m.content })),
        ],
        stream: true,
      }),
    });

    if (!aiResp.ok) {
      if (aiResp.status === 429) {
        return new Response(JSON.stringify({ error: "Too many requests, please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResp.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please try again later." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errText = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, errText);
      return new Response(JSON.stringify({ error: "AI service error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Increment usage server-side (authoritative)
    const newCount = currentCount + 1;
    const newResetAt = currentResetAt || nowMs + WINDOW_MS;
    await admin.from("guest_chat_usage").upsert({
      guest_id: guestId,
      count: newCount,
      reset_at: new Date(newResetAt).toISOString(),
      updated_at: new Date().toISOString(),
    });

    // Compose stream: prepend usage + scholarships SSE events, then proxy AI stream
    const encoder = new TextEncoder();
    const reader = aiResp.body!.getReader();
    const stream = new ReadableStream({
      async start(controller) {
        const usageEvt = `data: ${JSON.stringify({ type: "usage", used: newCount, limit: FREE_LIMIT, reset_at: newResetAt })}\n\n`;
        controller.enqueue(encoder.encode(usageEvt));
        if (scholarships.length > 0) {
          const evt = `data: ${JSON.stringify({ type: "scholarships", items: scholarships })}\n\n`;
          controller.enqueue(encoder.encode(evt));
        }
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            controller.enqueue(value);
          }
        } catch (e) {
          console.error("stream proxy error", e);
        } finally {
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("guest-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
