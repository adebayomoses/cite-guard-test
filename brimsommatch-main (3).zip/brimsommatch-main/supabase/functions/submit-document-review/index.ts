import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Mirrors src/lib/subscriptionTiers.ts limits for document_review.
// Free is enforced as "1 per 2 months" via the 2month period.
const LIMITS: Record<string, { count: number; period: "day" | "month" | "2month" | "total" }> = {
  free: { count: 1, period: "2month" },
  standard: { count: 3, period: "month" },
  pro: { count: 6, period: "month" },
  pro_plus: { count: 10, period: "month" },
};

const PRO_ONLY_SERVICES = new Set(["research_proposal", "full_package"]);

interface Item {
  service_type: string;
  file_url: string;
  file_name: string;
  notes?: string | null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false } },
    );

    const { data: claimsData, error: claimsErr } = await admin.auth.getClaims(token);
    if (claimsErr || !claimsData?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = claimsData.claims.sub as string;

    const body = await req.json().catch(() => ({}));
    const items: Item[] = Array.isArray(body?.items) ? body.items : [];
    if (items.length === 0) {
      return new Response(JSON.stringify({ error: "No items provided" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate each item
    for (const it of items) {
      if (!it?.service_type || !it?.file_url || !it?.file_name) {
        return new Response(JSON.stringify({ error: "Invalid item" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      // Ensure file path belongs to this user (matches existing storage RLS layout)
      if (!it.file_url.startsWith(`${userId}/`)) {
        return new Response(JSON.stringify({ error: "Forbidden file path" }), {
          status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Resolve plan: site setting override + admin-granted subscription
    const { data: settingsRows } = await admin
      .from("site_settings")
      .select("key, value")
      .in("key", ["premium_disabled"]);
    const freeMode =
      (settingsRows ?? []).find((r: any) => r.key === "premium_disabled")?.value === "true";

    let plan: keyof typeof LIMITS = "free";
    if (freeMode) {
      plan = "pro";
    } else {
      const { data: sub } = await admin
        .from("user_subscriptions")
        .select("plan, is_active")
        .eq("user_id", userId)
        .maybeSingle();
      if (sub?.is_active && sub.plan && LIMITS[sub.plan as string]) {
        plan = sub.plan as keyof typeof LIMITS;
      }
    }

    const tier = LIMITS[plan];

    // Pro-only services
    const requestsProOnly = items.some((it) => PRO_ONLY_SERVICES.has(it.service_type));
    if (requestsProOnly && !(plan === "pro" || plan === "pro_plus")) {
      return new Response(
        JSON.stringify({
          error: "upgrade_required",
          reason: "pro_only_service",
          plan,
        }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Current usage in window (free mode skips the check)
    let usage = 0;
    if (!freeMode) {
      const { data: countData, error: countErr } = await admin.rpc(
        "get_feature_usage_count" as any,
        { _user_id: userId, _feature: "document_review", _period: tier.period },
      );
      if (countErr) throw countErr;
      usage = (countData as number) ?? 0;

      const remaining = Math.max(0, tier.count - usage);
      // A full_package is counted as ONE document_review use, regardless of
      // how many files are in the package. Single items count 1 each.
      const cost = items.some((it) => it.service_type === "full_package") ? 1 : items.length;
      if (cost > remaining) {
        return new Response(
          JSON.stringify({
            error: "limit_reached",
            plan,
            usage,
            limit: tier.count,
            period: tier.period,
            remaining,
          }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
    }

    // Insert submission rows
    const rows = items.map((it) => ({
      user_id: userId,
      service_type: it.service_type,
      file_url: it.file_url,
      file_name: it.file_name,
      notes: it.notes ?? null,
      status: "pending",
    }));

    const { data: inserted, error: insErr } = await admin
      .from("document_submissions")
      .insert(rows)
      .select("id");
    if (insErr) throw insErr;

    // Track usage (one row per submission op — see cost above)
    if (!freeMode) {
      const cost = items.some((it) => it.service_type === "full_package") ? 1 : items.length;
      const usageRows = Array.from({ length: cost }, () => ({
        user_id: userId,
        feature: "document_review",
      }));
      const { error: usageErr } = await admin.from("feature_usage").insert(usageRows);
      if (usageErr) console.error("[submit-document-review] usage insert failed", usageErr);
    }

    return new Response(
      JSON.stringify({ success: true, ids: (inserted ?? []).map((r: any) => r.id) }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error("[submit-document-review] error", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
