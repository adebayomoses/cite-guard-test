import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function buildStudentSummary(profile: any, education: any[], subjects: any[], testScores: any[], research: any[], extracurriculars: any[], sop: string, documents: any[]) {
  return `
Student Profile:
- Name: ${profile?.full_name ?? "Not provided"}
- Highest Qualification (current): ${profile?.academic_level ?? "Not specified"}
- Intended Program (wants to study abroad): ${profile?.intended_program ?? "Not specified"}
- Intended Degree Level: ${profile?.intended_degree_level ?? "Not specified"}
- Intended Field of Study: ${profile?.intended_field_of_study ?? "Not specified"}
- Nationality: ${profile?.nationality ?? "Not provided"}
- Country of Residence: ${profile?.country_of_residence ?? "Not provided"}
- Bio: ${profile?.bio ?? "None"}

Education (${education.length} entries):
${education.map((e: any) => {
  const gpaStr = e.gpa != null
    ? (e.gpa_scale ? `${e.gpa}/${e.gpa_scale} (${((e.gpa / e.gpa_scale) * 100).toFixed(1)}%)` : `${e.gpa} (scale unknown)`)
    : "N/A";
  return `  - ${e.degree_level} at ${e.institution}, Field: ${e.field_of_study ?? "N/A"}, GPA: ${gpaStr}, Current: ${e.is_current}`;
}).join("\n") || "  None"}

High School Subjects (${subjects.length}):
${subjects.map((s: any) => `  - ${s.subject_name}: ${s.grade ?? "N/A"}`).join("\n") || "  None"}

Test Scores (${testScores.length}):
${testScores.map((t: any) => `  - ${t.test_type}: ${t.score}${t.max_score ? "/" + t.max_score : ""}`).join("\n") || "  None"}

Research Experience (${research.length}):
${research.map((r: any) => `  - ${r.title} at ${r.organization ?? "N/A"}, Publications: ${r.publications?.length ?? 0}`).join("\n") || "  None"}

Extracurriculars (${extracurriculars.length}):
${extracurriculars.map((e: any) => `  - ${e.title} (${e.category}) at ${e.organization ?? "N/A"}`).join("\n") || "  None"}

Statement of Purpose: ${sop ? "Provided (" + sop.length + " chars)" : "Not provided"}
Documents uploaded: ${documents.length} (${documents.map((d: any) => d.document_type).join(", ") || "none"})
`.trim();
}

const systemPrompt = `You are a personalized scholarship/admission fit evaluator. The student pasted (or uploaded) the description of a scholarship or admission opportunity. You will evaluate THIS specific opportunity against THE STUDENT'S real profile.

CRITICAL RULES:
1. Always address the student in the second person ("you", "your"). Never third person.
2. Compare GPAs as PERCENTAGES — student GPAs are given with their scale and percentage; if the opportunity states a min CGPA, normalize before comparing.
3. In "chance_reason", reference AT LEAST 2 concrete fields from the student's profile (e.g. their actual GPA %, a specific test score they took or are missing, their nationality, their field of study, research output, etc.). NEVER write generic statements that could apply to any student.
4. Each item in "action_steps" MUST be diagnostic and specific:
   - Name what is missing or weak in their profile
   - Say what concrete action to take
   - Tie it to why it matters for THIS opportunity
   - GOOD: "You don't have an English proficiency test on file — take IELTS and aim for 7.0+ since this scholarship requires proof of English."
   - BAD: "Improve your essay" / "Strengthen your application" / "Get more experience"
5. If a gap is structurally unclosable (e.g. wrong nationality, wrong degree level, deadline already passed), say so honestly in gap_summary instead of pretending it can be fixed.
6. Title/provider/country: extract from the opportunity text; if unknown, leave empty string.
7. match_score = how well the profile fits the requirements. chance_score = realistic likelihood of being selected (factor competitiveness). Both 0-100.
8. Provide 3 to 5 action_steps. No more, no less.

Return your answer ONLY by calling the evaluate_match function.`;

const aiToolDef = {
  type: "function" as const,
  function: {
    name: "evaluate_match",
    description: "Return personalized fit evaluation for the scholarship/admission opportunity.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", description: "Best-effort scholarship/program title extracted from text" },
        provider: { type: "string", description: "Provider/university/foundation if mentioned" },
        country: { type: "string", description: "Country if mentioned" },
        match_score: { type: "integer", minimum: 0, maximum: 100 },
        match_reason: { type: "string", minLength: 80 },
        chance_score: { type: "integer", minimum: 0, maximum: 100 },
        chance_reason: { type: "string", minLength: 80, description: "Must reference at least 2 concrete profile fields." },
        gap_summary: { type: "string", minLength: 60, description: "One short paragraph naming the specific reasons your chance isn't 90+." },
        action_steps: {
          type: "array",
          minItems: 3,
          maxItems: 5,
          items: { type: "string", minLength: 30 },
          description: "3-5 personalized, diagnostic action items.",
        },
      },
      required: ["title", "provider", "country", "match_score", "match_reason", "chance_score", "chance_reason", "gap_summary", "action_steps"],
      additionalProperties: false,
    },
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const scholarshipText: string = (body?.scholarship_text ?? "").toString().trim();
    if (!scholarshipText || scholarshipText.length < 30) {
      return new Response(JSON.stringify({ error: "Please provide more scholarship details (at least 30 characters)." }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const trimmedText = scholarshipText.slice(0, 15000);

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    const [profileRes, eduRes, testRes, researchRes, extraRes, sopRes, docsRes, subjectsRes] = await Promise.all([
      adminClient.from("profiles").select("*").eq("user_id", user.id).single(),
      adminClient.from("education_history").select("*").eq("user_id", user.id),
      adminClient.from("test_scores").select("*").eq("user_id", user.id),
      adminClient.from("research_experience").select("*").eq("user_id", user.id),
      adminClient.from("extracurriculars").select("*").eq("user_id", user.id),
      adminClient.from("sop_entries").select("content").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1),
      adminClient.from("user_documents").select("document_type, file_name").eq("user_id", user.id),
      adminClient.from("high_school_subjects").select("*").eq("user_id", user.id),
    ]);

    const studentSummary = buildStudentSummary(
      profileRes.data,
      eduRes.data ?? [],
      subjectsRes.data ?? [],
      testRes.data ?? [],
      researchRes.data ?? [],
      extraRes.data ?? [],
      sopRes.data?.[0]?.content ?? "",
      docsRes.data ?? []
    );

    const userPrompt = `Evaluate this scholarship/admission opportunity for the student.

${studentSummary}

--- OPPORTUNITY (pasted by the student) ---
${trimmedText}
--- END OPPORTUNITY ---

Call evaluate_match with personalized scores, reasons, gap summary, and 3-5 diagnostic action steps grounded in the student's real profile fields above.`;

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        temperature: 0,
        max_tokens: 2500,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [aiToolDef],
        tool_choice: { type: "function", function: { name: "evaluate_match" } },
      }),
    });

    if (!aiResponse.ok) {
      const status = aiResponse.status;
      const errBody = await aiResponse.text();
      console.error("AI error:", status, errBody);
      if (status === 429) return new Response(JSON.stringify({ error: "Rate limited. Please try again in a moment." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
      if (status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
      return new Response(JSON.stringify({ error: `AI gateway error: ${status}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiResponse.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(JSON.stringify({ error: "AI did not return structured output" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parsed = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify({ result: parsed }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("match-scholarship error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
