import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function buildStudentSummary(profile: any, education: any[], subjects: any[], testScores: any[], research: any[], extracurriculars: any[], sop: string, documents: any[]) {
  return `
Student Profile:
- Name: ${profile?.full_name ?? "Not provided"}
- Highest Qualification (current): ${profile?.academic_level ?? "Not specified"}
- Intended Program (wants to study abroad): ${profile?.intended_program ?? "Not specified"}
- Intended Degree Level: ${profile?.intended_degree_level ?? "Not specified"}
- Intended Field of Study: ${profile?.intended_field_of_study ?? "Not specified"}
- Nationality: ${profile?.nationality ?? "Not provided"}
- Country of Residence: ${profile?.country_of_residence ?? "Not provided"}
- Bio: ${profile?.bio ?? "None"}

Education (${education.length} entries):
${education.map((e: any) => {
  const gpaStr = e.gpa != null
    ? (e.gpa_scale ? `${e.gpa}/${e.gpa_scale} (${((e.gpa / e.gpa_scale) * 100).toFixed(1)}%)` : `${e.gpa} (scale unknown)`)
    : "N/A";
  return `  - ${e.degree_level} at ${e.institution}, Field: ${e.field_of_study ?? "N/A"}, GPA: ${gpaStr}, Current: ${e.is_current}`;
}).join("\n") || "  None"}

High School Subjects (${subjects.length}):
${subjects.map((s: any) => `  - ${s.subject_name}: ${s.grade ?? "N/A"}`).join("\n") || "  None"}

Test Scores (${testScores.length}):
${testScores.map((t: any) => `  - ${t.test_type}: ${t.score}${t.max_score ? "/" + t.max_score : ""}`).join("\n") || "  None"}

Research Experience (${research.length}):
${research.map((r: any) => `  - ${r.title} at ${r.organization ?? "N/A"}, Publications: ${r.publications?.length ?? 0}`).join("\n") || "  None"}

Extracurriculars (${extracurriculars.length}):
${extracurriculars.map((e: any) => `  - ${e.title} (${e.category}) at ${e.organization ?? "N/A"}`).join("\n") || "  None"}

Statement of Purpose: ${sop ? "Provided (" + sop.length + " chars)" : "Not provided"}
Documents uploaded: ${documents.length} (${documents.map((d: any) => d.document_type).join(", ") || "none"})
`.trim();
}

function formatScholarship(s: any) {
  return `
- ID: ${s.id}
  Title: ${s.title}
  Provider: ${s.provider ?? "N/A"}
  Country: ${s.country ?? "Any"}
  Degree Level: ${s.degree_level ?? "Any"}
  Field: ${s.field_of_study ?? "Any"}
  Min CGPA (as %): ${s.min_cgpa_percentage != null ? s.min_cgpa_percentage + "%" : "None"}
  Funding: ${s.funding_amount ?? "N/A"}
  Eligibility: ${s.eligibility_criteria ?? "N/A"}
  Deadline: ${s.next_close_date ?? "N/A"}
  Description: ${s.description ?? "N/A"}
`;
}

const systemPrompt = `You are a scholarship readiness evaluator. Evaluate a single scholarship for the student. Be realistic but encouraging.

IMPORTANT: Always address the student directly using second person ("you", "your").

CRITICAL GPA COMPARISON RULE: Student GPAs are provided with their scale (e.g. 3.36/4.0 = 84%) and scholarship minimum CGPAs are provided as percentages. ALWAYS compare using percentages.

Provide TWO separate scores:
1. Match score (0-100): How well the student's profile aligns with the scholarship requirements.
2. Chance score (0-100): The estimated likelihood of being selected, factoring competition.

For "reason" and "chance_reason", give SPECIFIC and DETAILED explanations (2-3 sentences). Reference concrete profile data and the scholarship's stated requirements. Written in second person.`;

const aiToolDef = {
  type: "function" as const,
  function: {
    name: "evaluate_scholarship",
    description: "Return the per-scholarship match and chance scores with detailed reasoning.",
    parameters: {
      type: "object",
      properties: {
        scholarship_id: { type: "string" },
        score: { type: "integer" },
        chance: { type: "integer" },
        reason: { type: "string", minLength: 80 },
        chance_reason: { type: "string", minLength: 80 },
      },
      required: ["scholarship_id", "score", "chance", "reason", "chance_reason"],
      additionalProperties: false,
    },
  },
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing authorization header");

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) throw new Error("Unauthorized");

    const body = await req.json().catch(() => ({}));
    const scholarshipId: string | undefined = body?.scholarship_id;
    if (!scholarshipId || typeof scholarshipId !== "string") {
      return new Response(JSON.stringify({ error: "scholarship_id is required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    const [scholarshipRes, profileRes, eduRes, testRes, researchRes, extraRes, sopRes, docsRes, subjectsRes, cachedRes] =
      await Promise.all([
        adminClient.from("scholarships").select("*").eq("id", scholarshipId).single(),
        adminClient.from("profiles").select("*").eq("user_id", user.id).single(),
        adminClient.from("education_history").select("*").eq("user_id", user.id),
        adminClient.from("test_scores").select("*").eq("user_id", user.id),
        adminClient.from("research_experience").select("*").eq("user_id", user.id),
        adminClient.from("extracurriculars").select("*").eq("user_id", user.id),
        adminClient.from("sop_entries").select("content").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1),
        adminClient.from("user_documents").select("document_type, file_name").eq("user_id", user.id),
        adminClient.from("high_school_subjects").select("*").eq("user_id", user.id),
        adminClient.from("score_results").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1),
      ]);

    if (!scholarshipRes.data) {
      return new Response(JSON.stringify({ error: "Scholarship not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const scholarship = scholarshipRes.data;
    const profile = profileRes.data;
    const education = eduRes.data ?? [];
    const testScores = testRes.data ?? [];
    const research = researchRes.data ?? [];
    const extracurriculars = extraRes.data ?? [];
    const sop = sopRes.data?.[0]?.content ?? "";
    const documents = docsRes.data ?? [];
    const subjects = subjectsRes.data ?? [];

    const studentSummary = buildStudentSummary(profile, education, subjects, testScores, research, extracurriculars, sop, documents);

    const userPrompt = `Evaluate this single scholarship for the student.

${studentSummary}

Scholarship:
${formatScholarship(scholarship)}

Call the evaluate_scholarship function. Set scholarship_id to "${scholarship.id}".`;

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        temperature: 0,
        max_tokens: 2000,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [aiToolDef],
        tool_choice: { type: "function", function: { name: "evaluate_scholarship" } },
      }),
    });

    if (!aiResponse.ok) {
      const status = aiResponse.status;
      const body = await aiResponse.text();
      console.error("AI error:", status, body);
      if (status === 429) return new Response(JSON.stringify({ error: "Rate limited. Please try again in a moment." }), {
        status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
      if (status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits." }), {
        status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
      return new Response(JSON.stringify({ error: `AI gateway error: ${status}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiData = await aiResponse.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      return new Response(JSON.stringify({ error: "AI did not return structured output" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parsed = JSON.parse(toolCall.function.arguments);
    const newMatch = {
      scholarship_id: scholarship.id,
      score: parsed.score,
      chance: parsed.chance,
      reason: parsed.reason,
      chance_reason: parsed.chance_reason || parsed.reason || "",
      // Note: no pending_ai flag → this is now a real AI score
    };

    // Update the cached score_results row: replace this scholarship's entry
    const cached = cachedRes.data?.[0];
    if (cached) {
      const matches: any[] = (cached.scholarship_matches as any[]) ?? [];
      const idx = matches.findIndex((m: any) => m.scholarship_id === scholarship.id);
      if (idx >= 0) matches[idx] = newMatch;
      else matches.push(newMatch);

      await adminClient
        .from("score_results")
        .update({ scholarship_matches: matches })
        .eq("id", cached.id);
    } else {
      // No cached row yet — create a minimal one
      await adminClient.from("score_results").insert({
        user_id: user.id,
        readiness_score: 50,
        readiness_summary: "Generate your full Chance Score for a complete readiness summary.",
        tips: [],
        scholarship_matches: [newMatch],
      });
    }

    return new Response(JSON.stringify({ match: newMatch }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("score-single-scholarship error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
