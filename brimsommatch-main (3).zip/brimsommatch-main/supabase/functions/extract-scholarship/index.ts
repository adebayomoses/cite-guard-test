import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // Validate auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claims?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });
    }

    const { raw_text } = await req.json();
    if (!raw_text || typeof raw_text !== "string" || raw_text.trim().length < 20) {
      return new Response(JSON.stringify({ error: "Please provide sufficient scholarship text" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: "You are a scholarship data extraction assistant. Extract structured scholarship information from raw text. Be precise with dates (use YYYY-MM-DD format). For degree_level, use comma-separated values from: BSC, MSC, PHD, Diploma, Associate, Postdoc, MBA. For funding_type use one of: Fully Funded, Partially Funded, Tuition Only, Living Expenses Only. For field_of_study, use comma-separated values from: Engineering, Computer Science & IT, Mathematics & Statistics, Physical Sciences, Life Sciences & Biology, Medicine & Health Sciences, Nursing & Pharmacy, Business & Management, Economics & Finance, Law, Social Sciences, Education, Arts & Design, Humanities & Literature, Languages & Linguistics, Agriculture & Environmental Science, Public Health, Any / All Fields. Format description and eligibility_criteria in markdown with bullet points and headings where appropriate.\n\nCRITICAL — BE EXHAUSTIVE, NOT SUMMARISED. The raw text may include navigation menus, unrelated pages, or generic university application guides mixed with the scholarship details. Ignore obvious navigation/menus, but do NOT drop any requirement or condition that is stated anywhere in the text — even if it appears in a general 'How to apply' or 'Application guide' section rather than the scholarship section itself. When in doubt, include it.\n\nThe eligibility_criteria field MUST be organised with these markdown subheadings (only include a subheading if the source text actually contains that information — never invent content):\n\n## Eligibility\n- Who can apply: nationality/residency, fee status, target programmes/degree level, campus, entry year, exclusions (e.g. programmes or applicant groups not eligible).\n\n## Academic Requirements\n- Degree classification thresholds (e.g. UK first-class, 2:1, 2:2, or international equivalent), minimum GPA, required prior qualifications, and any per-tier award criteria if the scholarship has multiple award levels.\n\n## Admission Requirements\n- Test scores (GRE/GMAT/IELTS/TOEFL/English language tests), prerequisite courses, work experience, portfolio/interview, qualification verification requirements (including which nationalities must verify and any verification fees).\n\n## Application Requirements\n- Documents the applicant must submit (degree certificates, transcripts, references — academic or professional and how many, personal statement with any word limit, English language test evidence, certified translations for non-English documents, agent/partner-programme specifics), and the application process/how the scholarship is awarded (e.g. automatic vs application-based, whether it appears in the offer letter, timelines).\n\nOmit any subheading whose information is absent from the source. Never fabricate requirements.",
          },
          {
            role: "user",
            content: `Extract scholarship details from the following text:\n\n${raw_text}`,
          },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_scholarship",
              description: "Extract structured scholarship data from raw text",
              parameters: {
                type: "object",
                properties: {
                  title: { type: "string", description: "Scholarship title" },
                  provider: { type: "string", description: "Organization offering the scholarship" },
                  country: { type: "string", description: "Country where scholarship is offered" },
                  description: { type: "string", description: "Detailed description in markdown" },
                  eligibility_criteria: { type: "string", description: "Eligibility requirements in markdown" },
                  field_of_study: { type: "string", description: "Comma-separated fields of study" },
                  degree_level: { type: "string", description: "Comma-separated degree levels" },
                  funding_amount: { type: "string", description: "Funding amount description" },
                  funding_type: { type: "string", description: "Type of funding" },
                  deadline: { type: "string", description: "Application deadline in YYYY-MM-DD" },
                  min_gpa: { type: "number", description: "Minimum GPA/CGPA required" },
                  min_cgpa_scale: { type: "number", description: "Scale of the CGPA (e.g. 4, 5, 10)" },
                  min_cgpa_percentage: { type: "number", description: "Minimum CGPA as percentage" },
                  url: { type: "string", description: "Application URL" },
                },
                required: ["title"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "extract_scholarship" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const text = await response.text();
      console.error("AI gateway error:", response.status, text);
      return new Response(JSON.stringify({ error: "AI extraction failed" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result = await response.json();
    const toolCall = result.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall?.function?.arguments) {
      return new Response(JSON.stringify({ error: "Could not extract scholarship details" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const extracted = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(extracted), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("extract-scholarship error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
