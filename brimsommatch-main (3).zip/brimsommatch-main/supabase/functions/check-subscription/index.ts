import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const TIERS: Record<string, string> = {
  // Legacy
  "prod_U9lKeVa3l33UzJ": "standard",
  "prod_U9lKiPRgjU7PQR": "pro",
  // Standard (monthly + yearly)
  "prod_UW6T8aLSSGd2QN": "standard",
  "prod_UW6UvOYXuFkDBc": "standard",
  // Pro (monthly + yearly)
  "prod_UW6VwYOuu4zNHl": "pro",
  "prod_UW6WzCWVuYDh4w": "pro",
  // Pro+ (monthly + yearly)
  "prod_UW6X0WLaZKav0f": "pro_plus",
  "prod_UW6Y4K2ghiHQ87": "pro_plus",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace("Bearer ", "");

    // Use service role to read DB
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Cryptographically verify JWT and extract userId + email
    let userId: string | null = null;
    let email: string | null = null;
    try {
      const { data: claimsData, error: claimsErr } = await supabaseAdmin.auth.getClaims(token);
      if (claimsErr || !claimsData?.claims?.sub) {
        return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      userId = claimsData.claims.sub as string;
      email = (claimsData.claims as any).email ?? null;
    } catch (_) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!userId) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }


    // Check for admin-granted override first
    const { data: adminOverride } = await supabaseAdmin
      .from("user_subscriptions")
      .select("plan, is_active")
      .eq("user_id", userId)
      .eq("stripe_subscription_id", "admin_granted")
      .maybeSingle();

    if (adminOverride && adminOverride.is_active && adminOverride.plan !== "free") {
      return new Response(JSON.stringify({
        subscribed: true,
        plan: adminOverride.plan,
        product_id: null,
        subscription_end: null,
        admin_granted: true,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // No admin override — check Stripe as before
    if (!email) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    const customers = await stripe.customers.list({ email, limit: 1 });

    if (customers.data.length === 0) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const customerId = customers.data[0].id;
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1,
    });

    if (subscriptions.data.length === 0) {
      return new Response(JSON.stringify({ subscribed: false, plan: "free" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const subscription = subscriptions.data[0];
    const subscriptionItem = subscription.items.data[0];
    const productId = subscriptionItem.price.product as string;
    const plan = TIERS[productId] || "standard";
    const periodEnd = typeof subscriptionItem.current_period_end === "number"
      ? subscriptionItem.current_period_end
      : null;
    const subscriptionEnd = periodEnd
      ? new Date(periodEnd * 1000).toISOString()
      : null;

    return new Response(JSON.stringify({
      subscribed: true,
      plan,
      product_id: productId,
      subscription_end: subscriptionEnd,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    return new Response(JSON.stringify({ error: msg }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
