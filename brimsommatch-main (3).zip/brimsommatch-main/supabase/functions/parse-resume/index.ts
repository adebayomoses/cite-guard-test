import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { BlobReader, ZipReader, BlobWriter } from "https://deno.land/x/zipjs@v2.7.32/index.js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Extract plain text from a DOCX file (which is a ZIP of XML files)
async function extractTextFromDocx(blob: Blob): Promise<string> {
  const reader = new ZipReader(new BlobReader(blob));
  const entries = await reader.getEntries();
  const docEntry = entries.find((e) => e.filename === "word/document.xml");
  if (!docEntry || !docEntry.getData) {
    await reader.close();
    throw new Error("Invalid DOCX: no word/document.xml found");
  }
  const writer = new BlobWriter();
  const xmlBlob = await docEntry.getData(writer);
  await reader.close();
  const xmlText = await xmlBlob.text();
  // Strip XML tags to get plain text, preserve paragraph breaks
  const text = xmlText
    .replace(/<\/w:p[^>]*>/g, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return text;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getUser(token);
    if (claimsError || !claimsData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { file_path } = await req.json();
    if (!file_path) {
      return new Response(JSON.stringify({ error: "file_path is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Download file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("user-documents")
      .download(file_path);

    if (downloadError || !fileData) {
      console.error("Download error:", downloadError);
      return new Response(JSON.stringify({ error: "Failed to download file" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const ext = file_path.split(".").pop()?.toLowerCase();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "AI not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = `You are a resume parser. Extract structured data from the resume. Be thorough and extract all available information. For fields not found, use empty strings or empty arrays. Do not invent data.`;

    // Build message content based on file type
    let userContent: unknown[];

    if (ext === "pdf") {
      // Gemini supports PDF natively via base64
      const arrayBuffer = await fileData.arrayBuffer();
      const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));
      userContent = [
        { type: "text", text: "Parse this resume and extract all profile information. Call the extract_profile function with the extracted data." },
        { type: "image_url", image_url: { url: `data:application/pdf;base64,${base64}` } },
      ];
    } else {
      // DOCX/DOC: extract text first, then send as plain text
      let resumeText: string;
      try {
        resumeText = await extractTextFromDocx(fileData);
      } catch (e) {
        console.error("DOCX extraction error:", e);
        return new Response(JSON.stringify({ error: "Could not read the document. Please try uploading a PDF instead." }), {
          status: 422,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!resumeText || resumeText.length < 20) {
        return new Response(JSON.stringify({ error: "The document appears to be empty or unreadable. Please try a different file." }), {
          status: 422,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      userContent = [
        { type: "text", text: `Parse this resume text and extract all profile information. Call the extract_profile function with the extracted data.\n\n--- RESUME ---\n${resumeText}\n--- END ---` },
      ];
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "extract_profile",
              description: "Extract structured profile data from a resume",
              parameters: {
                type: "object",
                properties: {
                  personal_info: {
                    type: "object",
                    properties: {
                      full_name: { type: "string" },
                      nationality: { type: "string" },
                      country_of_residence: { type: "string" },
                      bio: { type: "string", description: "A brief professional summary or objective from the resume" },
                    },
                    required: ["full_name"],
                  },
                  education: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        degree_level: { type: "string", description: "e.g. Bachelor's, Master's, PhD, High School" },
                        institution: { type: "string" },
                        field_of_study: { type: "string" },
                        gpa: { type: "string" },
                        gpa_scale: { type: "string", description: "e.g. 4.0, 5.0, 7.0, 10.0" },
                        start_date: { type: "string", description: "YYYY-MM-DD format if available" },
                        end_date: { type: "string", description: "YYYY-MM-DD format if available" },
                        is_current: { type: "boolean" },
                      },
                      required: ["degree_level", "institution"],
                    },
                  },
                  test_scores: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        test_type: { type: "string", description: "e.g. IELTS, TOEFL, GRE, SAT, GMAT" },
                        score: { type: "string" },
                        max_score: { type: "string" },
                        date_taken: { type: "string", description: "YYYY-MM-DD format if available" },
                      },
                      required: ["test_type", "score"],
                    },
                  },
                  research: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        title: { type: "string" },
                        organization: { type: "string" },
                        description: { type: "string" },
                        start_date: { type: "string" },
                        end_date: { type: "string" },
                        publications: { type: "array", items: { type: "string" } },
                      },
                      required: ["title"],
                    },
                  },
                  extracurriculars: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        category: { type: "string", enum: ["award", "leadership", "volunteering", "other"] },
                        title: { type: "string" },
                        organization: { type: "string" },
                        description: { type: "string" },
                        date: { type: "string" },
                      },
                      required: ["category", "title"],
                    },
                  },
                },
                required: ["personal_info"],
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "extract_profile" } },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("AI error:", response.status, errText);
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited, please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      return new Response(JSON.stringify({ error: "Failed to parse resume" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const aiResult = await response.json();
    const toolCall = aiResult.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall?.function?.arguments) {
      console.error("No tool call in AI response:", JSON.stringify(aiResult));
      return new Response(JSON.stringify({ error: "AI could not parse the resume" }), {
        status: 422, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const extracted = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(extracted), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("parse-resume error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
