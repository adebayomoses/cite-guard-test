import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Web Push crypto helpers using Web Crypto API
async function generatePushPayload(
  subscription: { endpoint: string; p256dh: string; auth: string },
  payload: string,
  vapidKeys: { publicKey: string; privateKey: string; subject: string }
) {
  // We'll use a simpler approach: send via fetch with the web push protocol
  // For Deno edge functions, we implement the raw Web Push protocol

  const encoder = new TextEncoder();

  // Import the subscription's p256dh key
  const p256dhRaw = base64UrlDecode(subscription.p256dh);
  const authSecret = base64UrlDecode(subscription.auth);

  // Generate a local ECDH key pair
  const localKeyPair = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveBits"]
  );

  // Import the subscription public key
  const subscriptionPublicKey = await crypto.subtle.importKey(
    "raw",
    p256dhRaw as BufferSource,
    { name: "ECDH", namedCurve: "P-256" },
    false,
    []
  );

  // Derive shared secret
  const sharedSecret = await crypto.subtle.deriveBits(
    { name: "ECDH", public: subscriptionPublicKey },
    localKeyPair.privateKey,
    256
  );

  // Export local public key
  const localPublicKeyRaw = await crypto.subtle.exportKey("raw", localKeyPair.publicKey);

  // Create the encryption info
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const payloadBytes = encoder.encode(payload);

  // Key derivation using HKDF
  const authInfo = encoder.encode("Content-Encoding: auth\0");
  const prkeyMaterial = await crypto.subtle.importKey(
    "raw",
    sharedSecret,
    { name: "HKDF" },
    false,
    ["deriveBits", "deriveKey"]
  );

  // IKM = HKDF(auth_secret, ecdh_secret, "Content-Encoding: auth\0", 32)
  const authKeyMaterial = await crypto.subtle.importKey(
    "raw",
    authSecret as BufferSource,
    { name: "HKDF" },
    false,
    ["deriveBits"]
  );

  // PRK = HMAC-SHA-256(auth_secret, shared_secret)
  const prkKey = await crypto.subtle.importKey(
    "raw",
    authSecret as BufferSource,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const prk = await crypto.subtle.sign("HMAC", prkKey, sharedSecret);

  // Derive content encryption key and nonce
  const context = createContext(new Uint8Array(p256dhRaw), new Uint8Array(localPublicKeyRaw));
  const contentEncryptionKeyInfo = createInfo(encoder.encode("Content-Encoding: aesgcm\0"), context);
  const nonceInfo = createInfo(encoder.encode("Content-Encoding: nonce\0"), context);

  const prkImport = await crypto.subtle.importKey("raw", prk, { name: "HKDF" }, false, [
    "deriveBits",
  ]);

  const cekBits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: salt as BufferSource, info: contentEncryptionKeyInfo as BufferSource },
    prkImport,
    128
  );
  const nonceBits = await crypto.subtle.deriveBits(
    { name: "HKDF", hash: "SHA-256", salt: salt as BufferSource, info: nonceInfo as BufferSource },
    prkImport,
    96
  );

  // Add padding
  const paddingLength = 0;
  const paddedPayload = new Uint8Array(2 + paddingLength + payloadBytes.length);
  paddedPayload[0] = (paddingLength >> 8) & 0xff;
  paddedPayload[1] = paddingLength & 0xff;
  paddedPayload.set(payloadBytes, 2 + paddingLength);

  // Encrypt
  const cek = await crypto.subtle.importKey("raw", cekBits, { name: "AES-GCM" }, false, [
    "encrypt",
  ]);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonceBits, tagLength: 128 },
    cek,
    paddedPayload
  );

  // Create VAPID JWT
  const jwt = await createVapidJwt(subscription.endpoint, vapidKeys);

  return {
    body: new Uint8Array(encrypted),
    headers: {
      Authorization: `WebPush ${jwt}`,
      "Crypto-Key": `dh=${base64UrlEncode(new Uint8Array(localPublicKeyRaw))};p256ecdsa=${vapidKeys.publicKey}`,
      Encryption: `salt=${base64UrlEncode(salt)}`,
      "Content-Encoding": "aesgcm",
      "Content-Type": "application/octet-stream",
      TTL: "86400",
    },
  };
}

function createContext(clientPublicKey: Uint8Array, serverPublicKey: Uint8Array): Uint8Array {
  const label = new TextEncoder().encode("P-256\0");
  const context = new Uint8Array(label.length + 1 + 2 + clientPublicKey.length + 2 + serverPublicKey.length);
  let offset = 0;
  context.set(label, offset);
  offset += label.length;
  context[offset++] = 0;
  context[offset++] = clientPublicKey.length;
  context.set(clientPublicKey, offset);
  offset += clientPublicKey.length;
  context[offset++] = 0;
  context[offset++] = serverPublicKey.length;
  context.set(serverPublicKey, offset);
  return context;
}

function createInfo(encoding: Uint8Array, context: Uint8Array): Uint8Array {
  const info = new Uint8Array(encoding.length + context.length);
  info.set(encoding, 0);
  info.set(context, encoding.length);
  return info;
}

async function createVapidJwt(
  endpoint: string,
  vapidKeys: { publicKey: string; privateKey: string; subject: string }
): Promise<string> {
  const url = new URL(endpoint);
  const audience = `${url.protocol}//${url.host}`;
  const exp = Math.floor(Date.now() / 1000) + 12 * 60 * 60;

  const header = { typ: "JWT", alg: "ES256" };
  const payload = { aud: audience, exp, sub: vapidKeys.subject };

  const headerB64 = base64UrlEncode(new TextEncoder().encode(JSON.stringify(header)));
  const payloadB64 = base64UrlEncode(new TextEncoder().encode(JSON.stringify(payload)));
  const unsignedToken = `${headerB64}.${payloadB64}`;

  // Import private key
  const privateKeyBytes = base64UrlDecode(vapidKeys.privateKey);
  const jwk = {
    kty: "EC",
    crv: "P-256",
    d: vapidKeys.privateKey,
    x: "",
    y: "",
  };

  // Decode public key to get x and y
  const publicKeyBytes = base64UrlDecode(vapidKeys.publicKey);
  // Public key is 65 bytes: 0x04 || x (32 bytes) || y (32 bytes)
  const x = base64UrlEncode(publicKeyBytes.slice(1, 33));
  const y = base64UrlEncode(publicKeyBytes.slice(33, 65));
  jwk.x = x;
  jwk.y = y;

  const key = await crypto.subtle.importKey(
    "jwk",
    jwk,
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    key,
    new TextEncoder().encode(unsignedToken)
  );

  // Convert DER signature to raw r||s format if needed
  const sigBytes = new Uint8Array(signature);
  let rawSig: Uint8Array;
  if (sigBytes.length === 64) {
    rawSig = sigBytes;
  } else {
    // DER decode
    rawSig = derToRaw(sigBytes);
  }

  return `${unsignedToken}.${base64UrlEncode(rawSig)}`;
}

function derToRaw(der: Uint8Array): Uint8Array {
  const raw = new Uint8Array(64);
  // DER: 0x30 len 0x02 rLen r 0x02 sLen s
  let offset = 2; // skip 0x30 and total length
  offset++; // skip 0x02
  const rLen = der[offset++];
  const rStart = rLen > 32 ? offset + (rLen - 32) : offset;
  const rDest = rLen < 32 ? 32 - rLen : 0;
  raw.set(der.slice(rStart, offset + rLen), rDest);
  offset += rLen;
  offset++; // skip 0x02
  const sLen = der[offset++];
  const sStart = sLen > 32 ? offset + (sLen - 32) : offset;
  const sDest = sLen < 32 ? 64 - sLen : 32;
  raw.set(der.slice(sStart, offset + sLen), sDest);
  return raw;
}

function base64UrlEncode(bytes: Uint8Array): string {
  const binString = Array.from(bytes, (b) => String.fromCharCode(b)).join("");
  return btoa(binString).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlDecode(str: string): Uint8Array {
  const padding = "=".repeat((4 - (str.length % 4)) % 4);
  const base64 = (str + padding).replace(/-/g, "+").replace(/_/g, "/");
  const binString = atob(base64);
  return Uint8Array.from(binString, (c) => c.charCodeAt(0));
}

// ===== FCM HTTP v1 helpers =====
let _fcmTokenCache: { token: string; expiresAt: number } | null = null;

function parseServiceAccount(): { client_email: string; private_key: string; project_id: string } | null {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT_JSON");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error("Failed to parse FCM_SERVICE_ACCOUNT_JSON:", e);
    return null;
  }
}

async function getFcmProjectId(): Promise<string | null> {
  const sa = parseServiceAccount();
  return sa?.project_id ?? null;
}

async function importPkcs8(pem: string): Promise<CryptoKey> {
  const cleaned = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\\n/g, "")
    .replace(/\s+/g, "");
  const der = Uint8Array.from(atob(cleaned), (c) => c.charCodeAt(0));
  return await crypto.subtle.importKey(
    "pkcs8",
    der as BufferSource,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );
}

async function getFcmAccessToken(): Promise<string | null> {
  if (_fcmTokenCache && _fcmTokenCache.expiresAt > Date.now() + 60_000) {
    return _fcmTokenCache.token;
  }
  const sa = parseServiceAccount();
  if (!sa) return null;
  try {
    const header = { alg: "RS256", typ: "JWT" };
    const now = Math.floor(Date.now() / 1000);
    const payload = {
      iss: sa.client_email,
      scope: "https://www.googleapis.com/auth/firebase.messaging",
      aud: "https://oauth2.googleapis.com/token",
      iat: now,
      exp: now + 3600,
    };
    const enc = new TextEncoder();
    const headerB64 = base64UrlEncode(enc.encode(JSON.stringify(header)));
    const payloadB64 = base64UrlEncode(enc.encode(JSON.stringify(payload)));
    const unsigned = `${headerB64}.${payloadB64}`;
    const key = await importPkcs8(sa.private_key);
    const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(unsigned));
    const jwt = `${unsigned}.${base64UrlEncode(new Uint8Array(sig))}`;

    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: jwt,
      }),
    });
    if (!res.ok) {
      console.error("FCM OAuth token error:", res.status, await res.text());
      return null;
    }
    const json = await res.json();
    _fcmTokenCache = {
      token: json.access_token,
      expiresAt: Date.now() + (json.expires_in ?? 3600) * 1000,
    };
    return _fcmTokenCache.token;
  } catch (e) {
    console.error("getFcmAccessToken failed:", e);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();

    // Public endpoint to get VAPID public key
    if (body.action === "get-vapid-key") {
      const vapidPublicKey = Deno.env.get("VAPID_PUBLIC_KEY");
      return new Response(JSON.stringify({ vapidPublicKey }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // All other actions require admin auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = claimsData.claims.sub;

    // Use service role client for reading all subscriptions
    const adminClient = createClient(supabaseUrl, serviceRoleKey);

    // ===== Chat-triggered notifications (DM / group) =====
    // Allows any authenticated user to notify chat recipients without admin role.
    // Derives title/body/url/user_ids server-side from the chat context.
    if (body.action === "chat-dm" || body.action === "chat-room") {
      const senderName: string = (body.sender_name || "Someone").toString().slice(0, 80);
      const preview: string = (body.content_preview || "").toString().slice(0, 140);

      if (body.action === "chat-dm") {
        const receiverId = body.receiver_id;
        if (!receiverId || typeof receiverId !== "string" || receiverId === userId) {
          return new Response(JSON.stringify({ error: "Invalid receiver_id" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        body.title = `${senderName}`;
        body.body = preview || "Sent you a message";
        body.url = `/community?dm=${userId}`;
        body.user_ids = [receiverId];
      } else {
        const roomId = body.room_id;
        const roomName: string = (body.room_name || "Group chat").toString().slice(0, 80);
        if (!roomId || typeof roomId !== "string") {
          return new Response(JSON.stringify({ error: "Invalid room_id" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        // Recipients = ALL users (group chat is open to everyone), excluding sender
        const { data: allProfiles } = await adminClient
          .from("profiles")
          .select("user_id");
        const recipientIds = Array.from(
          new Set(
            (allProfiles ?? [])
              .map((p: { user_id: string }) => p.user_id)
              .filter((id) => id && id !== userId)
          )
        );
        if (recipientIds.length === 0) {
          return new Response(
            JSON.stringify({ sent: 0, failed: 0, total: 0, nativeSent: 0, nativeFailed: 0, skipped: true }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        body.title = roomName;
        body.body = `${senderName}: ${preview}`.slice(0, 180);
        body.url = `/community?room=${roomId}`;
        body.user_ids = recipientIds;
      }
      body.broadcast = false;
    }

    const { title, body: notifBody, url, user_ids, broadcast } = body;

    // Authorization: only admins can broadcast or target other users.
    // Chat-triggered notifications validated above are exempt.
    const isChatNotify = body.action === "chat-dm" || body.action === "chat-room";
    const wantsBroadcast = !!broadcast;
    const wantsOtherUsers = Array.isArray(user_ids) && user_ids.some((uid: string) => uid !== userId);
    if (!isChatNotify && (wantsBroadcast || wantsOtherUsers)) {
      const { data: isAdmin } = await adminClient.rpc("has_role", { _user_id: userId, _role: "admin" });
      if (!isAdmin) {
        return new Response(JSON.stringify({ error: "Forbidden" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }


    if (!title) {
      return new Response(JSON.stringify({ error: "title is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Also insert in-app notification (broadcast = null user_id, targeted = specific user_id)
    // Skip when caller indicates the in-app row was already created (e.g. by a DB trigger).
    const skipInApp = body.skip_inapp === true;
    if (!skipInApp) {
      if (broadcast) {
        await adminClient.from("notifications").insert({
          user_id: null,
          title,
          body: notifBody || null,
          url: url || "/",
        });
      } else if (user_ids && user_ids.length > 0) {
        await adminClient.from("notifications").insert(
          user_ids.map((uid: string) => ({
            user_id: uid,
            title,
            body: notifBody || null,
            url: url || "/",
          }))
        );
      } else {
        // Test mode - insert for the caller
        await adminClient.from("notifications").insert({
          user_id: userId,
          title,
          body: notifBody || null,
          url: url || "/",
        });
      }
    }

    // Fetch subscriptions
    let query = adminClient.from("push_subscriptions").select("*");
    if (user_ids && Array.isArray(user_ids) && user_ids.length > 0) {
      query = query.in("user_id", user_ids);
    }
    // If not broadcast and no user_ids, just send to the caller (test mode)
    if (!broadcast && (!user_ids || user_ids.length === 0)) {
      query = query.eq("user_id", userId);
    }

    const { data: subscriptions, error: subError } = await query;
    if (subError) throw subError;

    const safeSubs = subscriptions ?? [];

    const vapidPublicKey = Deno.env.get("VAPID_PUBLIC_KEY")!;
    const vapidPrivateKey = Deno.env.get("VAPID_PRIVATE_KEY")!;
    const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@brimsom.com";

    const payloadString = JSON.stringify({
      title,
      body: notifBody || "",
      url: url || "/",
    });

    let sent = 0;
    let failed = 0;

    for (const sub of safeSubs) {
      try {
        const pushData = await generatePushPayload(
          { endpoint: sub.endpoint, p256dh: sub.p256dh, auth: sub.auth },
          payloadString,
          { publicKey: vapidPublicKey, privateKey: vapidPrivateKey, subject: vapidSubject }
        );

        const response = await fetch(sub.endpoint, {
          method: "POST",
          headers: pushData.headers,
          body: pushData.body,
        });

        if (response.status === 201 || response.status === 200) {
          sent++;
        } else if (response.status === 410 || response.status === 404) {
          // Subscription expired, remove it
          await adminClient.from("push_subscriptions").delete().eq("id", sub.id);
          failed++;
        } else {
          const text = await response.text();
          console.error(`Push failed for ${sub.id}: ${response.status} ${text}`);
          failed++;
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        console.error(`Push error for ${sub.id}:`, msg);
        // Subscription has corrupted/invalid keys – purge it so it stops failing forever
        if (/invalid P-256|InvalidAccessError|OperationError|DataError/i.test(msg)) {
          await adminClient.from("push_subscriptions").delete().eq("id", sub.id);
        }
        failed++;
      }
    }

    // ===== Native FCM fan-out (Android + iOS via Capacitor PushNotifications) =====
    let nativeSent = 0;
    let nativeFailed = 0;
    try {
      let tokenQuery = adminClient.from("device_tokens").select("*");
      if (user_ids && Array.isArray(user_ids) && user_ids.length > 0) {
        tokenQuery = tokenQuery.in("user_id", user_ids);
      } else if (!broadcast) {
        tokenQuery = tokenQuery.eq("user_id", userId);
      }
      const { data: deviceTokens } = await tokenQuery;

      if (deviceTokens && deviceTokens.length > 0) {
        const accessToken = await getFcmAccessToken();
        const projectId = await getFcmProjectId();
        if (accessToken && projectId) {
          for (const dt of deviceTokens) {
            try {
              const fcmRes = await fetch(
                `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`,
                {
                  method: "POST",
                  headers: {
                    Authorization: `Bearer ${accessToken}`,
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    message: {
                      token: dt.token,
                      notification: { title, body: notifBody || "" },
                      data: { url: url || "/" },
                      android: { priority: "HIGH", notification: { sound: "default", channel_id: "brimsom_default" } },
                      apns: {
                        payload: { aps: { sound: "default", badge: 1 } },
                      },
                    },
                  }),
                }
              );
              if (fcmRes.ok) {
                nativeSent++;
              } else {
                const txt = await fcmRes.text();
                console.error(`FCM failed for ${dt.id}: ${fcmRes.status} ${txt}`);
                nativeFailed++;
                // Remove invalid/unregistered tokens
                if (fcmRes.status === 404 || /UNREGISTERED|INVALID_ARGUMENT/i.test(txt)) {
                  await adminClient.from("device_tokens").delete().eq("id", dt.id);
                }
              }
            } catch (e) {
              console.error(`FCM error for ${dt.id}:`, e);
              nativeFailed++;
            }
          }
        } else {
          console.warn("FCM not configured (missing FCM_SERVICE_ACCOUNT_JSON)");
        }
      }
    } catch (e) {
      console.error("FCM fan-out error:", e);
    }

    return new Response(
      JSON.stringify({
        sent,
        failed,
        total: safeSubs.length,
        nativeSent,
        nativeFailed,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    console.error("Edge function error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
