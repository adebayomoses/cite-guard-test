import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SERVICE_LABELS: Record<string, string> = {
  sop: "Statement of Purpose",
  cv: "Academic CV",
  personal_statement: "Personal Statement",
  research_proposal: "Research Proposal",
  motivation_letter: "Motivation Letter",
  full_package: "Full Application Package",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);
    const token = authHeader.replace("Bearer ", "");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

    const { data: claimsData, error: claimsErr } = await admin.auth.getClaims(token);
    if (claimsErr || !claimsData?.claims?.sub) return json({ error: "Unauthorized" }, 401);
    const callerId = claimsData.claims.sub as string;

    // Only admins / moderators may trigger feedback emails
    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: callerId, _role: "admin" });
    const { data: isMod } = await admin.rpc("has_role", { _user_id: callerId, _role: "moderator" });
    if (!isAdmin && !isMod) return json({ error: "Forbidden" }, 403);

    const body = await req.json().catch(() => ({}));
    const submissionId = body?.submissionId;
    if (!submissionId || typeof submissionId !== "string") {
      return json({ error: "submissionId is required" }, 400);
    }

    const { data: submission, error: subErr } = await admin
      .from("document_submissions")
      .select("id, user_id, service_type, file_name, status, admin_feedback, reviewed_at")
      .eq("id", submissionId)
      .maybeSingle();
    if (subErr || !submission) return json({ error: "Submission not found" }, 404);

    const { data: userRes, error: userErr } = await admin.auth.admin.getUserById(submission.user_id);
    const recipientEmail = userRes?.user?.email;
    if (userErr || !recipientEmail) return json({ error: "Recipient email not found" }, 404);

    const { data: profile } = await admin
      .from("profiles")
      .select("full_name")
      .eq("user_id", submission.user_id)
      .maybeSingle();

    const templateData = {
      name: profile?.full_name?.split(" ")[0] || "there",
      serviceLabel: SERVICE_LABELS[submission.service_type] || submission.service_type,
      fileName: submission.file_name,
      status: submission.status,
      feedback: submission.admin_feedback || "",
    };

    const res = await fetch(`${supabaseUrl}/functions/v1/send-transactional-email`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${serviceKey}`,
        apikey: serviceKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        templateName: "document-review-feedback",
        recipientEmail,
        idempotencyKey: `doc-review-${submission.id}-${submission.status}-${submission.reviewed_at ?? ""}`,
        templateData,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("send-transactional-email failed", res.status, errText);
      return json({ error: "Failed to send email" }, 502);
    }

    return json({ success: true });
  } catch (e) {
    console.error("notify-document-feedback error", e);
    return json({ error: e instanceof Error ? e.message : "Unexpected error" }, 500);
  }
});
