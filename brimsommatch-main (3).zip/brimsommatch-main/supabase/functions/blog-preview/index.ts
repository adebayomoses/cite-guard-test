// Edge function that returns crawler-friendly HTML with per-post Open Graph
// meta tags. Browsers get redirected to the SPA route; social-preview
// crawlers (WhatsApp, LinkedIn, Slack, Facebook, X) read the meta tags.

const SITE_ORIGIN = "https://brimsom.io";

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const slug = url.searchParams.get("slug");

  if (!slug) {
    return new Response("Missing slug parameter", { status: 400 });
  }

  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

  // Fetch the post via PostgREST (no SDK needed)
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/blog_posts?slug=eq.${encodeURIComponent(slug)}&is_published=eq.true&select=title,slug,excerpt,thumbnail_url,published_at&limit=1`,
    { headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` } },
  );

  if (!res.ok) {
    return new Response("Failed to load post", { status: 502 });
  }

  const rows = await res.json();
  const post = Array.isArray(rows) && rows.length ? rows[0] : null;

  const canonical = `${SITE_ORIGIN}/blog/${slug}`;
  const title = escapeHtml(post?.title ?? "Brimsom Blog");
  const description = escapeHtml(
    post?.excerpt ?? "Tips, guides, and scholarship insights from Brimsom.",
  );
  const image = post?.thumbnail_url
    ? escapeHtml(post.thumbnail_url)
    : "https://storage.googleapis.com/gpt-engineer-file-uploads/VYKbEavl6Sb31c3Li7MreWlsLs13/social-images/social-1773009325951-Screenshot_2026-03-08_233509.webp";

  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>${title}</title>
<meta name="description" content="${description}" />
<link rel="canonical" href="${canonical}" />
<meta property="og:type" content="article" />
<meta property="og:title" content="${title}" />
<meta property="og:description" content="${description}" />
<meta property="og:image" content="${image}" />
<meta property="og:url" content="${canonical}" />
<meta property="og:site_name" content="Brimsom" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${title}" />
<meta name="twitter:description" content="${description}" />
<meta name="twitter:image" content="${image}" />
<meta http-equiv="refresh" content="0; url=${canonical}" />
<script>window.location.replace(${JSON.stringify(canonical)});</script>
</head>
<body>
<p>Redirecting to <a href="${canonical}">${title}</a>…</p>
</body>
</html>`;

  return new Response(html, {
    status: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300, s-maxage=600",
    },
  });
});
