import { sendLovableEmail } from 'npm:@lovable.dev/email-js'
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface MatchEntry {
  scholarship_id: string
  score?: number
  match_score?: number
  chance?: number
  chance_score?: number
  reason?: string
}

interface ScholarshipRow {
  id: string
  title: string
  country: string | null
  next_close_date: string | null
  funding_amount: string | null
  funding_type: string | null
  degree_level: string | null
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

  const apiKey = Deno.env.get('LOVABLE_API_KEY')!
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const supabase = createClient(supabaseUrl, serviceKey)

  // Auth: allow service-role (pg_cron) OR admin user
  const authHeader = req.headers.get('Authorization') ?? ''
  const token = authHeader.replace(/^Bearer\s+/i, '')
  if (!token) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
  let jwtRole: string | undefined
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))
    jwtRole = payload?.role
  } catch { /* not a JWT */ }
  if (token !== serviceKey && jwtRole !== 'service_role') {
    const { data: claimsData, error: claimsErr } = await supabase.auth.getClaims(token)
    const callerId = claimsData?.claims?.sub
    if (claimsErr || !callerId) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
    const { data: isAdmin } = await supabase.rpc('has_role', { _user_id: callerId, _role: 'admin' })
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
  }

  // Optional test mode: { test: true, testEmail?: string } — targets a single
  // recipient and appends a timestamp to the idempotency key so the send is
  // never deduped against the scheduled weekly send.
  let testMode = false
  let testEmail: string | null = null
  try {
    if (req.method === 'POST') {
      const body = await req.json().catch(() => ({}))
      if (body?.test) {
        testMode = true
        testEmail = typeof body.testEmail === 'string' ? body.testEmail.toLowerCase() : null
      }
    }
  } catch { /* ignore */ }

  const todayStr = new Date().toISOString().split('T')[0]
  const now = Date.now()

  // 1. Users opted in
  const { data: prefs, error: prefErr } = await supabase
    .from('email_preferences')
    .select('user_id')
    .eq('weekly_focus_enabled', true)
  if (prefErr) {
    console.error('prefs error', prefErr)
    return new Response(JSON.stringify({ error: 'prefs' }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  }
  if (!prefs?.length) {
    return new Response(JSON.stringify({ skipped: true, reason: 'no_opted_in_users' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  }

  let userIds = prefs.map((p: { user_id: string }) => p.user_id)

  // 2. Fetch each user's latest score_results row (has scholarship_matches jsonb)
  const { data: scoreRows } = await supabase
    .from('score_results')
    .select('user_id, scholarship_matches, created_at')
    .in('user_id', userIds)
    .order('created_at', { ascending: false })

  const latestScoreByUser = new Map<string, MatchEntry[]>()
  for (const row of scoreRows || []) {
    if (!latestScoreByUser.has(row.user_id)) {
      const matches = Array.isArray(row.scholarship_matches) ? row.scholarship_matches as MatchEntry[] : []
      latestScoreByUser.set(row.user_id, matches)
    }
  }

  // 3. Profiles + emails
  const { data: profiles } = await supabase.from('profiles').select('user_id, full_name').in('user_id', userIds)
  const profileMap = new Map((profiles || []).map((p: any) => [p.user_id, p.full_name]))
  const { data: authData } = await supabase.auth.admin.listUsers({ perPage: 1000 })
  const emailMap = new Map((authData?.users || []).map((u: any) => [u.id, u.email]))

  // Narrow to the test recipient if test mode is on
  if (testMode && testEmail) {
    const targetId = (authData?.users || []).find((u: any) => (u.email || '').toLowerCase() === testEmail)?.id
    userIds = targetId ? [targetId] : []
    if (!userIds.length) {
      return new Response(JSON.stringify({ error: 'test recipient not found or not opted in' }), {
        status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
  }

  // 4. Suppressed
  const { data: suppressed } = await supabase.from('suppressed_emails').select('email')
  const suppressedSet = new Set((suppressed || []).map((s: any) => s.email.toLowerCase()))

  // 5. Match threshold from site_settings (default 70)
  const { data: threshSetting } = await supabase.from('site_settings').select('value').eq('key', 'match_threshold').maybeSingle()
  const matchThreshold = Number(threshSetting?.value ?? 70)

  // Generic fallback pool: soonest-closing active scholarships (for users with no scores)
  const { data: genericSchols } = await supabase
    .from('scholarships')
    .select('id, title, country, next_close_date, funding_amount, funding_type, degree_level')
    .eq('is_active', true)
    .gte('next_close_date', todayStr)
    .order('next_close_date', { ascending: true })
    .limit(5)
  const genericTop5: ScholarshipRow[] = (genericSchols || []) as ScholarshipRow[]

  let sent = 0, skipped = 0, failed = 0, sentGeneric = 0

  for (const userId of userIds) {
    const email = emailMap.get(userId)
    if (!email || suppressedSet.has(email.toLowerCase())) { skipped++; continue }

    const matches = latestScoreByUser.get(userId) || []
    const scholarshipIds = matches.map((m) => m.scholarship_id).filter(Boolean)

    let top5: Array<{ s: ScholarshipRow; m: MatchEntry; weighted: number }> = []
    if (scholarshipIds.length) {
      const { data: schols } = await supabase
        .from('scholarships')
        .select('id, title, country, next_close_date, funding_amount, funding_type, degree_level')
        .in('id', scholarshipIds)
        .eq('is_active', true)
      const scholMap = new Map<string, ScholarshipRow>((schols || []).map((s: any) => [s.id, s]))

      const ranked = matches
        .map((m) => {
          const s = scholMap.get(m.scholarship_id)
          if (!s) return null
          if (s.next_close_date && s.next_close_date < todayStr) return null
          const baseScore = m.score ?? m.match_score ?? 0
          if (baseScore < matchThreshold) return null
          let urgency = 0
          if (s.next_close_date) {
            const daysLeft = Math.max(0, Math.floor((new Date(s.next_close_date).getTime() - now) / 86400000))
            if (daysLeft <= 30) urgency = 15 - Math.floor(daysLeft / 2)
          }
          return { s, m, weighted: baseScore + urgency }
        })
        .filter(Boolean) as Array<{ s: ScholarshipRow; m: MatchEntry; weighted: number }>

      ranked.sort((a, b) => b.weighted - a.weighted)
      top5 = ranked.slice(0, 5)
    }

    // Fallback to generic if no personalized picks
    const isGeneric = top5.length === 0
    if (isGeneric) {
      if (!genericTop5.length) { skipped++; continue }
      top5 = genericTop5.map((s) => ({ s, m: {} as MatchEntry, weighted: 0 }))
    }

    const name = profileMap.get(userId) || 'there'
    const firstName = typeof name === 'string' ? name.split(' ')[0] : 'there'
    const weekKey = new Date().toISOString().split('T')[0]
    const idempotencyKey = testMode
      ? `weekly-focus-test-${userId}-${Date.now()}`
      : `weekly-focus-${userId}-${weekKey}`

    // unsubscribe token
    let unsubscribeToken = ''
    const { data: existingToken } = await supabase
      .from('email_unsubscribe_tokens').select('token').eq('email', email.toLowerCase()).maybeSingle()
    if (existingToken?.token) unsubscribeToken = existingToken.token
    else {
      const newToken = crypto.randomUUID()
      await supabase.from('email_unsubscribe_tokens').insert({ email: email.toLowerCase(), token: newToken })
      unsubscribeToken = newToken
    }

    const rows = top5.map(({ s, m }) => {
      const deadline = s.next_close_date
        ? new Date(s.next_close_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
        : 'Rolling'
      const daysLeft = s.next_close_date
        ? Math.max(0, Math.floor((new Date(s.next_close_date).getTime() - now) / 86400000))
        : null
      const urgencyBadge = daysLeft !== null && daysLeft <= 14
        ? `<span style="display:inline-block;background:#fee2e2;color:#b91c1c;padding:2px 8px;border-radius:9999px;font-size:11px;font-weight:600;margin-left:6px;">⏰ ${daysLeft}d left</span>`
        : ''
      const funding = [s.funding_type, s.funding_amount].filter(Boolean).join(' — ') || 'See details'
      const tags = [s.country, s.degree_level].filter(Boolean).join(' · ')
      const reason = m.reason ? String(m.reason).slice(0, 140) : ''
      const displayScore = m.score ?? m.match_score
      const scoreBadge = displayScore
        ? `<span style="display:inline-block;background:#dcfce7;color:#166534;padding:2px 8px;border-radius:9999px;font-size:11px;font-weight:700;">${Math.round(displayScore)}% match</span>`
        : ''
      return `
      <tr>
        <td style="padding:18px;border-bottom:1px solid #e5e7eb;">
          <div style="margin-bottom:6px;">${scoreBadge}${urgencyBadge}</div>
          <div style="font-weight:600;font-size:16px;color:#111827;margin-bottom:4px;">${s.title}</div>
          <div style="font-size:13px;color:#6b7280;margin-bottom:6px;">${tags}</div>
          <div style="font-size:13px;color:#374151;margin-bottom:${reason ? '8px' : '0'};">💰 ${funding} &nbsp; 📅 ${deadline}</div>
          ${reason ? `<div style="font-size:12px;color:#4b5563;font-style:italic;border-left:3px solid #10b981;padding-left:8px;margin-top:6px;">Why this match: ${reason}</div>` : ''}
          <div style="margin-top:10px;"><a href="https://brimsommatch.lovable.app/scholarships/${s.id}" style="display:inline-block;padding:8px 16px;background:#10b981;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:13px;">View & Apply →</a></div>
        </td>
      </tr>`
    }).join('')

    const genericNudgeHtml = isGeneric ? `
      <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:10px;padding:16px;margin-bottom:20px;text-align:center;">
        <div style="font-weight:600;font-size:15px;color:#92400e;margin-bottom:6px;">✨ Want scholarships picked just for you?</div>
        <div style="font-size:13px;color:#78350f;margin-bottom:12px;">These are this week's soonest-closing scholarships. Generate your match scores to get a personalized weekly 5 tailored to your profile.</div>
        <a href="https://brimsommatch.lovable.app/dashboard" style="display:inline-block;padding:10px 20px;background:#f59e0b;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:13px;">Generate my scores →</a>
      </div>` : ''

    const headerSub = isGeneric
      ? `Hi ${firstName}, here are 5 scholarships closing soon. Personalize your weekly picks by generating your match scores.`
      : `Hi ${firstName}, out of all your matches these are the five worth focusing on right now — ranked by fit and closing urgency.`
    const subject = isGeneric
      ? `5 scholarships closing soon, ${firstName} ⏰`
      : `Your 5 for this week, ${firstName} 🎯`
    const headline = isGeneric ? '⏰ Closing soon this week' : '🎯 Your 5 for this week'

    const plainText = `Hi ${firstName},\n\n${isGeneric ? 'Here are 5 scholarships closing soon. Generate your match scores at https://brimsommatch.lovable.app/dashboard to get personalized picks next week.' : 'Your 5 for this week — hand-picked from your matches, ranked by fit and urgency:'}\n\n${top5.map((t, i) => {
      const d = t.s.next_close_date ? new Date(t.s.next_close_date).toLocaleDateString() : 'Rolling'
      const scorePart = (t.m.score ?? t.m.match_score) ? ` — ${Math.round((t.m.score ?? t.m.match_score) as number)}% match` : ''
      return `${i + 1}. ${t.s.title}${scorePart} — deadline ${d}\n   https://brimsommatch.lovable.app/scholarships/${t.s.id}`
    }).join('\n\n')}\n\nSee all scholarships: https://brimsommatch.lovable.app/scholarships\n\n— Brimsom`

    const html = `
<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#ffffff;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <div style="max-width:620px;margin:0 auto;padding:32px 16px;">
    <div style="text-align:center;margin-bottom:28px;">
      <h1 style="font-size:26px;font-weight:700;color:#111827;margin:0;">${headline}</h1>
      <p style="font-size:15px;color:#6b7280;margin-top:8px;">${headerSub}</p>
    </div>
    ${genericNudgeHtml}
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border-radius:12px;overflow:hidden;">
      ${rows}
    </table>
    <div style="text-align:center;margin-top:28px;">
      <a href="https://brimsommatch.lovable.app/${isGeneric ? 'dashboard' : 'scholarships?tab=foryou'}" style="display:inline-block;padding:14px 32px;background:#111827;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;font-size:15px;">${isGeneric ? 'Generate my match scores' : 'See all my matches'}</a>
    </div>
    <p style="text-align:center;font-size:13px;color:#6b7280;margin-top:20px;">Focus on 1–2 this week. Applying to fewer, better-fit scholarships beats spraying applications.</p>
    <hr style="border:none;border-top:1px solid #e5e7eb;margin:32px 0 16px;" />
    <p style="text-align:center;font-size:11px;color:#9ca3af;">You're receiving Your 5 because Weekly Focus is on in Brimsom email settings.</p>
  </div>
</body></html>`

    try {
      await sendLovableEmail(
        {
          to: email,
          from: 'Brimsom <noreply@notify.brimsom.com>',
          sender_domain: 'notify.brimsom.com',
          subject,
          html,
          text: plainText,
          purpose: 'transactional',
          label: 'weekly_focus',
          idempotency_key: idempotencyKey,
          unsubscribe_token: unsubscribeToken,
        },
        { apiKey, sendUrl: Deno.env.get('LOVABLE_SEND_URL') }
      )
      await supabase.from('email_send_log').insert({
        message_id: idempotencyKey, template_name: isGeneric ? 'weekly_focus_generic' : 'weekly_focus', recipient_email: email, status: 'sent',
      })
      sent++
      if (isGeneric) sentGeneric++
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      console.error('weekly_focus send failed', email, errorMsg)
      await supabase.from('email_send_log').insert({
        message_id: idempotencyKey, template_name: 'weekly_focus', recipient_email: email,
        status: 'failed', error_message: errorMsg.slice(0, 1000),
      })
      failed++
    }

    await new Promise((r) => setTimeout(r, 200))
  }

  console.log(`weekly_focus complete: sent=${sent} generic=${sentGeneric} skipped=${skipped} failed=${failed}`)
  return new Response(JSON.stringify({ sent, sentGeneric, skipped, failed }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
})
