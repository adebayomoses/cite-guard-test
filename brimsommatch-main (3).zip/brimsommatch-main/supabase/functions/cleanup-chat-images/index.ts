import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Restrict to service-role callers (pg_cron / server-side scheduled invocations).
  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace(/^Bearer\s+/i, "");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  if (!token || token !== serviceKey) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      serviceKey
    );


    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

    // Get expired chat_messages with images
    const { data: expiredChat } = await supabase
      .from("chat_messages")
      .select("id, image_url")
      .not("image_url", "is", null)
      .lt("created_at", cutoff);

    // Get expired direct_messages with images
    const { data: expiredDM } = await supabase
      .from("direct_messages")
      .select("id, image_url")
      .not("image_url", "is", null)
      .lt("created_at", cutoff);

    const allExpired = [...(expiredChat ?? []), ...(expiredDM ?? [])];
    let deletedFiles = 0;

    if (allExpired.length > 0) {
      // Extract storage paths from URLs
      const filePaths = allExpired
        .map((m) => {
          try {
            const url = new URL(m.image_url);
            const match = url.pathname.match(
              /\/storage\/v1\/object\/public\/chat-images\/(.+)/
            );
            return match ? match[1] : null;
          } catch {
            return null;
          }
        })
        .filter(Boolean) as string[];

      if (filePaths.length > 0) {
        const { data: removed } = await supabase.storage
          .from("chat-images")
          .remove(filePaths);
        deletedFiles = removed?.length ?? 0;
      }

      // Null out image_url on expired chat messages
      if (expiredChat && expiredChat.length > 0) {
        const ids = expiredChat.map((m) => m.id);
        await supabase
          .from("chat_messages")
          .update({ image_url: null })
          .in("id", ids);
      }

      // Null out image_url on expired direct messages
      if (expiredDM && expiredDM.length > 0) {
        const ids = expiredDM.map((m) => m.id);
        await supabase
          .from("direct_messages")
          .update({ image_url: null })
          .in("id", ids);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        expired: allExpired.length,
        deletedFiles,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
