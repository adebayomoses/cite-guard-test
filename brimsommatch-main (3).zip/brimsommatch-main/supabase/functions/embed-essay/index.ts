// Generates a vector embedding for one or more winning_essays records.
// Uses Google text-embedding-004 via Lovable AI Gateway (768 dims).
// Admin-only: validates the caller is an admin via JWT.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;

async function embed(text: string): Promise<number[]> {
  const trimmed = text.slice(0, 8000); // safety cap
  const res = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "openai/text-embedding-3-small",
      input: trimmed,
      dimensions: 768,
    }),
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Embedding API ${res.status}: ${t}`);
  }
  const json = await res.json();
  const vec = json?.data?.[0]?.embedding;
  if (!Array.isArray(vec)) throw new Error("Embedding response missing vector");
  return vec;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // Auth check
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) {
      return new Response(JSON.stringify({ error: "Missing auth" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data: claims, error: claimsErr } = await userClient.auth.getClaims(token);
    if (claimsErr || !claims?.claims?.sub) {
      return new Response(JSON.stringify({ error: "Invalid auth" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = claims.claims.sub;

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: "Admin only" }), {
        status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const { essay_id, all = false } = body as { essay_id?: string; all?: boolean };

    let query = admin.from("winning_essays").select("id,title,document_type,scholarship_name,country,field_of_study,degree_level,tags,content");
    if (essay_id) {
      query = query.eq("id", essay_id);
    } else if (!all) {
      // default: only rows missing an embedding
      query = query.is("embedding", null);
    }
    const { data: rows, error } = await query;
    if (error) throw error;

    let processed = 0;
    let failed = 0;
    for (const row of rows ?? []) {
      try {
        const text = [
          row.title,
          row.scholarship_name,
          row.country,
          row.field_of_study,
          row.degree_level,
          (row.tags ?? []).join(" "),
          row.content,
        ].filter(Boolean).join("\n");

        const vector = await embed(text);
        const { error: upErr } = await admin
          .from("winning_essays")
          .update({ embedding: vector as unknown as string, embedding_updated_at: new Date().toISOString() })
          .eq("id", row.id);
        if (upErr) throw upErr;
        processed++;
      } catch (e) {
        console.error("Failed to embed essay", row.id, e);
        failed++;
      }
    }

    return new Response(JSON.stringify({ processed, failed, total: rows?.length ?? 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err: any) {
    console.error("embed-essay error:", err);
    return new Response(JSON.stringify({ error: err.message ?? "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
