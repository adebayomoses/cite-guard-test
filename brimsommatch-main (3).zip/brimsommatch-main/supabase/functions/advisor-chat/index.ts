import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const DEGREE_KEYWORDS: Array<{ re: RegExp; token: string }> = [
  { re: /\b(phd|ph\.d|doctora|doctoral)\b/i, token: "phd" },
  { re: /\b(msc|m\.sc|master|masters|graduate|postgrad)\b/i, token: "master" },
  { re: /\b(mba)\b/i, token: "mba" },
  { re: /\b(bsc|b\.sc|bachelor|undergrad|undergraduate)\b/i, token: "bachelor" },
  { re: /\b(diploma)\b/i, token: "diploma" },
  { re: /\b(high\s?school|secondary)\b/i, token: "high school" },
];

function detectDegreeTokens(text: string): string[] {
  const found = new Set<string>();
  for (const { re, token } of DEGREE_KEYWORDS) if (re.test(text)) found.add(token);
  return Array.from(found);
}

const RECOMMEND_INTENT_RE = /\b(recommend|suggest|find|match|matches|matching|eligible|best|top|options|opportunities|what\s+can\s+i\s+apply|scholarships?\s+for\s+me|schools?\s+for\s+me|show\s+me|give\s+me|list)\b/i;

function hasRecommendationIntent(text: string, degreeTokens: string[]): boolean {
  if (RECOMMEND_INTENT_RE.test(text)) return true;
  // Degree token + verb implies recommendation
  if (degreeTokens.length > 0 && /\b(find|get|show|need|want|looking|search)\b/i.test(text)) return true;
  return false;
}

const WRITE_INTENT_RE = /\b(write|draft|compose|generate|create|update|revise|rewrite|improve|polish|expand|tailor|tailored|customize|customise|prepare|produce|finalize|finalise)\b/i;
const DOC_TYPE_RE = /\b(sop|s\.o\.p|statement of purpose|personal statement|motivation(?:al)? letter|motivation(?:al)? essay|essay|cover letter|recommendation letter|letter of recommendation|admission essay|application essay|study plan|research proposal)\b/i;
const ANGLE_SUGGESTION_RE = /\b(craft one(?: for me)?|suggest (?:angles?|one)|give me (?:angles?|options)|angle options?|i don'?t have (?:a )?(?:story|moment)|no story|you suggest|you choose an angle)\b/i;
const ANGLE_PICK_RE = /\b(?:go with|use|choose|pick|select|build (?:it|the essay) around)\s+(?:angle\s*)?(?:#?\d|one|two|three|first|second|third)\b|\b(?:angle\s*)?(?:#?\d|one|two|three|first|second|third)\s+(?:works|is fine|sounds good)\b/i;
const SCHOLARSHIP_INTENT_RE = /\b(scholarships?|funding|funded|grants?|fellowships?|opportunities|matches|matching|eligible|deadline|tuition\s+waivers?|stipends?)\b/i;

function sanitizeLongFormResponse(text: string): string {
  const withoutTokens = text
    .replace(/\[\[scholarship:[a-zA-Z0-9-]+\]\]/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  const withoutScholarshipTail = withoutTokens.replace(
    /(?:^|\n{1,3})(?:#{1,6}\s*)?(?:Strategy for Your Applications|Application Strategy|Scholarship Matches(?:\s+for\s+Your\s+[^\n]+)?|Scholarships?\s+(?:to\s+Fund|for)\s+[^\n]*|Recommended Scholarships?|Funding Opportunities|High-Match Funding Opportunities|Next Scholarship Steps)\b[\s\S]*$/i,
    "",
  ).trim();

  return withoutScholarshipTail || "Want me to tailor this to a specific scholarship? Just share the name.";
}

// Strip forbidden bracketed placeholders inside an essay block. Keep only "⚠️ [INSERT: ...]".
function stripPlaceholders(essayBody: string): string {
  return essayBody
    .replace(/\[([^\]]*)\]/g, (match, inner) => {
      const s = String(inner).trim();
      if (/^INSERT:/i.test(s)) return match; // keep INSERT markers
      // preserve ⚠️ [INSERT ...] variants
      return "";
    })
    .replace(/[ \t]{2,}/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\|\s*\|/g, "|")
    .replace(/^\s*\|\s*/gm, "")
    .replace(/\s*\|\s*$/gm, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// For CV/doc mode: ensure the body is wrapped in a ```essay fenced block.
// If the model already fenced it, sanitize inside. Otherwise auto-detect intro/recap and wrap the middle.
function ensureEssayWrap(text: string): string {
  const fenceRe = /```essay\s*([\s\S]*?)```/i;
  const m = text.match(fenceRe);
  if (m) {
    const cleaned = stripPlaceholders(m[1]);
    return text.replace(fenceRe, "```essay\n" + cleaned + "\n```");
  }
  // Auto-wrap: split on first recap marker (✅ / ⚠️ / ✏️ / **Notes** / **Recap**)
  const lines = text.split("\n");
  // Find intro end: first blank line or first line that looks like a header/name
  let bodyStart = 0;
  for (let i = 0; i < Math.min(lines.length, 4); i++) {
    if (lines[i].trim() === "") { bodyStart = i + 1; break; }
  }
  if (bodyStart === 0) bodyStart = 1;
  // Find recap start
  let recapStart = lines.length;
  for (let i = bodyStart + 3; i < lines.length; i++) {
    if (/^\s*(✅|⚠️|✏️|\*\*Notes|\*\*Recap|Notes:|Recap:)/.test(lines[i])) {
      recapStart = i;
      break;
    }
  }
  const intro = lines.slice(0, bodyStart).join("\n").trim();
  const body = stripPlaceholders(lines.slice(bodyStart, recapStart).join("\n"));
  const recap = lines.slice(recapStart).join("\n").trim();
  return [intro, "```essay\n" + body + "\n```", recap].filter(Boolean).join("\n\n");

function hasRecentLongFormDocContext(messages: any[]): boolean {
  return messages.slice(-8).some((m: any) => {
    const text = String(m?.content ?? "");
    return DOC_TYPE_RE.test(text) || /\bpersonal story|specific moment|sparked your interest|reply with the number \(1, 2, or 3\)|angle\s+\d\b|tailor this to a specific scholarship|short "Notes" section/i.test(text);
  });
}

async function computeHash(data: unknown): Promise<string> {
  const str = JSON.stringify(data, Object.keys(data as Record<string, unknown>).sort());
  const buffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function isProfileSufficient(profile: any, edu: any[], tests: any[], research: any[], extras: any[]): boolean {
  if (!profile?.academic_level) return false;
  if (edu.length === 0) return false;
  if (tests.length === 0 && research.length === 0 && extras.length === 0) return false;
  return true;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!);
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await anonClient.auth.getClaims(token);
    if (claimsError) console.error("getClaims error:", claimsError);
    const userId = claimsData?.claims?.sub;
    if (!userId) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { messages } = await req.json();
    if (!Array.isArray(messages) || messages.length === 0) {
      return new Response(JSON.stringify({ error: "messages required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey);

    const [profileRes, eduRes, testsRes, researchRes, extraRes, scoreRes, essayRes] = await Promise.all([
      admin.from("profiles").select("full_name,nationality,country_of_residence,academic_level,bio,date_of_birth,intended_program,intended_degree_level,intended_field_of_study").eq("user_id", userId).maybeSingle(),
      admin.from("education_history").select("degree_level,institution,field_of_study,gpa,gpa_scale,is_current,start_date,end_date").eq("user_id", userId),
      admin.from("test_scores").select("test_type,score,max_score").eq("user_id", userId),
      admin.from("research_experience").select("title,organization,description").eq("user_id", userId).limit(5),
      admin.from("extracurriculars").select("title,category,organization").eq("user_id", userId).limit(10),
      admin.from("score_results").select("scholarship_matches,readiness_score").eq("user_id", userId).order("created_at", { ascending: false }).limit(1).maybeSingle(),
      admin.from("essay_profiles").select("motivation,project_or_achievement,tools_software,research_interests,career_goals,why_study_abroad,academic_explanations").eq("user_id", userId).maybeSingle(),
    ]);

    const profile = profileRes.data;
    const edu = eduRes.data ?? [];
    const tests = testsRes.data ?? [];
    const research = researchRes.data ?? [];
    const extras = extraRes.data ?? [];
    const essay = essayRes.data as Record<string, string> | null;


    // Build scoreMap: scholarship_id -> { score, chance }
    let matchesArr = (scoreRes.data?.scholarship_matches as any[]) ?? [];
    let scoreMap = new Map<string, { score: number; chance: number }>();
    const rebuildScoreMap = (arr: any[]) => {
      scoreMap = new Map();
      for (const m of arr) {
        if (m?.scholarship_id) scoreMap.set(m.scholarship_id, { score: m.score ?? 0, chance: m.chance ?? 0 });
      }
    };
    rebuildScoreMap(matchesArr);

    // Determine degree intent: latest user message + profile
    const lastUserMsg = [...messages].reverse().find((m: any) => m.role === "user")?.content ?? "";
    const requestedTokens = detectDegreeTokens(String(lastUserMsg));
    const isAngleFlowTurn = hasRecentLongFormDocContext(messages) && (ANGLE_SUGGESTION_RE.test(String(lastUserMsg)) || ANGLE_PICK_RE.test(String(lastUserMsg)));
    const currentEdu = edu.find((e: any) => e.is_current) ?? edu[0];
    const profileDegree = (profile?.academic_level ?? currentEdu?.degree_level ?? "").toString();
    const profileTokens = detectDegreeTokens(profileDegree);
    const allTokens = Array.from(new Set([...requestedTokens, ...profileTokens]));
    const writingLongFormNow = (WRITE_INTENT_RE.test(String(lastUserMsg)) && DOC_TYPE_RE.test(String(lastUserMsg))) || ANGLE_PICK_RE.test(String(lastUserMsg));
    const userAskedMultiple = !isAngleFlowTurn && !writingLongFormNow && (requestedTokens.length >= 2 || /scholarships\b|opportunities\b|options\b|list/i.test(String(lastUserMsg)));

    // ===== AUTO-SCORE TRIGGER =====
    let autoScoreRan = false;
    let profileTooSparse = false;
    const wantsRecommendation = !isAngleFlowTurn && hasRecommendationIntent(String(lastUserMsg), requestedTokens);

    if (wantsRecommendation) {
      if (!isProfileSufficient(profile, edu, tests, research, extras)) {
        profileTooSparse = true;
      } else {
        const { data: usageCount } = await admin.rpc("get_feature_usage_count", {
          _user_id: userId,
          _feature: "score_generation",
          _period: "month",
        });
        const { data: capSetting } = await admin
          .from("site_settings")
          .select("value")
          .eq("key", "advisor_auto_score_cap")
          .maybeSingle();
        const parsedCap = parseInt(capSetting?.value ?? "5", 10);
        const SCORE_USAGE_CAP = isNaN(parsedCap) ? 5 : (parsedCap === 0 ? Infinity : parsedCap);
        if ((usageCount ?? 0) < SCORE_USAGE_CAP) {
          // Compute current hashes (mirror score-profile logic)
          const [sopRes, docsRes, subjectsRes, allScholarshipsRes] = await Promise.all([
            admin.from("sop_entries").select("content").eq("user_id", userId).order("created_at", { ascending: false }).limit(1),
            admin.from("user_documents").select("document_type, file_name").eq("user_id", userId),
            admin.from("high_school_subjects").select("*").eq("user_id", userId),
            admin.from("scholarships").select("*").eq("is_active", true),
          ]);
          const sop = sopRes.data?.[0]?.content ?? "";
          const documents = docsRes.data ?? [];
          const subjects = subjectsRes.data ?? [];
          const allScholarships = allScholarshipsRes.data ?? [];

          const profileDataForHash = {
            profile, education: edu, testScores: tests, research, extracurriculars: extras,
            sop, documents, subjects,
          };
          const currentProfileHash = await computeHash(profileDataForHash);
          const currentScholarshipHash = await computeHash(allScholarships);
          const combinedHash = `${currentProfileHash}|${currentScholarshipHash}`;

          const { data: cachedRow } = await admin
            .from("score_results")
            .select("profile_hash")
            .eq("user_id", userId)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();

          const isStale = !cachedRow || cachedRow.profile_hash !== combinedHash;

          if (isStale) {
            try {
              const scoreResp = await fetch(`${supabaseUrl}/functions/v1/score-profile`, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: authHeader,
                },
                body: JSON.stringify({}),
              });
              if (scoreResp.ok) {
                autoScoreRan = true;
                await admin.from("feature_usage").insert({
                  user_id: userId,
                  feature: "score_generation",
                });
                const { data: freshScore } = await admin
                  .from("score_results")
                  .select("scholarship_matches")
                  .eq("user_id", userId)
                  .order("created_at", { ascending: false })
                  .limit(1)
                  .maybeSingle();
                matchesArr = (freshScore?.scholarship_matches as any[]) ?? [];
                rebuildScoreMap(matchesArr);
              } else {
                console.warn("Auto-score failed:", scoreResp.status);
              }
            } catch (err) {
              console.warn("Auto-score error (non-fatal):", err);
            }
          }
        } else {
          console.log("Auto-score skipped: monthly cap reached for user", userId);
        }
      }
    }
    // ===== END AUTO-SCORE =====

    const today = new Date().toISOString().split("T")[0];
    let schQuery = admin
      .from("scholarships")
      .select("id,title,provider,country,degree_level,field_of_study,funding_amount,funding_type,next_close_date,url,eligibility_criteria")
      .eq("is_active", true)
      .or(`next_close_date.is.null,next_close_date.gte.${today}`)
      .order("created_at", { ascending: false })
      .limit(40);

    if (allTokens.length > 0) {
      const orParts = ["degree_level.is.null", ...allTokens.map((t) => `degree_level.ilike.%${t}%`)];
      schQuery = schQuery.or(orParts.join(","));
    }

    const { data: scholarships } = await schQuery;

    const profileSummary = `
USER PROFILE:
- Name: ${profile?.full_name ?? "Unknown"}
- Nationality: ${profile?.nationality ?? "Not set"}
- Country of residence: ${profile?.country_of_residence ?? "Not set"}
- Current academic level: ${profile?.academic_level ?? "Not set"}
- Intended program (wants to study abroad): ${profile?.intended_program ?? "Not set"}
- Intended degree level: ${profile?.intended_degree_level ?? "Not set"}
- Intended field of study: ${profile?.intended_field_of_study ?? "Not set"}
- Bio: ${profile?.bio ?? "—"}

EDUCATION:
${edu.map((e: any) => `- ${e.degree_level} in ${e.field_of_study ?? "—"} at ${e.institution} (GPA ${e.gpa ?? "?"}/${e.gpa_scale ?? "?"})${e.is_current ? " [current]" : ""}`).join("\n") || "- None on file"}

TEST SCORES:
${tests.map((t: any) => `- ${t.test_type}: ${t.score}${t.max_score ? "/" + t.max_score : ""}`).join("\n") || "- None on file"}

RESEARCH:
${research.map((r: any) => `- ${r.title}${r.organization ? " @ " + r.organization : ""}`).join("\n") || "- None on file"}

EXTRACURRICULARS:
${extras.map((x: any) => `- ${x.title} (${x.category})${x.organization ? " @ " + x.organization : ""}`).join("\n") || "- None on file"}

ESSAY PROFILE (source material the user wrote about themselves — use this as their authentic voice for SOP / motivation letter / personal statement writing; quote or paraphrase from it instead of inventing biographical details; if a needed field is empty, ASK them for it rather than making it up):
${essay && Object.values(essay).some(v => (v ?? "").toString().trim())
  ? [
      essay.motivation ? `- Motivation for the field: ${essay.motivation}` : "",
      essay.project_or_achievement ? `- Key project / academic achievement: ${essay.project_or_achievement}` : "",
      essay.tools_software ? `- Tools / software: ${essay.tools_software}` : "",
      essay.research_interests ? `- Research interests: ${essay.research_interests}` : "",
      essay.career_goals ? `- Career goals: ${essay.career_goals}` : "",
      essay.why_study_abroad ? `- Why study abroad: ${essay.why_study_abroad}` : "",
      essay.academic_explanations ? `- Academic record context to address: ${essay.academic_explanations}` : "",
    ].filter(Boolean).join("\n")
  : "- Not filled yet. If the user asks you to write an SOP/motivation letter/personal statement, ask them to fill the Essay Profile section on their Profile page (or ask them the missing questions directly in chat) before drafting."}
`.trim();


    const scholarshipContext = (scholarships ?? []).map((s: any, i: number) => {
      const sc = scoreMap.get(s.id);
      const scoreInfo = sc ? ` | match=${sc.score}% chance=${sc.chance}%` : " | match=? chance=?";
      return `${i + 1}. id=${s.id} | ${s.title} — ${s.provider ?? "—"} | ${s.country ?? "—"} | ${s.degree_level ?? "Any"} | Field: ${s.field_of_study ?? "Any"} | Funding: ${s.funding_amount ?? s.funding_type ?? "—"} | Deadline: ${s.next_close_date ?? "Rolling"}${scoreInfo} | ${s.url ?? ""}`;
    }).join("\n") || "No active scholarships matched.";

    // Detect explicit numeric count request (e.g. "give me 10", "list 15 scholarships", "top 8")
    const countMatch = String(lastUserMsg).match(/\b(?:give|list|show|recommend|suggest|find|top|best|need|want)\s+(?:me\s+)?(?:the\s+)?(\d{1,2})\b|\b(\d{1,2})\s+scholarships?\b/i);
    const requestedCount = countMatch ? parseInt(countMatch[1] ?? countMatch[2], 10) : null;
    const hasExplicitCount = requestedCount !== null && requestedCount > 0 && requestedCount <= 40;

    const multiHint = userAskedMultiple
      ? `\nIMPORTANT: The user is asking for MULTIPLE scholarships${requestedTokens.length >= 2 ? ` across degree levels: ${requestedTokens.join(", ")}` : ""}. ${hasExplicitCount ? `They explicitly asked for ${requestedCount} scholarships — return EXACTLY ${requestedCount} from the list if that many qualify. If fewer qualify, return all that qualify and explicitly state: "Only N scholarships in your matched pool fit this request." Do NOT default to a smaller range when a specific number is requested.` : "Recommend 3–6 matching scholarships from the list."} If multiple degree levels are requested, group them with bold markdown headings (e.g., **MSc options:** then tokens; **PhD options:** then tokens). Before each token, write ONE short sentence explaining why it fits this user.`
      : (hasExplicitCount ? `\nIMPORTANT: The user explicitly asked for ${requestedCount} scholarships — return EXACTLY ${requestedCount} as [[scholarship:<id>]] tokens if that many qualify from the list. If fewer qualify, return all that qualify and explicitly state: "Only N scholarships in your matched pool fit this request." Before each token, write ONE short sentence explaining why it fits this user.` : "");

    const autoScoreNote = autoScoreRan
      ? `\nNOTE: You just refreshed this user's personalized match scores in the background. Open your reply with one short, friendly line letting them know you've updated their match scores for the most personalized recommendations, then proceed.`
      : "";

    const sparseProfileNote = profileTooSparse
      ? `\nNOTE: This user's profile is too sparse to compute reliable match scores. Briefly recommend they complete their profile (academic level, education history, test scores or activities) on the Profile page so you can give better personalized recommendations. Still answer their question with general guidance.`
      : "";

    // Detect CV/résumé write requests — a distinct mode from SOP intake (no hook, no story questions).
    const CV_DOC_RE = /\b(cv|c\.v|curriculum vitae|résumé|resume)\b/i;
    const wantsCV = WRITE_INTENT_RE.test(String(lastUserMsg)) && CV_DOC_RE.test(String(lastUserMsg));

    // Detect requests to WRITE/DRAFT/UPDATE long-form documents (SOP, personal statement, motivation letter, essay, cover letter, recommendation letter)
    const wantsLongFormDoc = (WRITE_INTENT_RE.test(String(lastUserMsg)) && DOC_TYPE_RE.test(String(lastUserMsg))) || isAngleFlowTurn;
    const inLongFormConversation = !wantsCV && (wantsLongFormDoc || hasRecentLongFormDocContext(messages));
    const shouldSuppressScholarships = wantsCV || (inLongFormConversation && !SCHOLARSHIP_INTENT_RE.test(String(lastUserMsg)));
    console.log("[advisor-chat] flags", { lastUserMsg: String(lastUserMsg).slice(0, 100), wantsCV, wantsLongFormDoc, inLongFormConversation, shouldSuppressScholarships });

    // Map user request to a document_type token used in the essay library
    function detectRequestedDocType(text: string): string | null {
      const t = text.toLowerCase();
      if (/\b(sop|s\.o\.p|statement of purpose)\b/.test(t)) return "sop";
      if (/\bpersonal statement\b/.test(t)) return "personal_statement";
      if (/\bmotivation(?:al)? letter\b/.test(t)) return "motivation_letter";
      if (/\bcover letter\b/.test(t)) return "cover_letter";
      if (/\b(recommendation letter|letter of recommendation)\b/.test(t)) return "recommendation_letter";
      if (/\bstudy plan\b/.test(t)) return "study_plan";
      if (/\bresearch proposal\b/.test(t)) return "research_proposal";
      if (/\b(essay|admission essay|application essay)\b/.test(t)) return "essay";
      return null;
    }

    // ===== ESSAY LIBRARY RETRIEVAL (Phase 2: hybrid semantic + keyword) =====
    let essayReferences = "";
    if (inLongFormConversation) {
      try {
        const requestedDocType = detectRequestedDocType(String(lastUserMsg));
        const userField = (currentEdu?.field_of_study ?? "").toString().toLowerCase();
        const userCountryFromMsg = String(lastUserMsg).toLowerCase();

        // --- Semantic retrieval via embeddings (best-effort) ---
        const semanticBoost = new Map<string, number>(); // essay_id -> similarity (0..1)
        try {
          const embedQueryText = [
            String(lastUserMsg),
            userField,
            (profile?.country_of_origin ?? ""),
            (currentEdu?.degree_level ?? ""),
          ].filter(Boolean).join(" | ").slice(0, 4000);

          const embRes = await fetch("https://ai.gateway.lovable.dev/v1/embeddings", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${LOVABLE_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ model: "openai/text-embedding-3-small", input: embedQueryText, dimensions: 768 }),
          });
          if (embRes.ok) {
            const embJson = await embRes.json();
            const queryVec = embJson?.data?.[0]?.embedding;
            if (Array.isArray(queryVec)) {
              const { data: matches } = await admin.rpc("match_winning_essays", {
                query_embedding: queryVec as unknown as string,
                match_count: 8,
                filter_doc_type: requestedDocType,
              });
              for (const m of (matches ?? []) as any[]) {
                if (m?.id && typeof m.similarity === "number") {
                  semanticBoost.set(m.id, m.similarity);
                }
              }
            }
          } else {
            console.warn("Embedding API non-ok:", embRes.status);
          }
        } catch (semErr) {
          console.warn("Semantic retrieval failed (non-fatal):", semErr);
        }

        let essayQuery = admin.from("winning_essays").select(
          "id,title,document_type,scholarship_name,country,field_of_study,degree_level,year_won,content,tags"
        );
        if (requestedDocType) essayQuery = essayQuery.eq("document_type", requestedDocType);
        const { data: candidateEssays } = await essayQuery.limit(60);

        const scored = (candidateEssays ?? []).map((e: any) => {
          let score = 0;
          const country = (e.country ?? "").toLowerCase();
          const field = (e.field_of_study ?? "").toLowerCase();
          const degree = (e.degree_level ?? "").toLowerCase();
          const scholarship = (e.scholarship_name ?? "").toLowerCase();
          const tags: string[] = (e.tags ?? []).map((t: string) => t.toLowerCase());

          if (country && userCountryFromMsg.includes(country)) score += 4;
          if (field && userField && (field.includes(userField) || userField.includes(field))) score += 4;
          if (field && userCountryFromMsg.includes(field)) score += 2;
          if (degree) {
            for (const tok of allTokens) if (degree.includes(tok)) score += 2;
          }
          if (scholarship && userCountryFromMsg.includes(scholarship.split(" ")[0])) score += 3;
          for (const tag of tags) {
            if (userCountryFromMsg.includes(tag)) score += 1;
            if (userField && tag.includes(userField)) score += 1;
          }
          // Hybrid boost: semantic similarity (0..1) weighted to compete with keyword scores
          const sim = semanticBoost.get(e.id);
          if (typeof sim === "number") score += sim * 8; // up to +8 from semantics
          return { essay: e, score };
        }).sort((a, b) => b.score - a.score);

        const top = scored.slice(0, 3).filter((s) => s.score > 0 || requestedDocType);
        // Always include top 3 if a doc type matched, even with 0 score, so style is at least anchored
        const finalPicks = top.length > 0 ? top : scored.slice(0, 2);

        if (finalPicks.length > 0) {
          essayReferences = `\n\nWINNING ESSAY REFERENCES (style only — never copy phrases verbatim):
${finalPicks.map((p, i) => {
  const e = p.essay;
  const meta = [
    e.scholarship_name, e.country, e.field_of_study, e.degree_level, e.year_won
  ].filter(Boolean).join(" | ");
  // Cap each essay to ~2500 chars to control prompt size
  const body = (e.content ?? "").slice(0, 2500);
  return `--- REFERENCE ${i + 1} (${e.document_type}${meta ? " — " + meta : ""}) ---
${body}`;
}).join("\n\n")}
--- END REFERENCES ---`;
        }
      } catch (err) {
        console.warn("Essay retrieval failed (non-fatal):", err);
      }
    }
    // ===== END ESSAY RETRIEVAL =====

    const longFormHint = inLongFormConversation
      ? `\n\nIMPORTANT — LONG-FORM DOCUMENT REQUEST:
The user is asking you to WRITE or UPDATE an actual document (SOP, essay, motivation letter, etc.).

⚠️ SEQUENTIAL INTAKE (do this FIRST, before writing anything):
A generic opening + missing specifics are the #1 reasons essays get rejected. You MUST collect the critical fields ONE QUESTION AT A TIME before drafting. After every user answer, ACKNOWLEDGE with a specific echo showing you absorbed their detail (see Acknowledgment Rule below) — never generic "Got it" — then ask the NEXT missing item. Do NOT draft the essay until ALL critical fields below are settled, OR the user explicitly says "just write it" / "skip the questions" / "draft now".

Priority order — ask in this exact sequence, skip any already answered in profile or earlier in the conversation:
  1. **Personal hook** — handled by cases (a)–(e) below.
  2. **Target university & program** (degree level + field) — if missing.
  3. **Target professor / lab / research group** at that university — if program is known but professor/lab isn't on file or in the conversation.
  4. **Key project or academic achievement** with method + outcome — if essay.project_or_achievement is empty.
  5. **Specific research interest** (1–2 sub-topics inside the field) — if essay.research_interests is empty.
  6. **Career goal target** — a REAL short-term employer/program (e.g. "IMF LSMS team", "MSF field epidemiologist") — if essay.career_goals is generic or empty.

Only ONE question per assistant turn. Use the STRUCTURED QUESTION BLOCK for choice questions, prose for open ones (like "what's your target university?" or "name the professor whose work excites you most").

Hook cases:
  (a) Has the user ALREADY shared a personal story, defining moment, anecdote, or "why this field" memory in this conversation? If YES → hook is settled, move to the next missing item in the priority list above.
  (b) Did the user ask you to SUGGEST/CRAFT ANGLES ("craft one for me", "suggest angles", "give me options", "I don't have a story", "you suggest")? If YES → DO NOT write the essay yet. Present 2–3 distinct angle OPTIONS grounded in their profile. Format each as: **Angle N: [short title]** — 2–3 sentences. Then output a STRUCTURED QUESTION BLOCK with ["Angle 1", "Angle 2", "Angle 3"]. STOP.
  (c) Did the user explicitly opt out entirely ("just write it", "skip the questions", "use your judgment", "don't ask, just draft")? If YES → skip ALL remaining intake and draft, using placeholders for missing facts.
  (d) Did the user already pick an angle OR chose to use the Essay Profile story (e.g. "go with angle 2", "use my essay profile", "yes use it")? If YES → hook is settled. Acknowledge by echoing the specific detail (e.g. "Since you already wrote a powerful motivation story in your Essay Profile, I'll weave that in as the opening hook." or "Angle 2 it is — the community health thread is strong."), then ask the NEXT missing item from the priority list (university → professor → project → research interest → career goal). DO NOT start drafting yet.
  (e) Otherwise (first long-form request, no story or angle yet) → DO NOT write the essay yet. Reply with a short, warm message that:
      1. Acknowledges the request briefly ("Happy to draft your [SOP/motivation letter] — but first, the opening is what makes admissions remember you.").
      2. ${essay?.motivation && String(essay.motivation).trim()
            ? `Tell the user you can see they already filled the "Motivation of Study" section in their Essay Profile and quote 1–2 short phrases from it so they recognize it.`
            : `Briefly ask whether they have a defining moment or want you to craft one.`}
      3. Then output a STRUCTURED QUESTION BLOCK (see rule below) with the choices. Do NOT use bracketed "[ Option ]" notation or bullet lists for the choices.
      4. STOP. Do not write the essay in the same reply.


⚠️ STRUCTURED QUESTION BLOCK (REQUIRED for any question with selectable choices, including the hook intake and angle picks):
Output a fenced code block tagged \`brim-question\` with JSON. The frontend renders it as a clickable numbered option dialogue. Format:

\`\`\`brim-question
{
  "question": "Want me to build the opening from your Essay Profile motivation story, or craft a fresh personal hook?",
  "options": ["Use my Essay Profile", "Craft a new one for me"],
  "allowSkip": true,
  "allowFreeText": true
}
\`\`\`

Rules:
- Put any short context/acknowledgment as plain prose BEFORE the block (1–3 sentences max).
- ACKNOWLEDGMENT RULE — this is critical for trust: after EVERY user answer, first echo back what you heard and show you're using it. Examples of good acknowledgment:
    * If user says "I'm targeting MIT CS PhD": "MIT CS — strong fit. Since you're aiming for a top-tier AI lab, I'll make sure the research fit section is sharp."
    * If user says "I want to work with Prof. Smith": "Great choice — Prof. Smith's work on neural architecture search aligns well with your background."
    * If user says "My motivation came from building a malaria app in Uganda": "That Uganda fieldwork is exactly the kind of story that opens an SOP — vivid, specific, and mission-driven."
    * If user says "Use my Essay Profile": "Since you already wrote a powerful motivation story in your Essay Profile, I'll weave that in as the opening hook."
  The acknowledgment must reference the SPECIFIC detail the user shared (name, place, project, tool) — never generic "Got it" or "Understood." Then ask the NEXT question.
- Keep options short (2–6 words), 2–4 options max.
- For angle picks (case b), use options like ["Angle 1", "Angle 2", "Angle 3"] AFTER you describe each angle in prose.
- Always set allowSkip:true and allowFreeText:true unless a forced choice is truly required.
- Only ONE question block per assistant turn.
- For OPEN intake questions with no preset choices (e.g. "Which university and program?", "Which professor's work excites you?", "What's your key project?"), STILL use the block but with an empty "options": [] array and a helpful "placeholder" field. Example:
\`\`\`brim-question
{
  "question": "Which university and PhD program are you targeting for this SOP?",
  "options": [],
  "placeholder": "e.g. University of Chicago — PhD Economics",
  "allowSkip": true,
  "allowFreeText": true,
  "page": "2 of 5"
}
\`\`\`
This way every intake question renders as a clickable card with a typed answer field.

⚠️ CRITICAL FOR INTAKE/ANGLE REPLIES (cases b and e above): When you are asking the hook question OR presenting angle options, the reply must contain ONLY that question/block or those angles + block. DO NOT include any [[scholarship:<id>]] tokens, scholarship cards, scholarship recommendations, funding opportunities, "Recommended Scholarships", "Scholarship Matches for your journey", "Scholarship Matches for Your PhD Journey", or any other unrelated content.

WHEN WRITING THE ESSAY (after the hook is settled):
- HARD FORMAT CONTRACT: whenever you output the actual SOP / personal statement / motivation letter / cover letter / recommendation letter / scholarship essay / application essay prose, wrap ONLY the document body inside one fenced block opened with exactly \`\`\`essay and closed with \`\`\`. The app rejects mixed drafts: no commentary, no Notes, no tips, no questions, no word counts, and no scholarship tokens inside the essay block.
- Required shape: one short intro line OUTSIDE the block, then \`\`\`essay, then the complete document body in paragraphs, then closing \`\`\`, then a short Notes/Tips section and exactly one follow-up question OUTSIDE the block.
- Return the FINISHED PROSE in full — written paragraphs the user could paste into an application form. Do NOT return an outline, framework, or "how to write it" coaching unless they explicitly asked for tips/structure.
- Length: SOP/personal statement MUST be 800–1100 words (never shorter than 800 — count as you write and expand academic preparation, research, and why-this-program sections if you are under); motivation letter 500–700 words; short supplemental essays match the prompt's stated limit.
- Voice: write in FIRST PERSON ("I", "my") as if the user is speaking. Use their real profile details (name only if natural, education, GPA, test scores, country, research/extracurriculars).
- Structure: open with the chosen personal hook (vivid, specific, 3–5 sentences), then motivation/background, academic preparation, why-this-program/country, future goals, and a brief close. Use paragraph breaks; avoid bullet lists inside the document body.
- Do NOT prefix inside the essay block with meta commentary like "Here is your SOP:" — put any intro line before the \`\`\`essay block.
- After the document, add a short "Notes" section with 2–3 specific suggestions for personalization (e.g. "Replace [specific professor name] with someone you'd actually want to work with"; if you invented anecdote specifics, flag them for the user to confirm or replace).
- Never mix scholarship card tokens [[scholarship:<id>]] inside the SOP body itself.
- ⚠️ AFTER the essay ends, DO NOT append any scholarship recommendations, [[scholarship:<id>]] tokens, "Scholarships to Fund Your Journey", "Recommended Scholarships", "Scholarship Matches", funding cards, or related sections. The reply ends with the document body + the short Notes section. Close with ONE single-line offer like: "Want me to tailor this to a specific scholarship? Just share the name." — and nothing else. Scholarship cards ONLY appear when the user explicitly asks about scholarships in a separate turn.${essayReferences ? `
- You have been provided WINNING ESSAY REFERENCES from past successful applicants below. Study their STRUCTURE, TONE, OPENING HOOKS, TRANSITIONS, and how they weave personal narrative with academic justification. Adapt those patterns to THIS user's profile and target. NEVER copy sentences or phrases verbatim — paraphrase ideas in fresh language. Do NOT mention the references exist.` : ""}`
      : "";

    const cvHint = wantsCV
      ? `\n\nIMPORTANT — CV / RÉSUMÉ WRITE REQUEST:
The user asked you to draft a CV/résumé. This is NOT an SOP flow — do NOT ask for a personal hook, do NOT run intake questions, do NOT suggest angles. Draft the finished document immediately using the USER PROFILE data below.

🚨 HARD FORMAT CONTRACT:
1. One short intro line OUTSIDE the block (max 15 words), e.g. "Here's your academic CV drafted from your profile:"
2. ONE fenced block opened with EXACTLY \`\`\`essay and closed with \`\`\` containing the ENTIRE CV as ready-to-paste plain text.
3. A short recap OUTSIDE the block: ✅ strong points / ⚠️ gaps / ✏️ tightening notes, then ONE follow-up question.

🚫 ABSOLUTE BRACKET BAN inside the \`\`\`essay block. The only allowed bracket is \`⚠️ [INSERT: <ask>]\`. Never write \`[Email]\`, \`[Phone Number]\`, \`[Location]\`, \`[Dates]\`, \`[LinkedIn]\`, \`[Link to ...]\`, \`[Insert Score]\`, or any other bracketed placeholder — brackets are programmatically stripped. If a value is missing from the profile, OMIT the line entirely.

Inside the \`\`\`essay block:
- Line 1: real full name from USER PROFILE (never a placeholder).
- Contact lines: one per line — only include email, phone, location, LinkedIn if the value exists in USER PROFILE. OMIT missing lines.
- Sections in this order — OMIT any with no real data: Professional Summary, Education, Research Experience, Publications (only if a real citation exists — otherwise classify as Research Experience or Projects, never fabricate), Teaching Experience, Technical Skills, Test Scores (write real scores from TEST SCORES, never \`[Insert Score]\`), Awards & Honors, Extracurriculars, References.
- Real dates only. If a date is missing, OMIT it — never \`[Dates]\`.
- Plain-text formatting; no markdown \`#\` headers; no "Note:" / "Highlight…" / "This demonstrates…" INSIDE the block.
- Do NOT produce an outline / "structure for a CV" / section-tips list. Produce the finished CV.`
      : "";

    const systemPrompt = `You are Brim Advisor, an expert AI guide for international scholarships and university admissions. You speak in a warm, direct, professional tone — like a knowledgeable senior advisor.

CORE BEHAVIOR:
- Personalize every answer using the USER PROFILE below. Reference their degree level, field, GPA, country, and test scores explicitly when relevant.
- When recommending scholarships, ONLY cite scholarships from the AVAILABLE SCHOLARSHIPS list.
- For each scholarship you recommend, render it using ONLY this exact token on its own line: [[scholarship:<id>]] (use the id from the list). Do NOT also write the title, provider, deadline, or a markdown link for that scholarship — the app renders a rich card from the token automatically. You may add 1-2 sentences of context BEFORE or AFTER the token explaining why it fits the user.
- The card automatically displays Match % and Chance % badges, so do NOT repeat those numbers in prose unless directly asked.
- If the user asks about a scholarship not in the list, say you don't have current data on it and suggest they check the Scholarships page in the app.
- In any closing summary, recap, or "high chance" wrap-up, ONLY name scholarships you actually rendered as [[scholarship:<id>]] tokens earlier in THIS reply. Never mention a scholarship by name (e.g. "Kazakhstan Government Scholarships", "SINGA", "RTP") if you did not render its token above. If you want to highlight it in the summary, render its token there too.
- For SOP/essay/letter STRATEGY questions ("how should I structure", "what should I include"), give concrete structured advice with markdown headings/bullets. For SOP/essay/letter WRITING requests ("write me", "draft", "update", "tailor"), deliver finished prose — see the long-form document rule below.
- Never invent deadlines, funding amounts, or eligibility rules. If unsure, say so.
- Keep replies focused. Use markdown for clarity.${multiHint}${autoScoreNote}${sparseProfileNote}${longFormHint}${cvHint}

${profileSummary}

AVAILABLE SCHOLARSHIPS (active, matched to user where possible; match/chance shown when computed):
${shouldSuppressScholarships ? "(suppressed — user is in essay/SOP/CV mode; do NOT recommend scholarships, name scholarships, or render scholarship cards in this reply)" : scholarshipContext}${essayReferences}`;

    const callGateway = () => fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{ role: "system", content: systemPrompt }, ...messages],
        stream: !shouldSuppressScholarships,
      }),
    });

    let aiResp = await callGateway();

    // Retry once on transient upstream errors (502/503/504, Cloudflare 5xx)
    if (!aiResp.ok && aiResp.status >= 500 && aiResp.status < 600) {
      const firstErr = await aiResp.text().catch(() => "");
      console.warn("AI gateway transient error, retrying once:", aiResp.status, firstErr);
      await new Promise((r) => setTimeout(r, 800));
      aiResp = await callGateway();
    }

    if (!aiResp.ok) {
      if (aiResp.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit reached. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (aiResp.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await aiResp.text().catch(() => "");
      console.error("AI gateway error:", aiResp.status, t);
      const isUpstream = aiResp.status >= 500;
      return new Response(JSON.stringify({
        error: isUpstream
          ? "The AI service is temporarily unavailable. Please try again in a moment."
          : "AI gateway error",
      }), {
        status: isUpstream ? 503 : 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (shouldSuppressScholarships) {
      const rawJson = await aiResp.json().catch(() => null);
      const rawText = rawJson?.choices?.[0]?.message?.content ?? "";
      console.log("[advisor-chat] rawText head", rawText.slice(0, 200), "hasFence:", /```essay/.test(rawText));
      const stage1 = sanitizeLongFormResponse(rawText);
      const cleanedText = wantsCV ? ensureEssayWrap(stage1) : stage1;
      console.log("[advisor-chat] cleanedText head", cleanedText.slice(0, 200), "hasFence:", /```essay/.test(cleanedText));
      const body = `data: ${JSON.stringify({ choices: [{ delta: { content: cleanedText } }] })}\n\ndata: [DONE]\n\n`;
      return new Response(body, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
      });
    }

    return new Response(aiResp.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("advisor-chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
