import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SHORTLIST_SIZE = 50;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(stableStringify).join(",") + "]";
  const keys = Object.keys(value as Record<string, unknown>).sort();
  return "{" + keys.map(k => JSON.stringify(k) + ":" + stableStringify((value as Record<string, unknown>)[k])).join(",") + "}";
}

async function computeHash(data: unknown): Promise<string> {
  const str = stableStringify(data);
  const buffer = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buffer)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function buildStudentSummary(profile: any, education: any[], subjects: any[], testScores: any[], research: any[], extracurriculars: any[], sop: string, documents: any[]) {
  return `
Student Profile:
- Name: ${profile?.full_name ?? "Not provided"}
- Highest Qualification (current): ${profile?.academic_level ?? "Not specified"}
- Intended Program (wants to study abroad): ${profile?.intended_program ?? "Not specified"}
- Intended Degree Level: ${profile?.intended_degree_level ?? "Not specified"}
- Intended Field of Study: ${profile?.intended_field_of_study ?? "Not specified"}
- Nationality: ${profile?.nationality ?? "Not provided"}
- Country of Residence: ${profile?.country_of_residence ?? "Not provided"}
- Bio: ${profile?.bio ?? "None"}

Education (${education.length} entries):
${education.map((e: any) => {
  const gpaStr = e.gpa != null
    ? (e.gpa_scale ? `${e.gpa}/${e.gpa_scale} (${((e.gpa / e.gpa_scale) * 100).toFixed(1)}%)` : `${e.gpa} (scale unknown)`)
    : "N/A";
  return `  - ${e.degree_level} at ${e.institution}, Field: ${e.field_of_study ?? "N/A"}, GPA: ${gpaStr}, Current: ${e.is_current}`;
}).join("\n") || "  None"}

High School Subjects (${subjects.length}):
${subjects.map((s: any) => `  - ${s.subject_name}: ${s.grade ?? "N/A"}`).join("\n") || "  None"}

Test Scores (${testScores.length}):
${testScores.map((t: any) => `  - ${t.test_type}: ${t.score}${t.max_score ? "/" + t.max_score : ""}`).join("\n") || "  None"}

Research Experience (${research.length}):
${research.map((r: any) => `  - ${r.title} at ${r.organization ?? "N/A"}, Publications: ${r.publications?.length ?? 0}`).join("\n") || "  None"}

Extracurriculars (${extracurriculars.length}):
${extracurriculars.map((e: any) => `  - ${e.title} (${e.category}) at ${e.organization ?? "N/A"}`).join("\n") || "  None"}

Statement of Purpose: ${sop ? "Provided (" + sop.length + " chars)" : "Not provided"}
Documents uploaded: ${documents.length} (${documents.map((d: any) => d.document_type).join(", ") || "none"})
`.trim();
}

function formatScholarshipList(scholarships: any[]) {
  return scholarships.map((s: any) => `
- ID: ${s.id}
  Title: ${s.title}
  Provider: ${s.provider ?? "N/A"}
  Country: ${s.country ?? "Any"}
  Degree Level: ${s.degree_level ?? "Any"}
  Field: ${s.field_of_study ?? "Any"}
  Min CGPA (as %): ${s.min_cgpa_percentage != null ? s.min_cgpa_percentage + "%" : "None"}
  Funding: ${s.funding_amount ?? "N/A"}
  Eligibility: ${s.eligibility_criteria ?? "N/A"}
  Deadline: ${s.next_close_date ?? "N/A"}
`).join("\n");
}

// ============================================================
// PREFILTER: hard-filter + soft-rank (no AI)
// ============================================================

function getStudentMaxGpaPercent(education: any[]): number | null {
  let best: number | null = null;
  for (const e of education) {
    if (e.gpa != null && e.gpa_scale && e.gpa_scale > 0) {
      const pct = (Number(e.gpa) / Number(e.gpa_scale)) * 100;
      if (best == null || pct > best) best = pct;
    }
  }
  return best;
}

function getStudentDegreeLevels(profile: any, education: any[]): Set<string> {
  const set = new Set<string>();
  if (profile?.academic_level) set.add(String(profile.academic_level).toLowerCase());
  for (const e of education) {
    if (e.degree_level) set.add(String(e.degree_level).toLowerCase());
  }
  return set;
}

// Map of which degree levels a student is eligible to apply FOR, based on their current/highest level.
// E.g. someone in Bachelor's is eligible for Master's. Someone in High School is eligible for Bachelor's.
function eligibleTargetDegrees(studentLevels: Set<string>): Set<string> {
  const targets = new Set<string>();
  const lvls = Array.from(studentLevels);
  for (const lvl of lvls) {
    const l = lvl.toLowerCase();
    // Always allow current level (in case of transfer/repeat)
    targets.add(l);
    if (l.includes("high school") || l.includes("secondary")) {
      targets.add("bachelor"); targets.add("undergraduate"); targets.add("bachelors");
    }
    if (l.includes("bachelor") || l.includes("undergrad")) {
      targets.add("master"); targets.add("masters"); targets.add("graduate"); targets.add("postgraduate");
    }
    if (l.includes("master")) {
      targets.add("phd"); targets.add("doctorate"); targets.add("doctoral");
    }
  }
  return targets;
}

function degreeMatches(scholarshipDegree: string | null, targets: Set<string>): boolean {
  if (!scholarshipDegree) return true; // "Any"
  const sd = scholarshipDegree.toLowerCase();
  // Split comma-separated values
  const parts = sd.split(/[,;/]/).map(p => p.trim()).filter(Boolean);
  if (parts.length === 0) return true;
  for (const part of parts) {
    if (part.includes("any") || part.includes("all")) return true;
    for (const t of targets) {
      if (part.includes(t) || t.includes(part)) return true;
    }
  }
  return false;
}

function countryEligible(scholarshipCountry: string | null, eligibility: string | null, studentNationality: string | null, studentResidence: string | null): boolean {
  // We only HARD-exclude when the eligibility text clearly restricts to nationalities/regions
  // that don't include the student. Most country fields refer to study destination (not restriction),
  // so we keep them open and let AI / soft-rank decide.
  if (!eligibility) return true;
  const elig = eligibility.toLowerCase();
  const nat = (studentNationality ?? "").toLowerCase();
  const res = (studentResidence ?? "").toLowerCase();

  // Heuristic: if eligibility says "only for X citizens/nationals" or "must be a citizen of X",
  // and X doesn't include the student's nationality or residence, exclude.
  const restrictPatterns = [
    /only\s+(?:for\s+)?([a-z\s,]+?)(?:\s+citizens|\s+nationals|\s+residents)/i,
    /must\s+be\s+a\s+(?:citizen|national|resident)\s+of\s+([a-z\s,]+?)(?:\.|,|$)/i,
    /restricted\s+to\s+([a-z\s,]+?)(?:\s+citizens|\s+nationals)/i,
  ];
  for (const pat of restrictPatterns) {
    const m = elig.match(pat);
    if (m && m[1]) {
      const allowed = m[1].toLowerCase();
      if (nat && allowed.includes(nat)) return true;
      if (res && allowed.includes(res)) return true;
      // Found a restriction that doesn't include student → exclude
      return false;
    }
  }
  return true;
}

function deadlineOpen(deadline: string | null): boolean {
  if (!deadline) return true; // No deadline → assume open
  const d = new Date(deadline);
  if (isNaN(d.getTime())) return true; // Bad date → don't exclude
  return d.getTime() >= Date.now();
}

function gpaMeetsMin(scholarshipMinPct: number | null, studentMaxPct: number | null): boolean {
  if (scholarshipMinPct == null) return true;
  if (studentMaxPct == null) return true; // Don't exclude if student hasn't entered GPA
  return studentMaxPct + 1 >= scholarshipMinPct; // 1-point grace
}

// Soft ranking score 0-100 used to pick the top-N shortlist
function softRank(s: any, profile: any, education: any[], studentDegrees: Set<string>, targets: Set<string>, studentMaxGpa: number | null): number {
  let score = 50; // baseline

  // Degree level overlap with current/aspirational levels
  if (s.degree_level) {
    const sd = s.degree_level.toLowerCase();
    let hit = false;
    for (const t of targets) {
      if (sd.includes(t)) { hit = true; break; }
    }
    if (hit) score += 15;
  } else {
    score += 5; // "Any" is mildly positive
  }

  // Field of study overlap
  const studentFields = new Set(
    education.map((e: any) => (e.field_of_study ?? "").toLowerCase()).filter(Boolean)
  );
  if (s.field_of_study && studentFields.size > 0) {
    const sf = s.field_of_study.toLowerCase();
    let hit = false;
    for (const f of studentFields) {
      if (sf.includes(f) || f.includes(sf)) { hit = true; break; }
    }
    if (hit) score += 15;
  } else if (!s.field_of_study) {
    score += 5;
  }

  // Country preference
  if (s.country && profile?.country_of_residence) {
    if (s.country.toLowerCase().includes(profile.country_of_residence.toLowerCase())) score += 5;
  }

  // GPA buffer: above min by margin = bonus
  if (s.min_cgpa_percentage != null && studentMaxGpa != null) {
    const buffer = studentMaxGpa - s.min_cgpa_percentage;
    if (buffer >= 10) score += 10;
    else if (buffer >= 0) score += 5;
  } else if (s.min_cgpa_percentage == null) {
    score += 3;
  }

  // Recency: newer scholarships get small boost
  if (s.created_at) {
    const ageDays = (Date.now() - new Date(s.created_at).getTime()) / (1000 * 60 * 60 * 24);
    if (ageDays < 7) score += 5;
    else if (ageDays < 30) score += 2;
  }

  // Funding type bonus (full > partial)
  if (s.funding_type) {
    const ft = s.funding_type.toLowerCase();
    if (ft.includes("full")) score += 5;
  }

  return Math.min(100, Math.max(0, score));
}

interface PrefilterResult {
  shortlist: any[];               // top N for AI scoring
  longTail: { scholarship: any; score: number }[]; // remainder with deterministic score
  excluded: number;               // how many were hard-filtered out
}

function prefilterScholarships(
  scholarships: any[],
  profile: any,
  education: any[],
): PrefilterResult {
  const studentDegrees = getStudentDegreeLevels(profile, education);
  const targets = eligibleTargetDegrees(studentDegrees);
  const studentMaxGpa = getStudentMaxGpaPercent(education);

  const passed: { scholarship: any; score: number }[] = [];
  let excluded = 0;

  for (const s of scholarships) {
    // STRICT hard filters
    if (!deadlineOpen(s.next_close_date)) { excluded++; continue; }
    if (!degreeMatches(s.degree_level, targets)) { excluded++; continue; }
    if (!gpaMeetsMin(s.min_cgpa_percentage, studentMaxGpa)) { excluded++; continue; }
    if (!countryEligible(s.country, s.eligibility_criteria, profile?.nationality, profile?.country_of_residence)) {
      excluded++; continue;
    }

    const score = softRank(s, profile, education, studentDegrees, targets, studentMaxGpa);
    passed.push({ scholarship: s, score });
  }

  // Sort by soft score desc, tiebreak by recency
  passed.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const ad = a.scholarship.created_at ? new Date(a.scholarship.created_at).getTime() : 0;
    const bd = b.scholarship.created_at ? new Date(b.scholarship.created_at).getTime() : 0;
    return bd - ad;
  });

  const shortlist = passed.slice(0, SHORTLIST_SIZE).map(p => p.scholarship);
  const longTail = passed.slice(SHORTLIST_SIZE);
  return { shortlist, longTail, excluded };
}

// ============================================================
// AI scoring
// ============================================================

const systemPrompt = `You are a scholarship readiness evaluator. Analyze the student's profile against available scholarships. Be realistic but encouraging. Consider academic strength, test scores, research experience, extracurriculars, and overall preparedness.

IMPORTANT: Always address the student directly using second person ("you", "your"). For example, say "You are a strong match..." instead of "He is a strong match..." or "The student is a strong match...".

IMPORTANT: Adapt your evaluation based on the student's academic level. For high school students, focus on their subjects, grades, and extracurriculars rather than GPA, research, or publications (which are university-level expectations). For university/graduate students, weigh research, GPA, and publications more heavily.

CRITICAL GPA COMPARISON RULE: Student GPAs are provided with their scale (e.g. 3.36/4.0 = 84%) and scholarship minimum CGPAs are provided as percentages. ALWAYS compare using percentages. For example, a student with 3.36/4.0 (84%) meets a scholarship requiring 70% minimum CGPA. Never compare raw GPA numbers across different scales.

For each scholarship, provide TWO separate scores:
1. Match score (0-100): How well the student's profile criteria align with the scholarship requirements (GPA, field, country, degree level, eligibility criteria). A high match means the student meets most/all stated requirements.
2. Chance score (0-100): The estimated likelihood of actually being selected/winning, factoring in competition level, scholarship selectivity, strength of the application relative to typical awardees, and how competitive the student's overall profile is. This should often be LOWER than the match score for competitive scholarships.

These scores should be DIFFERENT — a student can be a 90% match but have a 30% chance if the scholarship is extremely competitive.

CRITICAL REASONING RULE: For each scholarship's "reason" and "chance_reason", provide SPECIFIC and DETAILED explanations (2-3 sentences minimum). Reference concrete profile data points (e.g., the student's exact GPA percentage, their field of study, their nationality, their test scores) and compare them against the scholarship's stated requirements. NEVER use vague phrases like "you are a good match" or "you meet the criteria" — explain exactly WHICH criteria are met or missed and by how much. For chance_reason, mention specific factors like the scholarship's prestige level, estimated applicant volume, how the student's profile compares to typical awardees, and what specific strengths or gaps affect their odds.`;

const aiToolDef = {
  type: "function" as const,
  function: {
    name: "evaluate_student",
    description: "Return the student's scholarship readiness score, summary, tips, and per-scholarship match scores.",
    parameters: {
      type: "object",
      properties: {
        readiness_score: { type: "integer", description: "Overall readiness score 0-100" },
        readiness_summary: { type: "string", description: "Brief explanation of the score" },
        tips: {
          type: "array",
          items: { type: "string" },
          description: "3-5 actionable tips to improve chances",
        },
        scholarship_matches: {
          type: "array",
          items: {
            type: "object",
            properties: {
              scholarship_id: { type: "string" },
              score: { type: "integer", description: "Match score 0-100: how well the student's profile fits the scholarship criteria" },
              chance: { type: "integer", description: "Chance score 0-100: estimated likelihood of being selected, considering competition and selectivity" },
              reason: { type: "string", minLength: 80, description: "Detailed explanation (2-3 sentences) of the match score. Reference specific criteria: state which requirements the student meets or misses (e.g., 'Your GPA of 84% exceeds the 70% minimum', 'Your field of Computer Science aligns with the STEM requirement', 'Your nationality does not match the eligibility restriction'). Written in second person." },
              chance_reason: { type: "string", minLength: 80, description: "Detailed explanation (2-3 sentences) of the chance score. Reference specific competitive factors: the scholarship's prestige and selectivity, estimated number of applicants, how the student's profile compares to typical winners, and what specific strengths (strong GPA, relevant research, leadership) or weaknesses (missing test scores, no publications) affect their odds. Written in second person." },
            },
            required: ["scholarship_id", "score", "chance", "reason", "chance_reason"],
          },
          description: "Match score for each scholarship",
        },
      },
      required: ["readiness_score", "readiness_summary", "tips", "scholarship_matches"],
      additionalProperties: false,
    },
  },
};

async function callAI(apiKey: string, userPrompt: string) {
  const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "google/gemini-3-flash-preview",
      temperature: 0,
      max_tokens: 16000,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      tools: [aiToolDef],
      tool_choice: { type: "function", function: { name: "evaluate_student" } },
    }),
  });

  if (!aiResponse.ok) {
    const status = aiResponse.status;
    const body = await aiResponse.text();
    console.error("AI error:", status, body);
    if (status === 429) return { error: "Rate limited. Please try again in a moment.", status: 429 };
    if (status === 402) return { error: "AI credits exhausted. Please add credits.", status: 402 };
    return { error: `AI gateway error: ${status}`, status: 500 };
  }

  const aiData = await aiResponse.json();
  const finishReason = aiData.choices?.[0]?.finish_reason;
  console.log("AI finish_reason:", finishReason, "usage:", JSON.stringify(aiData.usage ?? {}));
  const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
  if (!toolCall) {
    console.error("No tool call returned. finish_reason:", finishReason);
    return { error: "AI did not return structured output", status: 500 };
  }

  try {
    return { result: JSON.parse(toolCall.function.arguments), finishReason };
  } catch (e) {
    console.error("Failed to parse tool call args (likely truncated):", e);
    return { error: "AI response was truncated. Please try again.", status: 500 };
  }
}

// Retry scoring for any shortlist scholarships the AI omitted
async function fillMissingMatches(
  apiKey: string,
  studentSummary: string,
  shortlist: any[],
  currentMatches: any[],
  maxAttempts = 2,
): Promise<any[]> {
  let matches = [...currentMatches];
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const have = new Set(matches.map((m: any) => m.scholarship_id));
    const missing = shortlist.filter((s: any) => !have.has(s.id));
    if (missing.length === 0) return matches;

    console.log(`fillMissingMatches attempt ${attempt}: ${missing.length} missing`);

    const prompt = `Evaluate this student ONLY against the scholarships listed below. Provide both match scores and chance scores for each.

${studentSummary}

Scholarships to Evaluate:
${formatScholarshipList(missing)}

Call the evaluate_student function with your assessment. The readiness_score and tips can be approximate — only the scholarship_matches matter here.`;

    const aiResult = await callAI(apiKey, prompt);
    if (aiResult.error) {
      console.error(`Retry attempt ${attempt} failed:`, aiResult.error);
      break;
    }
    const newOnes = (aiResult.result.scholarship_matches ?? []).map((m: any) => ({
      ...m,
      chance_reason: m.chance_reason || m.reason || "",
    }));
    matches = [...matches, ...newOnes];
  }
  return matches;
}

// Build a "pending" deterministic match for long-tail scholarships
function buildPendingMatch(scholarshipId: string, deterministicScore: number) {
  const s = Math.round(deterministicScore);
  return {
    scholarship_id: scholarshipId,
    score: s,
    chance: Math.max(10, Math.round(s * 0.5)), // rough placeholder; user can request AI scoring
    reason: "Quick match based on profile criteria. Tap 'Score with AI' for a detailed evaluation.",
    chance_reason: "Estimated from profile fit. Tap 'Score with AI' for a personalized chance assessment.",
    pending_ai: true,
  };
}

// ============================================================
// Handler
// ============================================================

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing authorization header");

    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) throw new Error("Unauthorized");

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch profile data in parallel
    const [profileRes, eduRes, testRes, researchRes, extraRes, sopRes, docsRes, scholarshipsRes, subjectsRes] =
      await Promise.all([
        adminClient.from("profiles").select("*").eq("user_id", user.id).single(),
        adminClient.from("education_history").select("*").eq("user_id", user.id),
        adminClient.from("test_scores").select("*").eq("user_id", user.id),
        adminClient.from("research_experience").select("*").eq("user_id", user.id),
        adminClient.from("extracurriculars").select("*").eq("user_id", user.id),
        adminClient.from("sop_entries").select("content").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1),
        adminClient.from("user_documents").select("document_type, file_name").eq("user_id", user.id),
        adminClient.from("scholarships").select("*").eq("is_active", true),
        adminClient.from("high_school_subjects").select("*").eq("user_id", user.id),
      ]);

    const profile = profileRes.data;
    const education = eduRes.data ?? [];
    const testScores = testRes.data ?? [];
    const research = researchRes.data ?? [];
    const extracurriculars = extraRes.data ?? [];
    const sop = sopRes.data?.[0]?.content ?? "";
    const documents = docsRes.data ?? [];
    const scholarships = scholarshipsRes.data ?? [];
    const subjects = subjectsRes.data ?? [];

    // Run prefilter (deterministic, no AI)
    const { shortlist, longTail, excluded } = prefilterScholarships(scholarships, profile, education);
    console.log(`Prefilter: ${scholarships.length} total → ${shortlist.length} shortlisted, ${longTail.length} long-tail, ${excluded} excluded`);

    // Hashes
    const profileDataForHash = { profile, education, testScores, research, extracurriculars, sop, documents, subjects };
    const currentProfileHash = await computeHash(profileDataForHash);
    const currentScholarshipHash = await computeHash(scholarships);

    // Cached result
    const { data: cachedRows } = await adminClient
      .from("score_results")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1);

    const cached = cachedRows?.[0];
    const cachedMatches: any[] = (cached?.scholarship_matches as any[]) ?? [];
    const [cachedProfileHash, cachedScholarshipHash] = (cached?.profile_hash ?? "").split("|");
    const profileUnchanged = cached && cachedProfileHash === currentProfileHash;
    const scholarshipsUnchanged = cached && cachedScholarshipHash === currentScholarshipHash;

    // CASE 1: Nothing changed
    if (profileUnchanged && scholarshipsUnchanged) {
      return new Response(JSON.stringify({
        readiness_score: cached.readiness_score,
        readiness_summary: cached.readiness_summary,
        tips: cached.tips,
        scholarship_matches: cached.scholarship_matches,
        cached: true,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const studentSummary = buildStudentSummary(profile, education, subjects, testScores, research, extracurriculars, sop, documents);
    const combinedHash = `${currentProfileHash}|${currentScholarshipHash}`;

    // ----- AI scoring on the SHORTLIST only -----
    let aiMatches: any[] = [];
    let readinessScore = cached?.readiness_score ?? 50;
    let readinessSummary = cached?.readiness_summary ?? "";
    let tips: any = cached?.tips ?? [];

    // CASE 2: Profile changed → score the whole shortlist + refresh readiness
    if (!profileUnchanged) {
      if (shortlist.length === 0) {
        // No eligible scholarships — still produce a readiness summary
        const promptOnlyReadiness = `Evaluate this student's overall scholarship readiness. There are currently no scholarships in the database that match their basic eligibility (degree level, GPA minimum, deadline, country restrictions).

${studentSummary}

Call the evaluate_student function. Return scholarship_matches as an empty array.`;
        const r = await callAI(LOVABLE_API_KEY, promptOnlyReadiness);
        if (r.error) {
          return new Response(JSON.stringify({ error: r.error }), {
            status: r.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        readinessScore = r.result.readiness_score;
        readinessSummary = r.result.readiness_summary;
        tips = r.result.tips;
      } else {
        const userPrompt = `Evaluate this student for scholarship readiness and match them against the shortlisted scholarships below (these are pre-filtered to be eligible). Provide both match scores and chance scores for each.

${studentSummary}

Shortlisted Scholarships (${shortlist.length}):
${formatScholarshipList(shortlist)}

Call the evaluate_student function with your assessment.`;
        const r = await callAI(LOVABLE_API_KEY, userPrompt);
        if (r.error) {
          return new Response(JSON.stringify({ error: r.error }), {
            status: r.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        aiMatches = (r.result.scholarship_matches ?? []).map((m: any) => ({
          ...m,
          chance_reason: m.chance_reason || m.reason || "",
        }));
        // Recover any omitted shortlist items
        aiMatches = await fillMissingMatches(LOVABLE_API_KEY, studentSummary, shortlist, aiMatches);
        readinessScore = r.result.readiness_score;
        readinessSummary = r.result.readiness_summary;
        tips = r.result.tips;
      }
    } else {
      // CASE 3: Profile unchanged, scholarships changed → keep cached AI matches for shortlist
      // items that already have an AI score; only AI-score new shortlist items.
      const cachedMap = new Map(cachedMatches.map((m: any) => [m.scholarship_id, m]));
      const shortlistIds = new Set(shortlist.map((s: any) => s.id));

      // Reuse cached AI scores for shortlist items already scored (and not pending)
      const reused: any[] = [];
      const needScoring: any[] = [];
      for (const s of shortlist) {
        const c = cachedMap.get(s.id);
        if (c && !c.pending_ai) {
          reused.push(c);
        } else {
          needScoring.push(s);
        }
      }

      if (needScoring.length > 0) {
        const userPrompt = `Evaluate this student ONLY against the scholarships below. Provide both match scores and chance scores for each.

${studentSummary}

Scholarships to Evaluate:
${formatScholarshipList(needScoring)}

Call the evaluate_student function. The readiness_score and tips can be approximate — only the scholarship_matches matter.`;
        const r = await callAI(LOVABLE_API_KEY, userPrompt);
        if (r.error) {
          return new Response(JSON.stringify({ error: r.error }), {
            status: r.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        let newOnes = (r.result.scholarship_matches ?? []).map((m: any) => ({
          ...m,
          chance_reason: m.chance_reason || m.reason || "",
        }));
        newOnes = await fillMissingMatches(LOVABLE_API_KEY, studentSummary, needScoring, newOnes);
        aiMatches = [...reused, ...newOnes];
      } else {
        aiMatches = reused;
      }
    }

    // ----- Build long-tail pending matches (preserve any existing AI scores from cache) -----
    const cachedMap = new Map(cachedMatches.map((m: any) => [m.scholarship_id, m]));
    const longTailMatches = longTail.map(({ scholarship, score }) => {
      const existing = cachedMap.get(scholarship.id);
      if (existing && !existing.pending_ai) return existing; // user already scored this on-demand
      return buildPendingMatch(scholarship.id, score);
    });

    const allMatches = [...aiMatches, ...longTailMatches];

    // Cache
    await adminClient.from("score_results").delete().eq("user_id", user.id);
    await adminClient.from("score_results").insert({
      user_id: user.id,
      readiness_score: readinessScore,
      readiness_summary: readinessSummary,
      tips,
      scholarship_matches: allMatches,
      profile_hash: combinedHash,
    });

    return new Response(JSON.stringify({
      readiness_score: readinessScore,
      readiness_summary: readinessSummary,
      tips,
      scholarship_matches: allMatches,
      cached: false,
      _meta: {
        total_scholarships: scholarships.length,
        ai_scored: aiMatches.length,
        long_tail_pending: longTailMatches.length,
        excluded_by_prefilter: excluded,
      },
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("score-profile error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
