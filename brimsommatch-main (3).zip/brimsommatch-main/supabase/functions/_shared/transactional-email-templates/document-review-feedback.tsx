/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body, Button, Container, Head, Heading, Html, Preview, Section, Text, Hr,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  name?: string
  serviceLabel?: string
  fileName?: string
  status?: string
  feedback?: string
}

const STATUS_COPY: Record<string, { heading: string; intro: string }> = {
  reviewed: {
    heading: 'Your document review is ready',
    intro: 'Our team has finished reviewing your document and left feedback for you.',
  },
  in_review: {
    heading: 'Your document is being reviewed',
    intro: 'Our team has started reviewing your document and shared a note with you.',
  },
  rejected: {
    heading: 'Update on your document review',
    intro: 'Our team reviewed your submission and shared some notes below.',
  },
}

const DocumentReviewFeedbackEmail = ({
  name = 'there',
  serviceLabel = 'your document',
  fileName,
  status = 'reviewed',
  feedback,
}: Props) => {
  const copy = STATUS_COPY[status] || STATUS_COPY.reviewed
  return (
    <Html lang="en" dir="ltr">
      <Head />
      <Preview>{copy.heading}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Text style={logo}>Brimsom</Text>
          <Hr style={divider} />
          <Heading style={h1}>{copy.heading}</Heading>
          <Text style={text}>Hi {name}, {copy.intro}</Text>
          <Text style={meta}>
            Service: {serviceLabel}
            {fileName ? ` • File: ${fileName}` : ''}
          </Text>
          {feedback ? (
            <Section style={quote}>
              <Text style={quoteText}>{feedback}</Text>
            </Section>
          ) : null}
          <Button style={button} href="https://brimsom.com/document-review">
            View your review
          </Button>
          <Text style={footer}>— The Brimsom AI Team</Text>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: DocumentReviewFeedbackEmail,
  subject: (d: Record<string, any>) =>
    `Feedback on your ${d.serviceLabel || 'document'} review — Brimsom`,
  displayName: 'Document review feedback',
  previewData: {
    name: 'Moses',
    serviceLabel: 'Statement of Purpose',
    fileName: 'sop.pdf',
    status: 'reviewed',
    feedback: 'Great structure overall. Tighten the second paragraph and add a concrete research goal.',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'DM Sans', Arial, sans-serif" }
const container = { backgroundColor: '#ffffff', padding: '40px 32px', borderRadius: '12px', margin: '40px auto', maxWidth: '480px' }
const logo = { fontSize: '24px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px', textAlign: 'center' as const }
const divider = { borderColor: 'hsl(160, 10%, 90%)', margin: '0 0 24px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px' }
const text = { fontSize: '14px', color: 'hsl(220, 10%, 46%)', lineHeight: '1.6', margin: '0 0 16px' }
const meta = { fontSize: '13px', color: 'hsl(220, 10%, 56%)', margin: '0 0 20px' }
const quote = { backgroundColor: 'hsl(160, 30%, 96%)', borderRadius: '12px', padding: '16px 18px', margin: '0 0 24px' }
const quoteText = { fontSize: '14px', color: 'hsl(220, 25%, 20%)', lineHeight: '1.6', margin: '0', whiteSpace: 'pre-wrap' as const }
const button = { backgroundColor: 'hsl(160, 60%, 38%)', color: '#ffffff', fontSize: '14px', fontWeight: '600' as const, borderRadius: '12px', padding: '12px 24px', textDecoration: 'none' }
const footer = { fontSize: '12px', color: 'hsl(220, 10%, 46%)', margin: '30px 0 0' }
