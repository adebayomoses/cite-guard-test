/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'
import {
  Body, Button, Container, Head, Heading, Html, Preview, Text, Hr,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

interface Props {
  name?: string
  position?: string
  status?: 'reviewing' | 'shortlisted' | 'rejected' | 'hired'
}

const COPY: Record<string, { subject: (p: string) => string; heading: string; body: (n: string, p: string) => string; closing: string }> = {
  reviewing: {
    subject: (p) => `Update on your ${p} application at Brimsom`,
    heading: 'Your application is under review',
    body: (n, p) => `Hi ${n}, thanks for applying for the ${p} role at Brimsom AI. Our team is currently reviewing your application. We'll be in touch soon with the next steps.`,
    closing: 'We appreciate your patience.',
  },
  shortlisted: {
    subject: (p) => `Great news — you've been shortlisted for ${p}`,
    heading: "You've been shortlisted! 🎉",
    body: (n, p) => `Hi ${n}, congratulations! Your application for the ${p} role at Brimsom AI has been shortlisted. We were impressed by your profile and would like to move forward. Expect to hear from us shortly with the next steps.`,
    closing: 'Talk soon!',
  },
  rejected: {
    subject: (p) => `Update on your ${p} application at Brimsom`,
    heading: 'Update on your application',
    body: (n, p) => `Hi ${n}, thank you for your interest in the ${p} role at Brimsom AI and for the time you put into your application. After careful consideration, we've decided to move forward with other candidates this time. We genuinely appreciate your interest and encourage you to apply for future roles that match your skills.`,
    closing: 'Wishing you the very best in your job search.',
  },
  hired: {
    subject: (p) => `Welcome to Brimsom — offer for ${p}`,
    heading: "Welcome aboard! 🎊",
    body: (n, p) => `Hi ${n}, fantastic news — we'd love to have you join Brimsom AI as our new ${p}! Our team will reach out shortly with the offer details, onboarding steps, and next actions.`,
    closing: 'Welcome to the team!',
  },
}

const JobApplicationStatusEmail = ({ name = 'there', position = 'the role', status = 'reviewing' }: Props) => {
  const copy = COPY[status] || COPY.reviewing
  return (
    <Html lang="en" dir="ltr">
      <Head />
      <Preview>{copy.heading}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Text style={logo}>Brimsom</Text>
          <Hr style={divider} />
          <Heading style={h1}>{copy.heading}</Heading>
          <Text style={text}>{copy.body(name, position)}</Text>
          <Text style={text}>{copy.closing}</Text>
          <Button style={button} href="https://brimsom.com">Visit Brimsom</Button>
          <Text style={footer}>— The Brimsom AI Team</Text>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: JobApplicationStatusEmail,
  subject: (d: Record<string, any>) => {
    const status = (d.status || 'reviewing') as keyof typeof COPY
    const copy = COPY[status] || COPY.reviewing
    return copy.subject(d.position || 'your application')
  },
  displayName: 'Job application status update',
  previewData: { name: 'Jane', position: 'Moderator Data Specialist', status: 'shortlisted' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'DM Sans', Arial, sans-serif" }
const container = { backgroundColor: '#ffffff', padding: '40px 32px', borderRadius: '12px', margin: '40px auto', maxWidth: '480px' }
const logo = { fontSize: '24px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px', textAlign: 'center' as const }
const divider = { borderColor: 'hsl(160, 10%, 90%)', margin: '0 0 24px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px' }
const text = { fontSize: '14px', color: 'hsl(220, 10%, 46%)', lineHeight: '1.6', margin: '0 0 20px' }
const button = { backgroundColor: 'hsl(160, 60%, 38%)', color: '#ffffff', fontSize: '14px', fontWeight: '600' as const, borderRadius: '12px', padding: '12px 24px', textDecoration: 'none' }
const footer = { fontSize: '12px', color: 'hsl(220, 10%, 46%)', margin: '30px 0 0' }
