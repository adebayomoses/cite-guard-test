/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'

export interface TemplateEntry {
  component: React.ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  to?: string
  displayName?: string
  previewData?: Record<string, any>
}

import { template as jobApplicationStatus } from './job-application-status.tsx'
import { template as documentReviewFeedback } from './document-review-feedback.tsx'

export const TEMPLATES: Record<string, TemplateEntry> = {
  'job-application-status': jobApplicationStatus,
  'document-review-feedback': documentReviewFeedback,
}
