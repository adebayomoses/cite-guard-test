/// <reference types="npm:@types/react@18.3.1" />

import * as React from 'npm:react@18.3.1'

import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Hr,
} from 'npm:@react-email/components@0.0.22'

interface SignupEmailProps {
  siteName: string
  siteUrl: string
  recipient: string
  confirmationUrl: string
}

export const SignupEmail = ({
  siteName: _siteName,
  siteUrl: _siteUrl,
  recipient,
  confirmationUrl,
}: SignupEmailProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Confirm your Brimsom Scholarship Match signup</Preview>
    <Body style={main}>
      <Container style={container}>
        <Text style={logo}>Brimsom</Text>
        <Hr style={divider} />
        <Heading style={h1}>Please confirm your email address</Heading>
        <Text style={text}>
          Thanks for signing up for Brimsom Scholarship Match app! You're one step away from discovering scholarships matched to you.
        </Text>
        <Text style={text}>
          Please confirm your email address (
          <Link href={`mailto:${recipient}`} style={link}>
            {recipient}
          </Link>
          ) by clicking the button below:
        </Text>
        <Button style={button} href={confirmationUrl}>
          Confirm Email
        </Button>
        <Text style={footer}>
          If you didn't create a Brimsom account, you can safely ignore this email.
        </Text>
      </Container>
    </Body>
  </Html>
)

export default SignupEmail

const main = { backgroundColor: '#f5f7f6', fontFamily: "'DM Sans', Arial, sans-serif" }
const container = { backgroundColor: '#ffffff', padding: '40px 32px', borderRadius: '12px', margin: '40px auto', maxWidth: '480px' }
const logo = { fontSize: '24px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px', textAlign: 'center' as const }
const divider = { borderColor: 'hsl(160, 10%, 90%)', margin: '0 0 24px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, fontFamily: "'Fraunces', Georgia, serif", color: 'hsl(220, 25%, 10%)', margin: '0 0 16px' }
const text = { fontSize: '14px', color: 'hsl(220, 10%, 46%)', lineHeight: '1.6', margin: '0 0 20px' }
const link = { color: 'hsl(160, 60%, 38%)', textDecoration: 'underline' }
const button = { backgroundColor: 'hsl(160, 60%, 38%)', color: '#ffffff', fontSize: '14px', fontWeight: '600' as const, borderRadius: '12px', padding: '12px 24px', textDecoration: 'none' }
const footer = { fontSize: '12px', color: 'hsl(220, 10%, 46%)', margin: '30px 0 0' }
