import { sendLovableEmail } from 'npm:@lovable.dev/email-js'
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  const apiKey = Deno.env.get('LOVABLE_API_KEY')!
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const supabase = createClient(supabaseUrl, serviceKey)

  // Authorization: allow either a service-role caller (pg_cron) OR a logged-in admin.
  const authHeader = req.headers.get('Authorization') ?? ''
  const token = authHeader.replace(/^Bearer\s+/i, '')
  if (!token) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
  // Decode JWT payload to detect service-role tokens (pg_cron uses a vault-stored
  // service key that may differ from SUPABASE_SERVICE_ROLE_KEY env var).
  let jwtRole: string | undefined
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))
    jwtRole = payload?.role
  } catch { /* not a JWT */ }

  if (token !== serviceKey && jwtRole !== 'service_role') {
    const { data: claimsData, error: claimsErr } = await supabase.auth.getClaims(token)
    const callerId = claimsData?.claims?.sub
    if (claimsErr || !callerId) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
    const { data: isAdmin } = await supabase.rpc('has_role', { _user_id: callerId, _role: 'admin' })
    if (!isAdmin) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
  }





  // 1. Get scholarships created in the last 7 days (newest 10)
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  const todayStr = new Date().toISOString().split('T')[0]
  const { data: scholarshipsRaw, error: schErr } = await supabase
    .from('scholarships')
    .select('id, title, country, next_close_date, funding_amount, funding_type, degree_level')
    .eq('is_active', true)
    .gte('created_at', sevenDaysAgo)
    .order('created_at', { ascending: false })
    .limit(50)

  if (schErr) {
    console.error('Failed to fetch scholarships', schErr)
    return new Response(JSON.stringify({ error: 'Failed to fetch scholarships' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  // Filter to only scholarships with a future deadline (next_close_date) or
  // no deadline at all (rolling). `next_close_date` is maintained by the DB
  // trigger from `scholarship_intakes`.
  const scholarships = (scholarshipsRaw ?? [])
    .filter((s: any) => !s.next_close_date || s.next_close_date >= todayStr)
    .slice(0, 10)

  if (!scholarships.length) {
    console.log('No new active scholarships in the last 7 days, skipping digest.')
    return new Response(JSON.stringify({ skipped: true, reason: 'no_new_active_scholarships' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  // 2. Get users with digest enabled
  const { data: prefs, error: prefErr } = await supabase
    .from('email_preferences')
    .select('user_id')
    .eq('digest_enabled', true)

  if (prefErr) {
    console.error('Failed to fetch preferences', prefErr)
    return new Response(JSON.stringify({ error: 'Failed to fetch preferences' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  if (!prefs?.length) {
    console.log('No users with digest enabled, skipping.')
    return new Response(JSON.stringify({ skipped: true, reason: 'no_subscribed_users' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  // 3. Get suppressed emails
  const { data: suppressed } = await supabase.from('suppressed_emails').select('email')
  const suppressedSet = new Set((suppressed || []).map((s: { email: string }) => s.email.toLowerCase()))

  // 4. Get user details
  const allUserIds = prefs.map((p: { user_id: string }) => p.user_id)

  // Exclude users who have already generated a score — they receive the
  // personalized Weekly Focus 5 email instead, so the generic digest is
  // redundant for them.
  const { data: scoredRows } = await supabase
    .from('score_results')
    .select('user_id')
    .in('user_id', allUserIds)

  const scoredSet = new Set((scoredRows || []).map((r: { user_id: string }) => r.user_id))
  const userIds = allUserIds.filter((id: string) => !scoredSet.has(id))

  if (!userIds.length) {
    console.log('All subscribed users have generated scores; skipping generic digest.')
    return new Response(JSON.stringify({ skipped: true, reason: 'all_users_scored' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  const { data: profiles } = await supabase
    .from('profiles')
    .select('user_id, full_name')
    .in('user_id', userIds)

  const profileMap = new Map(
    (profiles || []).map((p: { user_id: string; full_name: string | null }) => [p.user_id, p.full_name])
  )

  const { data: authData } = await supabase.auth.admin.listUsers({ perPage: 1000 })
  const emailMap = new Map(
    (authData?.users || []).map((u: { id: string; email?: string }) => [u.id, u.email])
  )


  // 5. Build HTML email body
  const scholarshipRows = scholarships
    .map((s: { title: string; country: string | null; next_close_date: string | null; funding_amount: string | null; funding_type: string | null; degree_level: string | null }) => {
      const deadline = s.next_close_date ? new Date(s.next_close_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Open'
      const funding = [s.funding_type, s.funding_amount].filter(Boolean).join(' — ') || 'See details'
      const tags = [s.country, s.degree_level].filter(Boolean).join(' · ')
      return `
        <tr>
          <td style="padding: 16px; border-bottom: 1px solid #e5e7eb;">
            <div style="font-weight: 600; font-size: 16px; color: #111827; margin-bottom: 4px;">${s.title}</div>
            <div style="font-size: 13px; color: #6b7280; margin-bottom: 4px;">${tags}</div>
            <div style="font-size: 13px; color: #374151;">
              <span>💰 ${funding}</span> &nbsp; <span>📅 ${deadline}</span>
            </div>
          </td>
        </tr>`
    })
    .join('')

  // Build plain text version
  const scholarshipTextLines = scholarships
    .map((s: { title: string; country: string | null; next_close_date: string | null }, i: number) => {
      const deadline = s.next_close_date ? new Date(s.next_close_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Open'
      const tags = [s.country].filter(Boolean).join(' · ')
      return `${i + 1}. ${s.title}${tags ? ` (${tags})` : ''} — Deadline: ${deadline}`
    })
    .join('\n')

  // 6. Send emails directly
  let sent = 0
  let skipped = 0
  let failed = 0

  for (const userId of userIds) {
    const email = emailMap.get(userId)
    if (!email || suppressedSet.has(email.toLowerCase())) {
      skipped++
      continue
    }

    const name = profileMap.get(userId) || 'there'
    const idempotencyKey = `digest-${userId}-${new Date().toISOString().split('T')[0]}`

    // Get or create unsubscribe token for this email
    let unsubscribeToken = ''
    const { data: existingToken } = await supabase
      .from('email_unsubscribe_tokens')
      .select('token')
      .eq('email', email.toLowerCase())
      .maybeSingle()

    if (existingToken?.token) {
      unsubscribeToken = existingToken.token
    } else {
      const newToken = crypto.randomUUID()
      await supabase.from('email_unsubscribe_tokens').insert({
        email: email.toLowerCase(),
        token: newToken,
      })
      unsubscribeToken = newToken
    }

    const plainText = `Hi ${name},\n\nHere are the latest ${scholarships.length} scholarships added to Brimsom in the last 7 days:\n\n${scholarshipTextLines}\n\nBrowse all: https://brimsommatch.lovable.app/scholarships?tab=new\nCheck your Match Score: https://brimsommatch.lovable.app/score\n\n— The Brimsom Team`

    const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
<body style="margin: 0; padding: 0; background-color: #ffffff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
  <div style="max-width: 600px; margin: 0 auto; padding: 32px 16px;">
    <div style="text-align: center; margin-bottom: 32px;">
      <h1 style="font-size: 24px; font-weight: 700; color: #111827; margin: 0;">🎓 New Scholarships on Brimsom</h1>
      <p style="font-size: 14px; color: #6b7280; margin-top: 8px;">Hi ${name}, here are the latest ${scholarships.length} scholarships added in the last 7 days.</p>
    </div>
    <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9fafb; border-radius: 12px; overflow: hidden;">
      ${scholarshipRows}
    </table>
    <div style="text-align: center; margin-top: 32px;">
      <a href="https://brimsommatch.lovable.app/scholarships?tab=new" style="display: inline-block; padding: 14px 32px; background-color: #2563eb; color: #ffffff; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 15px;">Browse Newly Added</a>
    </div>
    <p style="text-align: center; font-size: 14px; color: #374151; margin-top: 20px;">
      🔥 Don't forget to <a href="https://brimsommatch.lovable.app/score" style="color: #2563eb; font-weight: 600;">check your Match Score</a> to see how well you fit these new opportunities!
    </p>
    <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 32px 0 16px;" />
    <p style="text-align: center; font-size: 11px; color: #9ca3af;">
      You're receiving this because you opted in to scholarship digests on Brimsom.<br/>
      To unsubscribe, go to Settings in the app and turn off "Scholarship Digest".
    </p>
  </div>
</body>
</html>`

    try {
      await sendLovableEmail(
        {
          to: email,
          from: 'Brimsom <noreply@notify.brimsom.com>',
          sender_domain: 'notify.brimsom.com',
          subject: `🎓 ${scholarships.length} New Scholarship${scholarships.length > 1 ? 's' : ''} Added on Brimsom`,
          html,
          text: plainText,
          purpose: 'transactional',
          label: 'scholarship_digest',
          idempotency_key: idempotencyKey,
          unsubscribe_token: unsubscribeToken,
        },
        { apiKey, sendUrl: Deno.env.get('LOVABLE_SEND_URL') }
      )

      // Log success
      await supabase.from('email_send_log').insert({
        message_id: idempotencyKey,
        template_name: 'scholarship_digest',
        recipient_email: email,
        status: 'sent',
      })

      sent++
      console.log('Digest sent to', email)
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error)
      console.error('Failed to send digest to', email, errorMsg)

      await supabase.from('email_send_log').insert({
        message_id: idempotencyKey,
        template_name: 'scholarship_digest',
        recipient_email: email,
        status: 'failed',
        error_message: errorMsg.slice(0, 1000),
      })

      failed++
    }

    // Small delay between sends
    await new Promise((r) => setTimeout(r, 200))
  }

  console.log(`Digest complete: sent=${sent}, skipped=${skipped}, failed=${failed}`)

  return new Response(
    JSON.stringify({ sent, skipped, failed, total_scholarships: scholarships.length }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
})
