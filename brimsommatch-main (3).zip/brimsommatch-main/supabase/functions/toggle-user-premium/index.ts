import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const VALID_PLANS = ["free", "standard", "pro", "pro_plus"] as const;
type Plan = (typeof VALID_PLANS)[number];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } },
    );

    // Auth (signing-keys friendly)
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsErr } = await supabaseAdmin.auth.getClaims(token);
    if (claimsErr || !claimsData?.claims?.sub) throw new Error("Authentication failed");
    const callerId = claimsData.claims.sub as string;

    const { data: isAdmin } = await supabaseAdmin.rpc("has_role", {
      _user_id: callerId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Unauthorized: admin role required");

    const body = await req.json().catch(() => ({}));
    const target_user_id = body.target_user_id as string | undefined;
    const plan = body.plan as Plan | undefined;
    if (!target_user_id || !plan) throw new Error("Missing target_user_id or plan");
    if (!VALID_PLANS.includes(plan)) throw new Error("Invalid plan");

    // Look up the current subscription so we don't clobber real Stripe data
    const { data: currentSub } = await supabaseAdmin
      .from("user_subscriptions")
      .select("plan, stripe_subscription_id, stripe_customer_id")
      .eq("user_id", target_user_id)
      .maybeSingle();

    const hasRealStripeSub =
      !!currentSub?.stripe_subscription_id &&
      currentSub.stripe_subscription_id !== "admin_granted";

    if (plan === "free") {
      // Refuse to revoke a real paid Stripe subscription from the admin panel.
      // The user must cancel via Stripe / customer portal so billing actually stops.
      if (hasRealStripeSub) {
        throw new Error(
          "This user has an active Stripe subscription. Cancel it in Stripe (or via their billing portal) instead of revoking here.",
        );
      }

      // Revoke an admin-granted plan: flip to free WITHOUT touching Stripe IDs
      // (in the admin-granted case stripe_subscription_id is the literal string "admin_granted",
      // so it's safe to clear, but leaving it as-is causes no harm either).
      await supabaseAdmin
        .from("user_subscriptions")
        .upsert(
          {
            user_id: target_user_id,
            plan: "free",
            is_active: true,
            stripe_subscription_id: null,
            stripe_customer_id: null,
            expires_at: null,
            updated_at: new Date().toISOString(),
          },
          { onConflict: "user_id" },
        );
    } else {
      // Grant a plan manually. Preserve any real Stripe IDs already on the row;
      // only mark as admin_granted when there is no existing Stripe link.
      const stripeSubId = hasRealStripeSub
        ? currentSub!.stripe_subscription_id
        : "admin_granted";
      const stripeCustomerId = hasRealStripeSub
        ? currentSub!.stripe_customer_id
        : null;

      await supabaseAdmin
        .from("user_subscriptions")
        .upsert(
          {
            user_id: target_user_id,
            plan,
            is_active: true,
            stripe_subscription_id: stripeSubId,
            stripe_customer_id: stripeCustomerId,
            expires_at: null,
            started_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          { onConflict: "user_id" },
        );
    }

    return new Response(JSON.stringify({ success: true, plan }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    return new Response(JSON.stringify({ error: msg }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 400,
    });
  }
});
