# iOS Submission Templates

These files are **not** auto-copied into the Xcode project. After you run `npx cap add ios` on your Mac, copy them into the native project as noted below, then commit.

## 1. `PrivacyInfo.xcprivacy` → `ios/App/App/PrivacyInfo.xcprivacy`
Required by Apple since May 2024. Drag it into the Xcode project navigator and make sure it's added to the **App** target.

## 2. `Info.plist.snippet.xml` → merge into `ios/App/App/Info.plist`
Add the keys to the root `<dict>`. Remove any usage-description keys for features you don't use.

## 3. `App.entitlements` → `ios/App/App/App.entitlements`
Then in Xcode → Target **App** → **Signing & Capabilities**, add:
- Push Notifications
- Sign in with Apple
- Background Modes → check **Remote notifications**

Set the entitlements file path under **Build Settings → Code Signing Entitlements** if Xcode doesn't link it automatically.

## 4. APNs key
Create a `.p8` APNs Auth Key in the Apple Developer console and upload it to the backend so push notifications fan out via APNs.

## 5. Icons & launch screen
Replace the Capacitor placeholders in `ios/App/App/Assets.xcassets/AppIcon.appiconset/` and `Splash.imageset/`.
