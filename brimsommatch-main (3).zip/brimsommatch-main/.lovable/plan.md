## Automatic Publish — annual auto-republish per scholarship

### What it does
- Each scholarship gets an optional **Automatic Publish** switch.
- When ON, every year on the **month/day** of the earliest intake's `open_date`, a daily job:
  1. Rolls every intake on that scholarship: `open_date += 1 year`, `close_date += 1 year`.
  2. Sets `is_active = true`, `status = 'approved'`.
  3. Skips the scholarship entirely if it is already `is_active = true` (per your choice).
  4. Logs the run in `activity_log`.
- The `next_close_date` trigger already in place will refresh automatically once intakes shift.
- The toggle is visible **only to the main admin** — defined as the earliest-assigned row in `user_roles` where `role = 'admin'`. Other admins/moderators see the scholarship form/approval UI exactly as today (no toggle, no read of the field).

### Database (one migration)
- `scholarships.auto_publish_enabled boolean NOT NULL DEFAULT false`.
- `user_roles.created_at timestamptz NOT NULL DEFAULT now()` (currently missing — needed to pick "first admin" deterministically).
- New SECURITY DEFINER function `public.is_main_admin(_user_id uuid) RETURNS boolean` → true iff `_user_id` is the row with `MIN(created_at)` (ties broken by `id`) among `role='admin'`.
- RLS update on `scholarships`: existing admin update policy stays, but add a CHECK that prevents non-main admins from changing `auto_publish_enabled` (enforced via a `BEFORE UPDATE` trigger that resets the column to `OLD.auto_publish_enabled` unless `is_main_admin(auth.uid())`). Same trigger on INSERT forces `auto_publish_enabled = false` unless main admin.

### Cron + edge function
- New edge function `auto-publish-scholarships` (service-role): finds scholarships where `auto_publish_enabled = true`, `is_active = false`, and an intake exists with `extract(month from open_date) = today.month AND extract(day from open_date) = today.day`. For each:
  - `UPDATE scholarship_intakes SET open_date = open_date + interval '1 year', close_date = close_date + interval '1 year' WHERE scholarship_id = $1`.
  - `UPDATE scholarships SET is_active = true, status = 'approved' WHERE id = $1`.
  - Insert one `activity_log` row.
- `pg_cron` job runs the function daily at 03:00 UTC (`net.http_post` to the function URL). Created via `supabase--insert` (not migration) because it embeds the function URL + anon key.

### Frontend
- New hook `useIsMainAdmin()` → calls `is_main_admin(auth.uid())` RPC, cached.
- `src/components/admin/ScholarshipForm.tsx`: add `auto_publish_enabled` to the zod schema + defaults; render a `<Switch>` with label "Automatic yearly publish" and a one-line description, **only when `useIsMainAdmin()` returns true**. Hidden for moderators/regular admins.
- `src/components/admin/PendingApprovalsTab.tsx`: in the approval row, surface the same toggle for the main admin so they can flip it during approval. Save in the same approve mutation.
- `src/integrations/supabase/types.ts` regenerates after migration → picks up new column automatically.

### Verification
- Set a test scholarship's intake `open_date` to today, enable auto-publish, set `is_active = false`. Invoke the edge function manually → intake dates jump +1 year, scholarship goes active, `next_close_date` refreshes.
- Confirm a non-main admin saving the form does not flip the field (trigger guards it).

### Out of scope
- No notification/email on auto-publish (can add later if you want).
- No "preview upcoming auto-publishes" admin dashboard view (can add later).

Approve and I'll ship the migration + code in one go.