import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Crown, Zap } from "lucide-react";
import type { PlanId } from "@/lib/subscriptionTiers";

interface UpgradeBannerProps {
  feature: string;
  currentPlan: PlanId;
  usage: number;
  limit: number;
  period: string;
  className?: string;
}

export default function UpgradeBanner({
  feature,
  currentPlan,
  usage,
  limit,
  period,
  className = "",
}: UpgradeBannerProps) {
  const navigate = useNavigate();
  const periodLabel =
    period === "day"
      ? "today"
      : period === "month"
      ? "this month"
      : period === "2month"
      ? "in this 2-month window"
      : "in total";
  const limitLabel = limit === Infinity ? "∞" : limit;

  return (
    <div
      className={`rounded-3xl border border-primary/20 bg-primary/5 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-3 ${className}`}
      role="alert"
    >
      <div className="h-10 w-10 shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
        <Crown className="h-5 w-5 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-foreground">
          You've reached your {feature.replace(/_/g, " ")} limit {periodLabel}
        </p>
        <p className="text-xs text-muted-foreground mt-0.5">
          Used {usage}/{limitLabel} on your{" "}
          <span className="capitalize font-medium">{currentPlan}</span> plan.
          Upgrade to keep going.
        </p>
      </div>
      <Button
        size="sm"
        onClick={() => navigate("/pricing")}
        className="shrink-0 w-full sm:w-auto"
      >
        <Zap className="h-4 w-4 mr-2" />
        Upgrade
      </Button>
    </div>
  );
}
