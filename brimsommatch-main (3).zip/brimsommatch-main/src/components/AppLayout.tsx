import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import AppNav from "@/components/AppNav";
import BottomNav from "@/components/BottomNav";
import FollowUpDialog from "@/components/FollowUpDialog";
import ProfileCompletionBanner from "@/components/ProfileCompletionBanner";

export default function AppLayout({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("min-h-dvh flex flex-col bg-background overflow-x-hidden max-w-full", className)}>
      {/* Soft teal gradient header wash */}
      <div
        className="fixed inset-x-0 top-0 pointer-events-none z-0"
        style={{ background: "var(--gradient-top)", height: "calc(18rem + env(safe-area-inset-top, 0px))" }}
      />
      <div className="relative z-10 flex flex-col min-h-dvh">
        <AppNav />
        <div
          className="flex-1 min-h-0 flex flex-col pb-16 lg:pb-0"
          style={{ paddingTop: "calc(4rem + env(safe-area-inset-top, 0px))" }}
        >
          <ProfileCompletionBanner />
          {children}
        </div>

        <BottomNav />
        <FollowUpDialog />
      </div>
    </div>
  );
}
