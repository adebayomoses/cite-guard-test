import { usePWAInstall } from "@/hooks/usePWAInstall";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { Button } from "@/components/ui/button";
import { Download, X, Share } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

export default function PWAInstallBanner() {
  const { canInstall, isIOS, promptInstall, dismiss } = usePWAInstall();
  const { settings, isLoading } = useSiteSettings();

  const pwaPromptEnabled = settings.show_pwa_install_prompt !== "false";

  if (isLoading || !pwaPromptEnabled || !canInstall) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-md rounded-xl border border-border bg-card p-4 shadow-lg"
      >
        <button
          onClick={dismiss}
          aria-label="Dismiss"
          className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-start gap-3 pr-6">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <Download className="h-5 w-5 text-primary" />
          </div>

          <div className="space-y-2">
            <p className="text-sm font-semibold text-foreground">
              Install Brimsom
            </p>

            {isIOS ? (
              <p className="text-xs text-muted-foreground">
                Tap <Share className="inline h-3.5 w-3.5 -translate-y-px" /> then{" "}
                <span className="font-medium text-foreground">"Add to Home Screen"</span>
              </p>
            ) : (
              <>
                <p className="text-xs text-muted-foreground">
                  Get the full app experience — faster access, offline support &amp; notifications.
                </p>
                <div className="flex gap-2">
                  <Button size="sm" onClick={promptInstall}>
                    Install
                  </Button>
                  <Button size="sm" variant="ghost" onClick={dismiss}>
                    Not now
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
