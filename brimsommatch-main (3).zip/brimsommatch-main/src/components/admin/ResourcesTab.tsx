import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Pencil, Trash2, FolderPlus } from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function ResourcesTab() {
  const qc = useQueryClient();
  const [tabDialog, setTabDialog] = useState(false);
  const [editingTab, setEditingTab] = useState<any>(null);
  const [tabName, setTabName] = useState("");
  const [tabOrder, setTabOrder] = useState(0);

  const [resDialog, setResDialog] = useState(false);
  const [editingRes, setEditingRes] = useState<any>(null);
  const [resTitle, setResTitle] = useState("");
  const [resDesc, setResDesc] = useState("");
  const [resYoutube, setResYoutube] = useState("");
  const [resLink, setResLink] = useState("");
  const [resTabId, setResTabId] = useState("");
  const [resOrder, setResOrder] = useState(0);

  const { data: tabs = [] } = useQuery({
    queryKey: ["resource-tabs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("resource_tabs").select("*").order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: resources = [], isLoading } = useQuery({
    queryKey: ["resources"],
    queryFn: async () => {
      const { data, error } = await supabase.from("resources").select("*").order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  // Tab CRUD
  const saveTab = useMutation({
    mutationFn: async () => {
      if (editingTab) {
        const { error } = await supabase.from("resource_tabs").update({ name: tabName, sort_order: tabOrder }).eq("id", editingTab.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("resource_tabs").insert({ name: tabName, sort_order: tabOrder });
        if (error) throw error;
      }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["resource-tabs"] }); setTabDialog(false); toast({ title: "Tab saved" }); },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteTab = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("resource_tabs").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["resource-tabs"] }); qc.invalidateQueries({ queryKey: ["resources"] }); toast({ title: "Tab deleted" }); },
  });

  // Resource CRUD
  const saveRes = useMutation({
    mutationFn: async () => {
      const payload = { title: resTitle, description: resDesc || null, youtube_url: resYoutube || null, link_url: resLink || null, tab_id: resTabId, sort_order: resOrder };
      if (editingRes) {
        const { error } = await supabase.from("resources").update(payload).eq("id", editingRes.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("resources").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["resources"] }); setResDialog(false); toast({ title: "Resource saved" }); },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteRes = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("resources").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["resources"] }); toast({ title: "Resource deleted" }); },
  });

  const openTabCreate = () => { setEditingTab(null); setTabName(""); setTabOrder(0); setTabDialog(true); };
  const openTabEdit = (t: any) => { setEditingTab(t); setTabName(t.name); setTabOrder(t.sort_order); setTabDialog(true); };
  const openResCreate = (tabId?: string) => { setEditingRes(null); setResTitle(""); setResDesc(""); setResYoutube(""); setResLink(""); setResTabId(tabId ?? tabs[0]?.id ?? ""); setResOrder(0); setResDialog(true); };
  const openResEdit = (r: any) => { setEditingRes(r); setResTitle(r.title); setResDesc(r.description ?? ""); setResYoutube(r.youtube_url ?? ""); setResLink(r.link_url ?? ""); setResTabId(r.tab_id); setResOrder(r.sort_order); setResDialog(true); };

  return (
    <TabsContent value="resources">
      {/* Tabs Management */}
      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Resource Categories (Tabs)</CardTitle>
          <Button size="sm" onClick={openTabCreate}><FolderPlus className="h-4 w-4 mr-1" /> New Tab</Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="w-20">Order</TableHead>
                <TableHead className="w-20">Default</TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tabs.map((t: any) => (
                <TableRow key={t.id}>
                  <TableCell className="font-medium">{t.name}</TableCell>
                  <TableCell>{t.sort_order}</TableCell>
                  <TableCell>{t.is_default ? "Yes" : "—"}</TableCell>
                  <TableCell className="text-right space-x-1 whitespace-nowrap">
                    <Button variant="ghost" size="icon" onClick={() => openTabEdit(t)}><Pencil className="h-4 w-4" /></Button>
                    {!t.is_default && (
                      <Button variant="ghost" size="icon" onClick={() => deleteTab.mutate(t.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Resources by Category */}
      {tabs.map((tab: any) => {
        const tabResources = resources.filter((r: any) => r.tab_id === tab.id);
        return (
          <Card key={tab.id} className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">{tab.name} <span className="text-muted-foreground font-normal text-sm">({tabResources.length})</span></CardTitle>
              <Button size="sm" onClick={() => openResCreate(tab.id)}><Plus className="h-4 w-4 mr-1" /> Add Resource</Button>
            </CardHeader>
            <CardContent>
              {tabResources.length === 0 ? (
                <p className="text-center py-6 text-muted-foreground text-sm">No resources in this category yet</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead className="hidden md:table-cell">Type</TableHead>
                      <TableHead className="w-20">Order</TableHead>
                      <TableHead className="w-24 text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tabResources.map((r: any) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{r.title}</TableCell>
                        <TableCell className="hidden md:table-cell text-muted-foreground">{r.youtube_url ? "Video" : "Link"}</TableCell>
                        <TableCell>{r.sort_order}</TableCell>
                        <TableCell className="text-right space-x-1 whitespace-nowrap">
                          <Button variant="ghost" size="icon" onClick={() => openResEdit(r)}><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => deleteRes.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        );
      })}

      {/* Tab Dialog */}
      <Dialog open={tabDialog} onOpenChange={setTabDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingTab ? "Edit Tab" : "New Tab"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Name</Label><Input value={tabName} onChange={(e) => setTabName(e.target.value)} /></div>
            <div><Label>Sort Order</Label><Input type="number" value={tabOrder} onChange={(e) => setTabOrder(Number(e.target.value))} /></div>
            <Button className="w-full" onClick={() => saveTab.mutate()} disabled={!tabName.trim() || saveTab.isPending}>
              {saveTab.isPending ? "Saving…" : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Resource Dialog */}
      <Dialog open={resDialog} onOpenChange={setResDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingRes ? "Edit Resource" : "New Resource"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Title</Label><Input value={resTitle} onChange={(e) => setResTitle(e.target.value)} /></div>
            <div><Label>Description (optional)</Label><Textarea value={resDesc} onChange={(e) => setResDesc(e.target.value)} rows={2} /></div>
            <div><Label>YouTube URL (optional)</Label><Input value={resYoutube} onChange={(e) => setResYoutube(e.target.value)} placeholder="https://youtube.com/watch?v=..." /></div>
            <div><Label>External Link URL (optional)</Label><Input value={resLink} onChange={(e) => setResLink(e.target.value)} placeholder="https://..." /></div>
            <div>
              <Label>Category Tab</Label>
              <Select value={resTabId} onValueChange={setResTabId}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {tabs.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Sort Order</Label><Input type="number" value={resOrder} onChange={(e) => setResOrder(Number(e.target.value))} /></div>
            <Button className="w-full" onClick={() => saveRes.mutate()} disabled={!resTitle.trim() || !resTabId || saveRes.isPending}>
              {saveRes.isPending ? "Saving…" : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
