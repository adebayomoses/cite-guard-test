import { useState } from "react";
import { useAppDownloads, type AppDownload } from "@/hooks/useAppDownloads";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Smartphone, Monitor, Apple, Upload, Loader2, Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const PLATFORMS = [
  { key: "android", label: "Android", icon: Smartphone },
  { key: "ios", label: "iOS", icon: Apple },
  { key: "windows", label: "Windows", icon: Monitor },
];

export default function DownloadsTab() {
  const { downloads, isLoading, upsertDownload, uploadFile } = useAppDownloads(true);
  const { settings, upsertSetting } = useSiteSettings();
  const [uploading, setUploading] = useState<string | null>(null);

  const showDownloadButton = settings.show_download_button !== "false";
  const showPwaPrompt = settings.show_pwa_install_prompt !== "false";

  const getDownload = (platform: string) => downloads.find((d) => d.platform === platform);

  const handleFileUpload = async (platform: string, file: File) => {
    setUploading(platform);
    try {
      const result = await uploadFile.mutateAsync({ platform, file });
      await upsertDownload.mutateAsync({
        platform,
        file_url: result.url,
        file_name: result.fileName,
        is_active: true,
      });
      toast({ title: "File uploaded", description: `${platform} app file uploaded successfully.` });
    } catch (e: any) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    }
    setUploading(null);
  };

  const handleVersionChange = async (platform: string, version: string) => {
    try {
      await upsertDownload.mutateAsync({ platform, version });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleToggleActive = async (platform: string, is_active: boolean) => {
    try {
      await upsertDownload.mutateAsync({ platform, is_active });
      toast({ title: is_active ? "Enabled" : "Disabled" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleTogglePwaPrompt = async (show: boolean) => {
    try {
      await upsertSetting.mutateAsync({ key: "show_pwa_install_prompt", value: show ? "true" : "false" });
      toast({ title: show ? "PWA install prompt enabled" : "PWA install prompt disabled" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleToggleButton = async (show: boolean) => {
    try {
      await upsertSetting.mutateAsync({ key: "show_download_button", value: show ? "true" : "false" });
      toast({ title: show ? "Download button shown" : "Download button hidden" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <TabsContent value="downloads">
      <div className="space-y-6 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2"><Download className="h-5 w-5" /> Download Button</span>
              <Switch checked={showDownloadButton} onCheckedChange={handleToggleButton} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              {showDownloadButton ? "The download button is visible on the landing page." : "The download button is hidden from the landing page."}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2"><Smartphone className="h-5 w-5" /> PWA Install Prompt</span>
              <Switch checked={showPwaPrompt} onCheckedChange={handleTogglePwaPrompt} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              {showPwaPrompt
                ? "The \"Install Brimsom\" banner is shown to eligible visitors on the website."
                : "The \"Install Brimsom\" banner is disabled and will not appear on the website."}
            </p>
          </CardContent>
        </Card>

        {PLATFORMS.map(({ key, label, icon: Icon }) => {
          const dl = getDownload(key);
          return (
            <Card key={key}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Icon className="h-5 w-5" /> {label}
                  </span>
                  <div className="flex items-center gap-2">
                    {dl?.file_url && <Badge variant="secondary">Uploaded</Badge>}
                    <Switch
                      checked={dl?.is_active ?? false}
                      onCheckedChange={(v) => handleToggleActive(key, v)}
                    />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Version</Label>
                  <Input
                    placeholder="e.g. 1.0.0"
                    defaultValue={dl?.version ?? ""}
                    onBlur={(e) => handleVersionChange(key, e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Store / Download Link</Label>
                  <Input
                    type="url"
                    placeholder="https://play.google.com/... or https://apps.apple.com/..."
                    defaultValue={dl?.file_url ?? ""}
                    onBlur={async (e) => {
                      const url = e.target.value.trim();
                      if (url === (dl?.file_url ?? "")) return;
                      try {
                        await upsertDownload.mutateAsync({
                          platform: key,
                          file_url: url || null,
                          file_name: url ? null : dl?.file_name ?? null,
                          is_active: true,
                        });
                        toast({ title: "Link saved" });
                      } catch (err: any) {
                        toast({ title: "Error", description: err.message, variant: "destructive" });
                      }
                    }}
                  />
                  <p className="text-xs text-muted-foreground">Paste an App Store / Play Store / website URL, or upload a file below.</p>
                </div>
                <div className="space-y-2">
                  <Label>Or Upload App File</Label>
                  {dl?.file_name && (
                    <p className="text-sm text-muted-foreground">Current file: {dl.file_name}</p>
                  )}
                  <div className="flex items-center gap-2">
                    <Input
                      type="file"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(key, file);
                      }}
                      disabled={uploading === key}
                    />
                    {uploading === key && <Loader2 className="h-4 w-4 animate-spin" />}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </TabsContent>
  );
}
