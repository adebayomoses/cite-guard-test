import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil, Trash2, ArrowUp, ArrowDown, ExternalLink } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface InfoSource {
  id: string;
  name: string;
  url: string;
  sort_order: number;
  is_active: boolean;
}

export default function InfoSourcesTab() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", url: "" });

  const { data: sources = [], isLoading } = useQuery({
    queryKey: ["info-sources-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("info_sources" as any)
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return data as unknown as InfoSource[];
    },
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["info-sources-admin"] });

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (editingId) {
        const { error } = await supabase
          .from("info_sources" as any)
          .update({ name: form.name, url: form.url, updated_at: new Date().toISOString() } as any)
          .eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("info_sources" as any)
          .insert({ name: form.name, url: form.url, sort_order: sources.length } as any);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      invalidate();
      setDialogOpen(false);
      toast({ title: editingId ? "Source updated" : "Source added" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("info_sources" as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast({ title: "Source deleted" }); },
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("info_sources" as any)
        .update({ is_active, updated_at: new Date().toISOString() } as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const swapOrder = useMutation({
    mutationFn: async ({ a, b }: { a: InfoSource; b: InfoSource }) => {
      await Promise.all([
        supabase.from("info_sources" as any).update({ sort_order: b.sort_order } as any).eq("id", a.id),
        supabase.from("info_sources" as any).update({ sort_order: a.sort_order } as any).eq("id", b.id),
      ]);
    },
    onSuccess: invalidate,
  });

  const openCreate = () => { setEditingId(null); setForm({ name: "", url: "" }); setDialogOpen(true); };
  const openEdit = (s: InfoSource) => { setEditingId(s.id); setForm({ name: s.name, url: s.url }); setDialogOpen(true); };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold">Info Sources</h2>
        <Button onClick={openCreate} size="sm"><Plus className="h-4 w-4 mr-1" /> Add Source</Button>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Order</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>URL</TableHead>
              <TableHead className="w-20">Active</TableHead>
              <TableHead className="w-32">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : sources.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No info sources yet</TableCell></TableRow>
            ) : sources.map((s, i) => (
              <TableRow key={s.id}>
                <TableCell>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === 0} onClick={() => swapOrder.mutate({ a: s, b: sources[i - 1] })}>
                      <ArrowUp className="h-3 w-3" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === sources.length - 1} onClick={() => swapOrder.mutate({ a: s, b: sources[i + 1] })}>
                      <ArrowDown className="h-3 w-3" />
                    </Button>
                  </div>
                </TableCell>
                <TableCell className="font-medium">{s.name}</TableCell>
                <TableCell>
                  <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline flex items-center gap-1 text-sm truncate max-w-xs">
                    {s.url} <ExternalLink className="h-3 w-3 shrink-0" />
                  </a>
                </TableCell>
                <TableCell>
                  <Switch checked={s.is_active} onCheckedChange={(checked) => toggleActive.mutate({ id: s.id, is_active: checked })} />
                </TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => deleteMutation.mutate(s.id)}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Source" : "Add Info Source"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Scholarship Portal" />
            </div>
            <div>
              <Label>URL</Label>
              <Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://example.com" />
            </div>
            <Button onClick={() => saveMutation.mutate()} disabled={!form.name || !form.url || saveMutation.isPending} className="w-full">
              {saveMutation.isPending ? "Saving…" : editingId ? "Update" : "Add Source"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
