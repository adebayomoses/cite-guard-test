import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Star, Eye, Trash2, Check, X, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface Testimonial {
  id: string;
  name: string;
  email: string | null;
  message: string;
  rating: number | null;
  image_url: string | null;
  is_approved: boolean;
  created_at: string;
  published_at: string | null;
}

// Convert ISO string to <input type="datetime-local"> value (local TZ, no seconds)
function isoToLocalInput(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function localInputToIso(value: string): string | null {
  if (!value) return null;
  return new Date(value).toISOString();
}

export default function TestimonialsTab() {
  const qc = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "approved">("pending");
  const [editing, setEditing] = useState<Testimonial | null>(null);
  const [editName, setEditName] = useState("");
  const [editMessage, setEditMessage] = useState("");
  const [editRating, setEditRating] = useState(5);
  const [editPublishedAt, setEditPublishedAt] = useState("");

  const { data: testimonials = [], isLoading } = useQuery({
    queryKey: ["admin-testimonials"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).rpc("admin_list_testimonials");
      if (error) throw error;
      return (data ?? []) as Testimonial[];
    },
  });

  const filtered = testimonials.filter((t) => {
    if (statusFilter === "pending") return !t.is_approved;
    if (statusFilter === "approved") return t.is_approved;
    return true;
  });

  const setApproved = useMutation({
    mutationFn: async ({ id, is_approved, current }: { id: string; is_approved: boolean; current: Testimonial }) => {
      const update: Record<string, unknown> = { is_approved };
      if (is_approved && !current.published_at) {
        update.published_at = new Date().toISOString();
      }
      const { error } = await (supabase as any)
        .from("testimonials")
        .update(update)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["admin-testimonials"] });
      qc.invalidateQueries({ queryKey: ["public-testimonials"] });
      toast({ title: vars.is_approved ? "Posted to blog" : "Unpublished" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteOne = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from("testimonials").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-testimonials"] });
      qc.invalidateQueries({ queryKey: ["public-testimonials"] });
      toast({ title: "Testimonial deleted" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const saveEdit = useMutation({
    mutationFn: async () => {
      if (!editing) return;
      const { error } = await (supabase as any)
        .from("testimonials")
        .update({
          name: editName.trim(),
          message: editMessage.trim(),
          rating: editRating,
          published_at: localInputToIso(editPublishedAt),
        })
        .eq("id", editing.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-testimonials"] });
      qc.invalidateQueries({ queryKey: ["public-testimonials"] });
      toast({ title: "Testimonial updated" });
      setEditing(null);
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const openEdit = (t: Testimonial) => {
    setEditing(t);
    setEditName(t.name);
    setEditMessage(t.message);
    setEditRating(t.rating ?? 5);
    setEditPublishedAt(isoToLocalInput(t.published_at));
  };

  const pendingCount = testimonials.filter((t) => !t.is_approved).length;
  const approvedCount = testimonials.filter((t) => t.is_approved).length;

  return (
    <TabsContent value="testimonials">
      <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <div className="flex gap-2 text-sm">
          <Badge variant="outline">Pending: {pendingCount}</Badge>
          <Badge variant="outline">Approved: {approvedCount}</Badge>
        </div>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="all">All</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Photo</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Submitted</TableHead>
              <TableHead className="hidden md:table-cell">Published</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No testimonials</TableCell></TableRow>
            ) : filtered.map((t) => (
              <TableRow key={t.id}>
                <TableCell className="font-medium">
                  {t.name}
                  {t.email && <div className="text-xs text-muted-foreground">{t.email}</div>}
                </TableCell>
                <TableCell>
                  {t.image_url ? (
                    <a href={t.image_url} target="_blank" rel="noopener noreferrer">
                      <img src={t.image_url} alt={t.name} className="h-12 w-12 rounded-md object-cover border border-border" />
                    </a>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map((n) => (
                      <Star key={n} className={cn("h-3.5 w-3.5", (t.rating ?? 0) >= n ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")} />
                    ))}
                  </div>
                </TableCell>
                <TableCell className="max-w-[300px]">
                  <p className="text-sm line-clamp-2">{t.message}</p>
                </TableCell>
                <TableCell>
                  {t.is_approved ? (
                    <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Posted</Badge>
                  ) : (
                    <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending</Badge>
                  )}
                </TableCell>
                <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                  {format(new Date(t.created_at), "MMM d, yyyy")}
                </TableCell>
                <TableCell className="hidden md:table-cell text-muted-foreground text-sm">
                  {t.published_at ? format(new Date(t.published_at), "MMM d, yyyy") : "—"}
                </TableCell>
                <TableCell className="text-right space-x-1 whitespace-nowrap">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(t)} title="View / Edit">
                    <Eye className="h-4 w-4" />
                  </Button>
                  {t.is_approved ? (
                    <Button variant="outline" size="sm" onClick={() => setApproved.mutate({ id: t.id, is_approved: false, current: t })} disabled={setApproved.isPending}>
                      <X className="h-3.5 w-3.5 mr-1" />Unpublish
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => setApproved.mutate({ id: t.id, is_approved: true, current: t })} disabled={setApproved.isPending}>
                      <Check className="h-3.5 w-3.5 mr-1" />Post
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => {
                    if (confirm("Delete this testimonial?")) deleteOne.mutate(t.id);
                  }}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="sm:max-w-lg max-w-[calc(100vw-2rem)]">
          <DialogHeader><DialogTitle>Edit Testimonial</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4">
              {editing.image_url && (
                <div className="space-y-2">
                  <Label>Photo</Label>
                  <a href={editing.image_url} target="_blank" rel="noopener noreferrer" className="block">
                    <img src={editing.image_url} alt={editing.name} className="max-h-48 rounded-lg object-cover border border-border" />
                  </a>
                </div>
              )}
              <div className="space-y-2">
                <Label>Name</Label>
                <Input value={editName} onChange={(e) => setEditName(e.target.value)} maxLength={100} />
              </div>
              <div className="space-y-2">
                <Label>Rating</Label>
                <div className="flex gap-1">
                  {[1,2,3,4,5].map((n) => (
                    <button key={n} type="button" onClick={() => setEditRating(n)} className="p-1">
                      <Star className={cn("h-6 w-6", editRating >= n ? "fill-amber-400 text-amber-400" : "text-muted-foreground")} />
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label>Message</Label>
                <Textarea value={editMessage} onChange={(e) => setEditMessage(e.target.value)} rows={6} maxLength={1000} />
                <p className="text-xs text-muted-foreground text-right">{editMessage.length}/1000</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="t-pub-date">Publish date (shown to viewers)</Label>
                <Input
                  id="t-pub-date"
                  type="datetime-local"
                  value={editPublishedAt}
                  onChange={(e) => setEditPublishedAt(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">Leave empty to hide the published date.</p>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
                <Button onClick={() => saveEdit.mutate()} disabled={saveEdit.isPending}>
                  {saveEdit.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Save
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
