import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Loader2, Search, Pencil, BookOpen, Sparkles } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const DOC_TYPES = [
  { value: "sop", label: "SOP / Statement of Purpose" },
  { value: "personal_statement", label: "Personal Statement" },
  { value: "motivation_letter", label: "Motivation Letter" },
  { value: "essay", label: "Essay" },
  { value: "cover_letter", label: "Cover Letter" },
  { value: "recommendation_letter", label: "Recommendation Letter" },
  { value: "study_plan", label: "Study Plan" },
  { value: "research_proposal", label: "Research Proposal" },
];

type Essay = {
  id: string;
  title: string;
  document_type: string;
  scholarship_name: string | null;
  country: string | null;
  field_of_study: string | null;
  degree_level: string | null;
  year_won: number | null;
  author_name: string | null;
  is_anonymized: boolean;
  content: string;
  tags: string[];
  notes: string | null;
  file_url: string | null;
  embedding: unknown | null;
  embedding_updated_at: string | null;
  created_at: string;
};

const empty = {
  title: "",
  document_type: "sop",
  scholarship_name: "",
  country: "",
  field_of_study: "",
  degree_level: "",
  year_won: "",
  author_name: "",
  is_anonymized: true,
  content: "",
  tags: "",
  notes: "",
};

export default function EssayLibraryTab() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [docFilter, setDocFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(empty);
  const [viewing, setViewing] = useState<Essay | null>(null);

  const { data: essays = [], isLoading } = useQuery({
    queryKey: ["winning-essays"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("winning_essays" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Essay[];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Not authenticated");
      if (!form.title.trim() || !form.content.trim()) {
        throw new Error("Title and content are required");
      }
      const payload = {
        title: form.title.trim(),
        document_type: form.document_type,
        scholarship_name: form.scholarship_name.trim() || null,
        country: form.country.trim() || null,
        field_of_study: form.field_of_study.trim() || null,
        degree_level: form.degree_level.trim() || null,
        year_won: form.year_won ? parseInt(form.year_won, 10) : null,
        author_name: form.author_name.trim() || null,
        is_anonymized: form.is_anonymized,
        content: form.content.trim(),
        tags: form.tags.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean),
        notes: form.notes.trim() || null,
      };
      let savedId = editingId;
      if (editingId) {
        const { error } = await supabase.from("winning_essays" as any).update(payload).eq("id", editingId);
        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from("winning_essays" as any)
          .insert({ ...payload, created_by: user.id })
          .select("id")
          .single();
        if (error) throw error;
        savedId = (data as any)?.id ?? null;
      }
      // Generate embedding (non-fatal if it fails)
      if (savedId) {
        try {
          await supabase.functions.invoke("embed-essay", { body: { essay_id: savedId } });
        } catch (e) {
          console.warn("Embedding generation failed:", e);
        }
      }
    },
    onSuccess: () => {
      toast({ title: editingId ? "Essay updated" : "Essay added" });
      qc.invalidateQueries({ queryKey: ["winning-essays"] });
      setOpen(false);
      setEditingId(null);
      setForm(empty);
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const embedAll = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke("embed-essay", { body: { all: true } });
      if (error) throw error;
      return data as { processed: number; failed: number; total: number };
    },
    onSuccess: (r) => {
      toast({ title: "Embeddings refreshed", description: `Processed ${r.processed} of ${r.total} (failed: ${r.failed})` });
      qc.invalidateQueries({ queryKey: ["winning-essays"] });
    },
    onError: (e: any) => toast({ title: "Embedding error", description: e.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("winning_essays" as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Essay deleted" });
      qc.invalidateQueries({ queryKey: ["winning-essays"] });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const openNew = () => {
    setEditingId(null);
    setForm(empty);
    setOpen(true);
  };

  const openEdit = (e: Essay) => {
    setEditingId(e.id);
    setForm({
      title: e.title,
      document_type: e.document_type,
      scholarship_name: e.scholarship_name ?? "",
      country: e.country ?? "",
      field_of_study: e.field_of_study ?? "",
      degree_level: e.degree_level ?? "",
      year_won: e.year_won?.toString() ?? "",
      author_name: e.author_name ?? "",
      is_anonymized: e.is_anonymized,
      content: e.content,
      tags: e.tags.join(", "),
      notes: e.notes ?? "",
    });
    setOpen(true);
  };

  const filtered = essays.filter((e) => {
    if (docFilter !== "all" && e.document_type !== docFilter) return false;
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      e.title.toLowerCase().includes(q) ||
      (e.scholarship_name ?? "").toLowerCase().includes(q) ||
      (e.country ?? "").toLowerCase().includes(q) ||
      (e.field_of_study ?? "").toLowerCase().includes(q) ||
      e.tags.some((t) => t.includes(q))
    );
  });

  return (
    <TabsContent value="essays">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" /> Essay Library
          </h2>
          <p className="text-sm text-muted-foreground">
            Winning SOPs, personal statements, and motivation letters used as style references when Brim writes for users.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => embedAll.mutate()} disabled={embedAll.isPending}>
            {embedAll.isPending ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Sparkles className="h-4 w-4 mr-1" />}
            Re-embed missing
          </Button>
          <Button onClick={openNew}>
            <Plus className="h-4 w-4 mr-1" /> Add Essay
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search title, scholarship, country, field, tags…"
            className="pl-9"
          />
        </div>
        <Select value={docFilter} onValueChange={setDocFilter}>
          <SelectTrigger className="w-full sm:w-[220px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {DOC_TYPES.map((d) => <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead className="hidden md:table-cell">Type</TableHead>
              <TableHead className="hidden md:table-cell">Country</TableHead>
              <TableHead className="hidden lg:table-cell">Field</TableHead>
              <TableHead className="hidden lg:table-cell">Degree</TableHead>
              <TableHead className="hidden md:table-cell">Year</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No essays yet. Add winning SOPs/letters to power Brim's writing.</TableCell></TableRow>
            ) : filtered.map((e) => (
              <TableRow key={e.id}>
                <TableCell className="font-medium">
                  <button className="text-left hover:underline" onClick={() => setViewing(e)}>
                    {e.title}
                  </button>
                  <div className="flex items-center gap-2 mt-0.5">
                    {e.scholarship_name && (
                      <span className="text-xs text-muted-foreground truncate max-w-[220px]">{e.scholarship_name}</span>
                    )}
                    {e.embedding ? (
                      <Badge variant="secondary" className="text-[10px] py-0 h-4">
                        <Sparkles className="h-2.5 w-2.5 mr-0.5" /> embedded
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-[10px] py-0 h-4 text-muted-foreground">no embedding</Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <Badge variant="secondary" className="text-xs">{DOC_TYPES.find((d) => d.value === e.document_type)?.label ?? e.document_type}</Badge>
                </TableCell>
                <TableCell className="hidden md:table-cell text-sm">{e.country ?? "—"}</TableCell>
                <TableCell className="hidden lg:table-cell text-sm">{e.field_of_study ?? "—"}</TableCell>
                <TableCell className="hidden lg:table-cell text-sm">{e.degree_level ?? "—"}</TableCell>
                <TableCell className="hidden md:table-cell text-sm">{e.year_won ?? "—"}</TableCell>
                <TableCell className="text-right space-x-1 whitespace-nowrap">
                  <Button variant="ghost" size="icon" onClick={() => openEdit(e)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => {
                    if (confirm(`Delete "${e.title}"?`)) remove.mutate(e.id);
                  }}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Add / Edit dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Essay" : "Add Winning Essay"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Title *</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Chevening 2024 — MSc Economics, UK" />
              </div>
              <div className="space-y-1.5">
                <Label>Document Type *</Label>
                <Select value={form.document_type} onValueChange={(v) => setForm({ ...form, document_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DOC_TYPES.map((d) => <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Scholarship Name</Label>
                <Input value={form.scholarship_name} onChange={(e) => setForm({ ...form, scholarship_name: e.target.value })} placeholder="e.g. Chevening Scholarships" />
              </div>
              <div className="space-y-1.5">
                <Label>Country</Label>
                <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} placeholder="e.g. United Kingdom" />
              </div>
              <div className="space-y-1.5">
                <Label>Field of Study</Label>
                <Input value={form.field_of_study} onChange={(e) => setForm({ ...form, field_of_study: e.target.value })} placeholder="e.g. Economics" />
              </div>
              <div className="space-y-1.5">
                <Label>Degree Level</Label>
                <Input value={form.degree_level} onChange={(e) => setForm({ ...form, degree_level: e.target.value })} placeholder="e.g. Master, PhD, Bachelor" />
              </div>
              <div className="space-y-1.5">
                <Label>Year Won</Label>
                <Input type="number" value={form.year_won} onChange={(e) => setForm({ ...form, year_won: e.target.value })} placeholder="e.g. 2024" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Tags (comma separated)</Label>
                <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="e.g. development, leadership, africa, quantitative" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Author Name (optional, kept private)</Label>
                <Input value={form.author_name} onChange={(e) => setForm({ ...form, author_name: e.target.value })} placeholder="Internal reference only" />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Essay Content *</Label>
                <Textarea
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                  rows={14}
                  placeholder="Paste the full essay text here. Anonymize personal details (names, exact institutions) before saving."
                  className="font-mono text-sm"
                />
                <p className="text-xs text-muted-foreground">{form.content.length} characters</p>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label>Internal Notes</Label>
                <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="Why this is a strong example, what to learn from it…" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate()} disabled={save.isPending}>
              {save.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editingId ? "Save Changes" : "Add Essay"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View dialog */}
      <Dialog open={!!viewing} onOpenChange={(v) => !v && setViewing(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>{viewing?.title}</DialogTitle>
          </DialogHeader>
          {viewing && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2 text-xs">
                <Badge variant="secondary">{DOC_TYPES.find((d) => d.value === viewing.document_type)?.label}</Badge>
                {viewing.scholarship_name && <Badge variant="outline">{viewing.scholarship_name}</Badge>}
                {viewing.country && <Badge variant="outline">{viewing.country}</Badge>}
                {viewing.field_of_study && <Badge variant="outline">{viewing.field_of_study}</Badge>}
                {viewing.degree_level && <Badge variant="outline">{viewing.degree_level}</Badge>}
                {viewing.year_won && <Badge variant="outline">{viewing.year_won}</Badge>}
              </div>
              {viewing.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {viewing.tags.map((t) => <Badge key={t} className="text-xs" variant="secondary">#{t}</Badge>)}
                </div>
              )}
              <div className="rounded-lg bg-muted p-4 whitespace-pre-wrap text-sm font-mono max-h-[50vh] overflow-y-auto">
                {viewing.content}
              </div>
              {viewing.notes && (
                <div className="text-sm">
                  <div className="font-medium mb-1">Notes</div>
                  <p className="text-muted-foreground whitespace-pre-wrap">{viewing.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
