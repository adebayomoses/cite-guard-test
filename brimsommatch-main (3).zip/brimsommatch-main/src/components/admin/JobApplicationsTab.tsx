import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Download, Trash2, Mail, Phone, Briefcase, FileText, Eye } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "@/hooks/use-toast";

interface JobApplication {
  id: string;
  position: string;
  full_name: string;
  email: string;
  phone: string | null;
  experience: string;
  resume_path: string | null;
  status: string;
  created_at: string;
}

const STATUSES = ["new", "reviewing", "shortlisted", "rejected", "hired"];

export default function JobApplicationsTab() {
  const qc = useQueryClient();
  const [downloading, setDownloading] = useState<string | null>(null);
  const [viewing, setViewing] = useState<string | null>(null);

  const { data: apps = [], isLoading } = useQuery({
    queryKey: ["job-applications"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_applications" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as JobApplication[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ app, status }: { app: JobApplication; status: string }) => {
      const { error } = await supabase.from("job_applications" as any).update({ status }).eq("id", app.id);
      if (error) throw error;
      // Notify applicant for meaningful status changes
      if (["reviewing", "shortlisted", "rejected", "hired"].includes(status) && status !== app.status) {
        try {
          await supabase.functions.invoke("send-transactional-email", {
            body: {
              templateName: "job-application-status",
              recipientEmail: app.email,
              idempotencyKey: `job-status-${app.id}-${status}`,
              templateData: { name: app.full_name, position: app.position, status },
            },
          });
        } catch (e) {
          console.error("Failed to send status email", e);
        }
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-applications"] });
      toast({ title: "Status updated", description: "Applicant has been notified by email." });
    },
  });

  const deleteApp = useMutation({
    mutationFn: async (app: JobApplication) => {
      if (app.resume_path) {
        await supabase.storage.from("job-applications").remove([app.resume_path]);
      }
      const { error } = await supabase.from("job_applications" as any).delete().eq("id", app.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["job-applications"] });
      toast({ title: "Application deleted" });
    },
  });

  const handleDownload = async (path: string, name: string) => {
    setDownloading(path);
    const { data, error } = await supabase.storage.from("job-applications").createSignedUrl(path, 60);
    setDownloading(null);
    if (error || !data) {
      toast({ title: "Could not generate download link", variant: "destructive" });
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  const handleView = async (path: string) => {
    setViewing(path);
    const { data, error } = await supabase.storage.from("job-applications").createSignedUrl(path, 60 * 60);
    setViewing(null);
    if (error || !data) {
      toast({ title: "Could not generate view link", variant: "destructive" });
      return;
    }
    window.open(data.signedUrl, "_blank");
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Job Applications</h2>
          <p className="text-sm text-muted-foreground">{apps.length} total submissions</p>
        </div>
      </div>

      {apps.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            No job applications yet.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {apps.map((app) => (
            <Card key={app.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <CardTitle className="text-base">{app.full_name}</CardTitle>
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Briefcase className="h-3 w-3" /> {app.position}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="outline">{formatDistanceToNow(new Date(app.created_at), { addSuffix: true })}</Badge>
                    <Select value={app.status} onValueChange={(v) => updateStatus.mutate({ app, status: v })}>
                      <SelectTrigger className="h-8 w-[140px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUSES.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-muted-foreground">
                  <a href={`mailto:${app.email}`} className="flex items-center gap-1 hover:text-foreground">
                    <Mail className="h-3.5 w-3.5" /> {app.email}
                  </a>
                  {app.phone && (
                    <a href={`tel:${app.phone}`} className="flex items-center gap-1 hover:text-foreground">
                      <Phone className="h-3.5 w-3.5" /> {app.phone}
                    </a>
                  )}
                </div>
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">Experience</p>
                  <p className="whitespace-pre-wrap text-sm">{app.experience}</p>
                </div>
                <div className="flex gap-2 pt-2">
                  {app.resume_path ? (
                    <>
                      <Button size="sm" variant="outline" onClick={() => handleView(app.resume_path!)} disabled={viewing === app.resume_path}>
                        {viewing === app.resume_path ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Eye className="h-4 w-4 mr-1" />}
                        View
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDownload(app.resume_path!, app.full_name)} disabled={downloading === app.resume_path}>
                        {downloading === app.resume_path ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Download className="h-4 w-4 mr-1" />}
                        Resume
                      </Button>
                    </>
                  ) : (
                    <Badge variant="secondary" className="gap-1"><FileText className="h-3 w-3" /> No resume</Badge>
                  )}
                  <Button size="sm" variant="ghost" className="text-destructive ml-auto"
                    onClick={() => { if (confirm("Delete this application?")) deleteApp.mutate(app); }}>
                    <Trash2 className="h-4 w-4 mr-1" /> Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
