import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Check, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";

interface Props {
  onEdit: (id: string) => void;
}

export default function OldReviewTab({ onEdit }: Props) {
  const queryClient = useQueryClient();

  const { data: scholarships = [], isLoading } = useQuery({
    queryKey: ["old-review-scholarships"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("*")
        .is("reviewed_at" as any, null)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const markDone = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("scholarships")
        .update({ reviewed_at: new Date().toISOString() } as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["old-review-scholarships"] });
      queryClient.invalidateQueries({ queryKey: ["old-review-scholarships-count"] });
      toast({ title: "Marked as reviewed" });
    },
    onError: (e: any) =>
      toast({ title: "Couldn't mark as reviewed", description: e.message, variant: "destructive" }),
  });

  return (
    <TabsContent value="old-review">
      <div className="mb-4 rounded-lg bg-muted/40 border border-border p-3 text-xs text-muted-foreground">
        Walk through every scholarship in the database (oldest first). Click <strong>Edit</strong> to fix issues, or
        <strong> Done</strong> when the entry looks good — it'll disappear from this list. Scholarships stay published
        either way.
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead className="hidden sm:table-cell">Provider</TableHead>
              <TableHead className="hidden md:table-cell">Country</TableHead>
              <TableHead className="hidden md:table-cell">Degree</TableHead>
              <TableHead className="hidden lg:table-cell">Deadline</TableHead>
              <TableHead className="hidden sm:table-cell">Created</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Loading…</TableCell>
              </TableRow>
            ) : scholarships.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-10 text-muted-foreground">
                  All caught up — every scholarship has been reviewed. 🎉
                </TableCell>
              </TableRow>
            ) : (
              scholarships.map((s: any) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium max-w-[180px] sm:max-w-[240px] truncate">{s.title}</TableCell>
                  <TableCell className="hidden sm:table-cell max-w-[160px] truncate text-muted-foreground">
                    {s.provider ?? "—"}
                  </TableCell>
                  <TableCell className="hidden md:table-cell">{s.country ?? "—"}</TableCell>
                  <TableCell className="hidden md:table-cell">{s.degree_level ?? "—"}</TableCell>
                  <TableCell className="hidden lg:table-cell">
                    {s.next_close_date ? format(new Date(s.next_close_date), "MMM d, yyyy") : "—"}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground">
                    {format(new Date(s.created_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell>
                    <Badge variant={s.is_active ? "default" : "secondary"}>
                      {s.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex items-center gap-0.5 whitespace-nowrap">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => onEdit(s.id)}
                        title="Edit scholarship"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 px-2 text-xs"
                        disabled={markDone.isPending}
                        onClick={() => markDone.mutate(s.id)}
                        title="Mark as reviewed"
                      >
                        {markDone.isPending && markDone.variables === s.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <>
                            <Check className="h-3.5 w-3.5 sm:mr-1" />
                            <span className="hidden sm:inline">Done</span>
                          </>
                        )}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </TabsContent>
  );
}
