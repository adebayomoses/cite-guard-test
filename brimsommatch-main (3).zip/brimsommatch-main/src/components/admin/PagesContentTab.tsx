import { useEffect, useState } from "react";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Loader2, FileText } from "lucide-react";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { toast } from "@/hooks/use-toast";
import MarkdownContent from "@/components/MarkdownContent";
import { DEFAULT_ABOUT_MARKDOWN, DEFAULT_PRIVACY_MARKDOWN } from "@/lib/defaultPageContent";

type PageKey = "about_page_content" | "privacy_page_content";

const PAGES: { key: PageKey; title: string; description: string; route: string; defaultContent: string }[] = [
  {
    key: "about_page_content",
    title: "About Us Page",
    description: "Full markdown content shown on the /about page. Leave blank to use the built-in default.",
    route: "/about",
    defaultContent: DEFAULT_ABOUT_MARKDOWN,
  },
  {
    key: "privacy_page_content",
    title: "Privacy Policy Page",
    description: "Full markdown content shown on the /privacy page. Leave blank to use the built-in default.",
    route: "/privacy",
    defaultContent: DEFAULT_PRIVACY_MARKDOWN,
  },
];

function PageEditor({ pageKey, title, description, route, defaultContent }: { pageKey: PageKey; title: string; description: string; route: string; defaultContent: string }) {
  const { settings, upsertSetting } = useSiteSettings();
  const [value, setValue] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!loaded && settings) {
      setValue(settings[pageKey] ?? "");
      setLoaded(true);
    }
  }, [settings, pageKey, loaded]);

  const handleSave = async () => {
    try {
      await upsertSetting.mutateAsync({ key: pageKey, value });
      toast({ title: "Saved", description: `${title} updated.` });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <FileText className="h-5 w-5" /> {title}
        </CardTitle>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Markdown content</Label>
          <Textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={`# ${title}\n\nWrite your page content here using markdown...`}
            rows={20}
            className="font-mono text-xs"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleSave} disabled={upsertSetting.isPending}>
            {upsertSetting.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save
          </Button>
          <Button variant="secondary" type="button" onClick={() => setValue(defaultContent)}>
            Load current default
          </Button>
          <Button variant="ghost" type="button" onClick={() => setValue("")}>
            Clear (use built-in)
          </Button>
          <Button variant="outline" asChild>
            <a href={route} target="_blank" rel="noreferrer">Open page</a>
          </Button>
        </div>
        {value.trim() && (
          <div>
            <Label className="mb-2 block">Preview</Label>
            <div className="rounded-lg border border-border bg-card p-4 max-h-96 overflow-auto">
              <MarkdownContent content={value} />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function PagesContentTab() {
  return (
    <TabsContent value="pages">
      <Tabs defaultValue={PAGES[0].key} className="space-y-4">
        <TabsList>
          {PAGES.map((p) => (
            <TabsTrigger key={p.key} value={p.key}>{p.title}</TabsTrigger>
          ))}
        </TabsList>
        {PAGES.map((p) => (
          <TabsContent key={p.key} value={p.key}>
            <PageEditor pageKey={p.key} title={p.title} description={p.description} route={p.route} defaultContent={p.defaultContent} />
          </TabsContent>
        ))}
      </Tabs>
    </TabsContent>
  );
}
