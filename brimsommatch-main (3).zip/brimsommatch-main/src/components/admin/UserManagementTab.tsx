import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCommunityModerators } from "@/hooks/useCommunityModerators";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Shield, ShieldBan, ShieldCheck, UserPlus, UserMinus, Loader2, Crown } from "lucide-react";
import { toast } from "@/hooks/use-toast";

type PlanValue = "free" | "standard" | "pro" | "pro_plus";

export default function UserManagementTab() {
  const [search, setSearch] = useState("");
  const [togglingUser, setTogglingUser] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const { moderatorIds, appointModerator, removeModerator, isCommunityModerator } = useCommunityModerators();

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["admin-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .order("full_name");
      if (error) throw error;
      return data;
    },
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ["admin-subscriptions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_subscriptions")
        .select("user_id, plan, stripe_subscription_id");
      if (error) throw error;
      return data;
    },
  });

  const subMap = new Map(subscriptions.map((s) => [s.user_id, s]));

  const { data: bans = [], refetch: refetchBans } = useQuery({
    queryKey: ["admin-chat-bans"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chat_bans")
        .select("*");
      if (error) throw error;
      return data;
    },
  });

  const { data: autoScoreUsage = [] } = useQuery({
    queryKey: ["admin-auto-score-usage"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_feature_usage_monthly" as any, {
        _feature: "score_generation",
      });
      if (error) throw error;
      return (data as { user_id: string; usage_count: number }[]) ?? [];
    },
  });
  const usageMap = new Map(autoScoreUsage.map((u) => [u.user_id, Number(u.usage_count)]));

  const bannedUserIds = new Set(bans.map((b) => b.user_id));

  const filtered = profiles.filter((p) =>
    !search || (p.full_name ?? "").toLowerCase().includes(search.toLowerCase())
  );

  const getUserPlan = (userId: string): PlanValue => {
    const sub = subMap.get(userId);
    return (sub?.plan as PlanValue) || "free";
  };

  const isAdminGranted = (userId: string) => {
    const sub = subMap.get(userId);
    return sub?.stripe_subscription_id === "admin_granted";
  };

  const handleTogglePremium = async (userId: string, plan: PlanValue) => {
    setTogglingUser(userId);
    try {
      const { data, error } = await supabase.functions.invoke("toggle-user-premium", {
        body: { target_user_id: userId, plan },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      toast({ title: plan === "free" ? "Premium revoked" : `${plan.charAt(0).toUpperCase() + plan.slice(1)} plan granted` });
      queryClient.invalidateQueries({ queryKey: ["admin-subscriptions"] });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setTogglingUser(null);
    }
  };

  const handleGlobalBan = async (userId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("chat_bans").insert({
      user_id: userId,
      banned_by: user.id,
      room_id: null,
      reason: "Banned by admin",
    });
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "User banned from all chat rooms" });
      refetchBans();
    }
  };

  const handleUnban = async (userId: string) => {
    const { error } = await supabase
      .from("chat_bans")
      .delete()
      .eq("user_id", userId);
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "User unbanned" });
      refetchBans();
    }
  };

  const handleAppoint = async (userId: string) => {
    try {
      await appointModerator(userId);
      toast({ title: "Community moderator appointed" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleRemoveMod = async (userId: string) => {
    try {
      await removeModerator(userId);
      toast({ title: "Community moderator removed" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const planBadge = (plan: PlanValue, adminGranted: boolean) => {
    if (plan === "free") return null;
    const label = plan === "pro_plus" ? "Pro+" : plan.charAt(0).toUpperCase() + plan.slice(1);
    return (
      <Badge className="text-xs gap-1 bg-amber-500/15 text-amber-600 border-amber-500/20">
        <Crown className="h-3 w-3" />
        {label}
        {adminGranted && " (Manual)"}
      </Badge>
    );
  };

  return (
    <TabsContent value="users">
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Premium</TableHead>
              <TableHead className="text-center">Auto-Score</TableHead>
              <TableHead className="text-right">Chat Ban</TableHead>
              <TableHead className="text-right">Community Mod</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  Loading…
                </TableCell>
              </TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No users found
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((p) => {
                const isBanned = bannedUserIds.has(p.user_id);
                const isMod = isCommunityModerator(p.user_id);
                const currentPlan = getUserPlan(p.user_id);
                const adminGranted = isAdminGranted(p.user_id);
                const isToggling = togglingUser === p.user_id;
                return (
                  <TableRow key={p.user_id}>
                    <TableCell className="font-medium">{p.full_name || "—"}</TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        {isBanned && (
                          <Badge variant="destructive" className="text-xs gap-1">
                            <ShieldBan className="h-3 w-3" /> Banned
                          </Badge>
                        )}
                        {isMod && (
                          <Badge className="text-xs gap-1 bg-primary/15 text-primary border-primary/20">
                            <Shield className="h-3 w-3" /> Moderator
                          </Badge>
                        )}
                        {planBadge(currentPlan, adminGranted)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Select
                          value={currentPlan}
                          onValueChange={(val) => handleTogglePremium(p.user_id, val as PlanValue)}
                          disabled={isToggling}
                        >
                          <SelectTrigger className="w-[140px] h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="free">Free</SelectItem>
                            <SelectItem value="standard">Standard</SelectItem>
                            <SelectItem value="pro">Pro</SelectItem>
                            <SelectItem value="pro_plus">Pro+</SelectItem>
                          </SelectContent>
                        </Select>
                        {isToggling && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline" className="text-xs font-mono">
                        {usageMap.get(p.user_id) ?? 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {isBanned ? (
                        <Button variant="outline" size="sm" onClick={() => handleUnban(p.user_id)} className="gap-1">
                          <ShieldCheck className="h-3.5 w-3.5" /> Unban
                        </Button>
                      ) : (
                        <Button variant="outline" size="sm" onClick={() => handleGlobalBan(p.user_id)} className="gap-1 text-destructive border-destructive/30">
                          <ShieldBan className="h-3.5 w-3.5" /> Ban
                        </Button>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {isMod ? (
                        <Button variant="outline" size="sm" onClick={() => handleRemoveMod(p.user_id)} className="gap-1">
                          <UserMinus className="h-3.5 w-3.5" /> Remove
                        </Button>
                      ) : (
                        <Button variant="outline" size="sm" onClick={() => handleAppoint(p.user_id)} className="gap-1">
                          <UserPlus className="h-3.5 w-3.5" /> Appoint
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </TabsContent>
  );
}
