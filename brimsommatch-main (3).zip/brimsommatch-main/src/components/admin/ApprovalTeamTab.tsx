import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserCheck, Trash2, Plus } from "lucide-react";
import { useApprovalTeam, useApprovalTeamMutations } from "@/hooks/useApprovalTeam";

/**
 * Admin-only management of the scholarship approval team.
 * Members of this team are the only people who can be auto-assigned new
 * scholarship submissions for review. If the team is empty, the legacy
 * behavior applies (all admins/scholarship moderators are eligible).
 */
export default function ApprovalTeamTab() {
  const { data: team = [], isLoading } = useApprovalTeam();
  const { add, remove } = useApprovalTeamMutations();
  const [pickId, setPickId] = useState("");

  // Eligible candidates: admins + scholarship moderators not already on the team
  const { data: candidates = [] } = useQuery({
    queryKey: ["approval-team-candidates", team.map((t) => t.user_id).join(",")],
    queryFn: async () => {
      const [{ data: admins }, { data: mods }] = await Promise.all([
        supabase.from("user_roles").select("user_id").eq("role", "admin"),
        supabase
          .from("moderator_permissions" as any)
          .select("user_id")
          .eq("section", "scholarships"),
      ]);
      const adminSet = new Set((admins ?? []).map((a: any) => a.user_id));
      const modSet = new Set((mods ?? []).map((m: any) => m.user_id));
      const ids = Array.from(new Set([...adminSet, ...modSet])).filter(
        (id) => !team.some((t) => t.user_id === id)
      );
      if (ids.length === 0) return [];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", ids);
      return ids.map((id) => {
        const p: any = (profiles ?? []).find((x: any) => x.user_id === id);
        return {
          user_id: id,
          full_name: p?.full_name ?? id.slice(0, 8),
          is_admin: adminSet.has(id),
        };
      });
    },
  });

  return (
    <TabsContent value="approval-team">
      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <UserCheck className="h-5 w-5" /> Approval Team
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Choose which admins and moderators are eligible to receive new
            scholarship submissions for approval/rejection. New submissions are
            auto-assigned (round-robin) only to people on this list. If the list
            is empty, all admins and scholarship moderators are eligible.
          </p>
        </div>

        <Card>
          <CardContent className="pt-6 flex flex-col sm:flex-row gap-2">
            <Select value={pickId} onValueChange={setPickId}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Add an admin or moderator…" />
              </SelectTrigger>
              <SelectContent>
                {candidates.length === 0 ? (
                  <SelectItem value="none" disabled>
                    No eligible candidates
                  </SelectItem>
                ) : (
                  candidates.map((c) => (
                    <SelectItem key={c.user_id} value={c.user_id}>
                      {c.full_name} {c.is_admin ? "· Admin" : "· Moderator"}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            <Button
              disabled={!pickId || add.isPending}
              onClick={() => {
                add.mutate(pickId, { onSuccess: () => setPickId("") });
              }}
            >
              <Plus className="h-4 w-4 mr-2" /> Add to team
            </Button>
          </CardContent>
        </Card>

        <div className="rounded-xl border border-border bg-card divide-y">
          {isLoading ? (
            <div className="p-6 text-center text-muted-foreground">Loading…</div>
          ) : team.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              No team members yet — all admins and scholarship moderators are
              currently eligible.
            </div>
          ) : (
            team.map((m) => (
              <div key={m.user_id} className="flex items-center justify-between p-4">
                <div>
                  <div className="font-medium">{m.full_name || m.user_id.slice(0, 8)}</div>
                  <Badge variant={m.is_admin ? "default" : "secondary"} className="text-xs mt-1">
                    {m.is_admin ? "Admin" : "Moderator"}
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-destructive"
                  disabled={remove.isPending}
                  onClick={() => remove.mutate(m.user_id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </TabsContent>
  );
}
