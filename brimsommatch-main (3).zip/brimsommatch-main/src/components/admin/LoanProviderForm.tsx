import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { DialogFooter } from "@/components/ui/dialog";
import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Upload, Loader2, X } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const loanProviderSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(200),
  description: z.string().trim().max(2000).optional().or(z.literal("")),
  requirements: z.string().trim().max(3000).optional().or(z.literal("")),
  rates: z.string().trim().max(200).optional().or(z.literal("")),
  url: z.string().trim().url("Must be a valid URL").max(500).optional().or(z.literal("")),
  logo_url: z.string().trim().max(500).optional().or(z.literal("")),
  is_active: z.boolean(),
  sort_order: z.coerce.number().int().min(0).default(0),
});

export type LoanProviderFormValues = z.infer<typeof loanProviderSchema>;

type Props = {
  defaultValues?: Partial<LoanProviderFormValues>;
  onSubmit: (values: LoanProviderFormValues) => void;
  loading?: boolean;
};

export default function LoanProviderForm({ defaultValues, onSubmit, loading }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const form = useForm<LoanProviderFormValues>({
    resolver: zodResolver(loanProviderSchema),
    defaultValues: {
      name: "",
      description: "",
      requirements: "",
      rates: "",
      url: "",
      logo_url: "",
      is_active: true,
      sort_order: 0,
      ...defaultValues,
    },
  });

  const currentLogo = form.watch("logo_url");

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `loan-logos/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from("site-assets").upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage.from("site-assets").getPublicUrl(path);
      form.setValue("logo_url", publicUrl);
      toast({ title: "Logo uploaded!" });
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-h-[60vh] overflow-y-auto px-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem><FormLabel>Name *</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="grid grid-cols-2 gap-4">
          <FormField control={form.control} name="rates" render={({ field }) => (
            <FormItem><FormLabel>Rates</FormLabel><FormControl><Input placeholder="e.g. Fixed from 5.5%" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="sort_order" render={({ field }) => (
            <FormItem><FormLabel>Sort Order</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
        </div>
        <FormField control={form.control} name="url" render={({ field }) => (
          <FormItem><FormLabel>Website URL</FormLabel><FormControl><Input placeholder="https://..." {...field} /></FormControl><FormMessage /></FormItem>
        )} />

        {/* Logo Upload */}
        <div className="space-y-2">
          <FormLabel>Logo</FormLabel>
          {currentLogo && (
            <div className="relative inline-block">
              <img src={currentLogo} alt="Logo preview" className="h-16 w-auto rounded border border-border object-contain bg-muted p-1" />
              <button
                type="button"
                className="absolute -top-2 -right-2 rounded-full bg-destructive text-destructive-foreground p-0.5"
                onClick={() => form.setValue("logo_url", "")}
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          )}
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
          <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading}>
            {uploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
            {currentLogo ? "Replace Logo" : "Upload Logo"}
          </Button>
        </div>

        <FormField control={form.control} name="description" render={({ field }) => (
          <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea rows={3} {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="requirements" render={({ field }) => (
          <FormItem>
            <FormLabel>Requirements</FormLabel>
            <FormControl><Textarea rows={4} placeholder="• Requirement 1&#10;• Requirement 2" {...field} /></FormControl>
            <p className="text-xs text-muted-foreground mt-1">Use bullet points (•) for each requirement</p>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="is_active" render={({ field }) => (
          <FormItem className="flex items-center gap-3">
            <FormLabel>Active</FormLabel>
            <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
          </FormItem>
        )} />
        <DialogFooter>
          <Button type="submit" disabled={loading}>{loading ? "Saving..." : "Save Loan Provider"}</Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
