import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { TabsContent } from "@/components/ui/tabs";
import { Eye, Trash2, Loader2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface SupportRequest {
  id: string;
  name: string;
  email: string;
  subject: string;
  category: string;
  message: string;
  status: string;
  user_id: string | null;
  created_at: string;
}

const CATEGORY_LABELS: Record<string, string> = {
  general: "General",
  account: "Account & Profile",
  scholarships: "Scholarships",
  technical: "Technical Issue",
  billing: "Billing",
  report: "Report / Abuse",
  data: "Data & Privacy",
  other: "Other",
};

const STATUS_BADGE: Record<string, { className: string; label: string }> = {
  open: { className: "bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20", label: "Open" },
  in_progress: { className: "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20", label: "In Progress" },
  resolved: { className: "bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20", label: "Resolved" },
  closed: { className: "bg-muted text-muted-foreground border-border", label: "Closed" },
};

export default function SupportRequestsTab() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewOpen, setViewOpen] = useState(false);
  const [viewing, setViewing] = useState<SupportRequest | null>(null);
  const [newStatus, setNewStatus] = useState("open");

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["admin-support-requests"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("support_requests" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SupportRequest[];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("support_requests" as any)
        .update({ status } as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-support-requests"] });
      toast({ title: "Status updated" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteRequest = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("support_requests" as any)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-support-requests"] });
      toast({ title: "Request deleted" });
      setViewOpen(false);
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const filtered = statusFilter === "all" ? requests : requests.filter((r) => r.status === statusFilter);

  const openView = (req: SupportRequest) => {
    setViewing(req);
    setNewStatus(req.status);
    setViewOpen(true);
  };

  return (
    <TabsContent value="support">
      <div className="flex gap-3 mb-6">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All ({requests.length})</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden sm:table-cell">Email</TableHead>
              <TableHead>Category</TableHead>
              <TableHead className="hidden md:table-cell">Subject</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No support requests</TableCell></TableRow>
            ) : filtered.map((req) => {
              const badge = STATUS_BADGE[req.status] ?? STATUS_BADGE.open;
              return (
                <TableRow key={req.id}>
                  <TableCell className="font-medium">{req.name}</TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground max-w-[180px] truncate">{req.email}</TableCell>
                  <TableCell><Badge variant="outline">{CATEGORY_LABELS[req.category] ?? req.category}</Badge></TableCell>
                  <TableCell className="hidden md:table-cell max-w-[200px] truncate">{req.subject}</TableCell>
                  <TableCell><Badge className={badge.className}>{badge.label}</Badge></TableCell>
                  <TableCell className="hidden sm:table-cell">{format(new Date(req.created_at), "MMM d, yyyy")}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" onClick={() => openView(req)}>
                      <Eye className="h-3.5 w-3.5 mr-1" /> View
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Support Request</DialogTitle></DialogHeader>
          {viewing && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Name</p>
                  <p className="font-medium">{viewing.name}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Email</p>
                  <p className="font-medium">{viewing.email}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Category</p>
                  <p className="font-medium">{CATEGORY_LABELS[viewing.category] ?? viewing.category}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Date</p>
                  <p className="font-medium">{format(new Date(viewing.created_at), "MMM d, yyyy h:mm a")}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-1">Subject</p>
                <p className="text-sm font-medium">{viewing.subject}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground mb-1">Message</p>
                <div className="rounded-lg bg-muted p-3 text-sm whitespace-pre-wrap max-h-60 overflow-y-auto">
                  {viewing.message}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Update Status</Label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button
                  className="flex-1"
                  onClick={() => { updateStatus.mutate({ id: viewing.id, status: newStatus }); setViewOpen(false); }}
                  disabled={updateStatus.isPending || newStatus === viewing.status}
                >
                  {updateStatus.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Update Status
                </Button>
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => deleteRequest.mutate(viewing.id)}
                  disabled={deleteRequest.isPending}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
