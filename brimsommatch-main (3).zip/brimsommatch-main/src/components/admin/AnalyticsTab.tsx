import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line } from "recharts";
import { Users, Eye } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState, useMemo } from "react";
import { format, subDays, parseISO, startOfDay } from "date-fns";

const registrationConfig: ChartConfig = {
  count: { label: "New Users", color: "hsl(var(--primary))" },
};

const visitConfig: ChartConfig = {
  count: { label: "Unique Visitors", color: "hsl(var(--chart-2, 280 65% 60%))" },
};

type DayCount = { date: string; count: number };

function aggregateByDay(rows: { created_at: string }[], days: number): DayCount[] {
  const now = new Date();
  const map = new Map<string, number>();
  for (let i = days - 1; i >= 0; i--) {
    const key = format(subDays(now, i), "yyyy-MM-dd");
    map.set(key, 0);
  }
  for (const r of rows) {
    const key = format(parseISO(r.created_at), "yyyy-MM-dd");
    if (map.has(key)) map.set(key, (map.get(key) ?? 0) + 1);
  }
  return Array.from(map.entries()).map(([date, count]) => ({
    date: format(parseISO(date), "MMM d"),
    count,
  }));
}

function uniqueVisitorsByDay(rows: { created_at: string; user_id: string }[], days: number): DayCount[] {
  const now = new Date();
  const map = new Map<string, Set<string>>();
  for (let i = days - 1; i >= 0; i--) {
    const key = format(subDays(now, i), "yyyy-MM-dd");
    map.set(key, new Set());
  }
  for (const r of rows) {
    const key = format(parseISO(r.created_at), "yyyy-MM-dd");
    map.get(key)?.add(r.user_id);
  }
  return Array.from(map.entries()).map(([date, users]) => ({
    date: format(parseISO(date), "MMM d"),
    count: users.size,
  }));
}

export default function AnalyticsTab() {
  const [range, setRange] = useState("30");
  const days = parseInt(range);

  const since = useMemo(() => subDays(new Date(), days).toISOString(), [days]);

  const { data: registrations, isLoading: regLoading } = useQuery({
    queryKey: ["admin-registrations", days],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("created_at")
        .gte("created_at", since)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: visits, isLoading: visitLoading } = useQuery({
    queryKey: ["admin-visits", days],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activity_log")
        .select("created_at, user_id")
        .gte("created_at", since)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const regData = useMemo(() => aggregateByDay(registrations ?? [], days), [registrations, days]);
  const visitData = useMemo(() => uniqueVisitorsByDay(visits ?? [], days), [visits, days]);

  const totalNewUsers = regData.reduce((s, d) => s + d.count, 0);
  const totalVisits = visitData.reduce((s, d) => s + d.count, 0);

  return (
    <TabsContent value="analytics">
      <div className="flex justify-end mb-4">
        <Select value={range} onValueChange={setRange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="14">Last 14 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">New Users ({range}d)</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {regLoading ? <Skeleton className="h-8 w-16" /> : <p className="text-2xl font-bold">{totalNewUsers}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Users ({range}d)</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {visitLoading ? <Skeleton className="h-8 w-16" /> : <p className="text-2xl font-bold">{totalVisits}</p>}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Daily New Registrations</CardTitle>
          </CardHeader>
          <CardContent>
            {regLoading ? (
              <Skeleton className="h-[250px] w-full" />
            ) : (
              <ChartContainer config={registrationConfig} className="h-[250px] w-full">
                <BarChart data={regData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis dataKey="date" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis allowDecimals={false} fontSize={11} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="count" fill="var(--color-count)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Daily Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            {visitLoading ? (
              <Skeleton className="h-[250px] w-full" />
            ) : (
              <ChartContainer config={visitConfig} className="h-[250px] w-full">
                <LineChart data={visitData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis dataKey="date" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis allowDecimals={false} fontSize={11} tickLine={false} axisLine={false} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Line type="monotone" dataKey="count" stroke="var(--color-count)" strokeWidth={2} dot={false} />
                </LineChart>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </TabsContent>
  );
}
