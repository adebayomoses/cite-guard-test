import { useState } from "react";
import { useAdminReports } from "@/hooks/useUserReports";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, CheckCircle2, Clock, Eye, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const REASON_LABELS: Record<string, string> = {
  spam: "Spam",
  harassment: "Harassment",
  inappropriate: "Inappropriate Content",
  impersonation: "Impersonation",
  scam: "Scam / Fraud",
  other: "Other",
};

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  pending: { label: "Pending", variant: "secondary" },
  reviewing: { label: "Reviewing", variant: "outline" },
  resolved: { label: "Resolved", variant: "default" },
  dismissed: { label: "Dismissed", variant: "destructive" },
};

export default function ReportsTab() {
  const { user } = useAuth();
  const { isAdmin } = useAdminRole();
  const { reports, isLoading, updateReport, deleteReport } = useAdminReports();
  const [statusFilter, setStatusFilter] = useState("all");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [reviewStatus, setReviewStatus] = useState("pending");
  const [adminNotes, setAdminNotes] = useState("");

  // Fetch profile names for reporter and reported users
  const userIds = [...new Set(reports.flatMap((r) => [r.reporter_id, r.reported_user_id]))];
  const { data: profiles = [] } = useQuery({
    queryKey: ["report-profiles", userIds.join(",")],
    queryFn: async () => {
      if (!userIds.length) return [];
      const { data } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", userIds);
      return data ?? [];
    },
    enabled: userIds.length > 0,
  });

  const getName = (uid: string) => profiles.find((p) => p.user_id === uid)?.full_name ?? "Unknown";

  const filtered = statusFilter === "all" ? reports : reports.filter((r) => r.status === statusFilter);
  const reviewing = reviewingId ? reports.find((r) => r.id === reviewingId) : null;

  const pendingCount = reports.filter((r) => r.status === "pending").length;
  const resolvedCount = reports.filter((r) => r.status === "resolved").length;

  const openReview = (report: typeof reports[0]) => {
    setReviewingId(report.id);
    setReviewStatus(report.status);
    setAdminNotes(report.admin_notes ?? "");
    setReviewOpen(true);
  };

  const handleSave = () => {
    if (!reviewingId || !user) return;
    updateReport.mutate({
      id: reviewingId,
      status: reviewStatus,
      admin_notes: adminNotes,
      reviewed_by: user.id,
    });
    setReviewOpen(false);
  };

  return (
    <TabsContent value="reports">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Reports</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : <p className="text-2xl font-bold">{reports.length}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Resolved</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : <p className="text-2xl font-bold text-green-600">{resolvedCount}</p>}
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-3 mb-4">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Reports</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="reviewing">Reviewing</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="dismissed">Dismissed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reporter</TableHead>
              <TableHead>Reported User</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">When</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No reports found</TableCell></TableRow>
            ) : filtered.map((report) => {
              const sc = STATUS_CONFIG[report.status] ?? STATUS_CONFIG.pending;
              return (
                <TableRow key={report.id}>
                  <TableCell className="font-medium">{getName(report.reporter_id)}</TableCell>
                  <TableCell>{getName(report.reported_user_id)}</TableCell>
                  <TableCell>{REASON_LABELS[report.reason] ?? report.reason}</TableCell>
                  <TableCell>
                    <Badge variant={sc.variant}>{sc.label}</Badge>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">
                    {formatDistanceToNow(new Date(report.created_at), { addSuffix: true })}
                  </TableCell>
                  <TableCell className="text-right space-x-1 whitespace-nowrap">
                    <Button variant="outline" size="sm" onClick={() => openReview(report)}>
                      <Eye className="h-3.5 w-3.5 mr-1" /> Review
                    </Button>
                    {isAdmin && (
                      <Button variant="ghost" size="icon" onClick={() => deleteReport.mutate(report.id)}>
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Review Report</DialogTitle></DialogHeader>
          {reviewing && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">Reporter</p>
                  <p className="text-sm font-medium">{getName(reviewing.reporter_id)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Reported User</p>
                  <p className="text-sm font-medium">{getName(reviewing.reported_user_id)}</p>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Reason</p>
                <p className="text-sm font-medium">{REASON_LABELS[reviewing.reason] ?? reviewing.reason}</p>
              </div>
              {reviewing.details && (
                <div className="rounded-lg bg-muted p-3">
                  <p className="text-xs text-muted-foreground mb-1">Details</p>
                  <p className="text-sm">{reviewing.details}</p>
                </div>
              )}
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={reviewStatus} onValueChange={setReviewStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="reviewing">Reviewing</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="dismissed">Dismissed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Admin Notes</Label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add notes about this report..."
                  rows={3}
                  maxLength={2000}
                />
              </div>
              <Button className="w-full" onClick={handleSave} disabled={updateReport.isPending}>
                Save Review
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
