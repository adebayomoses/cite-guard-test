import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";
import { format } from "date-fns";

interface Props {
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export function useRecentScholarshipsCount() {
  const { data: count = 0 } = useQuery({
    queryKey: ["recent-scholarships-24h-count"],
    queryFn: async () => {
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { count, error } = await supabase
        .from("scholarships")
        .select("*", { count: "exact", head: true })
        .gte("created_at", since);
      if (error) throw error;
      return count ?? 0;
    },
    refetchInterval: 60_000,
  });
  return count;
}

export default function RecentScholarshipsTab({ onEdit, onDelete }: Props) {
  const { data: scholarships = [], isLoading } = useQuery({
    queryKey: ["recent-scholarships-24h"],
    queryFn: async () => {
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const { data, error } = await supabase
        .from("scholarships")
        .select("*")
        .gte("created_at", since)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    refetchInterval: 60_000,
  });

  return (
    <TabsContent value="recent">
      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead className="hidden sm:table-cell">Country</TableHead>
              <TableHead className="hidden md:table-cell">Degree Level</TableHead>
              <TableHead className="hidden md:table-cell">Funding Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Loading…</TableCell>
              </TableRow>
            ) : scholarships.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No scholarships published in the last 24 hours
                </TableCell>
              </TableRow>
            ) : (
              scholarships.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium max-w-[250px] truncate">{s.title}</TableCell>
                  <TableCell className="hidden sm:table-cell">{s.country ?? "—"}</TableCell>
                  <TableCell className="hidden md:table-cell">{s.degree_level ?? "—"}</TableCell>
                  <TableCell className="hidden md:table-cell">{s.funding_type ?? "—"}</TableCell>
                  <TableCell>
                    <Badge variant={s.is_active ? "default" : "secondary"}>
                      {s.is_active ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground">
                    {format(new Date(s.created_at), "MMM d, h:mm a")}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex items-center gap-0.5 whitespace-nowrap">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(s.id)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDelete(s.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </TabsContent>
  );
}
