import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { getCountryFlag } from "@/lib/countryFlags";
import { Search, ArrowUpDown, Globe, Pencil, Trash2, Trophy, RefreshCw, ExternalLink, ArrowLeft } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";

type Row = { country: string; active: number; past: number; total: number };

interface CountriesTabProps {
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onToggleChallenge?: (id: string, next: boolean) => void;
  onRepublish?: (id: string) => void;
}

export default function CountriesTab({ onEdit, onDelete, onToggleChallenge, onRepublish }: CountriesTabProps = {}) {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"total" | "active" | "past" | "country">("total");
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-countries-stats"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("country, next_close_date, status")
        .not("country", "is", null);
      if (error) throw error;
      const now = Date.now();
      const map = new Map<string, Row>();
      for (const s of data ?? []) {
        const country = (s.country as string)?.trim();
        if (!country) continue;
        const parts = country.split(/[,;]/).map((c) => c.trim()).filter(Boolean);
        for (const c of parts) {
          if (!map.has(c)) map.set(c, { country: c, active: 0, past: 0, total: 0 });
          const r = map.get(c)!;
          const isPast = s.next_close_date && new Date(s.next_close_date as string).getTime() < now;
          if ((s as any).status === "approved" || (s as any).status === undefined || (s as any).status === null) {
            if (isPast) r.past += 1;
            else r.active += 1;
            r.total += 1;
          }
        }
      }
      return Array.from(map.values());
    },
  });

  const rows = useMemo(() => {
    let r = data ?? [];
    const q = search.trim().toLowerCase();
    if (q) r = r.filter((x) => x.country.toLowerCase().includes(q));
    r = [...r].sort((a, b) => {
      if (sortBy === "country") return a.country.localeCompare(b.country);
      return (b[sortBy] as number) - (a[sortBy] as number);
    });
    return r;
  }, [data, search, sortBy]);

  const totals = useMemo(() => {
    const r = data ?? [];
    return {
      countries: r.length,
      active: r.reduce((s, x) => s + x.active, 0),
      past: r.reduce((s, x) => s + x.past, 0),
      total: r.reduce((s, x) => s + x.total, 0),
    };
  }, [data]);

  const cycleSort = () => {
    setSortBy((s) => (s === "total" ? "active" : s === "active" ? "past" : s === "past" ? "country" : "total"));
  };

  if (selectedCountry) {
    return (
      <TabsContent value="countries">
        <div className="mb-3 flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setSelectedCountry(null)} className="gap-1">
            <ArrowLeft className="h-4 w-4" /> Back to countries
          </Button>
        </div>
        <div className="mb-4 flex items-center gap-2">
          <span className="text-2xl">{getCountryFlag(selectedCountry)}</span>
          <h2 className="text-xl font-serif font-semibold break-words">{selectedCountry} — Scholarships</h2>
        </div>
        <CountryScholarshipsView
          country={selectedCountry}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleChallenge={onToggleChallenge}
          onRepublish={onRepublish}
        />
      </TabsContent>
    );
  }

  return (
    <TabsContent value="countries">
      <div className="grid gap-3 sm:grid-cols-4 mb-4">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground flex items-center gap-1"><Globe className="h-3 w-3" />Countries</div><div className="text-2xl font-semibold">{totals.countries}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Active</div><div className="text-2xl font-semibold text-green-600">{totals.active}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Past Deadline</div><div className="text-2xl font-semibold text-muted-foreground">{totals.past}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Total</div><div className="text-2xl font-semibold">{totals.total}</div></CardContent></Card>
      </div>

      <div className="flex gap-2 mb-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search country..." className="pl-9" />
        </div>
        <button onClick={cycleSort} className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1 px-3 rounded-md border border-border">
          <ArrowUpDown className="h-3 w-3" /> Sort: {sortBy}
        </button>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Country</TableHead>
              <TableHead className="text-right">Active</TableHead>
              <TableHead className="text-right">Past Deadline</TableHead>
              <TableHead className="text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : rows.length === 0 ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No countries found</TableCell></TableRow>
            ) : rows.map((r) => (
              <TableRow
                key={r.country}
                className="cursor-pointer hover:bg-muted/40"
                onClick={() => setSelectedCountry(r.country)}
              >
                <TableCell className="font-medium">
                  <span className="mr-2">{getCountryFlag(r.country)}</span>
                  <span className="underline-offset-2 hover:underline">{r.country}</span>
                </TableCell>
                <TableCell className="text-right">
                  <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">{r.active}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Badge variant="secondary">{r.past}</Badge>
                </TableCell>
                <TableCell className="text-right font-semibold">{r.total}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </TabsContent>
  );
}

function CountryScholarshipsView({
  country,
  onEdit,
  onDelete,
  onToggleChallenge,
  onRepublish,
}: {
  country: string;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onToggleChallenge?: (id: string, next: boolean) => void;
  onRepublish?: (id: string) => void;
}) {
  const { data: scholarships, isLoading } = useQuery({
    queryKey: ["admin-country-scholarships", country],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("id, title, country, degree_level, next_close_date, status, is_active, is_challenge")
        .ilike("country", `%${country}%`)
        .order("next_close_date", { ascending: true, nullsFirst: false });
      if (error) throw error;
      const target = country.toLowerCase();
      return (data ?? []).filter((s) => {
        const parts = (s.country ?? "").split(/[,;]/).map((c: string) => c.trim().toLowerCase());
        return parts.includes(target);
      });
    },
  });

  const now = Date.now();
  const active = (scholarships ?? []).filter(
    (s) => !s.next_close_date || new Date(s.next_close_date as string).getTime() >= now
  );
  const past = (scholarships ?? []).filter(
    (s) => s.next_close_date && new Date(s.next_close_date as string).getTime() < now
  );

  return (
    <Tabs defaultValue="active" className="w-full">
      <TabsList>
        <TabsTrigger value="active">Active ({active.length})</TabsTrigger>
        <TabsTrigger value="past">Past Deadline ({past.length})</TabsTrigger>
      </TabsList>
      <TabsContent value="active">
        <CountryScholarshipsTable
          scholarships={active}
          isLoading={isLoading}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleChallenge={onToggleChallenge}
          onRepublish={onRepublish}
        />
      </TabsContent>
      <TabsContent value="past">
        <CountryScholarshipsTable
          scholarships={past}
          isLoading={isLoading}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleChallenge={onToggleChallenge}
          onRepublish={onRepublish}
        />
      </TabsContent>
    </Tabs>
  );
}

function CountryScholarshipsTable({
  scholarships,
  isLoading,
  onEdit,
  onDelete,
  onToggleChallenge,
  onRepublish,
}: {
  scholarships: any[];
  isLoading: boolean;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onToggleChallenge?: (id: string, next: boolean) => void;
  onRepublish?: (id: string) => void;
}) {
  return (
    <div className="rounded-xl border border-border bg-card mt-2">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead className="hidden md:table-cell">Degree</TableHead>
            <TableHead className="hidden sm:table-cell">Deadline</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
          ) : scholarships.length === 0 ? (
            <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No scholarships</TableCell></TableRow>
          ) : scholarships.map((s) => (
            <TableRow key={s.id}>
              <TableCell className="font-medium max-w-[160px] sm:max-w-[260px] truncate">
                <span className="inline-flex items-center gap-1.5">
                  {s.is_challenge && <Trophy className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                  <span className="truncate">{s.title}</span>
                </span>
              </TableCell>
              <TableCell className="hidden md:table-cell">{s.degree_level ?? "—"}</TableCell>
              <TableCell className="hidden sm:table-cell">{s.next_close_date ? format(new Date(s.next_close_date), "MMM d, yyyy") : "—"}</TableCell>
              <TableCell>
                {s.status === "approved" && s.is_active ? (
                  <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Active</Badge>
                ) : s.status === "pending" ? (
                  <Badge variant="secondary">Pending</Badge>
                ) : s.status === "rejected" ? (
                  <Badge variant="destructive">Rejected</Badge>
                ) : (
                  <Badge variant="outline">Inactive</Badge>
                )}
              </TableCell>
              <TableCell className="text-right">
                <div className="inline-flex items-center gap-0.5 whitespace-nowrap">
                  {onToggleChallenge && (
                    <Button
                      variant={s.is_challenge ? "default" : "outline"}
                      size="sm"
                      onClick={() => onToggleChallenge(s.id, !s.is_challenge)}
                      className="text-xs h-8 px-2"
                      title={s.is_challenge ? "Remove from Challenge List" : "Send to Challenge List"}
                    >
                      <Trophy className={`h-3.5 w-3.5 sm:mr-1 ${s.is_challenge ? "" : "text-amber-500"}`} />
                      <span className="hidden sm:inline">{s.is_challenge ? "In Challenge" : "Challenge"}</span>
                    </Button>
                  )}
                  {onRepublish && (
                    <Button variant="outline" size="sm" onClick={() => onRepublish(s.id)} className="text-xs h-8 px-2">
                      <RefreshCw className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Republish</span>
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="h-8 w-8" asChild title="View">
                    <a href={`/scholarships/${s.id}`} target="_blank" rel="noopener noreferrer"><ExternalLink className="h-4 w-4" /></a>
                  </Button>
                  {onEdit && (
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(s.id)} title="Edit"><Pencil className="h-4 w-4" /></Button>
                  )}
                  {onDelete && (
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDelete(s.id)} title="Delete"><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
