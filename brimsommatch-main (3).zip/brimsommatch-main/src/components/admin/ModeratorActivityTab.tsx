import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, GraduationCap, Clock, CheckCircle2, XCircle, FileText } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

interface ScholarshipRow {
  id: string;
  title: string;
  status: string;
  created_at: string;
  approved_at: string | null;
  rejection_reason: string | null;
}

interface ModeratorStats {
  user_id: string;
  full_name: string;
  scholarships_posted: number;
  scholarships_posted_month: number;
  scholarships_posted_week: number;
  scholarships_rejected_month: number;
  scholarships_rejected_total: number;
  approvals_done_month: number;
  approvals_done_week: number;
  approvals_done_total: number;
  rejections_done_month: number;
  rejections_done_total: number;
  last_active: string | null;
  recent_actions: { action: string; detail: string | null; created_at: string }[];
  posted_recent: ScholarshipRow[];
  approved_recent: ScholarshipRow[];
  rejected_recent: ScholarshipRow[];
}

export default function ModeratorActivityTab() {
  const [selectedMod, setSelectedMod] = useState<ModeratorStats | null>(null);
  const [dialogTab, setDialogTab] = useState<"posted" | "approved" | "rejected" | "activity">("posted");

  const { data: moderatorStats = [], isLoading } = useQuery({
    queryKey: ["moderator-activity-stats"],
    queryFn: async () => {
      const { data: modRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "moderator");
      if (!modRoles?.length) return [];

      const { data: adminRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "admin");

      const allUserIds = [
        ...modRoles.map((r) => r.user_id),
        ...(adminRoles?.map((r) => r.user_id) ?? []),
      ];
      const uniqueIds = [...new Set(allUserIds)];

      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", uniqueIds);

      const { data: scholarships } = await supabase
        .from("scholarships")
        .select("id, title, created_by, created_at, status, approved_by, approved_at, rejection_reason" as any);

      const { data: activities } = await supabase
        .from("activity_log")
        .select("user_id, action, detail, created_at")
        .in("user_id", uniqueIds)
        .order("created_at", { ascending: false })
        .limit(500);

      const monthStart = new Date();
      monthStart.setUTCDate(1);
      monthStart.setUTCHours(0, 0, 0, 0);
      const monthStartMs = monthStart.getTime();

      const weekStart = new Date();
      weekStart.setUTCHours(0, 0, 0, 0);
      weekStart.setUTCDate(weekStart.getUTCDate() - 7);
      const weekStartMs = weekStart.getTime();

      const allSch: any[] = (scholarships as any[]) ?? [];

      return uniqueIds.map((uid) => {
        const profile = profiles?.find((p) => p.user_id === uid);
        const userScholarships = allSch.filter((s) => s.created_by === uid);
        const approvedByUser = allSch.filter((s) => s.approved_by === uid && s.status === "approved");
        // Rejections done by this user — best signal: approved_by is set when admin acts, but rejected items are stamped via approved_by too in our trigger? Actually rejection_reason is set; approved_by may not always be stamped on reject. Use approved_by if present.
        const rejectedByUser = allSch.filter((s) => s.approved_by === uid && s.status === "rejected");

        const inMonth = (d?: string | null) => !!d && new Date(d).getTime() >= monthStartMs;
        const inWeek = (d?: string | null) => !!d && new Date(d).getTime() >= weekStartMs;

        const userActivities = (activities ?? []).filter((a) => a.user_id === uid);
        const lastActivity = userActivities[0]?.created_at ?? null;

        const toRow = (s: any): ScholarshipRow => ({
          id: s.id,
          title: s.title,
          status: s.status,
          created_at: s.created_at,
          approved_at: s.approved_at,
          rejection_reason: s.rejection_reason,
        });

        return {
          user_id: uid,
          full_name: profile?.full_name ?? "Unknown",
          scholarships_posted: userScholarships.length,
          scholarships_posted_month: userScholarships.filter((s) => inMonth(s.created_at)).length,
          scholarships_posted_week: userScholarships.filter((s) => inWeek(s.created_at)).length,
          scholarships_rejected_total: userScholarships.filter((s) => s.status === "rejected").length,
          scholarships_rejected_month: userScholarships.filter((s) => s.status === "rejected" && inMonth(s.created_at)).length,
          approvals_done_total: approvedByUser.length,
          approvals_done_month: approvedByUser.filter((s) => inMonth(s.approved_at)).length,
          approvals_done_week: approvedByUser.filter((s) => inWeek(s.approved_at)).length,
          rejections_done_total: rejectedByUser.length,
          rejections_done_month: rejectedByUser.filter((s) => inMonth(s.approved_at)).length,
          last_active: lastActivity,
          recent_actions: userActivities.slice(0, 20).map((a) => ({
            action: a.action,
            detail: a.detail,
            created_at: a.created_at,
          })),
          posted_recent: [...userScholarships]
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
            .slice(0, 20)
            .map(toRow),
          approved_recent: [...approvedByUser]
            .sort((a, b) => new Date(b.approved_at ?? 0).getTime() - new Date(a.approved_at ?? 0).getTime())
            .slice(0, 20)
            .map(toRow),
          rejected_recent: [...rejectedByUser]
            .sort((a, b) => new Date(b.approved_at ?? 0).getTime() - new Date(a.approved_at ?? 0).getTime())
            .slice(0, 20)
            .map(toRow),
        } as ModeratorStats;
      }).sort((a, b) => b.scholarships_posted_month - a.scholarships_posted_month);
    },
  });

  const totalPosted = moderatorStats.reduce((sum, m) => sum + m.scholarships_posted, 0);
  const totalPostedMonth = moderatorStats.reduce((sum, m) => sum + m.scholarships_posted_month, 0);
  const totalRejectedMonth = moderatorStats.reduce((sum, m) => sum + m.scholarships_rejected_month, 0);
  const totalRejected = moderatorStats.reduce((sum, m) => sum + m.scholarships_rejected_total, 0);

  const openDetails = (mod: ModeratorStats) => {
    setSelectedMod(mod);
    setDialogTab(mod.posted_recent.length ? "posted" : mod.approved_recent.length ? "approved" : mod.rejected_recent.length ? "rejected" : "activity");
  };

  const statusBadge = (status: string) => {
    const variant = status === "approved" ? "bg-emerald-500/15 text-emerald-700 border-emerald-500/20"
      : status === "rejected" ? "bg-destructive/10 text-destructive border-destructive/30"
      : status === "pending" ? "bg-amber-500/15 text-amber-700 border-amber-500/20"
      : "bg-muted text-muted-foreground";
    return <Badge variant="outline" className={`text-xs ${variant}`}>{status}</Badge>;
  };

  const renderRows = (rows: ScholarshipRow[], dateLabel: "created_at" | "approved_at") => {
    if (!rows.length) return <p className="text-sm text-muted-foreground text-center py-6">Nothing here yet</p>;
    return (
      <div className="space-y-2">
        {rows.map((s) => (
          <div key={s.id} className="rounded-lg border border-border p-3 space-y-1">
            <div className="flex items-start justify-between gap-2">
              <span className="text-sm font-medium line-clamp-2">{s.title}</span>
              {statusBadge(s.status)}
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                {dateLabel === "approved_at" && s.approved_at
                  ? formatDistanceToNow(new Date(s.approved_at), { addSuffix: true })
                  : formatDistanceToNow(new Date(s.created_at), { addSuffix: true })}
              </span>
            </div>
            {s.status === "rejected" && s.rejection_reason && (
              <p className="text-xs text-destructive">Reason: {s.rejection_reason}</p>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <TabsContent value="moderator-activity">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Moderators</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : <p className="text-2xl font-bold">{moderatorStats.length}</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Posted This Month</CardTitle>
            <GraduationCap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : (
              <p className="text-2xl font-bold">
                {totalPostedMonth}
                <span className="text-sm font-normal text-muted-foreground ml-2">/ {totalPosted} all-time</span>
              </p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Today</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : (
              <p className="text-2xl font-bold">
                {moderatorStats.filter((m) => {
                  if (!m.last_active) return false;
                  const diff = Date.now() - new Date(m.last_active).getTime();
                  return diff < 24 * 60 * 60 * 1000;
                }).length}
              </p>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium text-muted-foreground">Rejected This Month</CardTitle>
            <GraduationCap className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            {isLoading ? <Skeleton className="h-8 w-12" /> : (
              <p className="text-2xl font-bold text-destructive">
                {totalRejectedMonth}
                <span className="text-sm font-normal text-muted-foreground ml-2">/ {totalRejected} all-time</span>
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="text-center">Posted (Wk)</TableHead>
              <TableHead className="text-center">Posted (Mo)</TableHead>
              <TableHead className="text-center">Approved (Wk)</TableHead>
              <TableHead className="text-center">Approved (Mo)</TableHead>
              <TableHead className="text-center">Rejected (Mo)</TableHead>
              <TableHead className="text-center">All Time Posted</TableHead>
              <TableHead>Last Action</TableHead>
              <TableHead className="text-right">Details</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">Loading…</TableCell>
              </TableRow>
            ) : moderatorStats.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">No moderator activity yet</TableCell>
              </TableRow>
            ) : moderatorStats.map((mod) => (
              <TableRow key={mod.user_id}>
                <TableCell className="font-medium">{mod.full_name}</TableCell>
                <TableCell className="text-center">
                  <Badge variant="outline" className={mod.scholarships_posted_week > 0 ? "bg-primary/10 text-primary border-primary/30" : "text-muted-foreground"}>
                    {mod.scholarships_posted_week}
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge className="bg-primary/15 text-primary border-primary/20">{mod.scholarships_posted_month}</Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant="outline" className={mod.approvals_done_week > 0 ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30" : "text-muted-foreground"}>
                    {mod.approvals_done_week}
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant="outline" className={mod.approvals_done_month > 0 ? "bg-emerald-500/10 text-emerald-700 border-emerald-500/30" : "text-muted-foreground"}>
                    {mod.approvals_done_month}
                    {mod.approvals_done_total > 0 && <span className="ml-1 opacity-60">/ {mod.approvals_done_total}</span>}
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge
                    variant="outline"
                    className={mod.rejections_done_month > 0 ? "bg-destructive/10 text-destructive border-destructive/30" : "text-muted-foreground"}
                  >
                    {mod.rejections_done_month}
                    {mod.rejections_done_total > 0 && (
                      <span className="ml-1 opacity-60">/ {mod.rejections_done_total}</span>
                    )}
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant="secondary">{mod.scholarships_posted}</Badge>
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {mod.last_active
                    ? formatDistanceToNow(new Date(mod.last_active), { addSuffix: true })
                    : "No activity"}
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openDetails(mod)}
                  >
                    View
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!selectedMod} onOpenChange={(o) => !o && setSelectedMod(null)}>
        <DialogContent className="sm:max-w-2xl max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>{selectedMod?.full_name} — Moderator Activity</DialogTitle>
          </DialogHeader>
          {selectedMod && (
            <Tabs value={dialogTab} onValueChange={(v) => setDialogTab(v as any)}>
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="posted" className="gap-1 text-xs">
                  <FileText className="h-3.5 w-3.5" /> Posted ({selectedMod.posted_recent.length})
                </TabsTrigger>
                <TabsTrigger value="approved" className="gap-1 text-xs">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Approved ({selectedMod.approved_recent.length})
                </TabsTrigger>
                <TabsTrigger value="rejected" className="gap-1 text-xs">
                  <XCircle className="h-3.5 w-3.5" /> Rejected ({selectedMod.rejected_recent.length})
                </TabsTrigger>
                <TabsTrigger value="activity" className="gap-1 text-xs">
                  <Clock className="h-3.5 w-3.5" /> Log ({selectedMod.recent_actions.length})
                </TabsTrigger>
              </TabsList>
              <div className="mt-4 max-h-[60vh] overflow-y-auto">
                {dialogTab === "posted" && renderRows(selectedMod.posted_recent, "created_at")}
                {dialogTab === "approved" && renderRows(selectedMod.approved_recent, "approved_at")}
                {dialogTab === "rejected" && renderRows(selectedMod.rejected_recent, "approved_at")}
                {dialogTab === "activity" && (
                  <div className="space-y-2">
                    {selectedMod.recent_actions.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-6">No logged actions</p>
                    ) : selectedMod.recent_actions.map((a, i) => (
                      <div key={i} className="rounded-lg border border-border p-3 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{a.action}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
                          </span>
                        </div>
                        {a.detail && <p className="text-xs text-muted-foreground break-words">{a.detail}</p>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
