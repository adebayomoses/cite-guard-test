import { useState } from "react";
import { useRoomAnnouncements } from "@/hooks/useRoomAnnouncements";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Pencil, Trash2, Plus, Megaphone } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Props {
  roomId: string;
  roomName: string;
}

export default function AnnouncementManager({ roomId, roomName }: Props) {
  const [open, setOpen] = useState(false);
  const [newContent, setNewContent] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const { announcements, isLoading, addAnnouncement, updateAnnouncement, deleteAnnouncement } = useRoomAnnouncements(roomId);

  const handleAdd = async () => {
    if (!newContent.trim()) return;
    try {
      await addAnnouncement.mutateAsync(newContent.trim());
      setNewContent("");
      toast({ title: "Announcement added" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleUpdate = async () => {
    if (!editingId || !editContent.trim()) return;
    try {
      await updateAnnouncement.mutateAsync({ id: editingId, content: editContent.trim() });
      setEditingId(null);
      setEditContent("");
      toast({ title: "Announcement updated" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteAnnouncement.mutateAsync(id);
      toast({ title: "Announcement deleted" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <>
      <Button variant="ghost" size="icon" onClick={() => setOpen(true)} title="Manage announcements">
        <Megaphone className="h-4 w-4" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Announcements — #{roomName}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 max-h-[50vh] overflow-y-auto">
            {isLoading ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : announcements.length === 0 ? (
              <p className="text-sm text-muted-foreground">No announcements yet.</p>
            ) : (
              announcements.map((a) => (
                <div key={a.id} className="border border-border rounded-lg p-3 space-y-2">
                  {editingId === a.id ? (
                    <div className="space-y-2">
                      <Textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} />
                      <div className="flex gap-2">
                        <Button size="sm" onClick={handleUpdate} disabled={updateAnnouncement.isPending}>Save</Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>Cancel</Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm whitespace-pre-wrap">{a.content}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">{format(new Date(a.created_at), "MMM d, yyyy 'at' p")}</span>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingId(a.id); setEditContent(a.content); }}>
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDelete(a.id)}>
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ))
            )}
          </div>

          <div className="space-y-2 border-t border-border pt-4">
            <Textarea placeholder="Write an announcement…" value={newContent} onChange={(e) => setNewContent(e.target.value)} />
            <Button onClick={handleAdd} disabled={!newContent.trim() || addAnnouncement.isPending} className="gap-1">
              <Plus className="h-4 w-4" /> Add Announcement
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
