import { useForm } from "react-hook-form";
import { DEFAULT_APPLY_STEPS } from "@/lib/defaultApplySteps";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Shield, ExternalLink, X } from "lucide-react";
import { useReviewers } from "@/hooks/useReviewers";
import { useDuplicateScholarshipCheck } from "@/hooks/useDuplicateScholarshipCheck";
import DuplicateWarning from "@/components/admin/DuplicateWarning";
import { useState, useEffect } from "react";
import { Plus, Trash2, CalendarDays } from "lucide-react";
import type { ScholarshipIntake, IntakeTerm } from "@/hooks/useScholarshipIntakes";
import { toast } from "@/hooks/use-toast";
import { useIsMainAdmin } from "@/hooks/useIsMainAdmin";

const FUNDING_TYPE_OPTIONS = ["Fully Funded", "Partially Funded", "Tuition Only", "Living Expenses Only"] as const;

const FUNDING_CATEGORY_OPTIONS = [
  "Government Scholarships",
  "University Scholarships",
  "Assistantships",
  "Fellowships",
  "External/Private Scholarships",
] as const;

const TERM_OPTIONS: { value: IntakeTerm; label: string }[] = [
  { value: "general", label: "General" },
  { value: "fall", label: "Fall" },
  { value: "spring", label: "Spring" },
  { value: "summer", label: "Summer" },
  { value: "winter", label: "Winter" },
  { value: "custom", label: "Custom" },
];

const DEGREE_OPTIONS = ["BSC", "MSC", "PHD", "Diploma", "Associate", "Postdoc", "MBA"] as const;

import { FIELD_OF_STUDY_OPTIONS } from "@/lib/fieldsOfStudy";

const scholarshipSchema = z.object({
  title: z.string().trim().min(1, "Title is required").max(300),
  // Long-form markdown fields — AI extractions can be lengthy, so allow generous limits
  // (previous 2000-char cap was silently rejecting auto-generated content on submit,
  // making it look like user edits had reverted).
  description: z.string().trim().max(10000).optional().or(z.literal("")),
  provider: z.string().trim().max(300).optional().or(z.literal("")),
  country: z.string().trim().max(200).optional().or(z.literal("")),
  field_of_study: z.string().trim().max(2000).optional().or(z.literal("")),
  degree_level: z.string().trim().max(2000).optional().or(z.literal("")),
  funding_amount: z.string().trim().max(300).optional().or(z.literal("")),
  
  deadline_source_url: z.string().trim().url("Must be a valid URL").max(1000).optional().or(z.literal("")),
  
  funding_type: z.string().trim().max(100).optional().or(z.literal("")),
  funding_category: z.string().trim().max(100).optional().or(z.literal("")),
  eligibility_criteria: z.string().trim().max(10000).optional().or(z.literal("")),
  min_gpa: z.coerce.number().min(0).max(10).optional().or(z.literal("").transform(() => undefined)),
  min_cgpa_scale: z.coerce.number().min(1).max(10).optional().or(z.literal("").transform(() => undefined)),
  min_cgpa_percentage: z.coerce.number().min(0).max(100).optional().or(z.literal("").transform(() => undefined)),
  url: z.string().trim().url("Must be a valid URL").max(1000).optional().or(z.literal("")),
  admission_requirements_url: z.string().trim().url("Must be a valid URL").max(1000).optional().or(z.literal("")),
  apply_steps: z.string().trim().max(10000).optional().or(z.literal("")),
  has_application_fee: z.boolean().optional(),
  application_fee_amount: z.string().trim().max(200).optional().or(z.literal("")),
  is_active: z.boolean(),
  auto_publish_enabled: z.boolean().optional(),
  assigned_reviewer_id: z.string().uuid().optional().or(z.literal("")),
  forwarded_to_admin: z.boolean().optional(),
  submission_notes: z.string().trim().max(2000).optional().or(z.literal("")),
});

export type ScholarshipFormValues = z.infer<typeof scholarshipSchema>;

type Props = {
  defaultValues?: Partial<ScholarshipFormValues>;
  defaultIntakes?: ScholarshipIntake[];
  onSubmit: (values: ScholarshipFormValues, intakes: ScholarshipIntake[]) => void;
  loading?: boolean;
  /** Current user is admin — admins can publish without reviewer; mods must assign one */
  isAdmin?: boolean;
  /** Show this banner when editing a previously rejected scholarship */
  rejectionReason?: string | null;
  /** ID of the scholarship being edited — excluded from duplicate detection */
  editingId?: string | null;
};

export default function ScholarshipForm({ defaultValues, defaultIntakes, onSubmit, loading, isAdmin = false, rejectionReason, editingId }: Props) {
  const { data: reviewers = [] } = useReviewers();
  const { data: isMainAdmin = false } = useIsMainAdmin();
  const { settings } = useSiteSettings();
  const globalDefaultApplySteps = (settings?.default_apply_steps?.trim() ? settings.default_apply_steps : DEFAULT_APPLY_STEPS);
  // Stable client-side keys so React reconciliation doesn't mix up date inputs
  // when the user adds/removes/reorders rows or changes a term.
  type IntakeRow = ScholarshipIntake & { _key: string };
  const makeKey = () => `intake_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const withKeys = (rows: ScholarshipIntake[]): IntakeRow[] =>
    rows.map((r) => ({ ...r, _key: (r as any)._key ?? r.id ?? makeKey() }));

  const [intakes, setIntakes] = useState<IntakeRow[]>(() => withKeys(defaultIntakes ?? []));
  // Only resync when the source scholarship actually changes (use a stable signature
  // based on persisted ids), otherwise typing a date would re-trigger a parent
  // re-render → defaultIntakes ref change → state reset → lost dates.
  const intakeSignature = (defaultIntakes ?? []).map((i) => i.id ?? "").join("|") + ":" + (defaultIntakes ?? []).length;
  useEffect(() => { setIntakes(withKeys(defaultIntakes ?? [])); }, [intakeSignature]); // eslint-disable-line react-hooks/exhaustive-deps

  const addIntake = () => setIntakes((prev) => [...prev, { _key: makeKey(), term: "general", custom_label: "", open_date: "", close_date: "", sort_order: prev.length }]);
  const updateIntake = (idx: number, patch: Partial<ScholarshipIntake>) =>
    setIntakes((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  const removeIntake = (idx: number) => setIntakes((prev) => prev.filter((_, i) => i !== idx));

  const form = useForm<ScholarshipFormValues>({
    resolver: zodResolver(scholarshipSchema),
    defaultValues: {
      title: "",
      description: "",
      provider: "",
      country: "",
      field_of_study: "",
      degree_level: "",
      funding_amount: "",
      
      deadline_source_url: "",
      admission_requirements_url: "",
      
      funding_type: "",
      funding_category: "",
      eligibility_criteria: "",
      min_gpa: undefined,
      min_cgpa_scale: undefined,
      min_cgpa_percentage: undefined,
      url: "",
      apply_steps: defaultValues?.apply_steps || globalDefaultApplySteps,
      has_application_fee: false,
      application_fee_amount: "",
      is_active: true,
      auto_publish_enabled: false,
      assigned_reviewer_id: "",
      forwarded_to_admin: false,
      submission_notes: "",
      ...defaultValues,
    },
  });

  const forwardedToAdmin = form.watch("forwarded_to_admin");
  const eligibleReviewers = forwardedToAdmin ? reviewers.filter(r => r.is_admin) : reviewers;

  // Live duplicate detection — debounced fuzzy match against existing scholarships
  const watchedTitle = form.watch("title") || "";
  const watchedProvider = form.watch("provider") || "";
  const watchedCountry = form.watch("country") || "";
  const { matches: duplicateMatches } = useDuplicateScholarshipCheck(
    watchedTitle,
    watchedProvider,
    watchedCountry,
    editingId,
  );

  const handleSubmit = (values: ScholarshipFormValues) => {
    // Reviewer is now assigned automatically (round-robin random pick from eligible pool).
    // Admins editing an already-approved record keep the existing reviewer; otherwise auto-assign.
    let reviewerId = values.assigned_reviewer_id;
    if (!reviewerId) {
      if (eligibleReviewers.length > 0) {
        const pick = eligibleReviewers[Math.floor(Math.random() * eligibleReviewers.length)];
        reviewerId = pick.user_id;
      } else {
        // Graceful fallback: leave unassigned so any eligible reviewer/admin can pick it up later.
        reviewerId = "";
      }
    }
    // Sanitize intakes — drop empty rows, normalize sort order, blank custom_label for non-custom terms
    const cleanedIntakes: ScholarshipIntake[] = intakes
      .filter((it) => it.open_date || it.close_date || (it.term === "custom" && it.custom_label?.trim()))
      .map((it, i) => ({
        ...it,
        custom_label: it.term === "custom" ? (it.custom_label?.trim() || null) : null,
        open_date: it.open_date || null,
        close_date: it.close_date || null,
        sort_order: i,
      }));
    // Require at least one intake with both open and close dates — these now drive deadlines.
    const validIntakes = cleanedIntakes.filter((it) => it.open_date && it.close_date);
    if (validIntakes.length === 0) {
      toast({
        title: "Term intake required",
        description: "Add at least one term intake with both an open date and a close date.",
        variant: "destructive",
      });
      return;
    }
    const invertedIntake = validIntakes.find((it) => it.open_date! > it.close_date!);
    if (invertedIntake) {
      toast({
        title: "Check intake dates",
        description: "The deadline date cannot be before the open date for any term intake.",
        variant: "destructive",
      });
      return;
    }
    // Auto-append academic year suffix (e.g. "2026/2027") to the title if not already present.
    // Uses the earliest intake's open_date year; falls back to current year.
    let finalTitle = values.title;
    if (!/\b(19|20)\d{2}\b/.test(finalTitle)) {
      const earliestOpen = validIntakes
        .map((it) => it.open_date as string)
        .filter(Boolean)
        .sort()[0];
      const baseYear = earliestOpen ? new Date(earliestOpen).getFullYear() : new Date().getFullYear();
      finalTitle = `${finalTitle.trim()} ${baseYear}/${baseYear + 1}`;
    }
    onSubmit({ ...values, title: finalTitle, assigned_reviewer_id: reviewerId }, cleanedIntakes);
  };

  const selectedDegrees = (form.watch("degree_level") || "").split(",").map(s => s.trim()).filter(Boolean);
  const selectedFields = (form.watch("field_of_study") || "").split(",").map(s => s.trim()).filter(Boolean);

  const toggleDegree = (degree: string) => {
    const current = selectedDegrees;
    const updated = current.includes(degree)
      ? current.filter(d => d !== degree)
      : [...current, degree];
    form.setValue("degree_level", updated.join(", "), { shouldValidate: true });
  };

  const toggleFieldOfStudy = (field: string) => {
    const current = selectedFields;
    const updated = current.includes(field)
      ? current.filter(f => f !== field)
      : [...current, field];
    form.setValue("field_of_study", updated.join(", "), { shouldValidate: true });
  };

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(handleSubmit, (errors) => {
          // Surface validation failures so the user isn't left wondering why
          // "Save" silently did nothing (errors are often scrolled out of view).
          const firstField = Object.keys(errors)[0];
          const firstMsg = firstField ? (errors as any)[firstField]?.message : null;
          toast({
            title: "Please fix the highlighted fields",
            description: firstMsg ? `${firstField}: ${firstMsg}` : "Some required fields are missing or invalid.",
            variant: "destructive",
          });
        })}
        className="space-y-4 max-h-[60vh] overflow-y-auto px-4"
      >
        {rejectionReason && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Previously rejected</AlertTitle>
            <AlertDescription>
              <strong>Reviewer feedback:</strong> {rejectionReason}
              <div className="mt-1 text-xs">Edit the details below and resubmit for review.</div>
            </AlertDescription>
          </Alert>
        )}
        <FormField control={form.control} name="title" render={({ field }) => (
          <FormItem>
            <FormLabel>Title *</FormLabel>
            <FormControl><Input {...field} /></FormControl>
            <p className="text-xs text-muted-foreground">
              No need to type the year — we'll automatically append the academic year (e.g. "2026/2027") based on the earliest intake's open date if the title doesn't already include one.
            </p>
            <FormMessage />
          </FormItem>
        )} />
        <DuplicateWarning matches={duplicateMatches} />
        <div className="grid grid-cols-2 gap-4">
          <FormField control={form.control} name="provider" render={({ field }) => (
            <FormItem><FormLabel>Provider</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="country" render={({ field }) => (
            <FormItem><FormLabel>Country</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
          )} />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <FormField control={form.control} name="funding_amount" render={({ field }) => (
            <FormItem><FormLabel>Funding Amount</FormLabel><FormControl><Input placeholder="e.g. $10,000/year" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="funding_type" render={({ field }) => (
            <FormItem>
              <FormLabel>Funding Type</FormLabel>
              <Select onValueChange={(v) => field.onChange(v === "none" ? "" : v)} value={field.value || "none"}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {FUNDING_TYPE_OPTIONS.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )} />
        </div>

        <FormField control={form.control} name="funding_category" render={({ field }) => (
          <FormItem>
            <FormLabel>Funding Category</FormLabel>
            <Select onValueChange={(v) => field.onChange(v === "none" ? "" : v)} value={field.value || "none"}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {FUNDING_CATEGORY_OPTIONS.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />

        {/* Degree Level Multi-Select */}
        <FormField control={form.control} name="degree_level" render={() => (
          <FormItem>
            <FormLabel>Degree Level</FormLabel>
            <div className="flex flex-wrap gap-2 pt-1">
              {DEGREE_OPTIONS.map((degree) => (
                <label key={degree} className="flex items-center gap-1.5 cursor-pointer">
                  <Checkbox
                    checked={selectedDegrees.includes(degree)}
                    onCheckedChange={() => toggleDegree(degree)}
                  />
                  <span className="text-sm">{degree}</span>
                </label>
              ))}
            </div>
            {selectedDegrees.length > 0 && (
              <div className="flex flex-wrap gap-1 pt-1">
                {selectedDegrees.map(d => (
                  <Badge key={d} variant="secondary" className="text-xs gap-1 pr-1">
                    {d}
                    <button
                      type="button"
                      onClick={() => toggleDegree(d)}
                      className="ml-0.5 rounded-full hover:bg-background/60 p-0.5"
                      aria-label={`Remove ${d}`}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            <FormMessage />
          </FormItem>
        )} />

        {/* Field of Study Multi-Select */}
        <FormField control={form.control} name="field_of_study" render={() => (
          <FormItem>
            <FormLabel>Field of Study</FormLabel>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 pt-1">
              {FIELD_OF_STUDY_OPTIONS.map((field) => (
                <label key={field} className="flex items-center gap-1.5 cursor-pointer">
                  <Checkbox
                    checked={selectedFields.includes(field)}
                    onCheckedChange={() => toggleFieldOfStudy(field)}
                  />
                  <span className="text-sm">{field}</span>
                </label>
              ))}
            </div>
            {selectedFields.length > 0 && (
              <div className="flex flex-wrap gap-1 pt-1">
                {selectedFields.map(f => (
                  <Badge key={f} variant="secondary" className="text-xs">{f}</Badge>
                ))}
              </div>
            )}
            <FormMessage />
          </FormItem>
        )} />

        <FormField control={form.control} name="deadline_source_url" render={({ field }) => (
          <FormItem>
            <FormLabel>Deadline source link <span className="text-muted-foreground">(optional)</span></FormLabel>
            <FormControl>
              <Input type="url" placeholder="https://official-scholarship-page.com/deadline" {...field} />
            </FormControl>
            <p className="text-xs text-muted-foreground">
              Paste the official page that shows the deadline so reviewers can verify it. Only visible to reviewers and admins.
            </p>
            <FormMessage />
          </FormItem>
        )} />
        <p className="text-xs text-muted-foreground -mt-2">
          Add the actual open & close dates as <strong>term intakes</strong> below. The soonest upcoming close date is what the public sees on the card.
        </p>

        {/* Term-based intakes */}
        <div className="rounded-md border border-border bg-muted/40 p-3 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <CalendarDays className="h-4 w-4 text-primary" />
              Term intakes <span className="text-destructive">*</span>

            </div>
            <Button type="button" size="sm" variant="outline" onClick={addIntake}>
              <Plus className="h-3.5 w-3.5 mr-1" /> Add intake
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Add separate open &amp; close dates for each term (Fall, Spring, Summer, etc.). At least one intake with both dates is required — these drive the scholarship's deadline.
          </p>

          {intakes.length === 0 ? (
            <p className="text-xs text-destructive italic">At least one term intake is required.</p>
          ) : (
            <div className="space-y-3">
              {intakes.map((intake, idx) => (
                <div key={intake._key} className="rounded-md border border-border bg-background p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <Select value={intake.term} onValueChange={(v) => updateIntake(idx, { term: v as IntakeTerm })}>
                        <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {TERM_OPTIONS.map((t) => (
                            <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      onClick={() => removeIntake(idx)}
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      aria-label="Remove intake"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  {intake.term === "custom" && (
                    <Input
                      placeholder="Custom term name (e.g. Rolling, Quarter 2)"
                      value={intake.custom_label ?? ""}
                      onChange={(e) => updateIntake(idx, { custom_label: e.target.value })}
                      className="h-8 text-sm"
                    />
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs text-muted-foreground">Opens</label>
                      <Input
                        type="date"
                        value={intake.open_date ?? ""}
                        onChange={(e) => updateIntake(idx, { open_date: e.target.value })}
                        className="h-8 text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Closes</label>
                      <Input
                        type="date"
                        value={intake.close_date ?? ""}
                        onChange={(e) => updateIntake(idx, { close_date: e.target.value })}
                        className="h-8 text-sm"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Based CGPA: score out of scale */}
        <div className="space-y-2">
          <FormLabel>Based CGPA</FormLabel>
          <div className="grid grid-cols-3 gap-3 items-end">
            <FormField control={form.control} name="min_gpa" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs text-muted-foreground">Min CGPA</FormLabel>
                <FormControl><Input type="number" step="0.01" placeholder="e.g. 3" {...field} value={field.value ?? ""} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="min_cgpa_scale" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs text-muted-foreground">Out of</FormLabel>
                <FormControl><Input type="number" step="0.1" placeholder="e.g. 5" {...field} value={field.value ?? ""} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <FormField control={form.control} name="min_cgpa_percentage" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs text-muted-foreground">Min CGPA %</FormLabel>
                <FormControl><Input type="number" step="0.1" placeholder="e.g. 60" {...field} value={field.value ?? ""} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          </div>
        </div>

        <FormField control={form.control} name="url" render={({ field }) => (
          <FormItem>
            <FormLabel>Application URL</FormLabel>
            <div className="flex gap-2">
              <FormControl><Input placeholder="https://..." {...field} /></FormControl>
              <Button
                type="button"
                variant="outline"
                size="icon"
                disabled={!field.value}
                onClick={() => field.value && window.open(field.value, "_blank", "noopener,noreferrer")}
                title="Open link"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="admission_requirements_url" render={({ field }) => (
          <FormItem>
            <FormLabel>Admission Requirements Link</FormLabel>
            <div className="flex gap-2">
              <FormControl><Input type="url" placeholder="https://official-page.com/admission-requirements" {...field} /></FormControl>
              <Button
                type="button"
                variant="outline"
                size="icon"
                disabled={!field.value}
                onClick={() => field.value && window.open(field.value, "_blank", "noopener,noreferrer")}
                title="Open link"
              >
                <ExternalLink className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">Optional link to the official admission requirements page for this scholarship.</p>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="description" render={({ field }) => (
          <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea className="min-h-[80px] max-h-[400px] overflow-y-auto resize-none" {...field} ref={(el) => { field.ref(el); if (el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; } }} onInput={(e) => { const t = e.currentTarget; t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; }} /></FormControl><p className="text-xs text-muted-foreground mt-1">Supports markdown: **bold**, - bullet lists, ## headings</p><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="eligibility_criteria" render={({ field }) => (
          <FormItem><FormLabel>Eligibility Criteria</FormLabel><FormControl><Textarea className="min-h-[80px] max-h-[400px] overflow-y-auto resize-none" {...field} ref={(el) => { field.ref(el); if (el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; } }} onInput={(e) => { const t = e.currentTarget; t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; }} /></FormControl><p className="text-xs text-muted-foreground mt-1">Supports markdown: **bold**, - bullet lists, ## headings</p><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="apply_steps" render={({ field }) => (
          <FormItem><FormLabel>Apply Steps (optional)</FormLabel><FormControl><Textarea className="min-h-[80px] max-h-[400px] overflow-y-auto resize-none" placeholder="Leave blank to use default steps..." {...field} ref={(el) => { field.ref(el); if (el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; } }} onInput={(e) => { const t = e.currentTarget; t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; }} /></FormControl><p className="text-xs text-muted-foreground mt-1">Custom step-by-step apply instructions for this scholarship. Supports markdown. Leave blank to use default steps.</p><FormMessage /></FormItem>
        )} />

        {/* Application fee */}
        <div className="rounded-md border border-border bg-muted/40 p-3 space-y-3">
          <FormField control={form.control} name="has_application_fee" render={({ field }) => (
            <FormItem className="flex items-center justify-between gap-3 space-y-0">
              <div>
                <FormLabel>Has application fee?</FormLabel>
                <p className="text-xs text-muted-foreground">Toggle on if applicants must pay a fee to apply.</p>
              </div>
              <FormControl>
                <Switch checked={!!field.value} onCheckedChange={(v) => {
                  field.onChange(v);
                  if (!v) form.setValue("application_fee_amount", "");
                }} />
              </FormControl>
            </FormItem>
          )} />
          {form.watch("has_application_fee") && (
            <FormField control={form.control} name="application_fee_amount" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs text-muted-foreground">Fee amount (optional)</FormLabel>
                <FormControl><Input placeholder="e.g. $50 USD" {...field} value={field.value ?? ""} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
          )}
        </div>
        {isAdmin && (
          <FormField control={form.control} name="is_active" render={({ field }) => (
            <FormItem className="flex items-center gap-3">
              <FormLabel>Active (publish immediately)</FormLabel>
              <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
            </FormItem>
          )} />
        )}

        {isMainAdmin && (
          <FormField control={form.control} name="auto_publish_enabled" render={({ field }) => (
            <FormItem className="flex items-start justify-between gap-3 space-y-0 rounded-md border border-primary/30 bg-primary/5 p-3">
              <div>
                <FormLabel>Automatic yearly publish</FormLabel>
                <p className="text-xs text-muted-foreground">
                  Every year on the intake's open date (same month & day), this scholarship will auto-republish and all intake dates roll forward by 1 year. Only the main admin can change this.
                </p>
              </div>
              <FormControl><Switch checked={!!field.value} onCheckedChange={field.onChange} /></FormControl>
            </FormItem>
          )} />
        )}

        <FormField control={form.control} name="submission_notes" render={({ field }) => (
          <FormItem>
            <FormLabel>Notes to the approver <span className="text-muted-foreground">(optional)</span></FormLabel>
            <FormControl>
              <Textarea
                className="min-h-[70px]"
                placeholder="Anything the reviewer should know? e.g. source link, why deadline differs, missing info you couldn't find…"
                {...field}
                value={field.value ?? ""}
              />
            </FormControl>
            <p className="text-xs text-muted-foreground">Only reviewers and admins see this — not shown to public.</p>
            <FormMessage />
          </FormItem>
        )} />

        {/* Approval workflow controls */}
        <div className="rounded-md border border-border bg-muted/40 p-3 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Shield className="h-4 w-4 text-primary" />
            Review & approval
          </div>

          <FormField control={form.control} name="forwarded_to_admin" render={({ field }) => (
            <FormItem className="flex items-start gap-3 space-y-0">
              <FormControl>
                <Checkbox checked={!!field.value} onCheckedChange={(v) => {
                  field.onChange(!!v);
                  // Reset reviewer if it no longer matches the filter
                  form.setValue("assigned_reviewer_id", "");
                }} />
              </FormControl>
              <div className="text-sm leading-tight">
                <div>Forward to an admin for review</div>
                <p className="text-xs text-muted-foreground">Only admins will be able to approve this scholarship.</p>
              </div>
            </FormItem>
          )} />

          <div className="rounded-md bg-background border border-border p-3 text-sm">
            <div className="font-medium mb-1">Reviewer assignment</div>
            <p className="text-xs text-muted-foreground">
              {eligibleReviewers.length === 0 ? (
                <>No {forwardedToAdmin ? "admins" : "reviewers"} are listed right now. You can still submit — your scholarship will sit in the pending queue until an {forwardedToAdmin ? "admin" : "eligible reviewer"} picks it up.</>
              ) : (
                <>This scholarship will be automatically assigned to one of {eligibleReviewers.length} eligible {forwardedToAdmin ? "admin" : "reviewer"}{eligibleReviewers.length === 1 ? "" : "s"} for approval. You can't review your own work.</>
              )}
            </p>
            {form.formState.errors.assigned_reviewer_id && (
              <p className="text-xs text-destructive mt-2">{form.formState.errors.assigned_reviewer_id.message as string}</p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button type="submit" disabled={loading}>
            {loading ? "Saving..." : isAdmin ? "Save Scholarship" : "Submit for Review"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}
