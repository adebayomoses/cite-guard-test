import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "@/hooks/use-toast";
import { Trash2, Trophy, ExternalLink, Pencil } from "lucide-react";
import { Link } from "react-router-dom";

interface Props {
  onEditScholarship?: (id: string) => void;
}

export default function ChallengeTab({ onEditScholarship }: Props) {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"scholarships" | "submissions">("scholarships");

  const { data: scholarships = [], isLoading: loadingS } = useQuery({
    queryKey: ["admin-challenge-scholarships"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("id, title, provider, country, next_close_date, is_active")
        .eq("is_challenge", true as any)
        .order("country", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: submissions = [], isLoading: loadingSub } = useQuery({
    queryKey: ["admin-challenge-submissions"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("challenge_submissions")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const removeMut = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("scholarships").update({ is_challenge: false } as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Removed from Challenge List" });
      queryClient.invalidateQueries({ queryKey: ["admin-challenge-scholarships"] });
      queryClient.invalidateQueries({ queryKey: ["challenge-scholarships"] });
      queryClient.invalidateQueries({ queryKey: ["scholarships-admin"] });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Trophy className="h-5 w-5 text-amber-500" />
        <h2 className="text-lg font-semibold">Challenge</h2>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="scholarships">Scholarships ({scholarships.length})</TabsTrigger>
          <TabsTrigger value="submissions">Submissions ({submissions.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="scholarships" className="mt-4">
          {loadingS ? (
            <p className="text-muted-foreground text-sm">Loading…</p>
          ) : scholarships.length === 0 ? (
            <p className="text-muted-foreground text-sm">No scholarships in the challenge list yet.</p>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Country</TableHead>
                    <TableHead>Deadline</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scholarships.map((s: any) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium max-w-xs">
                        <div className="truncate">{s.title}</div>
                        {s.provider && <div className="text-xs text-muted-foreground truncate">{s.provider}</div>}
                      </TableCell>
                      <TableCell className="text-sm">{s.country || "—"}</TableCell>
                      <TableCell className="text-sm">
                        {s.next_close_date ? new Date(s.next_close_date).toLocaleDateString() : "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={s.is_active ? "default" : "secondary"}>
                          {s.is_active ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button size="sm" variant="ghost" asChild title="View">
                          <Link to={`/scholarships/${s.id}`}>
                            <ExternalLink className="h-3.5 w-3.5" />
                          </Link>
                        </Button>
                        {onEditScholarship && (
                          <Button size="sm" variant="ghost" onClick={() => onEditScholarship(s.id)} title="Edit">
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => {
                            if (confirm("Remove this scholarship from the Challenge List?")) {
                              removeMut.mutate(s.id);
                            }
                          }}
                          title="Remove from Challenge"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>

        <TabsContent value="submissions" className="mt-4">
          {loadingSub ? (
            <p className="text-muted-foreground text-sm">Loading…</p>
          ) : submissions.length === 0 ? (
            <p className="text-muted-foreground text-sm">No challenge submissions yet.</p>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Course of Study</TableHead>
                    <TableHead>CGPA</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Submitted</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions.map((s: any) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">{s.full_name}</TableCell>
                      <TableCell className="text-sm">{s.email}</TableCell>
                      <TableCell className="text-sm">{s.course_of_study}</TableCell>
                      <TableCell className="text-sm">{s.cgpa}</TableCell>
                      <TableCell className="text-sm">{s.phone}</TableCell>
                      <TableCell className="text-sm">{new Date(s.created_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
