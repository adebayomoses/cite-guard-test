import { useEffect, useState } from "react";
import { TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Check, ExternalLink, Loader2, Pencil, RefreshCw, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { format } from "date-fns";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Pair = {
  a_id: string; a_title: string; a_provider: string | null; a_country: string | null;
  a_status: string | null; a_is_active: boolean; a_created_at: string;
  b_id: string; b_title: string; b_provider: string | null; b_country: string | null;
  b_status: string | null; b_is_active: boolean; b_created_at: string;
  similarity_score: number;
};

type Item = {
  id: string;
  title: string;
  provider: string | null;
  country: string | null;
  status: string | null;
  is_active: boolean;
  created_at: string;
};

type Cluster = { items: Item[]; topSimilarity: number };

function buildClusters(pairs: Pair[]): Cluster[] {
  // Union-find on scholarship IDs
  const parent = new Map<string, string>();
  const find = (x: string): string => {
    if (!parent.has(x)) parent.set(x, x);
    if (parent.get(x) !== x) parent.set(x, find(parent.get(x)!));
    return parent.get(x)!;
  };
  const union = (a: string, b: string) => {
    const ra = find(a), rb = find(b);
    if (ra !== rb) parent.set(ra, rb);
  };
  const itemMap = new Map<string, Item>();
  const topSim = new Map<string, number>();

  for (const p of pairs) {
    union(p.a_id, p.b_id);
    if (!itemMap.has(p.a_id)) itemMap.set(p.a_id, {
      id: p.a_id, title: p.a_title, provider: p.a_provider, country: p.a_country,
      status: p.a_status, is_active: p.a_is_active, created_at: p.a_created_at,
    });
    if (!itemMap.has(p.b_id)) itemMap.set(p.b_id, {
      id: p.b_id, title: p.b_title, provider: p.b_provider, country: p.b_country,
      status: p.b_status, is_active: p.b_is_active, created_at: p.b_created_at,
    });
  }

  const groups = new Map<string, string[]>();
  for (const id of itemMap.keys()) {
    const root = find(id);
    if (!groups.has(root)) groups.set(root, []);
    groups.get(root)!.push(id);
  }

  for (const p of pairs) {
    const root = find(p.a_id);
    const cur = topSim.get(root) ?? 0;
    if (p.similarity_score > cur) topSim.set(root, p.similarity_score);
  }

  return Array.from(groups.entries())
    .map(([root, ids]) => ({
      items: ids.map((id) => itemMap.get(id)!).sort(
        (a, b) => +new Date(a.created_at) - +new Date(b.created_at),
      ),
      topSimilarity: topSim.get(root) ?? 0,
    }))
    .sort((a, b) => b.topSimilarity - a.topSimilarity);
}

interface Props {
  onEdit: (id: string) => void;
}

export default function DuplicateScholarshipsTab({ onEdit }: Props) {
  const { user } = useAuth();
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [loading, setLoading] = useState(false);
  const [threshold, setThreshold] = useState(0.6);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc("find_duplicate_scholarship_clusters", {
      similarity_threshold: threshold,
      max_pairs: 300,
    });
    if (error) {
      toast.error("Failed to scan for duplicates");
    } else {
      setPairs((data as Pair[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("scholarships").delete().eq("id", id);
    if (error) {
      toast.error("Failed to delete");
    } else {
      toast.success("Scholarship deleted");
      setPairs((prev) => prev.filter((p) => p.a_id !== id && p.b_id !== id));
    }
  };

  // Mark every pair in this cluster as "not a duplicate" so it stops appearing
  const handleMarkNotDuplicate = async (clusterIds: string[]) => {
    if (!user) return;
    const rows: { a_id: string; b_id: string; ignored_by: string }[] = [];
    for (let i = 0; i < clusterIds.length; i++) {
      for (let j = i + 1; j < clusterIds.length; j++) {
        const [a, b] = [clusterIds[i], clusterIds[j]].sort();
        rows.push({ a_id: a, b_id: b, ignored_by: user.id });
      }
    }
    const { error } = await supabase
      .from("scholarship_duplicate_ignores")
      .upsert(rows, { onConflict: "a_id,b_id", ignoreDuplicates: true } as any);
    if (error) {
      toast.error("Failed to mark as not duplicate");
    } else {
      toast.success("Marked as not duplicates");
      const idSet = new Set(clusterIds);
      setPairs((prev) => prev.filter((p) => !(idSet.has(p.a_id) && idSet.has(p.b_id))));
    }
  };

  const clusters = buildClusters(pairs);

  return (
    <TabsContent value="duplicates" className="space-y-4">
      <div className="rounded-lg border border-orange-500/30 bg-orange-500/5 p-3 text-sm">
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-orange-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-medium text-orange-700 dark:text-orange-400">
              Likely-duplicate scholarships
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Groups of scholarships whose titles are very similar. Review each group and delete the lower-quality
              or older entry to keep the database clean.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 mt-3">
          <label className="text-xs text-muted-foreground">Similarity threshold:</label>
          <select
            value={threshold}
            onChange={(e) => setThreshold(parseFloat(e.target.value))}
            className="text-xs rounded border border-border bg-background px-2 py-1"
          >
            <option value={0.5}>50% (loose)</option>
            <option value={0.6}>60% (recommended)</option>
            <option value={0.7}>70% (strict)</option>
            <option value={0.8}>80% (very strict)</option>
          </select>
          <Button size="sm" variant="outline" onClick={load} disabled={loading}>
            {loading ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5 mr-1.5" />}
            Rescan
          </Button>
        </div>
      </div>

      {loading && clusters.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin inline mr-2" />Scanning...
        </div>
      ) : clusters.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          No likely duplicates found at this threshold. 🎉
        </div>
      ) : (
        <div className="space-y-3">
          {clusters.map((cluster, idx) => (
            <div key={idx} className="rounded-xl border border-border bg-card p-3 space-y-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="text-sm font-medium">
                  Cluster {idx + 1} · {cluster.items.length} scholarships
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs">
                    {Math.round(cluster.topSimilarity * 100)}% similar
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 text-xs"
                    onClick={() => handleMarkNotDuplicate(cluster.items.map((it) => it.id))}
                    title="These are different scholarships — stop flagging this group"
                  >
                    <Check className="h-3.5 w-3.5 mr-1" />
                    Not a duplicate
                  </Button>
                </div>
              </div>
              <div className="space-y-1.5">
                {cluster.items.map((item, i) => (
                  <div
                    key={item.id}
                    className={`flex items-start justify-between gap-2 rounded-md border p-2.5 text-xs ${
                      i === 0 ? "border-border bg-background" : "border-orange-500/20 bg-orange-500/5"
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{item.title}</span>
                        {i === 0 && <Badge variant="secondary" className="text-[10px] py-0 h-4">Oldest</Badge>}
                        <Badge variant="outline" className="text-[10px] py-0 h-4">
                          {item.status || (item.is_active ? "active" : "inactive")}
                        </Badge>
                      </div>
                      <div className="text-muted-foreground mt-0.5">
                        {item.provider || "—"}
                        {item.country ? ` · ${item.country}` : ""}
                        {" · added "}{format(new Date(item.created_at), "MMM d, yyyy")}
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => window.open(`/scholarships/${item.id}`, "_blank")}
                        title="View"
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => onEdit(item.id)}
                        title="Edit"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 text-destructive hover:text-destructive"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this scholarship?</AlertDialogTitle>
                            <AlertDialogDescription>
                              "{item.title}" will be permanently removed. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(item.id)}
                              className="bg-destructive hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </TabsContent>
  );
}
