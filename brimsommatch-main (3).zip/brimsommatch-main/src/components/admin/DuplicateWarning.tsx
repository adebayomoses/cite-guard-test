import { AlertTriangle, ExternalLink } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import type { SimilarScholarship } from "@/hooks/useDuplicateScholarshipCheck";

interface Props {
  matches: SimilarScholarship[];
}

export default function DuplicateWarning({ matches }: Props) {
  if (matches.length === 0) return null;
  return (
    <Alert className="border-orange-500/40 bg-orange-500/5">
      <AlertTriangle className="h-4 w-4 text-orange-600" />
      <AlertTitle className="text-orange-700 dark:text-orange-400">
        {matches.length} possible duplicate{matches.length === 1 ? "" : "s"} found
      </AlertTitle>
      <AlertDescription className="space-y-2 mt-2">
        <p className="text-xs">
          A scholarship with a similar title already exists. Please review before submitting to avoid duplicates.
          If this is a new intake (e.g. different year), you can still proceed.
        </p>
        <div className="space-y-1.5">
          {matches.map((m) => (
            <div
              key={m.id}
              className="flex items-start justify-between gap-2 rounded-md border border-orange-500/20 bg-background/60 p-2 text-xs"
            >
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">{m.title}</div>
                <div className="text-muted-foreground truncate">
                  {m.provider || "—"}
                  {m.country ? ` · ${m.country}` : ""}
                </div>
                <div className="flex flex-wrap gap-1 mt-1">
                  <Badge variant="outline" className="text-[10px] py-0 h-4">
                    {Math.round(m.similarity_score * 100)}% similar
                  </Badge>
                  {m.provider_match && (
                    <Badge variant="outline" className="text-[10px] py-0 h-4 border-orange-500/40">
                      Same provider
                    </Badge>
                  )}
                  <Badge variant="secondary" className="text-[10px] py-0 h-4">
                    {m.status || (m.is_active ? "active" : "inactive")}
                  </Badge>
                </div>
              </div>
              <a
                href={`/scholarships/${m.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 text-orange-700 dark:text-orange-400 hover:underline inline-flex items-center gap-1"
              >
                View <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          ))}
        </div>
      </AlertDescription>
    </Alert>
  );
}
