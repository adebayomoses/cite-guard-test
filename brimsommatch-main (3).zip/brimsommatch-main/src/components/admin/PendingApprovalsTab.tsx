import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";
import { TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Check, X, Forward, Eye, Loader2, Search, Repeat } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";
import { useReviewers } from "@/hooks/useReviewers";
import { useScholarshipIntakes, termLabel } from "@/hooks/useScholarshipIntakes";
import { useIsMainAdmin } from "@/hooks/useIsMainAdmin";

type PendingRow = any;

const PAGE_SIZE = 50;

export default function PendingApprovalsTab({ viewAsUserId }: { viewAsUserId?: string | null } = {}) {
  const { user } = useAuth();
  const { isAdmin } = useAdminRole();
  const qc = useQueryClient();
  const { data: reviewers = [] } = useReviewers();
  const { data: isMainAdmin = false } = useIsMainAdmin();

  const effectiveUserId = viewAsUserId ?? user?.id ?? null;

  const [previewRow, setPreviewRow] = useState<PendingRow | null>(null);
  const [rejectRow, setRejectRow] = useState<PendingRow | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [forwardRow, setForwardRow] = useState<PendingRow | null>(null);
  const [forwardAdminId, setForwardAdminId] = useState<string>("");
  const [bulkAssignOpen, setBulkAssignOpen] = useState(false);
  const [bulkAssignId, setBulkAssignId] = useState<string>("");
  const { intakes: previewIntakes } = useScholarshipIntakes(previewRow?.id ?? null);

  // Filters
  const [search, setSearch] = useState("");
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [submitterFilter, setSubmitterFilter] = useState<string>("all");
  // Moderators default to "mine" so assigned scholarships appear immediately; admins see all.
  const [statusFilter, setStatusFilter] = useState<string>(isAdmin ? "all" : "mine"); // all | new | resubmitted | forwarded | mine
  const [sortBy, setSortBy] = useState<string>("oldest"); // oldest | newest
  const [visibleCount, setVisibleCount] = useState<number>(PAGE_SIZE);

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["pending-scholarships", effectiveUserId],
    queryFn: async () => {
      if (!effectiveUserId) return [];
      // Include pending rows the user didn't create, PLUS rows assigned to them
      // (so admins can explicitly assign a submitter's own work back to them for review).
      const { data, error } = await supabase
        .from("scholarships")
        .select("*")
        .eq("status", "pending")
        .or(`created_by.neq.${effectiveUserId},assigned_reviewer_id.eq.${effectiveUserId}`)
        .order("submitted_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!effectiveUserId,
    refetchInterval: 60_000,
  });

  // Pull profile names for submitter / reviewer display
  const userIds = Array.from(new Set(
    rows.flatMap((r: any) => [r.created_by, r.assigned_reviewer_id]).filter(Boolean)
  ));
  const { data: profiles = [] } = useQuery({
    queryKey: ["pending-profiles", userIds.sort().join(",")],
    queryFn: async () => {
      if (userIds.length === 0) return [];
      const { data } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", userIds);
      return data ?? [];
    },
    enabled: userIds.length > 0,
  });
  const nameOf = (id?: string | null) => {
    if (!id) return "—";
    const p: any = profiles.find((x: any) => x.user_id === id);
    return p?.full_name || id.slice(0, 8);
  };

  // Unique country list for filter
  const countries = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r: any) => {
      if (!r.country) return;
      r.country.split(",").forEach((p: string) => {
        const t = p.trim();
        if (t) set.add(t);
      });
    });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [rows]);

  // Unique submitter list for filter
  const submitters = useMemo(() => {
    const map = new Map<string, string>();
    rows.forEach((r: any) => {
      if (r.created_by && !map.has(r.created_by)) map.set(r.created_by, nameOf(r.created_by));
    });
    return [...map.entries()]
      .map(([user_id, label]) => ({ user_id, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [rows, profiles]);

  // Apply filters
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = rows.filter((r: any) => {
      if (q) {
        const hay = `${r.title ?? ""} ${r.provider ?? ""} ${r.country ?? ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (countryFilter !== "all") {
        const parts = (r.country || "").split(",").map((c: string) => c.trim()).filter(Boolean);
        if (!parts.includes(countryFilter)) return false;
      }
      if (submitterFilter !== "all" && r.created_by !== submitterFilter) return false;
      const isResub = (r.resubmission_count ?? 0) > 0 || !!r.resubmitted_at;
      const isFwd = !!r.forwarded_to_admin;
      if (statusFilter === "new" && (isResub || isFwd)) return false;
      if (statusFilter === "resubmitted" && !isResub) return false;
      if (statusFilter === "forwarded" && !isFwd) return false;
      if (statusFilter === "mine" && r.assigned_reviewer_id !== effectiveUserId) return false;
      return true;
    });
    list = [...list].sort((a: any, b: any) => {
      const ad = new Date(a.submitted_at || a.created_at).getTime();
      const bd = new Date(b.submitted_at || b.created_at).getTime();
      return sortBy === "newest" ? bd - ad : ad - bd;
    });
    return list;
  }, [rows, search, countryFilter, submitterFilter, statusFilter, sortBy, effectiveUserId]);

  const visible = filtered.slice(0, visibleCount);
  const hasMore = filtered.length > visibleCount;

  const notifyUser = async (toUserId: string, title: string, body: string, url = "/admin") => {
    await supabase.from("notifications").insert({
      user_id: toUserId, title, body, url,
    } as any);
  };

  const approveMutation = useMutation({
    mutationFn: async (row: PendingRow) => {
      const { error } = await supabase
        .from("scholarships")
        .update({ status: "approved", is_active: true } as any)
        .eq("id", row.id);
      if (error) throw error;
      await notifyUser(
        row.created_by,
        "Scholarship approved 🎉",
        `Your scholarship "${row.title}" is now live.`,
        `/scholarships`
      );
      try {
        const today = new Date().toISOString().split("T")[0];
        const eff = row.next_close_date && row.next_close_date >= today ? row.next_close_date : null;
        if (!eff) {
          console.info("Skipping broadcast: scholarship has no future deadline", row.id);
        } else {
          const { data: { session } } = await supabase.auth.getSession();
          if (session) {
            await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-push-notification`, {
              method: "POST",
              headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
              body: JSON.stringify({
                title: "New Scholarship Available! 🎓",
                body: row.title,
                url: "/scholarships",
                broadcast: true,
              }),
            });
          }
        }
      } catch (e) { console.error("push failed", e); }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pending-scholarships"] });
      qc.invalidateQueries({ queryKey: ["pending-scholarships-count"] });
      qc.invalidateQueries({ queryKey: ["scholarships-admin"] });
      toast({ title: "Scholarship approved and published" });
    },
    onError: (e: Error) => toast({ title: "Approval failed", description: e.message, variant: "destructive" }),
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ row, reason }: { row: PendingRow; reason: string }) => {
      const { error } = await supabase
        .from("scholarships")
        .update({ status: "rejected", rejection_reason: reason, is_active: false } as any)
        .eq("id", row.id);
      if (error) throw error;
      await notifyUser(
        row.created_by,
        "Scholarship needs changes",
        `"${row.title}" was rejected. Reason: ${reason}`,
        `/admin`
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pending-scholarships"] });
      qc.invalidateQueries({ queryKey: ["pending-scholarships-count"] });
      setRejectRow(null);
      setRejectReason("");
      toast({ title: "Scholarship rejected" });
    },
    onError: (e: Error) => toast({ title: "Rejection failed", description: e.message, variant: "destructive" }),
  });

  const toggleAutoPublishMutation = useMutation({
    mutationFn: async (row: PendingRow) => {
      const next = !row.auto_publish_enabled;
      const { error } = await supabase
        .from("scholarships")
        .update({ auto_publish_enabled: next } as any)
        .eq("id", row.id);
      if (error) throw error;
      return next;
    },
    onSuccess: (next) => {
      qc.invalidateQueries({ queryKey: ["pending-scholarships"] });
      toast({ title: next ? "Automatic publish enabled" : "Automatic publish disabled" });
    },
    onError: (e: Error) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const forwardMutation = useMutation({
    mutationFn: async ({ row, adminId }: { row: PendingRow; adminId: string }) => {
      const { error } = await supabase
        .from("scholarships")
        .update({ forwarded_to_admin: true, assigned_reviewer_id: adminId } as any)
        .eq("id", row.id);
      if (error) throw error;
      await notifyUser(
        adminId,
        "Scholarship assigned for review",
        `"${row.title}" was assigned to you for approval.`,
        `/admin`
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pending-scholarships"] });
      qc.invalidateQueries({ queryKey: ["pending-scholarships-count"] });
      setForwardRow(null);
      setForwardAdminId("");
      toast({ title: "Assigned successfully" });
    },
    onError: (e: Error) => toast({ title: "Assignment failed", description: e.message, variant: "destructive" }),
  });

  // Bulk-assign all currently filtered scholarships to one reviewer
  const bulkAssignMutation = useMutation({
    mutationFn: async ({ targets, adminId }: { targets: PendingRow[]; adminId: string }) => {
      const ids = targets.map((r) => r.id);
      if (ids.length === 0) return { count: 0 };
      const { error } = await supabase
        .from("scholarships")
        .update({ forwarded_to_admin: true, assigned_reviewer_id: adminId } as any)
        .in("id", ids);
      if (error) throw error;
      await notifyUser(
        adminId,
        `${ids.length} scholarships assigned for review`,
        `You've been assigned ${ids.length} scholarship${ids.length === 1 ? "" : "s"} to review.`,
        `/admin`,
      );
      return { count: ids.length };
    },
    onSuccess: ({ count }) => {
      qc.invalidateQueries({ queryKey: ["pending-scholarships"] });
      qc.invalidateQueries({ queryKey: ["pending-scholarships-count"] });
      setBulkAssignOpen(false);
      setBulkAssignId("");
      toast({ title: `Assigned ${count} scholarship${count === 1 ? "" : "s"}` });
    },
    onError: (e: Error) => toast({ title: "Bulk assign failed", description: e.message, variant: "destructive" }),
  });

  // Reviewer options for bulk assign (admin only) — admins + moderators, excluding self
  const bulkAssignTargets = useMemo(() => {
    return reviewers.map((r) => ({
      user_id: r.user_id,
      label: r.full_name || r.user_id.slice(0, 8),
      tag: r.is_admin ? "Admin" : "Moderator",
    }));
  }, [reviewers]);

  // Targets for the forward/assign dialog
  // Admins: any reviewer + the original submitter (so they can ask the submitter to self-review/redo)
  // Non-admins: admins only (original behaviour)
  const forwardTargets = useMemo(() => {
    if (!forwardRow) return [] as Array<{ user_id: string; label: string; tag?: string }>;
    if (isAdmin) {
      const list = reviewers.map((r) => ({
        user_id: r.user_id,
        label: r.full_name || r.user_id.slice(0, 8),
        tag: r.is_admin ? "Admin" : "Moderator",
      }));
      // include the original submitter if not already in list and not the current user
      if (forwardRow.created_by && forwardRow.created_by !== user?.id && !list.find(l => l.user_id === forwardRow.created_by)) {
        list.push({
          user_id: forwardRow.created_by,
          label: `${nameOf(forwardRow.created_by)} (original submitter)`,
          tag: "Submitter",
        });
      }
      return list;
    }
    return reviewers.filter(r => r.is_admin).map(r => ({
      user_id: r.user_id,
      label: r.full_name || r.user_id.slice(0, 8),
      tag: "Admin",
    }));
  }, [forwardRow, reviewers, isAdmin, user?.id, profiles]);

  return (
    <TabsContent value="approvals">
      {/* Filter bar */}
      <div className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setVisibleCount(PAGE_SIZE); }}
            placeholder="Search title, provider…"
            className="pl-9"
          />
        </div>
        <Select value={countryFilter} onValueChange={(v) => { setCountryFilter(v); setVisibleCount(PAGE_SIZE); }}>
          <SelectTrigger><SelectValue placeholder="Country" /></SelectTrigger>
          <SelectContent className="max-w-[calc(100vw-2rem)]">
            <SelectItem value="all">All countries</SelectItem>
            {countries.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={submitterFilter} onValueChange={(v) => { setSubmitterFilter(v); setVisibleCount(PAGE_SIZE); }}>
          <SelectTrigger><SelectValue placeholder="Submitter" /></SelectTrigger>
          <SelectContent className="max-w-[calc(100vw-2rem)]">
            <SelectItem value="all">All submitters</SelectItem>
            {submitters.map((s) => (
              <SelectItem key={s.user_id} value={s.user_id}>
                <span className="break-words">{s.label}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setVisibleCount(PAGE_SIZE); }}>
          <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="new">New only</SelectItem>
            <SelectItem value="resubmitted">Resubmitted</SelectItem>
            <SelectItem value="forwarded">Forwarded / Assigned</SelectItem>
            <SelectItem value="mine">Assigned to me</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger><SelectValue placeholder="Sort" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="oldest">Oldest first</SelectItem>
            <SelectItem value="newest">Newest first</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <div className="text-xs text-muted-foreground">
          Showing {Math.min(visible.length, filtered.length)} of {filtered.length}
          {filtered.length !== rows.length && ` (filtered from ${rows.length})`}
        </div>
        {isAdmin && filtered.length > 0 && (
          <Button
            size="sm"
            variant="outline"
            className="gap-1"
            onClick={() => setBulkAssignOpen(true)}
          >
            <Forward className="h-3.5 w-3.5" />
            Assign all ({filtered.length})
          </Button>
        )}
      </div>


      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead className="hidden sm:table-cell">Submitter</TableHead>
              <TableHead className="hidden md:table-cell">Assigned</TableHead>
              <TableHead className="hidden lg:table-cell">Submitted</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : visible.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No scholarships match your filters 🎉</TableCell></TableRow>
            ) : visible.map((r: any) => {
              const isForwarded = r.forwarded_to_admin;
              const isResubmitted = (r.resubmission_count ?? 0) > 0 || !!r.resubmitted_at;
              const canAct = isAdmin || !isForwarded || r.assigned_reviewer_id === effectiveUserId;
              return (
                <TableRow key={r.id}>
                  <TableCell className="max-w-[260px]">
                    <div className="font-medium truncate">{r.title}</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {isResubmitted && (
                        <Badge
                          className="text-xs bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30"
                          title={r.previous_rejection_reason ? `Previously rejected: ${r.previous_rejection_reason}` : "Previously rejected and resubmitted"}
                        >
                          Resubmitted{r.resubmission_count > 1 ? ` ×${r.resubmission_count}` : ""}
                        </Badge>
                      )}
                      {isForwarded && <Badge variant="secondary" className="text-xs">Assigned</Badge>}
                      {r.country && <Badge variant="outline" className="text-xs">{r.country}</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">{nameOf(r.created_by)}</TableCell>
                  <TableCell className="hidden md:table-cell">{nameOf(r.assigned_reviewer_id)}</TableCell>
                  <TableCell className="hidden lg:table-cell text-muted-foreground text-xs">
                    {format(new Date(r.submitted_at || r.created_at), "MMM d, h:mm a")}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1 flex-wrap">
                      <Button size="sm" variant="ghost" onClick={() => setPreviewRow(r)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      {(isAdmin || !isForwarded) && (
                        <Button size="sm" variant="ghost" onClick={() => setForwardRow(r)} title={isAdmin ? "Assign to reviewer" : "Forward to admin"}>
                          <Forward className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive"
                        disabled={!canAct || rejectMutation.isPending}
                        onClick={() => setRejectRow(r)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      {isMainAdmin && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className={r.auto_publish_enabled ? "text-primary" : "text-muted-foreground"}
                          disabled={toggleAutoPublishMutation.isPending}
                          onClick={() => toggleAutoPublishMutation.mutate(r)}
                          title={r.auto_publish_enabled ? "Automatic yearly publish: ON" : "Enable automatic yearly publish"}
                        >
                          <Repeat className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        disabled={!canAct || approveMutation.isPending}
                        onClick={() => approveMutation.mutate(r)}
                      >
                        {approveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {hasMore && (
        <div className="mt-4 flex justify-center">
          <Button variant="outline" onClick={() => setVisibleCount((n) => n + PAGE_SIZE)}>
            Load {Math.min(PAGE_SIZE, filtered.length - visibleCount)} more
          </Button>
        </div>
      )}

      {/* Preview Dialog */}
      <Dialog open={!!previewRow} onOpenChange={(o) => !o && setPreviewRow(null)}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>{previewRow?.title}</DialogTitle>
            <DialogDescription>Submitted by {nameOf(previewRow?.created_by)}</DialogDescription>
          </DialogHeader>
          {previewRow && (
            <div className="space-y-3 text-sm">
              {((previewRow.resubmission_count ?? 0) > 0 || previewRow.resubmitted_at) && (
                <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 space-y-1">
                  <div className="font-medium text-amber-700 dark:text-amber-400">
                    Resubmitted after rejection{previewRow.resubmission_count > 1 ? ` (×${previewRow.resubmission_count})` : ""}
                  </div>
                  {previewRow.previous_rejection_reason && (
                    <div className="text-xs text-muted-foreground">
                      <strong>Previous reason:</strong> {previewRow.previous_rejection_reason}
                    </div>
                  )}
                </div>
              )}
              {previewRow.submission_notes && (
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
                  <div className="font-medium text-primary mb-1">Note from submitter</div>
                  <div className="text-sm whitespace-pre-wrap">{previewRow.submission_notes}</div>
                </div>
              )}
              <div className="grid sm:grid-cols-2 gap-x-4 gap-y-2">
                {previewRow.provider && <div><strong>Provider:</strong> {previewRow.provider}</div>}
                {previewRow.country && <div><strong>Country:</strong> {previewRow.country}</div>}
                {previewRow.degree_level && <div><strong>Degree:</strong> {previewRow.degree_level}</div>}
                {previewRow.field_of_study && <div><strong>Field:</strong> {previewRow.field_of_study}</div>}
                {previewRow.funding_amount && <div><strong>Funding:</strong> {previewRow.funding_amount}</div>}
                {previewRow.funding_type && <div><strong>Funding type:</strong> {previewRow.funding_type}</div>}
                {previewRow.next_close_date && <div><strong>Next deadline:</strong> {previewRow.next_close_date}</div>}
                {previewRow.next_open_date && <div><strong>Next open date:</strong> {previewRow.next_open_date}</div>}
                {previewRow.auto_publish_enabled != null && (
                  <div><strong>Auto re-publish:</strong> {previewRow.auto_publish_enabled ? "Enabled" : "Disabled"}</div>
                )}
                {previewRow.is_active != null && (
                  <div><strong>Active:</strong> {previewRow.is_active ? "Yes" : "No"}</div>
                )}
                {(previewRow.min_gpa != null || previewRow.min_cgpa_scale != null || previewRow.min_cgpa_percentage != null) && (
                  <div>
                    <strong>Min CGPA:</strong>{" "}
                    {previewRow.min_gpa ?? "—"}
                    {previewRow.min_cgpa_scale ? ` / ${previewRow.min_cgpa_scale}` : ""}
                    {previewRow.min_cgpa_percentage != null ? ` (${previewRow.min_cgpa_percentage}%)` : ""}
                  </div>
                )}
                {(previewRow.has_application_fee || previewRow.application_fee_amount) && (
                  <div>
                    <strong>Application fee:</strong>{" "}
                    {previewRow.has_application_fee ? (previewRow.application_fee_amount || "Yes") : "None"}
                  </div>
                )}
              </div>

              {previewRow.deadline_source_url && (
                <div className="rounded-md border border-amber-300 bg-amber-50 dark:bg-amber-950/30 p-2">
                  <strong>Deadline source (verify):</strong>{" "}
                  <a
                    href={previewRow.deadline_source_url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-primary underline break-all"
                  >
                    {previewRow.deadline_source_url}
                  </a>
                </div>
              )}

              {previewIntakes.length > 0 && (
                <div>
                  <strong>Term intakes:</strong>
                  <ul className="mt-1 ml-4 list-disc text-muted-foreground space-y-0.5">
                    {previewIntakes.map((it) => (
                      <li key={it.id}>
                        {termLabel(it)}: {it.open_date || "—"} → {it.close_date || "—"}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {previewRow.url && (
                <div className="break-words">
                  <strong>Apply URL:</strong>{" "}
                  <a href={previewRow.url} target="_blank" rel="noreferrer" className="text-primary underline break-all">{previewRow.url}</a>
                </div>
              )}
              {previewRow.admission_requirements_url && (
                <div className="break-words">
                  <strong>Admission requirements URL:</strong>{" "}
                  <a href={previewRow.admission_requirements_url} target="_blank" rel="noreferrer" className="text-primary underline break-all">{previewRow.admission_requirements_url}</a>
                </div>
              )}
              {previewRow.description && (
                <div>
                  <strong>Description:</strong>
                  <div className="whitespace-pre-wrap mt-1 text-muted-foreground">{previewRow.description}</div>
                </div>
              )}
              {previewRow.eligibility_criteria && (
                <div>
                  <strong>Eligibility:</strong>
                  <div className="whitespace-pre-wrap mt-1 text-muted-foreground">{previewRow.eligibility_criteria}</div>
                </div>
              )}
              {previewRow.apply_steps && (
                <div>
                  <strong>How to apply:</strong>
                  <div className="whitespace-pre-wrap mt-1 text-muted-foreground">{previewRow.apply_steps}</div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={!!rejectRow} onOpenChange={(o) => { if (!o) { setRejectRow(null); setRejectReason(""); } }}>
        <DialogContent className="max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>Reject scholarship</DialogTitle>
            <DialogDescription>Tell the submitter what to fix. They'll be able to edit and resubmit.</DialogDescription>
          </DialogHeader>
          <Textarea
            placeholder="e.g. Funding amount is missing, please add a source URL…"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            rows={4}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectRow(null)}>Cancel</Button>
            <Button
              variant="destructive"
              disabled={rejectReason.trim().length < 5 || rejectMutation.isPending}
              onClick={() => rejectRow && rejectMutation.mutate({ row: rejectRow, reason: rejectReason.trim() })}
            >
              {rejectMutation.isPending ? "Rejecting…" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Forward / Assign Dialog */}
      <Dialog open={!!forwardRow} onOpenChange={(o) => { if (!o) { setForwardRow(null); setForwardAdminId(""); } }}>
        <DialogContent className="max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>{isAdmin ? "Assign for review" : "Forward to admin"}</DialogTitle>
            <DialogDescription>
              {isAdmin
                ? "Pick anyone — another admin, a moderator, or even the original submitter — to handle this review."
                : "Choose an admin to take over the review."}
            </DialogDescription>
          </DialogHeader>
          <Select value={forwardAdminId} onValueChange={setForwardAdminId}>
            <SelectTrigger><SelectValue placeholder="Select a reviewer…" /></SelectTrigger>
            <SelectContent className="max-w-[calc(100vw-2rem)]">
              {forwardTargets.length === 0 ? (
                <SelectItem value="none" disabled>No reviewers available</SelectItem>
              ) : forwardTargets.map(t => (
                <SelectItem key={t.user_id} value={t.user_id}>
                  <span className="break-words">{t.label}{t.tag ? ` · ${t.tag}` : ""}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setForwardRow(null)}>Cancel</Button>
            <Button
              disabled={!forwardAdminId || forwardMutation.isPending}
              onClick={() => forwardRow && forwardMutation.mutate({ row: forwardRow, adminId: forwardAdminId })}
            >
              {forwardMutation.isPending ? "Assigning…" : "Assign"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Assign Dialog */}
      <Dialog open={bulkAssignOpen} onOpenChange={(o) => { if (!o) { setBulkAssignOpen(false); setBulkAssignId(""); } }}>
        <DialogContent className="max-w-[calc(100vw-2rem)]">
          <DialogHeader>
            <DialogTitle>Assign all filtered scholarships</DialogTitle>
            <DialogDescription>
              All {filtered.length} scholarship{filtered.length === 1 ? "" : "s"} matching your current filters will be assigned to the chosen reviewer.
            </DialogDescription>
          </DialogHeader>
          <Select value={bulkAssignId} onValueChange={setBulkAssignId}>
            <SelectTrigger><SelectValue placeholder="Select a reviewer…" /></SelectTrigger>
            <SelectContent className="max-w-[calc(100vw-2rem)]">
              {bulkAssignTargets.length === 0 ? (
                <SelectItem value="none" disabled>No reviewers available</SelectItem>
              ) : bulkAssignTargets.map(t => (
                <SelectItem key={t.user_id} value={t.user_id}>
                  <span className="break-words">{t.label}{t.tag ? ` · ${t.tag}` : ""}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBulkAssignOpen(false)}>Cancel</Button>
            <Button
              disabled={!bulkAssignId || bulkAssignMutation.isPending || filtered.length === 0}
              onClick={() => bulkAssignMutation.mutate({ targets: filtered, adminId: bulkAssignId })}
            >
              {bulkAssignMutation.isPending ? "Assigning…" : `Assign ${filtered.length}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}
