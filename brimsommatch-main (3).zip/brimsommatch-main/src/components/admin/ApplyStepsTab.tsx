import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Loader2, AlertTriangle, ExternalLink, RotateCcw } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Link } from "react-router-dom";
import { DEFAULT_APPLY_STEPS } from "@/lib/defaultApplySteps";

const CATEGORIES = [
  "Government Scholarships",
  "University Scholarships",
  "Assistantships",
  "Fellowships",
  "External/Private Scholarships",
] as const;

type Row = { id: string; category: string; steps: string };

export default function ApplyStepsTab() {
  const queryClient = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [resetting, setResetting] = useState(false);

  const { data: customCount } = useQuery({
    queryKey: ["scholarships_with_custom_apply_steps_count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("scholarships")
        .select("id", { count: "exact", head: true })
        .not("apply_steps", "is", null)
        .neq("apply_steps", "");
      if (error) throw error;
      return count ?? 0;
    },
  });

  const bulkReset = async () => {
    setResetting(true);
    try {
      const { error } = await supabase
        .from("scholarships")
        .update({ apply_steps: null })
        .not("apply_steps", "is", null);
      if (error) throw error;
      toast({
        title: "Reset complete",
        description: "All scholarships now use category / global default apply steps.",
      });
      queryClient.invalidateQueries({ queryKey: ["scholarships_with_custom_apply_steps_count"] });
      queryClient.invalidateQueries({ queryKey: ["scholarships"] });
    } catch (e: any) {
      toast({ title: "Reset failed", description: e?.message ?? "Please try again.", variant: "destructive" });
    } finally {
      setResetting(false);
    }
  };

  const { data: rows, isLoading } = useQuery({
    queryKey: ["admin_funding_category_apply_steps"],
    queryFn: async (): Promise<Row[]> => {
      const { data, error } = await (supabase as any)
        .from("funding_category_apply_steps")
        .select("id, category, steps")
        .order("category");
      if (error) throw error;
      return (data ?? []) as Row[];
    },
  });

  const { data: uncategorized } = useQuery({
    queryKey: ["scholarships_missing_funding_category"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("id, title, provider, country")
        .eq("is_active", true)
        .or("funding_category.is.null,funding_category.eq.")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  });

  // Seed drafts from server rows
  useEffect(() => {
    if (!rows) return;
    setDrafts((prev) => {
      const next = { ...prev };
      for (const r of rows) {
        if (next[r.category] === undefined) next[r.category] = r.steps ?? "";
      }
      return next;
    });
  }, [rows]);

  const rowFor = (cat: string) => rows?.find((r) => r.category === cat);

  const save = async (cat: string) => {
    const row = rowFor(cat);
    const value = drafts[cat] ?? "";
    setSavingKey(cat);
    try {
      let error;
      if (row) {
        ({ error } = await (supabase as any)
          .from("funding_category_apply_steps")
          .update({ steps: value })
          .eq("id", row.id));
      } else {
        ({ error } = await (supabase as any)
          .from("funding_category_apply_steps")
          .insert({ category: cat, steps: value }));
      }
      if (error) throw error;
      toast({ title: "Saved", description: `${cat} apply steps updated.` });
      queryClient.invalidateQueries({ queryKey: ["admin_funding_category_apply_steps"] });
      queryClient.invalidateQueries({ queryKey: ["funding_category_apply_steps"] });
    } catch (e: any) {
      toast({ title: "Save failed", description: e?.message ?? "Please try again.", variant: "destructive" });
    } finally {
      setSavingKey(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold">Apply Steps by Funding Category</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Write a tailored "How to apply" guide (markdown) for each funding category. Users see this when a
          scholarship in that category has no custom steps of its own. Empty categories fall back to the global
          default in Site Settings.
        </p>
      </div>

      <Card className="border-primary/30 bg-primary/5">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Bulk reset scholarships to defaults</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Clears the custom apply steps on every scholarship so they fall back to their funding-category
            steps or the global default. Useful after updating the default template — existing scholarships
            keep their own steps until you reset them.
          </p>
          <p className="text-xs text-muted-foreground">
            {customCount ?? "…"} scholarship{customCount === 1 ? "" : "s"} currently have custom apply steps.
          </p>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="sm" variant="outline" disabled={resetting || !customCount}>
                {resetting ? (
                  <><Loader2 className="h-3 w-3 mr-1 animate-spin" /> Resetting…</>
                ) : (
                  <><RotateCcw className="h-3 w-3 mr-1" /> Reset all to default</>
                )}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Reset all custom apply steps?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will clear the custom apply steps on {customCount ?? 0} scholarship
                  {customCount === 1 ? "" : "s"}. They will then use their funding-category steps, or the
                  global default. This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={bulkReset}>Reset all</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>



      {uncategorized && uncategorized.length > 0 && (
        <Card className="border-amber-500/40 bg-amber-500/5">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              {uncategorized.length} active scholarship{uncategorized.length === 1 ? "" : "s"} missing a funding category
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-xs text-muted-foreground">
              These scholarships will fall back to the global default steps. Assign each one a funding category so users
              get the right guide.
            </p>
            <div className="max-h-64 overflow-y-auto rounded-md border border-border bg-background divide-y divide-border">
              {uncategorized.map((s: any) => (
                <div key={s.id} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                  <div className="min-w-0">
                    <div className="font-medium truncate">{s.title}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {s.provider ?? "—"} · {s.country ?? "—"}
                    </div>
                  </div>
                  <Link
                    to={`/admin?edit=${s.id}`}
                    className="inline-flex items-center gap-1 text-xs text-primary hover:underline shrink-0"
                  >
                    Fix <ExternalLink className="h-3 w-3" />
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {CATEGORIES.map((cat) => {
        const row = rowFor(cat);
        const value = drafts[cat] ?? row?.steps ?? "";
        const dirty = row ? value !== (row.steps ?? "") : value.length > 0;
        return (
          <Card key={cat}>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between gap-2 text-base">
                <span>{cat}</span>
                {(!value || value.trim() === "") && (
                  <Badge variant="outline" className="text-xs">Using global default</Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Label className="text-xs text-muted-foreground">
                Markdown supported. Use `##` for section headings and `-` for bullet lists.
              </Label>
              <Textarea
                value={value}
                onChange={(e) => setDrafts((d) => ({ ...d, [cat]: e.target.value }))}
                placeholder={`e.g.\n\n## Step 1 — Confirm eligibility\n- Check…\n\n## Step 2 — Prepare documents\n- …`}
                className="min-h-[220px] font-mono text-sm"
              />
              <div className="flex items-center justify-between gap-2">
                <p className="text-xs text-muted-foreground">
                  {value.trim() ? `${value.length} chars` : "Leave blank to use the global default."}
                </p>
                <Button size="sm" onClick={() => save(cat)} disabled={!dirty || savingKey === cat}>
                  {savingKey === cat ? (
                    <><Loader2 className="h-3 w-3 mr-1 animate-spin" /> Saving…</>
                  ) : (
                    "Save"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}

      <Card className="bg-muted/30">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Resolution order</CardTitle>
        </CardHeader>
        <CardContent className="text-xs text-muted-foreground space-y-1">
          <p>1. Custom steps on the individual scholarship (if any)</p>
          <p>2. Steps for the scholarship's funding category (from this page)</p>
          <p>3. Global default in Site Settings</p>
          <p>4. Built-in fallback (used only if all above are empty)</p>
          <p className="pt-2 opacity-70">Built-in fallback preview length: {DEFAULT_APPLY_STEPS.length} chars.</p>
        </CardContent>
      </Card>
    </div>
  );
}
