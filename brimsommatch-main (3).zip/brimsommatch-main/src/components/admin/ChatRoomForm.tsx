import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
});

export type ChatRoomFormValues = z.infer<typeof schema>;

interface Props {
  defaultValues?: ChatRoomFormValues;
  onSubmit: (values: ChatRoomFormValues) => void;
  loading?: boolean;
}

export default function ChatRoomForm({ defaultValues, onSubmit, loading }: Props) {
  const form = useForm<ChatRoomFormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultValues ?? { name: "", description: "" },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem>
            <FormLabel>Room Name</FormLabel>
            <FormControl><Input {...field} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="description" render={({ field }) => (
          <FormItem>
            <FormLabel>Description</FormLabel>
            <FormControl><Textarea {...field} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <Button type="submit" disabled={loading} className="w-full">
          {loading ? "Saving…" : "Save"}
        </Button>
      </form>
    </Form>
  );
}
