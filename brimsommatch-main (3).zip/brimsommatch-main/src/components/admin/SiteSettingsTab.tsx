import { useState, useRef } from "react";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useSliderImages } from "@/hooks/useSliderImages";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { Loader2, Upload, Image, Share2, ShieldAlert, Trash2, ImagePlus, Gauge, Star, SlidersHorizontal, ListChecks, Mail } from "lucide-react";
import { DEFAULT_APPLY_STEPS } from "@/lib/defaultApplySteps";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";

const SCORE_LIMIT_FIELDS = [
  { key: "limit_score_generation_free", label: "Free Plan", defaultValue: "5" },
  { key: "limit_score_generation_standard", label: "Standard Plan", defaultValue: "15" },
  { key: "limit_score_generation_pro", label: "Pro Plan (0 = Unlimited)", defaultValue: "0" },
] as const;

const REC_LIMIT_FIELDS = [
  { key: "limit_scholarship_recommendation_free", label: "Free Plan", defaultValue: "5" },
  { key: "limit_scholarship_recommendation_standard", label: "Standard Plan", defaultValue: "15" },
  { key: "limit_scholarship_recommendation_pro", label: "Pro Plan (0 = Unlimited)", defaultValue: "0" },
] as const;

const COMPOSITE_FIELDS = [
  { key: "composite_match_weight", label: "Match Score Weight", defaultValue: "0.4", hint: "Value between 0 and 1" },
  { key: "composite_chance_weight", label: "Chance Score Weight", defaultValue: "0.6", hint: "Value between 0 and 1" },
  { key: "recommendation_threshold", label: "Recommendation Threshold (%)", defaultValue: "70", hint: "Min match & chance to qualify" },
] as const;

const SETTING_FIELDS = [
  { key: "hero_badge_text", label: "Hero Badge Text", type: "input", defaultValue: "AI-Powered Scholarship Matching" },
  { key: "hero_title", label: "Hero Title", type: "input", defaultValue: "Find scholarships you'll actually win" },
  { key: "hero_description", label: "Hero Description", type: "textarea", defaultValue: "Stop guessing. Brimsom analyzes your academic profile and matches you with scholarships where you have the strongest chance of success." },
  { key: "features_title", label: "Features Section Title", type: "input", defaultValue: "Everything you need to win" },
  { key: "features_description", label: "Features Section Description", type: "textarea", defaultValue: "From profile analysis to community support — Brimsom gives you the tools to maximize your scholarship success." },
  { key: "cta_title", label: "CTA Title", type: "input", defaultValue: "Ready to find your scholarship?" },
  { key: "cta_description", label: "CTA Description", type: "textarea", defaultValue: "Join thousands of students who are discovering scholarships matched to their unique strengths." },
] as const;

const SOCIAL_FIELDS = [
  { key: "social_instagram", label: "Instagram URL", placeholder: "https://instagram.com/..." },
  { key: "social_twitter", label: "X / Twitter URL", placeholder: "https://x.com/..." },
  { key: "social_tiktok", label: "TikTok URL", placeholder: "https://tiktok.com/@..." },
  { key: "social_youtube", label: "YouTube URL", placeholder: "https://youtube.com/..." },
  { key: "social_linkedin", label: "LinkedIn URL", placeholder: "https://linkedin.com/..." },
  { key: "social_facebook", label: "Facebook URL", placeholder: "https://facebook.com/..." },
] as const;

export default function SiteSettingsTab() {
  const { settings, isLoading, upsertSetting, uploadLogo } = useSiteSettings();
  const { images: sliderImages, uploadImage, deleteImage, updateImage, isLoading: sliderLoading } = useSliderImages();
  const [localValues, setLocalValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [sendingDigest, setSendingDigest] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const sliderFileRef = useRef<HTMLInputElement>(null);
  const phone1Ref = useRef<HTMLInputElement>(null);
  const phone2Ref = useRef<HTMLInputElement>(null);
  const [uploadingPhone, setUploadingPhone] = useState<1 | 2 | null>(null);
  const [sliderAltText, setSliderAltText] = useState("");

  const handlePhoneUpload = async (slot: 1 | 2, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhone(slot);
    try {
      const ext = file.name.split(".").pop();
      const path = `phone-frame-${slot}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("site-assets")
        .upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from("site-assets").getPublicUrl(path);
      const publicUrl = `${data.publicUrl}?t=${Date.now()}`;
      await upsertSetting.mutateAsync({ key: `phone_image_${slot}_url`, value: publicUrl });
      toast({ title: `Phone image ${slot} uploaded!` });
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    }
    setUploadingPhone(null);
    e.target.value = "";
  };

  const handlePhoneClear = async (slot: 1 | 2) => {
    try {
      await upsertSetting.mutateAsync({ key: `phone_image_${slot}_url`, value: "" });
      toast({ title: `Phone image ${slot} removed` });
    } catch (err: any) {
      toast({ title: "Remove failed", description: err.message, variant: "destructive" });
    }
  };

  const getValue = (key: string, defaultValue: string) => {
    if (key in localValues) return localValues[key];
    return settings[key] ?? defaultValue;
  };

  const handleChange = (key: string, value: string) => {
    setLocalValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const promises = Object.entries(localValues).map(([key, value]) =>
        upsertSetting.mutateAsync({ key, value })
      );
      await Promise.all(promises);
      setLocalValues({});
      toast({ title: "Settings saved!" });
    } catch (e: any) {
      toast({ title: "Error saving settings", description: e.message, variant: "destructive" });
    }
    setSaving(false);
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      await uploadLogo.mutateAsync(file);
      toast({ title: "Logo uploaded!" });
    } catch (err: any) {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    }
  };

  if (isLoading) return <div className="py-8 text-center text-muted-foreground">Loading…</div>;

  const hasChanges = Object.keys(localValues).length > 0;

  return (
    <div className="grid gap-6 max-w-2xl">
      {/* Platform Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShieldAlert className="h-5 w-5" /> Platform Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Authentication</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Allow users to log in and sign up. Turn off to hide the auth page before launch.
                <br />
                <span className="font-medium text-xs text-primary">Tip: Admins can bypass by adding ?bypass=true to the /auth URL.</span>
              </p>
            </div>
            <Switch 
              checked={getValue("auth_enabled", "true") === "true"} 
              onCheckedChange={(checked) => handleChange("auth_enabled", checked ? "true" : "false")} 
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Free Mode — Disable Premium</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Make all features free for everyone. Premium plans and usage limits will be bypassed.
              </p>
            </div>
            <Switch 
              checked={getValue("premium_disabled", "false") === "true"} 
              onCheckedChange={(checked) => handleChange("premium_disabled", checked ? "true" : "false")} 
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Show "Upgrade Plan" in Advisor menu</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the Upgrade Plan option in the Brim Advisor profile menu.
              </p>
            </div>
            <Switch
              checked={getValue("advisor_upgrade_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("advisor_upgrade_enabled", checked ? "true" : "false")}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Show "Upgrade" in main menu</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the Upgrade option in the hamburger menu, linking to the Pricing page.
              </p>
            </div>
            <Switch
              checked={getValue("upgrade_menu_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("upgrade_menu_enabled", checked ? "true" : "false")}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Show "Challenge List" menu</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the Challenge List in the hamburger menu. Turn off to hide it from users between challenges.
              </p>
            </div>
            <Switch
              checked={getValue("challenge_menu_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("challenge_menu_enabled", checked ? "true" : "false")}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Google Sign-In</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the "Continue with Google" button on the login page.
              </p>
            </div>
            <Switch
              checked={getValue("google_signin_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("google_signin_enabled", checked ? "true" : "false")}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Apple Sign-In</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the "Continue with Apple" button on the login page.
              </p>
            </div>
            <Switch
              checked={getValue("apple_signin_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("apple_signin_enabled", checked ? "true" : "false")}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
            <div className="space-y-0.5">
              <Label className="text-base">Show "Funding Category" filter</Label>
              <p className="text-sm text-muted-foreground mt-1">
                Show the Funding Category dropdown filter on the scholarship discovery page.
              </p>
            </div>
            <Switch
              checked={getValue("funding_category_filter_enabled", "true") !== "false"}
              onCheckedChange={(checked) => handleChange("funding_category_filter_enabled", checked ? "true" : "false")}
            />
          </div>
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Score Generation Limits */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Gauge className="h-5 w-5" /> Score Generation Limits</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Set the maximum number of score generations per month for each plan. Use 0 for unlimited.
          </p>
          {SCORE_LIMIT_FIELDS.map(({ key, label, defaultValue }) => (
            <div key={key} className="flex items-center gap-4">
              <Label className="w-40 shrink-0">{label}</Label>
              <Input
                type="number"
                min={0}
                className="w-24"
                value={getValue(key, defaultValue)}
                onChange={(e) => handleChange(key, e.target.value)}
              />
              <span className="text-xs text-muted-foreground">/month</span>
            </div>
          ))}
          <div className="flex items-center gap-4 pt-2 border-t border-border">
            <Label className="w-40 shrink-0">Advisor Auto-Score Cap</Label>
            <Input
              type="number"
              min={0}
              className="w-24"
              value={getValue("advisor_auto_score_cap", "5")}
              onChange={(e) => handleChange("advisor_auto_score_cap", e.target.value)}
            />
            <span className="text-xs text-muted-foreground">/month (0 = unlimited)</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Max times the AI advisor can auto-refresh a user's match scores per month before recommending scholarships.
          </p>
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Scholarship Recommendation Limits */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Star className="h-5 w-5" /> Recommendation Limits</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Set the maximum number of "Recommended to Apply" scholarships shown per month for each plan. Use 0 for unlimited.
          </p>
          {REC_LIMIT_FIELDS.map(({ key, label, defaultValue }) => (
            <div key={key} className="flex items-center gap-4">
              <Label className="w-40 shrink-0">{label}</Label>
              <Input
                type="number"
                min={0}
                className="w-24"
                value={getValue(key, defaultValue)}
                onChange={(e) => handleChange(key, e.target.value)}
              />
              <span className="text-xs text-muted-foreground">/month</span>
            </div>
          ))}
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Composite Ranking & Threshold */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><SlidersHorizontal className="h-5 w-5" /> Ranking & Threshold</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Configure how scholarships are ranked and what qualifies as "Recommended to Apply". The two weights should add up to 1.0.
          </p>
          {COMPOSITE_FIELDS.map(({ key, label, defaultValue, hint }) => (
            <div key={key} className="flex items-center gap-4">
              <Label className="w-56 shrink-0">{label}</Label>
              <Input
                type="number"
                step={key.includes("weight") ? "0.1" : "1"}
                min={0}
                max={key.includes("weight") ? 1 : 100}
                className="w-24"
                value={getValue(key, defaultValue)}
                onChange={(e) => handleChange(key, e.target.value)}
              />
              <span className="text-xs text-muted-foreground">{hint}</span>
            </div>
          ))}

          <div className="pt-4 mt-2 border-t border-border space-y-3">
            <div className="flex items-center gap-4">
              <Label className="w-56 shrink-0">GPA Soft Cutoff Tolerance (%)</Label>
              <Input
                type="number"
                step="1"
                min={0}
                max={50}
                className="w-24"
                value={getValue("eligibility_gpa_tolerance_pct", "5")}
                onChange={(e) => handleChange("eligibility_gpa_tolerance_pct", e.target.value)}
              />
              <span className="text-xs text-muted-foreground">e.g. 5 = student with 75% sees scholarships needing 80%</span>
            </div>
          </div>

          <div className="pt-4 mt-2 border-t border-border">
            <div className="flex items-center justify-between rounded-lg border border-border p-4 bg-card">
              <div className="space-y-0.5">
                <Label className="text-base">Enable "Best" Tab</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Show the "Best" tab on Discover Scholarships. Turn off to hide it from users — they'll see For You, New, and Explore All only.
                </p>
              </div>
              <Switch
                checked={getValue("best_tab_enabled", "true") !== "false"}
                onCheckedChange={(checked) => handleChange("best_tab_enabled", checked ? "true" : "false")}
              />
            </div>
          </div>

          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Default Apply Steps */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ListChecks className="h-5 w-5" /> Default Apply Steps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Default step-by-step instructions shown when a scholarship has no custom apply steps. Supports markdown.
          </p>
          <Textarea
            className="min-h-[160px]"
            value={getValue("default_apply_steps", DEFAULT_APPLY_STEPS)}
            onChange={(e) => handleChange("default_apply_steps", e.target.value)}
          />
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Logo Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Image className="h-5 w-5" /> Site Logo</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {settings.logo_url && (
            <div className="rounded-lg border border-border p-4 flex items-center justify-center bg-muted">
              <img src={settings.logo_url} alt="Site logo" className="max-h-20 object-contain" />
            </div>
          )}
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
          <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={uploadLogo.isPending}>
            {uploadLogo.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
            {settings.logo_url ? "Replace Logo" : "Upload Logo"}
          </Button>
        </CardContent>
      </Card>

      {/* Landing Phone Frames */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ImagePlus className="h-5 w-5" /> Landing Phone Frames</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Two images shown side by side on the landing page, right before the "Start for Free" buttons. Portrait phone screenshots work best.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {([1, 2] as const).map((slot) => {
              const url = settings[`phone_image_${slot}_url`];
              const isUploading = uploadingPhone === slot;
              const ref = slot === 1 ? phone1Ref : phone2Ref;
              return (
                <div key={slot} className="space-y-2">
                  <Label>Phone Image {slot}</Label>
                  <div className="rounded-lg border border-border p-3 flex items-center justify-center bg-muted min-h-[160px]">
                    {url ? (
                      <img src={url} alt={`Phone frame ${slot}`} className="max-h-40 object-contain" />
                    ) : (
                      <span className="text-xs text-muted-foreground">No image</span>
                    )}
                  </div>
                  <input
                    ref={ref}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handlePhoneUpload(slot, e)}
                  />
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => ref.current?.click()} disabled={isUploading} className="flex-1">
                      {isUploading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                      {url ? "Replace" : "Upload"}
                    </Button>
                    {url && (
                      <Button variant="ghost" size="sm" onClick={() => handlePhoneClear(slot)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Text Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Landing Page Content</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {SETTING_FIELDS.map(({ key, label, type, defaultValue }) => (
            <div key={key} className="space-y-2">
              <Label>{label}</Label>
              {type === "textarea" ? (
                <Textarea
                  value={getValue(key, defaultValue)}
                  onChange={(e) => handleChange(key, e.target.value)}
                  rows={3}
                />
              ) : (
                <Input
                  value={getValue(key, defaultValue)}
                  onChange={(e) => handleChange(key, e.target.value)}
                />
              )}
            </div>
          ))}
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>
      {/* Social Media Links */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Share2 className="h-5 w-5" /> Social Media Links</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {SOCIAL_FIELDS.map(({ key, label, placeholder }) => (
            <div key={key} className="space-y-2">
              <Label>{label}</Label>
              <Input
                value={getValue(key, "")}
                onChange={(e) => handleChange(key, e.target.value)}
                placeholder={placeholder}
              />
            </div>
          ))}
          <Button onClick={handleSave} disabled={saving || !hasChanges} className="w-full">
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </CardContent>
      </Card>

      {/* Slider Images */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ImagePlus className="h-5 w-5" /> Slider Images</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">Upload images to display in the landing page carousel below the hero section.</p>
          
          {/* Upload */}
          <div className="space-y-2">
            <Label>Alt Text (optional)</Label>
            <Input
              value={sliderAltText}
              onChange={(e) => setSliderAltText(e.target.value)}
              placeholder="Describe the image..."
            />
          </div>
          <input
            ref={sliderFileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              try {
                await uploadImage.mutateAsync({ file, altText: sliderAltText });
                setSliderAltText("");
                toast({ title: "Slider image uploaded!" });
              } catch (err: any) {
                toast({ title: "Upload failed", description: err.message, variant: "destructive" });
              }
              if (sliderFileRef.current) sliderFileRef.current.value = "";
            }}
          />
          <Button variant="outline" onClick={() => sliderFileRef.current?.click()} disabled={uploadImage.isPending}>
            {uploadImage.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
            Upload Image
          </Button>

          {/* Image list */}
          {sliderLoading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : sliderImages.length === 0 ? (
            <p className="text-sm text-muted-foreground">No slider images yet.</p>
          ) : (
            <div className="space-y-3">
              {sliderImages.map((img) => (
                <div key={img.id} className="flex items-center gap-3 rounded-lg border border-border p-3 bg-card">
                  <img src={img.image_url} alt={img.alt_text || ""} className="h-16 w-24 rounded object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">{img.alt_text || "No description"}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Label className="text-xs">Order:</Label>
                      <Input
                        type="number"
                        className="h-7 w-16 text-xs"
                        defaultValue={img.sort_order}
                        onBlur={(e) => {
                          const val = parseInt(e.target.value);
                          if (!isNaN(val) && val !== img.sort_order) {
                            updateImage.mutate({ id: img.id, sort_order: val });
                          }
                        }}
                      />
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={async () => {
                      try {
                        await deleteImage.mutateAsync(img);
                        toast({ title: "Image deleted" });
                      } catch (err: any) {
                        toast({ title: "Delete failed", description: err.message, variant: "destructive" });
                      }
                    }}
                    disabled={deleteImage.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Manual Digest Trigger */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5" /> Scholarship Digest</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Manually trigger the scholarship digest email to all opted-in users. This sends the latest scholarships added in the past 5 days.
          </p>
          <Button
            onClick={async () => {
              setSendingDigest(true);
              try {
                const { error } = await supabase.functions.invoke('send-scholarship-digest');
                if (error) throw error;
                toast({ title: "Digest sent!", description: "Scholarship digest emails have been dispatched." });
              } catch (err: any) {
                toast({ title: "Failed to send digest", description: err.message, variant: "destructive" });
              }
              setSendingDigest(false);
            }}
            disabled={sendingDigest}
            variant="outline"
            className="w-full"
          >
            {sendingDigest ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Mail className="h-4 w-4 mr-2" />}
            {sendingDigest ? "Sending…" : "Send Digest Now"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
