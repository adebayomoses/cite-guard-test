import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Crown, Zap } from "lucide-react";
import type { PlanId } from "@/lib/subscriptionTiers";

interface UpgradePromptProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  feature: string;
  currentPlan: PlanId;
  usage: number;
  limit: number;
  period: string;
}

export default function UpgradePrompt({
  open,
  onOpenChange,
  feature,
  currentPlan,
  usage,
  limit,
  period,
}: UpgradePromptProps) {
  const navigate = useNavigate();

  const periodLabel = period === "day" ? "today" : period === "month" ? "this month" : period === "2month" ? "in this 2-month window" : "in total";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md text-center">
        <DialogHeader>
          <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
            <Crown className="h-6 w-6 text-primary" />
          </div>
          <DialogTitle>Usage Limit Reached</DialogTitle>
          <DialogDescription>
            You've used {usage}/{limit} {feature.replace(/_/g, " ")} {periodLabel} on your{" "}
            <span className="font-semibold capitalize">{currentPlan}</span> plan.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          <Button
            className="w-full"
            onClick={() => {
              onOpenChange(false);
              navigate("/pricing");
            }}
          >
            <Zap className="h-4 w-4 mr-2" />
            Upgrade Plan
          </Button>
          <Button variant="ghost" className="w-full" onClick={() => onOpenChange(false)}>
            Maybe Later
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
