import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useEffect } from "react";
import { FIELD_OF_STUDY_OPTIONS } from "@/lib/fieldsOfStudy";

const ACADEMIC_LEVELS = ["High School / Secondary School", "Undergraduate", "Postgraduate (Master's / PhD)"] as const;
const INTENDED_DEGREE_LEVELS = ["Diploma / Certificate", "Bachelor's", "Master's", "PhD / Doctorate", "Postdoctoral", "Exchange / Short Program"] as const;
const INTENDED_FIELDS = FIELD_OF_STUDY_OPTIONS.filter((f) => f !== "Any / All Fields");

const schema = z.object({
  full_name: z.string().min(1, "Name is required").max(100),
  date_of_birth: z.string().optional(),
  nationality: z.string().max(100).optional(),
  country_of_residence: z.string().max(100).optional(),
  bio: z.string().max(1000).optional(),
  academic_level: z.string().optional(),
  intended_program: z.string().max(200).optional(),
  intended_degree_level: z.string().optional(),
  intended_field_of_study: z.string().max(150).optional(),
});

export type PersonalInfoData = z.infer<typeof schema>;

interface Props {
  defaultValues?: Partial<PersonalInfoData>;
  onNext: (data: PersonalInfoData) => void;
}

export default function PersonalInfoStep({ defaultValues, onNext }: Props) {
  const form = useForm<PersonalInfoData>({
    resolver: zodResolver(schema),
    defaultValues: { full_name: "", date_of_birth: "", nationality: "", country_of_residence: "", bio: "", academic_level: "", intended_program: "", intended_degree_level: "", intended_field_of_study: "", ...defaultValues },
  });

  useEffect(() => {
    if (defaultValues) form.reset({ full_name: "", date_of_birth: "", nationality: "", country_of_residence: "", bio: "", academic_level: "", intended_program: "", intended_degree_level: "", intended_field_of_study: "", ...defaultValues });
  }, [defaultValues]);

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onNext)} className="space-y-5 max-w-lg">
        <FormField control={form.control} name="full_name" render={({ field }) => (
          <FormItem><FormLabel>Full Name *</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="academic_level" render={({ field }) => (
          <FormItem>
            <FormLabel>Your Highest Level of Qualification</FormLabel>
            <Select onValueChange={field.onChange} value={field.value || ""}>
              <FormControl>
                <SelectTrigger>
                  <SelectValue placeholder="Select your academic level" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                {ACADEMIC_LEVELS.map((level) => (
                  <SelectItem key={level} value={level}>{level}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />

        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 space-y-4">
          <div>
            <h3 className="text-sm font-semibold">Study Goals (Abroad)</h3>
            <p className="text-xs text-muted-foreground">Helps us personalize your scholarship matches.</p>
          </div>
          <FormField control={form.control} name="intended_program" render={({ field }) => (
            <FormItem><FormLabel>Program / Course you want to study</FormLabel><FormControl><Input placeholder="e.g. MSc Data Science" {...field} /></FormControl><FormMessage /></FormItem>
          )} />
          <FormField control={form.control} name="intended_degree_level" render={({ field }) => (
            <FormItem>
              <FormLabel>Degree level you're applying for</FormLabel>
              <Select onValueChange={field.onChange} value={field.value || ""}>
                <FormControl><SelectTrigger><SelectValue placeholder="Select intended degree" /></SelectTrigger></FormControl>
                <SelectContent>
                  {INTENDED_DEGREE_LEVELS.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="intended_field_of_study" render={({ field }) => {
            const value = field.value || "";
            const isPreset = (INTENDED_FIELDS as readonly string[]).includes(value);
            const selectValue = value === "" ? "" : isPreset ? value : "__other__";
            return (
              <FormItem>
                <FormLabel>Field of study</FormLabel>
                <Select
                  value={selectValue}
                  onValueChange={(v) => field.onChange(v === "__other__" ? " " : v)}
                >
                  <FormControl><SelectTrigger><SelectValue placeholder="Select your field of study" /></SelectTrigger></FormControl>
                  <SelectContent>
                    {INTENDED_FIELDS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                    <SelectItem value="__other__">Other (specify)</SelectItem>
                  </SelectContent>
                </Select>
                {selectValue === "__other__" && (
                  <Input
                    className="mt-2"
                    placeholder="Type your field of study"
                    value={value.trim()}
                    onChange={(e) => field.onChange(e.target.value || " ")}
                  />
                )}
                <FormMessage />
              </FormItem>
            );
          }} />
        </div>
        <FormField control={form.control} name="date_of_birth" render={({ field }) => (
          <FormItem><FormLabel>Date of Birth</FormLabel><FormControl><Input type="date" {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="nationality" render={({ field }) => (
          <FormItem><FormLabel>Nationality</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="country_of_residence" render={({ field }) => (
          <FormItem><FormLabel>Country of Residence</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <FormField control={form.control} name="bio" render={({ field }) => (
          <FormItem><FormLabel>Bio</FormLabel><FormControl><Textarea rows={4} {...field} /></FormControl><FormMessage /></FormItem>
        )} />
        <div className="flex justify-end pt-2">
          <Button type="submit">Next</Button>
        </div>
      </form>
    </Form>
  );
}
