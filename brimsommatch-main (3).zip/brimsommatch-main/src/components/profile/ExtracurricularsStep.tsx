import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";

export interface ExtracurricularEntry {
  id?: string;
  category: string;
  title: string;
  organization: string;
  description: string;
  date: string;
}

const CATEGORIES = ["award", "leadership", "volunteering", "other"];
const empty = (): ExtracurricularEntry => ({ category: "other", title: "", organization: "", description: "", date: "" });

interface Props {
  defaultValues?: ExtracurricularEntry[];
  onSave: (data: ExtracurricularEntry[]) => void;
  onBack: () => void;
  saving?: boolean;
}

export default function ExtracurricularsStep({ defaultValues, onSave, onBack, saving }: Props) {
  const [entries, setEntries] = useState<ExtracurricularEntry[]>(defaultValues?.length ? defaultValues : [empty()]);

  useEffect(() => {
    if (defaultValues?.length) setEntries(defaultValues);
  }, [defaultValues]);

  const update = (i: number, field: keyof ExtracurricularEntry, value: string) => {
    setEntries(prev => prev.map((e, idx) => idx === i ? { ...e, [field]: value } : e));
  };

  return (
    <div className="space-y-6 max-w-lg">
      {entries.map((entry, i) => (
        <div key={i} className="rounded-lg border border-border p-4 space-y-3 bg-card">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Activity {i + 1}</span>
            {entries.length > 1 && (
              <Button variant="ghost" size="icon" onClick={() => setEntries(prev => prev.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label>Category</Label>
              <Select value={entry.category} onValueChange={v => update(i, "category", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Title *</Label><Input value={entry.title} onChange={e => update(i, "title", e.target.value)} /></div>
            <div><Label>Organization</Label><Input value={entry.organization} onChange={e => update(i, "organization", e.target.value)} /></div>
            <div><Label>Date</Label><Input type="date" value={entry.date} onChange={e => update(i, "date", e.target.value)} /></div>
          </div>
          <div><Label>Description</Label><Textarea rows={2} value={entry.description} onChange={e => update(i, "description", e.target.value)} /></div>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={() => setEntries(prev => [...prev, empty()])}><Plus className="h-4 w-4 mr-1" />Add Activity</Button>
      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onSave(entries)} disabled={saving}>{saving ? "Saving..." : "Save Profile"}</Button>
      </div>
    </div>
  );
}
