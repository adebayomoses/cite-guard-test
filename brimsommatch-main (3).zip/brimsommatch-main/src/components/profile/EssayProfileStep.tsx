import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles } from "lucide-react";

export interface EssayProfileData {
  motivation: string;
  project_or_achievement: string;
  tools_software: string;
  research_interests: string;
  career_goals: string;
  why_study_abroad: string;
  academic_explanations: string;
}

const empty = (): EssayProfileData => ({
  motivation: "",
  project_or_achievement: "",
  tools_software: "",
  research_interests: "",
  career_goals: "",
  why_study_abroad: "",
  academic_explanations: "",
});

interface Props {
  defaultValues?: EssayProfileData;
  onNext: (data: EssayProfileData) => void;
  onBack: () => void;
}

const FIELDS: Array<{ key: keyof EssayProfileData; label: string; placeholder?: string; rows?: number; hint?: string }> = [
  { key: "motivation", label: "Why do you want to study this field (Motivation of Study)?", placeholder: "Share what draws you to this field…", rows: 5, hint: "Aim for 100–300 words." },
  { key: "project_or_achievement", label: "Describe a specific research project or academic achievement", rows: 4 },
  { key: "tools_software", label: "What tools / software do you use?", placeholder: "e.g. Python, MATLAB, SPSS, Figma…", rows: 2 },
  { key: "research_interests", label: "What are your research interests?", rows: 3 },
  { key: "career_goals", label: "What are your career goals?", rows: 3 },
  { key: "why_study_abroad", label: "Why do you want to study abroad?", rows: 3 },
  { key: "academic_explanations", label: "Is there anything in your academic record that needs explaining?", placeholder: "Optional — gaps, low grades, transfers, etc.", rows: 3 },
];

export default function EssayProfileStep({ defaultValues, onNext, onBack }: Props) {
  const [data, setData] = useState<EssayProfileData>(defaultValues ?? empty());

  useEffect(() => {
    if (defaultValues) setData(defaultValues);
  }, [defaultValues]);

  const update = (key: keyof EssayProfileData, value: string) =>
    setData(prev => ({ ...prev, [key]: value }));

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 flex gap-3">
        <Sparkles className="h-5 w-5 text-primary shrink-0 mt-0.5" />
        <p className="text-sm text-foreground/80">
          For strong <strong>SOP / motivation letter / personal statement</strong> writing, this section needs to be filled.
          The more detail you share here, the better Brim can craft your essays.
        </p>
      </div>

      {FIELDS.map(f => (
        <div key={f.key} className="space-y-1.5">
          <Label>{f.label}</Label>
          <Textarea
            rows={f.rows ?? 3}
            value={data[f.key]}
            placeholder={f.placeholder}
            onChange={e => update(f.key, e.target.value)}
          />
          {f.hint && <p className="text-xs text-muted-foreground">{f.hint}</p>}
        </div>
      ))}

      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext(data)}>Next</Button>
      </div>
    </div>
  );
}
