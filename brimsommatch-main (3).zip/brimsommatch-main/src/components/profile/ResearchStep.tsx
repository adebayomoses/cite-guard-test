import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";

export interface ResearchEntry {
  id?: string;
  title: string;
  organization: string;
  description: string;
  start_date: string;
  end_date: string;
  publications: string[];
}

const empty = (): ResearchEntry => ({ title: "", organization: "", description: "", start_date: "", end_date: "", publications: [] });

interface Props {
  defaultValues?: ResearchEntry[];
  academicLevel?: string;
  onNext: (data: ResearchEntry[]) => void;
  onBack: () => void;
}

export default function ResearchStep({ defaultValues, academicLevel, onNext, onBack }: Props) {
  const isHS = academicLevel === "High School / Secondary School";
  const [entries, setEntries] = useState<ResearchEntry[]>(defaultValues?.length ? defaultValues : [empty()]);

  useEffect(() => {
    if (defaultValues?.length) setEntries(defaultValues);
  }, [defaultValues]);

  const update = (i: number, field: keyof ResearchEntry, value: string | string[]) => {
    setEntries(prev => prev.map((e, idx) => idx === i ? { ...e, [field]: value } : e));
  };

  return (
    <div className="space-y-6 max-w-lg">
      {entries.map((entry, i) => (
        <div key={i} className="rounded-lg border border-border p-4 space-y-3 bg-card">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Experience {i + 1}</span>
            {entries.length > 1 && (
              <Button variant="ghost" size="icon" onClick={() => setEntries(prev => prev.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div><Label>Title *</Label><Input value={entry.title} onChange={e => update(i, "title", e.target.value)} /></div>
            <div><Label>Organization</Label><Input value={entry.organization} onChange={e => update(i, "organization", e.target.value)} /></div>
            <div><Label>Start Date</Label><Input type="date" value={entry.start_date} onChange={e => update(i, "start_date", e.target.value)} /></div>
            <div><Label>End Date</Label><Input type="date" value={entry.end_date} onChange={e => update(i, "end_date", e.target.value)} /></div>
          </div>
          <div><Label>Description</Label><Textarea rows={3} value={entry.description} onChange={e => update(i, "description", e.target.value)} /></div>
          {!isHS && (
            <div>
              <Label>Publications (comma-separated)</Label>
              <Input value={entry.publications.join(", ")} onChange={e => update(i, "publications", e.target.value.split(",").map(s => s.trim()).filter(Boolean))} placeholder="Paper 1, Paper 2" />
            </div>
          )}
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={() => setEntries(prev => [...prev, empty()])}><Plus className="h-4 w-4 mr-1" />Add Experience</Button>
      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext(entries)}>Next</Button>
      </div>
    </div>
  );
}
