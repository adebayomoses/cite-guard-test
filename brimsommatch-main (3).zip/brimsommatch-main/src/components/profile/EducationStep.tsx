import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";

export interface EducationEntry {
  id?: string;
  degree_level: string;
  institution: string;
  field_of_study: string;
  gpa: string;
  gpa_scale: string;
  start_date: string;
  end_date: string;
  is_current: boolean;
}

export interface HighSchoolSubject {
  id?: string;
  subject_name: string;
  grade: string;
}

const empty = (): EducationEntry => ({ degree_level: "", institution: "", field_of_study: "", gpa: "", gpa_scale: "", start_date: "", end_date: "", is_current: false });

const GPA_SCALE_OPTIONS = [
  { value: "4", label: "/ 4.0" },
  { value: "5", label: "/ 5.0" },
  { value: "7", label: "/ 7.0" },
  { value: "10", label: "/ 10.0" },
  { value: "100", label: "/ 100 (%)" },
];
const emptySubject = (): HighSchoolSubject => ({ subject_name: "", grade: "" });

const HS_DEGREE_OPTIONS = ["High School Diploma", "A-Levels", "IB Diploma", "WAEC/NECO", "Other"];

interface Props {
  defaultValues?: EducationEntry[];
  defaultSubjects?: HighSchoolSubject[];
  academicLevel?: string;
  onNext: (data: EducationEntry[], subjects?: HighSchoolSubject[]) => void;
  onBack: () => void;
}

export default function EducationStep({ defaultValues, defaultSubjects, academicLevel, onNext, onBack }: Props) {
  const [entries, setEntries] = useState<EducationEntry[]>(defaultValues?.length ? defaultValues : [empty()]);
  const [subjects, setSubjects] = useState<HighSchoolSubject[]>(defaultSubjects?.length ? defaultSubjects : [emptySubject()]);

  const isHS = academicLevel === "High School / Secondary School";

  useEffect(() => {
    if (defaultValues?.length) setEntries(defaultValues);
  }, [defaultValues]);

  useEffect(() => {
    if (defaultSubjects?.length) setSubjects(defaultSubjects);
  }, [defaultSubjects]);

  const update = (i: number, field: keyof EducationEntry, value: string | boolean) => {
    setEntries(prev => prev.map((e, idx) => idx === i ? { ...e, [field]: value } : e));
  };

  const updateSubject = (i: number, field: keyof HighSchoolSubject, value: string) => {
    setSubjects(prev => prev.map((s, idx) => idx === i ? { ...s, [field]: value } : s));
  };

  const valid = entries.some(e => e.degree_level && e.institution);

  return (
    <div className="space-y-6 max-w-lg">
      {entries.map((entry, i) => (
        <div key={i} className="rounded-lg border border-border p-4 space-y-3 bg-card">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Entry {i + 1}</span>
            {entries.length > 1 && (
              <Button variant="ghost" size="icon" onClick={() => setEntries(prev => prev.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {isHS ? (
              <div>
                <Label>Degree Level *</Label>
                <Select value={entry.degree_level} onValueChange={(v) => update(i, "degree_level", v)}>
                  <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent>
                    {HS_DEGREE_OPTIONS.map((opt) => (
                      <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div><Label>Degree Level *</Label><Input value={entry.degree_level} onChange={e => update(i, "degree_level", e.target.value)} placeholder="e.g. Bachelor's" /></div>
            )}
            <div><Label>Institution *</Label><Input value={entry.institution} onChange={e => update(i, "institution", e.target.value)} /></div>
            {!isHS && (
              <div><Label>Field of Study</Label><Input value={entry.field_of_study} onChange={e => update(i, "field_of_study", e.target.value)} /></div>
            )}
            <div>
              <Label>{isHS ? "Grade / Score" : "GPA"}</Label>
              <Input value={entry.gpa} onChange={e => update(i, "gpa", e.target.value)} placeholder={isHS ? "e.g. A*, 85%, 8/9" : "e.g. 3.8"} />
            </div>
            {!isHS && (
              <div>
                <Label>GPA Scale</Label>
                <Select value={entry.gpa_scale} onValueChange={(v) => update(i, "gpa_scale", v)}>
                  <SelectTrigger><SelectValue placeholder="Select scale" /></SelectTrigger>
                  <SelectContent>
                    {GPA_SCALE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div><Label>Start Date</Label><Input type="date" value={entry.start_date} onChange={e => update(i, "start_date", e.target.value)} /></div>
            <div><Label>End Date</Label><Input type="date" value={entry.end_date} onChange={e => update(i, "end_date", e.target.value)} disabled={entry.is_current} /></div>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox checked={entry.is_current} onCheckedChange={v => update(i, "is_current", !!v)} id={`current-${i}`} />
            <Label htmlFor={`current-${i}`} className="text-sm">Currently enrolled</Label>
          </div>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={() => setEntries(prev => [...prev, empty()])}><Plus className="h-4 w-4 mr-1" />Add Entry</Button>

      {isHS && (
        <div className="rounded-lg border border-border p-4 space-y-3 bg-card">
          <span className="text-sm font-medium">Key Subjects / Courses</span>
          {subjects.map((sub, i) => (
            <div key={i} className="flex gap-2 items-end">
              <div className="flex-1">
                <Label>Subject</Label>
                <Input value={sub.subject_name} onChange={e => updateSubject(i, "subject_name", e.target.value)} placeholder="e.g. Mathematics" />
              </div>
              <div className="w-28">
                <Label>Grade</Label>
                <Input value={sub.grade} onChange={e => updateSubject(i, "grade", e.target.value)} placeholder="e.g. A*" />
              </div>
              {subjects.length > 1 && (
                <Button variant="ghost" size="icon" onClick={() => setSubjects(prev => prev.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4" /></Button>
              )}
            </div>
          ))}
          <Button variant="outline" size="sm" onClick={() => setSubjects(prev => [...prev, emptySubject()])}><Plus className="h-4 w-4 mr-1" />Add Subject</Button>
        </div>
      )}

      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext(entries, isHS ? subjects : undefined)} disabled={!valid}>Next</Button>
      </div>
    </div>
  );
}
