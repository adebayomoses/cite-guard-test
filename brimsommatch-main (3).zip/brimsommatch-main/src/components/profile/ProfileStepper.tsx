import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

const STEPS = [
  "Personal Info",
  "Education",
  "Test Scores",
  "Essay Profile",
  "Experience",
  "Documents",
  "Extracurriculars",
];

interface ProfileStepperProps {
  currentStep: number;
  completedSteps: Set<number>;
  onStepClick?: (step: number) => void;
}

export default function ProfileStepper({ currentStep, completedSteps, onStepClick }: ProfileStepperProps) {
  return (
    <div className="flex items-center gap-1 w-full max-w-3xl mx-auto">
      {STEPS.map((label, i) => {
        const isActive = i === currentStep;
        const isDone = completedSteps.has(i);
        const clickable = !!onStepClick;
        return (
          <div key={label} className="flex-1 flex flex-col items-center gap-1.5">
            <div className="flex items-center w-full">
              {i > 0 && (
                <div className={cn("h-0.5 flex-1", isDone || isActive ? "bg-primary" : "bg-border")} />
              )}
              <button
                type="button"
                onClick={clickable ? () => onStepClick!(i) : undefined}
                disabled={!clickable}
                aria-label={`Go to ${label}`}
                aria-current={isActive ? "step" : undefined}
                className={cn(
                  "w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-[10px] sm:text-xs font-medium shrink-0 transition-all",
                  isActive && "bg-primary text-primary-foreground",
                  isDone && !isActive && "bg-primary/20 text-primary",
                  !isActive && !isDone && "bg-muted text-muted-foreground",
                  clickable && "cursor-pointer hover:scale-110 hover:ring-2 hover:ring-primary/30"
                )}
              >
                {isDone && !isActive ? <Check className="h-4 w-4" /> : i + 1}
              </button>
              {i < STEPS.length - 1 && (
                <div className={cn("h-0.5 flex-1", isDone ? "bg-primary" : "bg-border")} />
              )}
            </div>
            {clickable ? (
              <button
                type="button"
                onClick={() => onStepClick!(i)}
                className={cn(
                  "text-[10px] leading-tight text-center hidden sm:block hover:text-primary transition-colors",
                  isActive ? "text-foreground font-medium" : "text-muted-foreground"
                )}
              >
                {label}
              </button>
            ) : (
              <span className={cn("text-[10px] leading-tight text-center hidden sm:block", isActive ? "text-foreground font-medium" : "text-muted-foreground")}>
                {label}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export { STEPS };
