import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, PenLine, FileText, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface ResumeData {
  personal_info?: {
    full_name?: string;
    nationality?: string;
    country_of_residence?: string;
    bio?: string;
  };
  education?: Array<{
    degree_level: string;
    institution: string;
    field_of_study?: string;
    gpa?: string;
    gpa_scale?: string;
    start_date?: string;
    end_date?: string;
    is_current?: boolean;
  }>;
  test_scores?: Array<{
    test_type: string;
    score: string;
    max_score?: string;
    date_taken?: string;
  }>;
  research?: Array<{
    title: string;
    organization?: string;
    description?: string;
    start_date?: string;
    end_date?: string;
    publications?: string[];
  }>;
  extracurriculars?: Array<{
    category: string;
    title: string;
    organization?: string;
    description?: string;
    date?: string;
  }>;
}

interface Props {
  onResumeData: (data: ResumeData) => void;
  onManual: () => void;
}

export default function ProfileMethodChooser({ onResumeData, onManual }: Props) {
  const { user } = useAuth();
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!["pdf", "docx", "doc"].includes(ext || "")) {
      toast.error("Please upload a PDF or Word document.");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error("File must be under 10MB.");
      return;
    }

    setUploading(true);
    try {
      const filePath = `${user.id}/resume_${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("user-documents")
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data, error } = await supabase.functions.invoke("parse-resume", {
        body: { file_path: filePath },
      });

      if (error) throw error;

      if (data?.error) {
        toast.error(data.error);
        return;
      }

      toast.success("Resume parsed! Review and edit your profile below.");
      onResumeData(data);
    } catch (err: any) {
      console.error("Resume upload error:", err);
      toast.error(err.message || "Failed to parse resume. Try filling manually.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-xl font-bold">How would you like to fill your profile?</h2>
        <p className="text-sm text-muted-foreground">
          Upload your resume for quick auto-fill, or enter details manually.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 max-w-lg mx-auto">
        {/* Upload Resume */}
        <Card
          className="cursor-pointer hover:border-primary/50 transition-colors relative overflow-hidden group"
          onClick={() => !uploading && fileRef.current?.click()}
        >
          <CardContent className="flex flex-col items-center justify-center gap-2 p-4 text-center">
            {uploading ? (
              <>
                <Loader2 className="h-8 w-8 text-primary animate-spin" />
                <span className="text-sm font-medium">Parsing...</span>
              </>
            ) : (
              <>
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Upload className="h-5 w-5 text-primary" />
                </div>
                <span className="font-semibold text-sm">Upload Resume</span>
                <span className="text-xs text-muted-foreground">PDF or Word</span>
              </>
            )}
          </CardContent>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.doc,.docx"
            className="hidden"
            onChange={handleUpload}
            disabled={uploading}
          />
        </Card>

        {/* Fill Manually */}
        <Card
          className="cursor-pointer hover:border-primary/50 transition-colors group"
          onClick={() => !uploading && onManual()}
        >
          <CardContent className="flex flex-col items-center justify-center gap-2 p-4 text-center">
            <div className="h-10 w-10 rounded-full bg-secondary/60 flex items-center justify-center group-hover:bg-secondary transition-colors">
              <PenLine className="h-5 w-5 text-foreground" />
            </div>
            <span className="font-semibold text-sm">Fill Manually</span>
            <span className="text-xs text-muted-foreground">Step-by-step form</span>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export type { ResumeData };
