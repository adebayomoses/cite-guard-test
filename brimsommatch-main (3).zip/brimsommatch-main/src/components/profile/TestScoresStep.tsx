import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2 } from "lucide-react";

export interface TestScoreEntry {
  id?: string;
  test_type: string;
  score: string;
  max_score: string;
  date_taken: string;
}

const TEST_TYPES = ["GRE", "TOEFL", "IELTS", "SAT", "ACT", "GMAT", "LSAT", "MCAT", "Other"];
const empty = (): TestScoreEntry => ({ test_type: "", score: "", max_score: "", date_taken: "" });

interface Props {
  defaultValues?: TestScoreEntry[];
  onNext: (data: TestScoreEntry[]) => void;
  onBack: () => void;
}

export default function TestScoresStep({ defaultValues, onNext, onBack }: Props) {
  const [entries, setEntries] = useState<TestScoreEntry[]>(defaultValues?.length ? defaultValues : [empty()]);

  useEffect(() => {
    if (defaultValues?.length) setEntries(defaultValues);
  }, [defaultValues]);

  const update = (i: number, field: keyof TestScoreEntry, value: string) => {
    setEntries(prev => prev.map((e, idx) => idx === i ? { ...e, [field]: value } : e));
  };

  return (
    <div className="space-y-6 max-w-lg">
      {entries.map((entry, i) => (
        <div key={i} className="rounded-lg border border-border p-4 space-y-3 bg-card">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Score {i + 1}</span>
            {entries.length > 1 && (
              <Button variant="ghost" size="icon" onClick={() => setEntries(prev => prev.filter((_, idx) => idx !== i))}><Trash2 className="h-4 w-4" /></Button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label>Test Type *</Label>
              <Select value={entry.test_type} onValueChange={v => update(i, "test_type", v)}>
                <SelectTrigger><SelectValue placeholder="Select test" /></SelectTrigger>
                <SelectContent>{TEST_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Score *</Label><Input value={entry.score} onChange={e => update(i, "score", e.target.value)} placeholder="e.g. 320" /></div>
            <div><Label>Max Score</Label><Input value={entry.max_score} onChange={e => update(i, "max_score", e.target.value)} placeholder="e.g. 340" /></div>
            <div><Label>Date Taken</Label><Input type="date" value={entry.date_taken} onChange={e => update(i, "date_taken", e.target.value)} /></div>
          </div>
        </div>
      ))}
      <Button variant="outline" size="sm" onClick={() => setEntries(prev => [...prev, empty()])}><Plus className="h-4 w-4 mr-1" />Add Score</Button>
      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext(entries)}>Next</Button>
      </div>
    </div>
  );
}
