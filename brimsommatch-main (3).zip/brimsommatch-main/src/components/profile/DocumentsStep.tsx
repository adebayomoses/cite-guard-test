import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface DocFile {
  id?: string;
  document_type: string;
  file_url: string;
  file_name: string;
}

interface Props {
  defaultDocs?: DocFile[];
  defaultSop?: string;
  onNext: (docs: DocFile[], sop: string) => void;
  onBack: () => void;
}

export default function DocumentsStep({ defaultDocs, defaultSop, onNext, onBack }: Props) {
  const { user } = useAuth();
  const [docs, setDocs] = useState<DocFile[]>(defaultDocs ?? []);
  const [sop, setSop] = useState(defaultSop ?? "");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (defaultDocs) setDocs(defaultDocs);
    if (defaultSop) setSop(defaultSop);
  }, [defaultDocs, defaultSop]);

  const uploadFile = async (file: File, type: string) => {
    if (!user) return;
    setUploading(true);
    const path = `${user.id}/${type}/${Date.now()}-${file.name}`;
    const { error } = await supabase.storage.from("user-documents").upload(path, file);
    if (error) {
      toast.error("Upload failed: " + error.message);
      setUploading(false);
      return;
    }
    const { data: { publicUrl } } = supabase.storage.from("user-documents").getPublicUrl(path);
    setDocs(prev => [...prev, { document_type: type, file_url: publicUrl, file_name: file.name }]);
    toast.success(`${file.name} uploaded`);
    setUploading(false);
  };

  const handleFileInput = (type: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) uploadFile(file, type);
    e.target.value = "";
  };

  const removeDoc = (i: number) => setDocs(prev => prev.filter((_, idx) => idx !== i));

  const docsOfType = (type: string) => docs.filter(d => d.document_type === type);

  return (
    <div className="space-y-6 max-w-lg">
      {/* Resume */}
      <div className="rounded-lg border border-border p-4 space-y-3 bg-card">
        <Label className="text-base font-semibold">Resume / CV</Label>
        {docsOfType("resume").map((d, i) => (
          <div key={i} className="flex items-center justify-between text-sm bg-muted rounded p-2">
            <span className="flex items-center gap-2"><FileText className="h-4 w-4" />{d.file_name}</span>
            <Button variant="ghost" size="icon" onClick={() => removeDoc(docs.indexOf(d))}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        <div>
          <Input type="file" accept=".pdf,.doc,.docx" onChange={handleFileInput("resume")} className="hidden" id="resume-upload" />
          <Button variant="outline" size="sm" asChild disabled={uploading}><label htmlFor="resume-upload" className="cursor-pointer"><Upload className="h-4 w-4 mr-1" />Upload Resume</label></Button>
        </div>
      </div>

      {/* SOP */}
      <div className="rounded-lg border border-border p-4 space-y-3 bg-card">
        <Label className="text-base font-semibold">Statement of Purpose</Label>
        <Textarea rows={6} value={sop} onChange={e => setSop(e.target.value)} placeholder="Write your statement of purpose here, or upload a file below..." />
        {docsOfType("sop").map((d, i) => (
          <div key={i} className="flex items-center justify-between text-sm bg-muted rounded p-2">
            <span className="flex items-center gap-2"><FileText className="h-4 w-4" />{d.file_name}</span>
            <Button variant="ghost" size="icon" onClick={() => removeDoc(docs.indexOf(d))}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        <div>
          <Input type="file" accept=".pdf,.doc,.docx" onChange={handleFileInput("sop")} className="hidden" id="sop-upload" />
          <Button variant="outline" size="sm" asChild disabled={uploading}><label htmlFor="sop-upload" className="cursor-pointer"><Upload className="h-4 w-4 mr-1" />Upload SOP File</label></Button>
        </div>
      </div>

      {/* Recommendation Letters */}
      <div className="rounded-lg border border-border p-4 space-y-3 bg-card">
        <Label className="text-base font-semibold">Recommendation Letters</Label>
        {docsOfType("recommendation").map((d, i) => (
          <div key={i} className="flex items-center justify-between text-sm bg-muted rounded p-2">
            <span className="flex items-center gap-2"><FileText className="h-4 w-4" />{d.file_name}</span>
            <Button variant="ghost" size="icon" onClick={() => removeDoc(docs.indexOf(d))}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        <div>
          <Input type="file" accept=".pdf,.doc,.docx" onChange={handleFileInput("recommendation")} className="hidden" id="rec-upload" />
          <Button variant="outline" size="sm" asChild disabled={uploading}><label htmlFor="rec-upload" className="cursor-pointer"><Upload className="h-4 w-4 mr-1" />Upload Letter</label></Button>
        </div>
      </div>

      <div className="flex justify-between pt-2">
        <Button variant="ghost" onClick={onBack}>Back</Button>
        <Button onClick={() => onNext(docs, sop)}>Next</Button>
      </div>
    </div>
  );
}
