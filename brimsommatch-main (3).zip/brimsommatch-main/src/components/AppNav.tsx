import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";
import { supabase } from "@/integrations/supabase/client";
import { usePushNotifications } from "@/hooks/usePushNotifications";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { Button } from "@/components/ui/button";
import { NotificationCenter } from "@/components/NotificationCenter";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "next-themes";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Bookmark,
  GraduationCap,
  LogOut,
  Menu,
  Search,
  MessageCircle,
  Shield,
  UserPen,
  LayoutDashboard,
  ClipboardList,
  Settings,
  Loader2,
  Globe,
  FileText,
  HelpCircle,
  Sparkles,
  Trophy,
  Crown,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/brim-ai-chat", label: "Brim Ai Chat", icon: Sparkles },
  { to: "/scholarships", label: "Scholarships", icon: Search },
  { to: "/saved", label: "Saved", icon: Bookmark },
  { to: "/community", label: "Community", icon: MessageCircle },
  { to: "/tracker", label: "Tracker", icon: ClipboardList },
  { to: "/blog", label: "Blog", icon: FileText },
  { to: "/faqs", label: "FAQs", icon: HelpCircle },
  { to: "/profile", label: "Profile", icon: UserPen },
];

export default function AppNav() {
  const { user, signOut } = useAuth();
  const { isAdmin, isModerator } = useAdminRole();
  const { supported, isSubscribed, loading: pushLoading, errorMessage: pushError, subscribe, unsubscribe } = usePushNotifications();
  const { settings } = useSiteSettings();
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [digestEnabled, setDigestEnabled] = useState(true);
  const [digestLoading, setDigestLoading] = useState(false);
  const [weeklyFocusEnabled, setWeeklyFocusEnabled] = useState(true);
  const [weeklyFocusLoading, setWeeklyFocusLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('email_preferences')
      .select('digest_enabled, weekly_focus_enabled')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setDigestEnabled(data.digest_enabled);
          if (typeof (data as any).weekly_focus_enabled === 'boolean') {
            setWeeklyFocusEnabled((data as any).weekly_focus_enabled);
          }
        }
      });
  }, [user]);

  const handleToggleDigest = async (checked: boolean) => {
    if (!user) return;
    setDigestLoading(true);
    // Upsert: insert if doesn't exist, update if it does
    const { error } = await supabase
      .from('email_preferences')
      .upsert({ user_id: user.id, digest_enabled: checked }, { onConflict: 'user_id' });
    if (error) {
      toast({ title: "Failed to update preference", variant: "destructive" });
    } else {
      setDigestEnabled(checked);
      toast({ title: checked ? "Scholarship digest enabled" : "Scholarship digest disabled" });
    }
    setDigestLoading(false);
  };

  const handleToggleWeeklyFocus = async (checked: boolean) => {
    if (!user) return;
    setWeeklyFocusLoading(true);
    const { error } = await supabase
      .from('email_preferences')
      .upsert({ user_id: user.id, weekly_focus_enabled: checked } as any, { onConflict: 'user_id' });
    if (error) {
      toast({ title: "Failed to update preference", variant: "destructive" });
    } else {
      setWeeklyFocusEnabled(checked);
      toast({ title: checked ? "Weekly Focus 5 enabled" : "Weekly Focus 5 disabled" });
    }
    setWeeklyFocusLoading(false);
  };

  const handleToggleNotifications = async () => {
    if (isSubscribed) {
      await unsubscribe();
      toast({ title: "Notifications disabled" });
    } else {
      const ok = await subscribe();
      if (ok) {
        toast({ title: "Notifications enabled!" });
      } else {
        toast({
          title: "Could not enable notifications",
          description: pushError || "Please check your browser settings and try again.",
          variant: "destructive",
        });
      }
    }
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav
      className="border-b border-border bg-background fixed top-0 left-0 right-0 w-full z-50"
      style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}
    >

      <div className="w-full max-w-7xl mx-auto flex items-center justify-between h-16 px-4">

        {/* Logo */}
        <div className="flex items-center gap-2">
          <Link to="/dashboard" className="flex items-center gap-2">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt="Logo" className="h-8 w-8 rounded-lg object-contain" />
            ) : (
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
            )}
            <span className="text-xl font-bold font-serif">Brimsom</span>
          </Link>
        </div>

        <div className="flex items-center gap-1">
          <NotificationCenter />
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Settings">
                <Settings className="h-5 w-5" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56 p-3" align="end">
              <div className="space-y-3">
                {supported && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Push Notifications</span>
                    <Switch
                      checked={isSubscribed}
                      onCheckedChange={handleToggleNotifications}
                      disabled={pushLoading}
                    />
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Scholarship Digest</span>
                  <Switch
                    checked={digestEnabled}
                    onCheckedChange={handleToggleDigest}
                    disabled={digestLoading}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Weekly Focus 5</span>
                  <Switch
                    checked={weeklyFocusEnabled}
                    onCheckedChange={handleToggleWeeklyFocus}
                    disabled={weeklyFocusLoading}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Dark Mode</span>
                  <Switch
                    checked={theme === "dark"}
                    onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
                  />
                </div>
              </div>
            </PopoverContent>
          </Popover>
          <Button variant="ghost" size="icon" onClick={() => setOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile Sheet */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="w-72 flex flex-col pt-[max(2rem,env(safe-area-inset-top,0px))] pb-[max(1rem,env(safe-area-inset-bottom,0px))]">
          <SheetHeader>
            <SheetTitle className="text-left text-sm font-normal text-muted-foreground truncate">
              {user?.email}
            </SheetTitle>
          </SheetHeader>

          <div className="flex flex-col gap-1 mt-4 flex-1">
            {navItems.map((item) => (
              <Button
                key={item.to}
                variant={isActive(item.to) ? "secondary" : "ghost"}
                className="justify-start"
                asChild
                onClick={() => setOpen(false)}
              >
                <Link to={item.to}>
                  <item.icon className="h-4 w-4 mr-2" />
                  {item.label}
                </Link>
              </Button>
            ))}
            {settings.challenge_menu_enabled !== "false" && (
              <Button
                variant={isActive("/challenge-list") ? "secondary" : "ghost"}
                className="justify-start"
                asChild
                onClick={() => setOpen(false)}
              >
                <Link to="/challenge-list">
                  <Trophy className="h-4 w-4 mr-2 text-amber-500" />
                  Challenge List
                </Link>
              </Button>
            )}
            {settings.upgrade_menu_enabled !== "false" && (
              <Button
                variant={isActive("/pricing") ? "secondary" : "ghost"}
                className="justify-start"
                asChild
                onClick={() => setOpen(false)}
              >
                <Link to="/pricing">
                  <Crown className="h-4 w-4 mr-2 text-primary" />
                  Upgrade
                </Link>
              </Button>
            )}
            {(isAdmin || isModerator) && (
              <Button
                variant={isActive("/info-sources") ? "secondary" : "ghost"}
                className="justify-start"
                asChild
                onClick={() => setOpen(false)}
              >
                <Link to="/info-sources">
                  <Globe className="h-4 w-4 mr-2" />
                  Info Sources
                </Link>
              </Button>
            )}
            {(isAdmin || isModerator) && (
              <Button
                variant={isActive("/admin") ? "secondary" : "ghost"}
                className="justify-start"
                asChild
                onClick={() => setOpen(false)}
              >
                <Link to="/admin">
                  <Shield className="h-4 w-4 mr-2" />
                  Admin
                </Link>
              </Button>
            )}
          </div>

          <Button
            variant="outline"
            className="justify-start mt-auto"
            onClick={() => {
              setOpen(false);
              signOut();
            }}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </SheetContent>
      </Sheet>
    </nav>
  );
}
