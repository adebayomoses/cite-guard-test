import { useEffect } from "react";
import { useLocation } from "react-router-dom";

interface SEOProps {
  title: string;
  description: string;
  /** Optional path override (defaults to current location.pathname). */
  path?: string;
  image?: string;
  type?: "website" | "article";
}

const SITE_URL = "https://brimsom.io";
const DEFAULT_IMAGE =
  "https://storage.googleapis.com/gpt-engineer-file-uploads/VYKbEavl6Sb31c3Li7MreWlsLs13/social-images/social-1773009325951-Screenshot_2026-03-08_233509.webp";

function setMeta(attr: "name" | "property", key: string, content: string) {
  const selector = `meta[${attr}="${key}"]`;
  let el = document.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function setCanonical(href: string) {
  let el = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!el) {
    el = document.createElement("link");
    el.rel = "canonical";
    document.head.appendChild(el);
  }
  el.href = href;
}

/**
 * Per-route head tag updater. Sets <title>, description, canonical,
 * Open Graph, and Twitter card tags so social previews are unique
 * per page instead of falling back to the sitewide defaults in
 * index.html.
 */
export default function SEO({ title, description, path, image, type = "website" }: SEOProps) {
  const location = useLocation();

  useEffect(() => {
    const url = `${SITE_URL}${path ?? location.pathname}`;
    const img = image || DEFAULT_IMAGE;

    document.title = title;
    setMeta("name", "description", description);

    setMeta("property", "og:title", title);
    setMeta("property", "og:description", description);
    setMeta("property", "og:url", url);
    setMeta("property", "og:type", type);
    setMeta("property", "og:image", img);

    setMeta("name", "twitter:card", "summary_large_image");
    setMeta("name", "twitter:title", title);
    setMeta("name", "twitter:description", description);
    setMeta("name", "twitter:image", img);

    setCanonical(url);
  }, [title, description, path, image, type, location.pathname]);

  return null;
}
