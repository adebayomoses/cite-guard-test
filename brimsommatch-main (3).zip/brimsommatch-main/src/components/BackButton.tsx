import { ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Props {
  fallback?: string;
  label?: string;
  className?: string;
  iconOnly?: boolean;
}

export default function BackButton({ fallback = "/dashboard", label = "Back", className, iconOnly = false }: Props) {
  const navigate = useNavigate();
  const handleClick = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate(fallback);
  };

  if (iconOnly) {
    return (
      <Button
        variant="ghost"
        size="icon"
        onClick={handleClick}
        aria-label={label}
        className={cn("h-9 w-9 -ml-1 shrink-0 text-muted-foreground hover:text-foreground", className)}
      >
        <ChevronLeft className="h-5 w-5" />
      </Button>
    );
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={handleClick}
      className={cn("gap-1 -ml-2 text-muted-foreground hover:text-foreground", className)}
    >
      <ChevronLeft className="h-4 w-4" /> {label}
    </Button>
  );
}
