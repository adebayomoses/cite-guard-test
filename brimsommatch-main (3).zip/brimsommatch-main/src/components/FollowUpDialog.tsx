import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useApplicationTracker } from "@/hooks/useApplicationTracker";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle2, Clock, XCircle } from "lucide-react";

const LS_KEY = "lastFollowUpShown";
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export default function FollowUpDialog() {
  const { user } = useAuth();
  const { applications, updateApplication, deleteApplication } = useApplicationTracker();
  const [open, setOpen] = useState(false);
  const [handled, setHandled] = useState<Set<string>>(new Set());

  const drafting = applications.filter((a) => a.status === "drafting");

  useEffect(() => {
    if (!user || drafting.length === 0) return;
    const last = localStorage.getItem(LS_KEY);
    if (!last) {
      localStorage.setItem(LS_KEY, String(Date.now()));
      return;
    }
    if (Date.now() - Number(last) >= WEEK_MS) setOpen(true);
  }, [user, drafting.length]);

  const markHandled = (id: string) => {
    setHandled((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  };

  const handleSubmitted = (id: string) => {
    updateApplication.mutate({ id, status: "submitted" });
    markHandled(id);
  };

  const handleNotInterested = (id: string) => {
    deleteApplication.mutate(id);
    markHandled(id);
  };

  const handleDismiss = () => {
    localStorage.setItem(LS_KEY, String(Date.now()));
    setOpen(false);
  };

  const remaining = drafting.filter((a) => !handled.has(a.id));

  useEffect(() => {
    if (open && remaining.length === 0 && drafting.length > 0 && handled.size > 0) {
      handleDismiss();
    }
  }, [remaining.length, handled.size]);

  if (!user) return null;

  return (
    <AlertDialog open={open} onOpenChange={(v) => { if (!v) handleDismiss(); }}>
      <AlertDialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md mx-auto">
        <AlertDialogHeader>
          <AlertDialogTitle>Scholarship Check-In</AlertDialogTitle>
          <AlertDialogDescription>
            You have {remaining.length} scholarship{remaining.length !== 1 ? "s" : ""} still in drafting. Have you submitted any?
          </AlertDialogDescription>
        </AlertDialogHeader>

        <ScrollArea className="max-h-[50vh]">
          <div className="space-y-3 pr-2">
            {remaining.map((app) => (
              <div key={app.id} className="rounded-lg border border-border p-2.5 sm:p-3 space-y-2">
                <p className="text-sm font-medium truncate">
                  {app.scholarship_title || app.custom_name || "Unknown Scholarship"}
                </p>
                <div className="flex flex-wrap gap-1.5 sm:gap-2">
                  <Button size="sm" variant="default" className="text-xs h-7" onClick={() => handleSubmitted(app.id)}>
                    <CheckCircle2 className="h-3 w-3 mr-1" /> Submitted
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => markHandled(app.id)}>
                    <Clock className="h-3 w-3 mr-1" /> Not Yet
                  </Button>
                  <Button size="sm" variant="ghost" className="text-xs h-7 text-destructive" onClick={() => handleNotInterested(app.id)}>
                    <XCircle className="h-3 w-3 mr-1" /> Not Interested
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <AlertDialogFooter>
          <AlertDialogCancel onClick={handleDismiss}>Dismiss</AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
