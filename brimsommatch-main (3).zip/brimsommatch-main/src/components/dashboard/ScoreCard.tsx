import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

interface ScoreCardProps {
  score: number;
  summary: string;
  loading?: boolean;
  showLink?: boolean;
}

export default function ScoreCard({ score, summary, loading, showLink = false }: ScoreCardProps) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;

  const color =
    score <= 30 ? "hsl(0, 72%, 51%)" :
    score <= 60 ? "hsl(45, 93%, 47%)" :
    "hsl(142, 71%, 45%)";

  if (loading) {
    return (
      <div className="rounded-3xl border border-border bg-card p-6">
        <h3 className="font-semibold mb-3">Win Chance Score</h3>
        <div className="text-4xl font-bold text-muted-foreground">—</div>
        <p className="text-sm text-muted-foreground mt-1">Loading...</p>
      </div>
    );
  }

  return (
    <div className="rounded-3xl border border-border bg-card p-4 md:p-6 flex flex-col items-center text-center h-full">
      <h3 className="font-semibold text-sm md:text-base mb-2 md:mb-3">Win Chance Score</h3>
      <div className="flex flex-col items-center gap-2 md:gap-3">
        <svg width="72" height="72" viewBox="0 0 96 96" className="shrink-0 md:w-24 md:h-24">
          <circle cx="48" cy="48" r={radius} fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
          <circle
            cx="48" cy="48" r={radius} fill="none"
            stroke={color} strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - progress}
            strokeLinecap="round"
            transform="rotate(-90 48 48)"
            className="transition-all duration-700"
          />
          <text x="48" y="48" textAnchor="middle" dominantBaseline="central"
            className="fill-foreground font-bold" fontSize="20">
            {score}%
          </text>
        </svg>
        {!showLink && <p className="text-xs md:text-sm text-muted-foreground">{summary}</p>}
      </div>
      {showLink && (
        <>
          <p className="text-xs md:text-sm text-muted-foreground mt-1.5 md:mt-2">Click to generate your score!</p>
          <Link to="/score" className="mt-1 md:mt-2 inline-flex items-center gap-1 text-xs md:text-sm text-primary hover:underline">
            View Details <ArrowRight className="h-3 w-3 md:h-3.5 md:w-3.5" />
          </Link>
        </>
      )}
    </div>
  );
}
