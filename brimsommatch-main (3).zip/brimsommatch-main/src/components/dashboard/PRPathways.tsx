import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { ChevronDown } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

const pathways = [
  { country: "Canada", flag: "🇨🇦", timeline: "3–5 years", steps: "Study Permit → Post-Grad Work Permit → Express Entry / PNP → PR" },
  { country: "UK", flag: "🇬🇧", timeline: "6+ years", steps: "Skilled Worker Visa → Indefinite Leave to Remain (ILR) after 5 years → Citizenship" },
  { country: "New Zealand", flag: "🇳🇿", timeline: "3–5 years", steps: "Student Visa → Post-Study Work Visa → Skilled Migrant / Work to Residence → PR" },
  { country: "Austria", flag: "🇦🇹", timeline: "5+ years", steps: "Red-White-Red Card → Red-White-Red Plus → Permanent Residence after 5 years" },
  { country: "Sweden", flag: "🇸🇪", timeline: "4–7 years", steps: "Student Visa → Work Permit → Permanent Residence after 4–7 years of work residence" },
  { country: "Germany", flag: "🇩🇪", timeline: "2–5 years", steps: "Student Visa → EU Blue Card / Work Visa → PR after 21–33 months (Blue Card) or 5 years" },
  { country: "France", flag: "🇫🇷", timeline: "5+ years", steps: "Student Visa → Work Permit → Carte de Résident (10-year PR) after 5 years" },
  { country: "Italy", flag: "🇮🇹", timeline: "5+ years", steps: "Student Visa → Work Permit → EU Long-Term Residence Permit after 5 years" },
  { country: "Spain", flag: "🇪🇸", timeline: "5+ years", steps: "Student Visa → Work Permit / Highly-Skilled → Long-Term EU Residence after 5 years" },
  { country: "Portugal", flag: "🇵🇹", timeline: "5+ years", steps: "Student Visa → Work Permit / D-type Residence Visa → Permanent Residence after 5 years" },
  { country: "Netherlands", flag: "🇳🇱", timeline: "5+ years", steps: "Student Visa → Orientation Year Visa → Highly-Skilled Migrant Visa → PR after 5 years" },
  { country: "Finland", flag: "🇫🇮", timeline: "4+ years", steps: "Student Residence Permit → Work Residence Permit → Permanent Residence after 4 years" },
  { country: "Norway", flag: "🇳🇴", timeline: "3+ years", steps: "Student Permit → Skilled Worker Visa → Permanent Residence after 3 years" },
  { country: "Switzerland", flag: "🇨🇭", timeline: "5–10 years", steps: "Work Permit B → Settlement Permit C after 5–10 years (depends on nationality & canton)" },
  { country: "Lithuania", flag: "🇱🇹", timeline: "5+ years", steps: "Student Visa → Temporary Residence Permit → Long-Term Residence after 5 years" },
  { country: "Bulgaria", flag: "🇧🇬", timeline: "5+ years", steps: "Student Visa → Work & Residence Permit → Long-Term EU Residence after 5 years" },
  { country: "Iceland", flag: "🇮🇸", timeline: "4+ years", steps: "Work Permit (Qualified Professionals) → Permanent Residence after 4 years" },
  { country: "Japan", flag: "🇯🇵", timeline: "1–10 years", steps: "Highly Skilled Professional Visa → PR after 1–5 years (points-based), standard = 10 years" },
  { country: "Russia", flag: "🇷🇺", timeline: "2+ years", steps: "Work Permit / Highly-Qualified Specialist → Temporary Residence Permit → PR after 1–2+ years" },
];

function getTimelineColor(timeline: string) {
  if (timeline.startsWith("1") || timeline.startsWith("2") || timeline.startsWith("3")) return "bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30";
  if (timeline.startsWith("4") || timeline.startsWith("5")) return "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30";
  return "bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30";
}

export default function PRPathways() {
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-1">🛫 PR Pathways</h2>
      <p className="text-sm text-muted-foreground mb-4">
        Before you japa in 2026, confirm the PR pathway for each country
      </p>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {pathways.map((p) => {
          const isOpen = expanded === p.country;
          return (
            <button
              key={p.country}
              onClick={() => setExpanded(isOpen ? null : p.country)}
              className={`rounded-xl border bg-card p-4 text-left transition-all hover:shadow-md ${isOpen ? "ring-2 ring-primary/40" : "border-border"}`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-2xl shrink-0">{p.flag}</span>
                  <span className="font-medium text-sm truncate">{p.country}</span>
                </div>
                <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
              </div>
              <Badge variant="outline" className={`mt-2 text-[10px] ${getTimelineColor(p.timeline)}`}>
                {p.timeline}
              </Badge>
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <p className="text-xs text-muted-foreground mt-3 leading-relaxed border-t border-border pt-3">
                      {p.steps}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          );
        })}
      </div>
    </div>
  );
}
