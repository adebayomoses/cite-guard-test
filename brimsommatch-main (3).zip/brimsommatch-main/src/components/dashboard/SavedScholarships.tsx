import { Bookmark } from "lucide-react";
import { Link } from "react-router-dom";

interface Props {
  scholarships: any[];
  loading: boolean;
}

export default function SavedScholarships({ scholarships, loading }: Props) {
  if (loading) return <div className="rounded-xl border border-border bg-card p-5"><p className="text-sm text-muted-foreground">Loading...</p></div>;

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-semibold mb-3 flex items-center gap-2">
        <Bookmark className="h-4 w-4 text-primary" /> Saved Scholarships
      </h3>
      {scholarships.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No saved scholarships yet. <Link to="/scholarships" className="text-primary underline">Browse scholarships</Link> to save some.
        </p>
      ) : (
        <ul className="space-y-2">
          {scholarships.slice(0, 5).map((s: any) => (
            <li key={s.id} className="text-sm truncate">{s.title}</li>
          ))}
          {scholarships.length > 5 && (
            <li className="text-xs text-muted-foreground">+{scholarships.length - 5} more</li>
          )}
        </ul>
      )}
    </div>
  );
}
