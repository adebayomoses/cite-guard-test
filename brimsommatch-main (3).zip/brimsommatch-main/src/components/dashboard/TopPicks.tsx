import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trophy, ArrowRight, Calendar } from "lucide-react";
import { getCountryFlag } from "@/lib/countryFlags";
import { format } from "date-fns";

interface Match {
  scholarship_id: string;
  score: number;
  chance: number;
  reason: string;
}

interface Scholarship {
  id: string;
  title: string;
  provider: string | null;
  url: string | null;
  funding_amount: string | null;
  funding_type: string | null;
  country: string | null;
  next_close_date: string | null;
}

export default function TopPicks({ matches }: { matches: Match[] }) {
  const { user } = useAuth();
  const [scholarships, setScholarships] = useState<Record<string, Scholarship>>({});

  const trackApplyClick = (scholarshipId: string) => {
    if (user) {
      supabase.from("scholarship_apply_clicks").insert({ scholarship_id: scholarshipId, user_id: user.id }).then(() => {});
    }
  };

  const top = [...matches].sort((a, b) => b.score - a.score).slice(0, 5);

  useEffect(() => {
    if (!top.length) return;
    const ids = top.map((m) => m.scholarship_id);
    const today = new Date().toISOString().split("T")[0];
    supabase
      .from("scholarships")
      .select("id, title, provider, url, funding_amount, funding_type, country, next_close_date")
      .in("id", ids)
      .eq("is_active", true)
      .or(`next_close_date.is.null,next_close_date.gte.${today}`)
      .then(({ data }) => {
        if (data) {
          const map: Record<string, Scholarship> = {};
          data.forEach((s) => (map[s.id] = s));
          setScholarships(map);
        }
      });
  }, [top.map((m) => m.scholarship_id).join(",")]);

  const displayed = top.filter((m) => scholarships[m.scholarship_id]);
  if (!displayed.length) return null;

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm sm:text-lg font-semibold flex items-center gap-1.5">
          <Trophy className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
          🎯 Top Picks for You
        </h2>
        <Link to="/scholarships?tab=foryou&view=top" className="text-xs sm:text-sm text-primary hover:underline inline-flex items-center gap-1 whitespace-nowrap">
          View All <ArrowRight className="h-3 w-3 sm:h-3.5 sm:w-3.5" />
        </Link>
      </div>

      {/* Mobile: vertical list */}
      <div className="flex flex-col gap-3 sm:hidden">
        {displayed.map((m) => {
          const s = scholarships[m.scholarship_id];
          return (
            <Link
              key={m.scholarship_id}
              to={`/scholarships/${m.scholarship_id}`}
              className="block rounded-xl border border-primary/30 bg-card p-3 flex items-center gap-3 cursor-pointer hover:border-primary/60 transition-colors"
            >
              {s?.country && (
                <span className="text-2xl leading-none shrink-0">{getCountryFlag(s.country)}</span>
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <h3 className="font-semibold text-sm leading-tight line-clamp-1 flex-1">{s?.title ?? "Scholarship"}</h3>
                  <Badge className="text-[10px] font-semibold shrink-0 bg-primary/15 text-primary hover:bg-primary/20">
                    {m.score}%
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-1">{s?.provider ?? ""}</p>
                {m.reason && (
                  <p className="text-[11px] text-muted-foreground/90 line-clamp-1 mt-0.5" title={m.reason}>
                    <span className="text-primary font-medium">Why: </span>{m.reason}
                  </p>
                )}
                {s?.next_close_date && (
                  <p className="text-[11px] text-muted-foreground flex items-center gap-1 mt-0.5">
                    <Calendar className="h-2.5 w-2.5" />
                    {format(new Date(s.next_close_date), "d MMM yyyy")}
                  </p>
                )}
              </div>
              {s?.url ? (
                <a href={s.url} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackApplyClick(m.scholarship_id); }}>
                  <Button size="sm" className="text-xs rounded-lg h-8 px-3 shrink-0">Apply</Button>
                </a>
              ) : (
                <span onClick={(e) => e.stopPropagation()}>
                  <Button size="sm" variant="outline" className="text-xs rounded-lg h-8 px-3 shrink-0">View</Button>
                </span>
              )}
            </Link>
          );
        })}
      </div>

      {/* Desktop: horizontal scroll */}
      <div className="hidden sm:flex gap-4 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
        {displayed.map((m) => {
          const s = scholarships[m.scholarship_id];
          return (
            <Link
              key={m.scholarship_id}
              to={`/scholarships/${m.scholarship_id}`}
              className="min-w-[220px] max-w-[260px] shrink-0 rounded-2xl border border-primary/30 bg-card p-4 flex flex-col gap-2 cursor-pointer hover:border-primary/60 transition-colors"
            >
              <div className="flex items-center justify-between">
                {s?.country && (
                  <span className="text-xl leading-none">{getCountryFlag(s.country)}</span>
                )}
                <Badge className="text-xs font-semibold bg-primary/15 text-primary hover:bg-primary/20">
                  <Trophy className="h-3 w-3 mr-1" />
                  {m.score}% Match
                </Badge>
              </div>
              <h3 className="font-semibold text-sm leading-tight line-clamp-2">
                {s?.title ?? "Scholarship"}
              </h3>
              <p className="text-xs text-muted-foreground line-clamp-1">
                {s?.provider ?? ""}
                {s?.funding_type ? ` · ${s.funding_type}` : ""}
              </p>
              {m.reason && (
                <p className="text-[11px] text-muted-foreground/90 line-clamp-2" title={m.reason}>
                  <span className="text-primary font-medium">Why: </span>{m.reason}
                </p>
              )}
              {s?.next_close_date && (
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Deadline: <span className="font-medium">{format(new Date(s.next_close_date), "d MMM yyyy")}</span>
                </p>
              )}
              <div className="mt-auto pt-2">
                {s?.url ? (
                  <a href={s.url} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackApplyClick(m.scholarship_id); }}>
                    <Button size="sm" className="w-full text-xs rounded-xl">
                      Apply Now
                    </Button>
                  </a>
                ) : (
                  <span onClick={(e) => e.stopPropagation()}>
                    <Button size="sm" variant="outline" className="w-full text-xs rounded-xl">View Details</Button>
                  </span>
                )}
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
