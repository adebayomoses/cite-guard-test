import { useState } from "react";
import { Activity, ChevronDown, ChevronUp } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";

interface ActivityItem {
  id: string;
  action: string;
  detail: string | null;
  created_at: string;
}

interface Props {
  activities: ActivityItem[];
  loading: boolean;
}

export default function RecentActivity({ activities, loading }: Props) {
  const [showAll, setShowAll] = useState(false);

  if (loading) return <div className="rounded-xl border border-border bg-card p-5"><p className="text-sm text-muted-foreground">Loading...</p></div>;

  const displayed = showAll ? activities : activities.slice(0, 6);

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <h3 className="font-semibold mb-3 flex items-center gap-2">
        <Activity className="h-4 w-4 text-primary" /> Recent Activity
      </h3>
      {activities.length === 0 ? (
        <p className="text-sm text-muted-foreground">No activity yet. Start by completing your profile!</p>
      ) : (
        <>
          <ul className="space-y-3">
            {displayed.map((a) => (
              <li key={a.id} className="flex items-start justify-between gap-2">
                <span className="text-sm">{a.action}</span>
                <span className="text-xs text-muted-foreground shrink-0">
                  {formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
                </span>
              </li>
            ))}
          </ul>
          {activities.length > 6 && (
            <Button
              variant="ghost"
              size="sm"
              className="mt-3 w-full text-muted-foreground"
              onClick={() => setShowAll((prev) => !prev)}
            >
              {showAll ? (<>Show Less <ChevronUp className="h-4 w-4 ml-1" /></>) : (<>See More <ChevronDown className="h-4 w-4 ml-1" /></>)}
            </Button>
          )}
        </>
      )}
    </div>
  );
}
