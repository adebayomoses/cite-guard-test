import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, Clock, ChevronDown, ChevronUp } from "lucide-react";
import { differenceInDays } from "date-fns";
import { Button } from "@/components/ui/button";

interface Scholarship {
  id: string;
  title: string;
  next_close_date: string | null;
}

interface DisplayItem {
  id: string;
  title: string;
  effective: string;
}

export default function UpcomingDeadlines() {
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    const today = new Date().toISOString().split("T")[0];
    supabase
      .from("scholarships")
      .select("id, title, next_close_date")
      .eq("is_active", true)
      .gte("next_close_date", today)
      .order("next_close_date", { ascending: true })
      .limit(200)
      .then(({ data }) => {
        setScholarships((data ?? []) as Scholarship[]);
        setLoading(false);
      });
  }, []);

  const deadlines = useMemo<DisplayItem[]>(() => {
    return scholarships
      .map((s) => (s.next_close_date ? { id: s.id, title: s.title, effective: s.next_close_date } : null))
      .filter((x): x is DisplayItem => x !== null)
      .slice(0, 20);
  }, [scholarships]);

  if (loading) return <div className="rounded-xl border border-border bg-card p-5"><p className="text-sm text-muted-foreground">Loading deadlines...</p></div>;
  if (deadlines.length === 0) return null;

  const displayed = showAll ? deadlines : deadlines.slice(0, 6);

  return (
    <div className="rounded-xl border border-border bg-card p-5 overflow-hidden">
      <h3 className="font-semibold mb-3 flex items-center gap-2">
        <Clock className="h-4 w-4 text-primary" /> Upcoming Deadlines
      </h3>
      <ul className="space-y-3">
        {displayed.map((s) => {
          const days = differenceInDays(new Date(s.effective), new Date());
          const urgency = days < 7 ? "text-destructive" : days < 30 ? "text-accent" : "text-muted-foreground";
          return (
            <li key={s.id}>
              <Link
                to={`/scholarships/${s.id}`}
                className="flex items-start justify-between gap-2 group rounded-md -mx-1 px-1 py-0.5 hover:bg-muted/60 transition-colors"
              >
                <span className="text-sm truncate min-w-0 group-hover:text-primary group-hover:underline underline-offset-2">{s.title}</span>
                <span className={`text-xs shrink-0 flex items-center gap-1 ${urgency}`}>
                  <Calendar className="h-3 w-3" />
                  {days === 0 ? "Today" : days === 1 ? "Tomorrow" : `${days}d`}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
      {deadlines.length > 6 && (
        <Button
          variant="ghost"
          size="sm"
          className="mt-3 w-full text-muted-foreground"
          onClick={() => setShowAll((prev) => !prev)}
        >
          {showAll ? (<>Show Less <ChevronUp className="h-4 w-4 ml-1" /></>) : (<>See More <ChevronDown className="h-4 w-4 ml-1" /></>)}
        </Button>
      )}
    </div>
  );
}

