import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface Match {
  scholarship_id: string;
  score: number;
  reason: string;
}

interface Scholarship {
  id: string;
  title: string;
  provider: string | null;
  url: string | null;
  funding_amount: string | null;
}

export default function MatchedScholarships({ matches }: { matches: Match[] }) {
  const [scholarships, setScholarships] = useState<Record<string, Scholarship>>({});
  const [visibleCount, setVisibleCount] = useState(6);

  useEffect(() => {
    if (!matches.length) return;
    const ids = matches.map((m) => m.scholarship_id);
    const today = new Date().toISOString().split("T")[0];
    supabase
      .from("scholarships")
      .select("id, title, provider, url, funding_amount")
      .in("id", ids)
      .eq("is_active", true)
      .or(`deadline.is.null,deadline.gte.${today}`)
      .then(({ data }) => {
        if (data) {
          const map: Record<string, Scholarship> = {};
          data.forEach((s) => (map[s.id] = s));
          setScholarships(map);
        }
      });
  }, [matches]);

  const sorted = [...matches].sort((a, b) => b.score - a.score);
  const visible = sorted.slice(0, visibleCount);
  const remaining = sorted.length - visibleCount;

  const badgeColor = (score: number) =>
    score >= 70 ? "default" : score >= 40 ? "secondary" : "outline";

  if (!sorted.length) return null;

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <h3 className="font-semibold mb-4">Matched Scholarships</h3>
      <div className="space-y-3">
        {visible.map((m) => {
          const s = scholarships[m.scholarship_id];
          return (
            <div key={m.scholarship_id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
              <Badge variant={badgeColor(m.score)} className="shrink-0 mt-0.5">
                {m.score}%
              </Badge>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm truncate">{s?.title ?? "Scholarship"}</span>
                  {s?.url && (
                    <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground">
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                </div>
                {s?.provider && <p className="text-xs text-muted-foreground">{s.provider}{s.funding_amount ? ` · ${s.funding_amount}` : ""}</p>}
                <p className="text-xs text-muted-foreground mt-1">{m.reason}</p>
              </div>
            </div>
          );
        })}
      </div>
      {remaining > 0 && (
        <div className="flex justify-center mt-4">
          <Button variant="outline" size="sm" onClick={() => setVisibleCount((c) => c + 6)}>
            Load More ({remaining} remaining)
          </Button>
        </div>
      )}
    </div>
  );
}
