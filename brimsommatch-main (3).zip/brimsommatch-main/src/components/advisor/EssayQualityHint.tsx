import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Sparkles, ArrowRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

const FIELDS: { key: string; label: string }[] = [
  { key: "motivation", label: "Motivation for your field" },
  { key: "project_or_achievement", label: "Key project or achievement" },
  { key: "career_goals", label: "Short & long-term career goals" },
  { key: "why_study_abroad", label: "Why study abroad" },
  { key: "research_interests", label: "Research interests" },
  { key: "tools_software", label: "Tools & software you use" },
  { key: "academic_explanations", label: "Context on academic record" },
];

const ESSAY_INTENT =
  /\b(sop|statement of purpose|motivation letter|personal statement|personal essay|admission essay|application essay|scholarship essay|cover letter|draft (?:my |an |a )?(?:essay|letter|statement)|write (?:my |an |a )?(?:essay|letter|statement|sop))\b/i;

export function detectEssayIntent(text: string): boolean {
  return ESSAY_INTENT.test(text);
}

export default function EssayQualityHint({ input }: { input: string }) {
  const { user } = useAuth();
  const [essay, setEssay] = useState<Record<string, string> | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("essay_profiles" as any)
        .select("motivation,project_or_achievement,tools_software,research_interests,career_goals,why_study_abroad,academic_explanations")
        .eq("user_id", user.id)
        .maybeSingle();
      if (!cancelled) {
        setEssay((data as any) ?? {});
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const show = loaded && !dismissed && detectEssayIntent(input);
  if (!show || !essay) return null;

  const missing = FIELDS.filter(
    (f) => !((essay as any)[f.key] ?? "").toString().trim()
  );
  const filled = FIELDS.length - missing.length;
  const pct = Math.round((filled / FIELDS.length) * 100);

  if (missing.length === 0) return null;

  const tone =
    pct >= 70
      ? "from-emerald-500/15 to-emerald-500/5 border-emerald-500/30"
      : pct >= 40
      ? "from-amber-500/15 to-amber-500/5 border-amber-500/30"
      : "from-primary/15 to-primary/5 border-primary/30";

  return (
    <div className="max-w-3xl mx-auto mb-2">
      <div
        className={cn(
          "rounded-2xl border bg-gradient-to-br px-4 py-3 text-sm",
          tone
        )}
      >
        <div className="flex items-start gap-3">
          <div className="shrink-0 mt-0.5 h-8 w-8 rounded-xl bg-background/70 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold">
                Essay quality: {pct}%
              </p>
              <button
                onClick={() => setDismissed(true)}
                className="text-xs text-muted-foreground hover:text-foreground"
                aria-label="Dismiss"
              >
                Hide
              </button>
            </div>
            <div className="mt-1.5 h-1.5 w-full rounded-full bg-background/60 overflow-hidden">
              <div
                className="h-full bg-primary transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
            <p className="mt-2 text-muted-foreground">
              Your essay will be significantly stronger with these filled in:
            </p>
            <ul className="mt-1.5 flex flex-wrap gap-1.5">
              {missing.slice(0, 5).map((f) => (
                <li
                  key={f.key}
                  className="text-xs px-2 py-0.5 rounded-full bg-background/70 border border-border/60"
                >
                  {f.label}
                </li>
              ))}
              {missing.length > 5 && (
                <li className="text-xs px-2 py-0.5 rounded-full bg-background/70 border border-border/60">
                  +{missing.length - 5} more
                </li>
              )}
            </ul>
            <div className="mt-2.5 flex items-center gap-3">
              <Link
                to="/profile?step=essay"
                className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
              >
                Complete Essay Profile <ArrowRight className="h-3 w-3" />
              </Link>
              <span className="text-xs text-muted-foreground">
                Optional — Brim will still try its best.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
