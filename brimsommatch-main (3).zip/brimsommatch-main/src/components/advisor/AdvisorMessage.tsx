import { useEffect, useState } from "react";
import MarkdownContent from "@/components/MarkdownContent";
import AdvisorScholarshipCard from "./AdvisorScholarshipCard";
import EssayBlock, { parseEssaySegments } from "@/components/brim/EssayBlock";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Copy, Share2, Check } from "lucide-react";
import { toast } from "sonner";

interface Props {
  content: string;
  scoresVersion?: number;
}

const TOKEN_RE = /\[\[scholarship:([a-zA-Z0-9-]+)\]\]/g;

type ScoreEntry = { score: number; chance: number };

// Module-level cache so multiple messages share one query
let scoreCache: { userId: string; map: Map<string, ScoreEntry>; hasResults: boolean } | null = null;
let scorePromise: Promise<void> | null = null;

async function loadScores(userId: string) {
  if (scoreCache?.userId === userId) return;
  if (scorePromise) return scorePromise;
  scorePromise = (async () => {
    const { data } = await supabase
      .from("score_results")
      .select("scholarship_matches")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    const map = new Map<string, ScoreEntry>();
    const arr = (data?.scholarship_matches as any[]) ?? [];
    for (const m of arr) {
      if (m?.scholarship_id) map.set(m.scholarship_id, { score: m.score ?? 0, chance: m.chance ?? 0 });
    }
    scoreCache = { userId, map, hasResults: !!data };
  })();
  await scorePromise;
  scorePromise = null;
}

export default function AdvisorMessage({ content, scoresVersion }: Props) {
  const { user } = useAuth();
  const [, force] = useState(0);
  const [copied, setCopied] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!user || !content.includes("[[scholarship:")) return;
    // Invalidate cache when scoresVersion bumps so we pull fresh match/chance values
    if (scoresVersion !== undefined && scoreCache?.userId === user.id) {
      scoreCache = null;
    }
    if (scoreCache?.userId === user.id) return;
    loadScores(user.id).then(() => force((n) => n + 1));
  }, [user, content, scoresVersion]);

  const essaySegments = parseEssaySegments(content);
  const hasEssaySegments = essaySegments.some((seg) => seg.type === "essay");
  const plainText = content
    .replace(TOKEN_RE, "")
    .replace(/```essay\s*\n?([\s\S]*?)(?:```|$)/g, "$1")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(plainText);
      setCopied(true);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("Couldn't copy");
    }
  };

  const ensureShareUrl = async (): Promise<string | null> => {
    if (shareUrl) return shareUrl;
    if (!user) {
      toast.error("Sign in to share");
      return null;
    }
    const token =
      (typeof crypto !== "undefined" && "randomUUID" in crypto)
        ? crypto.randomUUID().replace(/-/g, "")
        : Math.random().toString(36).slice(2) + Date.now().toString(36);
    const { error } = await supabase.from("shared_advisor_messages").insert({
      token,
      content,
      created_by: user.id,
    });
    if (error) {
      console.error(error);
      toast.error("Couldn't create share link");
      return null;
    }
    const url = `${window.location.origin}/shared/advisor/${token}`;
    setShareUrl(url);
    return url;
  };

  const handleShare = async () => {
    if (sharing) return;
    setSharing(true);
    try {
      const url = await ensureShareUrl();
      if (!url) return;
      const shareText = `Check out this insight from Brim Advisor:\n${url}`;
      const data = { title: "Brim Advisor", text: shareText, url };
      const canShare =
        typeof navigator !== "undefined" &&
        typeof navigator.share === "function" &&
        (!navigator.canShare || navigator.canShare(data));

      if (canShare) {
        try {
          await navigator.share(data);
          return;
        } catch (err: any) {
          if (err?.name === "AbortError") return;
        }
      }

      try {
        await navigator.clipboard.writeText(url);
        toast.success("Share link copied to clipboard");
      } catch {
        toast.error("Couldn't share");
      }
    } finally {
      setSharing(false);
    }
  };

  const Actions = () => (
    <div className="flex items-center gap-3 pt-2 mt-2 border-t border-border/40 text-xs text-muted-foreground">
      <button onClick={handleCopy} className="flex items-center gap-1 hover:text-foreground transition-colors" aria-label="Copy">
        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
        {copied ? "Copied" : "Copy"}
      </button>
      <button onClick={handleShare} disabled={sharing} className="flex items-center gap-1 hover:text-foreground transition-colors disabled:opacity-50" aria-label="Share">
        <Share2 className="h-3.5 w-3.5" />
        {sharing ? "Creating link…" : "Share"}
      </button>
    </div>
  );

  if (!content) return <MarkdownContent content="..." />;

  // Parse into header text, card blocks (commentary + card), and footer text.
  const matches: Array<{ id: string; start: number; end: number }> = [];
  let m: RegExpExecArray | null;
  while ((m = TOKEN_RE.exec(content)) !== null) {
    matches.push({ id: m[1], start: m.index, end: m.index + m[0].length });
  }

  if (hasEssaySegments) {
    return (
      <div className="w-full">
        {essaySegments.map((seg, idx) => (
          seg.type === "essay" ? (
            <EssayBlock key={`essay-${idx}`} content={seg.content} streaming={seg.streaming} />
          ) : seg.content.trim() ? (
            <MarkdownContent key={`text-${idx}`} content={seg.content.trim()} />
          ) : null
        ))}
        <Actions />
      </div>
    );
  }

  if (matches.length === 0) {
    return (
      <div>
        <MarkdownContent content={content} />
        <Actions />
      </div>
    );
  }

  const map = scoreCache?.userId === user?.id ? scoreCache?.map : undefined;
  const hasResults = scoreCache?.userId === user?.id ? scoreCache?.hasResults : undefined;

  // First card's preceding text becomes the header (intro paragraph stays put).
  // Each subsequent card pairs with the text between the previous card and itself.
  const header = content.slice(0, matches[0].start);
  const footer = content.slice(matches[matches.length - 1].end);

  const blocks: Array<{ id: string; commentary: string }> = matches.map((mt, i) => {
    const prevEnd = i === 0 ? mt.start : matches[i - 1].end;
    // For the first card, commentary is empty (its lead-in is the header).
    const commentary = i === 0 ? "" : content.slice(prevEnd, mt.start);
    return { id: mt.id, commentary };
  });

  // Stable sort by chance score desc; unscored sink to bottom.
  const sorted = blocks
    .map((b, i) => ({ b, i }))
    .sort((a, b) => {
      const ca = map?.get(a.b.id)?.chance ?? -1;
      const cb = map?.get(b.b.id)?.chance ?? -1;
      if (cb !== ca) return cb - ca;
      return a.i - b.i;
    })
    .map((x) => x.b);

  const renderText = (text: string, key: string) => {
    const trimmed = text.replace(/^\s*\n+|\n+\s*$/g, "");
    if (!trimmed) return null;
    return <MarkdownContent key={key} content={trimmed} />;
  };

  return (
    <div>
      {renderText(header, "header")}
      {sorted.map((blk, i) => {
        const s = map?.get(blk.id);
        return (
          <div key={`blk-${i}-${blk.id}`}>
            {renderText(blk.commentary, `cmt-${i}`)}
            <AdvisorScholarshipCard
              scholarshipId={blk.id}
              matchScore={s?.score}
              chanceScore={s?.chance}
              hasScoreResults={hasResults}
            />
          </div>
        );
      })}
      {renderText(footer, "footer")}
      <Actions />
    </div>
  );
}
