import { useState } from "react";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Upload, Wand2, History } from "lucide-react";
import { useMatchMe, type MatchResult } from "@/hooks/useMatchMe";
import { useFeatureAccess, useTrackUsage } from "@/hooks/useFeatureAccess";
import { useSaveMatchHistory } from "@/hooks/useMatchHistory";
import UpgradeBanner from "@/components/UpgradeBanner";
import MatchResultCard from "@/components/advisor/MatchResultCard";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function MatchMeDialog({ open, onOpenChange }: Props) {
  const [text, setText] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  
  const { matchScholarship, extractDocumentText, loading, extracting } = useMatchMe();
  const { canUse, remaining, limit, usage, period, plan } = useFeatureAccess("match_me");
  const trackUsage = useTrackUsage();
  const saveHistory = useSaveMatchHistory();

  const reset = () => {
    setText("");
    setFileName(null);
    setResult(null);
  };

  const handleClose = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setFileName(file.name);
    const extracted = await extractDocumentText(file);
    if (extracted) setText(extracted);
  };

  const handleSubmit = async () => {
    if (!text.trim() || loading) return;
    if (!canUse) return;
    const res = await matchScholarship(text.trim());
    if (res) {
      setResult(res);
      trackUsage.mutate("match_me");
      // Auto-save to history (silent — failures don't block the UX)
      saveHistory.mutate({ scholarship_text: text.trim(), result: res });
    }
  };

  const remainingLabel = limit === Infinity ? "Unlimited" : `${remaining}/${limit} left this month`;

  return (
    <>
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-w-[calc(100vw-1rem)] max-h-[calc(100dvh-2rem)] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="h-5 w-5 text-primary" /> Match Me
            <Badge variant="secondary" className="ml-auto text-[10px]">{remainingLabel}</Badge>
          </DialogTitle>
          <DialogDescription>
            Paste a scholarship/admission description or upload a PDF/DOCX. We'll score your fit, win-chance, and tell you exactly what to improve — based on your profile.
          </DialogDescription>
          <Link
            to="/match-history"
            onClick={() => onOpenChange(false)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-primary bg-primary/10 hover:bg-primary/15 border border-primary/20 rounded-full px-3 py-1.5 mt-2 w-fit transition"
          >
            <History className="h-4 w-4" /> View saved Match Me history
          </Link>
        </DialogHeader>

        {!canUse && (
          <UpgradeBanner
            feature="match_me"
            currentPlan={plan}
            usage={usage}
            limit={limit === Infinity ? 999 : limit}
            period={period}
          />
        )}

        {!result ? (
          <div className="space-y-4">
            <p className="text-sm font-bold text-foreground">
              For the most accurate match, make sure your{" "}
              <Link to="/profile" className="underline text-primary" onClick={() => onOpenChange(false)}>profile</Link>{" "}
              is up to date.
            </p>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Scholarship / admission details</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste the eligibility, benefits, deadlines, and requirements here…"
                className="min-h-[180px] resize-y"
                disabled={loading || extracting}
              />
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 border-t" />
              <span className="text-xs text-muted-foreground">or upload</span>
              <div className="flex-1 border-t" />
            </div>

            <label
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border border-dashed px-4 py-3 text-sm cursor-pointer hover:bg-muted transition",
                (loading || extracting) && "opacity-50 pointer-events-none"
              )}
            >
              <Upload className="h-4 w-4" />
              {extracting ? "Reading file…" : fileName ? `${fileName} — replace` : "Choose PDF or DOCX"}
              <Input
                type="file"
                accept=".pdf,.docx"
                className="hidden"
                onChange={(e) => handleFile(e.target.files?.[0])}
                disabled={loading || extracting}
              />
            </label>

            <Button
              onClick={handleSubmit}
              disabled={!text.trim() || loading || extracting}
              className="w-full gap-2"
            >
              {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Analyzing your fit…</> : <><Wand2 className="h-4 w-4" /> Match Me</>}
            </Button>
          </div>
        ) : (
          <MatchResultCard result={result} onReset={reset} />
        )}
      </DialogContent>
    </Dialog>
    </>
  );
}
