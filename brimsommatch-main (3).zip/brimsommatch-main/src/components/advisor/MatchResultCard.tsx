import { Target, TrendingUp, AlertCircle, CheckCircle2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { MatchResult } from "@/hooks/useMatchMe";

function ScoreChip({ label, value, icon: Icon }: { label: string; value: number; icon: any }) {
  const tone =
    value >= 80 ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" :
    value >= 60 ? "bg-amber-500/10 text-amber-600 border-amber-500/20" :
    "bg-rose-500/10 text-rose-600 border-rose-500/20";
  return (
    <div className={cn("flex items-center gap-2 rounded-2xl border px-3 py-2 min-w-0", tone)}>
      <Icon className="h-4 w-4 shrink-0" />
      <div className="leading-tight min-w-0">
        <p className="text-[10px] uppercase font-semibold tracking-wide opacity-80 truncate">{label}</p>
        <p className="text-lg font-bold">{value}<span className="text-xs opacity-70">/100</span></p>
      </div>
    </div>
  );
}

interface Props {
  result: MatchResult;
  onReset?: () => void;
  resetLabel?: string;
}

export default function MatchResultCard({ result, onReset, resetLabel = "Match another" }: Props) {
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border bg-card p-4">
        <p className="text-xs uppercase tracking-wide font-semibold text-muted-foreground mb-1">Opportunity</p>
        <h3 className="font-semibold text-base leading-snug">{result.title || "Untitled opportunity"}</h3>
        {(result.provider || result.country) && (
          <p className="text-xs text-muted-foreground mt-1">
            {[result.provider, result.country].filter(Boolean).join(" · ")}
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <ScoreChip label="Match" value={result.match_score} icon={Target} />
        <ScoreChip label="Win chance" value={result.chance_score} icon={TrendingUp} />
      </div>

      <div className="rounded-2xl border bg-muted/30 p-4 space-y-1">
        <p className="text-xs uppercase tracking-wide font-semibold text-muted-foreground">Why this match</p>
        <p className="text-sm leading-relaxed">{result.match_reason}</p>
      </div>

      <div className="rounded-2xl border bg-muted/30 p-4 space-y-1">
        <p className="text-xs uppercase tracking-wide font-semibold text-muted-foreground">Why your chance is {result.chance_score}/100</p>
        <p className="text-sm leading-relaxed">{result.chance_reason}</p>
      </div>

      <div className="rounded-2xl border border-destructive/20 bg-destructive/5 p-4 space-y-1">
        <div className="flex items-center gap-1.5">
          <AlertCircle className="h-4 w-4 text-destructive" />
          <p className="text-xs uppercase tracking-wide font-semibold text-destructive">Why it isn't 90+</p>
        </div>
        <p className="text-sm leading-relaxed">{result.gap_summary}</p>
      </div>

      <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 space-y-2">
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          <p className="text-xs uppercase tracking-wide font-semibold text-primary">How to become competitive</p>
        </div>
        <ul className="space-y-2">
          {result.action_steps?.map((step, i) => (
            <li key={i} className="flex gap-2 text-sm leading-relaxed">
              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-[11px] font-bold">{i + 1}</span>
              <span>{step}</span>
            </li>
          ))}
        </ul>
      </div>

      {onReset && (
        <Button variant="outline" className="w-full gap-2" onClick={onReset}>
          <RotateCcw className="h-4 w-4" /> {resetLabel}
        </Button>
      )}
    </div>
  );
}
