import { useEffect, useState } from "react";
import { Calendar, MapPin, ExternalLink, Bookmark, BookmarkCheck, Loader2, Target, TrendingUp, Sparkles, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useSavedScholarships } from "@/hooks/useSavedScholarships";
import { format } from "date-fns";
import { Link } from "react-router-dom";

type Scholarship = {
  id: string;
  title: string;
  provider: string | null;
  country: string | null;
  next_close_date: string | null;
  url: string | null;
  funding_amount: string | null;
  funding_type: string | null;
  degree_level: string | null;
};

interface Props {
  scholarshipId: string;
  matchScore?: number;
  chanceScore?: number;
  hasScoreResults?: boolean;
}

export default function AdvisorScholarshipCard({ scholarshipId, matchScore, chanceScore, hasScoreResults }: Props) {
  const [data, setData] = useState<Scholarship | null>(null);
  const [loading, setLoading] = useState(true);
  const { savedIds, toggleSave } = useSavedScholarships();
  const isSaved = savedIds.has(scholarshipId);

  useEffect(() => {
    let cancelled = false;
    const today = new Date().toISOString().split("T")[0];
    supabase
      .from("scholarships")
      .select("id,title,provider,country,next_close_date,url,funding_amount,funding_type,degree_level,is_active")
      .eq("id", scholarshipId)
      .eq("is_active", true)
      .or(`next_close_date.is.null,next_close_date.gte.${today}`)
      .maybeSingle()
      .then(({ data }) => {
        if (!cancelled) {
          setData(data as Scholarship | null);
          setLoading(false);
        }
      });
    return () => { cancelled = true; };
  }, [scholarshipId]);

  if (loading) {
    return (
      <div className="my-3 rounded-2xl border bg-card p-4 flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading scholarship…
      </div>
    );
  }

  if (!data) {
    // Scholarship is inactive, expired, or removed — hide silently
    return null;
  }

  const deadlineLabel = data.next_close_date
    ? (() => {
        try { return format(new Date(data.next_close_date as string), "MMM d, yyyy"); }
        catch { return data.next_close_date; }
      })()
    : "Rolling";

  const funding = data.funding_amount || data.funding_type;
  const hasScores = typeof matchScore === "number" && typeof chanceScore === "number";

  const isClosingSoon = (() => {
    if (!data.next_close_date) return false;
    const d = new Date(data.next_close_date);
    if (isNaN(d.getTime())) return false;
    const days = (d.getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return days >= 0 && days <= 21;
  })();

  return (
    <div className="my-3 rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="min-w-0">
          <h4 className="font-semibold text-sm leading-tight text-foreground">{data.title}</h4>
          {data.provider && (
            <p className="text-xs text-muted-foreground mt-0.5">{data.provider}</p>
          )}
        </div>
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8 shrink-0"
          onClick={() => toggleSave(data.id)}
          aria-label={isSaved ? "Unsave" : "Save"}
        >
          {isSaved ? (
            <BookmarkCheck className="h-4 w-4 text-primary" />
          ) : (
            <Bookmark className="h-4 w-4" />
          )}
        </Button>
      </div>

      {hasScores && (
        <div className="flex flex-wrap gap-1.5 mb-2">
          <Badge className="text-[10px] gap-1 bg-primary/10 text-primary hover:bg-primary/15 border-transparent">
            <Target className="h-3 w-3" /> Match {matchScore}%
          </Badge>
          <Badge className="text-[10px] gap-1 bg-secondary text-secondary-foreground hover:bg-secondary/80 border-transparent">
            <TrendingUp className="h-3 w-3" /> Win Chance {chanceScore}%
          </Badge>
        </div>
      )}

      {!hasScores && hasScoreResults === false && (
        <Link
          to="/score"
          className="mb-2 inline-flex items-center gap-1 rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium text-muted-foreground hover:bg-muted/80"
        >
          <Sparkles className="h-3 w-3" /> Generate your Score for Match & Win Chance
        </Link>
      )}

      <div className="flex flex-wrap gap-1.5 mb-3">
        {isClosingSoon && (
          <Badge className="text-[10px] gap-1 bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/20 hover:bg-orange-500/25">
            <Clock className="h-3 w-3" /> Closing Soon
          </Badge>
        )}
        {data.country && (
          <Badge variant="secondary" className="text-[10px] gap-1">
            <MapPin className="h-3 w-3" /> {data.country}
          </Badge>
        )}
        <Badge variant="secondary" className="text-[10px] gap-1">
          <Calendar className="h-3 w-3" /> {deadlineLabel}
        </Badge>
        {data.degree_level && (
          <Badge variant="outline" className="text-[10px]">{data.degree_level}</Badge>
        )}
        {funding && (
          <Badge variant="outline" className="text-[10px]">{funding}</Badge>
        )}
      </div>

      <div className="flex gap-2">
        <Button asChild size="sm" className="flex-1 gap-1.5" disabled={!data.url}>
          <a href={data.url ?? "#"} target="_blank" rel="noopener noreferrer">
            Apply <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </Button>
        <Button asChild size="sm" variant="outline">
          <Link to={`/scholarships/${data.id}`}>Details</Link>
        </Button>
      </div>
    </div>
  );
}
