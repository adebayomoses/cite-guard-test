import { useLocation, Link } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { UserPen, Sparkles } from "lucide-react";
import { useProfileData } from "@/hooks/useProfileData";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";

const THRESHOLD = 50;

export default function ProfileCompletionBanner() {
  const { user } = useAuth();
  const { isAdmin, isModerator } = useAdminRole();
  const location = useLocation();
  const { loading, getCompleteness } = useProfileData();

  // Don't show for admins/moderators (they have override)
  if (isAdmin || isModerator) return null;
  // Don't show on profile page itself, auth pages, or when not logged in
  if (!user) return null;
  if (location.pathname.startsWith("/profile")) return null;
  if (location.pathname.startsWith("/auth")) return null;
  if (location.pathname.startsWith("/admin")) return null;
  if (loading) return null;

  const completeness = getCompleteness();
  if (completeness >= THRESHOLD) return null;

  const remaining = THRESHOLD - completeness;

  return (
    <div className="border-b border-primary/20 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent">
      <div className="container mx-auto px-4 py-3 flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <div className="hidden sm:block">
            <p className="text-sm font-medium leading-tight">Unlock AI scholarship matching</p>
            <p className="text-xs text-muted-foreground leading-tight">
              Reach {THRESHOLD}% profile completion ({remaining}% to go)
            </p>
          </div>
          <div className="sm:hidden">
            <p className="text-sm font-medium leading-tight">Complete your profile</p>
            <p className="text-xs text-muted-foreground leading-tight">{remaining}% to unlock AI matching</p>
          </div>
        </div>

        <div className="flex-1 w-full flex items-center gap-3">
          <Progress value={completeness} className="h-2 flex-1" />
          <span className="text-xs font-semibold text-primary tabular-nums shrink-0">{completeness}%</span>
        </div>

        <Button asChild size="sm" className="w-full sm:w-auto shrink-0">
          <Link to="/profile">
            <UserPen className="h-4 w-4 mr-1.5" />
            Continue
          </Link>
        </Button>
      </div>
    </div>
  );
}
