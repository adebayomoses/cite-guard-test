import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { Star, Loader2, Upload, X as XIcon, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

const testimonialSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name too long"),
  email: z
    .string()
    .trim()
    .max(255, "Email too long")
    .email("Invalid email")
    .optional()
    .or(z.literal("")),
  message: z
    .string()
    .trim()
    .min(10, "Please write at least 10 characters")
    .max(1000, "Testimonial must be under 1000 characters"),
  rating: z.number().int().min(1).max(5),
});

interface Props {
  trigger: React.ReactNode;
}

function generateMathChallenge() {
  const a = Math.floor(Math.random() * 20) + 1;
  const b = Math.floor(Math.random() * 20) + 1;
  return { a, b, answer: a + b };
}

export default function SubmitTestimonialDialog({ trigger }: Props) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [challenge, setChallenge] = useState(generateMathChallenge);
  const [captchaInput, setCaptchaInput] = useState("");
  const [captchaError, setCaptchaError] = useState<string | null>(null);

  const resetChallenge = () => {
    setChallenge(generateMathChallenge());
    setCaptchaInput("");
    setCaptchaError(null);
  };

  useEffect(() => {
    if (open) resetChallenge();
  }, [open]);

  const reset = () => {
    setName("");
    setEmail("");
    setMessage("");
    setRating(5);
    setHover(0);
    setImageFile(null);
    setImagePreview(null);
    resetChallenge();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Invalid file", description: "Please select an image.", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Image must be under 5MB.", variant: "destructive" });
      return;
    }
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = testimonialSchema.safeParse({ name, email, message, rating });
    if (!parsed.success) {
      const first = parsed.error.issues[0];
      toast({ title: "Invalid input", description: first.message, variant: "destructive" });
      return;
    }
    if (!captchaInput.trim()) {
      setCaptchaError("Please answer the math question");
      return;
    }
    if (parseInt(captchaInput.trim(), 10) !== challenge.answer) {
      setCaptchaError("Incorrect answer — please try again");
      resetChallenge();
      return;
    }
    setCaptchaError(null);
    setSubmitting(true);
    try {
      let image_url: string | null = null;
      if (imageFile) {
        const ext = imageFile.name.split(".").pop() || "jpg";
        const path = `public/${user?.id ?? "guest"}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("testimonial-images")
          .upload(path, imageFile, { contentType: imageFile.type, upsert: false });
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("testimonial-images").getPublicUrl(path);
        image_url = pub.publicUrl;
      }
      const { error } = await (supabase as any).from("testimonials").insert({
        user_id: user?.id ?? null,
        name: parsed.data.name,
        email: parsed.data.email || null,
        message: parsed.data.message,
        rating: parsed.data.rating,
        image_url,
      });
      if (error) throw error;
      toast({
        title: "Thank you!",
        description: "Your testimonial has been submitted for review.",
      });
      reset();
      setOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md max-w-[calc(100vw-2rem)] max-h-[calc(100dvh-2rem)] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle>Share Your Testimonial</DialogTitle>
          <DialogDescription>
            Tell us about your experience with Brimsom. Submissions are reviewed before
            being published.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="t-name">Name *</Label>
            <Input
              id="t-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              maxLength={100}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="t-email">Email (optional)</Label>
            <Input
              id="t-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              maxLength={255}
            />
          </div>
          <div className="space-y-2">
            <Label>Rating</Label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  onMouseEnter={() => setHover(n)}
                  onMouseLeave={() => setHover(0)}
                  className="p-1 rounded hover:scale-110 transition-transform"
                  aria-label={`${n} star${n > 1 ? "s" : ""}`}
                >
                  <Star
                    className={cn(
                      "h-6 w-6 transition-colors",
                      (hover || rating) >= n
                        ? "fill-amber-400 text-amber-400"
                        : "text-muted-foreground",
                    )}
                  />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="t-message">Your testimonial *</Label>
            <Textarea
              id="t-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Share your story..."
              rows={5}
              maxLength={1000}
              required
            />
            <p className="text-xs text-muted-foreground text-right">
              {message.length}/1000
            </p>
          </div>
          <div className="space-y-2">
            <Label>Photo (optional)</Label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            {imagePreview ? (
              <div className="relative inline-block">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="h-24 w-24 rounded-lg object-cover border border-border"
                />
                <button
                  type="button"
                  onClick={() => {
                    setImageFile(null);
                    setImagePreview(null);
                    if (fileInputRef.current) fileInputRef.current.value = "";
                  }}
                  className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center shadow"
                  aria-label="Remove image"
                >
                  <XIcon className="h-3.5 w-3.5" />
                </button>
              </div>
            ) : (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="gap-2"
              >
                <Upload className="h-4 w-4" />
                Upload photo
              </Button>
            )}
            <p className="text-xs text-muted-foreground">Max 5MB. JPG, PNG, etc.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="t-captcha">
              Spam check: what is {challenge.a} + {challenge.b}? *
            </Label>
            <div className="flex gap-2">
              <Input
                id="t-captcha"
                type="number"
                inputMode="numeric"
                value={captchaInput}
                onChange={(e) => {
                  setCaptchaInput(e.target.value);
                  if (captchaError) setCaptchaError(null);
                }}
                placeholder="Your answer"
                className="flex-1 min-w-0 sm:max-w-[160px]"
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={resetChallenge}
                title="New question"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
            {captchaError && (
              <p className="text-xs text-destructive">{captchaError}</p>
            )}
          </div>
          <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button type="submit" disabled={submitting} className="w-full sm:w-auto">
              {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Submit
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
