const orbs = [
  { size: "w-72 h-72", color: "bg-primary/20", top: "top-[-5%]", left: "left-[-8%]", delay: "0s", anim: "animate-orb-float" },
  { size: "w-96 h-96", color: "bg-accent/15", top: "top-[10%]", left: "right-[-10%]", delay: "2s", anim: "animate-orb-drift" },
  { size: "w-64 h-64", color: "bg-primary/10", top: "top-[50%]", left: "left-[20%]", delay: "4s", anim: "animate-orb-float" },
  { size: "w-48 h-48", color: "bg-secondary/30", top: "top-[30%]", left: "right-[15%]", delay: "1s", anim: "animate-orb-drift" },
];

export default function FloatingOrbs() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {/* Dot grid overlay */}
      <div className="absolute inset-0 dot-grid opacity-40" />
      {/* Gradient orbs */}
      {orbs.map((orb, i) => (
        <div
          key={i}
          className={`absolute rounded-full blur-3xl ${orb.size} ${orb.color} ${orb.top} ${orb.left} ${orb.anim} opacity-60`}
          style={{ animationDelay: orb.delay }}
        />
      ))}
      {/* Small floating particles */}
      {Array.from({ length: 10 }).map((_, i) => (
        <div
          key={`p-${i}`}
          className="absolute w-2.5 h-2.5 rounded-full bg-primary/70 shadow-[0_0_12px_hsl(var(--primary)/0.6)] animate-particle-rise"
          style={{
            left: `${8 + i * 9}%`,
            bottom: "8%",
            animationDelay: `${i * 0.5}s`,
            animationDuration: `${3.5 + i * 0.4}s`,
          }}
        />
      ))}
      {/* Falling bubbles */}
      {Array.from({ length: 12 }).map((_, i) => {
        const size = 8 + ((i * 3) % 12);
        return (
          <div
            key={`f-${i}`}
            className="absolute rounded-full bg-primary/60 shadow-[0_0_10px_hsl(var(--primary)/0.55)] animate-bubble-fall"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${(i * 8.3) % 100}%`,
              top: "-20px",
              animationDelay: `${i * 0.6}s`,
              animationDuration: `${5 + (i % 5)}s`,
            }}
          />
        );
      })}
    </div>
  );
}
