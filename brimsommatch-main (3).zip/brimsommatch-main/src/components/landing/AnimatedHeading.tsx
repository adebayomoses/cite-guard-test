import { motion } from "framer-motion";

interface Props {
  customTitle?: string | null;
}

export default function AnimatedHeading({ customTitle }: Props) {
  if (customTitle) {
    return (
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-tight mb-6"
      >
        {customTitle}
      </motion.h1>
    );
  }

  const words = ["Find", "scholarships", "you'll", "actually"];

  return (
    <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-tight mb-6">
      {words.map((word, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0, y: 20, filter: "blur(4px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ delay: 0.15 * i, duration: 0.5 }}
          className="inline-block mr-[0.3em]"
        >
          {word}
        </motion.span>
      ))}
      <motion.span
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.7, duration: 0.5, type: "spring" }}
        className="inline-block animate-shimmer"
      >
        win
      </motion.span>
    </h1>
  );
}
