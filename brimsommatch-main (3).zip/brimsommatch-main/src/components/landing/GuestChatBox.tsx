import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { Sparkles, ChevronDown, ArrowUp, X, MessageSquarePlus, Calendar, MapPin, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "framer-motion";

const FREE_MESSAGE_LIMIT = 2;
const STORAGE_KEY = "brim_guest_chat_count";
const RESET_KEY = "brim_guest_chat_reset_at";
const GUEST_ID_KEY = "brim_guest_id";
const GUEST_ID_COOKIE = "bgid";
const RESET_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 hours
const COOKIE_MAX_AGE = 60 * 60 * 24 * 365; // 1 year

function readCookie(name: string): string | null {
  if (typeof document === "undefined") return null;
  const escaped = name.replace(/([.$?*|{}()\[\]\\\/\+^])/g, "\\$1");
  const match = document.cookie.match(new RegExp("(?:^|; )" + escaped + "=([^;]*)"));
  return match ? decodeURIComponent(match[1]) : null;
}

function writeCookie(name: string, value: string) {
  if (typeof document === "undefined") return;
  const secure = typeof location !== "undefined" && location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${name}=${encodeURIComponent(value)}; Max-Age=${COOKIE_MAX_AGE}; Path=/; SameSite=Lax${secure}`;
}

function getOrCreateGuestId(): string {
  // 1) Cookie — most stable across page loads and survives localStorage clears.
  let id = readCookie(GUEST_ID_COOKIE);
  // 2) Fallback to localStorage if cookies were stripped (e.g. some private modes).
  if (!id) {
    try { id = localStorage.getItem(GUEST_ID_KEY); } catch { /* ignore */ }
  }
  if (!id) {
    const rand = (globalThis.crypto?.randomUUID?.()
      ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}-${Math.random().toString(36).slice(2, 10)}`);
    id = `g_${rand}`;
  }
  // Mirror into both stores so the ID survives clearing either one.
  writeCookie(GUEST_ID_COOKIE, id);
  try { localStorage.setItem(GUEST_ID_KEY, id); } catch { /* ignore */ }
  return id;
}

type Scholarship = {
  id: string;
  title: string;
  provider: string | null;
  country: string | null;
  degree_level: string | null;
  next_close_date: string | null;
  funding_type: string | null;
  funding_amount: string | null;
  url: string | null;
};

type Msg = { role: "user" | "assistant"; content: string; scholarships?: Scholarship[] };

function GuestScholarshipCard({ s }: { s: Scholarship }) {
  const deadline = s.next_close_date ? new Date(s.next_close_date).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : null;
  return (
    <div className="bg-background border border-border rounded-xl p-3 flex flex-col gap-1.5 hover:border-primary/40 transition-colors">
      <p className="font-semibold text-sm text-foreground line-clamp-2 leading-snug">{s.title}</p>
      {s.provider && <p className="text-xs text-muted-foreground line-clamp-1">{s.provider}</p>}
      <div className="flex flex-wrap gap-1.5 mt-0.5">
        {s.country && (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-secondary text-foreground">
            <MapPin className="h-2.5 w-2.5" />{s.country}
          </span>
        )}
        {deadline && (
          <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary">
            <Calendar className="h-2.5 w-2.5" />{deadline}
          </span>
        )}
        {s.funding_type && (
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">{s.funding_type}</span>
        )}
      </div>
      <Link
        to="/auth?tab=signup"
        className="inline-flex items-center gap-1 text-[11px] text-primary font-medium mt-1 hover:underline"
      >
        <Lock className="h-2.5 w-2.5" /> Sign up to view & match
      </Link>
    </div>
  );
}

interface Props {
  initialPrompts: string[];
  typedPlaceholder: string;
}

function formatRemaining(ms: number) {
  if (ms <= 0) return "0s";
  const totalSec = Math.ceil(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export default function GuestChatBox({ initialPrompts, typedPlaceholder }: Props) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showSignupOverlay, setShowSignupOverlay] = useState(false);
  const [usedCount, setUsedCount] = useState(0);
  const [resetAt, setResetAt] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const scrollRef = useRef<HTMLDivElement>(null);
  const guestIdRef = useRef<string>("");

  useEffect(() => {
    // Establish stable guest identifier (cookie + localStorage mirror)
    guestIdRef.current = getOrCreateGuestId();

    const stored_resetAt = parseInt(localStorage.getItem(RESET_KEY) || "0", 10);
    if (stored_resetAt && Date.now() >= stored_resetAt) {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(RESET_KEY);
      setUsedCount(0);
      setResetAt(null);
      return;
    }
    if (stored_resetAt) setResetAt(stored_resetAt);
    const stored = parseInt(localStorage.getItem(STORAGE_KEY) || "0", 10);
    setUsedCount(stored);
    if (stored >= FREE_MESSAGE_LIMIT) setShowSignupOverlay(true);
  }, []);

  // Tick every second while limit reached so countdown stays live
  useEffect(() => {
    if (usedCount < FREE_MESSAGE_LIMIT || !resetAt) return;
    setNow(Date.now());
    const id = setInterval(() => {
      const t = Date.now();
      setNow(t);
      if (t >= resetAt) {
        localStorage.removeItem(STORAGE_KEY);
        localStorage.removeItem(RESET_KEY);
        setUsedCount(0);
        setResetAt(null);
        setShowSignupOverlay(false);
      }
    }, 1000);
    return () => clearInterval(id);
  }, [usedCount, resetAt]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const send = async (textOverride?: string) => {
    const text = (textOverride ?? input).trim();
    if (!text || loading) return;

    if (usedCount >= FREE_MESSAGE_LIMIT) {
      setShowSignupOverlay(true);
      return;
    }

    const newMessages: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/guest-chat`;
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: newMessages, guest_id: guestIdRef.current }),
      });

      if (!resp.ok || !resp.body) {
        const errBody = await resp.json().catch(() => ({ error: "Something went wrong" }));
        // Server says limit reached — sync local state with server truth
        if (resp.status === 429 && errBody?.limit_reached) {
          const serverReset = typeof errBody.reset_at === "number" ? errBody.reset_at : Date.now() + RESET_WINDOW_MS;
          setUsedCount(FREE_MESSAGE_LIMIT);
          setResetAt(serverReset);
          localStorage.setItem(STORAGE_KEY, String(FREE_MESSAGE_LIMIT));
          localStorage.setItem(RESET_KEY, String(serverReset));
          setMessages((prev) => prev.slice(0, -1)); // drop the unanswered user message
          setShowSignupOverlay(true);
          setLoading(false);
          return;
        }
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: `⚠️ ${errBody.error || "Couldn't reach Brim right now. Please try again."}` },
        ]);
        setLoading(false);
        return;
      }

      // Stream response
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";
      let assistantSoFar = "";
      let streamDone = false;
      let assistantStarted = false;

      const upsertAssistant = (chunk: string) => {
        assistantSoFar += chunk;
        setMessages((prev) => {
          if (!assistantStarted) {
            assistantStarted = true;
            return [...prev, { role: "assistant", content: assistantSoFar }];
          }
          return prev.map((m, i) =>
            i === prev.length - 1 && m.role === "assistant" ? { ...m, content: assistantSoFar } : m
          );
        });
      };

      const attachScholarships = (items: Scholarship[]) => {
        setMessages((prev) => {
          if (!assistantStarted) {
            assistantStarted = true;
            return [...prev, { role: "assistant", content: "", scholarships: items }];
          }
          return prev.map((m, i) =>
            i === prev.length - 1 && m.role === "assistant" ? { ...m, scholarships: items } : m
          );
        });
      };

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }
          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.type === "usage") {
              const serverUsed = typeof parsed.used === "number" ? parsed.used : usedCount + 1;
              const serverReset = typeof parsed.reset_at === "number" ? parsed.reset_at : Date.now() + RESET_WINDOW_MS;
              setUsedCount(serverUsed);
              setResetAt(serverReset);
              localStorage.setItem(STORAGE_KEY, String(serverUsed));
              localStorage.setItem(RESET_KEY, String(serverReset));
              if (serverUsed >= FREE_MESSAGE_LIMIT) {
                setTimeout(() => setShowSignupOverlay(true), 800);
              }
              continue;
            }
            if (parsed.type === "scholarships" && Array.isArray(parsed.items)) {
              attachScholarships(parsed.items);
              continue;
            }
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) upsertAssistant(content);
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }
    } catch (e) {
      console.error(e);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "⚠️ Couldn't reach Brim right now. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const remaining = Math.max(0, FREE_MESSAGE_LIMIT - usedCount);
  const hasConversation = messages.length > 0;
  const limitReached = usedCount >= FREE_MESSAGE_LIMIT;
  const msUntilReset = resetAt ? Math.max(0, resetAt - now) : 0;
  const countdownLabel = formatRemaining(msUntilReset);

  return (
    <div className="relative">
      <div className="relative bg-background border-2 border-primary/20 rounded-3xl p-5 sm:p-7 md:p-8 shadow-[0_20px_60px_-15px_hsl(var(--primary)/0.35)] ring-1 ring-foreground/5">
        <div className="absolute -inset-1 bg-gradient-to-br from-primary/30 via-primary/10 to-primary/30 rounded-3xl blur-2xl opacity-60 -z-10" />

        {/* Chips */}
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-secondary rounded-full text-sm font-medium text-foreground">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Brim V1
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-secondary rounded-full text-sm font-medium text-foreground">
            Scholarship match
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </div>
          {hasConversation && (
            <span className="ml-auto text-xs text-muted-foreground">
              {remaining > 0
                ? `${remaining} free ${remaining === 1 ? "question" : "questions"} left`
                : resetAt
                ? `Resets in ${countdownLabel}`
                : "Free preview ended"}
            </span>
          )}
        </div>

        <div className="border-t border-border/60 my-3" />

        {/* Conversation area */}
        {hasConversation && (
          <div
            ref={scrollRef}
            className="max-h-[320px] overflow-y-auto space-y-4 mb-4 pr-1 text-left"
          >
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`rounded-2xl px-4 py-3 text-sm ${
                    m.role === "user"
                      ? "max-w-[85%] bg-primary text-primary-foreground"
                      : "max-w-[92%] sm:max-w-[88%] bg-secondary text-foreground"
                  }`}
                >
                  {m.role === "assistant" ? (
                    <div className="space-y-3">
                      {m.scholarships && m.scholarships.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {m.scholarships.map((s) => (
                            <GuestScholarshipCard key={s.id} s={s} />
                          ))}
                        </div>
                      )}
                      {m.content && (
                        <div className="prose prose-sm dark:prose-invert max-w-none text-left prose-p:my-2 prose-ol:my-2 prose-ul:my-2 prose-ol:pl-5 prose-ul:pl-5 prose-li:my-1 prose-li:marker:text-primary prose-strong:text-foreground prose-headings:my-2 leading-relaxed">
                          <ReactMarkdown>{m.content}</ReactMarkdown>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="whitespace-pre-wrap text-left">{m.content}</p>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-secondary rounded-2xl px-4 py-2.5 text-sm text-muted-foreground flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Suggestion chips (only when no conversation yet) */}
        {!hasConversation && (
          <div className="flex flex-wrap gap-2 mb-3">
            {initialPrompts.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => send(p)}
                className="text-xs px-3 py-1.5 rounded-full bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        )}

        {/* Input row */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex items-center gap-2 mt-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={hasConversation ? "Ask a follow-up…" : typedPlaceholder}
            maxLength={500}
            disabled={loading || showSignupOverlay}
            className="flex-1 min-w-0 bg-transparent text-base sm:text-lg text-foreground placeholder:text-muted-foreground/70 py-3 px-1 outline-none disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading || showSignupOverlay}
            aria-label="Send"
            className="h-11 w-11 rounded-full bg-primary text-primary-foreground flex items-center justify-center shrink-0 shadow-md hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </form>

        <div className="flex justify-between items-center mt-2">
          <span className="text-xs text-muted-foreground">
            {hasConversation ? "Powered by Brim AI" : "Try Brim free — no signup needed"}
          </span>
          <Link to="/auth?tab=signup" className="text-xs text-primary hover:underline">
            Sign up →
          </Link>
        </div>

        {/* Signup overlay */}
        <AnimatePresence>
          {showSignupOverlay && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-card/95 backdrop-blur-sm rounded-3xl flex items-center justify-center p-6 z-30"
            >
              <button
                type="button"
                onClick={() => setShowSignupOverlay(false)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
                aria-label="Close"
              >
                <X className="h-5 w-5" />
              </button>
              <div className="text-center max-w-sm">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <MessageSquarePlus className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">You've used your free preview</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Sign up free to keep chatting with Brim, get your AI Chance Score, and discover scholarships matched to you.
                </p>
                {limitReached && resetAt && (
                  <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-secondary text-muted-foreground mb-4">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                    Free chat resets in <span className="font-semibold text-foreground">{countdownLabel}</span>
                  </div>
                )}
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <Button asChild>
                    <Link to="/auth?tab=signup">Create free account</Link>
                  </Button>
                  <Button variant="ghost" asChild>
                    <Link to="/auth">Log in</Link>
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
