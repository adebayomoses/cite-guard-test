import { useState } from "react";
import { Copy, Check, Share2, FileText } from "lucide-react";
import { toast } from "sonner";
import MarkdownContent from "@/components/MarkdownContent";

// Strip markdown emphasis/heading markers for plain-text copy
function stripMarkdown(s: string): string {
  return s
    .replace(/^\s*#{1,6}\s+/gm, "")
    .replace(/\*\*\*(.+?)\*\*\*/g, "$1")
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/(^|[^*])\*(?!\s)([^*\n]+?)\*(?!\*)/g, "$1$2")
    .replace(/__(.+?)__/g, "$1")
    .replace(/^\s*---+\s*$/gm, "")
    .trim();
}

interface Props {
  content: string;
  streaming?: boolean;
}

export default function EssayBlock({ content, streaming }: Props) {
  const [copied, setCopied] = useState(false);

  const plain = stripMarkdown(content);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(plain);
      setCopied(true);
      toast.success("Essay copied");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy");
    }
  };

  const handleShare = async () => {
    const data = { title: "My Essay Draft", text: plain };
    try {
      if (navigator.share) await navigator.share(data);
      else {
        await navigator.clipboard.writeText(data.text);
        toast.success("Copied — share it anywhere!");
      }
    } catch (e: any) {
      if (e?.name !== "AbortError") toast.error("Failed to share");
    }
  };

  const wordCount = content.trim().split(/\s+/).filter(Boolean).length;

  return (
    <div className="w-full my-2 rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-muted/40">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <FileText className="h-3.5 w-3.5" />
          <span>Essay Draft</span>
          {!streaming && <span className="text-muted-foreground/70">· {wordCount} words</span>}
          {streaming && <span className="text-primary animate-pulse">· writing…</span>}
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted"
            aria-label="Copy essay"
          >
            {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
          <button
            type="button"
            onClick={handleShare}
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted"
            aria-label="Share essay"
          >
            <Share2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Share</span>
          </button>
        </div>
      </div>
      <div className="px-3 py-3 sm:px-5 sm:py-4 max-h-[60vh] overflow-y-auto font-serif text-sm sm:text-[15px] leading-relaxed text-foreground">
        <MarkdownContent content={content.trim()} className="prose-p:my-3 prose-headings:font-serif" />
      </div>
    </div>
  );
}

/**
 * Extracts ```essay ... ``` fenced blocks from assistant content.
 * Returns ordered segments so the UI can render prose + essay cards in the right order.
 * Also handles an unclosed trailing essay block (streaming case).
 */
export type EssaySegment =
  | { type: "text"; content: string }
  | { type: "essay"; content: string; streaming?: boolean };

export function parseEssaySegments(raw: string): EssaySegment[] {
  const segments: EssaySegment[] = [];
  const fence = /```\s*essay\b[^\n]*\n?([\s\S]*?)(?:```|$)/gi;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let hadFence = false;
  while ((match = fence.exec(raw)) !== null) {
    hadFence = true;
    if (match.index > lastIndex) {
      const text = raw.slice(lastIndex, match.index);
      if (text.trim()) segments.push({ type: "text", content: text });
    }
    let body = match[1] ?? "";
    const closed = raw.slice(match.index + match[0].length - 3, match.index + match[0].length) === "```";
    // Strip trailing commentary (Notes for Personalization, Tips, Word count, follow-up Qs)
    // that the model sometimes leaks INSIDE the fenced block.
    const split = splitEssayAndTrailing(body);
    body = split.body;
    segments.push({ type: "essay", content: body, streaming: !closed });
    if (split.trailing.trim()) segments.push({ type: "text", content: split.trailing });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < raw.length) {
    const tail = raw.slice(lastIndex);
    if (tail.trim()) segments.push({ type: "text", content: tail });
  }

  // Fallback: if the model ignored the ```essay fence but clearly produced an
  // essay/SOP/letter under a recognizable heading, auto-wrap it into a card.
  if (!hadFence && segments.length === 1 && segments[0].type === "text") {
    const implicit = extractImplicitEssay(segments[0].content);
    if (implicit) return implicit;

    // Final fallback for Brim Advisor: sometimes the model outputs only the SOP
    // body with no heading/fence (e.g. starts directly with "For my undergraduate...").
    // Detect that as a standalone first-person document and card it.
    const standalone = extractStandaloneEssay(segments[0].content);
    if (standalone) return standalone;
  }
  return segments;
}

const ESSAY_HEADING =
  /(^|\n)\s*(?:#{1,6}\s*|>\s*)?(?:\*\*|__)?\s*(?:(?:Draft|Revised|Final|Full|Sample|Tailored|Updated)\s+)?(?:Statement of Purpose|Personal Statement|Motivation Letter|Letter of Motivation|Motivational Letter|Motivation Statement|Cover Letter|Scholarship Essay|Admission Essay|Application Essay|Supplemental Essay|Recommendation Letter|Letter of Recommendation|Reference Letter|SOP|Statement of Intent|Study Plan|Research Statement)(?:\s+(?:Draft|Version|Template|Sample))?(?:\s*(?:[—–\-:]|for\b).*)?(?:\*\*|__)?\s*(?:\n|$)/i;

// Markers that clearly signal the assistant has STOPPED writing the essay body
// and moved on to commentary / tips / follow-up question.
const ESSAY_END_MARKER =
  /\n\s*(?:✅|⚠️|✏️|(?:---+\s*\n+\s*)?(?:#{1,6}\s*)?(?:\*\*|__)?\s*(?:Strong sections|Needs your input|Tightening notes|Tips?|What to improve|Suggestions?|Suggested edits|Notes(?: for [A-Z][\w ]+)?|Personalization notes|Notes for Personalization|Word count|Word-count|Follow-up|Next steps?|How to personalize|Why this works|What I changed|Missing details|Placeholders?|Questions?|Ready for the next step)\s*(?::|\*\*|__|\n)|(?:---+\s*\n+\s*(?=(?:✅|⚠️|✏️|#{1,6}\s*)?(?:Strong sections|Needs your input|Tips?|Notes|Word count|Follow-up|Would you like|Want me to|Let me know)))|Want me to|Would you like|If you'd like|Let me know|Shall I|Do you want|Should I|I can also|I can help)\b|(?:\n\s*[A-Z][^\n]{8,180}\?\s*$)/im;

const ASSISTANT_INTRO_LINE =
  /^\s*(?:(?:here(?:'s| is)|sure|absolutely|of course|happy to help|below|great|perfect)[^\n]{0,260}(?:draft|letter|essay|statement|sop|motivation|based on what you shared)[^\n]*(?::|—|-)?\s*\n+)/i;

const FORMAL_LETTER_START =
  /(^|\n)\s*(Dear\s+(?:Admissions Committee|Selection Committee|Scholarship Committee|Hiring Committee|Graduate Admissions Committee|Visa Officer|Professor|Prof\.|Dr\.|Sir\/Madam|Sir or Madam|Madam\/Sir|[A-Z][^\n,]{1,70}),?)/i;

function splitEssayAndTrailing(text: string): { body: string; trailing: string } {
  let body = text.replace(/^\s*---+\s*\n+/, "");
  const endMatch = body.match(ESSAY_END_MARKER);
  if (!endMatch || endMatch.index === undefined) return { body, trailing: "" };
  return {
    body: body.slice(0, endMatch.index),
    trailing: body.slice(endMatch.index),
  };
}

const NON_DOCUMENT_MARKER = /```brim-question|\[\[scholarship:/i;

function looksLikeStandaloneDraft(text: string): boolean {
  const body = text.trim();
  if (NON_DOCUMENT_MARKER.test(body)) return false;

  const words = body.split(/\s+/).filter(Boolean).length;
  if (words < 45) return false;

  const paragraphs = body.split(/\n\s*\n/).filter((p) => p.trim().split(/\s+/).length >= 18).length;
  const firstPerson = (body.match(/\b(?:I|my|me|mine|myself|we|our|ours)\b/g) ?? []).length;
  const secondPerson = (body.match(/\b(?:you|your|yours|yourself)\b/gi) ?? []).length;
  const bulletLines = (body.match(/^\s*(?:[-*•]|\d+[.)])\s+/gm) ?? []).length;
  const formalLetter = FORMAL_LETTER_START.test(body);
  const hasApplicationClose = /\n\s*(?:Sincerely|Yours faithfully|Yours sincerely|Respectfully|Kind regards),?/i.test(body);

  if (bulletLines >= 3) return false;
  if (secondPerson > Math.max(6, firstPerson)) return false;

  return (paragraphs >= 2 && firstPerson >= 5) || (words >= 160 && firstPerson >= 8) || (formalLetter && (firstPerson >= 3 || hasApplicationClose));
}

function extractImplicitEssay(text: string): EssaySegment[] | null {
  const m = text.match(ESSAY_HEADING);
  if (!m || m.index === undefined) return null;
  const headingStart = m.index + (m[1] ? m[1].length : 0);
  const before = text.slice(0, headingStart).trimEnd();
  const after = text.slice(headingStart);

  const { body: essayBody, trailing } = splitEssayAndTrailing(after);

  // Lower threshold so short scholarship essays (~150-200 words) still card.
  if (essayBody.trim().split(/\s+/).filter(Boolean).length < 40) return null;

  const out: EssaySegment[] = [];
  if (before.trim()) out.push({ type: "text", content: before });
  out.push({ type: "essay", content: essayBody });
  if (trailing.trim()) out.push({ type: "text", content: trailing });
  return out;
}

function extractStandaloneEssay(text: string): EssaySegment[] | null {
  // Try multiple split points: assistant intro line, then any horizontal rule(s),
  // then the first paragraph boundary. Pick the first candidate whose body
  // looks like a real first-person draft.
  const candidates: Array<{ before: string; body: string; trailing: string }> = [];

  const pushCandidate = (before: string, rest: string) => {
    const { body, trailing } = splitEssayAndTrailing(rest);
    candidates.push({ before, body, trailing });
  };

  // 1) Strip assistant intro line ("Here is your...:")
  const intro = text.match(ASSISTANT_INTRO_LINE);
  if (intro) {
    pushCandidate(intro[0].trimEnd(), text.slice(intro[0].length));
  }

  // 2) Split at each horizontal rule (---), trying body = everything after
  const hrRe = /\n\s*---+\s*\n/g;
  let hr: RegExpExecArray | null;
  while ((hr = hrRe.exec(text)) !== null) {
    const before = text.slice(0, hr.index).trim();
    const rest = text.slice(hr.index + hr[0].length);
    pushCandidate(before, rest);
  }

  // 3) Split after the first paragraph (commentary intro paragraph)
  const paraSplit = text.indexOf("\n\n");
  if (paraSplit > 0) {
    pushCandidate(text.slice(0, paraSplit).trim(), text.slice(paraSplit + 2));
  }

  // 4) Split at a formal letter salutation (Dear Admissions Committee, ...)
  const formalStart = text.match(FORMAL_LETTER_START);
  if (formalStart && formalStart.index !== undefined) {
    const start = formalStart.index + (formalStart[1] ? formalStart[1].length : 0);
    pushCandidate(text.slice(0, start).trim(), text.slice(start));
  }

  // 5) Whole text as-is as the final fallback only, so commentary splits win.
  pushCandidate("", text);

  for (const c of candidates) {
    if (!looksLikeStandaloneDraft(c.body)) continue;
    const out: EssaySegment[] = [];
    if (c.before.trim()) out.push({ type: "text", content: c.before });
    out.push({ type: "essay", content: c.body });
    if (c.trailing.trim()) out.push({ type: "text", content: c.trailing });
    return out;
  }
  return null;
}

