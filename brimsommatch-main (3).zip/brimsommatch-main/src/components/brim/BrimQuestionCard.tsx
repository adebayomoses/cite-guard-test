import { useState } from "react";
import { ArrowRight, X, Pencil } from "lucide-react";

export type BrimQuestion = {
  question: string;
  options: string[];
  allowSkip?: boolean;
  allowFreeText?: boolean;
  page?: string;
  placeholder?: string;
};

interface Props {
  data: BrimQuestion;
  disabled?: boolean;
  onAnswer: (answer: string) => void;
  onDismiss?: () => void;
}

export default function BrimQuestionCard({ data, disabled, onAnswer, onDismiss }: Props) {
  const [freeText, setFreeText] = useState("");
  const [hovered, setHovered] = useState<number | null>(null);

  const handlePick = (opt: string) => {
    if (disabled) return;
    onAnswer(opt);
  };

  const submitFree = () => {
    const t = freeText.trim();
    if (!t || disabled) return;
    onAnswer(t);
  };

  const hasOptions = data.options.length > 0;
  const showFreeText = data.allowFreeText ?? true;
  const placeholder = data.placeholder ?? (hasOptions ? "Something else" : "Type your answer…");

  return (
    <div className="not-prose my-3 rounded-2xl border border-border bg-card shadow-sm overflow-hidden">
      <div className="flex items-start justify-between gap-3 px-4 pt-4 pb-2">
        <p className="text-sm sm:text-base text-foreground font-medium leading-snug flex-1">
          {data.question}
        </p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
          {data.page && <span>{data.page}</span>}
          {onDismiss && (
            <button
              type="button"
              onClick={onDismiss}
              className="hover:text-foreground transition-colors"
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <ul className={`divide-y divide-border ${hasOptions ? "border-t border-border" : ""}`}>
        {data.options.map((opt, idx) => (
          <li key={`${opt}-${idx}`}>
            <button
              type="button"
              disabled={disabled}
              onClick={() => handlePick(opt)}
              onMouseEnter={() => setHovered(idx)}
              onMouseLeave={() => setHovered(null)}
              className="w-full flex items-center gap-3 px-4 py-3 text-left text-sm hover:bg-muted/60 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-muted text-xs font-medium text-muted-foreground shrink-0">
                {idx + 1}
              </span>
              <span className="flex-1 text-foreground">{opt}</span>
              <ArrowRight
                className={`h-4 w-4 text-muted-foreground transition-opacity ${
                  hovered === idx ? "opacity-100" : "opacity-0"
                }`}
              />
            </button>
          </li>
        ))}

        {showFreeText && (
          <li className={`flex items-center gap-2 px-3 py-2 ${hasOptions ? "bg-muted/30" : "border-t border-border"}`}>
            <Pencil className="h-4 w-4 text-muted-foreground shrink-0" />
            <input
              type="text"
              value={freeText}
              onChange={(e) => setFreeText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  submitFree();
                }
              }}
              disabled={disabled}
              placeholder={placeholder}
              autoFocus
              className="flex-1 min-w-0 bg-transparent text-sm placeholder:text-muted-foreground focus:outline-none caret-primary disabled:opacity-50"
            />
            {freeText.trim() && (
              <button
                type="button"
                disabled={disabled}
                onClick={submitFree}
                className="shrink-0 text-xs px-3 py-1 rounded-md bg-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                Send
              </button>
            )}
            {data.allowSkip !== false && (
              <button
                type="button"
                disabled={disabled}
                onClick={() => handlePick("Skip")}
                className="shrink-0 text-xs px-2.5 py-1 rounded-md border border-border bg-background hover:bg-muted transition-colors disabled:opacity-50"
              >
                Skip
              </button>
            )}
          </li>
        )}
      </ul>
    </div>
  );
}

const BLOCK_RE = /```brim-question\s*\n([\s\S]*?)```/g;

export function extractBrimQuestion(content: string): { text: string; question: BrimQuestion | null } {
  let question: BrimQuestion | null = null;
  let m: RegExpExecArray | null;
  const re = new RegExp(BLOCK_RE);
  while ((m = re.exec(content)) !== null) {
    try {
      const parsed = JSON.parse(m[1].trim());
      if (parsed && typeof parsed.question === "string") {
        question = {
          question: parsed.question,
          options: Array.isArray(parsed.options) ? parsed.options.filter((o: any) => typeof o === "string") : [],
          allowSkip: parsed.allowSkip,
          allowFreeText: parsed.allowFreeText,
          page: parsed.page,
          placeholder: parsed.placeholder,
        };
      }
    } catch {
      // ignore malformed
    }
  }
  const text = content.replace(BLOCK_RE, "").replace(/\n{3,}/g, "\n\n").trim();
  return { text, question };
}
