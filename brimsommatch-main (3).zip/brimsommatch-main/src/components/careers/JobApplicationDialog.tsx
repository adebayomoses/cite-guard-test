import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { Loader2, Upload, CheckCircle2 } from "lucide-react";

const schema = z.object({
  full_name: z.string().trim().min(2, "Name is required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  phone: z.string().trim().max(30).optional(),
  experience: z.string().trim().min(10, "Tell us a bit about your experience").max(2000),
});

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  position: string;
}

const MAX_FILE_MB = 5;
const ALLOWED = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];

export default function JobApplicationDialog({ open, onOpenChange, position }: Props) {
  const [form, setForm] = useState({ full_name: "", email: "", phone: "", experience: "" });
  const [resume, setResume] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const reset = () => {
    setForm({ full_name: "", email: "", phone: "", experience: "" });
    setResume(null);
    setDone(false);
  };

  const handleFile = (f: File | null) => {
    if (!f) return setResume(null);
    if (f.size > MAX_FILE_MB * 1024 * 1024) {
      toast({ title: `File too large (max ${MAX_FILE_MB}MB)`, variant: "destructive" });
      return;
    }
    if (!ALLOWED.includes(f.type)) {
      toast({ title: "Only PDF or Word documents allowed", variant: "destructive" });
      return;
    }
    setResume(f);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      const first = Object.values(parsed.error.flatten().fieldErrors)[0]?.[0];
      toast({ title: first || "Please check the form", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      let resume_path: string | null = null;
      if (resume) {
        const ext = resume.name.split(".").pop();
        const path = `public/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from("job-applications")
          .upload(path, resume, { contentType: resume.type, upsert: false });
        if (upErr) throw upErr;
        resume_path = path;
      }
      const { error } = await supabase.from("job_applications").insert({
        position,
        full_name: parsed.data.full_name,
        email: parsed.data.email,
        phone: parsed.data.phone || null,
        experience: parsed.data.experience,
        resume_path,
      });
      if (error) throw error;
      setDone(true);
    } catch (err: any) {
      toast({ title: "Submission failed", description: err.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-lg max-h-[90vh] overflow-y-auto">
        {done ? (
          <div className="text-center py-8 space-y-3">
            <CheckCircle2 className="h-12 w-12 text-primary mx-auto" />
            <DialogTitle>Application received</DialogTitle>
            <p className="text-sm text-muted-foreground">
              Thank you! We'll review your application and reach out if it's a match.
            </p>
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <DialogHeader>
              <DialogTitle>Apply: {position}</DialogTitle>
              <DialogDescription>Fill in your details and upload your resume.</DialogDescription>
            </DialogHeader>

            <div className="space-y-2">
              <Label htmlFor="full_name">Full Name *</Label>
              <Input id="full_name" value={form.full_name} maxLength={100}
                onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input id="email" type="email" value={form.email} maxLength={255}
                  onChange={(e) => setForm({ ...form, email: e.target.value })} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" value={form.phone} maxLength={30}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="experience">Relevant Experience *</Label>
              <Textarea id="experience" rows={4} value={form.experience} maxLength={2000}
                placeholder="Briefly describe your background, skills, and why you're a good fit."
                onChange={(e) => setForm({ ...form, experience: e.target.value })} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="resume">Resume (PDF or Word, max 5MB)</Label>
              <label htmlFor="resume" className="flex items-center gap-2 border border-dashed border-input rounded-md px-3 py-3 cursor-pointer hover:bg-accent text-sm">
                <Upload className="h-4 w-4" />
                <span className="truncate">{resume ? resume.name : "Click to upload"}</span>
              </label>
              <input id="resume" type="file" className="hidden"
                accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                onChange={(e) => handleFile(e.target.files?.[0] || null)} />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
              <Button type="submit" disabled={submitting}>
                {submitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Submit Application
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
