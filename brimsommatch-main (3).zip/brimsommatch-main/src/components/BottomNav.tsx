import { useLocation, Link } from "react-router-dom";
import { LayoutDashboard, MessageCircle, Search, Sparkles, UserPen } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUnreadCounts } from "@/hooks/useUnreadCounts";

const tabs = [
  { label: "Home", icon: LayoutDashboard, to: "/dashboard" },
  { label: "Scholarships", icon: Search, to: "/scholarships" },
  { label: "Brim Ai", icon: Sparkles, to: "/brim-ai-chat" },
  { label: "Chat", icon: MessageCircle, to: "/community" },
  { label: "Profile", icon: UserPen, to: "/profile" },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const { totalUnread } = useUnreadCounts();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 lg:hidden border-t border-border bg-background/80 backdrop-blur-lg"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <div className="flex items-center justify-around h-14">
        {tabs.map(({ label, icon: Icon, to }) => {
          const active = pathname === to || pathname.startsWith(to + "/");
          const showBadge = to === "/community" && totalUnread > 0;
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 flex-1 h-full text-[10px] font-medium transition-colors",
                active ? "text-primary" : "text-muted-foreground"
              )}
            >
              <span className="relative">
                <Icon className="h-5 w-5" />
                {showBadge && (
                  <span className="absolute -top-1 -right-1.5 bg-primary text-primary-foreground text-[9px] font-bold rounded-full px-1 min-w-[16px] h-[16px] flex items-center justify-center leading-none">
                    {totalUnread > 9 ? "9+" : totalUnread}
                  </span>
                )}
              </span>
              <span>{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
