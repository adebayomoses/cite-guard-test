import ReactMarkdown from "react-markdown";

interface Props {
  content: string;
  className?: string;
}

export default function MarkdownContent({ content, className = "" }: Props) {
  const processed = content.replace(/^(#{1,6})([^\s#])/gm, "$1 $2");
  return (
    <div className={`prose prose-sm dark:prose-invert max-w-none prose-headings:text-foreground prose-p:text-foreground prose-li:text-foreground prose-strong:text-foreground ${className}`}>
      <ReactMarkdown>{processed}</ReactMarkdown>
    </div>
  );
}
