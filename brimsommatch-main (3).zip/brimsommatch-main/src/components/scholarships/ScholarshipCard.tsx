import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  GraduationCap,
  ExternalLink,
  Calendar,
  Bookmark,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  MessageCircleQuestion,
  Star,
  Sparkles,
  Trophy,
  Clock,
  Zap,
  Target,
  TrendingUp,
} from "lucide-react";
import { format } from "date-fns";
import { getCountryFlag } from "@/lib/countryFlags";
import MarkdownContent from "@/components/MarkdownContent";
import { DEFAULT_APPLY_STEPS } from "@/lib/defaultApplySteps";
import { useScholarshipIntakes, termLabel } from "@/hooks/useScholarshipIntakes";

interface Scholarship {
  id: string;
  title: string;
  description: string | null;
  provider: string | null;
  country: string | null;
  degree_level: string | null;
  field_of_study: string | null;
  funding_amount: string | null;
  funding_type: string | null;
  next_close_date: string | null;
  eligibility_criteria: string | null;
  url: string | null;
  admission_requirements_url: string | null;
  min_cgpa_percentage: number | null;
  apply_steps: string | null;
  created_at: string | null;
}

interface MatchData {
  score: number;
  chance: number;
  reason: string;
  chance_reason: string;
  pending_ai?: boolean;
}

interface ScholarshipCardProps {
  scholarship: Scholarship;
  matchData?: MatchData;
  isRecommended: boolean;
  isSaved: boolean;
  isExpanded: boolean;
  isStepsExpanded: boolean;
  isClosingSoon?: boolean;
  isNew?: boolean;
  defaultApplySteps?: string;
  categoryApplySteps?: Record<string, string>;
  isAdmin?: boolean;
  isScoring?: boolean;
  onToggleSave: () => void;
  onToggleExpand: () => void;
  onToggleSteps: () => void;
  onAsk: () => void;
  onApply: () => void;
  onScoreWithAI?: () => void;
  tourAttr?: Record<string, string>;
}

const badgeColor = (s: number) =>
  s >= 70 ? "default" : s >= 40 ? "secondary" : "outline";

export default function ScholarshipCard({
  scholarship: s,
  matchData,
  isRecommended,
  isSaved,
  isExpanded,
  isStepsExpanded,
  isClosingSoon,
  isNew,
  defaultApplySteps,
  categoryApplySteps,
  isAdmin,
  isScoring,
  onToggleSave,
  onToggleExpand,
  onToggleSteps,
  onAsk,
  onApply,
  onScoreWithAI,
  tourAttr,
}: ScholarshipCardProps) {
  const { intakes } = useScholarshipIntakes(s.id);
  const today = new Date().toISOString().split("T")[0];
  const upcomingIntakes = intakes.filter((it) => !it.close_date || it.close_date >= today);
  return (
    <div
      {...tourAttr}
      className={`rounded-xl border bg-card p-5 hover:border-primary/30 transition-colors cursor-pointer ${
        isRecommended ? "border-green-500/40 ring-1 ring-green-500/20" : "border-border"
      }`}
      onClick={(e) => {
        const target = e.target as HTMLElement;
        if (target.closest("a, button, [role='button']")) return;
        onToggleExpand();
      }}
    >
      <div className="space-y-3">
        {/* Title + Save */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-base">{s.title}</h3>
              {s.url && (
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground">
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </div>
            {s.provider && <p className="text-sm text-muted-foreground mt-1">{s.provider}</p>}
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleSave}
            className={`shrink-0 ${isSaved ? "text-primary" : "text-muted-foreground"}`}
          >
            <Bookmark className={`h-4 w-4 ${isSaved ? "fill-current" : ""}`} />
          </Button>
        </div>

        {/* Why this match? — surfaced on every scored card for transparency */}
        {matchData?.reason && !matchData.pending_ai && !isExpanded && (
          <div
            className={`flex gap-2 rounded-lg p-2.5 ${isRecommended ? "bg-primary/5" : "bg-muted/40"}`}
            title={matchData.reason}
          >
            <Lightbulb className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground/80 font-medium mb-0.5">
                Why this match?
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{matchData.reason}</p>
            </div>
          </div>
        )}

        {/* Score badges + Dates */}
        <div className="flex flex-wrap items-center gap-2">
          {matchData !== undefined && !matchData.pending_ai && (
            <>
              <Badge variant={badgeColor(matchData.score)}>{matchData.score}% match</Badge>
              <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20 hover:bg-blue-500/25">
                {matchData.chance}% win chance
              </Badge>
              {isRecommended && (
                <Badge className="bg-green-500/15 text-green-700 dark:text-green-400 border-green-500/30 hover:bg-green-500/25">
                  <Star className="h-3 w-3 mr-1 fill-current" />
                  Recommended
                </Badge>
              )}
            </>
          )}
          {onScoreWithAI && (
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs rounded-lg gap-1 border-primary/40 bg-primary/10 text-primary hover:bg-primary/20 hover:text-primary"
              disabled={isScoring}
              onClick={(e) => { e.stopPropagation(); onScoreWithAI(); }}
            >
              <Sparkles className="h-3 w-3" />
              {isScoring ? "Scoring…" : "Score with AI"}
            </Button>

          )}
          {upcomingIntakes.length > 0 ? (
            <div className="flex flex-col gap-1 w-full">
              {upcomingIntakes.map((it, i) => (
                <div key={i} className="flex items-center gap-1.5 text-sm text-muted-foreground flex-wrap">
                  <Calendar className="h-3.5 w-3.5 shrink-0" />
                  {it.term !== "general" && (
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4">{termLabel(it)}</Badge>
                  )}
                  {it.open_date && <span>Opens {format(new Date(it.open_date), "MMM d, yyyy")}</span>}
                  {it.open_date && it.close_date && <span className="opacity-60">·</span>}
                  {it.close_date && <span>Due {format(new Date(it.close_date), "MMM d, yyyy")}</span>}
                </div>
              ))}
            </div>
          ) : (
            <>
              {s.next_close_date && (
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Calendar className="h-3.5 w-3.5" />
                  <span>Due {format(new Date(s.next_close_date), "MMM d, yyyy")}</span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Metadata badges */}
        <div className="flex flex-wrap gap-2">
          {isClosingSoon && (
            <Badge className="bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/20 hover:bg-orange-500/25">
              <Clock className="h-3 w-3 mr-1" />
              Closing Soon
            </Badge>
          )}
          {isNew && (
            <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20 hover:bg-blue-500/25">
              <Zap className="h-3 w-3 mr-1" />
              New
            </Badge>
          )}
          {s.country && <Badge variant="outline"><span className="mr-1">{getCountryFlag(s.country)}</span>{s.country}</Badge>}
          {s.degree_level && <Badge variant="outline"><GraduationCap className="h-3 w-3 mr-1" />{s.degree_level}</Badge>}
          {s.funding_amount && <Badge variant="secondary">{s.funding_amount}</Badge>}
          {s.funding_type && <Badge variant="secondary">{s.funding_type}</Badge>}
          {s.min_cgpa_percentage && <Badge variant="secondary">Min CGPA: {s.min_cgpa_percentage}%</Badge>}
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap gap-2">
          {isAdmin && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs h-8 text-amber-500 hover:text-amber-400"
              onClick={() => window.open(`/admin/scholarship-winner/${s.id}`, '_blank')}
            >
              <Trophy className="h-3.5 w-3.5 mr-1" />
              Winner
            </Button>
          )}
          <Button variant="outline" size="sm" className="text-xs h-8" onClick={onAsk}>
            <MessageCircleQuestion className="h-3 w-3 mr-1" />
            Ask
          </Button>
          <Button variant="outline" size="sm" className="text-xs h-8" onClick={onToggleSteps}>
            {isStepsExpanded ? "Hide Steps" : "Apply Steps"}
          </Button>
          {s.admission_requirements_url && (
            <Button
              variant="outline"
              size="sm"
              className="text-xs h-8"
              onClick={(e) => {
                e.stopPropagation();
                window.open(s.admission_requirements_url!, "_blank", "noopener,noreferrer");
              }}
            >
              Admission Requirements <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          )}
          {s.url && (
            <Button size="sm" className="text-xs h-8" onClick={onApply}>
              Apply Now <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          )}
        </div>
      </div>


      {/* Expanded details */}
      {isExpanded && (
        <div className="mt-3 pt-3 border-t border-border space-y-4">
          {/* Smart Score Card */}
          {matchData && (
            <div className="rounded-xl border-2 border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-accent/5 p-3 space-y-2 shadow-md">
              <div className="flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                <h4 className="text-xs font-semibold text-foreground">Scholarship Score Summary</h4>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-background border border-border shadow-sm p-2 text-center space-y-0.5">
                  <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-medium">Match Score</p>
                  <div className={`text-lg font-bold ${matchData.score >= 70 ? "text-primary" : matchData.score >= 40 ? "text-orange-500" : "text-muted-foreground"}`}>
                    {matchData.score}%
                  </div>
                  <p className="text-[9px] text-muted-foreground leading-tight">
                    {matchData.score >= 70 ? "Strong match" : matchData.score >= 40 ? "Moderate match" : "Low match"}
                  </p>
                </div>

                <div className={`relative overflow-hidden rounded-lg border shadow-sm p-2 text-center space-y-0.5 ${
                  matchData.chance >= 70
                    ? "border-emerald-400/50 bg-gradient-to-br from-emerald-400/20 via-teal-300/15 to-cyan-400/20"
                    : matchData.chance >= 40
                    ? "border-amber-400/50 bg-gradient-to-br from-amber-300/20 via-orange-300/15 to-yellow-300/20"
                    : "border-rose-400/50 bg-gradient-to-br from-rose-400/20 via-pink-300/15 to-red-400/20"
                }`}>
                  <p className="text-[9px] uppercase tracking-wider font-semibold text-foreground/70">AI Win Chance</p>
                  <div className={`text-xl font-extrabold bg-clip-text text-transparent ${
                    matchData.chance >= 70
                      ? "bg-gradient-to-r from-emerald-600 to-teal-500"
                      : matchData.chance >= 40
                      ? "bg-gradient-to-r from-amber-600 to-orange-500"
                      : "bg-gradient-to-r from-rose-600 to-red-500"
                  }`}>
                    {matchData.chance}%
                  </div>
                  <p className={`text-[9px] font-semibold leading-tight ${
                    matchData.chance >= 70 ? "text-emerald-700" : matchData.chance >= 40 ? "text-amber-700" : "text-rose-700"
                  }`}>
                    {matchData.chance >= 70 ? "High likelihood" : matchData.chance >= 40 ? "Moderate chances" : "Highly competitive"}
                  </p>
                </div>
              </div>

              {matchData.reason && (
                <div className="flex gap-2 rounded-lg bg-background border border-border shadow-sm p-2.5">
                  <Target className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-medium">
                      Why your match score is {matchData.score}%
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{matchData.reason}</p>
                  </div>
                </div>
              )}

              {(matchData.chance_reason || !matchData.reason) && (
                <div className="flex gap-2 rounded-lg bg-background border border-border shadow-sm p-2.5">
                  <TrendingUp className="h-3.5 w-3.5 text-blue-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-medium">
                      Why your win chance is {matchData.chance}%
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {matchData.chance_reason || "Chance score based on competition level and scholarship selectivity."}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {s.description && <MarkdownContent content={s.description} />}
          {s.eligibility_criteria && (
            <div>
              <p className="text-xs font-medium text-foreground mb-1">Eligibility Criteria</p>
              <MarkdownContent content={s.eligibility_criteria} />
            </div>
          )}
        </div>
      )}

      {isStepsExpanded && (() => {
        const catKey = (s as any).funding_category?.trim?.() as string | undefined;
        const catSteps = catKey && categoryApplySteps ? categoryApplySteps[catKey] : undefined;
        const resolved =
          (s.apply_steps && s.apply_steps.trim() ? s.apply_steps : undefined) ??
          (catSteps && catSteps.trim() ? catSteps : undefined) ??
          (defaultApplySteps && defaultApplySteps.trim() ? defaultApplySteps : undefined) ??
          DEFAULT_APPLY_STEPS;
        return (
          <div className="mt-3 pt-3 border-t border-border space-y-3">
            <MarkdownContent content={resolved} />
          </div>
        );
      })()}

      <button
        onClick={onToggleExpand}
        className="flex items-center gap-1 text-xs text-primary mt-2 hover:underline"
      >
        {isExpanded ? <><ChevronUp className="h-3 w-3" /> Show less</> : <><ChevronDown className="h-3 w-3" /> Show more</>}
      </button>
    </div>
  );
}
