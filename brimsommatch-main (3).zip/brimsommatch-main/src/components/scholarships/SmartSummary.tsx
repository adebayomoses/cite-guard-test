import { Sparkles, TrendingUp, Target, ArrowRight, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface SmartSummaryProps {
  bestChancesCount: number;
  closingSoonCount: number;
  newCount: number;
  hasScores: boolean;
  profileCompleteness: number;
  onGenerate?: () => void;
  generating?: boolean;
}

export default function SmartSummary({
  bestChancesCount,
  closingSoonCount,
  newCount,
  hasScores,
  profileCompleteness,
  onGenerate,
  generating,
}: SmartSummaryProps) {
  if (!hasScores) {
    return (
      <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/5 via-primary/[0.02] to-transparent p-5 sm:p-6">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
            <Target className="h-5 w-5 text-primary" />
          </div>
          <div className="space-y-1.5">
            <h2 className="font-semibold text-base sm:text-lg">
              Let us find the right scholarships for you
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-lg">
              {profileCompleteness >= 50
                ? "Generate your match scores and we'll sort through all available scholarships to show you the ones where you have the best chances."
                : `Your profile is ${profileCompleteness}% complete. Reach 50% to unlock personalized scholarship matching.`}
            </p>
            {profileCompleteness < 50 && (
              <Button size="sm" variant="outline" className="mt-2" asChild>
                <Link to="/profile">
                  Complete Profile <ArrowRight className="h-3.5 w-3.5 ml-1" />
                </Link>
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/5 via-primary/[0.02] to-transparent p-5 sm:p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
          <Sparkles className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="font-semibold text-base sm:text-lg">Your Scholarship Summary</h2>
          <p className="text-sm text-muted-foreground">
            {bestChancesCount > 0
              ? `We found ${bestChancesCount} scholarship${bestChancesCount !== 1 ? "s" : ""} where you have a strong chance — let's get you started.`
              : "Keep your profile updated and click \"Generate Match Scores\" as new scholarships are added."}
          </p>
          {bestChancesCount === 0 && onGenerate && (
            <Button size="sm" variant="outline" className="mt-2" onClick={onGenerate} disabled={generating}>
              {generating ? "Generating..." : <><RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Generate Match Scores</>}
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl bg-card border border-border p-3 text-center">
          <div className="text-xl sm:text-2xl font-bold text-primary">{bestChancesCount}</div>
          <p className="text-[11px] sm:text-xs text-muted-foreground mt-0.5">Best Chances</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-3 text-center">
          <div className="text-xl sm:text-2xl font-bold text-orange-500">{closingSoonCount}</div>
          <p className="text-[11px] sm:text-xs text-muted-foreground mt-0.5">Closing Soon</p>
        </div>
        <div className="rounded-xl bg-card border border-border p-3 text-center">
          <div className="text-xl sm:text-2xl font-bold text-blue-500">{newCount}</div>
          <p className="text-[11px] sm:text-xs text-muted-foreground mt-0.5">New This Week</p>
        </div>
      </div>
    </div>
  );
}
