import { useEffect, useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface OnboardingTourProps {
  active: boolean;
  target: string;
  title: string;
  description: string;
  currentStep: number;
  totalSteps: number;
  onNext: () => void;
  onPrev: () => void;
  onSkip: () => void;
}

export default function OnboardingTour({
  active,
  target,
  title,
  description,
  currentStep,
  totalSteps,
  onNext,
  onPrev,
  onSkip,
}: OnboardingTourProps) {
  const [pos, setPos] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [tooltipPos, setTooltipPos] = useState<"bottom" | "top">("bottom");
  const tooltipRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!active) return;
    const el = document.querySelector(`[data-tour="${target}"]`);
    if (!el) { setPos(null); return; }

    const update = () => {
      const rect = el.getBoundingClientRect();
      setPos({ top: rect.top, left: rect.left, width: rect.width, height: rect.height });
      // Determine if tooltip should go above or below
      setTooltipPos(rect.bottom + 220 > window.innerHeight ? "top" : "bottom");
    };

    el.scrollIntoView({ behavior: "smooth", block: "center" });
    // Small delay to let scroll finish
    const timer = setTimeout(update, 350);
    window.addEventListener("resize", update);
    return () => { clearTimeout(timer); window.removeEventListener("resize", update); };
  }, [active, target]);

  if (!active || !pos) return null;

  const pad = 8;
  const isLast = currentStep === totalSteps - 1;

  return (
    <div className="fixed inset-0 z-[9999]" aria-live="polite">
      {/* Overlay with cutout using clip-path */}
      <div
        className="absolute inset-0 bg-black/50 transition-all duration-300"
        style={{
          clipPath: `polygon(
            0% 0%, 0% 100%, 
            ${pos.left - pad}px 100%, 
            ${pos.left - pad}px ${pos.top - pad}px, 
            ${pos.left + pos.width + pad}px ${pos.top - pad}px, 
            ${pos.left + pos.width + pad}px ${pos.top + pos.height + pad}px, 
            ${pos.left - pad}px ${pos.top + pos.height + pad}px, 
            ${pos.left - pad}px 100%, 
            100% 100%, 100% 0%
          )`,
        }}
        onClick={onSkip}
      />

      {/* Highlight ring */}
      <div
        className="absolute rounded-xl ring-2 ring-primary ring-offset-2 ring-offset-background pointer-events-none transition-all duration-300"
        style={{
          top: pos.top - pad,
          left: pos.left - pad,
          width: pos.width + pad * 2,
          height: pos.height + pad * 2,
        }}
      />

      {/* Tooltip */}
      <div
        ref={tooltipRef}
        className={cn(
          "absolute z-[10000] w-80 max-w-[90vw] rounded-xl border border-border bg-card p-4 shadow-xl transition-all duration-300",
          tooltipPos === "bottom" ? "mt-3" : "mb-3"
        )}
        style={{
          top: tooltipPos === "bottom" ? pos.top + pos.height + pad + 12 : undefined,
          bottom: tooltipPos === "top" ? window.innerHeight - pos.top + pad + 12 : undefined,
          left: Math.max(12, Math.min(pos.left, window.innerWidth - 332)),
        }}
      >
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-semibold text-sm text-foreground">{title}</h3>
          <button onClick={onSkip} className="text-muted-foreground hover:text-foreground shrink-0">
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed mb-4">{description}</p>
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {currentStep + 1} of {totalSteps}
          </span>
          <div className="flex gap-2">
            {currentStep > 0 && (
              <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={onPrev}>
                <ChevronLeft className="h-3 w-3 mr-1" /> Back
              </Button>
            )}
            <Button size="sm" className="h-7 text-xs" onClick={onNext}>
              {isLast ? "Done" : <>Next <ChevronRight className="h-3 w-3 ml-1" /></>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
