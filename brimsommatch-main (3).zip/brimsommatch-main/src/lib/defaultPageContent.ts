export const DEFAULT_ABOUT_MARKDOWN = `## Our Mission

Brimsom was built with a simple belief: **every student deserves a fair shot at funding their education**. Too many talented students miss out on scholarships — not because they aren't qualified, but because they don't know where to look or how competitive they are.

We created Brimsom to change that. By combining AI-powered profile analysis with a curated scholarship database and a supportive community, we help students discover opportunities matched to their unique strengths and apply with confidence.

## How It Works

1. **Build Your Profile** — Add your education history, GPA, test scores, research experience, extracurricular activities, and documents.
2. **Get Your Score** — Our AI evaluates your profile and generates a Scholarship Readiness Score with personalized tips for improvement.
3. **Discover Matches** — Browse scholarships filtered and ranked by how well they match your profile, field of study, and target country.
4. **Apply & Track** — Save scholarships, track your applications, set deadline reminders, and get document reviews.

## Platform Features

- **AI Chance Score** — Our AI analyzes your academic profile and generates a Scholarship Readiness Score.
- **Smart Matching** — AI compares your profile against each scholarship's criteria to surface your best chances.
- **Application Tracker** — Track every scholarship you're applying to in one place.
- **Document Review** — Submit SOPs, CVs, transcripts for expert review.
- **Brim AI Chat** — Chat with our AI assistant for instant guidance.
- **Community** — Connect with fellow scholarship seekers in topic-based chat rooms.
- **PR Pathways** — Explore post-study permanent residency pathways for different countries.

## How AI Scoring Works

Your Scholarship Readiness Score analyzes multiple dimensions of your academic profile:

- **Education** — Degree level, institution quality, field of study, and GPA
- **Test Scores** — Standardized test performance (GRE, IELTS, TOEFL, SAT, etc.)
- **Research** — Publications, research projects, and academic contributions
- **Extracurriculars** — Leadership, volunteering, awards, and professional experience
- **Documents** — Completeness of your application materials

The AI then compares your profile against the requirements and competitiveness of scholarships in our database to provide both an overall readiness score and individual match percentages.
`;

export const DEFAULT_PRIVACY_MARKDOWN = `_Last updated: March 2026_

At Brimsom, we are committed to protecting your privacy. This policy explains what data we collect, how we use it, and your rights as a user of our platform.

## 1. Information We Collect

- **Account Information**: Email address, name, and password when you create an account.
- **Profile Data**: Academic level, nationality, country of residence, date of birth, education history, GPA, test scores, research experience, extracurricular activities, and uploaded documents (e.g., CVs, transcripts, SOPs).
- **Scholarship Preferences**: Saved scholarships, application tracking data, and scholarship search activity.
- **Chat & Community Data**: Messages sent in community chat rooms and direct messages, including any images shared.
- **Session Bookings**: Proposed dates, session type, and notes when booking advisory sessions.
- **Device Information**: Push notification subscription details (endpoint, keys) if you opt in to notifications.

## 2. How We Use Your Information

- **AI Scholarship Matching**: Your academic profile is analyzed by AI to calculate a Scholarship Readiness Score and match you with relevant scholarships.
- **Chance Scoring**: We compare your profile data against scholarship eligibility criteria to estimate your likelihood of success.
- **Scholarship Digest Emails**: If enabled, we send periodic email digests with new scholarship opportunities tailored to your profile.
- **Community Features**: Your display name is shown in chat rooms and direct messages to facilitate community interaction.
- **Document Review**: Submitted documents are stored securely and reviewed by authorized administrators.
- **Platform Improvement**: Aggregated, anonymized usage data helps us improve our matching algorithms and user experience.

## 3. Data Storage & Security

- Your data is stored securely using industry-standard cloud infrastructure with encryption at rest and in transit.
- Database access is controlled through Row-Level Security policies, ensuring users can only access their own data.
- Authentication is handled through secure session management with email verification.
- File uploads are stored in secure cloud storage buckets with access controls.

## 4. Third-Party Services

- **Cloud Infrastructure**: Our backend database, authentication, file storage, and serverless functions are powered by secure cloud services.
- **AI Processing**: Scholarship matching and scoring use AI models to analyze your profile. Your data is processed securely and not used to train third-party models.
- **Push Notifications**: If you enable push notifications, your browser subscription details are stored to deliver real-time updates.
- **Email Delivery**: Transactional and digest emails are sent through a secure email delivery service.

## 5. Your Rights & Choices

- **Access & Export**: You can view all your profile data through your profile page.
- **Correction**: You can update your profile information at any time.
- **Deletion**: You can request deletion of your account and all associated data by contacting us.
- **Email Opt-Out**: You can disable scholarship digest emails through your notification preferences.
- **Push Notification Opt-Out**: You can disable push notifications through your browser settings.
- **Data Portability**: You may request a copy of your data in a standard format.

## 6. Cookies & Local Storage

- **Authentication Tokens**: We use secure session tokens stored in your browser to keep you logged in.
- **Theme Preference**: Your light/dark mode preference is stored locally.
- **PWA Data**: If you install Brimsom as a Progressive Web App, a service worker caches essential assets for offline access.
- We do not use third-party tracking cookies or advertising cookies.

## 7. Data Retention

- Active account data is retained as long as your account exists.
- Chat messages and community content are retained to maintain conversation history for all participants.
- Chat images older than 30 days may be automatically cleaned up.
- Deleted accounts have all associated personal data removed.

## 8. Children's Privacy

Brimsom is intended for students and individuals seeking scholarship opportunities. We do not knowingly collect personal information from children under the age of 13.

## 9. Changes to This Policy

We may update this Privacy Policy from time to time. When we make significant changes, we will notify users through the platform.

## 10. Contact Us

If you have questions about this Privacy Policy or wish to exercise your data rights, please reach out:

- **Email**: admin@brimsom.com
- **Platform**: Use the community chat or direct message feature to contact an administrator.
`;
