// Maps country name to ISO 3166-1 alpha-2 code for flag emoji generation
const countryCodeMap: Record<string, string> = {
  "Afghanistan": "AF", "Albania": "AL", "Algeria": "DZ", "Argentina": "AR",
  "Australia": "AU", "Austria": "AT", "Bangladesh": "BD", "Belgium": "BE",
  "Brazil": "BR", "Canada": "CA", "Chile": "CL", "China": "CN",
  "Colombia": "CO", "Czech Republic": "CZ", "Czechia": "CZ",
  "Denmark": "DK", "Egypt": "EG", "Ethiopia": "ET", "Finland": "FI",
  "France": "FR", "Germany": "DE", "Ghana": "GH", "Greece": "GR",
  "Hong Kong": "HK", "Hungary": "HU", "India": "IN", "Indonesia": "ID",
  "Iran": "IR", "Iraq": "IQ", "Ireland": "IE", "Israel": "IL",
  "Italy": "IT", "Japan": "JP", "Jordan": "JO", "Kenya": "KE",
  "Kuwait": "KW", "Lebanon": "LB", "Malaysia": "MY", "Mexico": "MX",
  "Morocco": "MA", "Nepal": "NP", "Netherlands": "NL", "New Zealand": "NZ",
  "Nigeria": "NG", "Norway": "NO", "Oman": "OM", "Pakistan": "PK",
  "Philippines": "PH", "Poland": "PL", "Portugal": "PT", "Qatar": "QA",
  "Romania": "RO", "Russia": "RU", "Saudi Arabia": "SA", "Singapore": "SG",
  "South Africa": "ZA", "South Korea": "KR", "Korea": "KR", "Spain": "ES",
  "Sri Lanka": "LK", "Sweden": "SE", "Switzerland": "CH", "Taiwan": "TW",
  "Thailand": "TH", "Turkey": "TR", "Türkiye": "TR",
  "UAE": "AE", "United Arab Emirates": "AE",
  "UK": "GB", "United Kingdom": "GB", "England": "GB",
  "USA": "US", "United States": "US", "United States of America": "US",
  "Vietnam": "VN", "Uganda": "UG", "Tanzania": "TZ", "Rwanda": "RW",
  "Zambia": "ZM", "Zimbabwe": "ZW", "Cameroon": "CM", "Senegal": "SN",
  "Tunisia": "TN", "Ukraine": "UA", "Peru": "PE", "Venezuela": "VE",
  "Cuba": "CU", "Jamaica": "JM", "Trinidad and Tobago": "TT",
  "Barbados": "BB", "Bahamas": "BS", "Costa Rica": "CR", "Panama": "PA",
  "Guatemala": "GT", "Honduras": "HN", "El Salvador": "SV",
  "Nicaragua": "NI", "Dominican Republic": "DO", "Haiti": "HT",
  "Bolivia": "BO", "Paraguay": "PY", "Uruguay": "UY", "Ecuador": "EC",
  "Myanmar": "MM", "Cambodia": "KH", "Laos": "LA", "Mongolia": "MN",
  "Uzbekistan": "UZ", "Kazakhstan": "KZ", "Georgia": "GE", "Armenia": "AM",
  "Azerbaijan": "AZ", "Croatia": "HR", "Serbia": "RS", "Bulgaria": "BG",
  "Slovakia": "SK", "Slovenia": "SI", "Lithuania": "LT", "Latvia": "LV",
  "Estonia": "EE", "Iceland": "IS", "Luxembourg": "LU", "Malta": "MT",
  "Cyprus": "CY", "Bahrain": "BH", "Brunei": "BN", "Fiji": "FJ",
  "Papua New Guinea": "PG", "Maldives": "MV", "Bhutan": "BT",
};

function codeToFlag(code: string): string {
  return [...code.toUpperCase()].map(c => String.fromCodePoint(0x1F1E6 + c.charCodeAt(0) - 65)).join("");
}

export function getCountryFlag(countryName: string): string {
  const code = countryCodeMap[countryName] || countryCodeMap[countryName.trim()];
  return code ? codeToFlag(code) : "🌍";
}
