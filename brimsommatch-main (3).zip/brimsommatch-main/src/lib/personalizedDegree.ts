// Shared helpers so Dashboard's "Matched Scholarships" count mirrors the
// Discovery page's auto-applied Degree filter ("For You" tab).

const INTENDED_TO_DEGREES: Record<string, string[]> = {
  "Diploma / Certificate": ["Diploma", "Certificate", "Associate"],
  "Bachelor's": ["BSC", "Bachelor", "BA", "BEng", "BBA", "Undergraduate"],
  "Master's": ["MSC", "MBA", "Master", "Masters", "MPhil", "MA"],
  "PhD / Doctorate": ["PHD", "Doctorate", "Doctoral"],
  "Postdoctoral": ["Postdoc", "Postdoctoral", "Fellowship"],
  "Exchange / Short Program": ["Exchange", "Short Program"],
};

const NEXT_LEVEL_DEGREES: Record<string, string[]> = {
  "High School / Secondary School": ["BSC", "Bachelor", "BA", "BEng", "BBA"],
  "Undergraduate": ["MSC", "MBA", "Master", "MPhil", "MA"],
  "Postgraduate (Master's / PhD)": ["PHD", "Postdoc", "Fellowship"],
};

const ACADEMIC_TO_DEGREES: Record<string, string[]> = {
  "High School / Secondary School": [
    "High School", "Diploma", "Associate",
    "BSC", "Bachelor", "BA", "BEng", "BBA",
  ],
  "Undergraduate": [
    "BSC", "Bachelor", "BA", "BEng", "BBA",
    "MSC", "MBA", "Master", "MPhil", "MA",
  ],
  "Postgraduate (Master's / PhD)": [
    "MSC", "MBA", "Master", "MPhil", "MA",
    "PHD", "Postdoc", "Fellowship",
  ],
};

/**
 * Returns the lowercased degree tokens that scholarships should match for the
 * user, mirroring Scholarships.tsx auto-filter precedence:
 *   1) intended_degree_level (preferred)
 *   2) next-level after current academic_level
 *   3) academic_level itself
 * Returns null when no personalization is possible (treat as "show all").
 */
export function getPersonalizedDegreeTokens(personalInfo: any): string[] | null {
  const intended = personalInfo?.intended_degree_level || "";
  const userLevel = personalInfo?.academic_level || "";

  const intendedTokens = INTENDED_TO_DEGREES[intended];
  if (intendedTokens?.length) return intendedTokens.map((t) => t.toLowerCase());

  const next = NEXT_LEVEL_DEGREES[userLevel];
  if (next?.length) return next.map((t) => t.toLowerCase());

  const current = ACADEMIC_TO_DEGREES[userLevel];
  if (current?.length) return current.map((t) => t.toLowerCase());

  return null;
}

/**
 * Mirrors the Discovery degreeFilter check: a scholarship matches when its
 * degree_level is empty/"any", or it contains at least one of the user's
 * personalized tokens.
 */
export function scholarshipMatchesDegreeTokens(
  scholarshipDegreeLevel: string | null | undefined,
  tokens: string[] | null,
): boolean {
  if (!tokens || tokens.length === 0) return true;
  const dl = (scholarshipDegreeLevel || "").trim().toLowerCase();
  if (!dl || dl === "any") return true;
  const parts = dl.split(",").map((d) => d.trim());
  return parts.some((p) => tokens.includes(p));
}

/**
 * Mirrors Discovery's auto-applied Field of Study filter. A scholarship passes
 * when its field_of_study is empty/"any" or shares a fuzzy substring match
 * with any of the user's education fields.
 */
export function scholarshipMatchesUserFields(
  scholarshipFieldOfStudy: string | null | undefined,
  userFields: string[],
): boolean {
  if (!userFields || userFields.length === 0) return true;
  const fs = (scholarshipFieldOfStudy || "").trim().toLowerCase();
  if (!fs || fs === "any") return true;
  const parts = fs.split(",").map((f) => f.trim()).filter(Boolean);
  const ufs = userFields.map((u) => u.toLowerCase()).filter(Boolean);
  return parts.some((p) => ufs.some((u) => p.includes(u) || u.includes(p)));
}
