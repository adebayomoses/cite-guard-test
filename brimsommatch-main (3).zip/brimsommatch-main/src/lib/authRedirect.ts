import { Capacitor } from "@capacitor/core";

// On native (Capacitor) builds, `window.location.origin` is `capacitor://localhost`
// or `http://localhost`, which cannot be opened from an email link. Always send
// auth confirmation/reset emails to the published web URL so they open in a
// real browser and complete the flow there.
const WEB_ORIGIN = "https://brimsom.com";

export function getAuthRedirectOrigin(): string {
  if (Capacitor.isNativePlatform()) return WEB_ORIGIN;
  return window.location.origin;
}
