export type PlanId = "free" | "standard" | "pro" | "pro_plus";

export type BillingInterval = "month" | "year";

export const PLAN_TIERS = {
  free: {
    name: "Free",
    price: 0,
    yearlyPrice: 0,
    priceId: null,
    yearlyPriceId: null,
    productId: null,
    yearlyProductId: null,
    limits: {
      brim_chat: { count: 5, period: "total" as const },
      document_review: { count: 1, period: "2month" as const },
      book_session: { count: 0, period: "month" as const },
      score_generation: { count: 5, period: "month" as const },
      scholarship_recommendation: { count: 5, period: "month" as const },
      match_me: { count: 2, period: "month" as const },
    },
  },
  standard: {
    name: "Standard",
    price: 3.99,
    yearlyPrice: 39.9,
    priceId: "price_1TX4GPQZiHaLiahhUccwarJm",
    yearlyPriceId: "price_1TX4HTQZiHaLiahhnUofKCIz",
    productId: "prod_UW6T8aLSSGd2QN",
    yearlyProductId: "prod_UW6UvOYXuFkDBc",
    limits: {
      brim_chat: { count: 10, period: "day" as const },
      document_review: { count: 3, period: "month" as const },
      book_session: { count: 0, period: "month" as const },
      score_generation: { count: 20, period: "month" as const },
      scholarship_recommendation: { count: 20, period: "month" as const },
      match_me: { count: 10, period: "month" as const },
    },
  },
  pro: {
    name: "Pro",
    price: 9.99,
    yearlyPrice: 99.9,
    priceId: "price_1TX4IkQZiHaLiahh4g7sVhBv",
    yearlyPriceId: "price_1TX4JFQZiHaLiahhcKMjWoK6",
    productId: "prod_UW6VwYOuu4zNHl",
    yearlyProductId: "prod_UW6WzCWVuYDh4w",
    limits: {
      brim_chat: { count: Infinity, period: "day" as const },
      document_review: { count: 6, period: "month" as const },
      book_session: { count: 1, period: "month" as const },
      score_generation: { count: Infinity, period: "month" as const },
      scholarship_recommendation: { count: Infinity, period: "month" as const },
      match_me: { count: 50, period: "month" as const },
    },
  },
  pro_plus: {
    name: "Pro+",
    price: 24.99,
    yearlyPrice: 249.9,
    priceId: "price_1TX4K8QZiHaLiahhvT4AUhL9",
    yearlyPriceId: "price_1TX4KxQZiHaLiahhJzAFWtlW",
    productId: "prod_UW6X0WLaZKav0f",
    yearlyProductId: "prod_UW6Y4K2ghiHQ87",
    limits: {
      brim_chat: { count: Infinity, period: "day" as const },
      document_review: { count: 10, period: "month" as const },
      book_session: { count: 3, period: "month" as const },
      score_generation: { count: Infinity, period: "month" as const },
      scholarship_recommendation: { count: Infinity, period: "month" as const },
      match_me: { count: Infinity, period: "month" as const },
    },
  },
} as const;

export type FeatureKey = "brim_chat" | "document_review" | "book_session" | "score_generation" | "scholarship_recommendation" | "match_me";

export function getFeatureLimit(plan: PlanId, feature: FeatureKey) {
  return PLAN_TIERS[plan].limits[feature];
}
