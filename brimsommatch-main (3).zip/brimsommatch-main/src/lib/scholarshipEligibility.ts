/**
 * Client-side eligibility prefilter for the "Explore All" tab.
 * Mirrors the deterministic logic used by the score-profile edge function so
 * users see only scholarships they're realistically eligible to apply for —
 * the same set that gets sent to the AI for full scoring.
 *
 * Hard filters: deadline open, degree level match, GPA above (min - 5%),
 * eligibility text doesn't restrict student out by nationality/residence.
 */

export interface EligibilityProfile {
  academic_level?: string | null;
  nationality?: string | null;
  country_of_residence?: string | null;
}

export interface EligibilityEducation {
  degree_level?: string | null;
  field_of_study?: string | null;
  gpa?: number | string | null;
  gpa_scale?: number | string | null;
}

export interface EligibilityScholarship {
  id: string;
  country?: string | null;
  degree_level?: string | null;
  field_of_study?: string | null;
  eligibility_criteria?: string | null;
  next_close_date?: string | null;
  min_cgpa_percentage?: number | null;
}

export const DEFAULT_GPA_TOLERANCE_PCT = 5;

function getStudentMaxGpaPercent(education: EligibilityEducation[]): number | null {
  let best: number | null = null;
  for (const e of education) {
    const gpa = e.gpa != null ? Number(e.gpa) : NaN;
    const scale = e.gpa_scale != null ? Number(e.gpa_scale) : NaN;
    if (!isNaN(gpa) && !isNaN(scale) && scale > 0) {
      const pct = (gpa / scale) * 100;
      if (best == null || pct > best) best = pct;
    }
  }
  return best;
}

function getStudentDegreeLevels(profile: EligibilityProfile, education: EligibilityEducation[]): Set<string> {
  const set = new Set<string>();
  if (profile?.academic_level) set.add(String(profile.academic_level).toLowerCase());
  for (const e of education) {
    if (e.degree_level) set.add(String(e.degree_level).toLowerCase());
  }
  return set;
}

function eligibleTargetDegrees(studentLevels: Set<string>): Set<string> {
  const targets = new Set<string>();
  for (const lvl of studentLevels) {
    const l = lvl.toLowerCase();
    targets.add(l);
    if (l.includes("high school") || l.includes("secondary")) {
      targets.add("bachelor"); targets.add("undergraduate"); targets.add("bachelors");
      targets.add("bsc"); targets.add("ba"); targets.add("beng"); targets.add("bba");
      targets.add("diploma"); targets.add("associate");
    }
    if (l.includes("bachelor") || l.includes("undergrad")) {
      targets.add("master"); targets.add("masters"); targets.add("graduate"); targets.add("postgraduate");
      targets.add("msc"); targets.add("mba"); targets.add("ma"); targets.add("mphil");
    }
    if (l.includes("master") || l.includes("postgrad")) {
      targets.add("phd"); targets.add("doctorate"); targets.add("doctoral");
      targets.add("postdoc"); targets.add("fellowship");
    }
  }
  return targets;
}

function degreeMatches(scholarshipDegree: string | null | undefined, targets: Set<string>): boolean {
  if (!scholarshipDegree) return true; // "Any" is inclusive
  const sd = scholarshipDegree.toLowerCase().trim();
  if (!sd || sd === "any" || sd === "all") return true;
  const parts = sd.split(/[,;/]/).map(p => p.trim()).filter(Boolean);
  if (parts.length === 0) return true;
  for (const part of parts) {
    if (part.includes("any") || part.includes("all")) return true;
    for (const t of targets) {
      if (!t) continue;
      if (part.includes(t) || t.includes(part)) return true;
    }
  }
  return false;
}

function countryEligible(
  eligibility: string | null | undefined,
  studentNationality: string | null | undefined,
  studentResidence: string | null | undefined,
): boolean {
  if (!eligibility) return true;
  const elig = eligibility.toLowerCase();
  const nat = (studentNationality ?? "").toLowerCase();
  const res = (studentResidence ?? "").toLowerCase();

  const restrictPatterns = [
    /only\s+(?:for\s+)?([a-z\s,]+?)(?:\s+citizens|\s+nationals|\s+residents)/i,
    /must\s+be\s+a\s+(?:citizen|national|resident)\s+of\s+([a-z\s,]+?)(?:\.|,|$)/i,
    /restricted\s+to\s+([a-z\s,]+?)(?:\s+citizens|\s+nationals)/i,
  ];
  for (const pat of restrictPatterns) {
    const m = elig.match(pat);
    if (m && m[1]) {
      const allowed = m[1].toLowerCase();
      if (nat && allowed.includes(nat)) return true;
      if (res && allowed.includes(res)) return true;
      return false;
    }
  }
  return true;
}

function deadlineOpen(deadline: string | null | undefined): boolean {
  if (!deadline) return true;
  const d = new Date(deadline);
  if (isNaN(d.getTime())) return true;
  return d.getTime() >= Date.now();
}

function gpaMeetsMin(scholarshipMinPct: number | null | undefined, studentMaxPct: number | null, tolerance: number): boolean {
  if (scholarshipMinPct == null) return true;
  if (studentMaxPct == null) return true; // Don't exclude if no GPA on file
  return studentMaxPct + tolerance >= scholarshipMinPct; // soft cutoff
}

/**
 * Returns true when the user's profile is rich enough to run a meaningful
 * eligibility filter. If false, callers should fall back to showing all
 * scholarships rather than producing a near-empty list.
 */
export function hasEnoughProfileForEligibility(
  profile: EligibilityProfile | null | undefined,
  education: EligibilityEducation[] | null | undefined,
): boolean {
  if (!profile && (!education || education.length === 0)) return false;
  const hasDegree = !!profile?.academic_level || (education ?? []).some(e => !!e.degree_level);
  const hasLocation = !!profile?.nationality || !!profile?.country_of_residence;
  return hasDegree || hasLocation;
}

/**
 * Apply the deterministic eligibility prefilter to a list of scholarships.
 * Returns the eligible subset in the original order.
 *
 * @param gpaTolerancePct admin-configurable soft cutoff (default 5%)
 */
export function filterEligibleScholarships<T extends EligibilityScholarship>(
  scholarships: T[],
  profile: EligibilityProfile | null | undefined,
  education: EligibilityEducation[] | null | undefined,
  gpaTolerancePct: number = DEFAULT_GPA_TOLERANCE_PCT,
): T[] {
  const safeProfile = profile ?? {};
  const safeEducation = education ?? [];
  const studentDegrees = getStudentDegreeLevels(safeProfile, safeEducation);
  const targets = eligibleTargetDegrees(studentDegrees);
  const studentMaxGpa = getStudentMaxGpaPercent(safeEducation);

  return scholarships.filter((s) => {
    if (!deadlineOpen(s.next_close_date)) return false;
    if (!degreeMatches(s.degree_level, targets)) return false;
    if (!gpaMeetsMin(s.min_cgpa_percentage, studentMaxGpa, gpaTolerancePct)) return false;
    if (!countryEligible(s.eligibility_criteria, safeProfile.nationality, safeProfile.country_of_residence)) return false;
    return true;
  });
}
