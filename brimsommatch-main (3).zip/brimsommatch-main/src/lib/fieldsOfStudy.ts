export const FIELD_OF_STUDY_OPTIONS = [
  "Engineering",
  "Computer Science & IT",
  "Mathematics & Statistics",
  "Physical Sciences",
  "Life Sciences & Biology",
  "Medicine & Health Sciences",
  "Nursing & Pharmacy",
  "Business & Management",
  "Economics & Finance",
  "Law",
  "Social Sciences",
  "Education",
  "Arts & Design",
  "Humanities & Literature",
  "Languages & Linguistics",
  "Agriculture & Environmental Science",
  "Public Health",
  "Any / All Fields",
] as const;

export type FieldOfStudy = typeof FIELD_OF_STUDY_OPTIONS[number];
