export const DEFAULT_APPLY_STEPS = `1. **Read the Scholarship Details** — Review the description, eligibility criteria, and requirements above.
2. **Prepare Required Documents** — Gather transcripts, recommendation letters, essays, and any other required materials.
3. **Create an Account** — Visit the scholarship provider's website and register for an account if required.
4. **Log In & Start Application** — Sign in to the application portal and begin filling out the form.
5. **Complete All Sections** — Fill in personal details, academic history, and any essay prompts carefully.
6. **Review & Submit** — Double-check all information, attach required documents, and submit before the deadline.`;
