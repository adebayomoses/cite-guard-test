import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import PageTransition from "@/components/PageTransition";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import AdminRoute from "@/components/AdminRoute";
import PWAInstallBanner from "@/components/PWAInstallBanner";
import { Skeleton } from "@/components/ui/skeleton";
import { useNativePushNotifications } from "@/hooks/useNativePushNotifications";

function NativePushRegistrar() {
  useNativePushNotifications();
  return null;
}

// Lazy-load all page components for code splitting
const Landing = lazy(() => import("./pages/Landing"));
const Auth = lazy(() => import("./pages/Auth"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Admin = lazy(() => import("./pages/Admin"));
const Profile = lazy(() => import("./pages/Profile"));
const Scholarships = lazy(() => import("./pages/Scholarships"));
const Community = lazy(() => import("./pages/Community"));
const Saved = lazy(() => import("./pages/Saved"));
const Score = lazy(() => import("./pages/Score"));
const Pathways = lazy(() => import("./pages/Pathways"));
const Resources = lazy(() => import("./pages/Resources"));
const BookSession = lazy(() => import("./pages/BookSession"));
const Loans = lazy(() => import("./pages/Loans"));
const DocumentReview = lazy(() => import("./pages/DocumentReview"));
const BrimChat = lazy(() => import("./pages/BrimChat"));
const Tracker = lazy(() => import("./pages/Tracker"));
const NotFound = lazy(() => import("./pages/NotFound"));
const InfoSources = lazy(() => import("./pages/InfoSources"));
const Blog = lazy(() => import("./pages/Blog"));
const BlogPost = lazy(() => import("./pages/BlogPost"));
const Downloads = lazy(() => import("./pages/Downloads"));
const Privacy = lazy(() => import("./pages/Privacy"));
const About = lazy(() => import("./pages/About"));
const Support = lazy(() => import("./pages/Support"));
const FAQs = lazy(() => import("./pages/FAQs"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const ScholarshipWinner = lazy(() => import("./pages/ScholarshipWinner"));
const Pricing = lazy(() => import("./pages/Pricing"));
const Advisor = lazy(() => import("./pages/Advisor"));
const SharedAdvisor = lazy(() => import("./pages/SharedAdvisor"));
const ScholarshipDetail = lazy(() => import("./pages/ScholarshipDetail"));
const Careers = lazy(() => import("./pages/Careers"));
const Unsubscribe = lazy(() => import("./pages/Unsubscribe"));
const MatchHistory = lazy(() => import("./pages/MatchHistory"));
const ChallengeList = lazy(() => import("./pages/ChallengeList"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="space-y-4 w-full max-w-md px-4">
        <Skeleton className="h-8 w-3/4 mx-auto" />
        <Skeleton className="h-4 w-1/2 mx-auto" />
        <Skeleton className="h-32 w-full rounded-xl" />
      </div>
    </div>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <Suspense fallback={<PageLoader />}>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageTransition><Landing /></PageTransition>} />
          <Route path="/auth" element={<PageTransition><Auth /></PageTransition>} />
          <Route path="/reset-password" element={<PageTransition><ResetPassword /></PageTransition>} />
          <Route path="/blog" element={<PageTransition><Blog /></PageTransition>} />
          <Route path="/blog/:slug" element={<PageTransition><BlogPost /></PageTransition>} />
          <Route path="/downloads" element={<PageTransition><Downloads /></PageTransition>} />
          <Route path="/privacy" element={<PageTransition><Privacy /></PageTransition>} />
          <Route path="/about" element={<PageTransition><About /></PageTransition>} />
          <Route path="/support" element={<PageTransition><Support /></PageTransition>} />
          <Route path="/careers" element={<PageTransition><Careers /></PageTransition>} />
          <Route path="/unsubscribe" element={<PageTransition><Unsubscribe /></PageTransition>} />
          <Route path="/shared/advisor/:token" element={<PageTransition><SharedAdvisor /></PageTransition>} />
          <Route path="/dashboard" element={<ProtectedRoute><PageTransition><Dashboard /></PageTransition></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><PageTransition><Profile /></PageTransition></ProtectedRoute>} />
          <Route path="/admin" element={<AdminRoute><PageTransition><Admin /></PageTransition></AdminRoute>} />
          <Route path="/admin/scholarship-winner/:id?" element={<AdminRoute><ScholarshipWinner /></AdminRoute>} />
          <Route path="/scholarships" element={<ProtectedRoute><PageTransition><Scholarships /></PageTransition></ProtectedRoute>} />
          <Route path="/scholarships/:id" element={<ProtectedRoute><PageTransition><ScholarshipDetail /></PageTransition></ProtectedRoute>} />
          <Route path="/saved" element={<ProtectedRoute><PageTransition><Saved /></PageTransition></ProtectedRoute>} />
          <Route path="/score" element={<ProtectedRoute><PageTransition><Score /></PageTransition></ProtectedRoute>} />
          <Route path="/community" element={<ProtectedRoute><PageTransition><Community /></PageTransition></ProtectedRoute>} />
          <Route path="/pathways" element={<ProtectedRoute><PageTransition><Pathways /></PageTransition></ProtectedRoute>} />
          <Route path="/resources" element={<ProtectedRoute><PageTransition><Resources /></PageTransition></ProtectedRoute>} />
          <Route path="/book-session" element={<ProtectedRoute><PageTransition><BookSession /></PageTransition></ProtectedRoute>} />
          <Route path="/loans" element={<ProtectedRoute><PageTransition><Loans /></PageTransition></ProtectedRoute>} />
          <Route path="/document_review" element={<ProtectedRoute><PageTransition><DocumentReview /></PageTransition></ProtectedRoute>} />
          <Route path="/brim-chat" element={<ProtectedRoute><PageTransition><BrimChat /></PageTransition></ProtectedRoute>} />
          <Route path="/brim-ai-chat" element={<ProtectedRoute><Advisor /></ProtectedRoute>} />
          <Route path="/match-history" element={<ProtectedRoute><PageTransition><MatchHistory /></PageTransition></ProtectedRoute>} />
          <Route path="/advisor" element={<Navigate to="/brim-ai-chat" replace />} />
          <Route path="/pricing" element={<ProtectedRoute><PageTransition><Pricing /></PageTransition></ProtectedRoute>} />
          <Route path="/tracker" element={<ProtectedRoute><PageTransition><Tracker /></PageTransition></ProtectedRoute>} />
          <Route path="/challenge-list" element={<ProtectedRoute><PageTransition><ChallengeList /></PageTransition></ProtectedRoute>} />
          <Route path="/faqs" element={<ProtectedRoute><PageTransition><FAQs /></PageTransition></ProtectedRoute>} />
          <Route path="/info-sources" element={<AdminRoute><PageTransition><InfoSources /></PageTransition></AdminRoute>} />
          <Route path="*" element={<PageTransition><NotFound /></PageTransition>} />
        </Routes>
      </AnimatePresence>
    </Suspense>
  );
}

const App = () => (
  <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <NativePushRegistrar />
            <AnimatedRoutes />
            <PWAInstallBanner />
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
