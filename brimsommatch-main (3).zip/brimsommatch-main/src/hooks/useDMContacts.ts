import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type DMContact = {
  userId: string;
  userName: string;
  lastMessage: string;
  lastMessageAt: string;
};

export function useDMContacts() {
  const [contacts, setContacts] = useState<DMContact[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchContacts = async () => {
    if (!user) return;
    setLoading(true);

    const { data } = await supabase
      .from("direct_messages")
      .select("*")
      .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
      .order("created_at", { ascending: false });

    if (!data) {
      setLoading(false);
      return;
    }

    const contactMap = new Map<string, DMContact>();
    for (const msg of data) {
      const otherUserId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
      if (!contactMap.has(otherUserId)) {
        const otherName =
          msg.sender_id !== user.id
            ? msg.sender_name
            : "";
        contactMap.set(otherUserId, {
          userId: otherUserId,
          userName: otherName,
          lastMessage: msg.content,
          lastMessageAt: msg.created_at,
        });
      }
    }

    // Fill in missing names from profiles via secure RPC
    const missingIds = Array.from(contactMap.values())
      .filter((c) => !c.userName)
      .map((c) => c.userId);
    if (missingIds.length > 0) {
      const { data: profiles } = await supabase.rpc("get_user_display_names", {
        user_ids: missingIds,
      });
      (profiles as { user_id: string; full_name: string | null }[] | null)?.forEach((p) => {
        const c = contactMap.get(p.user_id);
        if (c) c.userName = p.full_name || p.user_id.slice(0, 8);
      });
      // Fallback for any still missing
      contactMap.forEach((c) => {
        if (!c.userName) c.userName = c.userId.slice(0, 8);
      });
    }



    setContacts(Array.from(contactMap.values()));
    setLoading(false);
  };

  useEffect(() => {
    fetchContacts();

    if (!user) return;
    const channel = supabase
      .channel("dm-contacts")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "direct_messages" },
        () => fetchContacts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  return { contacts, loading };
}
