import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

// Extend ServiceWorkerRegistration to include pushManager
declare global {
  interface ServiceWorkerRegistration {
    pushManager: PushManager;
  }
}

// This will be set from the VAPID_PUBLIC_KEY secret via the edge function,
// but since the public key is safe to expose, we fetch it once or use a known value.
// We'll fetch it from an edge function endpoint for flexibility.

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function usePushNotifications() {
  const { user } = useAuth();
  const [permission, setPermission] = useState<NotificationPermission>(
    typeof Notification !== "undefined" ? Notification.permission : "default"
  );
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [supported] = useState(
    typeof window !== "undefined" && "serviceWorker" in navigator && "PushManager" in window
  );

  // Check existing subscription on mount
  useEffect(() => {
    if (!supported || !user) return;
    (async () => {
      try {
        const reg = await navigator.serviceWorker.ready;
        const sub = await reg.pushManager.getSubscription();
        if (sub) {
          // Check if it's in our DB
          const { data } = await supabase
            .from("push_subscriptions" as any)
            .select("id")
            .eq("user_id", user.id)
            .eq("endpoint", sub.endpoint)
            .maybeSingle();
          setIsSubscribed(!!data);
        }
      } catch {
        // ignore
      }
    })();
  }, [supported, user]);

  const subscribe = useCallback(async () => {
    if (!supported || !user) {
      console.warn("Push not supported or no user");
      return false;
    }
    setLoading(true);
    try {
      // Check if we're on iOS and not in standalone (installed) mode
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const isStandalone = window.matchMedia("(display-mode: standalone)").matches
        || (navigator as any).standalone === true;
      if (isIOS && !isStandalone) {
        setLoading(false);
        setErrorMessage("On iPhone, push notifications only work after installing the app to your home screen. Tap Share → Add to Home Screen, then try again.");
        return false;
      }

      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== "granted") {
        setLoading(false);
        setErrorMessage("Notification permission was denied. Please allow notifications in your browser settings.");
        return false;
      }

      // Fetch VAPID public key from edge function
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/send-push-notification`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "get-vapid-key" }),
        }
      );
      const { vapidPublicKey } = await res.json();
      if (!vapidPublicKey) throw new Error("Could not get VAPID key from server");

      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublicKey) as any,
      });

      const subJson = sub.toJSON();
      const { error } = await supabase.from("push_subscriptions" as any).insert({
        user_id: user.id,
        endpoint: sub.endpoint,
        p256dh: subJson.keys?.p256dh ?? "",
        auth: subJson.keys?.auth ?? "",
      } as any);

      if (error) throw error;
      setIsSubscribed(true);
      setErrorMessage(null);
      setLoading(false);
      return true;
    } catch (e: any) {
      console.error("Push subscribe error:", e);
      setErrorMessage(e?.message || "Failed to enable push notifications");
      setLoading(false);
      return false;
    }
  }, [supported, user]);

  const unsubscribe = useCallback(async () => {
    if (!supported || !user) return;
    setLoading(true);
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await supabase
          .from("push_subscriptions" as any)
          .delete()
          .eq("user_id", user.id)
          .eq("endpoint", sub.endpoint);
        await sub.unsubscribe();
      }
      setIsSubscribed(false);
    } catch (e) {
      console.error("Push unsubscribe error:", e);
    }
    setLoading(false);
  }, [supported, user]);

  return { supported, permission, isSubscribed, loading, errorMessage, subscribe, unsubscribe };
}
