import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

export function useAdminRole() {
  const { user } = useAuth();

  const { data: roles = { isAdmin: false, isModerator: false }, isLoading: loading } = useQuery({
    queryKey: ["admin-role", user?.id],
    queryFn: async () => {
      if (!user) return { isAdmin: false, isModerator: false };
      const [adminRes, modRes] = await Promise.all([
        supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }),
        supabase.rpc("has_role", { _user_id: user.id, _role: "moderator" }),
      ]);
      return {
        isAdmin: adminRes.data ?? false,
        isModerator: modRes.data ?? false,
      };
    },
    enabled: !!user,
  });

  return { isAdmin: roles.isAdmin, isModerator: roles.isModerator, loading };
}
