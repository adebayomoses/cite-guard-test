import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppDownload = {
  id: string;
  platform: string;
  file_url: string | null;
  file_name: string | null;
  version: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export function useAppDownloads(adminMode = false) {
  const queryClient = useQueryClient();

  const { data: downloads = [], isLoading } = useQuery({
    queryKey: ["app-downloads", adminMode],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("app_downloads")
        .select("*")
        .order("platform");
      if (error) throw error;
      return data as AppDownload[];
    },
  });

  const upsertDownload = useMutation({
    mutationFn: async (values: { platform: string; file_url?: string | null; file_name?: string | null; version?: string | null; is_active?: boolean }) => {
      const existing = downloads.find((d) => d.platform === values.platform);
      if (existing) {
        const { error } = await (supabase as any)
          .from("app_downloads")
          .update({ ...values, updated_at: new Date().toISOString() })
          .eq("id", existing.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase as any)
          .from("app_downloads")
          .insert(values);
        if (error) throw error;
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["app-downloads"] }),
  });

  const uploadFile = useMutation({
    mutationFn: async ({ platform, file }: { platform: string; file: File }) => {
      const ext = file.name.split(".").pop();
      const path = `${platform}/${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from("app-downloads")
        .upload(path, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data } = supabase.storage.from("app-downloads").getPublicUrl(path);
      return { url: data.publicUrl, fileName: file.name };
    },
  });

  return { downloads, isLoading, upsertDownload, uploadFile };
}
