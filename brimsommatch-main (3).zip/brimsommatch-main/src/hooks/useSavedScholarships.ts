import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export function useSavedScholarships() {
  const { user } = useAuth();
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [savedScholarships, setSavedScholarships] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchSaved();
  }, [user]);

  async function fetchSaved() {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("saved_scholarships")
      .select("scholarship_id, created_at, scholarships(*)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }) as any;

    const items = data ?? [];
    setSavedIds(new Set(items.map((d: any) => d.scholarship_id)));
    setSavedScholarships(items.map((d: any) => ({ ...d.scholarships, saved_at: d.created_at })));
    setLoading(false);
  }

  const toggleSave = useCallback(async (scholarshipId: string, logActivity?: (action: string, detail?: string) => Promise<void>) => {
    if (!user) return;
    const isSaved = savedIds.has(scholarshipId);

    if (isSaved) {
      await supabase
        .from("saved_scholarships")
        .delete()
        .eq("user_id", user.id)
        .eq("scholarship_id", scholarshipId);
      setSavedIds((prev) => { const n = new Set(prev); n.delete(scholarshipId); return n; });
      setSavedScholarships((prev) => prev.filter((s) => s.id !== scholarshipId));
      toast.success("Scholarship unsaved");
    } else {
      await supabase.from("saved_scholarships").insert({
        user_id: user.id,
        scholarship_id: scholarshipId,
      } as any);
      setSavedIds((prev) => new Set(prev).add(scholarshipId));
      logActivity?.("Bookmarked Scholarship", scholarshipId);
      toast.success("Scholarship saved!");
    }
  }, [user, savedIds]);

  return { savedIds, savedScholarships, loading, toggleSave, refetch: fetchSaved };
}
