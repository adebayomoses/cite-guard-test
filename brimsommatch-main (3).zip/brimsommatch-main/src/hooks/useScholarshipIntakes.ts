import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type IntakeTerm = "general" | "fall" | "spring" | "summer" | "winter" | "custom";

export interface ScholarshipIntake {
  id?: string;
  scholarship_id?: string;
  term: IntakeTerm;
  custom_label?: string | null;
  open_date?: string | null;
  close_date?: string | null;
  sort_order?: number;
}

export const TERM_ORDER: IntakeTerm[] = ["general", "fall", "spring", "summer", "winter", "custom"];

export function termLabel(intake: Pick<ScholarshipIntake, "term" | "custom_label">) {
  if (intake.term === "custom") return intake.custom_label?.trim() || "Custom intake";
  if (intake.term === "general") return "General";
  return intake.term.charAt(0).toUpperCase() + intake.term.slice(1);
}

// `effectiveDeadline()` was removed — the soonest upcoming intake close date is
// now maintained on `scholarships.next_close_date` by a database trigger.

/** Fetch intakes for many scholarships at once, grouped by scholarship_id. */
export function useScholarshipIntakesMap(scholarshipIds: string[]) {
  const [map, setMap] = useState<Record<string, ScholarshipIntake[]>>({});
  const [loading, setLoading] = useState(false);
  const key = scholarshipIds.slice().sort().join(",");

  useEffect(() => {
    if (!scholarshipIds.length) { setMap({}); return; }
    let cancelled = false;
    setLoading(true);
    (supabase as any)
      .from("scholarship_intakes")
      .select("*")
      .in("scholarship_id", scholarshipIds)
      .order("close_date", { ascending: true })
      .then(({ data }: any) => {
        if (cancelled) return;
        const grouped: Record<string, ScholarshipIntake[]> = {};
        (data ?? []).forEach((r: ScholarshipIntake) => {
          const id = r.scholarship_id!;
          (grouped[id] ||= []).push(r);
        });
        setMap(grouped);
        setLoading(false);
      });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return { intakesMap: map, loading };
}

/** Fetch intakes for a single scholarship. Returns empty array while loading. */
export function useScholarshipIntakes(scholarshipId?: string | null) {
  const [intakes, setIntakes] = useState<ScholarshipIntake[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!scholarshipId) { setIntakes([]); return; }
    let cancelled = false;
    setLoading(true);
    (supabase as any)
      .from("scholarship_intakes")
      .select("*")
      .eq("scholarship_id", scholarshipId)
      .order("sort_order", { ascending: true })
      .then(({ data }: any) => {
        if (cancelled) return;
        setIntakes((data ?? []) as ScholarshipIntake[]);
        setLoading(false);
      });
    return () => { cancelled = true; };
  }, [scholarshipId]);

  return { intakes, loading };
}
