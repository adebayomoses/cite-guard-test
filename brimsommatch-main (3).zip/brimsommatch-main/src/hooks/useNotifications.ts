import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect } from "react";

export interface AppNotification {
  id: string;
  user_id: string | null;
  title: string;
  body: string | null;
  url: string;
  is_read: boolean;
  created_at: string;
}

export function useNotifications() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["notifications", user?.id],
    enabled: !!user,
    queryFn: async () => {
      if (!user) return [];
      // Only show notifications created at or after the user signed up,
      // so brand-new users don't see pre-existing broadcast notifications.
      const signupAt = user.created_at ?? new Date(0).toISOString();
      const { data, error } = await supabase
        .from("notifications" as any)
        .select("*")
        .or(`user_id.eq.${user.id},user_id.is.null`)
        .gte("created_at", signupAt)
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return (data ?? []) as unknown as AppNotification[];
    },
  });

  // Subscribe to realtime notifications
  useEffect(() => {
    if (!user) return;
    const invalidate = () =>
      queryClient.invalidateQueries({ queryKey: ["notifications", user.id] });

    const channel = supabase
      .channel(`notifications-realtime-${user.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        invalidate
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=is.null` },
        invalidate
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const markAsRead = useMutation({
    mutationFn: async (id: string) => {
      await supabase
        .from("notifications" as any)
        .update({ is_read: true } as any)
        .eq("id", id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications", user?.id] });
    },
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      const unreadIds = notifications.filter((n) => !n.is_read).map((n) => n.id);
      if (unreadIds.length === 0) return;
      await supabase
        .from("notifications" as any)
        .update({ is_read: true } as any)
        .in("id", unreadIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notifications", user?.id] });
    },
  });

  return { notifications, unreadCount, isLoading, markAsRead, markAllAsRead };
}
