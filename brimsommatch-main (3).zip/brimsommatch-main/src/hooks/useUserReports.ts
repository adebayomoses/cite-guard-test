import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export interface UserReport {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  reported_message_id: string | null;
  room_id: string | null;
  reason: string;
  details: string | null;
  status: string;
  reviewed_by: string | null;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
}

export function useUserReports() {
  const { user } = useAuth();
  const qc = useQueryClient();

  const submitReport = useMutation({
    mutationFn: async (report: {
      reported_user_id: string;
      reported_message_id?: string;
      room_id?: string;
      reason: string;
      details?: string;
    }) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await supabase.from("user_reports" as any).insert({
        reporter_id: user.id,
        reported_user_id: report.reported_user_id,
        reported_message_id: report.reported_message_id ?? null,
        room_id: report.room_id ?? null,
        reason: report.reason,
        details: report.details ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Report submitted. Our team will review it.");
      qc.invalidateQueries({ queryKey: ["user-reports"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return { submitReport };
}

export function useAdminReports() {
  const qc = useQueryClient();

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ["user-reports", "admin"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("user_reports")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as UserReport[];
    },
  });

  const updateReport = useMutation({
    mutationFn: async (update: { id: string; status: string; admin_notes?: string; reviewed_by?: string }) => {
      const { error } = await supabase
        .from("user_reports" as any)
        .update({
          status: update.status,
          admin_notes: update.admin_notes ?? null,
          reviewed_by: update.reviewed_by ?? null,
          updated_at: new Date().toISOString(),
        })
        .eq("id", update.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Report updated");
      qc.invalidateQueries({ queryKey: ["user-reports"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteReport = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("user_reports" as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Report deleted");
      qc.invalidateQueries({ queryKey: ["user-reports"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return { reports, isLoading, updateReport, deleteReport };
}
