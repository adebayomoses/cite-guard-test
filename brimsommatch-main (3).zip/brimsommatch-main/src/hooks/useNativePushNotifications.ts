import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

/**
 * Registers the device with FCM/APNs via Capacitor Push Notifications
 * and saves the token to the `device_tokens` table for server-side fan-out.
 * Runs only on native iOS/Android. On web it is a no-op (Web Push handles it).
 */
export function useNativePushNotifications() {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    let cleanup: (() => void) | undefined;

    (async () => {
      try {
        const { Capacitor } = await import("@capacitor/core");
        if (!Capacitor.isNativePlatform()) return;

        const { PushNotifications } = await import("@capacitor/push-notifications");
        const platform = Capacitor.getPlatform() as "ios" | "android";

        // Request permission
        let perm = await PushNotifications.checkPermissions();
        if (perm.receive === "prompt" || perm.receive === "prompt-with-rationale") {
          perm = await PushNotifications.requestPermissions();
        }
        if (perm.receive !== "granted") {
          console.warn("Push permission not granted");
          return;
        }

        // Create a high-importance Android channel so notifications show in the tray with sound
        if (platform === "android") {
          try {
            await PushNotifications.createChannel({
              id: "brimsom_default",
              name: "Brimsom Notifications",
              description: "Scholarship alerts and updates",
              importance: 5, // IMPORTANCE_HIGH – heads-up + tray
              visibility: 1,
              sound: "default",
              lights: true,
              vibration: true,
            });
          } catch (e) {
            console.warn("createChannel failed:", e);
          }
        }

        // Register with FCM (Android) / APNs (iOS)
        await PushNotifications.register();

        const regListener = await PushNotifications.addListener(
          "registration",
          async (tokenRes: { value: string }) => {
            const token = tokenRes.value;
            console.log("Native push token:", token);
            try {
              await supabase.from("device_tokens" as any).upsert(
                {
                  user_id: user.id,
                  token,
                  platform,
                  app_id: "com.brimsom.app",
                  updated_at: new Date().toISOString(),
                } as any,
                { onConflict: "user_id,token" }
              );
            } catch (e) {
              console.error("Failed to save device token:", e);
            }
          }
        );

        const errListener = await PushNotifications.addListener(
          "registrationError",
          (err: any) => console.error("Push registration error:", err)
        );

        const recvListener = await PushNotifications.addListener(
          "pushNotificationReceived",
          (n: any) => console.log("Push received in foreground:", n)
        );

        const actionListener = await PushNotifications.addListener(
          "pushNotificationActionPerformed",
          (action: any) => {
            const url = action?.notification?.data?.url;
            if (url && typeof url === "string") {
              window.location.assign(url);
            }
          }
        );

        cleanup = () => {
          regListener.remove();
          errListener.remove();
          recvListener.remove();
          actionListener.remove();
        };
      } catch (e) {
        console.error("Native push init failed:", e);
      }
    })();

    return () => {
      cleanup?.();
    };
  }, [user]);
}
