import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type SimilarScholarship = {
  id: string;
  title: string;
  provider: string | null;
  country: string | null;
  status: string | null;
  is_active: boolean;
  created_at: string;
  similarity_score: number;
  provider_match: boolean;
};

/**
 * Debounced check for likely duplicates of a scholarship by fuzzy title match.
 * Returns matches with >= 0.45 trigram similarity, excluding the record being edited.
 */
export function useDuplicateScholarshipCheck(
  title: string,
  provider: string,
  country: string,
  excludeId?: string | null,
) {
  const [matches, setMatches] = useState<SimilarScholarship[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const trimmed = (title || "").trim();
    if (trimmed.length < 5) {
      setMatches([]);
      return;
    }
    const handle = setTimeout(async () => {
      setLoading(true);
      const { data, error } = await supabase.rpc("find_similar_scholarships", {
        query_title: trimmed,
        query_provider: provider?.trim() || null,
        query_country: country?.trim() || null,
        exclude_id: excludeId || null,
        similarity_threshold: 0.45,
        max_results: 5,
      });
      if (!error && data) setMatches(data as SimilarScholarship[]);
      setLoading(false);
    }, 500);
    return () => clearTimeout(handle);
  }, [title, provider, country, excludeId]);

  return { matches, loading };
}
