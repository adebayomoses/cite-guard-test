import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export type ApprovalTeamMember = {
  user_id: string;
  full_name: string | null;
  is_admin: boolean;
};

/** Fetches the current approval team (admins + moderators chosen to receive scholarships for review). */
export function useApprovalTeam() {
  return useQuery({
    queryKey: ["approval-team"],
    queryFn: async (): Promise<ApprovalTeamMember[]> => {
      const { data: rows, error } = await supabase
        .from("approval_team_members" as any)
        .select("user_id");
      if (error) throw error;
      const ids = (rows ?? []).map((r: any) => r.user_id);
      if (ids.length === 0) return [];

      const [{ data: profiles }, { data: admins }] = await Promise.all([
        supabase.from("profiles").select("user_id, full_name").in("user_id", ids),
        supabase.from("user_roles").select("user_id").eq("role", "admin").in("user_id", ids),
      ]);

      const adminSet = new Set((admins ?? []).map((a: any) => a.user_id));
      return ids.map((id) => {
        const p: any = (profiles ?? []).find((x: any) => x.user_id === id);
        return {
          user_id: id,
          full_name: p?.full_name ?? null,
          is_admin: adminSet.has(id),
        };
      }).sort((a, b) => Number(b.is_admin) - Number(a.is_admin));
    },
  });
}

/** Add or remove a user from the approval team (admin only). */
export function useApprovalTeamMutations() {
  const qc = useQueryClient();
  const { user } = useAuth();

  const add = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase
        .from("approval_team_members" as any)
        .insert({ user_id: userId, added_by: user?.id });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["approval-team"] });
      qc.invalidateQueries({ queryKey: ["scholarship-reviewers"] });
      toast({ title: "Added to approval team" });
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const remove = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase
        .from("approval_team_members" as any)
        .delete()
        .eq("user_id", userId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["approval-team"] });
      qc.invalidateQueries({ queryKey: ["scholarship-reviewers"] });
      toast({ title: "Removed from approval team" });
    },
    onError: (e: Error) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  return { add, remove };
}
