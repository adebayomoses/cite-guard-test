import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type ChatMessage = {
  id: string;
  room_id: string;
  user_id: string;
  user_name: string;
  content: string;
  created_at: string;
  image_url?: string | null;
};

export function useChatMessages(roomId: string | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  useEffect(() => {
    if (!roomId) return;
    setLoading(true);

    supabase
      .from("chat_messages")
      .select("*")
      .eq("room_id", roomId)
      .order("created_at")
      .then(({ data }) => {
        setMessages(data ?? []);
        setLoading(false);
      });

    const channel = supabase
      .channel(`chat-${roomId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "chat_messages",
          filter: `room_id=eq.${roomId}`,
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            setMessages((prev) => [...prev, payload.new as ChatMessage]);
          } else if (payload.eventType === "DELETE") {
            setMessages((prev) => prev.filter((m) => m.id !== (payload.old as any).id));
          }
        }
      )
      .subscribe();

    channelRef.current = channel;

    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId]);

  const sendMessage = useCallback(
    async (content: string, imageFile?: File) => {
      if (!roomId || !user) return;

      let imageUrl: string | null = null;

      if (imageFile) {
        const filePath = `${user.id}/${Date.now()}-${imageFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from("chat-images")
          .upload(filePath, imageFile);
        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from("chat-images")
            .getPublicUrl(filePath);
          imageUrl = urlData.publicUrl;
        }
      }

      const userName =
        user.user_metadata?.full_name || user.email?.split("@")[0] || "User";
      const { error: insertError } = await supabase.from("chat_messages").insert({
        room_id: roomId,
        user_id: user.id,
        user_name: userName,
        content,
        image_url: imageUrl,
      });

      if (!insertError) {
        // Fire-and-forget notification to other room members
        const { data: roomRow } = await supabase
          .from("chat_rooms")
          .select("name")
          .eq("id", roomId)
          .maybeSingle();
        const roomName = roomRow?.name ?? "Group chat";
        const preview = content || (imageUrl ? "📷 Photo" : "");
        supabase.functions
          .invoke("send-push-notification", {
            body: {
              action: "chat-room",
              room_id: roomId,
              room_name: roomName,
              sender_name: userName,
              content_preview: preview,
              title: roomName,
              body: `${userName}: ${preview}`.slice(0, 180),
              url: `/community?room=${roomId}`,
              skip_inapp: true,
            },
          })
          .catch(() => {});

      }
    },
    [roomId, user]
  );

  const deleteMessage = useCallback(
    async (messageId: string) => {
      await supabase.from("chat_messages").delete().eq("id", messageId);
    },
    []
  );

  return { messages, loading, sendMessage, deleteMessage };
}
