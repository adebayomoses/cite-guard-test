import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Counts scholarships that have not yet been manually reviewed
 * (reviewed_at IS NULL). Used for the "Old Review" tab badge.
 */
export function useOldReviewCount() {
  const { data: count = 0 } = useQuery({
    queryKey: ["old-review-scholarships-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("scholarships")
        .select("*", { count: "exact", head: true })
        .is("reviewed_at", null);
      if (error) throw error;
      return count ?? 0;
    },
    refetchInterval: 60_000,
  });
  return count;
}
