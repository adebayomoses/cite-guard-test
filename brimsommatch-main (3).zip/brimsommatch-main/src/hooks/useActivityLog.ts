import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface Activity {
  id: string;
  action: string;
  detail: string | null;
  created_at: string;
}

export function useActivityLog() {
  const { user } = useAuth();
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("activity_log")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => {
        setActivities((data as Activity[]) ?? []);
        setLoading(false);
      });
  }, [user]);

  async function logActivity(action: string, detail?: string) {
    if (!user) return;
    await supabase.from("activity_log").insert({
      user_id: user.id,
      action,
      detail: detail ?? null,
    } as any);
  }

  return { activities, loading, logActivity };
}
