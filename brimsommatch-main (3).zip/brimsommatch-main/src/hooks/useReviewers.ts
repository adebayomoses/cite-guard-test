import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type Reviewer = {
  user_id: string;
  full_name: string | null;
  is_admin: boolean;
};

/**
 * Returns admins + moderators with the 'scholarships' section,
 * excluding the current user. Used to assign reviewers when posting a scholarship.
 */
export function useReviewers() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["scholarship-reviewers", user?.id],
    queryFn: async (): Promise<Reviewer[]> => {
      // 1. Admins
      const { data: admins } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "admin");

      // 2. Moderators with scholarships permission
      const { data: mods } = await supabase
        .from("moderator_permissions" as any)
        .select("user_id")
        .eq("section", "scholarships");

      const adminIds = new Set((admins ?? []).map((a: any) => a.user_id));
      const modIds = new Set((mods ?? []).map((m: any) => m.user_id));
      let all = new Set<string>([...adminIds, ...modIds]);

      // If an explicit approval team has been configured, restrict reviewers to that team.
      const { data: team } = await supabase
        .from("approval_team_members" as any)
        .select("user_id");
      const teamIds = new Set((team ?? []).map((t: any) => t.user_id));
      if (teamIds.size > 0) {
        all = new Set([...all].filter((id) => teamIds.has(id)));
      }

      if (user?.id) all.delete(user.id);

      if (all.size === 0) return [];

      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", Array.from(all));

      return (profiles ?? []).map((p: any) => ({
        user_id: p.user_id,
        full_name: p.full_name,
        is_admin: adminIds.has(p.user_id),
      })).sort((a, b) => Number(b.is_admin) - Number(a.is_admin));
    },
    enabled: !!user,
  });
}
