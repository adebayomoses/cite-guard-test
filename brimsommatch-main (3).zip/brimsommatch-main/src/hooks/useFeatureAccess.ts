import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { type PlanId, type FeatureKey, PLAN_TIERS } from "@/lib/subscriptionTiers";
import { useSiteSettings } from "@/hooks/useSiteSettings";

export function useSubscriptionPlan() {
  const { user, session } = useAuth();

  return useQuery({
    queryKey: ["subscription-plan", user?.id],
    queryFn: async (): Promise<{ plan: PlanId; subscriptionEnd?: string }> => {
      if (!session?.access_token) return { plan: "free" };
      try {
        const { data, error } = await supabase.functions.invoke("check-subscription", {
          headers: { Authorization: `Bearer ${session.access_token}` },
        });
        if (error) throw error;
        return { plan: (data?.plan as PlanId) || "free", subscriptionEnd: data?.subscription_end };
      } catch {
        return { plan: "free" };
      }
    },
    enabled: !!user,
    staleTime: 60_000,
    refetchInterval: 60_000,
  });
}

export function useFeatureUsage(feature: FeatureKey, period: "day" | "month" | "total" | "2month") {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["feature-usage", user?.id, feature, period],
    queryFn: async () => {
      if (!user) return 0;
      if (period === "total") {
        const { count } = await (supabase as any)
          .from("feature_usage")
          .select("*", { count: "exact", head: true })
          .eq("user_id", user.id)
          .eq("feature", feature);
        return count ?? 0;
      }
      const { data, error } = await supabase.rpc("get_feature_usage_count" as any, {
        _user_id: user.id,
        _feature: feature,
        _period: period,
      });
      if (error) throw error;
      return (data as number) ?? 0;
    },
    enabled: !!user,
    staleTime: 10_000,
  });
}

export function useTrackUsage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (feature: FeatureKey) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await (supabase as any)
        .from("feature_usage")
        .insert({ user_id: user.id, feature });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["feature-usage"] });
    },
  });
}

export function useFeatureAccess(feature: FeatureKey) {
  const { settings } = useSiteSettings();
  const isFreeMode = settings?.premium_disabled === "true";

  const { data: subData, isLoading: planLoading } = useSubscriptionPlan();
  const plan = isFreeMode ? "pro" as PlanId : (subData?.plan ?? "free");
  const tierLimit = PLAN_TIERS[plan].limits[feature];

  // For score_generation and scholarship_recommendation, check dynamic limits from site_settings
  let dynamicCount: number | undefined;
  if (feature === "score_generation" || feature === "scholarship_recommendation" || feature === "match_me") {
    const settingKey = `limit_${feature}_${plan}`;
    const settingVal = settings?.[settingKey];
    if (settingVal !== undefined && settingVal !== null) {
      const parsed = parseInt(settingVal, 10);
      if (!isNaN(parsed)) {
        dynamicCount = parsed === 0 ? Infinity : parsed;
      }
    }
  }

  const limitCount = dynamicCount ?? tierLimit.count;
  const { data: usage = 0, isLoading: usageLoading } = useFeatureUsage(feature, tierLimit.period);

  const remaining = isFreeMode ? Infinity : (limitCount === Infinity ? Infinity : Math.max(0, limitCount - usage));
  const canUse = isFreeMode ? true : remaining > 0;

  return {
    plan,
    canUse,
    remaining,
    limit: isFreeMode ? Infinity : limitCount,
    period: tierLimit.period,
    usage: isFreeMode ? 0 : usage,
    isLoading: planLoading || usageLoading,
  };
}
