import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface RoomAnnouncement {
  id: string;
  room_id: string;
  content: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export function useRoomAnnouncements(roomId: string | null) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const queryKey = ["room-announcements", roomId];

  const { data: announcements = [], isLoading } = useQuery({
    queryKey,
    queryFn: async () => {
      if (!roomId) return [];
      const { data, error } = await supabase
        .from("room_announcements" as any)
        .select("*")
        .eq("room_id", roomId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as RoomAnnouncement[];
    },
    enabled: !!roomId,
  });

  const addAnnouncement = useMutation({
    mutationFn: async (content: string) => {
      if (!roomId || !user) throw new Error("Missing room or user");
      const { error } = await supabase
        .from("room_announcements" as any)
        .insert({ room_id: roomId, content, created_by: user.id } as any);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey }),
  });

  const updateAnnouncement = useMutation({
    mutationFn: async ({ id, content }: { id: string; content: string }) => {
      const { error } = await supabase
        .from("room_announcements" as any)
        .update({ content, updated_at: new Date().toISOString() } as any)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey }),
  });

  const deleteAnnouncement = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("room_announcements" as any)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey }),
  });

  return { announcements, isLoading, addAnnouncement, updateAnnouncement, deleteAnnouncement };
}
