import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useCommunityModerators() {
  const { user } = useAuth();
  const [moderatorIds, setModeratorIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  const fetchModerators = useCallback(async () => {
    const { data } = await supabase
      .from("community_moderators" as any)
      .select("user_id");
    setModeratorIds(new Set((data ?? []).map((r: any) => r.user_id as string)));
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchModerators();
  }, [fetchModerators]);

  const isCommunityModerator = useCallback(
    (userId?: string) => userId ? moderatorIds.has(userId) : false,
    [moderatorIds]
  );

  const isCurrentUserModerator = user ? moderatorIds.has(user.id) : false;

  const appointModerator = useCallback(
    async (userId: string) => {
      if (!user) return;
      const { error } = await supabase.from("community_moderators" as any).insert({
        user_id: userId,
        appointed_by: user.id,
      });
      if (error) throw error;
      await fetchModerators();
    },
    [user, fetchModerators]
  );

  const removeModerator = useCallback(
    async (userId: string) => {
      const { error } = await (supabase as any)
        .from("community_moderators")
        .delete()
        .eq("user_id", userId);
      if (error) throw error;
      // Re-fetch from DB to guarantee the UI reflects the actual state
      // (covers cases where RLS silently filters or another tab changed state).
      await fetchModerators();
    },
    [fetchModerators]
  );

  return {
    moderatorIds,
    loading,
    isCommunityModerator,
    isCurrentUserModerator,
    appointModerator,
    removeModerator,
    refetch: fetchModerators,
  };
}
