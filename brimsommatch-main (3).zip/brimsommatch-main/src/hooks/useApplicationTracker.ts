import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";

export interface Application {
  id: string;
  user_id: string;
  scholarship_id: string | null;
  status: string;
  notes: string | null;
  custom_name: string | null;
  deadline: string | null;
  created_at: string;
  updated_at: string;
  scholarship_title?: string;
}

const TABLE = "scholarship_applications" as any;

export function useApplicationTracker() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const key = ["scholarship-applications", user?.id];

  const { data: applications = [], isLoading } = useQuery({
    queryKey: key,
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from(TABLE)
        .select("*")
        .eq("user_id", user!.id)
        .order("updated_at", { ascending: false });
      if (error) throw error;

      // Fetch scholarship titles for linked ones
      const ids = (data as any[]).filter((d) => d.scholarship_id).map((d) => d.scholarship_id);
      let titleMap: Record<string, string> = {};
      if (ids.length) {
        const { data: schols } = await supabase
          .from("scholarships")
          .select("id, title")
          .in("id", ids);
        if (schols) titleMap = Object.fromEntries(schols.map((s) => [s.id, s.title]));
      }

      return (data as any[]).map((d) => ({
        ...d,
        scholarship_title: d.scholarship_id
          ? (titleMap[d.scholarship_id] || "Scholarship (removed)")
          : undefined,
      })) as Application[];
    },
  });

  // Realtime
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel("app-tracker")
      .on("postgres_changes", { event: "*", schema: "public", table: "scholarship_applications", filter: `user_id=eq.${user.id}` }, () => {
        qc.invalidateQueries({ queryKey: key });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);

  const addApplication = useMutation({
    mutationFn: async (app: { scholarship_id?: string; custom_name?: string; deadline?: string; notes?: string }) => {
      const { error } = await (supabase.from(TABLE) as any).insert({
        user_id: user!.id,
        scholarship_id: app.scholarship_id || null,
        custom_name: app.custom_name || null,
        deadline: app.deadline || null,
        notes: app.notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
  });

  const updateApplication = useMutation({
    mutationFn: async ({ id, ...fields }: { id: string; status?: string; notes?: string; deadline?: string; custom_name?: string }) => {
      const { error } = await (supabase.from(TABLE) as any).update(fields).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
  });

  const deleteApplication = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase.from(TABLE) as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: key }),
  });

  return { applications, isLoading, addApplication, updateApplication, deleteApplication };
}
