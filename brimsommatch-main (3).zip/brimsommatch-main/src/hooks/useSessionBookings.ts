import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export interface SessionBooking {
  id: string;
  user_id: string;
  session_type: string;
  proposed_date_1: string;
  proposed_date_2: string;
  proposed_date_3: string;
  confirmed_date: string | null;
  notes: string | null;
  status: string;
  admin_notes: string | null;
  reviewed_by: string | null;
  created_at: string;
  updated_at: string;
}

export function useUserBookings() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["session-bookings", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("session_bookings" as any)
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as SessionBooking[];
    },
    enabled: !!user,
  });
}

export function useCreateBooking() {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      session_type: string;
      proposed_date_1: string;
      proposed_date_2: string;
      proposed_date_3: string;
      notes?: string;
    }) => {
      const { error } = await supabase.from("session_bookings" as any).insert({
        user_id: user!.id,
        session_type: input.session_type,
        proposed_date_1: input.proposed_date_1,
        proposed_date_2: input.proposed_date_2,
        proposed_date_3: input.proposed_date_3,
        notes: input.notes || null,
      } as any);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["session-bookings"] }),
  });
}

export function useAdminBookings() {
  return useQuery({
    queryKey: ["admin-session-bookings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("session_bookings" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      const bookings = (data ?? []) as unknown as SessionBooking[];

      // fetch profile names
      const userIds = [...new Set(bookings.map((b) => b.user_id))];
      if (userIds.length === 0) return bookings.map((b) => ({ ...b, profiles: null }));

      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", userIds);

      const profileMap = new Map((profiles ?? []).map((p) => [p.user_id, p]));
      return bookings.map((b) => ({ ...b, profiles: profileMap.get(b.user_id) ?? null }));
    },
  });
}

export function useUpdateBooking() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      id: string;
      status: string;
      confirmed_date?: string | null;
      admin_notes?: string;
      reviewed_by: string;
    }) => {
      const { error } = await supabase
        .from("session_bookings" as any)
        .update({
          status: input.status,
          confirmed_date: input.confirmed_date ?? null,
          admin_notes: input.admin_notes || null,
          reviewed_by: input.reviewed_by,
        } as any)
        .eq("id", input.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-session-bookings"] }),
  });
}
