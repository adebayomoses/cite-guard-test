import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useIsMainAdmin() {
  return useQuery({
    queryKey: ["is-main-admin"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;
      const { data, error } = await supabase.rpc("is_main_admin", { _user_id: user.id });
      if (error) return false;
      return !!data;
    },
    staleTime: 5 * 60 * 1000,
  });
}
