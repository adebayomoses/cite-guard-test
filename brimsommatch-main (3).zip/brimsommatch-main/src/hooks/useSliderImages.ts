import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface SliderImage {
  id: string;
  image_url: string;
  alt_text: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
}

export function useSliderImages() {
  const queryClient = useQueryClient();

  const { data: images = [], isLoading } = useQuery({
    queryKey: ["slider-images"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("slider_images")
        .select("*")
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data as SliderImage[];
    },
  });

  const activeImages = images.filter((img) => img.is_active);

  const uploadImage = useMutation({
    mutationFn: async ({ file, altText }: { file: File; altText: string }) => {
      const ext = file.name.split(".").pop();
      const path = `${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("slider-images")
        .upload(path, file);
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from("slider-images")
        .getPublicUrl(path);

      const maxOrder = images.length > 0 ? Math.max(...images.map((i) => i.sort_order)) + 1 : 0;

      const { error: insertError } = await supabase.from("slider_images").insert({
        image_url: urlData.publicUrl,
        alt_text: altText,
        sort_order: maxOrder,
      });
      if (insertError) throw insertError;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["slider-images"] }),
  });

  const deleteImage = useMutation({
    mutationFn: async (image: SliderImage) => {
      // Delete from storage
      const url = new URL(image.image_url);
      const pathParts = url.pathname.split("/slider-images/");
      if (pathParts[1]) {
        await supabase.storage.from("slider-images").remove([pathParts[1]]);
      }
      const { error } = await supabase.from("slider_images").delete().eq("id", image.id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["slider-images"] }),
  });

  const updateImage = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<SliderImage> & { id: string }) => {
      const { error } = await supabase.from("slider_images").update(updates).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["slider-images"] }),
  });

  return { images, activeImages, isLoading, uploadImage, deleteImage, updateImage };
}
