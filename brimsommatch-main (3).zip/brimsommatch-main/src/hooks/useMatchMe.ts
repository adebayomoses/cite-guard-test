import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export type MatchResult = {
  title: string;
  provider: string;
  country: string;
  match_score: number;
  match_reason: string;
  chance_score: number;
  chance_reason: string;
  gap_summary: string;
  action_steps: string[];
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1] ?? "";
      resolve(base64);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function handleEdgeError(error: any, fallback: string) {
  const ctx = (error as any)?.context;
  const status = ctx?.status;
  if (status === 429) {
    toast({ title: "Slow down", description: "Rate limit reached. Try again shortly.", variant: "destructive" });
    return;
  }
  if (status === 402) {
    toast({ title: "Out of credits", description: "Add credits to continue.", variant: "destructive" });
    return;
  }
  toast({ title: fallback, description: error?.message ?? "Please try again.", variant: "destructive" });
}

export function useMatchMe() {
  const [loading, setLoading] = useState(false);
  const [extracting, setExtracting] = useState(false);

  const extractDocumentText = async (file: File): Promise<string | null> => {
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: "File too large", description: "Max 10 MB.", variant: "destructive" });
      return null;
    }
    setExtracting(true);
    try {
      const file_base64 = await fileToBase64(file);
      const { data, error } = await supabase.functions.invoke("extract-document-text", {
        body: { file_base64, file_name: file.name },
      });
      if (error) {
        handleEdgeError(error, "Could not read file");
        return null;
      }
      return (data as any)?.text ?? null;
    } finally {
      setExtracting(false);
    }
  };

  const matchScholarship = async (scholarship_text: string): Promise<MatchResult | null> => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("match-scholarship", {
        body: { scholarship_text },
      });
      if (error) {
        handleEdgeError(error, "Match failed");
        return null;
      }
      return ((data as any)?.result as MatchResult) ?? null;
    } finally {
      setLoading(false);
    }
  };

  return { matchScholarship, extractDocumentText, loading, extracting };
}
