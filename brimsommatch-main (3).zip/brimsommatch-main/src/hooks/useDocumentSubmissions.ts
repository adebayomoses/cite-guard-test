import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export interface DocumentSubmission {
  id: string;
  user_id: string;
  service_type: string;
  file_url: string;
  file_name: string;
  notes: string | null;
  status: string;
  admin_feedback: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
  // joined fields for admin
  profiles?: { full_name: string | null } | null;
}

export function useUserSubmissions() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["document-submissions", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("document_submissions" as any)
        .select("*")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as DocumentSubmission[];
    },
    enabled: !!user,
  });
}

export class DocumentReviewLimitError extends Error {
  plan: string;
  usage: number;
  limit: number;
  period: string;
  constructor(info: { plan: string; usage: number; limit: number; period: string }) {
    super("limit_reached");
    this.name = "DocumentReviewLimitError";
    this.plan = info.plan;
    this.usage = info.usage;
    this.limit = info.limit;
    this.period = info.period;
  }
}

async function submitViaEdge(items: { service_type: string; file_url: string; file_name: string; notes?: string | null }[]) {
  const { data, error } = await supabase.functions.invoke("submit-document-review", {
    body: { items },
  });
  // functions.invoke returns the parsed body on non-2xx in `data` sometimes;
  // prefer error path when present.
  if (error) {
    // Try to parse FunctionsHttpError context for a structured payload
    const ctx: any = (error as any).context;
    let payload: any = null;
    try {
      if (ctx && typeof ctx.json === "function") payload = await ctx.json();
      else if (ctx?.body) payload = JSON.parse(ctx.body);
    } catch { /* ignore */ }
    if (payload?.error === "limit_reached") {
      throw new DocumentReviewLimitError(payload);
    }
    if (payload?.error === "upgrade_required") {
      throw new Error("This service requires a Pro plan. Please upgrade to continue.");
    }
    throw new Error(payload?.error || error.message || "Submission failed");
  }
  if (data?.error === "limit_reached") {
    throw new DocumentReviewLimitError(data);
  }
  if (data?.error === "upgrade_required") {
    throw new Error("This service requires a Pro plan. Please upgrade to continue.");
  }
  if (data?.error) throw new Error(data.error);
  return data;
}

export function useCreateSubmission() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ serviceType, file, notes }: { serviceType: string; file: File; notes: string }) => {
      if (!user) throw new Error("Not authenticated");

      const filePath = `${user.id}/reviews/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from("user-documents")
        .upload(filePath, file);
      if (uploadError) throw uploadError;

      try {
        await submitViaEdge([
          { service_type: serviceType, file_url: filePath, file_name: file.name, notes: notes || null },
        ]);
      } catch (e) {
        // Clean up orphan upload if the server rejected the submission
        await supabase.storage.from("user-documents").remove([filePath]).catch(() => {});
        throw e;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["document-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["feature-usage"] });
    },
  });
}

export function useCreatePackageSubmission() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ files, notes }: { files: Record<string, File>; notes: string }) => {
      if (!user) throw new Error("Not authenticated");
      const timestamp = Date.now();

      const uploaded: { fieldKey: string; path: string; file: File }[] = [];
      try {
        for (const [fieldKey, file] of Object.entries(files)) {
          const filePath = `${user.id}/reviews/${timestamp}_${fieldKey}_${file.name}`;
          const { error: uploadError } = await supabase.storage
            .from("user-documents")
            .upload(filePath, file);
          if (uploadError) throw uploadError;
          uploaded.push({ fieldKey, path: filePath, file });
        }

        const items = uploaded.map((u) => {
          const prefixedNotes = notes ? `[${u.fieldKey}] ${notes}` : `[${u.fieldKey}]`;
          return {
            service_type: "full_package",
            file_url: u.path,
            file_name: u.file.name,
            notes: prefixedNotes,
          };
        });
        await submitViaEdge(items);
      } catch (e) {
        await supabase.storage
          .from("user-documents")
          .remove(uploaded.map((u) => u.path))
          .catch(() => {});
        throw e;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["document-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["feature-usage"] });
    },
  });
}

export function useAdminSubmissions() {
  return useQuery({
    queryKey: ["admin-document-submissions"],
    queryFn: async () => {
      // Fetch submissions
      const { data: subs, error } = await supabase
        .from("document_submissions" as any)
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      const submissions = subs as unknown as DocumentSubmission[];

      // Fetch profile names for user_ids
      const userIds = [...new Set(submissions.map((s) => s.user_id))];
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name")
          .in("user_id", userIds);
        const profileMap = new Map((profiles ?? []).map((p) => [p.user_id, p.full_name]));
        submissions.forEach((s) => {
          (s as any).profiles = { full_name: profileMap.get(s.user_id) ?? null };
        });
      }
      return submissions;
    },
  });
}

export function useDeleteSubmission() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("document_submissions" as any)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-document-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["document-submissions"] });
    },
  });
}

export function useUpdateSubmission() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status, admin_feedback, reviewed_by }: {
      id: string; status: string; admin_feedback: string; reviewed_by: string;
    }) => {
      const { error } = await supabase
        .from("document_submissions" as any)
        .update({
          status,
          admin_feedback,
          reviewed_by,
          reviewed_at: new Date().toISOString(),
        } as any)
        .eq("id", id);
      if (error) throw error;

      // Notify the user by email that feedback is available
      try {
        await supabase.functions.invoke("notify-document-feedback", {
          body: { submissionId: id },
        });
      } catch (e) {
        console.error("Failed to send document feedback email", e);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-document-submissions"] });
    },
  });
}

