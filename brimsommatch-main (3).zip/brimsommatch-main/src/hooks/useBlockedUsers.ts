import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useBlockedUsers() {
  const [blockedIds, setBlockedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchBlocked = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("blocked_users")
      .select("blocked_id")
      .eq("blocker_id", user.id);
    setBlockedIds(new Set((data ?? []).map((r) => r.blocked_id)));
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchBlocked();
  }, [fetchBlocked]);

  const isBlocked = useCallback(
    (userId: string) => blockedIds.has(userId),
    [blockedIds]
  );

  const blockUser = useCallback(
    async (blockedId: string) => {
      if (!user) return;
      await supabase
        .from("blocked_users")
        .insert({ blocker_id: user.id, blocked_id: blockedId });
      setBlockedIds((prev) => new Set([...prev, blockedId]));
    },
    [user]
  );

  const unblockUser = useCallback(
    async (blockedId: string) => {
      if (!user) return;
      await supabase
        .from("blocked_users")
        .delete()
        .eq("blocker_id", user.id)
        .eq("blocked_id", blockedId);
      setBlockedIds((prev) => {
        const next = new Set(prev);
        next.delete(blockedId);
        return next;
      });
    },
    [user]
  );

  return { blockedIds, loading, isBlocked, blockUser, unblockUser };
}
