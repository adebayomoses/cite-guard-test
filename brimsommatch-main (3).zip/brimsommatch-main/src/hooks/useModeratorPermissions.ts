import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

export function useModeratorPermissions() {
  const { user } = useAuth();

  const { data: permissions = [], isLoading } = useQuery({
    queryKey: ["moderator-permissions", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("moderator_permissions" as any)
        .select("section")
        .eq("user_id", user.id);
      if (error) throw error;
      return (data as any[]).map((r) => r.section as string);
    },
    enabled: !!user,
  });

  return { permissions, isLoading };
}
