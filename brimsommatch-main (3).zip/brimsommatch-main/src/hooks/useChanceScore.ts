import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface ScholarshipMatch {
  scholarship_id: string;
  score: number;
  chance: number;
  reason: string;
  chance_reason?: string;
  pending_ai?: boolean;
}

interface ScoreResult {
  readiness_score: number;
  readiness_summary: string;
  tips: string[];
  scholarship_matches: ScholarshipMatch[];
}

export function useChanceScore() {
  const { user } = useAuth();
  const [score, setScore] = useState<ScoreResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetchCached();
  }, [user]);

  async function fetchCached() {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("score_results")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1);

    if (data?.[0]) {
      setScore({
        readiness_score: data[0].readiness_score,
        readiness_summary: data[0].readiness_summary ?? "",
      tips: (data[0].tips as unknown as string[]) ?? [],
      scholarship_matches: (data[0].scholarship_matches as unknown as ScholarshipMatch[]) ?? [],
      });
    }
    setLoading(false);
  }

  async function generate(logActivity?: (action: string, detail?: string) => Promise<void>) {
    if (!user) return;
    setGenerating(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const resp = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/score-profile`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({}),
        }
      );

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "Unknown error" }));
        if (resp.status === 429) {
          toast.error("Rate limited — please wait a moment and try again.");
        } else if (resp.status === 402) {
          toast.error("AI credits exhausted. Please add credits to continue.");
        } else {
          toast.error(err.error || "Failed to generate score");
        }
        return;
      }

      const result = await resp.json();
      if (result.cached) {
        toast.info("Your score is already up to date.");
      } else {
        logActivity?.("Generated Chance Score", `Score: ${result.readiness_score}`);
        toast.success("Score generated!");
      }
      setScore({
        readiness_score: result.readiness_score,
        readiness_summary: result.readiness_summary,
        tips: result.tips,
        scholarship_matches: result.scholarship_matches,
      });
    } catch (e) {
      console.error(e);
      toast.error("Failed to generate score");
    } finally {
      setGenerating(false);
    }
  }

  return { score, loading, generating, generate };
}
