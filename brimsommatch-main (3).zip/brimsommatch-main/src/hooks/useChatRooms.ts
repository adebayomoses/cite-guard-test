import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type ChatRoom = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

export function useChatRooms() {
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("chat_rooms")
      .select("*")
      .order("created_at")
      .then(({ data }) => {
        setRooms(data ?? []);
        setLoading(false);
      });
  }, []);

  return { rooms, loading };
}
