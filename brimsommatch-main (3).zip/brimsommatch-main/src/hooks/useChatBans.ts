import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useChatBans(roomId: string | null) {
  const { user } = useAuth();
  const [bannedUserIds, setBannedUserIds] = useState<Set<string>>(new Set());
  const [isSelfBanned, setIsSelfBanned] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchBans = useCallback(async () => {
    if (!roomId) return;
    const { data } = await supabase
      .from("chat_bans" as any)
      .select("user_id, room_id");
    
    const bans = (data ?? []) as any[];
    const ids = new Set(
      bans
        .filter((b: any) => b.room_id === null || b.room_id === roomId)
        .map((b: any) => b.user_id as string)
    );
    setBannedUserIds(ids);
    setIsSelfBanned(user ? ids.has(user.id) : false);
    setLoading(false);
  }, [roomId, user]);

  useEffect(() => {
    fetchBans();
  }, [fetchBans]);

  const banUser = useCallback(
    async (userId: string, reason?: string) => {
      if (!user || !roomId) return;
      await supabase.from("chat_bans" as any).insert({
        user_id: userId,
        banned_by: user.id,
        room_id: roomId,
        reason: reason || null,
      });
      setBannedUserIds((prev) => new Set([...prev, userId]));
    },
    [user, roomId]
  );

  const unbanUser = useCallback(
    async (userId: string) => {
      if (!roomId) return;
      await (supabase as any)
        .from("chat_bans")
        .delete()
        .eq("user_id", userId)
        .eq("room_id", roomId);
      setBannedUserIds((prev) => {
        const next = new Set(prev);
        next.delete(userId);
        return next;
      });
    },
    [roomId]
  );

  const isBanned = useCallback(
    (userId: string) => bannedUserIds.has(userId),
    [bannedUserIds]
  );

  return { bannedUserIds, isSelfBanned, loading, banUser, unbanUser, isBanned, refetch: fetchBans };
}
