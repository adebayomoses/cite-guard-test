import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface SingleScoreResult {
  scholarship_id: string;
  score: number;
  chance: number;
  reason: string;
  chance_reason: string;
}

/**
 * On-demand AI scoring for a single scholarship (used for long-tail items
 * outside the prefiltered shortlist).
 */
export function useScoreSingle() {
  const [scoringId, setScoringId] = useState<string | null>(null);

  async function scoreSingle(scholarshipId: string): Promise<SingleScoreResult | null> {
    setScoringId(scholarshipId);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error("Please sign in to score scholarships.");
        return null;
      }

      const resp = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/score-single-scholarship`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ scholarship_id: scholarshipId }),
        }
      );

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "Unknown error" }));
        if (resp.status === 429) toast.error("Rate limited — please wait a moment and try again.");
        else if (resp.status === 402) toast.error("AI credits exhausted. Please add credits to continue.");
        else toast.error(err.error || "Failed to score scholarship");
        return null;
      }

      const data = await resp.json();
      toast.success("Scored! Detailed match and chance scores ready.");
      return data.match as SingleScoreResult;
    } catch (e) {
      console.error(e);
      toast.error("Failed to score scholarship");
      return null;
    } finally {
      setScoringId(null);
    }
  }

  return { scoreSingle, scoringId };
}
