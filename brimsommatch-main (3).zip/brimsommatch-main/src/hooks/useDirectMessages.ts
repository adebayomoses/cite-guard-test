import { useEffect, useRef, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type DirectMessage = {
  id: string;
  sender_id: string;
  receiver_id: string;
  sender_name: string;
  content: string;
  created_at: string;
  image_url?: string | null;
};

export function useDirectMessages(otherUserId: string | null) {
  const [messages, setMessages] = useState<DirectMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  useEffect(() => {
    if (!otherUserId || !user) return;
    setLoading(true);

    supabase
      .from("direct_messages")
      .select("*")
      .or(
        `and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})`
      )
      .order("created_at")
      .then(({ data }) => {
        setMessages((data as DirectMessage[]) ?? []);
        setLoading(false);
      });

    const channel = supabase
      .channel(`dm-${[user.id, otherUserId].sort().join("-")}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "direct_messages",
        },
        (payload) => {
          const msg = payload.new as DirectMessage;
          const isRelevant =
            (msg.sender_id === user.id && msg.receiver_id === otherUserId) ||
            (msg.sender_id === otherUserId && msg.receiver_id === user.id);
          if (isRelevant) {
            setMessages((prev) => [...prev, msg]);
          }
        }
      )
      .subscribe();

    channelRef.current = channel;

    return () => {
      supabase.removeChannel(channel);
    };
  }, [otherUserId, user?.id]);

  const sendDirectMessage = useCallback(
    async (receiverId: string, content: string, imageFile?: File) => {
      if (!user) return;

      let imageUrl: string | null = null;

      if (imageFile) {
        const filePath = `${user.id}/${Date.now()}-${imageFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from("chat-images")
          .upload(filePath, imageFile);
        if (!uploadError) {
          const { data: urlData } = supabase.storage
            .from("chat-images")
            .getPublicUrl(filePath);
          imageUrl = urlData.publicUrl;
        }
      }

      const senderName =
        user.user_metadata?.full_name || user.email?.split("@")[0] || "User";
      const { error: insertError } = await supabase.from("direct_messages").insert({
        sender_id: user.id,
        receiver_id: receiverId,
        sender_name: senderName,
        content,
        image_url: imageUrl,
      });

      if (!insertError) {
        // Fire-and-forget push notification (in-app notification is created
        // reliably by a DB trigger on direct_messages). Use fetch with
        // keepalive so the request survives tab close / navigation.
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          const token = sessionData.session?.access_token;
          if (token) {
            const url = `https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/send-push-notification`;
            fetch(url, {
              method: "POST",
              keepalive: true,
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
                apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
              },
              body: JSON.stringify({
                action: "chat-dm",
                receiver_id: receiverId,
                sender_name: senderName,
                content_preview: content || (imageUrl ? "📷 Photo" : ""),
                title: senderName,
                body: content || (imageUrl ? "📷 Photo" : "Sent you a message"),
                url: `/community?dm=${user.id}`,
                user_ids: [receiverId],
                skip_inapp: true,
              }),

            }).catch(() => {});
          }
        } catch {
          // ignore
        }
      }
    },
    [user]
  );

  return { messages, loading, sendDirectMessage };
}
