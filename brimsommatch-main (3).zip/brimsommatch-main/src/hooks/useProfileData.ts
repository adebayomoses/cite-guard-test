import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import type { PersonalInfoData } from "@/components/profile/PersonalInfoStep";
import type { EducationEntry, HighSchoolSubject } from "@/components/profile/EducationStep";
import type { TestScoreEntry } from "@/components/profile/TestScoresStep";
import type { ResearchEntry } from "@/components/profile/ResearchStep";
import type { ExtracurricularEntry } from "@/components/profile/ExtracurricularsStep";
import type { EssayProfileData } from "@/components/profile/EssayProfileStep";

// Sanitize date strings: only accept YYYY-MM-DD format, otherwise return null
function sanitizeDate(val: string | null | undefined): string | null {
  if (!val) return null;
  const trimmed = val.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
  if (/^\d{4}-\d{2}$/.test(trimmed)) return `${trimmed}-01`;
  if (/^\d{4}$/.test(trimmed)) return `${trimmed}-01-01`;
  return null;
}

interface DocFile {
  id?: string;
  document_type: string;
  file_url: string;
  file_name: string;
}

export function useProfileData() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [personalInfo, setPersonalInfo] = useState<PersonalInfoData | null>(null);
  const [education, setEducation] = useState<EducationEntry[]>([]);
  const [highSchoolSubjects, setHighSchoolSubjects] = useState<HighSchoolSubject[]>([]);
  const [testScores, setTestScores] = useState<TestScoreEntry[]>([]);
  const [research, setResearch] = useState<ResearchEntry[]>([]);
  const [documents, setDocuments] = useState<DocFile[]>([]);
  const [sop, setSop] = useState("");
  const [extracurriculars, setExtracurriculars] = useState<ExtracurricularEntry[]>([]);
  const [essayProfile, setEssayProfile] = useState<EssayProfileData | null>(null);

  useEffect(() => {
    if (!user) return;
    loadAll();
  }, [user]);

  async function loadAll() {
    if (!user) return;
    setLoading(true);
    const [profileRes, eduRes, testRes, researchRes, docsRes, sopRes, extraRes, subjectsRes, essayRes] = await Promise.all([
      supabase.from("profiles").select("*").eq("user_id", user.id).single(),
      supabase.from("education_history").select("*").eq("user_id", user.id),
      supabase.from("test_scores").select("*").eq("user_id", user.id),
      supabase.from("research_experience").select("*").eq("user_id", user.id),
      supabase.from("user_documents").select("*").eq("user_id", user.id),
      supabase.from("sop_entries").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(1),
      supabase.from("extracurriculars").select("*").eq("user_id", user.id),
      supabase.from("high_school_subjects").select("*").eq("user_id", user.id),
      supabase.from("essay_profiles" as any).select("*").eq("user_id", user.id).maybeSingle(),
    ]);

    if (profileRes.data) {
      setPersonalInfo({
        full_name: profileRes.data.full_name ?? "",
        date_of_birth: profileRes.data.date_of_birth ?? "",
        nationality: profileRes.data.nationality ?? "",
        country_of_residence: profileRes.data.country_of_residence ?? "",
        bio: profileRes.data.bio ?? "",
        academic_level: profileRes.data.academic_level ?? "",
        intended_program: (profileRes.data as any).intended_program ?? "",
        intended_degree_level: (profileRes.data as any).intended_degree_level ?? "",
        intended_field_of_study: (profileRes.data as any).intended_field_of_study ?? "",
      });
    }
    if (eduRes.data) setEducation(eduRes.data.map(e => ({ ...e, gpa: e.gpa?.toString() ?? "", gpa_scale: e.gpa_scale?.toString() ?? "", start_date: e.start_date ?? "", end_date: e.end_date ?? "", is_current: e.is_current ?? false })));
    if (testRes.data) setTestScores(testRes.data.map(t => ({ ...t, score: t.score.toString(), max_score: t.max_score?.toString() ?? "", date_taken: t.date_taken ?? "" })));
    if (researchRes.data) setResearch(researchRes.data.map(r => ({ ...r, organization: r.organization ?? "", description: r.description ?? "", start_date: r.start_date ?? "", end_date: r.end_date ?? "", publications: r.publications ?? [] })));
    if (docsRes.data) setDocuments(docsRes.data);
    if (sopRes.data?.[0]) setSop(sopRes.data[0].content);
    if (extraRes.data) setExtracurriculars(extraRes.data.map(e => ({ ...e, organization: e.organization ?? "", description: e.description ?? "", date: e.date ?? "" })));
    if (subjectsRes.data) setHighSchoolSubjects(subjectsRes.data.map(s => ({ id: s.id, subject_name: s.subject_name, grade: s.grade ?? "" })));
    if ((essayRes as any)?.data) {
      const e: any = (essayRes as any).data;
      setEssayProfile({
        motivation: e.motivation ?? "",
        project_or_achievement: e.project_or_achievement ?? "",
        tools_software: e.tools_software ?? "",
        research_interests: e.research_interests ?? "",
        career_goals: e.career_goals ?? "",
        why_study_abroad: e.why_study_abroad ?? "",
        academic_explanations: e.academic_explanations ?? "",
      });
    }
    setLoading(false);
  }

  async function saveEssayProfile(data: EssayProfileData) {
    if (!user) return;
    const payload = {
      user_id: user.id,
      motivation: data.motivation || null,
      project_or_achievement: data.project_or_achievement || null,
      tools_software: data.tools_software || null,
      research_interests: data.research_interests || null,
      career_goals: data.career_goals || null,
      why_study_abroad: data.why_study_abroad || null,
      academic_explanations: data.academic_explanations || null,
    };
    const { error } = await supabase
      .from("essay_profiles" as any)
      .upsert(payload, { onConflict: "user_id" });
    if (error) toast.error("Failed to save essay profile: " + error.message);
    else setEssayProfile(data);
  }

  async function savePersonalInfo(data: PersonalInfoData) {
    if (!user) return;
    const { error } = await supabase.from("profiles").update({
      full_name: data.full_name,
      date_of_birth: sanitizeDate(data.date_of_birth),
      nationality: data.nationality || null,
      country_of_residence: data.country_of_residence || null,
      bio: data.bio || null,
      academic_level: data.academic_level || null,
      intended_program: data.intended_program || null,
      intended_degree_level: data.intended_degree_level || null,
      intended_field_of_study: data.intended_field_of_study || null,
    } as any).eq("user_id", user.id);
    if (error) toast.error("Failed to save: " + error.message);
    else setPersonalInfo(data);
  }

  async function saveEducation(entries: EducationEntry[], subjects?: HighSchoolSubject[]) {
    if (!user) return;
    await supabase.from("education_history").delete().eq("user_id", user.id);
    const rows = entries.filter(e => e.degree_level && e.institution).map(e => ({
      user_id: user.id,
      degree_level: e.degree_level,
      institution: e.institution,
      field_of_study: e.field_of_study || null,
      gpa: e.gpa ? parseFloat(e.gpa) : null,
      gpa_scale: e.gpa_scale ? parseFloat(e.gpa_scale) : null,
      start_date: sanitizeDate(e.start_date),
      end_date: sanitizeDate(e.end_date),
      is_current: e.is_current,
    }));
    if (rows.length) {
      const { error } = await supabase.from("education_history").insert(rows);
      if (error) toast.error("Failed to save education: " + error.message);
    }
    setEducation(entries);

    // Save high school subjects if provided
    if (subjects) {
      await supabase.from("high_school_subjects").delete().eq("user_id", user.id);
      const subjectRows = subjects.filter(s => s.subject_name).map(s => ({
        user_id: user.id,
        subject_name: s.subject_name,
        grade: s.grade || null,
      }));
      if (subjectRows.length) {
        const { error } = await supabase.from("high_school_subjects").insert(subjectRows);
        if (error) toast.error("Failed to save subjects: " + error.message);
      }
      setHighSchoolSubjects(subjects);
    }
  }

  async function saveTestScores(entries: TestScoreEntry[]) {
    if (!user) return;
    await supabase.from("test_scores").delete().eq("user_id", user.id);
    const rows = entries.filter(e => e.test_type && e.score).map(e => ({
      user_id: user.id,
      test_type: e.test_type,
      score: parseFloat(e.score),
      max_score: e.max_score ? parseFloat(e.max_score) : null,
      date_taken: sanitizeDate(e.date_taken),
    }));
    if (rows.length) {
      const { error } = await supabase.from("test_scores").insert(rows);
      if (error) toast.error("Failed to save test scores: " + error.message);
    }
    setTestScores(entries);
  }

  async function saveResearch(entries: ResearchEntry[]) {
    if (!user) return;
    await supabase.from("research_experience").delete().eq("user_id", user.id);
    const rows = entries.filter(e => e.title).map(e => ({
      user_id: user.id,
      title: e.title,
      organization: e.organization || null,
      description: e.description || null,
      start_date: sanitizeDate(e.start_date),
      end_date: sanitizeDate(e.end_date),
      publications: e.publications.length ? e.publications : null,
    }));
    if (rows.length) {
      const { error } = await supabase.from("research_experience").insert(rows);
      if (error) toast.error("Failed to save research: " + error.message);
    }
    setResearch(entries);
  }

  async function saveDocs(docs: DocFile[], sopText: string) {
    if (!user) return;
    await supabase.from("user_documents").delete().eq("user_id", user.id);
    if (docs.length) {
      const rows = docs.map(d => ({ user_id: user.id, document_type: d.document_type, file_url: d.file_url, file_name: d.file_name }));
      const { error } = await supabase.from("user_documents").insert(rows);
      if (error) toast.error("Failed to save documents: " + error.message);
    }
    await supabase.from("sop_entries").delete().eq("user_id", user.id);
    if (sopText.trim()) {
      const { error } = await supabase.from("sop_entries").insert({ user_id: user.id, content: sopText });
      if (error) toast.error("Failed to save SOP: " + error.message);
    }
    setDocuments(docs);
    setSop(sopText);
  }

  async function saveExtracurriculars(entries: ExtracurricularEntry[]) {
    if (!user) return;
    await supabase.from("extracurriculars").delete().eq("user_id", user.id);
    const rows = entries.filter(e => e.title).map(e => ({
      user_id: user.id,
      category: e.category,
      title: e.title,
      organization: e.organization || null,
      description: e.description || null,
      date: e.date || null,
    }));
    if (rows.length) {
      const { error } = await supabase.from("extracurriculars").insert(rows);
      if (error) toast.error("Failed to save: " + error.message);
    }
    setExtracurriculars(entries);
  }

  function getCompleteness() {
    let filled = 0;
    if (personalInfo?.full_name) filled++;
    if (education.some(e => e.degree_level && e.institution)) filled++;
    if (testScores.some(t => t.test_type && t.score)) filled++;
    if (essayProfile && Object.values(essayProfile).some(v => (v ?? "").trim())) filled++;
    if (research.some(r => r.title)) filled++;
    if (documents.length > 0 || sop.trim()) filled++;
    if (extracurriculars.some(e => e.title)) filled++;
    return Math.round((filled / 7) * 100);
  }

  function setFromResume(data: {
    personal_info?: { full_name?: string; nationality?: string; country_of_residence?: string; bio?: string };
    education?: Array<{ degree_level: string; institution: string; field_of_study?: string; gpa?: string; gpa_scale?: string; start_date?: string; end_date?: string; is_current?: boolean }>;
    test_scores?: Array<{ test_type: string; score: string; max_score?: string; date_taken?: string }>;
    research?: Array<{ title: string; organization?: string; description?: string; start_date?: string; end_date?: string; publications?: string[] }>;
    extracurriculars?: Array<{ category: string; title: string; organization?: string; description?: string; date?: string }>;
  }) {
    if (data.personal_info) {
      setPersonalInfo({
        full_name: data.personal_info.full_name ?? "",
        date_of_birth: "",
        nationality: data.personal_info.nationality ?? "",
        country_of_residence: data.personal_info.country_of_residence ?? "",
        bio: data.personal_info.bio ?? "",
        academic_level: "",
      });
    }
    if (data.education?.length) {
      setEducation(data.education.map(e => ({
        degree_level: e.degree_level,
        institution: e.institution,
        field_of_study: e.field_of_study ?? "",
        gpa: e.gpa ?? "",
        gpa_scale: e.gpa_scale ?? "",
        start_date: e.start_date ?? "",
        end_date: e.end_date ?? "",
        is_current: e.is_current ?? false,
      })));
    }
    if (data.test_scores?.length) {
      setTestScores(data.test_scores.map(t => ({
        test_type: t.test_type,
        score: t.score,
        max_score: t.max_score ?? "",
        date_taken: t.date_taken ?? "",
      })));
    }
    if (data.research?.length) {
      setResearch(data.research.map(r => ({
        title: r.title,
        organization: r.organization ?? "",
        description: r.description ?? "",
        start_date: r.start_date ?? "",
        end_date: r.end_date ?? "",
        publications: r.publications ?? [],
      })));
    }
    if (data.extracurriculars?.length) {
      setExtracurriculars(data.extracurriculars.map(e => ({
        category: e.category,
        title: e.title,
        organization: e.organization ?? "",
        description: e.description ?? "",
        date: e.date ?? "",
      })));
    }
  }

  return {
    loading,
    personalInfo,
    education,
    highSchoolSubjects,
    testScores,
    research,
    documents,
    sop,
    extracurriculars,
    essayProfile,
    savePersonalInfo,
    saveEducation,
    saveTestScores,
    saveResearch,
    saveDocs,
    saveExtracurriculars,
    saveEssayProfile,
    getCompleteness,
    setFromResume,
    reload: loadAll,
  };
}
