import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type AdvisorConversation = {
  id: string;
  title: string | null;
  created_at: string;
  updated_at: string;
};

export type AdvisorMessage = {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  created_at: string;
};

export function useAdvisorConversations() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<AdvisorConversation[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("advisor_conversations")
      .select("id,title,created_at,updated_at")
      .eq("user_id", user.id)
      .order("updated_at", { ascending: false })
      .limit(50);
    setConversations((data ?? []) as AdvisorConversation[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const createConversation = async (): Promise<AdvisorConversation | null> => {
    if (!user) return null;
    const { data, error } = await supabase
      .from("advisor_conversations")
      .insert({ user_id: user.id, title: null })
      .select()
      .single();
    if (error) return null;
    setConversations(prev => [data as AdvisorConversation, ...prev]);
    return data as AdvisorConversation;
  };

  const renameConversation = async (id: string, title: string) => {
    await supabase.from("advisor_conversations").update({ title }).eq("id", id);
    setConversations(prev => prev.map(c => (c.id === id ? { ...c, title } : c)));
  };

  const deleteConversation = async (id: string) => {
    await supabase.from("advisor_conversations").delete().eq("id", id);
    setConversations(prev => prev.filter(c => c.id !== id));
  };

  return { conversations, loading, reload: load, createConversation, renameConversation, deleteConversation };
}

export async function loadMessages(conversationId: string): Promise<AdvisorMessage[]> {
  const { data } = await supabase
    .from("advisor_messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });
  return (data ?? []) as AdvisorMessage[];
}

export async function saveMessage(conversationId: string, role: "user" | "assistant", content: string) {
  await supabase.from("advisor_messages").insert({ conversation_id: conversationId, role, content });
}
