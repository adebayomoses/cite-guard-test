import { useState, useCallback, useEffect } from "react";

const LS_PREFIX = "tour_completed_";

export interface TourStep {
  target: string; // data-tour attribute value
  title: string;
  description: string;
}

export function useOnboardingTour(tourId: string, steps: TourStep[]) {
  const lsKey = LS_PREFIX + tourId;
  const [active, setActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const isCompleted = () => localStorage.getItem(lsKey) === "true";

  // Auto-start on first visit after a short delay
  useEffect(() => {
    if (isCompleted() || steps.length === 0) return;
    const timer = setTimeout(() => setActive(true), 800);
    return () => clearTimeout(timer);
  }, [tourId, steps.length]);

  const next = useCallback(() => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((s) => s + 1);
    } else {
      finish();
    }
  }, [currentStep, steps.length]);

  const prev = useCallback(() => {
    if (currentStep > 0) setCurrentStep((s) => s - 1);
  }, [currentStep]);

  const skip = useCallback(() => {
    finish();
  }, []);

  const finish = useCallback(() => {
    setActive(false);
    setCurrentStep(0);
    localStorage.setItem(lsKey, "true");
  }, [lsKey]);

  const restart = useCallback(() => {
    setCurrentStep(0);
    setActive(true);
  }, []);

  return {
    active,
    currentStep,
    step: steps[currentStep] ?? null,
    totalSteps: steps.length,
    next,
    prev,
    skip,
    restart,
  };
}
