import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

const EPOCH = "1970-01-01T00:00:00Z";

export function useUnreadCounts() {
  const { user } = useAuth();
  const [roomUnread, setRoomUnread] = useState<Record<string, number>>({});
  const [dmUnread, setDmUnread] = useState<Record<string, number>>({});
  const lastReadRef = useRef<{ room: Record<string, string>; dm: Record<string, string> }>({
    room: {},
    dm: {},
  });

  const refresh = useCallback(async () => {
    if (!user) return;

    // Load all read-state rows for this user
    const { data: readRows } = await supabase
      .from("chat_read_state")
      .select("kind, target_id, last_read_at")
      .eq("user_id", user.id);

    const roomReads: Record<string, string> = {};
    const dmReads: Record<string, string> = {};
    (readRows ?? []).forEach((r) => {
      if (r.kind === "room") roomReads[r.target_id] = r.last_read_at;
      else if (r.kind === "dm") dmReads[r.target_id] = r.last_read_at;
    });
    lastReadRef.current = { room: roomReads, dm: dmReads };

    // Rooms
    const { data: rooms } = await supabase.from("chat_rooms").select("id");
    const roomCounts: Record<string, number> = {};
    if (rooms) {
      await Promise.all(
        rooms.map(async (r) => {
          const lastRead = roomReads[r.id] ?? EPOCH;
          const { count } = await supabase
            .from("chat_messages")
            .select("id", { count: "exact", head: true })
            .eq("room_id", r.id)
            .gt("created_at", lastRead)
            .neq("user_id", user.id);
          roomCounts[r.id] = count ?? 0;
        })
      );
    }
    setRoomUnread(roomCounts);

    // DMs — group incoming messages by sender
    const { data: dms } = await supabase
      .from("direct_messages")
      .select("sender_id, created_at")
      .eq("receiver_id", user.id);
    const dmCounts: Record<string, number> = {};
    if (dms) {
      for (const m of dms) {
        const lastRead = dmReads[m.sender_id] ?? EPOCH;
        if (m.created_at > lastRead) {
          dmCounts[m.sender_id] = (dmCounts[m.sender_id] ?? 0) + 1;
        }
      }
    }
    setDmUnread(dmCounts);
  }, [user]);

  useEffect(() => {
    if (!user) return;
    refresh();

    const channel = supabase
      .channel("unread-counts")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages" },
        (payload) => {
          const msg = payload.new as { room_id: string; user_id: string; created_at: string };
          if (msg.user_id === user.id) return;
          const lastRead = lastReadRef.current.room[msg.room_id] ?? EPOCH;
          if (msg.created_at > lastRead) {
            setRoomUnread((prev) => ({
              ...prev,
              [msg.room_id]: (prev[msg.room_id] ?? 0) + 1,
            }));
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "direct_messages" },
        (payload) => {
          const msg = payload.new as { sender_id: string; receiver_id: string; created_at: string };
          if (msg.receiver_id !== user.id) return;
          const lastRead = lastReadRef.current.dm[msg.sender_id] ?? EPOCH;
          if (msg.created_at > lastRead) {
            setDmUnread((prev) => ({
              ...prev,
              [msg.sender_id]: (prev[msg.sender_id] ?? 0) + 1,
            }));
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_read_state", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const row = (payload.new ?? payload.old) as
            | { kind: "room" | "dm"; target_id: string; last_read_at: string }
            | undefined;
          if (!row) return;
          // Sync ref so other devices get reflected
          if (row.kind === "room") {
            lastReadRef.current.room[row.target_id] = row.last_read_at;
            setRoomUnread((prev) => ({ ...prev, [row.target_id]: 0 }));
          } else {
            lastReadRef.current.dm[row.target_id] = row.last_read_at;
            setDmUnread((prev) => ({ ...prev, [row.target_id]: 0 }));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, refresh]);

  const markRead = useCallback(
    async (kind: "room" | "dm", targetId: string) => {
      if (!user) return;
      const now = new Date().toISOString();
      lastReadRef.current[kind][targetId] = now;
      if (kind === "room") {
        setRoomUnread((prev) => ({ ...prev, [targetId]: 0 }));
      } else {
        setDmUnread((prev) => ({ ...prev, [targetId]: 0 }));
      }
      await supabase
        .from("chat_read_state")
        .upsert(
          { user_id: user.id, kind, target_id: targetId, last_read_at: now },
          { onConflict: "user_id,kind,target_id" }
        );
    },
    [user]
  );

  const markRoomRead = useCallback((roomId: string) => markRead("room", roomId), [markRead]);
  const markDMRead = useCallback((otherUserId: string) => markRead("dm", otherUserId), [markRead]);

  const totalUnread =
    Object.values(roomUnread).reduce((a, b) => a + b, 0) +
    Object.values(dmUnread).reduce((a, b) => a + b, 0);

  return { roomUnread, dmUnread, totalUnread, markRoomRead, markDMRead, refresh };
}
