import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type CategoryApplySteps = Record<string, string>;

/**
 * Fetches the per-funding-category "How to apply" guides.
 * Returns a map keyed by category name (trimmed) -> markdown steps.
 * Empty strings are treated as "not set" and dropped, so the resolver can
 * fall back through: per-scholarship → category → global default.
 */
export function useCategoryApplySteps() {
  return useQuery({
    queryKey: ["funding_category_apply_steps"],
    queryFn: async (): Promise<CategoryApplySteps> => {
      const { data, error } = await (supabase as any)
        .from("funding_category_apply_steps")
        .select("category, steps");
      if (error) throw error;
      const map: CategoryApplySteps = {};
      for (const row of (data ?? []) as { category: string; steps: string | null }[]) {
        const key = row.category?.trim();
        const val = (row.steps ?? "").trim();
        if (key && val) map[key] = row.steps ?? "";
      }
      return map;
    },
    staleTime: 5 * 60 * 1000,
  });
}
