import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export interface QuickAction {
  id: string;
  label: string;
  icon_name: string;
  route: string;
  sort_order: number;
  is_enabled: boolean;
}

export function useQuickActions(enabledOnly = true) {
  const queryClient = useQueryClient();

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ["quick-actions", enabledOnly],
    queryFn: async () => {
      let q = supabase
        .from("quick_actions" as any)
        .select("id, label, icon_name, route, sort_order, is_enabled")
        .order("sort_order", { ascending: true });
      if (enabledOnly) q = q.eq("is_enabled", true);
      const { data, error } = await q;
      if (error) throw error;
      return data as unknown as QuickAction[];
    },
  });

  const toggleEnabled = useMutation({
    mutationFn: async ({ id, is_enabled }: { id: string; is_enabled: boolean }) => {
      const { error } = await (supabase.from("quick_actions" as any) as any)
        .update({ is_enabled })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["quick-actions"] }),
  });

  const swapOrder = useMutation({
    mutationFn: async ({ a, b }: { a: QuickAction; b: QuickAction }) => {
      const { error: e1 } = await (supabase.from("quick_actions" as any) as any)
        .update({ sort_order: b.sort_order })
        .eq("id", a.id);
      if (e1) throw e1;
      const { error: e2 } = await (supabase.from("quick_actions" as any) as any)
        .update({ sort_order: a.sort_order })
        .eq("id", b.id);
      if (e2) throw e2;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["quick-actions"] }),
  });

  return { actions, isLoading, toggleEnabled, swapOrder };
}
