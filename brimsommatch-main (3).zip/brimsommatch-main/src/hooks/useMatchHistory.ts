import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { MatchResult } from "@/hooks/useMatchMe";

export type MatchHistoryEntry = {
  id: string;
  user_id: string;
  scholarship_text: string;
  result: MatchResult;
  created_at: string;
};

export function useMatchHistory() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["match-history", user?.id],
    queryFn: async (): Promise<MatchHistoryEntry[]> => {
      if (!user) return [];
      const { data, error } = await (supabase as any)
        .from("match_history")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return (data ?? []) as MatchHistoryEntry[];
    },
    enabled: !!user,
    staleTime: 30_000,
  });
}

export function useSaveMatchHistory() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (payload: { scholarship_text: string; result: MatchResult }) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await (supabase as any).from("match_history").insert({
        user_id: user.id,
        scholarship_text: payload.scholarship_text,
        result: payload.result,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["match-history"] });
    },
  });
}

export function useDeleteMatchHistory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from("match_history").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["match-history"] });
    },
  });
}
