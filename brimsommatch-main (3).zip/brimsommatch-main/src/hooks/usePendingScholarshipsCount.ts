import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

/**
 * Counts pending scholarships the current user is eligible to review
 * (not their own submissions).
 */
export function usePendingScholarshipsCount() {
  const { user } = useAuth();
  const { data: count = 0 } = useQuery({
    queryKey: ["pending-scholarships-count", user?.id],
    queryFn: async () => {
      if (!user) return 0;
      const { count, error } = await supabase
        .from("scholarships")
        .select("*", { count: "exact", head: true })
        .eq("status", "pending")
        .or(`created_by.neq.${user.id},assigned_reviewer_id.eq.${user.id}`);
      if (error) throw error;
      return count ?? 0;
    },
    enabled: !!user,
    refetchInterval: 60_000,
  });
  return count;
}
