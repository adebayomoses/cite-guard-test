import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { FileText, Upload, Clock, Loader2, CheckCircle, Crown } from "lucide-react";
import { useUserSubmissions, useCreateSubmission, useCreatePackageSubmission, DocumentReviewLimitError } from "@/hooks/useDocumentSubmissions";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { useFeatureAccess } from "@/hooks/useFeatureAccess";
import UpgradeBanner from "@/components/UpgradeBanner";
import SEO from "@/components/SEO";

const SERVICE_TYPES = {
  sop: "Personal Statement / SOP Review",
  resume: "CV / Resume Review",
  research_proposal: "Research Proposal Review",
  full_package: "Full Application Package",
};

const reviewServices = [
  { key: "sop", title: SERVICE_TYPES.sop, description: "Get expert feedback on your statement of purpose or personal essay to strengthen your application.", icon: FileText, turnaround: "2-3 business days", proOnly: false },
  { key: "resume", title: SERVICE_TYPES.resume, description: "Have your academic CV or resume reviewed and optimised for scholarship applications.", icon: FileText, turnaround: "1-2 business days", proOnly: false },
  { key: "research_proposal", title: SERVICE_TYPES.research_proposal, description: "Get detailed feedback on your research proposal from experienced reviewers.", icon: FileText, turnaround: "3-5 business days", proOnly: true },
  { key: "full_package", title: SERVICE_TYPES.full_package, description: "Submit all your documents for a comprehensive review covering your entire application.", icon: Upload, turnaround: "5-7 business days", proOnly: true },
];

const FULL_PACKAGE_FIELDS = [
  { key: "Resume / CV", required: true },
  { key: "Statement of Purpose", required: true },
  { key: "Academic Transcripts", required: true },
  { key: "Recommendation Letter 1", required: false },
  { key: "Recommendation Letter 2", required: false },
  { key: "Additional Document", required: false },
];

function statusBadge(status: string) {
  switch (status) {
    case "pending": return <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending</Badge>;
    case "in_review": return <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20">In Review</Badge>;
    case "completed": return <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Completed</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function DocumentReview() {
  const { user } = useAuth();
  const { data: submissions = [], isLoading } = useUserSubmissions();
  const createSubmission = useCreateSubmission();
  const createPackage = useCreatePackageSubmission();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [packageFiles, setPackageFiles] = useState<Record<string, File | null>>({});
  const [notes, setNotes] = useState("");
  const [serverLimit, setServerLimit] = useState<{ usage: number; limit: number; period: string } | null>(null);

  const { canUse, remaining, limit, period, usage, plan } = useFeatureAccess("document_review");

  const isFullPackage = selectedService === "full_package";
  const requiredFieldsFilled = isFullPackage
    ? FULL_PACKAGE_FIELDS.filter((f) => f.required).every((f) => packageFiles[f.key])
    : !!file;

  const openSubmit = (serviceKey: string) => {
    const service = reviewServices.find((s) => s.key === serviceKey);
    if (service?.proOnly && plan !== "pro") {
      toast({ title: "Pro plan required for this service", variant: "destructive" });
      return;
    }
    if (!canUse) {
      toast({ title: "Usage limit reached — upgrade to continue", variant: "destructive" });
      return;
    }
    setSelectedService(serviceKey);
    setFile(null);
    setPackageFiles({});
    setNotes("");
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!selectedService) return;
    try {
      if (isFullPackage) {
        const filled = Object.fromEntries(
          Object.entries(packageFiles).filter(([, v]) => v != null) as [string, File][]
        );
        if (Object.keys(filled).length === 0) return;
        await createPackage.mutateAsync({ files: filled, notes });
      } else {
        if (!file) return;
        await createSubmission.mutateAsync({ serviceType: selectedService, file, notes });
      }
      setDialogOpen(false);
      toast({ title: "Document submitted!", description: "You can track progress in My Submissions." });
    } catch (e: any) {
      if (e instanceof DocumentReviewLimitError) {
        setServerLimit({ usage: e.usage, limit: e.limit, period: e.period });
        setDialogOpen(false);
        toast({ title: "Usage limit reached — upgrade to continue", variant: "destructive" });
        return;
      }
      toast({ title: "Submission failed", description: e.message, variant: "destructive" });
    }
  };

  const isPending = createSubmission.isPending || createPackage.isPending;

  return (
    <AppLayout>
      <SEO title="Document Review | Brimsom" description="Submit your SOP, CV, or essay for professional review by the Brimsom team." path="/document-review" />
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl sm:text-3xl font-bold">Document Review</h1>
          {limit !== Infinity && limit > 0 && (
            <span className={`text-xs px-2 py-1 rounded-full ${remaining <= 0 ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"}`}>
              {remaining}/{limit} remaining this month
            </span>
          )}
        </div>
        <p className="text-muted-foreground mb-8">Send your documents to experts for professional review and feedback.</p>

        {!canUse && (
          <div className="mb-6">
            <UpgradeBanner
              feature="document_review"
              currentPlan={plan}
              usage={serverLimit?.usage ?? usage}
              limit={serverLimit?.limit ?? (limit === Infinity ? 999 : limit)}
              period={serverLimit?.period ?? period}
            />
          </div>
        )}

        <Tabs defaultValue="submit" className="space-y-6">
          <TabsList>
            <TabsTrigger value="submit">Submit</TabsTrigger>
            <TabsTrigger value="submissions">My Submissions ({submissions.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="submit">
            <div className="grid sm:grid-cols-2 gap-6">
              {reviewServices.map((service) => (
                <Card key={service.key} className={`flex flex-col ${service.proOnly && plan !== "pro" ? "opacity-80" : ""}`}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                        <service.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <CardTitle className="text-lg">{service.title}</CardTitle>
                        {service.proOnly && (
                          <Badge className="bg-primary/10 text-primary border-primary/20 shrink-0">
                            <Crown className="h-3 w-3 mr-1" />
                            Pro
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 space-y-3">
                    <p className="text-sm text-muted-foreground">{service.description}</p>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      <span>{service.turnaround}</span>
                    </div>
                  </CardContent>
                  <div className="p-6 pt-0">
                    <Button size="sm" className="w-full" onClick={() => openSubmit(service.key)} disabled={!user} variant={service.proOnly && plan !== "pro" ? "outline" : "default"}>
                      {service.proOnly && plan !== "pro" ? (
                        <><Crown className="h-3.5 w-3.5 mr-1.5" />Upgrade to Pro</>
                      ) : (
                        <><Upload className="h-3.5 w-3.5 mr-1.5" />Submit for Review</>
                      )}
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="submissions">
            {isLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : submissions.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">No submissions yet. Submit a document for review to get started.</div>
            ) : (
              <div className="space-y-4">
                {submissions.map((sub) => (
                  <Card key={sub.id}>
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-medium">{SERVICE_TYPES[sub.service_type as keyof typeof SERVICE_TYPES] ?? sub.service_type}</p>
                          <p className="text-sm text-muted-foreground">{sub.file_name}</p>
                        </div>
                        {statusBadge(sub.status)}
                      </div>
                      {sub.notes && <p className="text-sm text-muted-foreground">Note: {sub.notes}</p>}
                      <p className="text-xs text-muted-foreground">Submitted {format(new Date(sub.created_at), "MMM d, yyyy")}</p>
                      {sub.status === "completed" && sub.admin_feedback && (
                        <div className="rounded-lg bg-green-500/5 border border-green-500/20 p-3 mt-2">
                          <div className="flex items-center gap-1.5 mb-1">
                            <CheckCircle className="h-3.5 w-3.5 text-green-600" />
                            <span className="text-sm font-medium text-green-700 dark:text-green-400">Feedback</span>
                          </div>
                          <p className="text-sm text-muted-foreground whitespace-pre-wrap">{sub.admin_feedback}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className={isFullPackage ? "sm:max-w-lg" : "sm:max-w-md"}>
            <DialogHeader>
              <DialogTitle>Submit for Review</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {selectedService && (SERVICE_TYPES[selectedService as keyof typeof SERVICE_TYPES] ?? selectedService)}
              </p>

              {isFullPackage ? (
                <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                  {FULL_PACKAGE_FIELDS.map((field) => (
                    <div key={field.key} className="space-y-1.5">
                      <Label className="flex items-center gap-1">
                        {field.key}
                        {field.required && <span className="text-destructive">*</span>}
                        {packageFiles[field.key] && <CheckCircle className="h-3.5 w-3.5 text-green-600 ml-auto" />}
                      </Label>
                      <Input
                        type="file"
                        accept=".pdf,.doc,.docx"
                        onChange={(e) =>
                          setPackageFiles((prev) => ({ ...prev, [field.key]: e.target.files?.[0] ?? null }))
                        }
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Upload Document (PDF, DOC, DOCX)</Label>
                  <Input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Notes (optional)</Label>
                <Textarea
                  placeholder="Any specific areas you'd like feedback on..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  maxLength={1000}
                />
              </div>
              <Button className="w-full" onClick={handleSubmit} disabled={!requiredFieldsFilled || isPending}>
                {isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                Submit
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </AppLayout>
  );
}