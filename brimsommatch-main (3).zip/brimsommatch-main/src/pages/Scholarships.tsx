import { useEffect, useState, useMemo } from "react";
import { useFeatureAccess, useTrackUsage, useSubscriptionPlan } from "@/hooks/useFeatureAccess";
import { PLAN_TIERS, type PlanId } from "@/lib/subscriptionTiers";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useCategoryApplySteps } from "@/hooks/useCategoryApplySteps";
import { useProfileData } from "@/hooks/useProfileData";
import UpgradeBanner from "@/components/UpgradeBanner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Search, RefreshCw, Loader2, Star, UserCircle, Sparkles, Globe, ChevronDown, SlidersHorizontal } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

import { useSavedScholarships } from "@/hooks/useSavedScholarships";
import { useActivityLog } from "@/hooks/useActivityLog";
import { useChanceScore } from "@/hooks/useChanceScore";
import { useScoreSingle } from "@/hooks/useScoreSingle";
import { useApplicationTracker } from "@/hooks/useApplicationTracker";

import OnboardingTour from "@/components/OnboardingTour";
import { useOnboardingTour, type TourStep } from "@/hooks/useOnboardingTour";

import SmartSummary from "@/components/scholarships/SmartSummary";
import ScholarshipCard from "@/components/scholarships/ScholarshipCard";
import { filterEligibleScholarships, hasEnoughProfileForEligibility } from "@/lib/scholarshipEligibility";
import { FIELD_OF_STUDY_OPTIONS } from "@/lib/fieldsOfStudy";
import { useScholarshipIntakesMap } from "@/hooks/useScholarshipIntakes";
import SEO from "@/components/SEO";

const scholarshipsTourSteps: TourStep[] = [
  { target: "sch-summary", title: "Your Summary", description: "See at a glance how many scholarships match your profile and where your best chances are." },
  { target: "sch-match-btn", title: "Generate Match Scores", description: "Click here to generate AI-powered match & chance scores for all scholarships based on your profile." },
  { target: "sch-tabs", title: "Browse by Category", description: "Switch between your Best Chances, Closing Soon deadlines, New This Week additions, or explore all scholarships." },
  { target: "sch-card-first", title: "Scholarship Cards", description: "Each card shows key details and AI insights. Click 'Show more' for full info, 'Ask' to chat with AI, or 'Apply Now' to start." },
];

interface Scholarship {
  id: string;
  title: string;
  description: string | null;
  provider: string | null;
  country: string | null;
  degree_level: string | null;
  field_of_study: string | null;
  funding_amount: string | null;
  funding_type: string | null;
  funding_category: string | null;
  next_close_date: string | null;
  eligibility_criteria: string | null;
  url: string | null;
  admission_requirements_url: string | null;
  min_cgpa_percentage: number | null;
  apply_steps: string | null;
  created_at: string | null;
  republished_at?: string | null;
}

// Freshness = when it was posted, or when it was auto-republished for a new cycle
const freshnessDate = (s: { created_at: string | null; republished_at?: string | null }) => {
  const created = s.created_at ? new Date(s.created_at).getTime() : 0;
  const republished = s.republished_at ? new Date(s.republished_at).getTime() : 0;
  const ts = Math.max(created, republished);
  return ts > 0 ? ts : null;
};

type TabValue = "foryou" | "recommended" | "new" | "all";

const INITIAL_SHOW = 6;

const FUNDING_CATEGORY_OPTIONS = [
  "Government Scholarships",
  "University Scholarships",
  "Assistantships",
  "Fellowships",
  "External/Private Scholarships",
] as const;

export default function Scholarships() {
  const { user } = useAuth();
  const { isAdmin } = useAdminRole();
  const navigate = useNavigate();
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [countryFilter, setCountryFilter] = useState("all");
  const [degreeFilter, setDegreeFilter] = useState("all");
  const [fieldFilter, setFieldFilter] = useState("all");
  const [chanceFilter, setChanceFilter] = useState("all");
  const [fundingCategoryFilter, setFundingCategoryFilter] = useState("all");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [personalizedFilters, setPersonalizedFilters] = useState(false);
  const [filtersApplied, setFiltersApplied] = useState(false);
  // "Explore All" eligibility toggle: default to showing only eligible matches.
  const [showAllScholarships, setShowAllScholarships] = useState(false);
  // Hide AI-scored 0% matches (ineligible per AI) on Explore All by default.
  const [hideIneligible, setHideIneligible] = useState(true);
  const { savedIds, toggleSave } = useSavedScholarships();
  const { logActivity } = useActivityLog();
  const { score, generating, generate } = useChanceScore();
  const profile = useProfileData();
  const profileCompleteness = profile.getCompleteness();
  const { canUse, remaining, limit, usage, plan, period, isLoading: featureLoading } = useFeatureAccess("score_generation");
  const { data: subData } = useSubscriptionPlan();
  const { settings } = useSiteSettings();
  const { data: categoryApplySteps } = useCategoryApplySteps();
  const userPlan = (subData?.plan ?? "free") as PlanId;
  const recLimit = useMemo(() => {
    const settingVal = settings?.[`limit_scholarship_recommendation_${userPlan}`];
    if (settingVal !== undefined && settingVal !== null) {
      const parsed = parseInt(settingVal, 10);
      if (!isNaN(parsed)) return parsed === 0 ? Infinity : parsed;
    }
    return PLAN_TIERS[userPlan].limits.scholarship_recommendation.count;
  }, [settings, userPlan]);
  const matchWeight = parseFloat(settings?.composite_match_weight ?? "0.4") || 0.4;
  const chanceWeight = parseFloat(settings?.composite_chance_weight ?? "0.6") || 0.6;
  const recThreshold = parseInt(settings?.recommendation_threshold ?? "70", 10) || 70;
  const gpaTolerancePct = (() => {
    const v = parseFloat(settings?.eligibility_gpa_tolerance_pct ?? "5");
    return isNaN(v) ? 5 : v;
  })();
  const bestTabEnabled = (settings?.best_tab_enabled ?? "true") !== "false";
  const trackUsage = useTrackUsage();
  const { applications, addApplication } = useApplicationTracker();
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());
  
  
  const [showProfilePrompt, setShowProfilePrompt] = useState(false);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [reminderType, setReminderType] = useState<"profile" | "generate" | "refresh">("profile");
  const [remindedThisSession, setRemindedThisSession] = useState(false);
  const [searchParams] = useSearchParams();
  const [showCounts, setShowCounts] = useState<Record<TabValue, number>>({
    foryou: INITIAL_SHOW,
    recommended: INITIAL_SHOW,
    new: INITIAL_SHOW,
    all: INITIAL_SHOW,
  });

  // Default to "foryou" tab — works immediately without score generation
  const [activeTab, setActiveTab] = useState<TabValue>(() => {
    const param = searchParams.get("tab");
    if (param === "recommended" || param === "best") return "recommended";
    if (param === "new") return "new";
    if (param === "all") return "all";
    if (param === "foryou") return "foryou";
    return "foryou";
  });

  // If admin disabled the Best tab while user is viewing it, switch to "foryou".
  useEffect(() => {
    if (!bestTabEnabled && activeTab === "recommended") setActiveTab("foryou");
  }, [bestTabEnabled, activeTab]);

  const tour = useOnboardingTour("scholarships", scholarshipsTourSteps);
  const trackedIds = useMemo(() => new Set(applications.map((a) => a.scholarship_id).filter(Boolean)), [applications]);

  const handleApply = async (s: Scholarship) => {
    if (!trackedIds.has(s.id)) {
      try {
        await addApplication.mutateAsync({ scholarship_id: s.id, deadline: s.next_close_date ?? undefined });
        toast.success("Added to your Application Tracker");
      } catch {}
    }
    if (user) {
      supabase.from("scholarship_apply_clicks").insert({ scholarship_id: s.id, user_id: user.id }).then(() => {});
    }
    if (s.url) window.open(s.url, "_blank");
  };

  const { scoreSingle, scoringId } = useScoreSingle();
  const [localScores, setLocalScores] = useState<Map<string, { score: number; chance: number; reason: string; chance_reason: string; pending_ai?: boolean }>>(new Map());

  const matchScores = useMemo(() => {
    const map = new Map<string, { score: number; chance: number; reason: string; chance_reason: string; pending_ai?: boolean }>();
    if (score?.scholarship_matches) {
      score.scholarship_matches.forEach((m: any) => map.set(m.scholarship_id, { score: m.score, chance: m.chance, reason: m.reason, chance_reason: m.chance_reason ?? "", pending_ai: m.pending_ai }));
    }
    localScores.forEach((v, k) => map.set(k, v));
    return map;
  }, [score, localScores]);

  const handleScoreWithAI = async (id: string) => {
    const result = await scoreSingle(id);
    if (result) {
      setLocalScores((prev) => {
        const next = new Map(prev);
        next.set(id, { score: result.score, chance: result.chance, reason: result.reason, chance_reason: result.chance_reason, pending_ai: false });
        return next;
      });
    }
  };

  const toggleCard = (id: string) => {
    setExpandedCards((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
    setExpandedSteps((prev) => { const next = new Set(prev); next.delete(id); return next; });
  };

  const toggleSteps = (id: string) => {
    setExpandedSteps((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
    setExpandedCards((prev) => { const next = new Set(prev); next.delete(id); return next; });
  };


  useEffect(() => {
    supabase
      .from("scholarships")
      .select("*")
      .eq("is_active", true)
      .order("next_close_date", { ascending: true, nullsFirst: false })
      .then(({ data }) => {
        setScholarships((data ?? []) as Scholarship[]);
        setLoading(false);
      });
  }, []);

  // Fetch intakes for all loaded scholarships (used for the per-card multi-intake display)
  const scholarshipIds = useMemo(() => scholarships.map((s) => s.id), [scholarships]);
  const { intakesMap } = useScholarshipIntakesMap(scholarshipIds);
  const effectiveDeadlines = useMemo(() => {
    const map = new Map<string, string | null>();
    scholarships.forEach((s) => {
      map.set(s.id, s.next_close_date);
    });
    return map;
  }, [scholarships]);

  const countries = useMemo(() => {
    const set = new Set<string>();
    scholarships.forEach((s) => {
      if (!s.country) return;
      s.country.split(",").forEach((part) => {
        const trimmed = part.trim();
        if (trimmed) set.add(trimmed);
      });
    });
    return [...set].sort((a, b) => a.localeCompare(b));
  }, [scholarships]);
  // Use the SAME canonical option sets as the scholarship submission form so
  // the discovery filters always line up with what providers can choose. Avoid
  // dynamically deriving from existing rows — legacy/freeform values like
  // "LLM", "Law (JD)", "All", "Architecture & Built Environment" pollute the list.
  const degrees = useMemo(() => ["BSC", "MSC", "PHD", "Diploma", "Associate", "Postdoc", "MBA"], []);
  const fields = useMemo(() => FIELD_OF_STUDY_OPTIONS.filter((f) => f !== "Any / All Fields"), []);

  // Academic level → degree filter mapping
  const ACADEMIC_TO_DEGREES: Record<string, string[]> = {
    "High School / Secondary School": [
      "High School", "Diploma", "Associate",
      "BSC", "Bachelor", "BA", "BEng", "BBA",
    ],
    "Undergraduate": [
      "BSC", "Bachelor", "BA", "BEng", "BBA",
      "MSC", "MBA", "Master", "MPhil", "MA",
    ],
    "Postgraduate (Master's / PhD)": [
      "MSC", "MBA", "Master", "MPhil", "MA",
      "PHD", "Postdoc", "Fellowship",
    ],
  };

  const NEXT_LEVEL_DEGREES: Record<string, string[]> = {
    "High School / Secondary School": ["BSC", "Bachelor", "BA", "BEng", "BBA"],
    "Undergraduate": ["MSC", "MBA", "Master", "MPhil", "MA"],
    "Postgraduate (Master's / PhD)": ["PHD", "Postdoc", "Fellowship"],
  };

  // Map the user's "intended degree level" (what they're applying for) to scholarship degree tokens.
  const INTENDED_TO_DEGREES: Record<string, string[]> = {
    "Diploma / Certificate": ["Diploma", "Certificate", "Associate"],
    "Bachelor's": ["BSC", "Bachelor", "BA", "BEng", "BBA", "Undergraduate"],
    "Master's": ["MSC", "MBA", "Master", "Masters", "MPhil", "MA"],
    "PhD / Doctorate": ["PHD", "Doctorate", "Doctoral"],
    "Postdoctoral": ["Postdoc", "Postdoctoral", "Fellowship"],
    "Exchange / Short Program": ["Exchange", "Short Program"],
  };

  // Auto-apply personalized filters on first load
  useEffect(() => {
    if (filtersApplied || loading || scholarships.length === 0 || profile.loading) return;
    setFiltersApplied(true);

    const userCountry = profile.personalInfo?.country_of_residence || profile.personalInfo?.nationality || "";
    const userLevel = profile.personalInfo?.academic_level || "";
    const intendedLevel = (profile.personalInfo as any)?.intended_degree_level || "";
    const userFields = profile.education.map(e => e.field_of_study).filter(Boolean) as string[];

    let anySet = false;

    // Note: Country filter is NOT auto-applied because students look for scholarships abroad.

    // Auto-set degree filter — prefer the user's stated intended degree level.
    const intendedTokens = INTENDED_TO_DEGREES[intendedLevel] || [];
    if (intendedTokens.length) {
      const matchingIntended = degrees.find(d => intendedTokens.some(m => d.toLowerCase() === m.toLowerCase()));
      if (matchingIntended) {
        setDegreeFilter(matchingIntended);
        anySet = true;
      }
    }
    // Fallback: derive from current academic level (next level up).
    if (!anySet && userLevel && ACADEMIC_TO_DEGREES[userLevel]) {
      const nextLevel = NEXT_LEVEL_DEGREES[userLevel] || [];
      const matchingNext = degrees.find(d => nextLevel.some(m => d.toLowerCase() === m.toLowerCase()));
      const matchingCurrent = degrees.find(d => ACADEMIC_TO_DEGREES[userLevel].some(m => d.toLowerCase() === m.toLowerCase()));
      const matchingDegree = matchingNext || matchingCurrent;
      if (matchingDegree) {
        setDegreeFilter(matchingDegree);
        anySet = true;
      }
    }

    // Auto-apply field of study from profile education (first match).
    if (userFields.length) {
      const matchingField = fields.find(f =>
        userFields.some(uf =>
          f.toLowerCase() === uf.toLowerCase() ||
          f.toLowerCase().includes(uf.toLowerCase()) ||
          uf.toLowerCase().includes(f.toLowerCase())
        )
      );
      if (matchingField) {
        setFieldFilter(matchingField);
        anySet = true;
      }
    }

    if (anySet) setPersonalizedFilters(true);
  }, [loading, scholarships, profile.loading, profile.personalInfo, profile.education, countries, degrees, fields, filtersApplied]);


  // Relevance scoring for Explore All
  const getRelevanceScore = useMemo(() => {
    const userCountry = profile.personalInfo?.country_of_residence || "";
    const userNationality = profile.personalInfo?.nationality || "";
    const userLevel = profile.personalInfo?.academic_level || "";
    const userFields = profile.education.map(e => (e.field_of_study || "").toLowerCase()).filter(Boolean);
    const nextDegrees = (NEXT_LEVEL_DEGREES[userLevel] || []).map(d => d.toLowerCase());
    const allDegrees = (ACADEMIC_TO_DEGREES[userLevel] || []).map(d => d.toLowerCase());

    return (s: Scholarship) => {
      let score = 0;
      if (s.country && (s.country === userCountry || s.country === userNationality)) score += 3;
      if (s.degree_level && allDegrees.length) {
        const sDegrees = s.degree_level.split(",").map(d => d.trim().toLowerCase());
        if (sDegrees.some(d => nextDegrees.includes(d))) score += 3;
        else if (sDegrees.some(d => allDegrees.includes(d))) score += 2;
      }
      if (s.field_of_study && userFields.length) {
        const sFields = s.field_of_study.split(",").map(f => f.trim().toLowerCase());
        if (sFields.some(sf => userFields.some(uf => sf.includes(uf) || uf.includes(sf)))) score += 2;
      }
      return score;
    };
  }, [profile.personalInfo, profile.education]);

  // Base filtered list (search + filters applied). Drops scholarships whose
  // legacy deadline has passed AND that have no upcoming intake close_date.
  const today = useMemo(() => new Date().toISOString().split("T")[0], []);
  const filtered = useMemo(() => {
    return scholarships.filter((s) => {
      // Hide expired: no upcoming close date at all
      if (!s.next_close_date) {
        // Still allow rolling/no-deadline scholarships (no intakes yet)
        // — they're filtered out only if they ever had a past close that's now gone.
      } else if (s.next_close_date < today) {
        return false;
      }

      if (search && !s.title.toLowerCase().includes(search.toLowerCase()) && !s.provider?.toLowerCase().includes(search.toLowerCase())) return false;
      if (countryFilter !== "all") {
        const parts = (s.country || "").split(",").map((c) => c.trim()).filter(Boolean);
        if (!parts.includes(countryFilter)) return false;
      }
      if (degreeFilter !== "all") {
        const dl = (s.degree_level || "").trim().toLowerCase();
        if (dl && dl !== "any" && !dl.split(",").map(d => d.trim()).includes(degreeFilter.toLowerCase())) return false;
      }
      if (fieldFilter !== "all") {
        const fs = (s.field_of_study || "").trim().toLowerCase();
        if (fs && fs !== "any" && !fs.split(",").map(f => f.trim()).includes(fieldFilter.toLowerCase())) return false;
      }
      if (chanceFilter !== "all") {
        const m = matchScores.get(s.id);
        const minChance = parseInt(chanceFilter, 10);
        if (!m || m.chance < minChance) return false;
      }
      if (fundingCategoryFilter !== "all") {
        if ((s.funding_category || "").trim() !== fundingCategoryFilter) return false;
      }
      return true;
    });
  }, [scholarships, intakesMap, today, search, countryFilter, degreeFilter, fieldFilter, chanceFilter, fundingCategoryFilter, matchScores]);

  // ── Tab-specific lists ──

  // "For You": AI-scored scholarships with match ≥ 40% — broader personalized view
  // Uses country round-robin so no single country dominates the top slots.
  const forYouThreshold = parseInt(settings?.foryou_threshold ?? "40", 10) || 40;
  const forYouList = useMemo(() => {
    const eligible = filtered
      .filter((s) => {
        const m = matchScores.get(s.id);
        return m && !m.pending_ai ? m.score >= forYouThreshold : false;
      })
      .sort((a, b) => {
        const ma = matchScores.get(a.id)!;
        const mb = matchScores.get(b.id)!;
        return (matchWeight * mb.score + chanceWeight * mb.chance) - (matchWeight * ma.score + chanceWeight * ma.chance);
      });

    // Round-robin by country, preserving score order within each country
    const byCountry = new Map<string, typeof eligible>();
    for (const s of eligible) {
      const key = s.country ?? "__unknown__";
      if (!byCountry.has(key)) byCountry.set(key, []);
      byCountry.get(key)!.push(s);
    }
    const buckets = Array.from(byCountry.values());
    const interleaved: typeof eligible = [];
    let added = true;
    while (added) {
      added = false;
      for (const bucket of buckets) {
        const next = bucket.shift();
        if (next) {
          interleaved.push(next);
          added = true;
        }
      }
    }
    return interleaved;
  }, [filtered, matchScores, forYouThreshold, matchWeight, chanceWeight]);

  // Recommended: scholarships meeting the recommendation threshold, with an
  // urgency boost so scholarships closing soon float toward the top.
  const urgencyDays = parseInt(settings?.recommended_urgency_days ?? "60", 10) || 60;
  const urgencyBoost = parseFloat(settings?.recommended_urgency_boost ?? "15") || 15;
  const allRecommended = useMemo(() => {
    const nowMs = Date.now();
    const urgencyScore = (closeDate: string | null | undefined) => {
      if (!closeDate) return 0;
      const daysLeft = (new Date(closeDate).getTime() - nowMs) / (1000 * 60 * 60 * 24);
      if (isNaN(daysLeft) || daysLeft < 0 || daysLeft > urgencyDays) return 0;
      return urgencyBoost * (1 - daysLeft / urgencyDays);
    };
    return filtered
      .filter((s) => {
        const m = matchScores.get(s.id);
        return m && !m.pending_ai ? m.score >= recThreshold && m.chance >= recThreshold : false;
      })
      .sort((a, b) => {
        const ma = matchScores.get(a.id)!;
        const mb = matchScores.get(b.id)!;
        const baseA = matchWeight * ma.score + chanceWeight * ma.chance + urgencyScore(a.next_close_date);
        const baseB = matchWeight * mb.score + chanceWeight * mb.chance + urgencyScore(b.next_close_date);
        return baseB - baseA;
      });
  }, [filtered, matchScores, recThreshold, matchWeight, chanceWeight, urgencyDays, urgencyBoost]);

  const bestChances = useMemo(() => {
    if (recLimit === Infinity) return allRecommended;
    return allRecommended.slice(0, recLimit);
  }, [allRecommended, recLimit]);

  const recommendedIds = useMemo(() => new Set(bestChances.map((s) => s.id)), [bestChances]);

  // Closing Soon: effective deadlines within 21 days (uses earliest of legacy
  // deadline + upcoming intake close_dates).
  const closingSoon = useMemo(() => {
    const now = Date.now();
    const cutoff = now + 21 * 24 * 60 * 60 * 1000;
    return filtered
      .map((s) => ({ s, eff: effectiveDeadlines.get(s.id) }))
      .filter(({ eff }) => {
        if (!eff) return false;
        const dl = new Date(eff).getTime();
        return dl >= now && dl <= cutoff;
      })
      .sort((a, b) => new Date(a.eff!).getTime() - new Date(b.eff!).getTime())
      .map(({ s }) => s);
  }, [filtered, effectiveDeadlines]);

  const closingSoonIds = useMemo(() => new Set(closingSoon.map((s) => s.id)), [closingSoon]);

  // New This Week: posted OR auto-republished within last 7 days
  const sevenDaysAgo = useMemo(() => Date.now() - 7 * 24 * 60 * 60 * 1000, []);
  const newThisWeek = useMemo(() =>
    filtered
      .filter((s) => {
        const ts = freshnessDate(s);
        return ts !== null && ts >= sevenDaysAgo;
      })
      .sort((a, b) => (freshnessDate(b) ?? 0) - (freshnessDate(a) ?? 0)),
    [filtered, sevenDaysAgo]
  );

  const newIds = useMemo(() => new Set(newThisWeek.map((s) => s.id)), [newThisWeek]);

  // Eligibility prefilter (deterministic, mirrors backend logic).
  // Only narrows Explore All so users see scholarships they're realistically eligible for.
  // Falls back to the full list if the user's profile is too thin to filter meaningfully.
  const profileRichEnough = useMemo(
    () => hasEnoughProfileForEligibility(profile.personalInfo, profile.education),
    [profile.personalInfo, profile.education]
  );
  const eligibilityFilterActive = profileRichEnough && !showAllScholarships;
  const eligibleFiltered = useMemo(() => {
    if (!eligibilityFilterActive) return filtered;
    return filterEligibleScholarships(filtered, profile.personalInfo, profile.education, gpaTolerancePct);
  }, [filtered, eligibilityFilterActive, profile.personalInfo, profile.education, gpaTolerancePct]);
  const eligibilityHiddenCount = filtered.length - eligibleFiltered.length;

  // Ineligible (0%) filter — hides scholarships the AI scored as 0 match or 0 chance.
  // Only meaningful when scores exist; "pending_ai" placeholders are kept visible.
  const ineligibleHiddenCount = useMemo(() => {
    if (!hideIneligible) return 0;
    return eligibleFiltered.reduce((n, s) => {
      const m = matchScores.get(s.id);
      if (!m || m.pending_ai) return n;
      return m.score === 0 || m.chance === 0 ? n + 1 : n;
    }, 0);
  }, [eligibleFiltered, matchScores, hideIneligible]);

  // Explore All: sorted with recommended first, then composite, then relevance
  const exploreAll = useMemo(() => {
    const base = hideIneligible
      ? eligibleFiltered.filter((s) => {
          const m = matchScores.get(s.id);
          if (!m || m.pending_ai) return true;
          return m.score > 0 && m.chance > 0;
        })
      : eligibleFiltered;
    return [...base].sort((a, b) => {
      const recA = recommendedIds.has(a.id);
      const recB = recommendedIds.has(b.id);
      if (recA !== recB) return recA ? -1 : 1;
      const ma = matchScores.get(a.id);
      const mb = matchScores.get(b.id);
      const compA = ma ? (matchWeight * ma.score) + (chanceWeight * ma.chance) : -1;
      const compB = mb ? (matchWeight * mb.score) + (chanceWeight * mb.chance) : -1;
      if (compA !== compB) return compB - compA;
      return getRelevanceScore(b) - getRelevanceScore(a);
    });
  }, [eligibleFiltered, recommendedIds, matchScores, matchWeight, chanceWeight, getRelevanceScore, hideIneligible]);

  // Dashboard-driven view slicing: ?view=top | closing | eligible
  const forYouView = searchParams.get("view");
  const forYouViewList = useMemo(() => {
    if (forYouView === "top") return forYouList.slice(0, 5);
    if (forYouView === "closing") {
      const now = Date.now();
      const cutoff = now + 30 * 24 * 60 * 60 * 1000;
      return forYouList.filter((s) => {
        if (!s.next_close_date) return false;
        const t = new Date(s.next_close_date).getTime();
        return t >= now && t <= cutoff;
      });
    }
    if (forYouView === "eligible") return eligibleFiltered;
    if (forYouView === "matched") return forYouList;
    return forYouList;
  }, [forYouView, forYouList, eligibleFiltered]);

  const forYouViewLabel =
    forYouView === "top" ? "🎯 Top Picks — your 5 strongest matches" :
    forYouView === "closing" ? "⏰ Closing soon — matches with deadlines within 30 days" :
    forYouView === "matched" ? "✅ Matched — scholarships that meet your match threshold" :
    forYouView === "eligible" ? "🔍 Eligible — every scholarship you qualify for" :
    null;

  const tabData: Record<TabValue, { list: Scholarship[]; label: string; emptyTitle: string; emptyDesc: string }> = {
    foryou: {
      list: forYouViewList,
      label: forYouViewLabel ?? `${forYouViewList.length} scholarship${forYouViewList.length !== 1 ? "s" : ""} personalized for you`,
      emptyTitle: matchScores.size === 0
        ? "Generate scores to see personalized results"
        : "No personalized matches yet",
      emptyDesc: matchScores.size === 0
        ? "Click \"Generate Match Scores\" to let our AI analyze your profile and find scholarships tailored to you."
        : "Based on your current profile, no scholarships meet the personalization threshold. Keep your profile updated — new scholarships are added regularly.",
    },

    recommended: {
      list: bestChances,
      label: "Scholarships we recommend for you to apply",
      emptyTitle: matchScores.size === 0
        ? "Generate scores to see recommendations"
        : "No strong matches found yet",
      emptyDesc: matchScores.size === 0
        ? "Click \"Generate Match Scores\" to let our AI analyze your profile and find scholarships where you have the best chances."
        : "Based on your current profile, none meet our recommendation criteria. Keep your profile updated — new scholarships are added regularly.",
    },
    new: {
      list: newThisWeek,
      label: `${newThisWeek.length} new scholarship${newThisWeek.length !== 1 ? "s" : ""} added this week`,
      emptyTitle: "No new scholarships this week",
      emptyDesc: "Check back soon — new scholarships are added regularly.",
    },
    all: {
      list: exploreAll,
      label: `${exploreAll.length} scholarship${exploreAll.length !== 1 ? "s" : ""} available`,
      emptyTitle: "No scholarships match your filters",
      emptyDesc: "Try adjusting your search or filter criteria.",
    },
  };

  const currentTab = tabData[activeTab];
  const displayList = currentTab.list;
  const visibleCount = showCounts[activeTab];
  const visibleList = displayList.slice(0, visibleCount);
  const hasMore = displayList.length > visibleCount;

  const handleShowMore = () => {
    setShowCounts((prev) => ({
      ...prev,
      [activeTab]: prev[activeTab] + INITIAL_SHOW,
    }));
  };

  const handleTabChange = (v: string) => {
    setActiveTab(v as TabValue);
    // Show reminder once per session per page visit
    if (remindedThisSession || profile.loading) return;

    if (profileCompleteness < 50) {
      setReminderType("profile");
      setReminderOpen(true);
      setRemindedThisSession(true);
      return;
    }
    if (matchScores.size === 0) {
      setReminderType("generate");
      setReminderOpen(true);
      setRemindedThisSession(true);
      return;
    }
    // Refresh reminder — throttled to max 2/day
    try {
      const today = new Date().toISOString().split("T")[0];
      const raw = localStorage.getItem("scholarshipsReminderShown");
      const parsed = raw ? JSON.parse(raw) as { date: string; count: number } : null;
      const current = parsed && parsed.date === today ? parsed : { date: today, count: 0 };
      if (current.count < 2) {
        setReminderType("refresh");
        setReminderOpen(true);
        setRemindedThisSession(true);
        localStorage.setItem("scholarshipsReminderShown", JSON.stringify({ date: today, count: current.count + 1 }));
      }
    } catch {}
  };

  return (
    <AppLayout>
      <SEO title="Browse Scholarships | Brimsom" description="Discover and filter hundreds of international scholarships matched to your profile." path="/scholarships" />
      <main className="container mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
              <BackButton iconOnly />
              Discover Scholarships
            </h1>
            <p className="text-muted-foreground text-sm">Personalized scholarship discovery powered by AI</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="text-xs">
              {limit === Infinity ? "Unlimited" : `${remaining}/${limit} left`}
            </Badge>
            <Button
              data-tour="sch-match-btn"
              onClick={() => {
                if (profileCompleteness < 50) { setShowProfilePrompt(true); return; }
                if (!canUse) { toast.error("Usage limit reached — upgrade to continue"); return; }
                generate(logActivity).then(() => trackUsage.mutate("score_generation"));
              }}
              disabled={generating || featureLoading}
              variant="default"
              size="sm"
            >
              {generating ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <RefreshCw className="h-4 w-4 mr-1" />}
              {generating ? "Generating..." : "Generate Match Scores"}
            </Button>
          </div>
        </div>

        {!featureLoading && !canUse && (
          <UpgradeBanner
            feature="score_generation"
            currentPlan={plan}
            usage={usage}
            limit={limit === Infinity ? 999 : limit}
            period={period}
          />
        )}

        {/* Smart Summary Hero */}
        <div data-tour="sch-summary">
          <SmartSummary
            bestChancesCount={bestChances.length}
            closingSoonCount={closingSoon.length}
            newCount={newThisWeek.length}
            hasScores={matchScores.size > 0}
            profileCompleteness={profileCompleteness}
            generating={generating}
            onGenerate={() => {
              if (profileCompleteness < 50) { setShowProfilePrompt(true); return; }
              if (!canUse) { toast.error("Usage limit reached — upgrade to continue"); return; }
              generate(logActivity).then(() => trackUsage.mutate("score_generation"));
            }}
          />
        </div>

        {/* Tabs — contextual grouping */}
        <Tabs data-tour="sch-tabs" value={activeTab} onValueChange={handleTabChange}>
          <TabsList className={`w-full grid ${bestTabEnabled ? "grid-cols-4" : "grid-cols-3"} bg-primary/10 border border-primary/20 rounded-xl p-1 animate-in fade-in slide-in-from-bottom-2 duration-500`}>
            <TabsTrigger value="foryou" className="group gap-1 text-[11px] sm:text-sm px-1 sm:px-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
              <UserCircle className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
              <span className="truncate">For You</span>
              {forYouList.length > 0 && (
                <Badge className="ml-0.5 text-[10px] px-1.5 py-0 shrink-0 bg-primary/15 text-primary border-primary/20 group-data-[state=active]:bg-primary-foreground/20 group-data-[state=active]:text-primary-foreground group-data-[state=active]:border-primary-foreground/30">{forYouList.length}</Badge>
              )}
            </TabsTrigger>
            {bestTabEnabled && (
              <TabsTrigger value="recommended" className="group gap-1 text-[11px] sm:text-sm px-1 sm:px-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
                <Star className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
                <span className="truncate">Best</span>
                {bestChances.length > 0 && (
                  <Badge className="ml-0.5 text-[10px] px-1.5 py-0 shrink-0 bg-primary/15 text-primary border-primary/20 group-data-[state=active]:bg-primary-foreground/20 group-data-[state=active]:text-primary-foreground group-data-[state=active]:border-primary-foreground/30">{bestChances.length}</Badge>
                )}
              </TabsTrigger>
            )}
            <TabsTrigger value="new" className="group gap-1 text-[11px] sm:text-sm px-1 sm:px-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
              <Sparkles className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
              <span className="truncate">New</span>
              {newThisWeek.length > 0 && (
                <Badge className="ml-0.5 text-[10px] px-1.5 py-0 shrink-0 bg-primary/15 text-primary border-primary/20 group-data-[state=active]:bg-primary-foreground/20 group-data-[state=active]:text-primary-foreground group-data-[state=active]:border-primary-foreground/30">{newThisWeek.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="all" className="group gap-1 text-[11px] sm:text-sm px-1 sm:px-3 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm transition-all">
              <Globe className="h-3 w-3 sm:h-3.5 sm:w-3.5 shrink-0" />
              <span className="truncate">Explore All</span>
              {exploreAll.length > 0 && (
                <Badge className="ml-0.5 text-[10px] px-1.5 py-0 shrink-0 bg-primary/15 text-primary border-primary/20 group-data-[state=active]:bg-primary-foreground/20 group-data-[state=active]:text-primary-foreground group-data-[state=active]:border-primary-foreground/30">{exploreAll.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Tab subheading */}
        {displayList.length > 0 && (
          <p className="text-sm text-muted-foreground font-medium">{currentTab.label}</p>
        )}

        {activeTab === "foryou" && forYouView && (
          <button
            onClick={() => navigate("/scholarships?tab=foryou")}
            className="inline-flex items-center gap-1 self-start rounded-full border border-primary/30 bg-primary/10 hover:bg-primary/15 text-primary text-xs px-2.5 py-1 transition-colors"
          >
            Clear view · show all personalized
          </button>
        )}


        {/* Upgrade nudge for Best Chances */}
        {activeTab === "recommended" && allRecommended.length > bestChances.length && (
          <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-4 py-2.5">
            <Star className="h-4 w-4 text-primary shrink-0" />
            <p className="text-sm text-muted-foreground">
              Showing <strong>{bestChances.length}</strong> of <strong>{allRecommended.length}</strong> recommendations ({PLAN_TIERS[userPlan].name} plan).{" "}
              <button onClick={() => navigate("/pricing")} className="text-primary hover:underline font-medium">
                Upgrade for more
              </button>
            </p>
          </div>
        )}

        {/* Eligibility filter banner — only on Explore All */}
        {activeTab === "all" && profileRichEnough && (
          <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-4 py-2.5">
            <Sparkles className="h-4 w-4 text-primary shrink-0" />
            <p className="text-sm text-muted-foreground flex-1">
              {showAllScholarships ? (
                <>Showing <strong>all {filtered.length}</strong> active scholarships.</>
              ) : (
                <>
                  Showing <strong>{eligibleFiltered.length}</strong> scholarships you're eligible for
                  {eligibilityHiddenCount > 0 && <> · {eligibilityHiddenCount} hidden</>}
                </>
              )}
            </p>
            <button
              onClick={() => setShowAllScholarships(!showAllScholarships)}
              className="text-primary hover:underline font-medium text-xs whitespace-nowrap"
            >
              {showAllScholarships ? "Show eligible only" : "Show all"}
            </button>
          </div>
        )}

        {/* Ineligible (0%) toggle — only on Explore All when AI scores exist */}
        {activeTab === "all" && matchScores.size > 0 && (ineligibleHiddenCount > 0 || !hideIneligible) && (
          <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-4 py-2.5">
            <p className="text-sm text-muted-foreground flex-1">
              {hideIneligible ? (
                <>Hiding <strong>{ineligibleHiddenCount}</strong> ineligible (0%) scholarship{ineligibleHiddenCount !== 1 ? "s" : ""} based on AI evaluation.</>
              ) : (
                <>Showing ineligible (0%) scholarships in the list.</>
              )}
            </p>
            <button
              onClick={() => setHideIneligible(!hideIneligible)}
              className="text-primary hover:underline font-medium text-xs whitespace-nowrap"
            >
              {hideIneligible ? "Show ineligible" : "Hide ineligible"}
            </button>
          </div>
        )}
        <div data-tour="sch-filters" className="space-y-3">
          {/* Search bar + filter toggle (mobile) */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by title or provider..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Button
              variant="outline"
              size="icon"
              className="sm:hidden relative shrink-0"
              onClick={() => setFiltersOpen(!filtersOpen)}
            >
              <SlidersHorizontal className="h-4 w-4" />
              {(() => {
                const count = [countryFilter, degreeFilter, fieldFilter, chanceFilter, fundingCategoryFilter].filter(v => v !== "all").length;
                return count > 0 ? (
                  <span className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold">{count}</span>
                ) : null;
              })()}
            </Button>
          </div>

          {/* Filter dropdowns — collapsible on mobile, always visible on sm+ */}
          <div className={`grid grid-cols-2 gap-2 sm:flex sm:flex-row sm:gap-3 ${filtersOpen ? "" : "hidden sm:flex"}`}>
            <Select value={countryFilter} onValueChange={setCountryFilter}>
              <SelectTrigger className="w-full sm:w-[160px]"><SelectValue placeholder="Country" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                {countries.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={degreeFilter} onValueChange={setDegreeFilter}>
              <SelectTrigger className="w-full sm:w-[160px]"><SelectValue placeholder="Degree" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Degrees</SelectItem>
                {degrees.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={fieldFilter} onValueChange={setFieldFilter}>
              <SelectTrigger className="w-full sm:w-[160px]"><SelectValue placeholder="Field" /></SelectTrigger>
              <SelectContent className="max-w-[calc(100vw-2rem)] w-[calc(100vw-2rem)] sm:w-auto">
                <SelectItem value="all">All Fields</SelectItem>
                {fields.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}
              </SelectContent>
            </Select>
            {matchScores.size > 0 && (
              <Select value={chanceFilter} onValueChange={setChanceFilter}>
                <SelectTrigger className="w-full sm:w-[160px]"><SelectValue placeholder="Chance Score" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Chance</SelectItem>
                  <SelectItem value="80">80%+ Chance</SelectItem>
                  <SelectItem value="60">60%+ Chance</SelectItem>
                  <SelectItem value="40">40%+ Chance</SelectItem>
                  <SelectItem value="20">20%+ Chance</SelectItem>
                </SelectContent>
              </Select>
            )}
            {(settings?.funding_category_filter_enabled ?? "true") !== "false" && (
              <Select value={fundingCategoryFilter} onValueChange={setFundingCategoryFilter}>
                <SelectTrigger className="w-full sm:w-[180px]"><SelectValue placeholder="Funding Category" /></SelectTrigger>
                <SelectContent className="max-w-[calc(100vw-2rem)] w-[calc(100vw-2rem)] sm:w-auto">
                  <SelectItem value="all">All Funding Categories</SelectItem>
                  {FUNDING_CATEGORY_OPTIONS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Personalized filters banner */}
          {personalizedFilters && (
            <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-sm">
              <Sparkles className="h-3.5 w-3.5 text-primary shrink-0" />
              <span className="text-muted-foreground">Filtered for your profile</span>
              <button
                className="text-primary hover:underline font-medium ml-auto text-xs"
                onClick={() => {
                  setCountryFilter("all");
                  setDegreeFilter("all");
                  setFieldFilter("all");
                  setChanceFilter("all");
                  setFundingCategoryFilter("all");
                  setPersonalizedFilters(false);
                }}
              >
                Show All
              </button>
            </div>
          )}
        </div>

        {/* Results */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading scholarships...</div>
        ) : displayList.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <p className="text-muted-foreground font-medium">{currentTab.emptyTitle}</p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">{currentTab.emptyDesc}</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {visibleList.map((s, idx) => (
              <ScholarshipCard
                key={s.id}
                scholarship={s}
                matchData={matchScores.get(s.id)}
                isRecommended={recommendedIds.has(s.id)}
                isSaved={savedIds.has(s.id)}
                isExpanded={expandedCards.has(s.id)}
                isStepsExpanded={expandedSteps.has(s.id)}
                isClosingSoon={closingSoonIds.has(s.id)}
                isNew={newIds.has(s.id)}
                defaultApplySteps={settings?.default_apply_steps}
                categoryApplySteps={categoryApplySteps}
                isAdmin={isAdmin}
                onToggleSave={() => toggleSave(s.id, logActivity)}
                onToggleExpand={() => toggleCard(s.id)}
                onToggleSteps={() => toggleSteps(s.id)}
                
                onAsk={() => navigate("/brim-chat", {
                  state: {
                    scholarship: {
                      title: s.title,
                      provider: s.provider,
                      country: s.country,
                      degree_level: s.degree_level,
                      funding_amount: s.funding_amount,
                      deadline: s.next_close_date,
                      description: s.description,
                      eligibility_criteria: s.eligibility_criteria,
                    },
                  },
                })}
                onApply={() => handleApply(s)}
                isScoring={scoringId === s.id}
                onScoreWithAI={(!matchScores.get(s.id) || matchScores.get(s.id)?.pending_ai) ? () => handleScoreWithAI(s.id) : undefined}
                tourAttr={idx === 0 ? { "data-tour": "sch-card-first" } : undefined}
              />
            ))}

            {/* Progressive disclosure — Show More */}
            {hasMore && (
              <Button
                variant="outline"
                className="w-full rounded-xl text-sm"
                onClick={handleShowMore}
              >
                <ChevronDown className="h-4 w-4 mr-1.5" />
                Show {Math.min(INITIAL_SHOW, displayList.length - visibleCount)} more
                <span className="text-muted-foreground ml-1.5">
                  ({visibleCount} of {displayList.length})
                </span>
              </Button>
            )}
          </div>
        )}
      </main>

      {tour.step && (
        <OnboardingTour
          active={tour.active}
          target={tour.step.target}
          title={tour.step.title}
          description={tour.step.description}
          currentStep={tour.currentStep}
          totalSteps={tour.totalSteps}
          onNext={tour.next}
          onPrev={tour.prev}
          onSkip={tour.skip}
        />
      )}

      <Dialog open={showProfilePrompt} onOpenChange={setShowProfilePrompt}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <UserCircle className="h-6 w-6 text-primary" />
            </div>
            <DialogTitle className="text-center">Complete Your Profile First</DialogTitle>
            <DialogDescription className="text-center">
              Your profile is currently <strong>{profileCompleteness}%</strong> complete. You need at least 50% completion to generate match and chance scores.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Progress value={profileCompleteness} className="h-2" />
            <p className="text-xs text-muted-foreground text-center">
              A more complete profile means more accurate results.
            </p>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setShowProfilePrompt(false)} className="w-full sm:w-auto">
              Close
            </Button>
            <Button asChild className="w-full sm:w-auto">
              <Link to="/profile">Go to Profile</Link>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={reminderOpen} onOpenChange={setReminderOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              {reminderType === "profile" ? (
                <UserCircle className="h-6 w-6 text-primary" />
              ) : (
                <Sparkles className="h-6 w-6 text-primary" />
              )}
            </div>
            <DialogTitle className="text-center">
              {reminderType === "profile" && "Complete your profile"}
              {reminderType === "generate" && "Generate your personalized matches"}
              {reminderType === "refresh" && "Refresh your matches"}
            </DialogTitle>
            <DialogDescription className="text-center">
              {reminderType === "profile" && `Your profile is ${profileCompleteness}% complete. Finish it to unlock personalized scholarship matches and chance scores.`}
              {reminderType === "generate" && "Let our AI analyze your profile and recommend the best scholarships tailored to you."}
              {reminderType === "refresh" && "New scholarships are added regularly. Regenerate your matches to make sure you're seeing the latest opportunities for you."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setReminderOpen(false)} className="w-full sm:w-auto">
              Maybe later
            </Button>
            {reminderType === "profile" ? (
              <Button asChild className="w-full sm:w-auto">
                <Link to="/profile">Update Profile</Link>
              </Button>
            ) : (
              <Button asChild className="w-full sm:w-auto">
                <Link to="/score">{reminderType === "generate" ? "Generate Matches" : "Refresh Matches"}</Link>
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
