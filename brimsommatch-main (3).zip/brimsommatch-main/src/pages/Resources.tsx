import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, ExternalLink } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import SEO from "@/components/SEO";

function extractYouTubeId(url: string): string | null {
  const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|shorts\/))([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
}

export default function Resources() {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);

  const { data: tabs = [], isLoading: tabsLoading } = useQuery({
    queryKey: ["resource-tabs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("resource_tabs")
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const { data: resources = [], isLoading: resLoading } = useQuery({
    queryKey: ["resources"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("resources")
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return data;
    },
  });

  const defaultTab = tabs.find((t: any) => t.is_default)?.id ?? tabs[0]?.id;
  const loading = tabsLoading || resLoading;

  return (
    <AppLayout>
      <SEO title="Resources | Brimsom" description="Guides, videos, and resources to help you win international scholarships." path="/resources" />
      <main className="container mx-auto px-4 py-12 max-w-5xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Resources</h1>
        <p className="text-muted-foreground mb-8">Videos, guides and links to help your scholarship journey.</p>

        {loading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-64" />
            <Skeleton className="h-40 w-full" />
          </div>
        ) : tabs.length === 0 ? (
          <p className="text-muted-foreground">No resources available yet.</p>
        ) : (
          <Tabs defaultValue={defaultTab} className="space-y-6">
            <TabsList className="flex-wrap h-auto">
              {tabs.map((tab: any) => (
                <TabsTrigger key={tab.id} value={tab.id}>{tab.name}</TabsTrigger>
              ))}
            </TabsList>

            {tabs.map((tab: any) => {
              const tabResources = resources.filter((r: any) => r.tab_id === tab.id);
              return (
                <TabsContent key={tab.id} value={tab.id}>
                  {tabResources.length === 0 ? (
                    <p className="text-muted-foreground py-8 text-center">No resources in this category yet.</p>
                  ) : (
                    <div className="grid gap-4 sm:grid-cols-2">
                      {tabResources.map((res: any) => {
                        const videoId = res.youtube_url ? extractYouTubeId(res.youtube_url) : null;
                        return (
                          <Card key={res.id} className="flex flex-col">
                            {videoId && (
                              <div
                                className="relative cursor-pointer group"
                                onClick={() => setVideoUrl(res.youtube_url)}
                              >
                                <img
                                  src={`https://img.youtube.com/vi/${videoId}/mqdefault.jpg`}
                                  alt={res.title}
                                  className="w-full aspect-video object-cover rounded-t-lg"
                                  loading="lazy"
                                />
                                <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/50 transition-colors rounded-t-lg">
                                  <Play className="h-10 w-10 text-white fill-white" />
                                </div>
                              </div>
                            )}
                            <CardHeader className={videoId ? "pt-3" : ""}>
                              <CardTitle className="text-base">{res.title}</CardTitle>
                              {res.description && (
                                <CardDescription>{res.description}</CardDescription>
                              )}
                            </CardHeader>
                            <CardContent className="mt-auto flex gap-2">
                              {videoId && (
                                <Button size="sm" onClick={() => setVideoUrl(res.youtube_url)}>
                                  <Play className="h-4 w-4 mr-1" /> Watch
                                </Button>
                              )}
                              {res.link_url && (
                                <Button size="sm" variant="outline" asChild>
                                  <a href={res.link_url} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="h-4 w-4 mr-1" /> Open Link
                                  </a>
                                </Button>
                              )}
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  )}
                </TabsContent>
              );
            })}
          </Tabs>
        )}

        <Dialog open={!!videoUrl} onOpenChange={(open) => !open && setVideoUrl(null)}>
          <DialogContent className="max-w-3xl p-0 overflow-hidden">
            <DialogHeader className="p-4 pb-0">
              <DialogTitle>Video</DialogTitle>
            </DialogHeader>
            {videoUrl && extractYouTubeId(videoUrl) && (
              <div className="aspect-video w-full">
                <iframe
                  src={`https://www.youtube.com/embed/${extractYouTubeId(videoUrl)}?autoplay=1`}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="Video player"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>
      </main>
    </AppLayout>
  );
}
