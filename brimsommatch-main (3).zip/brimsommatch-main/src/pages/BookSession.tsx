import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, GraduationCap, Stamp, MessageSquare, CalendarIcon, Check, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarPicker } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { useUserBookings, useCreateBooking } from "@/hooks/useSessionBookings";
import { toast } from "@/hooks/use-toast";
import { useFeatureAccess, useTrackUsage } from "@/hooks/useFeatureAccess";
import UpgradeBanner from "@/components/UpgradeBanner";
import SEO from "@/components/SEO";

const SESSION_TYPE_LABELS: Record<string, string> = {
  scholarship_interview: "Scholarship Interview",
  visa_interview: "Visa Interview",
  general_advising: "General Advising",
};

const bookingOptions = [
  {
    title: "Book Mock Interview",
    description: "Practice with experienced interviewers to boost your confidence.",
    icon: Calendar,
    subOptions: [
      { label: "Scholarship Interview", description: "Prepare for scholarship panel interviews with targeted feedback.", icon: GraduationCap, sessionType: "scholarship_interview" },
      { label: "Visa Interview", description: "Practice common visa interview questions and build confidence.", icon: Stamp, sessionType: "visa_interview" },
    ],
  },
  {
    title: "Book Consultation",
    description: "Get personalized guidance on your scholarship and study abroad journey.",
    icon: MessageSquare,
    subOptions: [
      { label: "General Advising Session", description: "Discuss your goals, application strategy, and next steps with an expert.", icon: MessageSquare, sessionType: "general_advising" },
    ],
  },
];

function DatePickerField({ label, date, onSelect }: { label: string; date: Date | undefined; onSelect: (d: Date | undefined) => void }) {
  return (
    <div className="space-y-1">
      <SEO title="Book a Session | Brimsom" description="Book a 1:1 advisory session with the Brimsom team." path="/book-session" />
      <Label className="text-xs">{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}>
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date ? format(date, "PPP") : "Pick a date"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <CalendarPicker mode="single" selected={date} onSelect={onSelect} disabled={(d) => d < new Date()} initialFocus className="p-3 pointer-events-auto" />
        </PopoverContent>
      </Popover>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "pending": return <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending</Badge>;
    case "confirmed": return <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Confirmed</Badge>;
    case "completed": return <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20">Completed</Badge>;
    case "cancelled": return <Badge variant="secondary">Cancelled</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function BookSession() {
  const { user } = useAuth();
  const { data: bookings = [], isLoading: bookingsLoading } = useUserBookings();
  const createBooking = useCreateBooking();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedType, setSelectedType] = useState("");
  const [date1, setDate1] = useState<Date>();
  const [date2, setDate2] = useState<Date>();
  const [date3, setDate3] = useState<Date>();
  const [notes, setNotes] = useState("");

  const { canUse, remaining, limit, period, usage, plan } = useFeatureAccess("book_session");
  const trackUsage = useTrackUsage();

  const openDialog = (sessionType: string) => {
    if (!canUse) {
      toast({ title: "Usage limit reached — upgrade to continue", variant: "destructive" });
      return;
    }
    setSelectedType(sessionType);
    setDate1(undefined);
    setDate2(undefined);
    setDate3(undefined);
    setNotes("");
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!date1 || !date2 || !date3) {
      toast({ title: "Please select all 3 proposed dates", variant: "destructive" });
      return;
    }
    try {
      await createBooking.mutateAsync({
        session_type: selectedType,
        proposed_date_1: date1.toISOString(),
        proposed_date_2: date2.toISOString(),
        proposed_date_3: date3.toISOString(),
        notes,
      });
      trackUsage.mutate("book_session");
      setDialogOpen(false);
      toast({ title: "Booking request submitted!" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <AppLayout>
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-2xl sm:text-3xl font-bold">Book a Session</h1>
          {limit !== Infinity && limit > 0 && (
            <span className={`text-xs px-2 py-1 rounded-full ${remaining <= 0 ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"}`}>
              {remaining}/{limit} remaining this month
            </span>
          )}
        </div>
        <p className="text-muted-foreground mb-8">Schedule mock interviews or consultations with our experts.</p>

        {!canUse && (
          <div className="mb-6">
            <UpgradeBanner
              feature="book_session"
              currentPlan={plan}
              usage={usage}
              limit={limit === Infinity ? 999 : limit}
              period={period}
            />
          </div>
        )}

        <Tabs defaultValue="book" className="space-y-6">
          <TabsList>
            <TabsTrigger value="book">Book</TabsTrigger>
            <TabsTrigger value="my-bookings">My Bookings</TabsTrigger>
          </TabsList>

          <TabsContent value="book">
            <div className="grid gap-8">
              {bookingOptions.map((option) => (
                <Card key={option.title}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                        <option.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{option.title}</CardTitle>
                        <CardDescription>{option.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid sm:grid-cols-2 gap-4">
                      {option.subOptions.map((sub) => (
                        <div key={sub.label} className="rounded-lg border border-border p-4 flex flex-col gap-2">
                          <div className="flex items-center gap-2">
                            <sub.icon className="h-4 w-4 text-primary" />
                            <span className="font-medium text-sm">{sub.label}</span>
                          </div>
                          <p className="text-xs text-muted-foreground">{sub.description}</p>
                          <Button size="sm" className="mt-auto w-full" onClick={() => openDialog(sub.sessionType)}>
                            Book Now
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="my-bookings">
            {bookingsLoading ? (
              <div className="text-center py-8 text-muted-foreground">Loading…</div>
            ) : bookings.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">No bookings yet. Submit a booking request from the Book tab.</div>
            ) : (
              <div className="space-y-4">
                {bookings.map((b) => (
                  <Card key={b.id}>
                    <CardContent className="pt-6 space-y-3">
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div>
                          <p className="font-medium">{SESSION_TYPE_LABELS[b.session_type] ?? b.session_type}</p>
                          <p className="text-xs text-muted-foreground">Submitted {format(new Date(b.created_at), "MMM d, yyyy")}</p>
                        </div>
                        <StatusBadge status={b.status} />
                      </div>
                      <div className="text-sm space-y-1">
                        <p className="text-xs font-medium text-muted-foreground mb-1">Proposed Dates:</p>
                        {[b.proposed_date_1, b.proposed_date_2, b.proposed_date_3].map((d, i) => {
                          const isConfirmed = b.confirmed_date && d === b.confirmed_date;
                          return (
                            <div key={i} className={cn("flex items-center gap-2 rounded px-2 py-1", isConfirmed && "bg-green-500/10")}>
                              {isConfirmed && <Check className="h-3.5 w-3.5 text-green-600" />}
                              <span className={cn(isConfirmed && "font-medium text-green-700 dark:text-green-400")}>
                                {format(new Date(d), "PPP")}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                      {b.confirmed_date && (
                        <div className="rounded-lg bg-green-500/10 p-3 text-sm">
                          <p className="font-medium text-green-700 dark:text-green-400">
                            Confirmed: {format(new Date(b.confirmed_date), "PPP")}
                          </p>
                        </div>
                      )}
                      {b.admin_notes && (
                        <div className="rounded-lg bg-muted p-3 text-sm">
                          <p className="text-xs font-medium text-muted-foreground mb-1">Admin Notes:</p>
                          <p>{b.admin_notes}</p>
                        </div>
                      )}
                      {b.notes && (
                        <div className="text-xs text-muted-foreground">
                          <span className="font-medium">Your notes:</span> {b.notes}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Book {SESSION_TYPE_LABELS[selectedType]}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Select 3 dates you're available for this session.</p>
              <DatePickerField label="Proposed Date 1" date={date1} onSelect={setDate1} />
              <DatePickerField label="Proposed Date 2" date={date2} onSelect={setDate2} />
              <DatePickerField label="Proposed Date 3" date={date3} onSelect={setDate3} />
              <div className="space-y-1">
                <Label className="text-xs">Notes (optional)</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any additional information..." rows={3} />
              </div>
              <Button className="w-full" onClick={handleSubmit} disabled={createBooking.isPending}>
                {createBooking.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Submit Booking Request
              </Button>
            </div>
          </DialogContent>
        </Dialog>

      </main>
    </AppLayout>
  );
}
