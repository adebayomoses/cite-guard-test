import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Briefcase, Clock, Globe, Laptop, MapPin, AlertCircle, CheckCircle2, GraduationCap, Send } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import JobApplicationDialog from "@/components/careers/JobApplicationDialog";
import SEO from "@/components/SEO";

const jobs = [
  {
    id: "moderator-data-specialist",
    title: "Moderator Data Specialist",
    urgent: true,
    type: "Remote",
    duration: "3 Months (with potential extension on performance)",
    hours: "Approx. 4 hours per day",
    location: "Remote",
    description:
      "We are looking for a detail-oriented individual to assist with online data extraction tasks. Your primary responsibility will be to collect and input 17 data entries per day into the Brimsom platform. The task is straightforward and should take no more than 4 hours daily.",
    requirements: [
      "Must own a functional laptop",
      "Reliable internet connection",
      "Ability to stay consistent and focused",
      "Strong attention to detail",
      "Self-motivated and disciplined",
    ],
    note: "This is a short-term role, but exceptional performance may lead to an extension.",
  },
];

export default function Careers() {
  const { settings } = useSiteSettings();
  const logoUrl = settings.logo_url;
  const [applyingTo, setApplyingTo] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Careers at Brimsom — Join our remote team"
        description="Explore open roles at Brimsom and help us build the world's smartest scholarship discovery platform."
        path="/careers"
      />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="relative z-10">
        <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto flex items-center justify-between h-16 px-4">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Home</Link>
            </Button>
            <ThemeToggle />
          </div>
        </nav>

        <main className="container mx-auto px-4 py-12 max-w-3xl">
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            {logoUrl ? (
              <img src={logoUrl} alt="Brimsom" className="h-12 w-12 rounded-xl object-contain" />
            ) : (
              <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
            )}
            <div>
              <h1 className="text-3xl font-bold">Careers at Brimsom</h1>
              <p className="text-sm text-muted-foreground">Join us in helping students unlock education opportunities</p>
            </div>
          </div>

          {/* Intro */}
          <Card className="mb-8">
            <CardContent className="pt-6 text-sm text-muted-foreground leading-relaxed">
              <p>
                At <strong className="text-foreground">Brimsom AI</strong>, we are building the smartest scholarship companion for students worldwide. We're a small, ambitious team and we're always on the lookout for thoughtful, detail-oriented people who want to make a real difference. Browse our open roles below.
              </p>
            </CardContent>
          </Card>

          {/* Open Roles */}
          <h2 className="text-xl font-semibold mb-4">Open Roles</h2>

          <div className="space-y-6">
            {jobs.map((job) => (
              <Card key={job.id} id={job.id} className="overflow-hidden">
                <CardHeader className="bg-primary/5 border-b">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        {job.urgent && (
                          <Badge variant="destructive" className="gap-1">
                            <AlertCircle className="h-3 w-3" /> Urgently Needed
                          </Badge>
                        )}
                        <Badge variant="secondary" className="gap-1">
                          <Globe className="h-3 w-3" /> {job.type}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl">{job.title}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">Position opened at Brimsom AI</p>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Briefcase className="h-4 w-4" />
                      <span>Short-Term</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6 space-y-5">
                  {/* Quick facts */}
                  <div className="grid sm:grid-cols-3 gap-3">
                    <div className="flex items-start gap-2 text-sm">
                      <Clock className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Duration</p>
                        <p className="text-xs text-muted-foreground">{job.duration}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 text-sm">
                      <Laptop className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Working Hours</p>
                        <p className="text-xs text-muted-foreground">{job.hours}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Location</p>
                        <p className="text-xs text-muted-foreground">{job.location}</p>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <h3 className="font-semibold text-sm mb-2">Job Description</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{job.description}</p>
                  </div>

                  {/* Requirements */}
                  <div>
                    <h3 className="font-semibold text-sm mb-2">Requirements</h3>
                    <ul className="space-y-1.5">
                      {job.requirements.map((req) => (
                        <li key={req} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Note */}
                  {job.note && (
                    <div className="rounded-lg bg-muted/50 border border-border p-3">
                      <p className="text-xs text-muted-foreground">
                        <strong className="text-foreground">Note:</strong> {job.note}
                      </p>
                    </div>
                  )}

                  {/* CTA */}
                  <div className="flex flex-col sm:flex-row gap-2 pt-2">
                    <Button className="flex-1" onClick={() => setApplyingTo(job.title)}>
                      <Send className="h-4 w-4 mr-2" /> Apply Now
                    </Button>
                    <Button variant="outline" asChild className="flex-1">
                      <Link to="/support">Contact Us</Link>
                    </Button>
                  </div>
                  <p className="text-xs text-center text-muted-foreground">
                    Submit your application below — we'll review and reach out if it's a match.
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <JobApplicationDialog
            open={!!applyingTo}
            onOpenChange={(v) => !v && setApplyingTo(null)}
            position={applyingTo || ""}
          />


          {/* No more roles */}
          <div className="text-center py-12 mt-4">
            <p className="text-sm text-muted-foreground">
              Don't see a role that fits? We'd still love to hear from you.
            </p>
            <Button variant="link" asChild>
              <a href="mailto:careers@brimsom.com">careers@brimsom.com</a>
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}
