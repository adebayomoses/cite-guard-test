import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import SEO from "@/components/SEO";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Loader2, Zap, Settings, Sparkles, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useSubscriptionPlan } from "@/hooks/useFeatureAccess";
import { PLAN_TIERS, type PlanId } from "@/lib/subscriptionTiers";
import { toast } from "sonner";

type RowKey =
  | "brim_chat"
  | "score_gen"
  | "rec_scholarships"
  | "doc_review"
  | "sessions"
  | "match_me"
  | "research_proposal"
  | "priority"
  | "scholarships"
  | "community"
  | "score_pathways";

const FEATURES_LIST: { key: RowKey; label: string; values: Record<PlanId, string> }[] = [
  { key: "brim_chat", label: "Brim Chat", values: { free: "5 total", standard: "10/day", pro: "Unlimited", pro_plus: "Unlimited" } },
  { key: "score_gen", label: "Score Generation", values: { free: "5/month", standard: "20/month", pro: "Unlimited", pro_plus: "Unlimited" } },
  { key: "rec_scholarships", label: "Recommended Scholarships", values: { free: "5/month", standard: "20/month", pro: "Unlimited", pro_plus: "Unlimited" } },
  { key: "match_me", label: "Match Me", values: { free: "2/month", standard: "10/month", pro: "50/month", pro_plus: "Unlimited" } },
  { key: "doc_review", label: "Document Reviews", values: { free: "1 / 2 months", standard: "3/month", pro: "6/month", pro_plus: "10/month" } },
  { key: "sessions", label: "Booked Sessions", values: { free: "—", standard: "—", pro: "1/month", pro_plus: "3/month" } },
  { key: "research_proposal", label: "Research Proposal Review", values: { free: "—", standard: "—", pro: "—", pro_plus: "✓" } },
  { key: "priority", label: "Priority Queue", values: { free: "—", standard: "—", pro: "—", pro_plus: "✓" } },
  { key: "scholarships", label: "Scholarships Database", values: { free: "✓", standard: "✓", pro: "✓", pro_plus: "✓" } },
  { key: "community", label: "Community Chat", values: { free: "✓", standard: "✓", pro: "✓", pro_plus: "✓" } },
  { key: "score_pathways", label: "Score & Pathways", values: { free: "✓", standard: "✓", pro: "✓", pro_plus: "✓" } },
];

const plans: { id: PlanId; icon: typeof Zap; highlight?: boolean }[] = [
  { id: "free", icon: Zap },
  { id: "standard", icon: Crown },
  { id: "pro", icon: Crown, highlight: true },
  { id: "pro_plus", icon: Sparkles },
];

const ctaLabel: Record<PlanId, string> = {
  free: "Free Forever",
  standard: "Get Standard",
  pro: "Go Pro",
  pro_plus: "Go Pro+",
};

export default function Pricing() {
  const { session } = useAuth();
  const { data: subData } = useSubscriptionPlan();
  const currentPlan = subData?.plan ?? "free";
  const [loading, setLoading] = useState<string | null>(null);
  const [interval, setInterval] = useState<"month" | "year">("month");
  const [searchParams] = useSearchParams();

  const success = searchParams.get("success");

  const handleCheckout = async (priceId: string) => {
    if (!session) {
      toast.error("Please sign in first");
      return;
    }
    setLoading(priceId);
    try {
      const { data, error } = await supabase.functions.invoke("create-checkout", {
        body: { priceId },
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (e: any) {
      toast.error(e.message || "Failed to start checkout");
    } finally {
      setLoading(null);
    }
  };

  const handleManage = async () => {
    if (!session) return;
    setLoading("manage");
    try {
      const { data, error } = await supabase.functions.invoke("customer-portal", {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      if (error) throw error;
      if (data?.url) window.open(data.url, "_blank");
    } catch (e: any) {
      toast.error(e.message || "Failed to open portal");
    } finally {
      setLoading(null);
    }
  };

  return (
    <AppLayout>
      <SEO
        title="Pricing | Brimsom"
        description="Compare Brimsom Free, Standard, and Pro plans — chance scores, scholarship recommendations, document reviews, and advisor sessions."
        path="/pricing"
      />
      <main className="container mx-auto px-4 py-12 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Choose Your Plan</h1>
          <p className="text-muted-foreground">Unlock premium features to boost your scholarship journey.</p>
          {success && (
            <div className="mt-4 rounded-lg bg-green-500/10 border border-green-500/20 p-3 text-green-700 dark:text-green-400 text-sm">
              🎉 Subscription activated! It may take a moment to reflect.
            </div>
          )}
        </div>

        <div className="flex justify-center mb-8">
          <div className="inline-flex items-center rounded-full border border-border bg-card p-1">
            <button
              onClick={() => setInterval("month")}
              className={`px-4 py-1.5 text-sm rounded-full transition ${
                interval === "month" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setInterval("year")}
              className={`px-4 py-1.5 text-sm rounded-full transition flex items-center gap-1.5 ${
                interval === "year" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              Yearly
              <span className="text-[10px] font-semibold bg-amber-500/20 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-full">
                ~2 mo free
              </span>
            </button>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {plans.map(({ id, icon: Icon, highlight }) => {
            const tier = PLAN_TIERS[id];
            const isCurrent = currentPlan === id;
            const isYearly = interval === "year" && id !== "free";
            const displayPrice = isYearly ? tier.yearlyPrice : tier.price;
            const priceIdToUse = isYearly ? tier.yearlyPriceId : tier.priceId;
            return (
              <Card
                key={id}
                className={`relative flex flex-col ${highlight ? "border-primary shadow-lg" : ""}`}
              >
                {highlight && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <div className="mx-auto h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{tier.name}</CardTitle>
                  <p className="text-2xl font-bold mt-1">
                    {tier.price === 0
                      ? "Free"
                      : isYearly
                      ? `$${displayPrice}/yr`
                      : `$${displayPrice}/mo`}
                  </p>
                  {isYearly && tier.price > 0 && (
                    <p className="text-xs text-muted-foreground">
                      ${(tier.yearlyPrice / 12).toFixed(2)}/mo billed yearly
                    </p>
                  )}
                </CardHeader>
                <CardContent className="flex-1 space-y-2.5">
                  {[...FEATURES_LIST]
                    .sort((a, b) => {
                      const aOut = a.values[id] === "—" ? 1 : 0;
                      const bOut = b.values[id] === "—" ? 1 : 0;
                      return aOut - bOut;
                    })
                    .map((f) => {
                      const value = f.values[id];
                      const notIncluded = value === "—";
                      return (
                        <div key={f.key} className="flex items-start gap-2 text-sm">
                          {notIncluded ? (
                            <X className="h-3.5 w-3.5 text-destructive shrink-0 mt-0.5" />
                          ) : (
                            <Check className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
                          )}
                          <span className={notIncluded ? "text-muted-foreground" : ""}>
                            {f.label}
                            {!notIncluded && (
                              <>: <span className="font-medium">{value}</span></>
                            )}
                          </span>
                        </div>
                      );
                    })}
                </CardContent>
                <div className="p-6 pt-0">
                  {isCurrent ? (
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full" disabled>
                        Current Plan
                      </Button>
                      {id !== "free" && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full"
                          onClick={handleManage}
                          disabled={loading === "manage"}
                        >
                          {loading === "manage" ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-1" />
                          ) : (
                            <Settings className="h-4 w-4 mr-1" />
                          )}
                          Manage Subscription
                        </Button>
                      )}
                    </div>
                  ) : priceIdToUse ? (
                    <Button
                      className="w-full"
                      variant={highlight ? "default" : "outline"}
                      onClick={() => handleCheckout(priceIdToUse!)}
                      disabled={!!loading}
                    >
                      {loading === priceIdToUse ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-1" />
                      ) : null}
                      {ctaLabel[id]}
                    </Button>
                  ) : (
                    <Button variant="outline" className="w-full" disabled>
                      {ctaLabel[id]}
                    </Button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>

        <p className="text-center text-xs text-muted-foreground max-w-2xl mx-auto">
          All paid plans include unlimited scholarships, community access, and the score &amp; pathways tools.
          Document reviews and sessions on Pro and Pro+ are handled by our human approval team and reset monthly.
        </p>
      </main>
    </AppLayout>
  );
}
