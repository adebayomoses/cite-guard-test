import { useState } from "react";
import { Link } from "react-router-dom";
import { Wand2, ChevronLeft, ChevronDown, ChevronUp, Trash2, History, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import AppNav from "@/components/AppNav";
import BottomNav from "@/components/BottomNav";
import MatchResultCard from "@/components/advisor/MatchResultCard";
import { useMatchHistory, useDeleteMatchHistory, type MatchHistoryEntry } from "@/hooks/useMatchHistory";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import SEO from "@/components/SEO";

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleString(undefined, {
      month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit",
    });
  } catch { return iso; }
}

function HistoryItem({ entry }: { entry: MatchHistoryEntry }) {
  const [open, setOpen] = useState(false);
  const del = useDeleteMatchHistory();
  const title = entry.result?.title || "Untitled opportunity";
  const subtitle = [entry.result?.provider, entry.result?.country].filter(Boolean).join(" · ");

  return (
    <div className="rounded-2xl border bg-card overflow-hidden">
      <SEO title="Match History | Brimsom" description="Review the scholarships Brimsom has matched to your profile over time." path="/match-history" />
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-muted/40 transition"
      >
        <div className="h-9 w-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
          <Wand2 className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm leading-snug truncate">{title}</p>
          {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
          <div className="flex items-center gap-2 mt-1.5 flex-wrap">
            <Badge variant="secondary" className="text-[10px]">Match {entry.result?.match_score ?? 0}/100</Badge>
            <Badge variant="secondary" className="text-[10px]">Chance {entry.result?.chance_score ?? 0}/100</Badge>
            <span className="text-[11px] text-muted-foreground">{formatDate(entry.created_at)}</span>
          </div>
        </div>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground shrink-0 mt-1" /> : <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />}
      </button>

      {open && (
        <div className="border-t bg-muted/20 p-4 space-y-4">
          <MatchResultCard result={entry.result} />
          <div className="flex justify-end">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive gap-1.5">
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="max-w-[calc(100vw-2rem)]">
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this analysis?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently remove this saved Match Me analysis. You can always run a new one.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() =>
                      del.mutate(entry.id, {
                        onSuccess: () => toast({ title: "Deleted", description: "Analysis removed from history." }),
                        onError: (e: any) => toast({ title: "Couldn't delete", description: e?.message ?? "Try again.", variant: "destructive" }),
                      })
                    }
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      )}
    </div>
  );
}

export default function MatchHistory() {
  const { data: entries = [], isLoading } = useMatchHistory();

  return (
    <div className="min-h-screen bg-background pb-24 lg:pb-8">
      <AppNav />
      <main className="max-w-3xl mx-auto px-4 pt-20 sm:pt-24">
        <div className="mb-4">
          <Link to="/brim-ai-chat" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
            <ChevronLeft className="h-4 w-4" /> Back to Brim AI
          </Link>
        </div>

        <div className="flex items-start justify-between gap-3 mb-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
              <History className="h-6 w-6 text-primary" /> Match Me history
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Your last 10 Match Me analyses. Older entries are automatically removed as new ones are added.
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)}
          </div>
        ) : entries.length === 0 ? (
          <div className="rounded-3xl border border-dashed bg-muted/20 p-8 text-center">
            <div className="h-12 w-12 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-3">
              <Wand2 className="h-5 w-5" />
            </div>
            <h3 className="font-semibold mb-1">No saved analyses yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Run Match Me on any scholarship and the result will be saved here automatically.
            </p>
            <Button asChild>
              <Link to="/brim-ai-chat">Open Brim AI</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map((e) => <HistoryItem key={e.id} entry={e} />)}
          </div>
        )}
      </main>
      <BottomNav />
    </div>
  );
}
