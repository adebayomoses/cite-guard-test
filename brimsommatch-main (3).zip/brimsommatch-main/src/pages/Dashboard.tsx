import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { UserPen, Search, Users, Briefcase, Route, FileText, BookOpen, Calendar, Landmark, Bot, ClipboardList, ChevronDown, ChevronUp, Sparkles, ArrowRight, Wand2, type LucideIcon } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { useProfileData } from "@/hooks/useProfileData";
import { useChanceScore } from "@/hooks/useChanceScore";
import { useActivityLog } from "@/hooks/useActivityLog";
import { useQuickActions } from "@/hooks/useQuickActions";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useAdminRole } from "@/hooks/useAdminRole";
import { Skeleton } from "@/components/ui/skeleton";

import ScoreCard from "@/components/dashboard/ScoreCard";
import UpcomingDeadlines from "@/components/dashboard/UpcomingDeadlines";
import RecentActivity from "@/components/dashboard/RecentActivity";
import RecommendedScholarships from "@/components/dashboard/RecommendedScholarships";
import PersonalizedScholarships from "@/components/dashboard/PersonalizedScholarships";
import TopPicks from "@/components/dashboard/TopPicks";

import OnboardingTour from "@/components/OnboardingTour";
import { useOnboardingTour, type TourStep } from "@/hooks/useOnboardingTour";
import SEO from "@/components/SEO";
import { getPersonalizedDegreeTokens, scholarshipMatchesDegreeTokens, scholarshipMatchesUserFields } from "@/lib/personalizedDegree";

const dashboardTourSteps: TourStep[] = [
  { target: "profile-completeness", title: "Profile Completeness", description: "This shows how complete your profile is. A higher percentage unlocks more features like your Chance Score." },
  { target: "chance-score", title: "Chance Score", description: "Once your profile is 50%+ complete, generate your AI-powered chance score to see how you rank for scholarships." },
  { target: "matched-scholarships", title: "Matched Scholarships", description: "See how many scholarships match your profile. Click 'Browse All' to explore the full list." },
  { target: "quick-actions", title: "Quick Actions", description: "Shortcuts to the most useful features — scholarships, community, document review, and more." },
  { target: "upcoming-deadlines", title: "Upcoming Deadlines & Activity", description: "Track your upcoming scholarship deadlines and recent activity all in one place." },
];

const iconMap: Record<string, LucideIcon> = {
  Search, Users, Briefcase, Route, FileText, BookOpen, Calendar, Landmark, Bot, ClipboardList, Wand2,
};

const actionColors: Record<string, { bg: string; icon: string }> = {
  Search:       { bg: "bg-[hsl(160,40%,92%)]", icon: "text-[hsl(160,60%,38%)]" },
  Users:        { bg: "bg-[hsl(210,60%,92%)]", icon: "text-[hsl(210,65%,45%)]" },
  Briefcase:    { bg: "bg-[hsl(35,80%,92%)]",  icon: "text-[hsl(35,80%,45%)]" },
  Route:        { bg: "bg-[hsl(270,40%,92%)]", icon: "text-[hsl(270,50%,52%)]" },
  FileText:     { bg: "bg-[hsl(0,50%,92%)]",   icon: "text-[hsl(0,60%,50%)]" },
  BookOpen:     { bg: "bg-[hsl(45,80%,92%)]",  icon: "text-[hsl(45,85%,45%)]" },
  Calendar:     { bg: "bg-[hsl(190,55%,91%)]", icon: "text-[hsl(190,60%,38%)]" },
  Landmark:     { bg: "bg-[hsl(160,40%,92%)]", icon: "text-[hsl(160,60%,38%)]" },
  Bot:          { bg: "bg-[hsl(210,60%,92%)]", icon: "text-[hsl(210,65%,45%)]" },
  ClipboardList:{ bg: "bg-[hsl(35,80%,92%)]",  icon: "text-[hsl(35,80%,45%)]" },
  Wand2:        { bg: "bg-[hsl(280,55%,93%)]", icon: "text-[hsl(280,60%,50%)]" },
};

const darkActionColors: Record<string, { bg: string; icon: string }> = {
  Search:       { bg: "dark:bg-[hsl(160,30%,16%)]", icon: "dark:text-[hsl(160,55%,55%)]" },
  Users:        { bg: "dark:bg-[hsl(210,30%,16%)]", icon: "dark:text-[hsl(210,60%,60%)]" },
  Briefcase:    { bg: "dark:bg-[hsl(35,30%,16%)]",  icon: "dark:text-[hsl(35,70%,55%)]" },
  Route:        { bg: "dark:bg-[hsl(270,25%,18%)]", icon: "dark:text-[hsl(270,50%,65%)]" },
  FileText:     { bg: "dark:bg-[hsl(0,25%,16%)]",   icon: "dark:text-[hsl(0,55%,60%)]" },
  BookOpen:     { bg: "dark:bg-[hsl(45,30%,16%)]",  icon: "dark:text-[hsl(45,75%,55%)]" },
  Calendar:     { bg: "dark:bg-[hsl(190,30%,16%)]", icon: "dark:text-[hsl(190,55%,55%)]" },
  Landmark:     { bg: "dark:bg-[hsl(160,30%,16%)]", icon: "dark:text-[hsl(160,55%,55%)]" },
  Bot:          { bg: "dark:bg-[hsl(210,30%,16%)]", icon: "dark:text-[hsl(210,60%,60%)]" },
  ClipboardList:{ bg: "dark:bg-[hsl(35,30%,16%)]",  icon: "dark:text-[hsl(35,70%,55%)]" },
  Wand2:        { bg: "dark:bg-[hsl(280,30%,18%)]", icon: "dark:text-[hsl(280,55%,68%)]" },
};

export default function Dashboard() {
  const { user } = useAuth();
  const { isAdmin, isModerator } = useAdminRole();
  const navigate = useNavigate();
  const profile = useProfileData();
  const completeness = profile.getCompleteness();
  const { score, loading: scoreLoading, generating, generate } = useChanceScore();
  const { activities, loading: activityLoading, logActivity } = useActivityLog();
  const { actions: quickActions, isLoading: qaLoading } = useQuickActions(true);
  const [showAllActions, setShowAllActions] = useState(false);
  const tour = useOnboardingTour("dashboard", dashboardTourSteps);
  const { settings } = useSiteSettings();
  const forYouThreshold = parseInt(settings?.foryou_threshold ?? "40", 10) || 40;

  // First-ever visit: route brand-new users to Brim Ai Chat once for the "AI-first" wow moment.
  // After that, the dashboard becomes their default landing page on subsequent logins.
  // Admins and moderators are exempt.
  useEffect(() => {
    if (profile.loading || !user) return;
    if (isAdmin || isModerator) return;
    const firstSeenKey = `brim_first_seen_${user.id}`;
    if (!localStorage.getItem(firstSeenKey)) {
      localStorage.setItem(firstSeenKey, "1");
      navigate("/brim-ai-chat", { replace: true, state: { firstTime: true } });
      return;
    }
    // Existing behaviour: nudge low-completeness users to their profile once per session
    const key = `profile_redirect_done_${user.id}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    if (completeness < 50) {
      navigate("/profile", { replace: true });
    }
  }, [profile.loading, completeness, user, navigate, isAdmin, isModerator]);

  const [askBrim, setAskBrim] = useState("");
  const submitAskBrim = (e: React.FormEvent) => {
    e.preventDefault();
    const text = askBrim.trim();
    navigate("/brim-ai-chat", text ? { state: { initialMessage: text } } : {});
  };

  // Active+personalized scholarships: same auto filters that the Discovery
  // "For You" tab applies (degree level from intended/academic level + field of
  // study from the user's education), so the dashboard count mirrors what
  // users actually see in personalized Discovery.
  const [eligibleIds, setEligibleIds] = useState<Set<string>>(new Set());
  const [deadlineById, setDeadlineById] = useState<Map<string, string | null>>(new Map());
  const userFields = useMemo(
    () => profile.education.map((e) => e.field_of_study).filter(Boolean) as string[],
    [profile.education],
  );
  const personalInfoKey = JSON.stringify({
    intended: (profile.personalInfo as any)?.intended_degree_level,
    academic: profile.personalInfo?.academic_level,
    fields: userFields,
  });
  useEffect(() => {
    const today = new Date().toISOString().split("T")[0];
    supabase
      .from("scholarships")
      .select("id, degree_level, field_of_study, next_close_date")
      .eq("is_active", true)
      .or(`next_close_date.is.null,next_close_date.gte.${today}`)
      .then(({ data }) => {
        const tokens = getPersonalizedDegreeTokens(profile.personalInfo);
        const ids = new Set<string>();
        const dl = new Map<string, string | null>();
        (data ?? []).forEach((s: any) => {
          if (
            scholarshipMatchesDegreeTokens(s.degree_level, tokens) &&
            scholarshipMatchesUserFields(s.field_of_study, userFields)
          ) {
            ids.add(s.id);
            dl.set(s.id, s.next_close_date);
          }
        });
        setEligibleIds(ids);
        setDeadlineById(dl);
      });
  }, [personalInfoKey]);

  // Tiered breakdown of the user's personalized pool:
  //  - Eligible: passes eligibility filter (any score)
  //  - Matched: eligible AND score >= threshold (recommended)
  //  - Top Picks: top 5 highest-scoring matched
  //  - Closing Soon: matched with deadline within 30 days
  const eligibleMatches = (score?.scholarship_matches ?? []).filter(
    (m: any) => eligibleIds.has(m.scholarship_id)
  );
  const matched = eligibleMatches.filter((m: any) => !m.pending_ai && m.score >= forYouThreshold);
  const matchCount = matched.length;
  const eligibleCount = eligibleMatches.length;
  const topPicksCount = Math.min(5, matched.length);
  const now = Date.now();
  const soonMs = 30 * 24 * 60 * 60 * 1000;
  const closingSoonCount = matched.filter((m: any) => {
    const d = deadlineById.get(m.scholarship_id);
    if (!d) return false;
    const t = new Date(d).getTime();
    return !isNaN(t) && t - now <= soonMs && t >= now;
  }).length;
  const firstName = (profile.personalInfo?.full_name || user?.user_metadata?.full_name || "").split(" ")[0] || "there";

  return (
    <AppLayout>
      <SEO title="Dashboard | Brimsom" description="Your Brimsom dashboard — recommended scholarships, chance score, and quick actions." path="/dashboard" />

      <main className="container mx-auto px-4 py-12 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold mb-2">Welcome back, {firstName}</h1>
            <p className="text-muted-foreground">Your personalized scholarship dashboard.</p>
          </div>
          <div className="flex gap-2" />
        </div>

        {/* Ask Brim hero — chat-first entry point on the dashboard */}
        <form
          onSubmit={submitAskBrim}
          className="rounded-3xl border border-border bg-gradient-to-br from-primary/10 via-card to-card p-4 sm:p-5 shadow-sm"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="h-8 w-8 rounded-full bg-primary/15 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-primary" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-sm sm:text-base leading-tight">Ask Brim anything</h3>
              <p className="text-xs text-muted-foreground">Find scholarships, draft an SOP, plan your application.</p>
            </div>
          </div>
          <div className="flex gap-2">
            <input
              value={askBrim}
              onChange={(e) => setAskBrim(e.target.value)}
              placeholder="e.g. Find me fully-funded Master's scholarships in Germany"
              className="flex-1 min-w-0 rounded-full border border-border bg-background px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40 placeholder:text-muted-foreground"
            />
            <Button type="submit" size="icon" className="rounded-full shrink-0" aria-label="Ask Brim">
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </form>

        <div className="space-y-8">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
              <div data-tour="profile-completeness" className="rounded-3xl border border-border bg-card p-4 md:p-6 flex flex-col items-center text-center">
                <h3 className="font-semibold text-sm md:text-base mb-2 md:mb-3">Profile Completeness</h3>
                {profile.loading ? (
                  <div className="text-2xl md:text-4xl font-bold text-muted-foreground">—</div>
                ) : (
                  <div className="flex justify-center">
                    <svg width="72" height="72" viewBox="0 0 96 96" className="shrink-0 md:w-24 md:h-24">
                      <circle cx="48" cy="48" r="40" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
                      <circle
                        cx="48" cy="48" r="40" fill="none"
                        stroke={completeness <= 30 ? "hsl(0, 72%, 51%)" : completeness <= 60 ? "hsl(45, 93%, 47%)" : "hsl(142, 71%, 45%)"}
                        strokeWidth="8"
                        strokeDasharray={2 * Math.PI * 40}
                        strokeDashoffset={2 * Math.PI * 40 - (completeness / 100) * 2 * Math.PI * 40}
                        strokeLinecap="round"
                        transform="rotate(-90 48 48)"
                        className="transition-all duration-700"
                      />
                      <text x="48" y="48" textAnchor="middle" dominantBaseline="central"
                        className="fill-foreground font-bold" fontSize="20">
                        {completeness}%
                      </text>
                    </svg>
                  </div>
                )}
                <p className="text-xs md:text-sm text-muted-foreground mt-1.5 md:mt-2">
                  {completeness < 50 ? "Complete 50%+ to generate your chance score" : "Ready to generate your score!"}
                </p>
                <Link to="/profile" className="mt-2 md:mt-3 inline-flex items-center gap-1.5 text-xs md:text-sm text-primary hover:underline font-medium">
                  <UserPen className="h-3 w-3 md:h-3.5 md:w-3.5" />
                  {completeness > 0 ? "Edit Profile" : "Complete Profile"}
                </Link>
              </div>

              {score ? (
                <div data-tour="chance-score" className="h-full"><ScoreCard score={score.readiness_score} summary={score.readiness_summary} showLink /></div>
              ) : (
                <div data-tour="chance-score" className="rounded-3xl border border-border bg-card p-6 h-full">
                  <h3 className="font-semibold mb-2">Chance Score</h3>
                  <div className="text-4xl font-bold text-muted-foreground">—</div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {completeness >= 50 ? "Generate your score on the Score page" : "Available after 50% profile completion"}
                  </p>
                  {completeness >= 50 && (
                    <Button variant="outline" size="sm" className="mt-3" asChild>
                      <Link to="/score">Generate Score</Link>
                    </Button>
                  )}
                </div>
              )}

              <div data-tour="matched-scholarships" className="col-span-2 md:col-span-1 rounded-3xl border border-border bg-card p-4 md:p-6 flex flex-col text-center">
                <h3 className="font-semibold text-sm md:text-base mb-1">Matched Scholarships</h3>
                {!score ? (
                  <>
                    <div className="text-2xl md:text-4xl font-bold text-muted-foreground">—</div>
                    <p className="text-xs md:text-sm text-muted-foreground mt-1">Generate score to see matches</p>
                  </>
                ) : (
                  <>
                    <div className="text-2xl md:text-4xl font-bold text-primary leading-none">{matchCount}</div>
                    <p className="text-[11px] md:text-xs text-muted-foreground mt-1">
                      Matched · <span className="font-medium text-foreground/80">{eligibleCount}</span> Eligible
                    </p>
                    <div className="grid grid-cols-3 gap-1.5 mt-3 text-[10px] sm:text-[11px] md:text-xs">
                      <Link to="/scholarships?tab=foryou&view=top" className="rounded-lg bg-primary/10 hover:bg-primary/15 transition-colors p-1.5 md:p-2 flex flex-col items-center justify-center min-w-0">
                        <div className="text-base md:text-lg font-bold text-primary leading-none">{topPicksCount}</div>
                        <div className="text-muted-foreground mt-1 whitespace-nowrap truncate max-w-full">🎯 Top Picks</div>
                      </Link>
                      <Link to="/scholarships?tab=foryou&view=closing" className="rounded-lg bg-orange-500/10 hover:bg-orange-500/15 transition-colors p-1.5 md:p-2 flex flex-col items-center justify-center min-w-0">
                        <div className="text-base md:text-lg font-bold text-orange-600 dark:text-orange-400 leading-none">{closingSoonCount}</div>
                        <div className="text-muted-foreground mt-1 whitespace-nowrap truncate max-w-full">⏰ Closing</div>
                      </Link>
                      <Link to="/scholarships?tab=foryou&view=matched" className="rounded-lg bg-emerald-500/10 hover:bg-emerald-500/15 transition-colors p-1.5 md:p-2 flex flex-col items-center justify-center min-w-0">
                        <div className="text-base md:text-lg font-bold text-emerald-600 dark:text-emerald-400 leading-none">{matchCount}</div>
                        <div className="text-muted-foreground mt-1 whitespace-nowrap truncate max-w-full">✅ Matched</div>
                      </Link>
                    </div>
                  </>
                )}
                <Button variant="outline" size="sm" className="mt-3 text-xs md:text-sm self-center" asChild>
                  <Link to="/scholarships?tab=foryou"><Search className="h-3 w-3 md:h-3.5 md:w-3.5 mr-1 md:mr-1.5" />Browse All</Link>
                </Button>
              </div>
          </div>

          <div data-tour="quick-actions">
            <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-3 gap-2 sm:gap-4">
              {qaLoading
                ? Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="rounded-xl border border-border bg-card p-3 sm:p-6 flex flex-col items-center">
                      <Skeleton className="h-8 w-8 sm:h-12 sm:w-12 rounded-full mb-2 sm:mb-3" />
                      <Skeleton className="h-3 sm:h-4 w-14 sm:w-20" />
                    </div>
                  ))
                : (showAllActions ? quickActions : quickActions.slice(0, 6)).map((action) => {
                    const Icon = iconMap[action.icon_name] ?? Search;
                    const light = actionColors[action.icon_name] ?? { bg: "bg-muted", icon: "text-primary" };
                    const dark = darkActionColors[action.icon_name] ?? { bg: "dark:bg-muted", icon: "dark:text-primary" };
                    return (
                      <Link
                        key={action.id}
                        to={action.route}
                        className="rounded-2xl border border-border bg-card p-3 sm:p-5 flex flex-col items-center text-center hover:scale-[1.02] hover:shadow-md transition-all duration-200"
                      >
                        <div className={`h-10 w-10 sm:h-14 sm:w-14 rounded-2xl flex items-center justify-center mb-2 sm:mb-3 ${light.bg} ${dark.bg}`}>
                          <Icon className={`h-5 w-5 sm:h-6 sm:w-6 ${light.icon} ${dark.icon}`} />
                        </div>
                        <span className="text-[11px] sm:text-sm font-semibold leading-tight">{action.label}</span>
                      </Link>
                    );
                  })}
            </div>
            {!qaLoading && quickActions.length > 6 && (
              <Button
                variant="ghost"
                size="sm"
                className="mt-3 w-full text-muted-foreground"
                onClick={() => setShowAllActions((prev) => !prev)}
              >
                {showAllActions ? (
                  <>Show Less <ChevronUp className="h-4 w-4 ml-1" /></>
                ) : (
                  <>See More <ChevronDown className="h-4 w-4 ml-1" /></>
                )}
              </Button>
            )}
          </div>

          {score?.scholarship_matches && score.scholarship_matches.length > 0 && (
            <>
              <TopPicks matches={matched} />
              <PersonalizedScholarships matches={score.scholarship_matches} />
              <RecommendedScholarships matches={score.scholarship_matches} />
            </>
          )}

          <div data-tour="upcoming-deadlines" className="grid md:grid-cols-2 gap-6">
            <UpcomingDeadlines />
            <RecentActivity activities={activities} loading={activityLoading} />
          </div>
        </div>
      </main>

      {tour.step && (
        <OnboardingTour
          active={tour.active}
          target={tour.step.target}
          title={tour.step.title}
          description={tour.step.description}
          currentStep={tour.currentStep}
          totalSteps={tour.totalSteps}
          onNext={tour.next}
          onPrev={tour.prev}
          onSkip={tour.skip}
        />
      )}
    </AppLayout>
  );
}
