import { useState, useRef, useEffect, useCallback } from "react";
import { useUserReports } from "@/hooks/useUserReports";
import { useUnreadCounts } from "@/hooks/useUnreadCounts";
import { useAuth } from "@/contexts/AuthContext";
import { useChatRooms } from "@/hooks/useChatRooms";
import { useChatMessages } from "@/hooks/useChatMessages";
import { useDirectMessages } from "@/hooks/useDirectMessages";
import { useDMContacts } from "@/hooks/useDMContacts";
import { useBlockedUsers } from "@/hooks/useBlockedUsers";
import { useRoomAnnouncements } from "@/hooks/useRoomAnnouncements";
import { useChatBans } from "@/hooks/useChatBans";
import { useCommunityModerators } from "@/hooks/useCommunityModerators";
import { useAdminRole } from "@/hooks/useAdminRole";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Send, MessageCircle, Hash, ChevronLeft, User, ShieldBan, ShieldCheck, Pin, X, ImagePlus, Trash2, Shield, Flag, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import AppLayout from "@/components/AppLayout";
import { format } from "date-fns";
import { toast } from "sonner";
import SEO from "@/components/SEO";

type ChatMode = "room" | "dm";

const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp"];

export default function Community() {
  const { user } = useAuth();
  const { rooms, loading: roomsLoading } = useChatRooms();
  const { contacts, loading: contactsLoading } = useDMContacts();
  const { blockedIds, isBlocked, blockUser, unblockUser } = useBlockedUsers();
  const { isAdmin } = useAdminRole();
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [selectedDMUserId, setSelectedDMUserId] = useState<string | null>(null);
  const [selectedDMUserName, setSelectedDMUserName] = useState<string>("");
  const [chatMode, setChatMode] = useState<ChatMode>("room");
  const [sidebarTab, setSidebarTab] = useState<"rooms" | "dms">("rooms");
  const [showSidebar, setShowSidebar] = useState(true);
  const { messages: roomMessages, loading: roomMsgsLoading, sendMessage: sendRoomMessage, deleteMessage } = useChatMessages(chatMode === "room" ? selectedRoomId : null);
  const { messages: dmMessages, loading: dmMsgsLoading, sendDirectMessage } = useDirectMessages(chatMode === "dm" ? selectedDMUserId : null);
  const { isSelfBanned, isBanned: isChatBanned, banUser: banFromChat, unbanUser: unbanFromChat } = useChatBans(chatMode === "room" ? selectedRoomId : null);
  const { isCurrentUserModerator, isCommunityModerator } = useCommunityModerators();
  const canModerate = isAdmin || isCurrentUserModerator;
  const [draft, setDraft] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportTarget, setReportTarget] = useState<{ userId: string; userName: string; messageId?: string } | null>(null);
  const [reportReason, setReportReason] = useState("spam");
  const [reportDetails, setReportDetails] = useState("");
  const { submitReport } = useUserReports();
  const { roomUnread, dmUnread, markRoomRead, markDMRead } = useUnreadCounts();
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { announcements } = useRoomAnnouncements(chatMode === "room" ? selectedRoomId : null);
  const [announcementsDismissed, setAnnouncementsDismissed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const resizeTextarea = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 144)}px`;
  }, []);

  useEffect(() => {
    resizeTextarea();
  }, [draft, resizeTextarea]);

  useEffect(() => { setAnnouncementsDismissed(false); }, [selectedRoomId]);

  useEffect(() => {
    if (!selectedRoomId && rooms.length > 0) {
      setSelectedRoomId(rooms[0].id);
      markRoomRead(rooms[0].id);
    }
  }, [rooms, selectedRoomId, markRoomRead]);

  const messagesBase = chatMode === "room"
    ? roomMessages.filter((m) => !isChatBanned(m.user_id))
    : dmMessages.filter((m) => !isBlocked(m.sender_id));
  const messages = searchQuery.trim()
    ? messagesBase.filter((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messagesBase;
  const msgsLoading = chatMode === "room" ? roomMsgsLoading : dmMsgsLoading;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!ACCEPTED_TYPES.includes(file.type)) {
      toast.error("Only JPEG, PNG, GIF, and WebP images are allowed.");
      return;
    }
    if (file.size > MAX_IMAGE_SIZE) {
      toast.error("Image must be under 5MB.");
      return;
    }
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const clearImage = () => {
    setImageFile(null);
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSend = async () => {
    const text = draft.trim();
    if (!text && !imageFile) return;
    const file = imageFile;
    setDraft("");
    clearImage();
    if (chatMode === "room") {
      await sendRoomMessage(text || " ", file || undefined);
    } else if (selectedDMUserId) {
      await sendDirectMessage(selectedDMUserId, text || " ", file || undefined);
    }
  };

  const openDM = (userId: string, userName: string) => {
    if (userId === user?.id) return;
    setSelectedDMUserId(userId);
    setSelectedDMUserName(userName);
    setChatMode("dm");
    setSidebarTab("dms");
    setShowSidebar(false);
    markDMRead(userId);
  };

  const selectedRoom = rooms.find((r) => r.id === selectedRoomId);
  const chatHeader = chatMode === "room" ? selectedRoom?.name ?? "Select a room" : selectedDMUserName || "Direct Message";
  const headerIcon = chatMode === "room" ? <Hash className="h-4 w-4 text-primary" /> : <User className="h-4 w-4 text-primary" />;
  const placeholder = chatMode === "room" ? (selectedRoom ? `Message #${selectedRoom.name}` : "Select a room") : `Message ${selectedDMUserName}`;
  const canSend = chatMode === "room" ? (!!selectedRoomId && !isSelfBanned) : (!!selectedDMUserId && !isBlocked(selectedDMUserId!));
  const filteredContacts = contacts.filter((c) => !isBlocked(c.userId));

  return (
    <AppLayout className="h-dvh overflow-hidden">
      <SEO title="Community | Brimsom" description="Connect with other scholarship applicants in Brimsom's community chat rooms and direct messages." path="/community" />
      {/* Image lightbox */}
      {expandedImage && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={() => setExpandedImage(null)}>
          <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-white hover:bg-white/20" onClick={() => setExpandedImage(null)}>
            <X className="h-6 w-6" />
          </Button>
          <img src={expandedImage} alt="Full size" className="max-w-full max-h-full object-contain rounded-lg" />
        </div>
      )}

      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Sidebar */}
        <aside className={`${showSidebar ? "flex" : "hidden"} md:flex flex-col w-full md:w-72 border-r border-border bg-card shrink-0`}>
          <div className="p-3 border-b border-border">
            <Tabs value={sidebarTab} onValueChange={(v) => setSidebarTab(v as "rooms" | "dms")}>
              <TabsList className="w-full">
                <TabsTrigger value="rooms" className="flex-1 gap-1"><Hash className="h-3 w-3" /> Rooms</TabsTrigger>
                <TabsTrigger value="dms" className="flex-1 gap-1"><MessageCircle className="h-3 w-3" /> DMs</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="flex-1 overflow-y-auto">
            {sidebarTab === "rooms" ? (
              roomsLoading ? (
                <p className="p-4 text-sm text-muted-foreground">Loading…</p>
              ) : (
                rooms.map((room) => {
                  const unread = roomUnread[room.id] ?? 0;
                  return (
                    <button
                      key={room.id}
                      onClick={() => { setSelectedRoomId(room.id); setChatMode("room"); setShowSidebar(false); markRoomRead(room.id); }}
                      className={`w-full text-left px-4 py-3 hover:bg-accent transition-colors ${chatMode === "room" && room.id === selectedRoomId ? "bg-accent" : ""}`}
                    >
                      <div className="flex items-center gap-2">
                        <Hash className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="font-medium text-sm flex-1 truncate">{room.name}</span>
                        {unread > 0 && (
                          <span className="bg-primary text-primary-foreground text-[10px] font-bold rounded-full px-1.5 min-w-[18px] h-[18px] flex items-center justify-center">
                            {unread > 99 ? "99+" : unread}
                          </span>
                        )}
                      </div>
                      {room.description && <p className="text-xs text-muted-foreground mt-0.5 ml-6 line-clamp-1">{room.description}</p>}
                    </button>
                  );
                })
              )
            ) : (
              contactsLoading ? (
                <p className="p-4 text-sm text-muted-foreground">Loading…</p>
              ) : filteredContacts.length === 0 ? (
                <p className="p-4 text-sm text-muted-foreground text-center">No conversations yet. Click a username in any chat room to start a DM.</p>
              ) : (
                filteredContacts.map((contact) => {
                  const unread = dmUnread[contact.userId] ?? 0;
                  return (
                    <button
                      key={contact.userId}
                      onClick={() => openDM(contact.userId, contact.userName)}
                      className={`w-full text-left px-4 py-3 hover:bg-accent transition-colors ${chatMode === "dm" && selectedDMUserId === contact.userId ? "bg-accent" : ""}`}
                    >
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6"><AvatarFallback className="text-xs">{contact.userName.charAt(0).toUpperCase()}</AvatarFallback></Avatar>
                        <span className="font-medium text-sm truncate flex-1">{contact.userName}</span>
                        {unread > 0 && (
                          <span className="bg-primary text-primary-foreground text-[10px] font-bold rounded-full px-1.5 min-w-[18px] h-[18px] flex items-center justify-center">
                            {unread > 99 ? "99+" : unread}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 ml-8 line-clamp-1">{contact.lastMessage}</p>
                    </button>
                  );
                })
              )
            )}
          </div>
        </aside>

        {/* Chat area */}
        <div className={`${!showSidebar ? "flex" : "hidden"} md:flex flex-col flex-1 min-w-0 h-full`}>
          {/* Header */}
          <div className="shrink-0 border-b border-border px-4 py-3 flex items-center gap-2">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setShowSidebar(true)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            {headerIcon}
            <span className="font-semibold flex-1">{chatHeader}</span>

            <Button
              variant={searchOpen ? "secondary" : "ghost"}
              size="icon"
              onClick={() => { setSearchOpen(!searchOpen); if (searchOpen) setSearchQuery(""); }}
              title="Search messages"
            >
              <Search className="h-4 w-4" />
            </Button>

            {chatMode === "dm" && selectedDMUserId && (
              isBlocked(selectedDMUserId) ? (
                <Button variant="outline" size="sm" onClick={() => unblockUser(selectedDMUserId)} className="gap-1">
                  <ShieldCheck className="h-4 w-4" /> Unblock
                </Button>
              ) : (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-1 text-destructive border-destructive/30">
                      <ShieldBan className="h-4 w-4" /> Block
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Block {selectedDMUserName}?</AlertDialogTitle>
                      <AlertDialogDescription>You won't receive messages from this user anymore. You can unblock them later.</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => { if (selectedDMUserId) blockUser(selectedDMUserId); }}>Block</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )
            )}
          </div>

          {/* Search bar */}
          {searchOpen && (
            <div className="shrink-0 px-4 py-2 border-b border-border bg-muted/30">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search messages…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 h-9"
                  autoFocus
                />
                {searchQuery && (
                  <Button variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7" onClick={() => setSearchQuery("")}>
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </div>
              {searchQuery.trim() && (
                <p className="text-xs text-muted-foreground mt-1">{messages.length} result{messages.length !== 1 ? "s" : ""} found</p>
              )}
            </div>
          )}

          {/* Pinned Announcements */}
          {chatMode === "room" && announcements.length > 0 && !announcementsDismissed && (
            <div className="shrink-0 mx-4 mt-3 rounded-lg border border-primary/20 bg-primary/5 p-3">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-primary">
                  <Pin className="h-3 w-3" /> Pinned Announcement
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setAnnouncementsDismissed(true)}>
                  <X className="h-3 w-3" />
                </Button>
              </div>
              <div className="space-y-2 max-h-24 overflow-y-auto">
                {announcements.slice(0, 3).map((a) => (
                  <p key={a.id} className="text-sm">{a.content}</p>
                ))}
              </div>
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 min-h-0 overflow-y-auto p-4">
            {msgsLoading ? (
              <p className="text-sm text-muted-foreground">Loading messages…</p>
            ) : messages.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center mt-8">No messages yet. Start the conversation!</p>
            ) : (
              <div className="space-y-4">
                {messages.map((msg) => {
                  const senderId = "user_id" in msg ? msg.user_id : msg.sender_id;
                  const senderName = "user_name" in msg ? msg.user_name : msg.sender_name;
                  const isOwn = senderId === user?.id;
                  const msgImageUrl = msg.image_url;
                  return (
                    <div key={msg.id} className={`group flex w-full ${isOwn ? "justify-end" : "justify-start"}`}>
                      <div className={`flex max-w-[75%] ${isOwn ? "flex-row-reverse" : "flex-row"} items-end gap-2`}>
                        <Avatar className="h-8 w-8 shrink-0">
                          <AvatarFallback className="text-xs">{senderName.charAt(0).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          {!isOwn && (
                            <div className="flex items-center gap-2 mb-1">
                              <button
                                onClick={() => openDM(senderId, senderName)}
                                className="text-xs font-semibold hover:underline cursor-pointer"
                              >
                                {senderName}
                              </button>
                              {isCommunityModerator(senderId) && (
                                <span title="Community Moderator"><Shield className="h-3 w-3 text-primary" /></span>
                              )}
                            </div>
                          )}
                          <div
                            className={`relative p-3 rounded-2xl ${
                              isOwn
                                ? "bg-primary text-primary-foreground rounded-br-none"
                                : "bg-muted rounded-bl-none"
                            }`}
                          >
                            {msg.content.trim() && <p className="text-sm break-words">{msg.content}</p>}
                            {msgImageUrl && (
                              <button onClick={() => setExpandedImage(msgImageUrl)} className="mt-1 block">
                                <img
                                  src={msgImageUrl}
                                  alt="Attachment"
                                  className="max-w-[240px] max-h-[200px] rounded-lg object-cover cursor-pointer hover:opacity-90 transition-opacity"
                                />
                              </button>
                            )}
                            <span className={`text-[10px] mt-1 block ${isOwn ? "text-primary-foreground/70 text-right" : "text-muted-foreground"}`}>
                              {format(new Date(msg.created_at), "p")}
                            </span>
                          </div>
                          {/* Action buttons */}
                          <div className={`flex items-center gap-1 mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity ${isOwn ? "justify-end" : "justify-start"}`}>
                            {chatMode === "room" && (isOwn || canModerate) && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-muted-foreground hover:text-destructive"
                                onClick={() => deleteMessage(msg.id)}
                                title="Delete message"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            )}
                            {chatMode === "room" && canModerate && !isOwn && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-muted-foreground hover:text-destructive"
                                onClick={() => {
                                  banFromChat(senderId);
                                  toast.success(`${senderName} has been banned from this room`);
                                }}
                                title="Ban from chat"
                              >
                                <ShieldBan className="h-3 w-3" />
                              </Button>
                            )}
                            {!isOwn && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-muted-foreground hover:text-yellow-600"
                                onClick={() => {
                                  setReportTarget({ userId: senderId, userName: senderName, messageId: msg.id });
                                  setReportReason("spam");
                                  setReportDetails("");
                                  setReportOpen(true);
                                }}
                                title="Report user"
                              >
                                <Flag className="h-3 w-3" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>
            )}
          </div>

          {/* Image preview */}
          {imagePreview && (
            <div className="shrink-0 px-4 pt-2 flex items-center gap-2">
              <div className="relative">
                <img src={imagePreview} alt="Preview" className="h-16 w-16 rounded-lg object-cover border border-border" />
                <button
                  onClick={clearImage}
                  className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
              <span className="text-xs text-muted-foreground truncate max-w-[200px]">{imageFile?.name}</span>
            </div>
          )}

          {/* Input */}
          {isSelfBanned && chatMode === "room" ? (
            <div className="shrink-0 border-t border-border p-4 text-center text-sm text-destructive">
              <ShieldBan className="h-4 w-4 inline mr-1.5" />
              You are banned from sending messages in this room.
            </div>
          ) : (
          <div className="shrink-0 border-t border-border p-4">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-2 items-end">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif,image/webp"
                className="hidden"
                onChange={handleImageSelect}
              />
              <Button type="button" variant="ghost" size="icon" disabled={!canSend} onClick={() => fileInputRef.current?.click()} className="shrink-0">
                <ImagePlus className="h-4 w-4" />
              </Button>
              <Textarea
                ref={textareaRef}
                placeholder={placeholder}
                value={draft}
                onChange={(e) => { setDraft(e.target.value); resizeTextarea(); }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                disabled={!canSend}
                rows={1}
                maxLength={2000}
                className="flex-1 min-h-10 max-h-36 resize-none py-2.5"
              />
              <Button type="submit" size="icon" disabled={(!draft.trim() && !imageFile) || !canSend} className="shrink-0"><Send className="h-4 w-4" /></Button>
            </form>
          </div>
          )}
        </div>
      </div>
      {/* Report Dialog */}
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Report {reportTarget?.userName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Reason</Label>
              <Select value={reportReason} onValueChange={setReportReason}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="spam">Spam</SelectItem>
                  <SelectItem value="harassment">Harassment</SelectItem>
                  <SelectItem value="inappropriate">Inappropriate Content</SelectItem>
                  <SelectItem value="impersonation">Impersonation</SelectItem>
                  <SelectItem value="scam">Scam / Fraud</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Details (optional)</Label>
              <Textarea
                value={reportDetails}
                onChange={(e) => setReportDetails(e.target.value)}
                placeholder="Provide additional context..."
                rows={3}
                maxLength={1000}
              />
            </div>
            <Button
              className="w-full"
              disabled={submitReport.isPending}
              onClick={() => {
                if (!reportTarget) return;
                submitReport.mutate({
                  reported_user_id: reportTarget.userId,
                  reported_message_id: reportTarget.messageId,
                  room_id: chatMode === "room" ? selectedRoomId ?? undefined : undefined,
                  reason: reportReason,
                  details: reportDetails || undefined,
                });
                setReportOpen(false);
              }}
            >
              Submit Report
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
