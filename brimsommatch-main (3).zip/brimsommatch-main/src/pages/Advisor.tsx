import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Sparkles, Plus, Trash2, MessageSquare, Send, Menu, PanelLeftClose, PanelLeftOpen, Pencil, Check, X, LayoutDashboard, Wand2, PenLine } from "lucide-react";
import MatchMeDialog from "@/components/advisor/MatchMeDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import AppNav from "@/components/AppNav";
import BottomNav from "@/components/BottomNav";
import AdvisorMessageView from "@/components/advisor/AdvisorMessage";
import EssayQualityHint from "@/components/advisor/EssayQualityHint";
import BrimQuestionCard, { extractBrimQuestion } from "@/components/brim/BrimQuestionCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { UserCog, LifeBuoy, Crown, LogOut } from "lucide-react";
import {
  useAdvisorConversations,
  loadMessages,
  saveMessage,
  type AdvisorMessage,
} from "@/hooks/useAdvisorConversations";
import { formatDistanceToNow } from "date-fns";
import SEO from "@/components/SEO";

const SUGGESTIONS = [
  "Find me Master's scholarships I'm eligible for",
  "Help me draft an SOP for a Computer Science MSc",
  "What are my realistic chances at Chevening?",
  "Analyse my chance of winning a scholarship",
];

type UIMessage = { role: "user" | "assistant"; content: string; hidden?: boolean };

const ESSAY_KICKOFF = "I want to write my personal statement / Statement of Purpose. Please guide me step by step — ask one question at a time about my background, target university, professor/lab, key project, research interest, and career goals before drafting.";

const ESSAY_SUGGESTIONS = [
  "Draft a Statement of Purpose for a Master's program",
  "Help me write a personal statement for a PhD",
  "Write a motivation letter for a scholarship",
  "Polish my existing SOP draft",
];

const STOPWORDS = new Set([
  "a","an","the","and","or","but","if","of","for","to","in","on","at","by","with","from","as","is","are","was","were","be","been","being","have","has","had","do","does","did","will","would","can","could","should","may","might","must","shall","i","you","he","she","it","we","they","me","my","your","his","her","our","their","this","that","these","those","what","which","who","whom","whose","when","where","why","how","there","here","not","no","yes","so","than","then","just","about","into","over","under","up","down","out","off","very","really","also","some","any","all","more","most","much","many","few","help","find","tell","give","show","ask","please","need","want","get","got","make","made","let","like","know","think","say","said","go","going","gone","come","came","take","taken","look","see","seen","eligible","best","good","great","nice","ok","okay","hi","hello","hey","thanks","thank"
]);

function generateTitle(text: string): string {
  // Strip punctuation, lowercase split
  const words = text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s'-]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);

  // Capitalize words from original casing if possible
  const originalWords = text.replace(/[^\p{L}\p{N}\s'-]/gu, " ").split(/\s+/).filter(Boolean);
  const caseMap = new Map<string, string>();
  originalWords.forEach((w) => {
    if (!caseMap.has(w.toLowerCase())) caseMap.set(w.toLowerCase(), w);
  });

  const keywords = words.filter((w) => w.length > 2 && !STOPWORDS.has(w));
  const picked = (keywords.length ? keywords : words).slice(0, 4);

  const title = picked
    .map((w) => {
      const orig = caseMap.get(w) ?? w;
      // Keep proper-casing if original was capitalized, else titlecase
      return /[A-Z]/.test(orig) ? orig : orig.charAt(0).toUpperCase() + orig.slice(1);
    })
    .join(" ");

  return title || text.slice(0, 40);
}

export default function Advisor() {
  const { conversations, createConversation, renameConversation, deleteConversation, reload } =
    useAdvisorConversations();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(20);
  const [desktopCollapsed, setDesktopCollapsed] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [scoresVersion, setScoresVersion] = useState(0);
  const [matchOpen, setMatchOpen] = useState(false);
  const [matchConfirmOpen, setMatchConfirmOpen] = useState(false);
  const [essayMode, setEssayMode] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { user, signOut } = useAuth();
  const { settings } = useSiteSettings();
  const showUpgrade = (settings.advisor_upgrade_enabled ?? "true") !== "false";
  const [profile, setProfile] = useState<{ full_name: string | null; avatar_url: string | null } | null>(null);
  const initialMessageHandled = useRef(false);
  const skipNextConversationLoad = useRef(false);

  const resizeTextarea = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    const cap = Math.round(window.innerHeight * 0.3);
    el.style.height = `${Math.min(el.scrollHeight, cap)}px`;
  };

  useEffect(() => {
    resizeTextarea();
  }, [input]);

  useEffect(() => {
    document.title = "Brim Ai Chat | Brimsom";
  }, []);

  // Auto-open Match Me when arriving via ?match=1 (e.g. from quick actions)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get("match") === "1") {
      setMatchConfirmOpen(true);
      // Strip the param so refreshes don't re-trigger
      navigate(location.pathname, { replace: true });
    }
  }, [location.search, location.pathname, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("full_name, avatar_url").eq("user_id", user.id).maybeSingle()
      .then(({ data }) => setProfile(data ?? null));
  }, [user]);

  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      return;
    }
    if (skipNextConversationLoad.current) {
      skipNextConversationLoad.current = false;
      return;
    }
    setEssayMode(false);
    loadMessages(activeId).then((msgs) =>
      setMessages(msgs.map((m: AdvisorMessage) => ({ role: m.role, content: m.content })))
    );
  }, [activeId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, streaming]);

  const startNew = async () => {
    const c = await createConversation();
    if (c) {
      setActiveId(c.id);
      setMessages([]);
      setEssayMode(false);
      setSidebarOpen(false);
    }
  };

  const handleSend = async (text?: string, opts?: { hidden?: boolean; seedHidden?: string }) => {
    const content = (text ?? input).trim();
    if (!content || streaming) return;

    let convId = activeId;
    if (!convId) {
      const c = await createConversation();
      if (!c) {
        toast({ title: "Could not start conversation", variant: "destructive" });
        return;
      }
      convId = c.id;
      skipNextConversationLoad.current = true;
      setActiveId(convId);
    }

    const userMsg: UIMessage = { role: "user", content, hidden: opts?.hidden };
    const visibleCount = messages.filter(m => !m.hidden).length;
    const autoSeed = essayMode && visibleCount === 0 && !opts?.seedHidden && !opts?.hidden
      ? ESSAY_KICKOFF
      : opts?.seedHidden;
    const seed: UIMessage[] = autoSeed
      ? [{ role: "user", content: autoSeed, hidden: true }]
      : [];
    const newHistory = [...messages, ...seed, userMsg];
    setMessages(newHistory);
    setInput("");
    setStreaming(true);

    if (!opts?.hidden) saveMessage(convId, "user", content);

    // Smart auto-title: only if conversation has no title yet (first user msg)
    const conv = conversations.find((c) => c.id === convId);
    if (!conv?.title && messages.length === 0) {
      renameConversation(convId, opts?.hidden ? "Personal Statement" : generateTitle(content));
    }

    try {
      const { data: { session } } = await import("@/integrations/supabase/client").then(m => m.supabase.auth.getSession());
      const token = session?.access_token;

      const resp = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/advisor-chat`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token ?? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
          },
          body: JSON.stringify({ messages: newHistory }),
        }
      );

      if (!resp.ok || !resp.body) {
        if (resp.status === 429) {
          toast({ title: "Slow down", description: "Rate limit reached. Try again shortly.", variant: "destructive" });
        } else if (resp.status === 402) {
          toast({ title: "Out of credits", description: "Add credits to continue.", variant: "destructive" });
        } else {
          toast({ title: "Chat failed", variant: "destructive" });
        }
        setStreaming(false);
        return;
      }

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let assistantText = "";

      const pushDelta = (chunk: string) => {
        assistantText += chunk;
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant") {
            return prev.map((m, i) =>
              i === prev.length - 1 ? { ...m, content: assistantText } : m
            );
          }
          return [...prev, { role: "assistant", content: assistantText }];
        });
      };

      let done = false;
      while (!done) {
        const { done: d, value } = await reader.read();
        if (d) break;
        buffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, nl);
          buffer = buffer.slice(nl + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const json = line.slice(6).trim();
          if (json === "[DONE]") { done = true; break; }
          try {
            const parsed = JSON.parse(json);
            const c = parsed.choices?.[0]?.delta?.content;
            if (c) pushDelta(c);
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }

      if (assistantText) {
        await saveMessage(convId, "assistant", assistantText);
      }
      reload();
    } catch (e) {
      console.error(e);
      toast({ title: "Connection error", variant: "destructive" });
    } finally {
      setStreaming(false);
      setScoresVersion((v) => v + 1);
    }
  };

  // Auto-send a message passed via navigation state (e.g. from Dashboard "Ask Brim" hero)
  useEffect(() => {
    const state = location.state as { initialMessage?: string; firstTime?: boolean } | null;
    if (!state || initialMessageHandled.current) return;
    if (!state.initialMessage && !state.firstTime) return;
    initialMessageHandled.current = true;
    // Clear nav state so refresh / back doesn't re-trigger
    navigate(location.pathname, { replace: true, state: {} });
    if (state.initialMessage) {
      handleSend(state.initialMessage);
    }
  }, [location.state]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteConversation(id);
    if (activeId === id) {
      setActiveId(null);
      setMessages([]);
    }
  };

  const startRename = (id: string, currentTitle: string | null, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingId(id);
    setRenameValue(currentTitle ?? "");
  };

  const commitRename = async (e?: React.MouseEvent | React.KeyboardEvent) => {
    e?.stopPropagation();
    if (!renamingId) return;
    const v = renameValue.trim();
    if (v) await renameConversation(renamingId, v);
    setRenamingId(null);
    setRenameValue("");
  };

  const cancelRename = (e?: React.MouseEvent | React.KeyboardEvent) => {
    e?.stopPropagation();
    setRenamingId(null);
    setRenameValue("");
  };

  const Sidebar = useMemo(() => (
    <div className="flex flex-col h-full bg-card">
      <div className="p-3 border-b space-y-2">
        <Button asChild variant="outline" className="w-full justify-start gap-2">
          <Link to="/dashboard">
            <LayoutDashboard className="h-4 w-4" /> Visit Dashboard
          </Link>
        </Button>
        <Button onClick={startNew} className="w-full justify-start gap-2" variant="default">
          <Plus className="h-4 w-4" /> New chat
        </Button>
      </div>
      <div className="px-3 py-3 border-b">
        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">Features</p>
        <Button
          variant="secondary"
          className="w-full justify-start gap-2"
          onClick={() => { setMatchConfirmOpen(true); setSidebarOpen(false); }}
        >
          <Wand2 className="h-4 w-4" /> Match Me
        </Button>
        <Button
          variant="secondary"
          className="w-full justify-start gap-2 mt-2"
          onClick={() => {
            // Instant switch to a clean essay-mode empty state; no visible kickoff message
            setActiveId(null);
            setMessages([]);
            setInput("");
            setEssayMode(true);
            setSidebarOpen(false);
          }}
        >
          <PenLine className="h-4 w-4" /> Statement Writer
        </Button>

      </div>
      <div className="px-3 pt-3 pb-1">
        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Your Chats</p>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {conversations.length === 0 && (
            <p className="text-xs text-muted-foreground p-3">No conversations yet.</p>
          )}
          {conversations.slice(0, visibleCount).map((c) => {
            const isRenaming = renamingId === c.id;
            return (
              <div
                key={c.id}
                onClick={() => { if (!isRenaming) { setActiveId(c.id); setSidebarOpen(false); } }}
                className={cn(
                  "group relative grid w-full min-w-0 grid-cols-[auto,minmax(0,1fr)] items-start gap-2 rounded-lg px-3 py-2 text-left text-sm transition hover:bg-muted cursor-pointer",
                  activeId === c.id && "bg-muted"
                )}
              >
                <MessageSquare className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0 overflow-hidden pr-14">
                  {isRenaming ? (
                    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      <Input
                        autoFocus
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") commitRename(e);
                          if (e.key === "Escape") cancelRename(e);
                        }}
                        className="h-7 text-sm px-2"
                      />
                      <button onClick={commitRename} className="p-1 hover:text-primary">
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      <button onClick={cancelRename} className="p-1 hover:text-destructive">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <p className="block w-full truncate font-medium" title={c.title ?? "New chat"}>{c.title ?? "New chat"}</p>
                      <p className="block w-full truncate text-[10px] text-muted-foreground">
                        {formatDistanceToNow(new Date(c.updated_at), { addSuffix: true })}
                      </p>
                    </>
                  )}
                </div>
                {!isRenaming && (
                  <div
                    className={cn(
                      "absolute right-1.5 top-1.5 flex items-center gap-0 rounded-md bg-background/95 p-0.5 shadow-sm backdrop-blur-sm transition-opacity",
                      activeId === c.id
                        ? "opacity-100"
                        : "opacity-100 md:opacity-0 md:group-hover:opacity-100 md:focus-within:opacity-100"
                    )}
                  >
                    <button
                      onClick={(e) => startRename(c.id, c.title, e)}
                      className="p-1 rounded text-muted-foreground hover:text-primary hover:bg-background"
                      aria-label="Rename"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(c.id, e)}
                      className="p-1 rounded text-muted-foreground hover:text-destructive hover:bg-background"
                      aria-label="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
          {conversations.length > visibleCount && (
            <button
              onClick={() => setVisibleCount((n) => n + 20)}
              className="w-full text-xs text-muted-foreground hover:text-foreground py-2"
            >
              Load more
            </button>
          )}
        </div>
      </ScrollArea>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="border-t p-3 flex items-center gap-3 hover:bg-muted transition-colors text-left w-full">
            <Avatar className="h-9 w-9">
              <AvatarImage src={profile?.avatar_url ?? undefined} alt={profile?.full_name ?? "Profile"} />
              <AvatarFallback>
                {(profile?.full_name ?? user?.email ?? "U").trim().charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium truncate">
                {profile?.full_name || user?.email?.split("@")[0] || "Your profile"}
              </p>
              <p className="text-xs text-muted-foreground truncate">Account</p>
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" side="top" className="w-56">
          <DropdownMenuItem onClick={() => { setSidebarOpen(false); navigate("/profile"); }}>
            <UserCog className="h-4 w-4 mr-2" /> Update profile
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => { setSidebarOpen(false); navigate("/support"); }}>
            <LifeBuoy className="h-4 w-4 mr-2" /> Get help
          </DropdownMenuItem>
          {showUpgrade && (
            <DropdownMenuItem onClick={() => { setSidebarOpen(false); navigate("/pricing"); }}>
              <Crown className="h-4 w-4 mr-2" /> Upgrade plan
            </DropdownMenuItem>
          )}
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onClick={async () => { await signOut(); navigate("/auth"); }}
            className="text-destructive focus:text-destructive"
          >
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  ), [conversations, visibleCount, activeId, renamingId, renameValue, profile, user, showUpgrade]);

  return (
    <div className="h-dvh overflow-hidden bg-background">
      <SEO title="Brim Advisor | Brimsom" description="Chat with Brim, your AI scholarship advisor, grounded in your profile and live scholarship data." path="/advisor" />
      <AppNav />
      <div className="flex h-dvh overflow-hidden pt-[calc(4rem+env(safe-area-inset-top,0px))] pb-[calc(4rem+env(safe-area-inset-bottom,0px))] lg:pb-0">
        {/* Desktop sidebar (collapsible) */}
        <aside
          className={cn(
            "hidden md:flex border-r flex-col transition-all duration-200",
            desktopCollapsed ? "w-0 overflow-hidden border-r-0" : "w-72"
          )}
        >
          {Sidebar}
        </aside>

        {/* Mobile sidebar */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="p-0 w-72 pt-8">
            {Sidebar}
          </SheetContent>
        </Sheet>

        {/* Main chat */}
        <main className="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">
          <header className="border-b px-4 py-2 flex items-center gap-2">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:inline-flex"
              onClick={() => setDesktopCollapsed((v) => !v)}
              aria-label={desktopCollapsed ? "Open sidebar" : "Collapse sidebar"}
            >
              {desktopCollapsed ? <PanelLeftOpen className="h-5 w-5" /> : <PanelLeftClose className="h-5 w-5" />}
            </Button>
            {settings.logo_url ? (
              <img src={settings.logo_url} alt="Brimsom" className="h-6 w-6 rounded-md object-contain" />
            ) : (
              <Sparkles className="h-5 w-5 text-primary" />
            )}
            <h1 className="font-semibold truncate flex items-center gap-2">
              <span className="truncate">
                {conversations.find((c) => c.id === activeId)?.title ?? "Brim Chat"}
              </span>
              <span className="shrink-0 text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-gradient-to-r from-primary/15 to-primary/5 text-primary border border-primary/20 tracking-wide">
                Brim V1
              </span>
            </h1>
          </header>

          <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto overscroll-contain">
            {messages.filter(m => !m.hidden).length === 0 ? (
              essayMode ? (
                <div className="h-full flex flex-col items-center justify-center px-4 text-center">
                  <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                    <PenLine className="h-7 w-7 text-primary" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-2">Let's craft your essay</h2>
                  <p className="text-muted-foreground text-sm mb-6 max-w-md">
                    Statements of Purpose, personal statements, and motivation letters — guided step by step using your profile and your own words.
                  </p>
                  <div className="grid sm:grid-cols-2 gap-2 w-full max-w-2xl">
                    {ESSAY_SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => handleSend(s, { seedHidden: ESSAY_KICKOFF })}
                        className="text-left p-3 rounded-xl border hover:bg-muted transition text-sm"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground mt-6 max-w-md">
                    Or type your own request below — Brim will ask one question at a time before drafting.
                  </p>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center px-4 text-center">
                  <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                    <Sparkles className="h-7 w-7 text-primary" />
                  </div>
                  <h2 className="text-2xl font-semibold mb-2">How can I help?</h2>
                  <p className="text-muted-foreground text-sm mb-6 max-w-md">
                    Personalized advice on scholarships, admissions, and SOPs, grounded in your profile and our live scholarship database.
                  </p>
                  <div className="grid sm:grid-cols-2 gap-2 w-full max-w-2xl">
                    {SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => handleSend(s)}
                        className="text-left p-3 rounded-xl border hover:bg-muted transition text-sm"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )
            ) : (
              <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
                {messages.map((m, i) => {
                  if (m.hidden) return null;
                  const isLast = i === messages.length - 1;
                  if (m.role === "assistant") {
                    const { text, question } = extractBrimQuestion(m.content || "");
                    return (
                      <div key={i} className="flex flex-col items-start gap-2 w-full">
                        {(text || !question) && (
                          <div className="rounded-2xl px-4 py-3 w-full max-w-[85%] bg-muted">
                            <AdvisorMessageView content={text || "..."} scoresVersion={scoresVersion} />
                          </div>
                        )}
                        {question && (
                          <div className="w-full max-w-[85%]">
                            <BrimQuestionCard
                              data={question}
                              disabled={streaming || !isLast}
                              onAnswer={(ans) => handleSend(ans)}
                            />
                          </div>
                        )}
                      </div>
                    );
                  }
                  return (
                    <div key={i} className="flex justify-end">
                      <div className="rounded-2xl px-4 py-3 max-w-[85%] bg-primary text-primary-foreground">
                        <p className="whitespace-pre-wrap text-sm">{m.content}</p>
                      </div>
                    </div>
                  );
                })}
                {streaming && messages[messages.length - 1]?.role === "user" && (
                  <div className="flex justify-start">
                    <div className="rounded-2xl px-4 py-3 bg-muted text-sm text-muted-foreground">Thinking…</div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="shrink-0 bg-background/95 p-3 backdrop-blur supports-[backdrop-filter]:bg-background/80">
            <EssayQualityHint input={input} />
            <div className="max-w-3xl mx-auto">
              <div className="rounded-3xl border bg-card shadow-sm px-4 pt-3 pb-2 transition-shadow focus-within:shadow-md">
                <Textarea
                  value={input}
                  ref={textareaRef}
                  rows={1}
                  onChange={(e) => {
                    setInput(e.target.value);
                    requestAnimationFrame(resizeTextarea);
                  }}
                  onInput={resizeTextarea}
                  onPaste={() => requestAnimationFrame(resizeTextarea)}
                  onKeyDown={handleKeyDown}
                  placeholder="Write a message…"
                  className="min-h-[40px] max-h-[30vh] resize-none overflow-y-auto border-0 bg-transparent p-0 leading-6 shadow-none focus-visible:ring-0 focus-visible:ring-offset-0"
                  disabled={streaming}
                />
                <div className="flex items-center justify-between pt-1">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition"
                      >
                        <Sparkles className="h-3.5 w-3.5 text-primary" />
                        Brim V1
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start" side="top" className="w-56">
                      <DropdownMenuItem className="flex-col items-start gap-0.5">
                        <span className="text-sm font-medium flex items-center gap-1.5">
                          <Sparkles className="h-3.5 w-3.5 text-primary" /> Brim V1
                        </span>
                        <span className="text-[11px] text-muted-foreground">Current model — grounded in your profile</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem disabled className="flex-col items-start gap-0.5 opacity-70">
                        <span className="text-sm font-medium">Brim V2</span>
                        <span className="text-[11px] text-muted-foreground">Coming soon</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button
                    onClick={() => handleSend()}
                    disabled={!input.trim() || streaming}
                    size="icon"
                    className="h-9 w-9 rounded-full shrink-0"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <p className="text-center text-[11px] text-muted-foreground mt-2">
                Brim is AI and can make mistakes. Please double-check responses.
              </p>
            </div>
          </div>


        </main>
      </div>
      <BottomNav />
      <MatchMeDialog open={matchOpen} onOpenChange={setMatchOpen} />
      <AlertDialog open={matchConfirmOpen} onOpenChange={setMatchConfirmOpen}>
        <AlertDialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Is your profile up to date?</AlertDialogTitle>
            <AlertDialogDescription>
              For the most accurate match and win-chance score, your profile should reflect your latest education, scores, and experience.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => { setMatchConfirmOpen(false); navigate("/profile"); }}>
              No, update profile
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => { setMatchConfirmOpen(false); setMatchOpen(true); }}>
              Yes, continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
