import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import AppLayout from "@/components/AppLayout";
import ScholarshipCard from "@/components/scholarships/ScholarshipCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Sparkles } from "lucide-react";
import { useChanceScore } from "@/hooks/useChanceScore";
import { useSavedScholarships } from "@/hooks/useSavedScholarships";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useCategoryApplySteps } from "@/hooks/useCategoryApplySteps";
import { useScoreSingle } from "@/hooks/useScoreSingle";
import { useAdminRole } from "@/hooks/useAdminRole";
import { useActivityLog } from "@/hooks/useActivityLog";
import { toast } from "sonner";
import SEO from "@/components/SEO";

export default function ScholarshipDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin } = useAdminRole();
  const { logActivity } = useActivityLog();
  const { score } = useChanceScore();
  const { savedIds, toggleSave } = useSavedScholarships();
  const { settings } = useSiteSettings();
  const { data: categoryApplySteps } = useCategoryApplySteps();
  const { scoreSingle, scoringId } = useScoreSingle();

  const [scholarship, setScholarship] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [stepsExpanded, setStepsExpanded] = useState(false);
  const [singleMatch, setSingleMatch] = useState<any | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    supabase
      .from("scholarships")
      .select("*")
      .eq("id", id)
      .eq("is_active", true)
      .maybeSingle()
      .then(({ data }) => {
        setScholarship(data);
        setLoading(false);
      });
  }, [id]);

  const matchData = useMemo(() => {
    if (singleMatch) return singleMatch;
    const m = score?.scholarship_matches?.find((x) => x.scholarship_id === id);
    if (!m) return undefined;
    return {
      score: m.score,
      chance: m.chance,
      reason: m.reason,
      chance_reason: m.chance_reason ?? "",
      pending_ai: m.pending_ai,
    };
  }, [score, id, singleMatch]);

  const handleApply = () => {
    if (!scholarship?.url || !user) return;
    supabase.from("scholarship_apply_clicks").insert({
      scholarship_id: scholarship.id,
      user_id: user.id,
    } as any).then(() => {});
    window.open(scholarship.url, "_blank", "noopener,noreferrer");
  };

  const handleScoreWithAI = async () => {
    if (!id) return;
    const result = await scoreSingle(id);
    if (result) {
      setSingleMatch({
        score: result.score,
        chance: result.chance,
        reason: result.reason,
        chance_reason: result.chance_reason,
        pending_ai: false,
      });
    }
  };

  return (
    <AppLayout>
      <SEO title="Scholarship Details | Brimsom" description="Full eligibility, deadlines, funding, and application details for this scholarship." />
      <div className="w-full max-w-3xl mx-auto px-4 py-4 space-y-4">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="-ml-2">
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>

        {loading ? (
          <div className="space-y-3">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-48 w-full rounded-xl" />
          </div>
        ) : !scholarship ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <h2 className="text-lg font-semibold mb-2">Scholarship not found</h2>
            <p className="text-sm text-muted-foreground mb-4">
              This scholarship may have been removed or is no longer active.
            </p>
            <Button onClick={() => navigate("/scholarships")}>Browse Scholarships</Button>
          </div>
        ) : (
          <>
            {!matchData && (
              <div className="rounded-lg border border-border bg-muted/30 p-3 flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">
                  Generate scores on the{" "}
                  <button
                    onClick={() => navigate("/score")}
                    className="text-primary hover:underline font-medium"
                  >
                    Score page
                  </button>{" "}
                  to see your personalized match analysis for this scholarship.
                </p>
              </div>
            )}

            {matchData?.pending_ai && (
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 flex items-center justify-between gap-3">
                <div className="flex items-start gap-2 min-w-0">
                  <Sparkles className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Get a detailed AI analysis of your match and win chance for this scholarship.
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={handleScoreWithAI}
                  disabled={scoringId === id}
                  className="shrink-0"
                >
                  {scoringId === id ? "Scoring…" : "Score with AI"}
                </Button>
              </div>
            )}

            <ScholarshipCard
              scholarship={scholarship}
              matchData={matchData}
              isRecommended={!!matchData && matchData.score >= 70 && matchData.chance >= 70}
              isSaved={savedIds.has(scholarship.id)}
              isExpanded={true}
              isStepsExpanded={stepsExpanded}
              isAdmin={isAdmin}
              isScoring={scoringId === id}
              defaultApplySteps={settings?.default_apply_steps}
              categoryApplySteps={categoryApplySteps}
              onToggleSave={() => toggleSave(scholarship.id, logActivity)}
              onToggleExpand={() => {}}
              onToggleSteps={() => setStepsExpanded((v) => !v)}
              onAsk={() => {
                const params = new URLSearchParams({
                  scholarship: scholarship.id,
                  title: scholarship.title ?? "",
                  provider: scholarship.provider ?? "",
                  country: scholarship.country ?? "",
                });
                navigate(`/brim-chat?${params.toString()}`);
              }}
              onApply={handleApply}
              onScoreWithAI={matchData?.pending_ai ? handleScoreWithAI : undefined}
            />
          </>
        )}
      </div>
    </AppLayout>
  );
}
