import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import SEO from "@/components/SEO";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle, GraduationCap, BarChart3, MessageCircle, ClipboardList, FileText, Shield, Smartphone } from "lucide-react";

const faqCategories = [
  {
    title: "Getting Started",
    icon: HelpCircle,
    items: [
      { q: "How do I create an account?", a: "Tap 'Get Started' on the landing page and sign up with your email address. You'll receive a verification email — click the link to activate your account and start building your profile." },
      { q: "Why should I complete my profile?", a: "Your profile powers scholarship matching, chance scoring, and personalized recommendations. The more complete it is, the better your results. Aim for at least 50% completion to unlock features like the Chance Score." },
      { q: "What information do I need to provide?", a: "Your profile includes personal info (nationality, country of residence), education history, test scores (SAT, GRE, IELTS, etc.), extracurricular activities, research experience, and uploaded documents like transcripts or CVs." },
      { q: "Can I edit my profile later?", a: "Absolutely. Visit the Profile page anytime to update your information. Changes are saved automatically and your recommendations will refresh accordingly." },
    ],
  },
  {
    title: "Scholarships & Matching",
    icon: GraduationCap,
    items: [
      { q: "How does scholarship matching work?", a: "We compare your profile — degree level, field of study, nationality, GPA, and test scores — against our database of active scholarships. Scholarships that align with your qualifications appear as recommended matches on your dashboard." },
      { q: "How do I save a scholarship?", a: "Click the bookmark icon on any scholarship card. Saved scholarships appear on your Saved page for easy access later." },
      { q: "Are scholarship deadlines accurate?", a: "We update deadlines regularly, but always verify on the official scholarship website before applying. Deadlines shown are based on the most recent information available." },
      { q: "Can I filter scholarships?", a: "Yes. Use the filters on the Scholarships page to narrow results by country, degree level, field of study, funding type, and more." },
      { q: "What does 'funding type' mean?", a: "Funding type indicates the coverage: Fully Funded (tuition + living expenses), Partial (tuition only or a fixed amount), or Variable (depends on the applicant's circumstances)." },
    ],
  },
  {
    title: "Chance Score",
    icon: BarChart3,
    items: [
      { q: "What is the Chance Score?", a: "The Chance Score is an AI-generated readiness assessment (0–100) that evaluates how competitive your profile is for international scholarships. It considers your academics, test scores, extracurriculars, and research experience." },
      { q: "How can I improve my score?", a: "Follow the personalized tips provided after generating your score. Common suggestions include improving test scores, adding research experience, strengthening extracurriculars, and completing more of your profile." },
      { q: "Why do I need 50% profile completion?", a: "The AI needs sufficient data to generate a meaningful assessment. With less than 50%, the score wouldn't be reliable enough to be useful." },
      { q: "How often should I regenerate my score?", a: "Regenerate after making significant profile updates — such as adding new test scores, education entries, or extracurricular activities — to see how your readiness has changed." },
    ],
  },
  {
    title: "Community & Chat",
    icon: MessageCircle,
    items: [
      { q: "What are chat rooms?", a: "Chat rooms are topic-based group conversations where you can connect with other students. Rooms are created by admins and may focus on specific countries, scholarship types, or general discussion." },
      { q: "Can I send direct messages?", a: "Yes. You can start a private conversation with any community member. Navigate to the Community page and select a user to message directly." },
      { q: "How do I block someone?", a: "Open the user's profile or message thread and select the block option. Blocked users cannot send you messages or see your activity." },
      { q: "What are room announcements?", a: "Admins and moderators can pin important announcements to chat rooms. These appear at the top of the room so you never miss critical updates." },
    ],
  },
  {
    title: "Application Tracker",
    icon: ClipboardList,
    items: [
      { q: "How does the tracker work?", a: "The Application Tracker lets you manage all your scholarship applications in one place. Add applications from your saved scholarships or create custom entries, then track their status through each stage." },
      { q: "What statuses are available?", a: "You can set applications to: Interested, In Progress, Submitted, Accepted, Rejected, or Waitlisted. Update the status as your application progresses." },
      { q: "Can I add notes to applications?", a: "Yes. Each application has a notes field where you can record deadlines, requirements, login credentials, or any other details you want to remember." },
      { q: "Can I track scholarships not listed on Brimsom?", a: "Yes. Use the 'Add Custom' option to manually add any scholarship with a custom name and deadline." },
    ],
  },
  {
    title: "Documents & Reviews",
    icon: FileText,
    items: [
      { q: "What documents can I upload?", a: "You can upload transcripts, CVs/resumes, recommendation letters, personal statements, and other supporting documents to your profile." },
      { q: "What is the document review service?", a: "Submit documents like SOPs, CVs, or essays for professional review. Our team provides feedback to help strengthen your applications." },
      { q: "How long does a review take?", a: "Review times vary, but you'll receive a notification when feedback is ready. Check the Document Review page for status updates on your submissions." },
      { q: "Are my documents secure?", a: "Yes. Documents are stored securely and only accessible to you and authorized reviewers. We never share your files with third parties." },
    ],
  },
  {
    title: "Privacy & Security",
    icon: Shield,
    items: [
      { q: "How is my data used?", a: "Your profile data is used solely to provide scholarship matching, chance scoring, and personalized recommendations. We do not sell your data to third parties. See our Privacy Policy for full details." },
      { q: "Can I delete my account?", a: "Yes. Contact our support team to request account deletion. All your data, including profile information, documents, and chat history, will be permanently removed." },
      { q: "How do I opt out of emails?", a: "Toggle the 'Scholarship Digest' switch off in the Settings popover (gear icon in the header). You can also unsubscribe using the link in any digest email." },
    ],
  },
  {
    title: "Technical",
    icon: Smartphone,
    items: [
      { q: "Can I install Brimsom as an app?", a: "Yes! Brimsom is a Progressive Web App (PWA). On mobile, tap 'Add to Home Screen' in your browser menu. On desktop, look for the install icon in the address bar." },
      { q: "How do push notifications work?", a: "Enable push notifications from the Settings popover (gear icon). You'll receive alerts for new scholarships, application updates, chat messages, and important announcements." },
      { q: "Which browsers are supported?", a: "Brimsom works best on modern browsers: Chrome, Firefox, Safari, and Edge. For the best experience including PWA features, we recommend Chrome or Safari." },
      { q: "The app isn't loading properly. What should I do?", a: "Try clearing your browser cache and refreshing the page. If the issue persists, try a different browser or contact support through our Support page." },
    ],
  },
];

export default function FAQs() {
  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqCategories.flatMap((cat) =>
      cat.items.map((item) => ({
        "@type": "Question",
        name: item.q,
        acceptedAnswer: { "@type": "Answer", text: item.a },
      }))
    ),
  };

  return (
    <AppLayout>
      <SEO
        title="FAQs | Brimsom"
        description="Answers to common questions about Brimsom — scholarships, chance scores, community, documents, and more."
        path="/faqs"
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <main className="container mx-auto px-4 py-10 max-w-3xl space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-xl sm:text-3xl font-bold flex items-center justify-center gap-2">
            <BackButton iconOnly />
            Frequently Asked Questions
          </h1>
          <p className="text-muted-foreground">Find answers to common questions about using Brimsom.</p>
        </div>

        {faqCategories.map((cat) => (
          <section key={cat.title} className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-3">
              <cat.icon className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold">{cat.title}</h2>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {cat.items.map((item, i) => (
                <AccordionItem key={i} value={`${cat.title}-${i}`}>
                  <AccordionTrigger className="text-left text-sm">{item.q}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-sm">{item.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </section>
        ))}
      </main>
    </AppLayout>
  );
}
