import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import MarkdownContent from "@/components/MarkdownContent";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export default function SharedAdvisor() {
  const { token } = useParams<{ token: string }>();
  const [content, setContent] = useState<string | null>(null);
  const [createdAt, setCreatedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data, error } = await supabase
        .rpc("get_shared_advisor_message" as any, { _token: token });
      const row = Array.isArray(data) ? data[0] : null;
      if (error || !row) setNotFound(true);
      else {
        const cleaned = (row.content as string)
          .replace(/\[\[scholarship:[a-zA-Z0-9-]+\]\]/g, "")
          .replace(/\n{3,}/g, "\n\n")
          .trim();
        setContent(cleaned);
        setCreatedAt(row.created_at as string);
      }
      setLoading(false);
    })();
  }, [token]);

  useEffect(() => {
    document.title = "Shared from Brim Advisor | Brimsom";
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-background">

      <header className="border-b bg-background/70 backdrop-blur">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <Sparkles className="h-5 w-5 text-primary" />
            <span>Brimsom</span>
          </Link>
          <Button asChild size="sm" variant="outline">
            <Link to="/auth">Try Brim Advisor</Link>
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-10">
        <div className="mb-6">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Shared from</p>
          <h1 className="text-2xl font-semibold">Brim Advisor</h1>
          {createdAt && (
            <p className="text-xs text-muted-foreground mt-1">
              {new Date(createdAt).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" })}
            </p>
          )}
        </div>

        <div className="rounded-3xl border bg-card p-6 shadow-sm">
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading…</p>
          ) : notFound ? (
            <p className="text-sm text-muted-foreground">This shared message couldn't be found or has been removed.</p>
          ) : (
            <MarkdownContent content={content || ""} />
          )}
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-3">
            Want personalized scholarship advice like this?
          </p>
          <Button asChild>
            <Link to="/auth">Get started with Brimsom</Link>
          </Button>
        </div>
      </main>
    </div>
  );
}
