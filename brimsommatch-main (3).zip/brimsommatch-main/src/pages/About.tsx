import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, GraduationCap, Target, Sparkles, Users, BarChart3, BookOpen, MessageCircle, Globe } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import MarkdownContent from "@/components/MarkdownContent";
import SEO from "@/components/SEO";

const features = [
  {
    icon: Target,
    title: "AI Chance Score",
    description: "Our AI analyzes your academic profile — education, GPA, test scores, research, and extracurriculars — and generates a Scholarship Readiness Score. This score tells you how prepared you are relative to typical scholarship requirements.",
  },
  {
    icon: Sparkles,
    title: "Smart Matching",
    description: "Instead of manually sifting through hundreds of scholarships, Brimsom's AI compares your profile against each scholarship's eligibility criteria, degree level, field of study, and funding type to surface the ones where you have the best chances.",
  },
  {
    icon: BarChart3,
    title: "Application Tracker",
    description: "Keep track of every scholarship you're applying to. Monitor statuses, deadlines, and notes all in one place so nothing falls through the cracks.",
  },
  {
    icon: BookOpen,
    title: "Document Review",
    description: "Submit your SOPs, CVs, transcripts, and other documents for expert review. Get actionable feedback to strengthen your applications before you submit.",
  },
  {
    icon: MessageCircle,
    title: "Brim AI Chat",
    description: "Have questions about scholarships, applications, or your profile? Chat with Brim, our AI assistant, for instant guidance and tips tailored to your situation.",
  },
  {
    icon: Users,
    title: "Community",
    description: "Connect with fellow scholarship seekers in topic-based chat rooms. Share experiences, ask questions, and support each other through the application journey.",
  },
  {
    icon: Globe,
    title: "PR Pathways",
    description: "Explore post-study permanent residency pathways for different countries. Understand your options beyond graduation.",
  },
];

export default function About() {
  const { settings } = useSiteSettings();
  const logoUrl = settings.logo_url;
  const override = (settings.about_page_content ?? "").trim();

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="About Brimsom — AI-powered scholarship matching"
        description="Learn how Brimsom helps students discover the right scholarships with AI chance scoring, smart matching, and personalized guidance."
        path="/about"
      />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="relative z-10">
        <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto flex items-center justify-between h-16 px-4">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Home</Link>
            </Button>
            <ThemeToggle />
          </div>
        </nav>

        <main className="container mx-auto px-4 py-12 max-w-3xl">
          {override ? (
            <>
              <div className="flex items-center gap-3 mb-8">
                {logoUrl ? (
                  <img src={logoUrl} alt="Brimsom" className="h-12 w-12 rounded-xl object-contain" />
                ) : (
                  <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
                    <GraduationCap className="h-6 w-6 text-primary-foreground" />
                  </div>
                )}
                <h1 className="text-3xl font-bold">About Brimsom</h1>
              </div>
              <Card><CardContent className="pt-6"><MarkdownContent content={override} /></CardContent></Card>
            </>
          ) : (
          <>

          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            {logoUrl ? (
              <img src={logoUrl} alt="Brimsom" className="h-12 w-12 rounded-xl object-contain" />
            ) : (
              <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
            )}
            <div>
              <h1 className="text-3xl font-bold">About Brimsom</h1>
              <p className="text-sm text-muted-foreground">Your AI-powered scholarship companion</p>
            </div>
          </div>

          {/* Mission */}
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg">Our Mission</h2>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed space-y-3">
              <p>
                Brimsom was built with a simple belief: <strong className="text-foreground">every student deserves a fair shot at funding their education</strong>. Too many talented students miss out on scholarships — not because they aren't qualified, but because they don't know where to look or how competitive they are.
              </p>
              <p>
                We created Brimsom to change that. By combining AI-powered profile analysis with a curated scholarship database and a supportive community, we help students discover opportunities matched to their unique strengths and apply with confidence.
              </p>
            </CardContent>
          </Card>

          {/* How it works */}
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg">How It Works</h2>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed space-y-3">
              <p>Brimsom guides you through a simple process:</p>
              <ol className="list-decimal list-inside space-y-2 ml-1">
                <li><strong className="text-foreground">Build Your Profile</strong> — Add your education history, GPA, test scores, research experience, extracurricular activities, and documents.</li>
                <li><strong className="text-foreground">Get Your Score</strong> — Our AI evaluates your profile and generates a Scholarship Readiness Score with personalized tips for improvement.</li>
                <li><strong className="text-foreground">Discover Matches</strong> — Browse scholarships filtered and ranked by how well they match your profile, field of study, and target country.</li>
                <li><strong className="text-foreground">Apply & Track</strong> — Save scholarships, track your applications, set deadline reminders, and get document reviews.</li>
              </ol>
            </CardContent>
          </Card>

          {/* Features */}
          <h2 className="text-xl font-semibold mb-4">Platform Features</h2>
          <div className="grid gap-4 sm:grid-cols-2 mb-8">
            {features.map((feature) => (
              <Card key={feature.title}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <feature.icon className="h-4.5 w-4.5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm mb-1">{feature.title}</h3>
                      <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* AI Scoring */}
          <Card className="mb-6">
            <CardHeader>
              <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg">How AI Scoring Works</h2>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed space-y-3">
              <p>
                Your Scholarship Readiness Score is generated by analyzing multiple dimensions of your academic profile:
              </p>
              <ul className="list-disc list-inside space-y-1.5 ml-1">
                <li><strong className="text-foreground">Education</strong> — Degree level, institution quality, field of study, and GPA</li>
                <li><strong className="text-foreground">Test Scores</strong> — Standardized test performance (GRE, IELTS, TOEFL, SAT, etc.)</li>
                <li><strong className="text-foreground">Research</strong> — Publications, research projects, and academic contributions</li>
                <li><strong className="text-foreground">Extracurriculars</strong> — Leadership, volunteering, awards, and professional experience</li>
                <li><strong className="text-foreground">Documents</strong> — Completeness of your application materials</li>
              </ul>
              <p>
                The AI then compares your profile against the requirements and competitiveness of scholarships in our database to provide both an overall readiness score and individual match percentages.
              </p>
            </CardContent>
          </Card>

          {/* CTA */}
          <div className="text-center py-8">
            <h2 className="text-2xl font-bold mb-3">Ready to get started?</h2>
            <p className="text-muted-foreground mb-6">Create your profile and discover scholarships matched to your strengths.</p>
            <Button size="lg" asChild>
              <Link to="/auth?tab=signup">Get Started for Free</Link>
            </Button>
          </div>
          </>
          )}
        </main>
      </div>
    </div>
  );
}
