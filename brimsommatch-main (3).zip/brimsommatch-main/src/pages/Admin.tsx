import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { useAdminRole } from "@/hooks/useAdminRole";
import { useModeratorPermissions } from "@/hooks/useModeratorPermissions";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Pencil, Trash2, Search, Users, GraduationCap, Bookmark, Sparkles, MessageCircle, BarChart3, Hash, ArrowUp, ArrowDown, Briefcase, Route, FileText, BookOpen, Calendar, Landmark, Bot, RefreshCw, Download, Eye, Bell, Send, Shield, UserPlus, Trophy, type LucideIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAdminSubmissions, useUpdateSubmission, useDeleteSubmission, type DocumentSubmission } from "@/hooks/useDocumentSubmissions";
import { useAdminBookings, useUpdateBooking, type SessionBooking } from "@/hooks/useSessionBookings";
import { Switch } from "@/components/ui/switch";
import { useQuickActions } from "@/hooks/useQuickActions";
import { Checkbox } from "@/components/ui/checkbox";
import ResourcesTab from "@/components/admin/ResourcesTab";
import BlogTab from "@/components/admin/BlogTab";
import InfoSourcesTab from "@/components/admin/InfoSourcesTab";
import DownloadsTab from "@/components/admin/DownloadsTab";
import SupportRequestsTab from "@/components/admin/SupportRequestsTab";
import UserManagementTab from "@/components/admin/UserManagementTab";
import JobApplicationsTab from "@/components/admin/JobApplicationsTab";
import RecentScholarshipsTab, { useRecentScholarshipsCount } from "@/components/admin/RecentScholarshipsTab";
import PendingApprovalsTab from "@/components/admin/PendingApprovalsTab";
import OldReviewTab from "@/components/admin/OldReviewTab";
import DuplicateScholarshipsTab from "@/components/admin/DuplicateScholarshipsTab";
import EssayLibraryTab from "@/components/admin/EssayLibraryTab";
import CountriesTab from "@/components/admin/CountriesTab";
import ApprovalTeamTab from "@/components/admin/ApprovalTeamTab";
import ChallengeTab from "@/components/admin/ChallengeTab";
import { usePendingScholarshipsCount } from "@/hooks/usePendingScholarshipsCount";
// (effectiveDeadline removed — scholarships.next_close_date is maintained by trigger)
import { useOldReviewCount } from "@/hooks/useOldReviewCount";

const qaIconMap: Record<string, LucideIcon> = {
  Search, Users, Briefcase, Route, FileText, BookOpen, Calendar, Landmark, Bot,
};

function QuickActionsTab() {
  const { actions, isLoading, toggleEnabled, swapOrder } = useQuickActions(false);

  const moveUp = (index: number) => {
    if (index === 0) return;
    swapOrder.mutate({ a: actions[index], b: actions[index - 1] });
  };
  const moveDown = (index: number) => {
    if (index >= actions.length - 1) return;
    swapOrder.mutate({ a: actions[index], b: actions[index + 1] });
  };

  return (
    <TabsContent value="quickactions">
      <SEO title="Admin | Brimsom" description="Brimsom administration console." path="/admin" />
      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Order</TableHead>
              <TableHead className="w-12">Icon</TableHead>
              <TableHead>Label</TableHead>
              <TableHead className="hidden sm:table-cell">Route</TableHead>
              <TableHead className="w-24">Enabled</TableHead>
              <TableHead className="w-24 text-right">Reorder</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : actions.map((qa, i) => {
              const Icon = qaIconMap[qa.icon_name] ?? Search;
              return (
                <TableRow key={qa.id}>
                  <TableCell className="font-mono text-muted-foreground">{qa.sort_order}</TableCell>
                  <TableCell><Icon className="h-4 w-4 text-primary" /></TableCell>
                  <TableCell className="font-medium">{qa.label}</TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground">{qa.route}</TableCell>
                  <TableCell>
                    <Switch
                      checked={qa.is_enabled}
                      onCheckedChange={(v) => toggleEnabled.mutate({ id: qa.id, is_enabled: v })}
                    />
                  </TableCell>
                  <TableCell className="text-right space-x-1 whitespace-nowrap">
                    <Button variant="ghost" size="icon" disabled={i === 0} onClick={() => moveUp(i)}>
                      <ArrowUp className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" disabled={i === actions.length - 1} onClick={() => moveDown(i)}>
                      <ArrowDown className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </TabsContent>
  );
}


function NotificationsTab() {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [url, setUrl] = useState("/");
  const [sending, setSending] = useState(false);

  const { data: subCount } = useQuery({
    queryKey: ["push-sub-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("push_subscriptions" as any)
        .select("*", { count: "exact", head: true });
      if (error) throw error;
      return count ?? 0;
    },
  });

  const sendNotification = async (broadcast: boolean) => {
    if (!title.trim()) {
      toast({ title: "Title required", description: "Please enter a notification title.", variant: "destructive" });
      return;
    }
    setSending(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");


      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/send-push-notification`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ title, body, url, broadcast }),
        }
      );
      const result = await res.json();
      if (res.ok) {
        const webPart = `Web: ${result.sent ?? 0} sent${result.failed ? `, ${result.failed} failed` : ""}`;
        const nativePart = `Mobile: ${result.nativeSent ?? 0} sent${result.nativeFailed ? `, ${result.nativeFailed} failed` : ""}`;
        toast({ title: "Notification dispatched", description: `${webPart} • ${nativePart}` });
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" });
      }
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
    setSending(false);
  };

  return (
    <TabsContent value="notifications">
      <div className="grid gap-6 max-w-lg">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" /> Push Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-lg bg-muted p-3 text-sm">
              <span className="font-medium">{subCount ?? 0}</span> active push subscriber(s)
            </div>
            <div className="space-y-2">
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Notification title" />
            </div>
            <div className="space-y-2">
              <Label>Body</Label>
              <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Notification body" rows={3} />
            </div>
            <div className="space-y-2">
              <Label>URL (click target)</Label>
              <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="/" />
            </div>
            <div className="flex gap-2">
              <Button onClick={() => sendNotification(false)} disabled={sending || !title} variant="outline" className="flex-1">
                {sending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
                Test (Me Only)
              </Button>
              <Button onClick={() => sendNotification(true)} disabled={sending || !title} className="flex-1">
                {sending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Send className="h-4 w-4 mr-2" />}
                Broadcast All
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </TabsContent>
  );
}

import AnnouncementManager from "@/components/admin/AnnouncementManager";
import AppLayout from "@/components/AppLayout";
import { toast } from "@/hooks/use-toast";
import ScholarshipForm, { type ScholarshipFormValues } from "@/components/admin/ScholarshipForm";
import ChatRoomForm, { type ChatRoomFormValues } from "@/components/admin/ChatRoomForm";
import LoanProviderForm, { type LoanProviderFormValues } from "@/components/admin/LoanProviderForm";
import SiteSettingsTab from "@/components/admin/SiteSettingsTab";
import ApplyStepsTab from "@/components/admin/ApplyStepsTab";
import PagesContentTab from "@/components/admin/PagesContentTab";
import ModeratorActivityTab from "@/components/admin/ModeratorActivityTab";
import TestimonialsTab from "@/components/admin/TestimonialsTab";
import AnalyticsTab from "@/components/admin/AnalyticsTab";
import ReportsTab from "@/components/admin/ReportsTab";
import { useActivityLog } from "@/hooks/useActivityLog";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import SEO from "@/components/SEO";

const SERVICE_LABELS: Record<string, string> = {
  sop: "SOP / Personal Statement",
  resume: "CV / Resume",
  research_proposal: "Research Proposal",
  full_package: "Full Application Package",
};

function DocReviewsTabLabel() {
  const { data: submissions = [] } = useAdminSubmissions();
  const uncompleted = submissions.filter((s) => s.status !== "completed").length;
  return (
    <span className="flex items-center gap-1.5">
      Doc Reviews
      {uncompleted > 0 && (
        <span className="inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-semibold">
          {uncompleted}
        </span>
      )}
    </span>
  );
}

function DocReviewsTab({ user }: { user: any }) {
  const { data: submissions = [], isLoading } = useAdminSubmissions();
  const updateSubmission = useUpdateSubmission();
  const deleteSubmission = useDeleteSubmission();
  const [statusFilter, setStatusFilter] = useState("all");
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState("");
  const [reviewStatus, setReviewStatus] = useState("pending");

  const pendingCount = submissions.filter((s) => s.status === "pending").length;
  const inReviewCount = submissions.filter((s) => s.status === "in_review").length;
  const uncompletedCount = pendingCount + inReviewCount;

  const filtered = statusFilter === "all" ? submissions : submissions.filter((s) => s.status === statusFilter);
  const reviewing = reviewingId ? submissions.find((s) => s.id === reviewingId) : null;

  const handleDelete = async (id: string) => {
    if (!window.confirm("Delete this submission permanently? This cannot be undone.")) return;
    try {
      await deleteSubmission.mutateAsync(id);
      toast({ title: "Submission deleted" });
    } catch (e: any) {
      toast({ title: "Delete failed", description: e.message, variant: "destructive" });
    }
  };


  const openReview = (sub: DocumentSubmission) => {
    setReviewingId(sub.id);
    setFeedback(sub.admin_feedback ?? "");
    setReviewStatus(sub.status);
    setReviewDialogOpen(true);
  };

  const handleSave = async () => {
    if (!reviewingId || !user) return;
    try {
      await updateSubmission.mutateAsync({
        id: reviewingId,
        status: reviewStatus,
        admin_feedback: feedback,
        reviewed_by: user.id,
      });
      setReviewDialogOpen(false);
      toast({ title: "Review saved" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };




  return (
    <TabsContent value="docreviews">
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="in_review">In Review</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">
          {uncompletedCount} uncompleted
        </Badge>
        <span className="text-xs text-muted-foreground">
          {pendingCount} pending · {inReviewCount} in review · {submissions.length} total
        </span>
      </div>


      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Service</TableHead>
              <TableHead className="hidden sm:table-cell">File</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No submissions</TableCell></TableRow>
            ) : filtered.map((sub) => (
              <TableRow key={sub.id}>
                <TableCell className="font-medium">{(sub as any).profiles?.full_name ?? "—"}</TableCell>
                <TableCell>{SERVICE_LABELS[sub.service_type] ?? sub.service_type}</TableCell>
                <TableCell className="hidden sm:table-cell max-w-[150px] truncate">{sub.file_name}</TableCell>
                <TableCell>
                  {sub.status === "pending" && <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending</Badge>}
                  {sub.status === "in_review" && <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20">In Review</Badge>}
                  {sub.status === "completed" && <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Completed</Badge>}
                </TableCell>
                <TableCell className="hidden sm:table-cell">{format(new Date(sub.created_at), "MMM d, yyyy")}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <DocumentViewerButton filePath={sub.file_url} fileName={sub.file_name} />
                    <Button variant="outline" size="sm" onClick={() => openReview(sub)}>
                      Review
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleDelete(sub.id)} disabled={deleteSubmission.isPending}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </TableCell>

              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Review Submission</DialogTitle></DialogHeader>
          {reviewing && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium">{SERVICE_LABELS[reviewing.service_type] ?? reviewing.service_type}</p>
                <p className="text-sm text-muted-foreground">{(reviewing as any).profiles?.full_name ?? "Unknown user"}</p>
              </div>
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{reviewing.file_name}</span>
                <DocumentViewerButton filePath={reviewing.file_url} fileName={reviewing.file_name} />
              </div>
              {reviewing.notes && (
                <div className="rounded-lg bg-muted p-3 text-sm">{reviewing.notes}</div>
              )}
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={reviewStatus} onValueChange={setReviewStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_review">In Review</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Feedback</Label>
                <Textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Provide review feedback..."
                  rows={4}
                  maxLength={5000}
                />
              </div>
              <Button className="w-full" onClick={handleSave} disabled={updateSubmission.isPending}>
                {updateSubmission.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Save Review
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}

const BOOKING_TYPE_LABELS: Record<string, string> = {
  scholarship_interview: "Scholarship Interview",
  visa_interview: "Visa Interview",
  general_advising: "General Advising",
};

function BookingsTab({ user }: { user: any }) {
  const { data: bookings = [], isLoading } = useAdminBookings();
  const updateBooking = useUpdateBooking();
  const [statusFilter, setStatusFilter] = useState("all");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [confirmedDate, setConfirmedDate] = useState<string | null>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [reviewStatus, setReviewStatus] = useState("pending");

  const filtered = statusFilter === "all" ? bookings : bookings.filter((b: any) => b.status === statusFilter);
  const reviewing = reviewingId ? bookings.find((b: any) => b.id === reviewingId) : null;

  const openReview = (b: any) => {
    setReviewingId(b.id);
    setConfirmedDate(b.confirmed_date ?? null);
    setAdminNotes(b.admin_notes ?? "");
    setReviewStatus(b.status);
    setReviewOpen(true);
  };

  const handleSave = async () => {
    if (!reviewingId || !user) return;
    try {
      await updateBooking.mutateAsync({
        id: reviewingId,
        status: reviewStatus,
        confirmed_date: confirmedDate,
        admin_notes: adminNotes,
        reviewed_by: user.id,
      });
      setReviewOpen(false);
      toast({ title: "Booking updated" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <TabsContent value="bookings">
      <div className="flex gap-3 mb-6">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden sm:table-cell">Date</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No bookings</TableCell></TableRow>
            ) : filtered.map((b: any) => (
              <TableRow key={b.id}>
                <TableCell className="font-medium">{b.profiles?.full_name ?? "—"}</TableCell>
                <TableCell>{BOOKING_TYPE_LABELS[b.session_type] ?? b.session_type}</TableCell>
                <TableCell>
                  {b.status === "pending" && <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending</Badge>}
                  {b.status === "confirmed" && <Badge className="bg-green-500/15 text-green-600 dark:text-green-400 border-green-500/20">Confirmed</Badge>}
                  {b.status === "completed" && <Badge className="bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/20">Completed</Badge>}
                  {b.status === "cancelled" && <Badge variant="secondary">Cancelled</Badge>}
                </TableCell>
                <TableCell className="hidden sm:table-cell">{format(new Date(b.created_at), "MMM d, yyyy")}</TableCell>
                <TableCell className="text-right">
                  <Button variant="outline" size="sm" onClick={() => openReview(b)}>
                    <Eye className="h-3.5 w-3.5 mr-1" />Review
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle>Review Booking</DialogTitle></DialogHeader>
          {reviewing && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium">{BOOKING_TYPE_LABELS[reviewing.session_type] ?? reviewing.session_type}</p>
                <p className="text-sm text-muted-foreground">{(reviewing as any).profiles?.full_name ?? "Unknown user"}</p>
              </div>

              {reviewing.notes && (
                <div className="rounded-lg bg-muted p-3 text-sm">{reviewing.notes}</div>
              )}

              <div className="space-y-2">
                <Label className="text-xs font-medium">Select Confirmed Date</Label>
                {[reviewing.proposed_date_1, reviewing.proposed_date_2, reviewing.proposed_date_3].map((d, i) => (
                  <label key={i} className={cn(
                    "flex items-center gap-3 rounded-lg border p-3 cursor-pointer transition-colors",
                    confirmedDate === d ? "border-primary bg-primary/5" : "border-border"
                  )}>
                    <input
                      type="radio"
                      name="confirmed_date"
                      checked={confirmedDate === d}
                      onChange={() => setConfirmedDate(d)}
                      className="accent-primary"
                    />
                    <span className="text-sm">{format(new Date(d), "PPP")}</span>
                  </label>
                ))}
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={reviewStatus} onValueChange={setReviewStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="confirmed">Confirmed</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Admin Notes</Label>
                <Textarea value={adminNotes} onChange={(e) => setAdminNotes(e.target.value)} placeholder="Add notes for the user..." rows={3} />
              </div>

              <Button className="w-full" onClick={handleSave} disabled={updateBooking.isPending}>
                {updateBooking.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Save
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}

function DocumentViewerButton({ filePath, fileName }: { filePath: string; fileName?: string | null }) {
  const [open, setOpen] = useState(false);
  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const ext = (fileName || filePath || "").split("?")[0].split(".").pop()?.toLowerCase() ?? "";
  const isPdf = ext === "pdf";

  const openViewer = async () => {
    setLoading(true);
    const { data, error } = await supabase.storage.from("user-documents").createSignedUrl(filePath, 3600);
    setLoading(false);
    if (error || !data?.signedUrl) {
      toast({ title: "Error", description: error?.message || "Could not open document", variant: "destructive" });
      return;
    }
    setUrl(data.signedUrl);
    setOpen(true);
  };

  const viewerSrc = url
    ? isPdf
      ? url
      : `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(url)}`
    : "";

  return (
    <>
      <Button variant="ghost" size="sm" onClick={openViewer} disabled={loading}>
        {loading ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Eye className="h-3.5 w-3.5 mr-1" />}
        View
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-4xl p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="truncate pr-8">{fileName || "Document"}</DialogTitle>
          </DialogHeader>
          {url && (
            <div className="space-y-3">
              <iframe src={viewerSrc} title="Document preview" className="w-full h-[70vh] rounded-lg border border-border bg-muted" />
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={() => window.open(url, "_blank")}>
                  <Download className="h-3.5 w-3.5 mr-1" />Download
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}


const SCHOLARSHIP_TABLE_PAGE_SIZE = 25;

function ScholarshipTable({ scholarships, isLoading, getStatusBadge, onEdit, onDelete, onRepublish, onToggleChallenge }: {
  scholarships: any[];
  isLoading: boolean;
  getStatusBadge: (s: any) => React.ReactNode;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onRepublish?: (id: string) => void;
  onToggleChallenge?: (id: string, next: boolean) => void;
}) {
  const [visibleCount, setVisibleCount] = useState(SCHOLARSHIP_TABLE_PAGE_SIZE);
  // Reset paging when the underlying list changes size (tab switch, filter, delete)
  useEffect(() => {
    setVisibleCount(SCHOLARSHIP_TABLE_PAGE_SIZE);
  }, [scholarships.length]);

  const visible = scholarships.slice(0, visibleCount);
  const hasMore = scholarships.length > visibleCount;

  return (
    <div className="space-y-3">
      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead className="hidden md:table-cell">Country</TableHead>
              <TableHead className="hidden md:table-cell">Degree</TableHead>
              <TableHead className="hidden sm:table-cell">Deadline</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : scholarships.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No scholarships found</TableCell></TableRow>
            ) : visible.map((s) => (
              <TableRow key={s.id}>
                <TableCell className="font-medium max-w-[160px] sm:max-w-[200px] truncate">
                  <span className="inline-flex items-center gap-1.5">
                    {s.is_challenge && <Trophy className="h-3.5 w-3.5 text-amber-500 shrink-0" aria-label="In Challenge List" />}
                    <span className="truncate">{s.title}</span>
                  </span>
                </TableCell>
                <TableCell className="hidden md:table-cell">{s.country ?? "—"}</TableCell>
                <TableCell className="hidden md:table-cell">{s.degree_level ?? "—"}</TableCell>
                <TableCell className="hidden sm:table-cell">{s.next_close_date ? format(new Date(s.next_close_date), "MMM d, yyyy") : "—"}</TableCell>
                <TableCell>{getStatusBadge(s)}</TableCell>
                <TableCell className="text-right">
                  <div className="inline-flex items-center gap-0.5 whitespace-nowrap">
                    {onToggleChallenge && (
                      <Button
                        variant={s.is_challenge ? "default" : "outline"}
                        size="sm"
                        onClick={() => onToggleChallenge(s.id, !s.is_challenge)}
                        className="text-xs h-8 px-2"
                        title={s.is_challenge ? "Remove from Challenge List" : "Send to Challenge List"}
                      >
                        <Trophy className={`h-3.5 w-3.5 sm:mr-1 ${s.is_challenge ? "" : "text-amber-500"}`} />
                        <span className="hidden sm:inline">{s.is_challenge ? "In Challenge" : "Challenge"}</span>
                      </Button>
                    )}
                    {onRepublish && (
                      <Button variant="outline" size="sm" onClick={() => onRepublish(s.id)} className="text-xs h-8 px-2">
                        <RefreshCw className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Republish</span>
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8 hidden sm:inline-flex" asChild><a href={`/admin/scholarship-winner/${s.id}`} target="_blank" rel="noopener noreferrer"><Trophy className="h-4 w-4 text-amber-500" /></a></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(s.id)}><Pencil className="h-4 w-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onDelete(s.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {!isLoading && scholarships.length > 0 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground px-1">
          <span>Showing {visible.length} of {scholarships.length}</span>
          {hasMore && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setVisibleCount((c) => c + SCHOLARSHIP_TABLE_PAGE_SIZE)}
            >
              Load more
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

interface PlatformMetrics {
  total_users: number;
  active_scholarships: number;
  total_scholarships: number;
  total_saves: number;
  scores_generated: number;
  community_messages: number;
}

const metricCards = [
  { key: "total_users" as const, label: "Total Users", icon: Users },
  { key: "active_scholarships" as const, label: "Active Scholarships", icon: GraduationCap },
  { key: "total_scholarships" as const, label: "Total Scholarships", icon: BarChart3 },
  { key: "total_saves" as const, label: "Saved (Total)", icon: Bookmark },
  { key: "scores_generated" as const, label: "Scores Generated", icon: Sparkles },
  { key: "community_messages" as const, label: "Community Messages", icon: MessageCircle },
];

const ADMIN_SECTIONS = [
  { key: "overview", label: "Overview" },
  { key: "scholarships", label: "Scholarships" },
  { key: "approvals", label: "Approvals" },
  { key: "chatrooms", label: "Chat Rooms" },
  { key: "docreviews", label: "Doc Reviews" },
  { key: "bookings", label: "Bookings" },
  { key: "quickactions", label: "Quick Actions" },
  { key: "loans", label: "Loans" },
  { key: "notifications", label: "Notifications" },
  { key: "support", label: "Support" },
  { key: "blog", label: "Blog" },
  { key: "resources", label: "Resources" },
  { key: "analytics", label: "Analytics" },
  { key: "downloads", label: "Downloads" },
  { key: "reports", label: "Reports" },
  { key: "careers", label: "Careers" },
  { key: "sitesettings", label: "Site Settings" },
  { key: "applysteps", label: "Apply Steps" },
] as const;

function ModeratorsTab() {
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [selectedSections, setSelectedSections] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);
  const [editingMod, setEditingMod] = useState<{ user_id: string; full_name: string; sections: string[] } | null>(null);
  const [editSections, setEditSections] = useState<string[]>([]);
  const [savingEdit, setSavingEdit] = useState(false);

  const openEdit = (mod: { user_id: string; full_name: string; sections: string[] }) => {
    setEditingMod(mod);
    setEditSections(mod.sections);
  };

  const toggleEditSection = (section: string) => {
    setEditSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    );
  };

  const handleSaveEdit = async () => {
    if (!editingMod) return;
    setSavingEdit(true);
    try {
      const current = new Set(editingMod.sections);
      const next = new Set(editSections);
      const toAdd = [...next].filter((s) => !current.has(s));
      const toRemove = [...current].filter((s) => !next.has(s));

      if (toRemove.length) {
        const { error } = await (supabase as any)
          .from("moderator_permissions")
          .delete()
          .eq("user_id", editingMod.user_id)
          .in("section", toRemove);
        if (error) throw error;
      }
      if (toAdd.length) {
        const { error } = await (supabase as any)
          .from("moderator_permissions")
          .insert(toAdd.map((section) => ({ user_id: editingMod.user_id, section })));
        if (error) throw error;
      }

      toast({ title: "Sections updated" });
      setEditingMod(null);
      queryClient.invalidateQueries({ queryKey: ["moderators-list"] });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
    setSavingEdit(false);
  };

  const { data: moderators = [], isLoading } = useQuery({
    queryKey: ["moderators-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "moderator");
      if (error) throw error;
      if (!data.length) return [];
      const userIds = data.map((r) => r.user_id);
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", userIds);
      const { data: perms } = await (supabase as any)
        .from("moderator_permissions")
        .select("user_id, section")
        .in("user_id", userIds);
      return userIds.map((uid) => ({
        user_id: uid,
        full_name: profiles?.find((p: any) => p.user_id === uid)?.full_name ?? "Unknown",
        sections: (perms as any[] ?? []).filter((p: any) => p.user_id === uid).map((p: any) => p.section),
      }));
    },
  });

  const toggleSection = (section: string) => {
    setSelectedSections((prev) =>
      prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]
    );
  };

  const handleCreate = async () => {
    if (!email || !password || !fullName || selectedSections.length === 0) return;
    setCreating(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/create-moderator`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ email, password, full_name: fullName, sections: selectedSections }),
        }
      );
      const result = await res.json();
      if (!res.ok) throw new Error(result.error);
      toast({ title: "Moderator created successfully" });
      setCreateOpen(false);
      setEmail(""); setPassword(""); setFullName(""); setSelectedSections([]);
      queryClient.invalidateQueries({ queryKey: ["moderators-list"] });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
    setCreating(false);
  };

  const removeModerator = async (userId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/create-moderator`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ action: "remove", user_id: userId }),
        }
      );
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Failed to remove moderator");
      await queryClient.invalidateQueries({ queryKey: ["moderators-list"] });
      toast({ title: "Moderator removed" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  return (
    <TabsContent value="moderators">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Shield className="h-5 w-5" /> Moderators
        </h2>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button><UserPlus className="h-4 w-4 mr-2" />Create Moderator</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader><DialogTitle>Create Moderator Account</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="John Doe" />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="moderator@example.com" />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
              </div>
              <div className="space-y-2">
                <Label>Permitted Sections</Label>
                <div className="grid grid-cols-2 gap-2">
                  {ADMIN_SECTIONS.map(({ key, label }) => (
                    <label key={key} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox
                        checked={selectedSections.includes(key)}
                        onCheckedChange={() => toggleSection(key)}
                      />
                      {label}
                    </label>
                  ))}
                </div>
              </div>
              <Button className="w-full" onClick={handleCreate} disabled={creating || !email || !password || !fullName || selectedSections.length === 0}>
                {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Create Moderator
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Sections</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
            ) : moderators.length === 0 ? (
              <TableRow><TableCell colSpan={3} className="text-center py-8 text-muted-foreground">No moderators yet</TableCell></TableRow>
            ) : moderators.map((mod) => (
              <TableRow key={mod.user_id}>
                <TableCell className="font-medium">{mod.full_name}</TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {mod.sections.map((s: string) => (
                      <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(mod)} title="Edit sections">
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => removeModerator(mod.user_id)} title="Remove permissions">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!editingMod} onOpenChange={(o) => !o && setEditingMod(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Sections — {editingMod?.full_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Permitted Sections</Label>
              <div className="grid grid-cols-2 gap-2">
                {ADMIN_SECTIONS.map(({ key, label }) => (
                  <label key={key} className="flex items-center gap-2 text-sm cursor-pointer">
                    <Checkbox
                      checked={editSections.includes(key)}
                      onCheckedChange={() => toggleEditSection(key)}
                    />
                    {label}
                  </label>
                ))}
              </div>
            </div>
            <Button className="w-full" onClick={handleSaveEdit} disabled={savingEdit || editSections.length === 0}>
              {savingEdit && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </TabsContent>
  );
}

export default function Admin() {
  const { user } = useAuth();
  const { isAdmin, isModerator } = useAdminRole();
  const { permissions: modPermissions } = useModeratorPermissions();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingIdState] = useState<string | null>(null);
  const editingIdRef = useRef<string | null>(null);
  const setEditingId = (id: string | null) => { editingIdRef.current = id; setEditingIdState(id); };
  const [roomDialogOpen, setRoomDialogOpen] = useState(false);
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);
  const [loanDialogOpen, setLoanDialogOpen] = useState(false);
  const [editingLoanId, setEditingLoanId] = useState<string | null>(null);
  const [autoGenOpen, setAutoGenOpen] = useState(false);
  const [autoGenText, setAutoGenText] = useState("");
  const [autoGenLoading, setAutoGenLoading] = useState(false);
  const [autoGenDefaults, setAutoGenDefaults] = useState<Partial<ScholarshipFormValues> | null>(null);
  const [viewAsModId, setViewAsModId] = useState<string | null>(null);
  const [upcomingFilter, setUpcomingFilter] = useState("all");
  const [activeAdminTab, setActiveAdminTab] = useState<string | null>(null);
  const { logActivity } = useActivityLog();

  const { data: moderatorsForView = [] } = useQuery({
    queryKey: ["moderators-for-view-as"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data: roles } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "moderator");
      const ids = (roles ?? []).map((r) => r.user_id);
      if (!ids.length) return [];
      const [{ data: profiles }, { data: perms }] = await Promise.all([
        supabase.from("profiles").select("user_id, full_name").in("user_id", ids),
        (supabase as any).from("moderator_permissions").select("user_id, section").in("user_id", ids),
      ]);
      return ids.map((uid) => ({
        user_id: uid,
        full_name: profiles?.find((p: any) => p.user_id === uid)?.full_name ?? "Unknown",
        sections: ((perms as any[]) ?? []).filter((p) => p.user_id === uid).map((p) => p.section as string),
      }));
    },
  });

  const viewAsMod = viewAsModId ? moderatorsForView.find((m) => m.user_id === viewAsModId) : null;
  const effectiveIsAdmin = isAdmin && !viewAsMod;
  const effectiveIsModerator = isModerator || !!viewAsMod;
  const effectivePermissions = viewAsMod ? viewAsMod.sections : modPermissions;
  const canSee = (section: string) => effectiveIsAdmin || effectivePermissions.includes(section);

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["admin-platform-metrics"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("admin_platform_metrics");
      if (error) throw error;
      return data as unknown as PlatformMetrics;
    },
  });

  const { data: scholarships = [], isLoading } = useQuery({
    queryKey: ["scholarships-admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("scholarships").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: chatRooms = [], isLoading: roomsLoading } = useQuery({
    queryKey: ["chat-rooms-admin"],
    queryFn: async () => {
      const { data, error } = await supabase.from("chat_rooms").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: loanProviders = [], isLoading: loansLoading } = useQuery({
    queryKey: ["loan-providers-admin"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("loan_providers").select("*").order("sort_order");
      if (error) throw error;
      return data as any[];
    },
  });

  const roomUpsert = useMutation({
    mutationFn: async (values: ChatRoomFormValues & { id?: string }) => {
      const payload = { name: values.name, description: values.description || null };
      if (values.id) {
        const { error } = await supabase.from("chat_rooms").update(payload).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("chat_rooms").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat-rooms-admin"] });
      setRoomDialogOpen(false);
      setEditingRoomId(null);
      toast({ title: editingRoomId ? "Room updated" : "Room created" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const loanUpsert = useMutation({
    mutationFn: async (values: LoanProviderFormValues & { id?: string }) => {
      const payload = {
        name: values.name,
        description: values.description || null,
        requirements: values.requirements || null,
        rates: values.rates || null,
        url: values.url || null,
        logo_url: values.logo_url || null,
        is_active: values.is_active,
        sort_order: values.sort_order ?? 0,
      };
      if (values.id) {
        const { error } = await (supabase as any).from("loan_providers").update(payload).eq("id", values.id);
        if (error) throw error;
      } else {
        const { error } = await (supabase as any).from("loan_providers").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loan-providers-admin"] });
      queryClient.invalidateQueries({ queryKey: ["loan-providers"] });
      setLoanDialogOpen(false);
      setEditingLoanId(null);
      toast({ title: editingLoanId ? "Loan provider updated" : "Loan provider created" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const loanDelete = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from("loan_providers").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loan-providers-admin"] });
      queryClient.invalidateQueries({ queryKey: ["loan-providers"] });
      toast({ title: "Loan provider deleted" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const roomDelete = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("chat_rooms").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["chat-rooms-admin"] });
      toast({ title: "Room deleted" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const sendPushNotification = async (title: string, body: string, url: string, broadcast: boolean) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      await fetch(`https://${projectId}.supabase.co/functions/v1/send-push-notification`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ title, body, url, broadcast }),
      });
    } catch (e) {
      console.error("Push notification error:", e);
    }
  };

  const upsertMutation = useMutation({
    mutationFn: async (args: { values: ScholarshipFormValues & { id?: string }; intakes: any[] }) => {
      const { values, intakes } = args;
      // Safety net: ensure the academic year suffix is present on the title even
      // when the form's own appender was bypassed (e.g. legacy submit paths).
      let safeTitle = (values.title || "").trim();
      if (safeTitle && !/\b(19|20)\d{2}\b/.test(safeTitle)) {
        const earliestOpen = (intakes || [])
          .map((it: any) => it?.open_date as string | null)
          .filter((d): d is string => !!d)
          .sort()[0];
        const baseYear = earliestOpen ? new Date(earliestOpen).getFullYear() : new Date().getFullYear();
        safeTitle = `${safeTitle} ${baseYear}/${baseYear + 1}`;
      }
      const payload: any = {
        title: safeTitle,
        description: values.description || null,
        provider: values.provider || null,
        country: values.country || null,
        field_of_study: values.field_of_study || null,
        degree_level: values.degree_level || null,
        funding_amount: values.funding_amount || null,
        deadline_source_url: (values as any).deadline_source_url || null,
        admission_requirements_url: (values as any).admission_requirements_url || null,
        funding_type: (values as any).funding_type || null,
        funding_category: (values as any).funding_category || null,
        eligibility_criteria: values.eligibility_criteria || null,
        min_gpa: values.min_gpa ?? null,
        min_cgpa_scale: (values as any).min_cgpa_scale ?? null,
        min_cgpa_percentage: (values as any).min_cgpa_percentage ?? null,
        url: values.url || null,
        apply_steps: values.apply_steps || null,
        is_active: values.is_active,
        auto_publish_enabled: !!(values as any).auto_publish_enabled,
        assigned_reviewer_id: (values as any).assigned_reviewer_id || null,
        forwarded_to_admin: !!(values as any).forwarded_to_admin,
        has_application_fee: !!(values as any).has_application_fee,
        application_fee_amount: (values as any).has_application_fee ? ((values as any).application_fee_amount || null) : null,
        submission_notes: (values as any).submission_notes?.trim() || null,
      };
      const isNew = !values.id;
      let resultRow: any = null;
      if (values.id) {
        const { data, error } = await supabase
          .from("scholarships")
          .update({ ...payload, updated_by: user?.id } as any)
          .eq("id", values.id)
          .select()
          .single();
        if (error) throw error;
        resultRow = data;
      } else {
        const { data, error } = await supabase
          .from("scholarships")
          .insert({ ...payload, created_by: user?.id, updated_by: user?.id } as any)
          .select()
          .single();
        if (error) throw error;
        resultRow = data;
      }

      // Sync intakes: replace all rows for this scholarship
      const scholarshipId = resultRow?.id;
      if (scholarshipId) {
        await (supabase as any).from("scholarship_intakes").delete().eq("scholarship_id", scholarshipId);
        if (intakes.length > 0) {
          const rows = intakes.map((it: any, i: number) => ({
            scholarship_id: scholarshipId,
            term: it.term,
            custom_label: it.custom_label ?? null,
            open_date: it.open_date || null,
            close_date: it.close_date || null,
            sort_order: i,
          }));
          const { error: intakeErr } = await (supabase as any).from("scholarship_intakes").insert(rows);
          if (intakeErr) throw intakeErr;
        }
      }

      // Notify the assigned reviewer
      if (payload.assigned_reviewer_id && resultRow?.status === "pending") {
        await supabase.from("notifications").insert({
          user_id: payload.assigned_reviewer_id,
          title: "New scholarship awaiting your review",
          body: resultRow.title,
          url: "/admin",
        } as any);
      }
      // Compute effective deadline from the intakes the admin just saved so
      // we don't broadcast a "new scholarship" push for one already expired.
      const today = new Date().toISOString().split("T")[0];
      const upcoming = intakes
        .map((it: any) => it.close_date)
        .filter((d: string | null) => !!d && d >= today);
      const hasFutureDeadline = upcoming.length > 0;
      return { isNew, title: values.title, status: resultRow?.status, hasFutureDeadline };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["scholarships-admin"] });
      queryClient.invalidateQueries({ queryKey: ["admin-platform-metrics"] });
      queryClient.invalidateQueries({ queryKey: ["pending-scholarships"] });
      queryClient.invalidateQueries({ queryKey: ["pending-scholarships-count"] });
      setDialogOpen(false);
      setEditingId(null);
      const wasPending = result?.status === "pending";
      toast({
        title: wasPending
          ? "Submitted for review"
          : (editingId ? "Scholarship updated" : "Scholarship created"),
        description: wasPending ? "A reviewer has been notified." : undefined,
      });
      logActivity(result?.isNew ? "Created scholarship" : "Updated scholarship", result?.title);
      // Push notification only when admin publishes a NEW scholarship that
      // still has a future deadline — skip expired ones to avoid spam.
      if (result?.isNew && result?.status === "approved" && result?.hasFutureDeadline) {
        sendPushNotification(
          "New Scholarship Available! 🎓",
          result.title,
          "/scholarships",
          true
        );
      }
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("scholarships").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["scholarships-admin"] });
      queryClient.invalidateQueries({ queryKey: ["admin-platform-metrics"] });
      const deleted = scholarships.find((s) => s.id === id);
      logActivity("Deleted scholarship", deleted?.title ?? id);
      toast({ title: "Scholarship deleted" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const confirmDelete = (id: string) => {
    const sch = scholarships.find((s) => s.id === id);
    const title = sch?.title ? `"${sch.title}"` : "this scholarship";
    if (window.confirm(`Delete ${title}? This action cannot be undone.`)) {
      deleteMutation.mutate(id);
    }
  };



  const toggleChallengeMutation = useMutation({
    mutationFn: async ({ id, next }: { id: string; next: boolean }) => {
      const { error } = await supabase.from("scholarships").update({ is_challenge: next } as any).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, { next, id }) => {
      queryClient.invalidateQueries({ queryKey: ["scholarships-admin"] });
      queryClient.invalidateQueries({ queryKey: ["challenge-scholarships"] });
      const sch = scholarships.find((s) => s.id === id);
      logActivity(next ? "Added to Challenge List" : "Removed from Challenge List", sch?.title ?? id);
      toast({ title: next ? "Added to Challenge List" : "Removed from Challenge List" });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const [republishId, setRepublishId] = useState<string | null>(null);
  const editing = editingId ? scholarships.find((s) => s.id === editingId) : null;

  // Load intakes for the scholarship currently being edited or republished
  const [editingIntakes, setEditingIntakes] = useState<any[]>([]);
  useEffect(() => {
    const sourceId = editingId ?? republishId;
    if (!sourceId) { setEditingIntakes([]); return; }
    let cancelled = false;
    (supabase as any)
      .from("scholarship_intakes")
      .select("*")
      .eq("scholarship_id", sourceId)
      .order("sort_order", { ascending: true })
      .then(({ data }: any) => {
        if (!cancelled) setEditingIntakes((data ?? []) as any[]);
      });
    return () => { cancelled = true; };
  }, [editingId, republishId]);

  const recentCount = useRecentScholarshipsCount();
  const pendingCount = usePendingScholarshipsCount();
  const oldReviewCount = useOldReviewCount();
  const today = new Date().toISOString().split("T")[0];

  const searchFilter = (s: typeof scholarships[0]) =>
    [s.title, s.provider, s.country, s.degree_level].some((v) => v?.toLowerCase().includes(search.toLowerCase()));

  const activeScholarships = scholarships.filter((s) => s.is_active && (!s.next_close_date || s.next_close_date >= today)).filter(searchFilter);
  const pastDeadlineScholarships = scholarships.filter((s) => s.next_close_date && s.next_close_date < today && (s as any).status !== "rejected").filter(searchFilter);
  const upcomingScholarshipsAll = scholarships.filter((s) => s.is_active && (s as any).status !== "rejected" && (s as any).status !== "pending" && (s as any).next_open_date && (s as any).next_open_date > today).filter(searchFilter);
  const daysUntil = (d: string) => Math.ceil((new Date(d).getTime() - new Date(today).getTime()) / (1000 * 60 * 60 * 24));
  const upcomingScholarships = upcomingScholarshipsAll.filter((s) => {
    const days = daysUntil((s as any).next_open_date);
    if (upcomingFilter === "all") return days <= 90;
    if (upcomingFilter === "lt1") return days < 30;
    if (upcomingFilter === "1to2") return days >= 30 && days <= 60;
    if (upcomingFilter === "2to3") return days > 60 && days <= 90;
    if (upcomingFilter === "gt3") return days > 90;
    return true;
  });
  const scopedUserId = viewAsModId ?? user?.id;
  const rejectedScholarships = scholarships.filter((s) => (s as any).status === "rejected" && (s as any).created_by === scopedUserId).filter(searchFilter);
  const pendingScholarships = scholarships.filter((s) => (s as any).status === "pending" && (s as any).created_by === scopedUserId).filter(searchFilter);
  const autoPublishScholarships = scholarships.filter((s) => (s as any).auto_publish_enabled).filter(searchFilter);

  

  const getStatusBadge = (s: typeof scholarships[0]) => {
    if ((s as any).status === "rejected") return <Badge className="bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/20">Rejected</Badge>;
    if ((s as any).status === "pending") return <Badge className="bg-yellow-500/15 text-yellow-600 dark:text-yellow-400 border-yellow-500/20">Pending review</Badge>;
    if (s.next_close_date && s.next_close_date < today) return <Badge className="bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/20">Expired</Badge>;
    if (!s.is_active) return <Badge variant="secondary">Inactive</Badge>;
    return <Badge variant="default">Active</Badge>;
  };

  const openEdit = (id: string) => { setRepublishId(null); setEditingId(id); setDialogOpen(true); };
  const openCreate = () => { setRepublishId(null); setEditingId(null); setDialogOpen(true); };

  const openRepublish = (id: string) => {
    setRepublishId(id);
    setEditingId(null);
    setDialogOpen(true);
  };
  const editingRoom = editingRoomId ? chatRooms.find((r) => r.id === editingRoomId) : null;
  const openRoomEdit = (id: string) => { setEditingRoomId(id); setRoomDialogOpen(true); };
  const openRoomCreate = () => { setEditingRoomId(null); setRoomDialogOpen(true); };

  const editingLoan = editingLoanId ? loanProviders.find((l: any) => l.id === editingLoanId) : null;
  const handleAutoGenExtract = async () => {
    if (!autoGenText.trim()) return;
    setAutoGenLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");
      const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID;
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/extract-scholarship`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ raw_text: autoGenText }),
        }
      );
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || "Extraction failed");
      // Filter out non-standard degree levels the AI may hallucinate (e.g. field-of-study values)
      const ALLOWED_DEGREES = ["BSC", "MSC", "PHD", "Diploma", "Associate", "Postdoc", "MBA"];
      const cleanedDegreeLevel = (result.degree_level || "")
        .split(",")
        .map((s: string) => s.trim())
        .filter((s: string) => ALLOWED_DEGREES.includes(s))
        .join(", ");
      setAutoGenDefaults({
        title: result.title || "",
        description: result.description || "",
        provider: result.provider || "",
        country: result.country || "",
        field_of_study: result.field_of_study || "",
        degree_level: cleanedDegreeLevel,
        funding_amount: result.funding_amount || "",
        
        funding_type: result.funding_type || "",
        funding_category: result.funding_category || "",
        eligibility_criteria: result.eligibility_criteria || "",
        min_gpa: result.min_gpa ?? undefined,
        min_cgpa_scale: result.min_cgpa_scale ?? undefined,
        min_cgpa_percentage: result.min_cgpa_percentage ?? undefined,
        url: result.url || "",
        is_active: true,
      });

      setAutoGenOpen(false);
      setAutoGenText("");
      setEditingId(null);
      setRepublishId(null);
      setDialogOpen(true);
      toast({ title: "Details extracted!", description: "Review and save the scholarship." });
    } catch (e: any) {
      toast({ title: "Extraction failed", description: e.message, variant: "destructive" });
    }
    setAutoGenLoading(false);
  };

  const openLoanEdit = (id: string) => { setEditingLoanId(id); setLoanDialogOpen(true); };
  const openLoanCreate = () => { setEditingLoanId(null); setLoanDialogOpen(true); };

  return (
    <AppLayout>

      <main className="w-full max-w-7xl mx-auto px-3 sm:px-4 py-6 sm:py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6">
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          {isAdmin && moderatorsForView.length > 0 && (
            <div className="flex items-center gap-2">
              <Label className="text-xs text-muted-foreground whitespace-nowrap">View as</Label>
              <Select value={viewAsModId ?? "self"} onValueChange={(v) => setViewAsModId(v === "self" ? null : v)}>
                <SelectTrigger className="h-9 w-[200px] text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="self">Admin (me)</SelectItem>
                  {moderatorsForView.map((m) => (
                    <SelectItem key={m.user_id} value={m.user_id}>{m.full_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        {viewAsMod && (
          <div className="mb-4 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400">
            Viewing panel as moderator <strong>{viewAsMod.full_name}</strong>. Click "Admin (me)" to exit.
          </div>
        )}

        <Tabs value={activeAdminTab ?? (effectiveIsAdmin ? "overview" : (effectivePermissions[0] ?? "overview"))} onValueChange={setActiveAdminTab} key={viewAsModId ?? "self"} className="space-y-6">
          <TabsList className="flex w-full overflow-x-auto sm:flex-wrap h-auto justify-start gap-1">
            {canSee("overview") && <TabsTrigger value="overview">Overview</TabsTrigger>}
            {canSee("scholarships") && <TabsTrigger value="scholarships">Scholarships</TabsTrigger>}
            {canSee("scholarships") && <TabsTrigger value="countries">Countries</TabsTrigger>}
            {canSee("approvals") && (
              <TabsTrigger value="approvals">
                Approvals{pendingCount > 0 ? ` (${pendingCount})` : ""}
              </TabsTrigger>
            )}
            {canSee("chatrooms") && <TabsTrigger value="chatrooms">Chat Rooms</TabsTrigger>}
            {canSee("docreviews") && <TabsTrigger value="docreviews"><DocReviewsTabLabel /></TabsTrigger>}
            {canSee("bookings") && <TabsTrigger value="bookings">Bookings</TabsTrigger>}
            {canSee("quickactions") && <TabsTrigger value="quickactions">Quick Actions</TabsTrigger>}
            {canSee("loans") && <TabsTrigger value="loans">Loans</TabsTrigger>}
            {canSee("notifications") && <TabsTrigger value="notifications">Notifications</TabsTrigger>}
            {canSee("resources") && <TabsTrigger value="resources">Resources</TabsTrigger>}
            {canSee("blog") && <TabsTrigger value="blog">Blog</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="downloads">Downloads</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="sitesettings">Site Settings</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="applysteps">Apply Steps</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="pages">Pages</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="infosources">Info Sources</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="analytics">Analytics</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="users">Users</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="moderators">Moderators</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="approval-team">Approval Team</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="moderator-activity">Mod Activity</TabsTrigger>}
            {canSee("support") && <TabsTrigger value="support">Support</TabsTrigger>}
            {(effectiveIsAdmin || effectiveIsModerator) && <TabsTrigger value="reports">Reports</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="testimonials">Testimonials</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="essays">Essay Library</TabsTrigger>}
            {canSee("careers") && <TabsTrigger value="careers">Careers</TabsTrigger>}
            {effectiveIsAdmin && <TabsTrigger value="challenge">Challenge</TabsTrigger>}
          </TabsList>

          {canSee("careers") && (
            <TabsContent value="careers">
              <JobApplicationsTab />
            </TabsContent>
          )}

          {effectiveIsAdmin && (
            <TabsContent value="challenge">
              <ChallengeTab onEditScholarship={(id) => { setActiveAdminTab("scholarships"); setRepublishId(null); setEditingId(id); setDialogOpen(true); }} />
            </TabsContent>
          )}

          <TabsContent value="overview">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {metricCards.map(({ key, label, icon: Icon }) => (
                <Card key={key}>
                  <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    {metricsLoading ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      <p className="text-2xl font-bold">{metrics?.[key] ?? 0}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="scholarships">
            {(() => {
              const republishing = republishId ? scholarships.find((s) => s.id === republishId) : null;
              const formSource = editing || republishing;
              const advanceYear = (dateStr: string | null) => {
                if (!dateStr) return "";
                const d = new Date(dateStr);
                d.setFullYear(d.getFullYear() + 1);
                return d.toISOString().split("T")[0];
              };
              const formDefaults = autoGenDefaults ? autoGenDefaults : formSource ? {
                title: formSource.title,
                description: formSource.description ?? "",
                provider: formSource.provider ?? "",
                country: formSource.country ?? "",
                field_of_study: formSource.field_of_study ?? "",
                degree_level: formSource.degree_level ?? "",
                funding_amount: formSource.funding_amount ?? "",
                
                deadline_source_url: (formSource as any).deadline_source_url ?? "",
                admission_requirements_url: (formSource as any).admission_requirements_url ?? "",
                funding_type: formSource.funding_type ?? "",
                funding_category: (formSource as any).funding_category ?? "",
                eligibility_criteria: formSource.eligibility_criteria ?? "",
                min_gpa: formSource.min_gpa ?? undefined,
                min_cgpa_scale: formSource.min_cgpa_scale ?? undefined,
                min_cgpa_percentage: formSource.min_cgpa_percentage ?? undefined,
                url: formSource.url ?? "",
                apply_steps: formSource.apply_steps ?? "",
                is_active: republishing ? true : formSource.is_active,
                auto_publish_enabled: !!(formSource as any).auto_publish_enabled,
                has_application_fee: !!(formSource as any).has_application_fee,
                application_fee_amount: (formSource as any).application_fee_amount ?? "",
                submission_notes: (formSource as any).submission_notes ?? "",
              } : undefined;

              return (
                <>
                  <div className="flex flex-col sm:flex-row gap-3 mb-6">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Search scholarships (all tabs)..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
                    </div>
                    <Button variant="outline" onClick={() => setAutoGenOpen(true)}>
                      <Sparkles className="h-4 w-4 mr-2" />Auto Generate
                    </Button>
                    <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) { setEditingId(null); setRepublishId(null); setAutoGenDefaults(null); } }}>
                      <DialogTrigger asChild>
                        <Button onClick={openCreate}><Plus className="h-4 w-4 mr-2" />Add Scholarship</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-2xl">
                        <DialogHeader><DialogTitle>{editing ? "Edit Scholarship" : autoGenDefaults ? "Review Extracted Scholarship" : republishing ? "Republish Scholarship" : "Add Scholarship"}</DialogTitle></DialogHeader>
                        <ScholarshipForm
                          key={editingId ?? republishId ?? (autoGenDefaults ? "autogen" : "new")}
                          defaultValues={formDefaults}
                          defaultIntakes={editingIntakes}
                          isAdmin={isAdmin}
                          editingId={editingId ?? republishId ?? null}
                          rejectionReason={editing?.status === "rejected" ? editing?.rejection_reason : null}
                          onSubmit={(v, intakes) => {
                            upsertMutation.mutate({ values: { ...v, id: editingIdRef.current ?? undefined }, intakes });
                          }}
                          loading={upsertMutation.isPending}
                        />
                      </DialogContent>
                    </Dialog>
                  </div>

                  {search.trim().length > 0 && (() => {
                    const allMatches = scholarships.filter(searchFilter);
                    return (
                      <div className="mb-4 rounded-lg border border-border bg-muted/40 p-3 text-sm">
                        <div className="font-medium">
                          {allMatches.length} match{allMatches.length === 1 ? "" : "es"} across all statuses for "{search}"
                        </div>
                        {allMatches.length > 0 && (
                          <div className="mt-1 text-xs text-muted-foreground flex flex-wrap gap-x-3 gap-y-1">
                            <span>Active: {activeScholarships.length}</span>
                            <span>Pending: {pendingScholarships.length}</span>
                            <span>Rejected: {rejectedScholarships.length}</span>
                            <span>Past: {pastDeadlineScholarships.length}</span>
                            <span className="italic">Switch tabs to view results in each status.</span>
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {/* Auto Generate Dialog */}
                  <Dialog open={autoGenOpen} onOpenChange={(o) => { setAutoGenOpen(o); if (!o) setAutoGenText(""); }}>
                    <DialogContent className="sm:max-w-2xl">
                      <DialogHeader><DialogTitle className="flex items-center gap-2"><Sparkles className="h-5 w-5" />Auto Generate Scholarship</DialogTitle></DialogHeader>
                      <div className="space-y-4">
                        <p className="text-sm text-muted-foreground">Paste the full content from a scholarship webpage below. AI will extract the key details for you.</p>
                        <Textarea
                          value={autoGenText}
                          onChange={(e) => setAutoGenText(e.target.value)}
                          placeholder="Paste scholarship page content here..."
                          rows={12}
                          className="font-mono text-xs"
                        />
                        <Button
                          className="w-full"
                          onClick={handleAutoGenExtract}
                          disabled={autoGenLoading || autoGenText.trim().length < 20}
                        >
                          {autoGenLoading ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Extracting...</> : <><Sparkles className="h-4 w-4 mr-2" />Extract Details</>}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Tabs defaultValue="active" className="space-y-4">
                    <TabsList className="flex w-full overflow-x-auto sm:inline-flex sm:w-auto h-auto justify-start gap-1">
                      <TabsTrigger value="active">Active ({activeScholarships.length})</TabsTrigger>
                      <TabsTrigger value="pending">Pending ({pendingScholarships.length})</TabsTrigger>
                      <TabsTrigger value="rejected" className={rejectedScholarships.length > 0 ? "text-red-600 dark:text-red-400" : ""}>
                        Rejected{rejectedScholarships.length > 0 ? ` (${rejectedScholarships.length})` : ""}
                      </TabsTrigger>
                      <TabsTrigger value="past">Past ({pastDeadlineScholarships.length})</TabsTrigger>
                      <TabsTrigger value="upcoming">Upcoming ({upcomingScholarships.length})</TabsTrigger>
                      <TabsTrigger value="recent">Recent ({recentCount})</TabsTrigger>
                      <TabsTrigger value="old-review">Old Review{oldReviewCount > 0 ? ` (${oldReviewCount})` : ""}</TabsTrigger>
                      <TabsTrigger value="duplicates">Duplicates</TabsTrigger>
                      <TabsTrigger value="auto-publish">Auto-Publish ({autoPublishScholarships.length})</TabsTrigger>
                    </TabsList>

                    <TabsContent value="active">
                      <ScholarshipTable
                        scholarships={activeScholarships}
                        isLoading={isLoading}
                        getStatusBadge={getStatusBadge}
                        onEdit={openEdit}
                        onDelete={confirmDelete}
                        onToggleChallenge={effectiveIsAdmin ? (id, next) => toggleChallengeMutation.mutate({ id, next }) : undefined}
                      />
                    </TabsContent>

                    <TabsContent value="pending">
                      {pendingScholarships.length === 0 && !isLoading ? (
                        <div className="text-center py-8 text-muted-foreground">No scholarships awaiting review.</div>
                      ) : (
                        <ScholarshipTable
                          scholarships={pendingScholarships}
                          isLoading={isLoading}
                          getStatusBadge={getStatusBadge}
                          onEdit={openEdit}
                          onDelete={confirmDelete}
                        />
                      )}
                    </TabsContent>

                    <TabsContent value="rejected">
                      {rejectedScholarships.length === 0 && !isLoading ? (
                        <div className="text-center py-8 text-muted-foreground">No rejected scholarships. 🎉</div>
                      ) : (
                        <div className="space-y-3">
                          <div className="rounded-lg bg-red-500/5 border border-red-500/20 p-3 text-sm text-red-700 dark:text-red-300">
                            These scholarships were rejected by a reviewer. Click <strong>Edit</strong> to see the rejection reason, fix the issues, and resubmit.
                          </div>
                          <ScholarshipTable
                            scholarships={rejectedScholarships}
                            isLoading={isLoading}
                            getStatusBadge={getStatusBadge}
                            onEdit={openEdit}
                            onDelete={confirmDelete}
                          />
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="past">
                      <ScholarshipTable
                        scholarships={pastDeadlineScholarships}
                        isLoading={isLoading}
                        getStatusBadge={getStatusBadge}
                        onEdit={openEdit}
                        onDelete={confirmDelete}
                        onRepublish={openRepublish}
                      />
                    </TabsContent>

                    <TabsContent value="upcoming">
                      <div className="space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3">
                          <Label className="text-sm text-muted-foreground">Opens in:</Label>
                          <Select value={upcomingFilter} onValueChange={setUpcomingFilter}>
                            <SelectTrigger className="w-full sm:w-[220px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All (next 90 days)</SelectItem>
                              <SelectItem value="lt1">&lt; 1 month</SelectItem>
                              <SelectItem value="1to2">1–2 months</SelectItem>
                              <SelectItem value="2to3">2–3 months</SelectItem>
                              <SelectItem value="gt3">&gt; 3 months</SelectItem>
                            </SelectContent>
                          </Select>
                          <span className="text-sm text-muted-foreground">
                            Showing {upcomingScholarships.length} of {upcomingScholarshipsAll.length}
                          </span>
                        </div>
                        {upcomingScholarships.length === 0 && !isLoading ? (
                          <div className="text-center py-8 text-muted-foreground">
                            No upcoming scholarships match this filter.
                          </div>
                        ) : (
                          <>
                            <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 text-sm text-muted-foreground">
                              These scholarships haven't opened yet — their next intake's open date is still in the future.
                            </div>
                            <ScholarshipTable
                              scholarships={upcomingScholarships}
                              isLoading={isLoading}
                              getStatusBadge={getStatusBadge}
                              onEdit={openEdit}
                              onDelete={confirmDelete}
                            />
                          </>
                        )}
                      </div>
                    </TabsContent>

                    <RecentScholarshipsTab onEdit={openEdit} onDelete={confirmDelete} />

                    <OldReviewTab onEdit={openEdit} />

                    <DuplicateScholarshipsTab onEdit={openEdit} />

                    <TabsContent value="auto-publish">
                      {autoPublishScholarships.length === 0 && !isLoading ? (
                        <div className="text-center py-8 text-muted-foreground">
                          No scholarships have Automatic Publish enabled yet. Turn it on from a scholarship's Edit dialog (main admin only).
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 text-sm text-muted-foreground">
                            These scholarships will automatically republish every year on their intake's open date. Intake dates roll forward by 1 year each cycle.
                          </div>
                          <ScholarshipTable
                            scholarships={autoPublishScholarships}
                            isLoading={isLoading}
                            getStatusBadge={getStatusBadge}
                            onEdit={openEdit}
                            onDelete={confirmDelete}
                          />
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </>
              );
            })()}
          </TabsContent>

          <PendingApprovalsTab viewAsUserId={viewAsModId} />

          <TabsContent value="chatrooms">
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <Dialog open={roomDialogOpen} onOpenChange={(o) => { setRoomDialogOpen(o); if (!o) setEditingRoomId(null); }}>
                <DialogTrigger asChild>
                  <Button onClick={openRoomCreate}><Plus className="h-4 w-4 mr-2" />Add Room</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader><DialogTitle>{editingRoom ? "Edit Room" : "Add Room"}</DialogTitle></DialogHeader>
                  <ChatRoomForm
                    key={editingRoomId ?? "new-room"}
                    defaultValues={editingRoom ? { name: editingRoom.name, description: editingRoom.description ?? "" } : undefined}
                    onSubmit={(v) => roomUpsert.mutate({ ...v, id: editingRoomId ?? undefined })}
                    loading={roomUpsert.isPending}
                  />
                </DialogContent>
              </Dialog>
            </div>

            <div className="rounded-xl border border-border bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Description</TableHead>
                    <TableHead className="hidden sm:table-cell">Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roomsLoading ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
                  ) : chatRooms.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No rooms yet</TableCell></TableRow>
                  ) : chatRooms.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium flex items-center gap-2"><Hash className="h-4 w-4 text-muted-foreground" />{r.name}</TableCell>
                      <TableCell className="hidden sm:table-cell max-w-[200px] truncate">{r.description ?? "—"}</TableCell>
                      <TableCell className="hidden sm:table-cell">{format(new Date(r.created_at), "MMM d, yyyy")}</TableCell>
                      <TableCell className="text-right space-x-1 whitespace-nowrap">
                        <AnnouncementManager roomId={r.id} roomName={r.name} />
                        <Button variant="ghost" size="icon" onClick={() => openRoomEdit(r.id)}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => roomDelete.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <DocReviewsTab user={user} />

          <BookingsTab user={user} />

          <QuickActionsTab />

          <TabsContent value="loans">
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <Dialog open={loanDialogOpen} onOpenChange={(o) => { setLoanDialogOpen(o); if (!o) setEditingLoanId(null); }}>
                <DialogTrigger asChild>
                  <Button onClick={openLoanCreate}><Plus className="h-4 w-4 mr-2" />Add Loan Provider</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader><DialogTitle>{editingLoan ? "Edit Loan Provider" : "Add Loan Provider"}</DialogTitle></DialogHeader>
                  <LoanProviderForm
                    key={editingLoanId ?? "new-loan"}
                    defaultValues={editingLoan ? {
                      name: editingLoan.name,
                      description: editingLoan.description ?? "",
                      requirements: editingLoan.requirements ?? "",
                      rates: editingLoan.rates ?? "",
                      url: editingLoan.url ?? "",
                      logo_url: editingLoan.logo_url ?? "",
                      is_active: editingLoan.is_active,
                      sort_order: editingLoan.sort_order ?? 0,
                    } : undefined}
                    onSubmit={(v) => loanUpsert.mutate({ ...v, id: editingLoanId ?? undefined })}
                    loading={loanUpsert.isPending}
                  />
                </DialogContent>
              </Dialog>
            </div>

            <div className="rounded-xl border border-border bg-card">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead className="hidden sm:table-cell">Rates</TableHead>
                    <TableHead>Active</TableHead>
                    <TableHead className="hidden sm:table-cell">Order</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loansLoading ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</TableCell></TableRow>
                  ) : loanProviders.length === 0 ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No loan providers yet</TableCell></TableRow>
                  ) : loanProviders.map((l: any) => (
                    <TableRow key={l.id}>
                      <TableCell className="font-medium">{l.name}</TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground">{l.rates ?? "—"}</TableCell>
                      <TableCell>
                        <Badge variant={l.is_active ? "default" : "secondary"}>{l.is_active ? "Active" : "Inactive"}</Badge>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground">{l.sort_order}</TableCell>
                      <TableCell className="text-right space-x-1 whitespace-nowrap">
                        <Button variant="ghost" size="icon" onClick={() => openLoanEdit(l.id)}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => loanDelete.mutate(l.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          <TabsContent value="notifications">
            <NotificationsTab />
          </TabsContent>
          <ResourcesTab />
          <BlogTab />
          {isAdmin && <DownloadsTab />}
          {isAdmin && (
            <TabsContent value="sitesettings">
              <SiteSettingsTab />
            </TabsContent>
          )}
          {isAdmin && (
            <TabsContent value="applysteps">
              <ApplyStepsTab />
            </TabsContent>
          )}
          {isAdmin && <PagesContentTab />}
          {isAdmin && (
            <TabsContent value="infosources">
              <InfoSourcesTab />
            </TabsContent>
          )}
          {isAdmin && <AnalyticsTab />}
          {isAdmin && <UserManagementTab />}
          {isAdmin && <ModeratorsTab />}
          {isAdmin && <ApprovalTeamTab />}
          {isAdmin && <ModeratorActivityTab />}
          {isAdmin && <SupportRequestsTab />}
          {(isAdmin || isModerator) && <ReportsTab />}
          {isAdmin && <TestimonialsTab />}
          {isAdmin && <EssayLibraryTab />}
          <CountriesTab
            onEdit={(id) => { setActiveAdminTab("scholarships"); setRepublishId(null); setEditingId(id); setDialogOpen(true); }}
            onDelete={confirmDelete}
            onToggleChallenge={effectiveIsAdmin ? (id, next) => toggleChallengeMutation.mutate({ id, next }) : undefined}
            onRepublish={(id) => { setActiveAdminTab("scholarships"); setEditingId(null); setRepublishId(id); setDialogOpen(true); }}
          />
        </Tabs>
      </main>
    </AppLayout>
  );
}
