import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import SEO from "@/components/SEO";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useMemo, useState, useEffect } from "react";
import { Link, Navigate } from "react-router-dom";
import { Trophy, ExternalLink, Calendar, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { getCountryFlag } from "@/lib/countryFlags";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

export default function ChallengeList() {
  const { settings, isLoading: settingsLoading } = useSiteSettings();
  const enabled = settings.challenge_menu_enabled !== "false";
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: submission, isLoading: loadingSub } = useQuery({
    queryKey: ["my-challenge-submission", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await (supabase as any)
        .from("challenge_submissions")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const { data: profile } = useQuery({
    queryKey: ["my-profile-basic", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("user_id", user.id)
        .maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  const [form, setForm] = useState({ full_name: "", course_of_study: "", cgpa: "", phone: "" });
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (!loadingSub && user && submission === null) setShowForm(true);
  }, [loadingSub, user, submission]);

  useEffect(() => {
    if (showForm && !form.full_name && profile?.full_name) {
      setForm((f) => ({ ...f, full_name: profile.full_name || "" }));
    }
  }, [showForm, profile, form.full_name]);

  const saveMut = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Not signed in");
      const payload = {
        user_id: user.id,
        full_name: form.full_name.trim(),
        email: user.email ?? "",
        course_of_study: form.course_of_study.trim(),
        cgpa: form.cgpa.trim(),
        phone: form.phone.trim(),
      };
      const { error } = await (supabase as any).from("challenge_submissions").insert(payload);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Submitted", description: "Welcome to the Challenge!" });
      setShowForm(false);
      queryClient.invalidateQueries({ queryKey: ["my-challenge-submission", user?.id] });
    },
    onError: (e: any) => toast({ title: "Could not submit", description: e.message, variant: "destructive" }),
  });

  const canViewList = !!submission && !showForm;

  const { data: scholarships = [], isLoading } = useQuery({
    queryKey: ["challenge-scholarships"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("scholarships")
        .select("*")
        .eq("is_challenge", true as any)
        .eq("is_active", true)
        .order("country", { ascending: true })
        .order("next_close_date", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
    enabled: enabled && canViewList,
  });

  const grouped = useMemo(() => {
    const map = new Map<string, any[]>();
    scholarships.forEach((s: any) => {
      const countries = (s.country || "Other").split(",").map((c: string) => c.trim()).filter(Boolean);
      (countries.length ? countries : ["Other"]).forEach((c: string) => {
        if (!map.has(c)) map.set(c, []);
        map.get(c)!.push(s);
      });
    });
    return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [scholarships]);

  if (!settingsLoading && !enabled) return <Navigate to="/dashboard" replace />;

  const formValid = form.full_name.trim() && form.course_of_study.trim() && form.cgpa.trim() && form.phone.trim();

  return (
    <AppLayout>
      <SEO title="Challenge List | Brimsom" description="Scholarships featured in the current Brimsom Challenge." path="/challenge-list" />
      <main className="container mx-auto px-4 py-6 sm:py-12 space-y-6">
        <div className="flex items-center gap-2">
          <BackButton iconOnly />
          <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <Trophy className="h-5 w-5 sm:h-6 sm:w-6 text-amber-500" /> Challenge List
          </h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Scholarships hand-picked for the current challenge, grouped by country.
        </p>

        {loadingSub || !canViewList ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <Trophy className="h-10 w-10 text-amber-500 mx-auto mb-3" />
            <p className="text-muted-foreground">
              Please complete the short form to access the Challenge List.
            </p>
          </div>
        ) : isLoading ? (
          <p className="text-muted-foreground">Loading…</p>
        ) : grouped.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <Trophy className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No challenge scholarships yet. Check back soon.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {grouped.map(([country, items]) => (
              <section key={country} className="space-y-3">
                <div className="flex items-center gap-2 sticky top-16 bg-background/80 backdrop-blur-sm py-2 z-10">
                  <span className="text-2xl">{getCountryFlag(country)}</span>
                  <h2 className="text-lg font-semibold">{country}</h2>
                  <Badge variant="secondary">{items.length}</Badge>
                </div>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map((s: any) => (
                    <div key={`${country}-${s.id}`} className="rounded-xl border border-border bg-card p-4 sm:p-5 space-y-2 min-w-0">
                      <Link to={`/scholarships/${s.id}`} className="block">
                        <h3 className="font-semibold line-clamp-2 hover:text-primary transition-colors">{s.title}</h3>
                      </Link>
                      {s.provider && <p className="text-sm text-muted-foreground truncate">{s.provider}</p>}
                      {s.funding_amount && <p className="text-sm text-primary font-medium">{s.funding_amount}</p>}
                      {s.next_close_date && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Deadline: {new Date(s.next_close_date).toLocaleDateString()}
                        </p>
                      )}
                      {s.url && (
                        <Button size="sm" className="w-full mt-1" asChild>
                          <a href={s.url} target="_blank" rel="noopener noreferrer">
                            Apply Now <ExternalLink className="h-3.5 w-3.5 ml-1" />
                          </a>
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}

        <Dialog open={showForm} onOpenChange={(o) => { if (!o && !submission) return; setShowForm(o); }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Join the Challenge</DialogTitle>
              <DialogDescription>
                Tell us a bit about yourself to access the Challenge List. This is a one-time form.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="ch-name">Full name</Label>
                <Input id="ch-name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} maxLength={120} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ch-course">Course of study</Label>
                <Input id="ch-course" value={form.course_of_study} onChange={(e) => setForm({ ...form, course_of_study: e.target.value })} maxLength={120} placeholder="e.g. Computer Science" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ch-cgpa">CGPA</Label>
                <Input id="ch-cgpa" value={form.cgpa} onChange={(e) => setForm({ ...form, cgpa: e.target.value })} maxLength={20} placeholder="e.g. 4.50/5.00 or 3.8/4.0" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ch-phone">Phone number</Label>
                <Input id="ch-phone" type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} maxLength={30} placeholder="+234..." />
              </div>
              <Button className="w-full" disabled={!formValid || saveMut.isPending} onClick={() => saveMut.mutate()}>
                {saveMut.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Submit & view list
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </AppLayout>
  );
}
