import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import { useApplicationTracker, Application } from "@/hooks/useApplicationTracker";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { MoreVertical, Trash2, Pencil, CalendarDays } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import SEO from "@/components/SEO";

const STATUSES = [
  { value: "drafting", label: "Drafting" },
  { value: "submitted", label: "Submitted" },
  { value: "accepted", label: "Accepted" },
  { value: "rejected", label: "Rejected" },
];

function statusMeta(status: string) {
  return STATUSES.find((s) => s.value === status) ?? STATUSES[0];
}

const PAGE_SIZE = 10;

export default function Tracker() {
  const { applications, isLoading, updateApplication, deleteApplication } = useApplicationTracker();
  const [editApp, setEditApp] = useState<Application | null>(null);
  const [form, setForm] = useState({ custom_name: "", deadline: "", notes: "" });
  const [visibleCounts, setVisibleCounts] = useState<Record<string, number>>({});

  const getVisible = (status: string) => visibleCounts[status] ?? PAGE_SIZE;
  const loadMore = (status: string) =>
    setVisibleCounts((prev) => ({ ...prev, [status]: getVisible(status) + PAGE_SIZE }));

  const openEdit = (app: Application) => {
    setEditApp(app);
    setForm({ custom_name: app.custom_name || app.scholarship_title || "", deadline: app.deadline || "", notes: app.notes || "" });
  };

  const handleEdit = async () => {
    if (!editApp) return;
    await updateApplication.mutateAsync({ id: editApp.id, custom_name: form.custom_name, deadline: form.deadline || undefined, notes: form.notes || undefined });
    setEditApp(null);
    toast({ title: "Application updated" });
  };

  const handleStatusChange = async (id: string, status: string) => {
    await updateApplication.mutateAsync({ id, status });
    toast({ title: `Moved to ${statusMeta(status).label}` });
  };

  const handleDelete = async (id: string) => {
    await deleteApplication.mutateAsync(id);
    toast({ title: "Application deleted" });
  };

  const total = applications.length;

  return (
    <AppLayout>
      <SEO title="Application Tracker | Brimsom" description="Track every scholarship application from interested to submitted, accepted, or waitlisted." path="/tracker" />
      <main className="container mx-auto px-4 py-12 space-y-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
            <BackButton iconOnly />
            Application Tracker
          </h1>
          <p className="text-muted-foreground">Track your scholarship applications across stages.</p>
        </div>

        <div className="flex flex-wrap gap-3">
          <Badge variant="outline" className="text-sm px-3 py-1">Total: {total}</Badge>
          {STATUSES.map((s) => {
            const count = applications.filter((a) => a.status === s.value).length;
            return count > 0 ? <Badge key={s.value} variant="outline" className="text-sm px-3 py-1">{s.label}: {count}</Badge> : null;
          })}
        </div>

        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <Tabs defaultValue="drafting" className="w-full">
            <TabsList className="w-full grid grid-cols-4">
              {STATUSES.map((s) => {
                const count = applications.filter((a) => a.status === s.value).length;
                return (
                  <TabsTrigger key={s.value} value={s.value} className="text-xs sm:text-sm">
                    {s.label} ({count})
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {STATUSES.map((s) => {
              const items = applications.filter((a) => a.status === s.value);
              const visible = getVisible(s.value);
              const shown = items.slice(0, visible);
              const remaining = items.length - shown.length;
              return (
                <TabsContent key={s.value} value={s.value} className="space-y-3 mt-4">
                  {items.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-10">No applications in {s.label.toLowerCase()}</p>
                  )}
                  {shown.map((app) => (
                    <DropdownMenu key={app.id}>
                      <DropdownMenuTrigger asChild>
                        <Card className="p-4 flex items-start justify-between gap-3 cursor-pointer transition-colors hover:bg-accent/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                          <div className="space-y-1 min-w-0">
                            <span className="font-medium text-sm leading-tight block">
                              {app.custom_name || app.scholarship_title || "Untitled"}
                            </span>
                            {app.deadline && (
                              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                <CalendarDays className="h-3 w-3" />
                                {format(new Date(app.deadline), "MMM d, yyyy")}
                              </div>
                            )}
                            {app.notes && <p className="text-xs text-muted-foreground line-clamp-2">{app.notes}</p>}
                          </div>
                          <MoreVertical className="h-4 w-4 shrink-0 text-muted-foreground" />
                        </Card>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {STATUSES.filter((st) => st.value !== app.status).map((st) => (
                          <DropdownMenuItem key={st.value} onClick={() => handleStatusChange(app.id, st.value)}>
                            Move to {st.label}
                          </DropdownMenuItem>
                        ))}
                        <DropdownMenuItem onClick={() => openEdit(app)}>
                          <Pencil className="h-3.5 w-3.5 mr-1.5" />Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(app.id)}>
                          <Trash2 className="h-3.5 w-3.5 mr-1.5" />Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ))}
                  {remaining > 0 && (
                    <div className="flex justify-center pt-2">
                      <Button variant="outline" size="sm" onClick={() => loadMore(s.value)}>
                        Load More ({remaining} remaining)
                      </Button>
                    </div>
                  )}
                </TabsContent>
              );
            })}
          </Tabs>
        )}
      </main>

      {/* Edit Dialog */}
      <Dialog open={!!editApp} onOpenChange={(o) => !o && setEditApp(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Application</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Scholarship Name</label>
              <Input value={form.custom_name} onChange={(e) => setForm((f) => ({ ...f, custom_name: e.target.value }))} />
            </div>
            <div>
              <label className="text-sm font-medium">Deadline</label>
              <Input type="date" value={form.deadline} onChange={(e) => setForm((f) => ({ ...f, deadline: e.target.value }))} />
            </div>
            <div>
              <label className="text-sm font-medium">Notes</label>
              <Textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditApp(null)}>Cancel</Button>
            <Button onClick={handleEdit} disabled={updateApplication.isPending}>
              {updateApplication.isPending ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}