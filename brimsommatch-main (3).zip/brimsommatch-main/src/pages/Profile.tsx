import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import ProfileStepper from "@/components/profile/ProfileStepper";
import PersonalInfoStep from "@/components/profile/PersonalInfoStep";
import EducationStep from "@/components/profile/EducationStep";
import TestScoresStep from "@/components/profile/TestScoresStep";
import ResearchStep from "@/components/profile/ResearchStep";
import DocumentsStep from "@/components/profile/DocumentsStep";
import ExtracurricularsStep from "@/components/profile/ExtracurricularsStep";
import EssayProfileStep from "@/components/profile/EssayProfileStep";
import ProfileMethodChooser from "@/components/profile/ProfileMethodChooser";
import type { ResumeData } from "@/components/profile/ProfileMethodChooser";
import { useProfileData } from "@/hooks/useProfileData";
import { toast } from "sonner";
import SEO from "@/components/SEO";

const STEP_PARAM_MAP: Record<string, number> = {
  personal: 0,
  education: 1,
  tests: 2,
  essay: 3,
  experience: 4,
  documents: 5,
  extracurriculars: 6,
};

export default function Profile() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const stepParam = searchParams.get("step");
  const initialStep = stepParam && STEP_PARAM_MAP[stepParam] !== undefined ? STEP_PARAM_MAP[stepParam] : 0;
  const [step, setStep] = useState(initialStep);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [saving, setSaving] = useState(false);
  const [academicLevel, setAcademicLevel] = useState("");
  const [mode, setMode] = useState<"choose" | "stepper">(stepParam ? "stepper" : "choose");
  const profile = useProfileData();

  useEffect(() => {
    if (stepParam && STEP_PARAM_MAP[stepParam] !== undefined) {
      setStep(STEP_PARAM_MAP[stepParam]);
      setMode("stepper");
    }
  }, [stepParam]);

  const markDone = (s: number) => setCompletedSteps(prev => new Set([...prev, s]));

  // Sync academic level from loaded profile
  if (profile.personalInfo?.academic_level && !academicLevel) {
    setAcademicLevel(profile.personalInfo.academic_level);
  }

  // Skip chooser if profile already has data (editing mode)
  // Don't count full_name alone — it's set at signup. Only skip chooser for real profile data.
  const hasExistingData = profile.education.some(e => e.institution) ||
    profile.testScores.length > 0 ||
    profile.research.some(r => r.title) ||
    profile.extracurriculars.length > 0;

  if (!profile.loading && hasExistingData && mode === "choose") {
    setMode("stepper");
  }

  if (profile.loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading profile...</p>
      </div>
    );
  }

  const handleResumeData = (data: ResumeData) => {
    profile.setFromResume(data);
    setMode("stepper");
  };

  return (
    <AppLayout>
      <SEO title="Your Profile | Brimsom" description="Build the profile that powers AI scholarship matching and chance scoring." path="/profile" />
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-start justify-between gap-4 mb-1">
          <div className="min-w-0">
            <h1 className="text-lg sm:text-2xl font-bold mb-1 flex items-center gap-2">
              <BackButton iconOnly />
              Complete Your Profile
            </h1>
            <p className="text-muted-foreground mb-8">Fill out each section to unlock your chance score and scholarship matches.</p>
          </div>
          {mode === "stepper" && (
            <div
              className="shrink-0 h-14 w-14 rounded-full border-2 border-primary/30 bg-primary/10 flex items-center justify-center"
              title="Profile completeness"
              aria-label={`Profile ${profile.getCompleteness()}% complete`}
            >
              <span className="text-sm font-bold text-primary">{profile.getCompleteness()}%</span>
            </div>
          )}
        </div>

        {mode === "choose" && (
          <ProfileMethodChooser
            onResumeData={handleResumeData}
            onManual={() => setMode("stepper")}
          />
        )}

        {mode === "stepper" && (
          <>
            <div className="mb-10">
              <ProfileStepper currentStep={step} completedSteps={completedSteps} onStepClick={setStep} />
            </div>

            {step === 0 && (
              <PersonalInfoStep
                defaultValues={profile.personalInfo ?? undefined}
                onNext={async (data) => {
                  await profile.savePersonalInfo(data);
                  setAcademicLevel(data.academic_level || "");
                  markDone(0);
                  setStep(1);
                }}
              />
            )}
            {step === 1 && (
              <EducationStep
                defaultValues={profile.education.length ? profile.education : undefined}
                defaultSubjects={profile.highSchoolSubjects.length ? profile.highSchoolSubjects : undefined}
                academicLevel={academicLevel}
                onNext={async (data, subjects) => {
                  await profile.saveEducation(data, subjects);
                  markDone(1);
                  setStep(2);
                }}
                onBack={() => setStep(0)}
              />
            )}
            {step === 2 && (
              <TestScoresStep
                defaultValues={profile.testScores.length ? profile.testScores : undefined}
                onNext={async (data) => {
                  await profile.saveTestScores(data);
                  markDone(2);
                  setStep(3);
                }}
                onBack={() => setStep(1)}
              />
            )}
            {step === 3 && (
              <EssayProfileStep
                defaultValues={profile.essayProfile ?? undefined}
                onNext={async (data) => {
                  await profile.saveEssayProfile(data);
                  markDone(3);
                  setStep(4);
                }}
                onBack={() => setStep(2)}
              />
            )}
            {step === 4 && (
              <ResearchStep
                defaultValues={profile.research.length ? profile.research : undefined}
                academicLevel={academicLevel}
                onNext={async (data) => {
                  await profile.saveResearch(data);
                  markDone(4);
                  setStep(5);
                }}
                onBack={() => setStep(3)}
              />
            )}
            {step === 5 && (
              <DocumentsStep
                defaultDocs={profile.documents.length ? profile.documents : undefined}
                defaultSop={profile.sop || undefined}
                onNext={async (docs, sopText) => {
                  await profile.saveDocs(docs, sopText);
                  markDone(5);
                  setStep(6);
                }}
                onBack={() => setStep(4)}
              />
            )}
            {step === 6 && (
              <ExtracurricularsStep
                defaultValues={profile.extracurriculars.length ? profile.extracurriculars : undefined}
                onSave={async (data) => {
                  setSaving(true);
                  await profile.saveExtracurriculars(data);
                  markDone(6);
                  setSaving(false);
                  toast.success("Profile saved successfully!");
                  navigate("/dashboard");
                }}
                onBack={() => setStep(5)}
                saving={saving}
              />
            )}
          </>
        )}
      </main>
    </AppLayout>
  );
}
