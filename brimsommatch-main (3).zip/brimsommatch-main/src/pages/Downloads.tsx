import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Smartphone, Monitor, Apple, ArrowLeft } from "lucide-react";
import { useAppDownloads } from "@/hooks/useAppDownloads";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { ThemeToggle } from "@/components/ThemeToggle";
import { GraduationCap } from "lucide-react";
import SEO from "@/components/SEO";

const platformConfig: Record<string, { label: string; icon: typeof Smartphone; description: string }> = {
  android: { label: "Android", icon: Smartphone, description: "Download the APK for Android devices" },
  ios: { label: "iOS", icon: Apple, description: "Download for iPhone and iPad" },
  windows: { label: "Windows", icon: Monitor, description: "Download for Windows PC" },
};

export default function Downloads() {
  const { downloads, isLoading } = useAppDownloads();
  const { settings } = useSiteSettings();
  const logoUrl = settings.logo_url;

  const activeDownloads = downloads.filter((d) => d.is_active && d.file_url);

  return (
    <div className="min-h-screen bg-background">
      <SEO title="Get the App | Brimsom" description="Install Brimsom on iOS, Android, or desktop and take your scholarship journey on the go." path="/downloads" />
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto flex items-center justify-between h-16 px-4">
          <Link to="/" className="flex items-center gap-2">
            {logoUrl ? (
              <img src={logoUrl} alt="Logo" className="h-8 w-8 rounded-lg object-contain" />
            ) : (
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
            )}
            <span className="text-xl font-bold font-serif">Brimsom</span>
          </Link>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="ghost" size="sm" asChild>
              <Link to="/"><ArrowLeft className="h-4 w-4 mr-1" /> Back</Link>
            </Button>
          </div>
        </div>
      </nav>

      <main className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Download Brimsom</h1>
          <p className="text-muted-foreground text-lg">
            Get the Brimsom app on your favorite platform and never miss a scholarship opportunity.
          </p>
        </div>

        {isLoading ? (
          <div className="text-center text-muted-foreground py-12">Loading...</div>
        ) : activeDownloads.length === 0 ? (
          <div className="text-center text-muted-foreground py-12">
            <Download className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No downloads available at the moment. Check back soon!</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {activeDownloads.map((dl) => {
              const config = platformConfig[dl.platform] ?? { label: dl.platform, icon: Download, description: "" };
              const Icon = config.icon;
              return (
                <Card key={dl.id} className="text-center">
                  <CardHeader>
                    <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                      <Icon className="h-7 w-7 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{config.label}</CardTitle>
                    {dl.version && <Badge variant="secondary" className="mx-auto mt-1">v{dl.version}</Badge>}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{config.description}</p>
                    <Button className="w-full" asChild>
                      <a href={dl.file_url!} download={dl.file_name ?? undefined}>
                        <Download className="h-4 w-4 mr-2" /> Download
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
