import { useState, useCallback, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { GraduationCap, Target, Users, Sparkles, ArrowRight, Instagram, Youtube, Linkedin, Facebook, Twitter, Menu, Download, Wand2, PenLine, MessageCircle } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { useAppDownloads } from "@/hooks/useAppDownloads";
import { useSliderImages } from "@/hooks/useSliderImages";
import useEmblaCarousel from "embla-carousel-react";
import Autoplay from "embla-carousel-autoplay";
import FloatingOrbs from "@/components/landing/FloatingOrbs";
import AnimatedHeading from "@/components/landing/AnimatedHeading";
import GuestChatBox from "@/components/landing/GuestChatBox";
import SEO from "@/components/SEO";

const smartFeatures = [
  {
    icon: Target,
    title: "AI Chance Score",
    description: "Get a personalized score showing your likelihood of winning scholarships based on your profile.",
  },
  {
    icon: Sparkles,
    title: "Smart Matching",
    description: "AI compares your profile against each scholarship's requirements so you don't waste time.",
  },
  {
    icon: Wand2,
    title: "Match Me",
    description: "Paste any scholarship link and Brim instantly tells you how well it fits your profile.",
  },
  {
    icon: MessageCircle,
    title: "Brim AI Chat",
    description: "Chat with Brim for tailored guidance on scholarships, essays, and application strategy.",
  },
];

const otherFeatures = [
  {
    icon: PenLine,
    title: "Statement Writer",
    description: "Draft tailored personal statements and SOPs with Brim using your profile and target scholarship.",
  },
  {
    icon: GraduationCap,
    title: "Scholarship Feed",
    description: "Browse curated scholarships with filters for country, field, deadline, and funding amount.",
  },
  {
    icon: Users,
    title: "Community",
    description: "Connect with fellow applicants, share tips, and support each other through the process.",
  },
];

const steps = [
  "Build your academic profile with education, research, and achievements",
  "Get your AI-powered Scholarship Readiness Score",
  "Discover scholarships matched to your strengths",
  "Apply with confidence, no more guessing",
];

export default function Landing() {
  const { settings } = useSiteSettings();
  const { downloads } = useAppDownloads();
  const { activeImages } = useSliderImages();
  const [mobileOpen, setMobileOpen] = useState(false);
  const logoUrl = settings.logo_url;
  const showDownloadButton = settings.show_download_button !== "false" && downloads.some((d) => d.is_active && d.file_url);

  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true }, [Autoplay({ delay: 4000, stopOnInteraction: false })]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  // Typewriter effect for chat preview
  const prompts = [
    "Find me fully-funded UK Masters scholarships…",
    "Improve my SOP for Chevening…",
    "What are my chances for DAAD?",
  ];

  // Random match count messages for the bubble
  const matchMessages = [
    "I found 8 matches for you — want to see?",
    "I found 12 matches for you — want to see?",
    "I found 15 matches for you — want to see?",
    "I found 23 matches for you — want to see?",
    "I found 6 matches for you — want to see?",
    "I found 31 matches for you — want to see?",
  ];
  const [randomMatchMessage] = useState(() => 
    matchMessages[Math.floor(Math.random() * matchMessages.length)]
  );

  const [typed, setTyped] = useState("");
  const [promptIdx, setPromptIdx] = useState(0);

  useEffect(() => {
    const current = prompts[promptIdx];
    let i = 0;
    setTyped("");
    const typing = setInterval(() => {
      i++;
      setTyped(current.slice(0, i));
      if (i >= current.length) {
        clearInterval(typing);
        setTimeout(() => setPromptIdx((p) => (p + 1) % prompts.length), 2200);
      }
    }, 55);
    return () => clearInterval(typing);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [promptIdx]);

  const { scrollYProgress } = useScroll();
  const ctaY = useTransform(scrollYProgress, [0.6, 1], [40, 0]);
  const ctaScale = useTransform(scrollYProgress, [0.6, 0.85], [0.97, 1]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on("select", onSelect);
    return () => { emblaApi.off("select", onSelect); };
  }, [emblaApi, onSelect]);

  const LogoIcon = () => logoUrl ? (
    <img src={logoUrl} alt="Brimsom AI Logo" className="h-8 w-8 rounded-lg object-contain" />
  ) : (
    <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
      <GraduationCap className="h-5 w-5 text-primary-foreground" />
    </div>
  );

  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden">
      <SEO
        title="Brimsom — Find Scholarships You'll Win"
        description="AI powered scholarship matching. Build your profile, get a chance score, and discover scholarships matched to your strengths."
        path="/"
      />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="relative z-10 pt-16">
      {/* Nav */}
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm fixed top-0 inset-x-0 z-50">
        <div className="container mx-auto flex items-center justify-between h-16 px-4">
          <Link to="/" className="flex items-center gap-2">
            <LogoIcon />
            <span className="text-xl font-bold font-serif">Brimsom AI</span>
          </Link>
          <div className="hidden md:flex items-center gap-2">
            <Button variant="ghost" asChild size="sm">
              <Link to="/blog">Blog</Link>
            </Button>
            <ThemeToggle />
            <Button variant="ghost" asChild>
              <Link to="/auth">Log in</Link>
            </Button>
            <Button asChild>
              <Link to="/auth?tab=signup">Get Started</Link>
            </Button>
          </div>
          <div className="flex md:hidden items-center gap-1">
            <ThemeToggle />
            <Button variant="ghost" size="icon" aria-label="Open menu" onClick={() => setMobileOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Sheet */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-72 flex flex-col">
          <SheetHeader>
            <SheetTitle className="text-left">Menu</SheetTitle>
          </SheetHeader>
          <div className="flex flex-col gap-2 mt-4 flex-1">
            <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/blog">Blog</Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/auth">Log in</Link>
            </Button>
            <Button className="w-full mt-2" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/auth?tab=signup">Get Started <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      <main id="main-content">
      {/* Hero */}
      <section className="relative container mx-auto px-4 pt-20 pb-24 text-center">
        <FloatingOrbs />
        <div className="relative z-10">
          <AnimatedHeading customTitle={settings.hero_title} />

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6"
          >
            {settings.hero_description || "Stop guessing. Brimsom analyzes your academic profile and matches you with scholarships where you have the strongest chance of success."}
          </motion.p>

          <div className="mb-10" />

          {(settings.phone_image_1_url || settings.phone_image_2_url) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0, duration: 0.6 }}
              className="mb-10 flex items-end justify-center gap-3 sm:gap-6"
            >
              {[settings.phone_image_1_url, settings.phone_image_2_url]
                .filter(Boolean)
                .map((url, i) => (
                  <img
                    key={i}
                    src={url as string}
                    alt={`App preview ${i + 1}`}
                    className="w-40 sm:w-56 md:w-64 h-auto object-contain drop-shadow-2xl"
                    loading="lazy"
                  />
                ))}
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button size="lg" asChild className="h-12 px-8 text-base">
              <Link to="/auth?tab=signup">
                Start for Free <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="h-12 px-8 text-base">
              <a href="#features">See How It Works</a>
            </Button>
          </motion.div>

          {showDownloadButton && (() => {
            const storeConfig: Record<string, { label: string; sub: string; icon: JSX.Element }> = {
              android: {
                label: "Google Play",
                sub: "GET IT ON",
                icon: (
                  <svg viewBox="0 0 24 24" className="h-7 w-7" aria-hidden="true">
                    <path fill="#EA4335" d="M3.6 2.3c-.4.4-.6 1-.6 1.8v15.8c0 .8.2 1.4.6 1.8l12-11.7L3.6 2.3z" />
                    <path fill="#FBBC04" d="m17.9 12 3.4-2c1-.6 1-1.6 0-2.2l-3.4-2-3.9 3.8L17.9 12z" />
                    <path fill="#34A853" d="M3.6 21.7c.6.6 1.5.6 2.6 0l12.7-7.3-3.9-3.8L3.6 21.7z" />
                    <path fill="#4285F4" d="M6.2 2.3c-1.1-.6-2-.6-2.6 0l11.4 11.1 3.9-3.8L6.2 2.3z" />
                  </svg>
                ),
              },
              ios: {
                label: "App Store",
                sub: "Download on the",
                icon: (
                  <svg viewBox="0 0 24 24" className="h-7 w-7 fill-current" aria-hidden="true">
                    <path d="M16.5 12.6c0-2.4 2-3.6 2.1-3.6-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.6.9-.7 0-1.9-.9-3.1-.8-1.6 0-3 .9-3.9 2.4-1.7 2.9-.4 7.2 1.2 9.6.8 1.2 1.7 2.5 3 2.4 1.2 0 1.6-.8 3.1-.8s1.9.8 3.1.8c1.3 0 2.1-1.2 2.9-2.4.6-.9.9-1.7 1.2-2.5-1.4-.6-2.5-2.1-2.5-4.1zM14 4.5c.7-.8 1.1-2 1-3.1-1 0-2.2.7-2.9 1.5-.6.7-1.2 1.9-1 3 1.1.1 2.3-.6 2.9-1.4z" />
                  </svg>
                ),
              },
              windows: {
                label: "Microsoft",
                sub: "Download for",
                icon: (
                  <svg viewBox="0 0 24 24" className="h-7 w-7" aria-hidden="true">
                    <path fill="#F25022" d="M3 3h8.5v8.5H3z" />
                    <path fill="#7FBA00" d="M12.5 3H21v8.5h-8.5z" />
                    <path fill="#00A4EF" d="M3 12.5h8.5V21H3z" />
                    <path fill="#FFB900" d="M12.5 12.5H21V21h-8.5z" />
                  </svg>
                ),
              },
            };
            const order = ["android", "ios", "windows"];
            const active = order
              .map((p) => ({ platform: p, item: downloads.find((d) => d.platform === p && d.is_active && d.file_url) }))
              .filter((x) => x.item);
            if (active.length === 0) return null;
            return (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.4 }}
                className="mt-8 flex flex-wrap items-center justify-center gap-3"
              >
                {active.map(({ platform, item }) => {
                  const cfg = storeConfig[platform];
                  if (!cfg || !item) return null;
                  return (
                    <a
                      key={platform}
                      href={item.file_url!}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 rounded-xl border border-border bg-foreground text-background px-4 py-2.5 hover:opacity-90 transition-opacity min-w-[160px]"
                      aria-label={`Download for ${cfg.label}`}
                    >
                      {cfg.icon}
                      <div className="flex flex-col leading-tight text-left">
                        <span className="text-[10px] uppercase tracking-wide opacity-80">{cfg.sub}</span>
                        <span className="text-sm font-semibold">{cfg.label}</span>
                      </div>
                    </a>
                  );
                })}
              </motion.div>
            );
          })()}

          {/* Social Media Icons */}
          {(() => {
            const socials = [
              { key: "social_instagram", icon: Instagram, label: "Instagram" },
              { key: "social_twitter", icon: Twitter, label: "X" },
              { key: "social_tiktok", icon: null, label: "TikTok" },
              { key: "social_youtube", icon: Youtube, label: "YouTube" },
              { key: "social_linkedin", icon: Linkedin, label: "LinkedIn" },
              { key: "social_facebook", icon: Facebook, label: "Facebook" },
            ].filter(s => settings[s.key]);
            if (socials.length === 0) return null;
            return (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.5 }}
                className="mt-8 flex flex-col items-center gap-3"
              >
                <span className="text-sm text-muted-foreground">Follow us</span>
                <div className="flex items-center gap-3">
                  {socials.map(({ key, icon: Icon, label }) => (
                    <a
                      key={key}
                      href={settings[key]}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="h-10 w-10 rounded-full border border-border bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                      aria-label={label}
                    >
                      {Icon ? (
                        <Icon className="h-5 w-5" />
                      ) : (
                        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.88-2.89 2.89 2.89 0 0 1 2.88-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.18 8.18 0 0 0 4.76 1.52V6.84a4.84 4.84 0 0 1-1-.15z"/></svg>
                      )}
                    </a>
                  ))}
                </div>
              </motion.div>
            );
          })()}
        </div>

        {/* AI Chat Preview - Interactive (2 free messages) */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6, duration: 0.6 }}
          className="relative z-10 max-w-3xl lg:max-w-4xl mx-auto mt-16 px-2"
        >
          {/* Floating assistant bubble */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2.2, duration: 0.5 }}
            className="absolute -top-12 left-4 sm:left-8 z-20"
          >
            <div className="bg-card border border-border shadow-lg rounded-2xl px-4 py-2.5 text-sm text-foreground flex items-center gap-2 whitespace-nowrap">
              <Sparkles className="h-3.5 w-3.5 text-primary shrink-0" />
              <span>{randomMatchMessage}</span>
            </div>
          </motion.div>

          <GuestChatBox
            initialPrompts={prompts}
            typedPlaceholder={typed}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative z-10 max-w-3xl mx-auto mt-12 sm:mt-16 px-2"
        >
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-tight text-foreground">
            Say goodbye to manual scholarship hunting
          </h2>
          <p className="mt-4 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Brim finds, ranks, and matches scholarships to you, in seconds, not weekends.
          </p>
        </motion.div>

        {activeImages.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.3, duration: 0.6 }}
            className="max-w-4xl mx-auto mt-12 relative z-10"
          >
            <div className="overflow-hidden rounded-xl" ref={emblaRef}>
              <div className="flex">
                {activeImages.map((img, idx) => (
                  <div key={img.id} className="flex-[0_0_100%] min-w-0">
                    <img
                      src={img.image_url}
                      alt={img.alt_text || ""}
                      width={1280}
                      height={720}
                      className="w-full h-64 sm:h-80 md:h-96 object-cover rounded-xl"
                      loading={idx === 0 ? "eager" : "lazy"}
                      fetchPriority={idx === 0 ? "high" : "auto"}
                      decoding={idx === 0 ? "sync" : "async"}
                    />
                  </div>
                ))}
              </div>
            </div>
            {activeImages.length > 1 && (
              <div className="flex justify-center gap-2 mt-4">
                {activeImages.map((_, i) => (
                  <button
                    key={i}
                    className={`h-2 rounded-full transition-all ${i === selectedIndex ? "w-6 bg-primary" : "w-2 bg-muted-foreground/30"}`}
                    onClick={() => emblaApi?.scrollTo(i)}
                    aria-label={`Go to slide ${i + 1}`}
                  />
                ))}
              </div>
            )}
          </motion.div>
        )}
      </section>

      {/* Features */}
      <section id="features" className="bg-secondary/50 py-24">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{settings.features_title || "Everything you need to win"}</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              {settings.features_description || "From profile analysis to community support — Brimsom gives you the tools to maximize your scholarship success."}
            </p>
          </motion.div>
          <div className="space-y-14">
            {[
              { heading: "Brimsom Smart Features", subheading: "AI-powered tools that do the heavy lifting for you.", items: smartFeatures },
              { heading: "Other Features", subheading: "Everything else you need to apply with confidence.", items: otherFeatures },
            ].map((group) => (
              <div key={group.heading}>
                <div className="mb-6 text-center">
                  <h3 className="text-2xl font-bold mb-2">{group.heading}</h3>
                  <p className="text-sm text-muted-foreground">{group.subheading}</p>
                </div>
                <div className={`grid gap-6 ${group.items.length === 3 ? "md:grid-cols-3 max-w-5xl mx-auto" : "md:grid-cols-2 lg:grid-cols-4"}`}>
                  {group.items.map((feature, i) => (
                    <motion.div
                      key={feature.title}
                      initial={{ opacity: 0, y: 30, scale: 0.95, rotate: -1 }}
                      whileInView={{ opacity: 1, y: 0, scale: 1, rotate: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1, duration: 0.5, type: "spring", stiffness: 120 }}
                      className="bg-card rounded-xl border border-border p-6 feature-card-hover"
                    >
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                        <feature.icon className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto">
            <motion.h2
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-3xl md:text-4xl font-bold mb-12 text-center"
            >
              How it works
            </motion.h2>
            <div className="relative space-y-6">
              {/* Connecting line */}
              <div className="absolute left-4 top-4 bottom-4 w-px bg-border hidden sm:block" />
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5 }}
                  className="flex items-start gap-4"
                >
                  <div className="relative flex-shrink-0 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-semibold z-10">
                    {i + 1}
                  </div>
                  <p className="text-lg pt-0.5">{step}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <motion.section style={{ y: ctaY, scale: ctaScale }} className="py-24 bg-primary/90 relative overflow-hidden mx-4 sm:mx-8 my-12 rounded-[45%/25%] sm:rounded-[35%/60%]">
        {/* Subtle animated orb in CTA */}
        <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-primary-foreground/5 blur-3xl animate-orb-drift pointer-events-none" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4"
          >
            {settings.cta_title || "Ready to find your scholarship?"}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-primary-foreground/80 mb-8 max-w-xl mx-auto"
          >
            {settings.cta_description || "Join thousands of students who are discovering scholarships matched to their unique strengths."}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <Button size="lg" variant="secondary" asChild className="h-12 px-8 text-base">
              <Link to="/auth?tab=signup">
                Create Your Profile <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>

          {/* Follow us socials */}
          {(() => {
            const socials = [
              { key: "social_instagram", icon: Instagram, label: "Instagram" },
              { key: "social_twitter", icon: Twitter, label: "X" },
              { key: "social_tiktok", icon: null, label: "TikTok" },
              { key: "social_youtube", icon: Youtube, label: "YouTube" },
              { key: "social_linkedin", icon: Linkedin, label: "LinkedIn" },
              { key: "social_facebook", icon: Facebook, label: "Facebook" },
            ].filter(s => settings[s.key]);
            if (socials.length === 0) return null;
            return (
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="mt-8 flex flex-col items-center gap-3"
              >
                <span className="text-sm text-primary-foreground/80">Follow us</span>
                <div className="flex items-center gap-3">
                  {socials.map(({ key, icon: Icon, label }) => (
                    <a
                      key={key}
                      href={settings[key]}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="h-10 w-10 rounded-full border border-primary-foreground/30 bg-primary-foreground/10 flex items-center justify-center text-primary-foreground hover:bg-primary-foreground/20 transition-colors"
                      aria-label={label}
                    >
                      {Icon ? (
                        <Icon className="h-5 w-5" />
                      ) : (
                        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.88-2.89 2.89 2.89 0 0 1 2.88-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.18 8.18 0 0 0 4.76 1.52V6.84a4.84 4.84 0 0 1-1-.15z"/></svg>
                      )}
                    </a>
                  ))}
                </div>
              </motion.div>
            );
          })()}
        </div>
      </motion.section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            {logoUrl ? (
              <img src={logoUrl} alt="Brimsom AI Logo" className="h-6 w-6 rounded object-contain" />
            ) : (
              <div className="h-6 w-6 rounded bg-primary flex items-center justify-center">
                <GraduationCap className="h-3.5 w-3.5 text-primary-foreground" />
              </div>
            )}
            <span className="font-semibold text-foreground">Brimsom</span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/about" className="hover:text-foreground transition-colors">About</Link>
            <Link to="/privacy" className="hover:text-foreground transition-colors">Privacy</Link>
            <Link to="/support" className="hover:text-foreground transition-colors">Support</Link>
            <span>© {new Date().getFullYear()} Brimsom</span>
          </div>
        </div>
      </footer>
      </div>
    </div>
  );
}
