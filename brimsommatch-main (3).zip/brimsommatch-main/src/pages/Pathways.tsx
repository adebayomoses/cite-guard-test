import AppLayout from "@/components/AppLayout";
import PRPathways from "@/components/dashboard/PRPathways";
import SEO from "@/components/SEO";

export default function Pathways() {
  return (
    <AppLayout>
      <SEO title="PR Pathways | Brimsom" description="Permanent residency and emigration pathways for 19 study-abroad destinations." path="/pathways" />
      <main className="container mx-auto px-4 py-12">
        <PRPathways />
      </main>
    </AppLayout>
  );
}
