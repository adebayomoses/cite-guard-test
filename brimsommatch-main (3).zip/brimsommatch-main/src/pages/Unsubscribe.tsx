import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle2, XCircle, MailX } from "lucide-react";
import SEO from "@/components/SEO";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export default function Unsubscribe() {
  const [params] = useSearchParams();
  const token = params.get("token");
  const [state, setState] = useState<"loading" | "valid" | "already" | "invalid" | "submitting" | "done" | "error">("loading");
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    if (!token) { setState("invalid"); return; }
    (async () => {
      try {
        const r = await fetch(`${SUPABASE_URL}/functions/v1/handle-email-unsubscribe?token=${encodeURIComponent(token)}`, { headers: { apikey: ANON_KEY } });
        const d = await r.json();
        if (d.email) setEmail(d.email);
        if (d.alreadyUnsubscribed || d.already_unsubscribed) setState("already");
        else if (r.ok && d.valid !== false) setState("valid");
        else setState("invalid");
      } catch { setState("invalid"); }
    })();
  }, [token]);

  const confirm = async () => {
    setState("submitting");
    try {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/handle-email-unsubscribe`, {
        method: "POST",
        headers: { "Content-Type": "application/json", apikey: ANON_KEY },
        body: JSON.stringify({ token }),
      });
      setState(r.ok ? "done" : "error");
    } catch { setState("error"); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <SEO title="Unsubscribe | Brimsom" description="Manage your Brimsom email preferences." />
      <Card className="max-w-md w-full">
        <CardContent className="py-10 text-center space-y-4">
          {state === "loading" && <><Loader2 className="h-10 w-10 animate-spin mx-auto text-muted-foreground" /><p className="text-sm text-muted-foreground">Validating link…</p></>}
          {state === "valid" && <>
            <MailX className="h-12 w-12 mx-auto text-primary" />
            <h1 className="text-xl font-semibold">Unsubscribe from Brimsom emails</h1>
            <p className="text-sm text-muted-foreground">{email ? `${email} will no longer receive emails from Brimsom.` : "You'll stop receiving emails from Brimsom."}</p>
            <Button onClick={confirm} className="w-full">Confirm Unsubscribe</Button>
          </>}
          {state === "submitting" && <><Loader2 className="h-10 w-10 animate-spin mx-auto text-muted-foreground" /><p className="text-sm text-muted-foreground">Unsubscribing…</p></>}
          {state === "done" && <>
            <CheckCircle2 className="h-12 w-12 mx-auto text-primary" />
            <h1 className="text-xl font-semibold">You've been unsubscribed</h1>
            <p className="text-sm text-muted-foreground">{email || "This address"} won't receive further emails from Brimsom.</p>
            <Button asChild variant="outline"><Link to="/">Back to Brimsom</Link></Button>
          </>}
          {state === "already" && <>
            <CheckCircle2 className="h-12 w-12 mx-auto text-primary" />
            <h1 className="text-xl font-semibold">Already unsubscribed</h1>
            <p className="text-sm text-muted-foreground">{email || "This address"} is already unsubscribed.</p>
            <Button asChild variant="outline"><Link to="/">Back to Brimsom</Link></Button>
          </>}
          {(state === "invalid" || state === "error") && <>
            <XCircle className="h-12 w-12 mx-auto text-destructive" />
            <h1 className="text-xl font-semibold">{state === "invalid" ? "Invalid link" : "Something went wrong"}</h1>
            <p className="text-sm text-muted-foreground">{state === "invalid" ? "This unsubscribe link is invalid or has expired." : "Please try again later."}</p>
            <Button asChild variant="outline"><Link to="/">Back to Brimsom</Link></Button>
          </>}
        </CardContent>
      </Card>
    </div>
  );
}
