import { Link } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import SEO from "@/components/SEO";

const NotFound = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEO title="Page Not Found | Brimsom" description="The page you're looking for doesn't exist. Head back to Brimsom to keep exploring scholarships." />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <nav className="border-b border-border bg-background/80 backdrop-blur-sm relative z-10">
        <div className="container mx-auto flex items-center h-16 px-4">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <GraduationCap className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold font-serif">Brimsom</span>
          </Link>
        </div>
      </nav>
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
          <p className="text-xl text-muted-foreground mb-8">
            This page doesn't exist.
          </p>
          <Button asChild>
            <Link to="/">Back to Home</Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
