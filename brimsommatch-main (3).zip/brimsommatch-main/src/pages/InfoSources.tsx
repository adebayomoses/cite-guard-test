import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, Globe, Loader2 } from "lucide-react";
import SEO from "@/components/SEO";

interface InfoSource {
  id: string;
  name: string;
  url: string;
}

export default function InfoSources() {
  const { data: sources = [], isLoading } = useQuery({
    queryKey: ["info-sources"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("info_sources" as any)
        .select("id, name, url")
        .eq("is_active", true)
        .order("sort_order");
      if (error) throw error;
      return data as unknown as InfoSource[];
    },
  });

  return (
    <AppLayout>
      <SEO title="Info Sources | Brimsom" description="Curated information sources for international students and scholarship applicants." path="/info-sources" />
      <main className="w-full mx-auto px-4 py-6 sm:py-8 max-w-3xl">
        <h1 className="text-xl sm:text-2xl font-bold mb-2 flex items-center gap-2">
          <BackButton iconOnly />
          Info Sources
        </h1>
        <p className="text-muted-foreground mb-6">Click on any source below to check for new scholarship updates.</p>

        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : sources.length === 0 ? (
          <p className="text-center text-muted-foreground py-16">No info sources available yet.</p>
        ) : (
          <div className="grid gap-3">
            {sources.map((s) => (
              <a key={s.id} href={s.url} target="_blank" rel="noopener noreferrer" className="block group w-full min-w-0">
                <Card className="transition-colors hover:border-primary/50 hover:bg-accent/50 overflow-hidden">
                  <CardContent className="flex items-center gap-3 p-4">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Globe className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{s.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{s.url}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary shrink-0 transition-colors" />
                  </CardContent>
                </Card>
              </a>
            ))}
          </div>
        )}
      </main>
    </AppLayout>
  );
}
