import { useState, useEffect } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { GraduationCap, Loader2, Lock, Mail, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import SEO from "@/components/SEO";
import { getAuthRedirectOrigin } from "@/lib/authRedirect";

export default function Auth() {
  const [searchParams] = useSearchParams();
  const [isSignUp, setIsSignUp] = useState(searchParams.get("tab") === "signup");
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showVerifyDialog, setShowVerifyDialog] = useState(false);
  const [verifyEmail, setVerifyEmail] = useState("");
  const [resending, setResending] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const { signIn, signUp, user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isConfirmed = searchParams.get("confirmed") === "true";
  const { settings, isLoading: settingsLoading } = useSiteSettings();
  const isAuthDisabled = settings.auth_enabled === "false" && searchParams.get("bypass") !== "true";

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);

  useEffect(() => {
    if (isConfirmed && user) {
      signOut().then(() => {
        toast({ title: "Email confirmed!", description: "Your account has been verified. Please log in." });
      });
      return;
    }
    if (!loading && user) navigate("/dashboard", { replace: true });
  }, [user, loading, navigate, isConfirmed]);

  const handleResendVerification = async () => {
    setResending(true);
    const { error } = await supabase.auth.resend({
      type: "signup",
      email: verifyEmail,
      options: {
        emailRedirectTo: `${getAuthRedirectOrigin()}/auth?confirmed=true`,
      },
    });
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Verification email resent", description: "Please check your inbox." });
      setCooldown(60);
    }
    setResending(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    if (isForgotPassword) {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${getAuthRedirectOrigin()}/reset-password`,
      });
      if (error) {
        toast({ title: "Error", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "Check your email", description: "We sent you a password reset link." });
      }
      setSubmitting(false);
      return;
    }

    if (isSignUp) {
      const { error } = await signUp(email, password, fullName);
      if (error) {
        // If user already exists / already registered, show verify dialog
        if (error.message?.toLowerCase().includes("already registered") || error.message?.toLowerCase().includes("already been registered")) {
          setVerifyEmail(email);
          setShowVerifyDialog(true);
        } else {
          toast({ title: "Sign up failed", description: error.message, variant: "destructive" });
        }
      } else {
        setVerifyEmail(email);
        setShowVerifyDialog(true);
      }
    } else {
      const { error } = await signIn(email, password);
      if (error) {
        // If email not confirmed
        if (error.message?.toLowerCase().includes("email not confirmed")) {
          setVerifyEmail(email);
          setShowVerifyDialog(true);
        } else {
          toast({ title: "Login failed", description: error.message, variant: "destructive" });
        }
      }
    }
    setSubmitting(false);
  };

  if (loading || settingsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (isAuthDisabled) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
        <div className="w-full max-w-md relative z-10">
        <Link to="/" className="flex items-center justify-center gap-2 mb-8">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt="Logo" className="h-10 w-10 rounded-lg object-contain" />
            ) : (
              <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
            )}
            <span className="text-2xl font-bold font-serif">Brimsom</span>
          </Link>
          <Card className="text-center py-6 border-muted shadow-sm">
            <CardHeader>
              <div className="mx-auto bg-muted p-3 rounded-full w-fit mb-4">
                <Lock className="h-6 w-6 text-muted-foreground" />
              </div>
              <CardTitle className="text-2xl">Coming Soon</CardTitle>
              <CardDescription className="text-base mt-2">
                The platform is currently not accepting new users or logins. We're getting things ready behind the scenes!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full">
                <Link to="/">Return to Home</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <SEO title="Log in or Sign up | Brimsom" description="Create your Brimsom account or sign in to access AI-powered scholarship matching." path="/auth" />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="w-full max-w-md relative z-10">
        <Link to="/" className="flex items-center justify-center gap-2 mb-8">
          {settings.logo_url ? (
            <img src={settings.logo_url} alt="Logo" className="h-10 w-10 rounded-lg object-contain" />
          ) : (
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <GraduationCap className="h-6 w-6 text-primary-foreground" />
            </div>
          )}
          <span className="text-2xl font-bold font-serif">Brimsom</span>
        </Link>

        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">
              {isForgotPassword ? "Reset your password" : isSignUp ? "Create your account" : "Welcome back"}
            </CardTitle>
            <CardDescription>
              {isForgotPassword
                ? "Enter your email and we'll send you a reset link"
                : isSignUp
                  ? "Start discovering scholarships matched to you"
                  : "Log in to your Brimsom account"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && !isForgotPassword && (
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Your full name" required />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
              </div>
              {!isForgotPassword && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Password</Label>
                  </div>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required minLength={6} />
                  {!isSignUp && (
                    <button
                      type="button"
                      onClick={() => setIsForgotPassword(true)}
                      className="text-sm text-primary hover:underline mt-1"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
              )}
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isForgotPassword ? "Send Reset Link" : isSignUp ? "Sign Up" : "Log In"}
              </Button>
            </form>
            {!isForgotPassword && (settings.google_signin_enabled !== "false" || settings.apple_signin_enabled !== "false") && (
              <>
                <div className="relative my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-muted" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                  </div>
                </div>
                <div className="space-y-2">
                  {settings.google_signin_enabled !== "false" && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full gap-2"
                    onClick={async () => {
                      const { error } = await lovable.auth.signInWithOAuth("google", {
                        redirect_uri: window.location.origin,
                      });
                      if (error) {
                        toast({ title: "Google sign-in failed", description: String(error.message || error), variant: "destructive" });
                      }
                    }}
                  >
                    <svg className="h-4 w-4" viewBox="0 0 24 24">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    Continue with Google
                  </Button>
                  )}
                  {settings.apple_signin_enabled !== "false" && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full gap-2"
                    onClick={async () => {
                      const { error } = await lovable.auth.signInWithOAuth("apple", {
                        redirect_uri: window.location.origin,
                      });
                      if (error) {
                        toast({ title: "Apple sign-in failed", description: String(error.message || error), variant: "destructive" });
                      }
                    }}
                  >
                    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.05 20.28c-.98.95-2.05.86-3.08.45-1.09-.42-2.09-.46-3.24 0-1.44.58-2.2.41-3.06-.45C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                    </svg>
                    Continue with Apple
                  </Button>
                  )}
                </div>
              </>
            )}
            <div className="mt-6 text-center text-sm text-muted-foreground">
              {isForgotPassword ? (
                <button onClick={() => setIsForgotPassword(false)} className="text-primary font-medium hover:underline">
                  Back to login
                </button>
              ) : (
                <>
                  {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                  <button onClick={() => setIsSignUp(!isSignUp)} className="text-primary font-medium hover:underline">
                    {isSignUp ? "Log in" : "Sign up"}
                  </button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showVerifyDialog} onOpenChange={setShowVerifyDialog}>
        <DialogContent className="text-center">
          <DialogHeader className="items-center">
            <div className="mx-auto bg-primary/10 p-4 rounded-full w-fit mb-2">
              <Mail className="h-8 w-8 text-primary" />
            </div>
            <DialogTitle className="text-xl">Verify your email</DialogTitle>
            <DialogDescription className="text-base mt-2">
              We've sent a verification link to{" "}
              <span className="font-semibold text-foreground">{verifyEmail}</span>.
              <br />
              Please check your inbox (and spam folder) and click the link to activate your account.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 mt-4">
            <Button
              variant="outline"
              className="w-full gap-2"
              onClick={handleResendVerification}
              disabled={resending || cooldown > 0}
            >
              {resending ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend verification email"}
            </Button>
            <Button
              className="w-full"
              onClick={() => setShowVerifyDialog(false)}
            >
              Got it
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
