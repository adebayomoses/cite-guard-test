import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Bot, Send, User, Copy, Share2, Check, PenLine } from "lucide-react";
import MarkdownContent from "@/components/MarkdownContent";
import BrimQuestionCard, { extractBrimQuestion } from "@/components/brim/BrimQuestionCard";
import EssayBlock, { parseEssaySegments } from "@/components/brim/EssayBlock";
import { toast } from "sonner";
import { useFeatureAccess, useTrackUsage } from "@/hooks/useFeatureAccess";
import UpgradeBanner from "@/components/UpgradeBanner";
import { supabase } from "@/integrations/supabase/client";
import SEO from "@/components/SEO";


type Msg = { role: "user" | "assistant"; content: string };

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/brim-chat`;

export default function BrimChat() {
  const location = useLocation();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scholarshipHandled = useRef(false);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    const cap = Math.round(window.innerHeight * 0.6);
    el.style.height = `${Math.min(el.scrollHeight, cap)}px`;
  }, [input]);

  const { canUse, remaining, limit, period, usage, plan, isLoading: accessLoading } = useFeatureAccess("brim_chat");
  const trackUsage = useTrackUsage();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleCopy = async (text: string, idx: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIdx(idx);
      toast.success("Copied to clipboard");
      setTimeout(() => setCopiedIdx((c) => (c === idx ? null : c)), 2000);
    } catch {
      toast.error("Failed to copy");
    }
  };

  const handleShare = async (text: string) => {
    const shareData = {
      title: "Brim Chat",
      text: `${text}\n\n— via Brim Chat (https://brimsom.com)`,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.text);
        toast.success("Copied — share it anywhere!");
      }
    } catch (e: any) {
      if (e?.name !== "AbortError") toast.error("Failed to share");
    }
  };

  const sendMessages = useCallback(async (allMessages: Msg[]) => {
    setIsLoading(true);
    let assistantSoFar = "";

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const accessToken = sessionData.session?.access_token ?? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ messages: allMessages }),
      });


      if (resp.status === 429) { toast.error("Rate limit reached. Please wait a moment and try again."); return; }
      if (resp.status === 402) { toast.error("AI credits exhausted. Please try again later."); return; }
      if (!resp.ok || !resp.body) throw new Error("Failed to start stream");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";

      const upsert = (chunk: string) => {
        assistantSoFar += chunk;
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant") {
            return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: assistantSoFar } : m));
          }
          return [...prev, { role: "assistant", content: assistantSoFar }];
        });
      };

      let streamDone = false;
      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });

        let idx: number;
        while ((idx = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, idx);
          textBuffer = textBuffer.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") { streamDone = true; break; }
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) upsert(content);
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }
    } catch (e) {
      console.error(e);
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Handle scholarship context from navigation state
  useEffect(() => {
    const scholarship = (location.state as any)?.scholarship;
    if (scholarship && !scholarshipHandled.current) {
      scholarshipHandled.current = true;
      navigate(location.pathname, { replace: true, state: {} });

      const parts = [`I have a question about the **${scholarship.title}** scholarship`];
      if (scholarship.provider) parts[0] += ` by ${scholarship.provider}`;
      parts[0] += ".";
      const details: string[] = [];
      if (scholarship.country) details.push(`Country: ${scholarship.country}`);
      if (scholarship.degree_level) details.push(`Degree: ${scholarship.degree_level}`);
      if (scholarship.funding_amount) details.push(`Funding: ${scholarship.funding_amount}`);
      if (scholarship.deadline || scholarship.next_close_date) details.push(`Deadline: ${scholarship.deadline ?? scholarship.next_close_date}`);
      if (details.length) parts.push(details.join(" | "));
      if (scholarship.description) parts.push(scholarship.description.slice(0, 500));

      const userMsg: Msg = { role: "user", content: parts.join("\n\n") };
      setMessages([userMsg]);
      trackUsage.mutate("brim_chat");
      sendMessages([userMsg]);
    }
  }, [location.state, navigate, sendMessages, trackUsage]);

  const send = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || isLoading) return;

    if (!canUse) {
      toast.error("Usage limit reached — upgrade to continue");
      return;
    }

    if (!overrideText) setInput("");
    const userMsg: Msg = { role: "user", content: text };
    const allMessages = [...messages, userMsg];
    setMessages(allMessages);
    trackUsage.mutate("brim_chat");
    await sendMessages(allMessages);
  };

  const startPersonalStatement = () => {
    if (isLoading) return;
    if (!canUse) { toast.error("Usage limit reached — upgrade to continue"); return; }
    // Start a fresh chat focused on personal statement / SOP writing
    setMessages([]);
    setInput("");
    setTimeout(() => {
      send("I want to write my personal statement / Statement of Purpose. Please guide me step by step, asking one question at a time about my background, target university, professor/lab, key project, research interest, and career goals before drafting.");
    }, 0);
  };

  const SUGGESTED_PROMPTS = [
    "Match me to scholarships that fit my profile",
    "What documents do I need for a study visa?",
    "Tips to improve my scholarship application",
    "How do I request a recommendation letter?",
  ];

  const remainingLabel = limit === Infinity
    ? ""
    : `${remaining} message${remaining !== 1 ? "s" : ""} remaining ${period === "day" ? "today" : period === "month" ? "this month" : ""}`;

  return (
    <AppLayout className="flex h-dvh flex-col overflow-hidden">
      <SEO title="Brim Chat | Brimsom" description="Talk with Brim, Brimsom's AI scholarship assistant." path="/brim-chat" />
      <main className="flex flex-1 min-h-0 w-full max-w-3xl flex-col overflow-hidden px-2 sm:px-4 py-6 mx-auto pb-[calc(1rem+env(safe-area-inset-bottom,0px))]">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">Brim Chat</h1>
            <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-gradient-to-r from-primary/15 to-primary/5 text-primary border border-primary/20 tracking-wide">
              Brim V1
            </span>
          </div>
          {!accessLoading && limit !== Infinity && (
            <span className={`text-xs px-2 py-1 rounded-full ${remaining <= 2 ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"}`}>
              {remainingLabel}
            </span>
          )}
        </div>
        <p className="text-muted-foreground text-sm mb-4">AI-powered scholarship &amp; study abroad advisor</p>

        <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain space-y-4 mb-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <Bot className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground text-sm max-w-md mb-6">
                Ask me anything about scholarships, study abroad applications, SOPs, visa processes, or application strategy.
              </p>

              <button
                type="button"
                onClick={startPersonalStatement}
                disabled={isLoading}
                className="group w-full max-w-md mb-6 rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-4 text-left transition-all hover:border-primary/40 hover:shadow-md disabled:opacity-50"
              >
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
                    <PenLine className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-sm">Personal Statement Writer</h3>
                      <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-primary/15 text-primary border border-primary/20">New</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Start a guided chat to craft your SOP or personal statement — one question at a time.
                    </p>
                  </div>
                </div>
              </button>

              <div className="flex flex-wrap gap-2 justify-center max-w-xl">
                {SUGGESTED_PROMPTS.map((prompt) => (
                  <button
                    key={prompt}
                    type="button"
                    onClick={() => send(prompt)}
                    disabled={isLoading}
                    className="text-xs px-3 py-2 rounded-full bg-muted hover:bg-muted/70 text-foreground border border-border transition-colors disabled:opacity-50"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""}`}>
              {msg.role === "assistant" && (
                <div className="hidden sm:flex h-8 w-8 rounded-full bg-primary/10 items-center justify-center shrink-0 mt-1">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
              )}
              <div className={`${msg.role === "user" ? "max-w-[85%] sm:max-w-[75%] md:max-w-[70%]" : "flex-1 sm:max-w-[85%] md:max-w-[80%]"} flex flex-col ${msg.role === "user" ? "items-end" : "items-start"}`}>

                {msg.role === "assistant" ? (() => {
                  const { text, question } = extractBrimQuestion(msg.content);
                  const isLast = i === messages.length - 1;
                  const segments = parseEssaySegments(text);
                  return (
                    <>
                      {segments.map((seg, sIdx) =>
                        seg.type === "essay" ? (
                          <div key={`e-${sIdx}`} className="w-full">
                            <EssayBlock content={seg.content} streaming={seg.streaming && isLast && isLoading} />
                          </div>
                        ) : (
                          <div key={`t-${sIdx}`} className="rounded-xl px-4 py-3 bg-muted mt-1 first:mt-0 text-sm">
                            <MarkdownContent content={seg.content} />
                          </div>
                        )
                      )}
                      {question && (
                        <div className="w-full mt-2">
                          <BrimQuestionCard
                            data={question}
                            disabled={isLoading || !isLast}
                            onAnswer={(ans) => {
                              const norm = ans.trim().toLowerCase();
                              if (norm === "fill my profile" || norm === "fill profile" || norm.startsWith("fill my profile")) {
                                navigate("/profile-builder");
                                return;
                              }
                              send(ans);
                            }}
                          />
                        </div>
                      )}
                    </>
                  );
                })() : (
                  <div className="rounded-xl px-4 py-3 bg-primary text-primary-foreground">
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  </div>
                )}
                {msg.role === "assistant" && msg.content && !(isLoading && i === messages.length - 1) && (
                  <div className="flex gap-1 mt-1.5 px-1">
                    <button
                      type="button"
                      onClick={() => handleCopy(msg.content, i)}
                      className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted"
                      aria-label="Copy message"
                    >
                      {copiedIdx === i ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                      <span>{copiedIdx === i ? "Copied" : "Copy"}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleShare(msg.content)}
                      className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-muted"
                      aria-label="Share message"
                    >
                      <Share2 className="h-3 w-3" />
                      <span>Share</span>
                    </button>
                  </div>
                )}
              </div>

              {msg.role === "user" && (
                <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-1">
                  <User className="h-4 w-4 text-primary-foreground" />
                </div>
              )}
            </div>
          ))}
          {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex gap-3">
              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <div className="bg-muted rounded-xl px-4 py-3">
                <span className="text-sm text-muted-foreground animate-pulse">Thinking...</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {!accessLoading && !canUse && (
          <div className="shrink-0 pb-3">
            <UpgradeBanner
              feature="brim_chat"
              currentPlan={plan}
              usage={usage}
              limit={limit === Infinity ? 999 : limit}
              period={period}
            />
          </div>
        )}

        <form
          onSubmit={(e) => { e.preventDefault(); send(); }}
          className="shrink-0 flex gap-2 items-end border-t border-border pt-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80"
        >
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder={canUse ? "Ask about scholarships, study abroad, SOPs..." : "Usage limit reached — upgrade to continue"}
            disabled={isLoading}
            rows={1}
            className="flex-1 min-h-[44px] max-h-[60vh] resize-none overflow-y-auto py-2.5 leading-6"
            ref={textareaRef}
          />
          <Button type="submit" size="icon" disabled={isLoading || !input.trim() || !canUse}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </main>

    </AppLayout>
  );
}
