import AppLayout from "@/components/AppLayout";
import BackButton from "@/components/BackButton";
import { useSavedScholarships } from "@/hooks/useSavedScholarships";
import { Bookmark, Search, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import SEO from "@/components/SEO";

export default function Saved() {
  const { savedScholarships, loading } = useSavedScholarships();

  return (
    <AppLayout>
      <SEO title="Saved Scholarships | Brimsom" description="All the scholarships you've bookmarked, in one place." path="/saved" />
      <main className="container mx-auto px-4 py-6 sm:py-12 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h1 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
            <BackButton iconOnly />
            <Bookmark className="h-5 w-5 sm:h-6 sm:w-6 text-primary" /> Saved Scholarships
          </h1>
          <Button variant="outline" size="sm" asChild>
            <Link to="/scholarships">
              <Search className="h-3.5 w-3.5 mr-1.5" /> Browse All
            </Link>
          </Button>
        </div>

        {loading ? (
          <p className="text-muted-foreground">Loading...</p>
        ) : savedScholarships.length === 0 ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <Bookmark className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">
              No saved scholarships yet.{" "}
              <Link to="/scholarships" className="text-primary underline">
                Browse scholarships
              </Link>{" "}
              to save some.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {savedScholarships.map((s: any) => (
              <div key={s.id} className="rounded-xl border border-border bg-card p-4 sm:p-5 space-y-2 min-w-0">
                <h3 className="font-semibold line-clamp-2">{s.title}</h3>
                {s.provider && <p className="text-sm text-muted-foreground truncate">{s.provider}</p>}
                {s.funding_amount && <p className="text-sm text-primary font-medium">{s.funding_amount}</p>}
                {s.next_close_date && (
                  <p className="text-xs text-muted-foreground">
                    Deadline: {new Date(s.next_close_date).toLocaleDateString()}
                  </p>
                )}
                {s.url && (
                  <Button size="sm" className="w-full mt-1" asChild>
                    <a href={s.url} target="_blank" rel="noopener noreferrer">
                      Apply Now <ExternalLink className="h-3.5 w-3.5 ml-1" />
                    </a>
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </AppLayout>
  );
}
