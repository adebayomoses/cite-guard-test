import { useEffect, useState, useMemo } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { Trophy, MapPin, GraduationCap, DollarSign, Calendar, BookOpen, Award, Sparkles, Lightbulb, Star, Crown } from "lucide-react";
import MarkdownContent from "@/components/MarkdownContent";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import SEO from "@/components/SEO";

type WinnerVariant = {
  id: string;
  filter: string;
  bg: string;
  trophyIcon: typeof Trophy;
  trophyAnim: { initial: any; animate: any; transition: any };
  confettiColors: string[];
  decorIcon: typeof Sparkles;
};

const WINNER_VARIANTS: WinnerVariant[] = [
  {
    id: "gold",
    filter: "none",
    bg: "linear-gradient(160deg, hsl(220 25% 6%) 0%, hsl(30 30% 8%) 50%, hsl(220 20% 7%) 100%)",
    trophyIcon: Trophy,
    trophyAnim: {
      initial: { opacity: 0, scale: 0.3, rotate: -15 },
      animate: { opacity: 1, scale: 1, rotate: 0 },
      transition: { type: "spring", stiffness: 200, damping: 15, delay: 0.2 },
    },
    confettiColors: ["hsl(45 100% 60%)", "hsl(160 60% 45%)", "hsl(0 80% 60%)", "hsl(220 70% 55%)", "hsl(280 60% 55%)", "hsl(35 90% 55%)"],
    decorIcon: Sparkles,
  },
  {
    id: "emerald",
    filter: "hue-rotate(110deg) saturate(0.95)",
    bg: "radial-gradient(circle at 20% 10%, hsl(160 40% 10%) 0%, hsl(180 30% 6%) 60%, hsl(220 25% 5%) 100%)",
    trophyIcon: Crown,
    trophyAnim: {
      initial: { opacity: 0, y: 60, scale: 0.6 },
      animate: { opacity: 1, y: 0, scale: 1 },
      transition: { type: "spring", stiffness: 140, damping: 18, delay: 0.2 },
    },
    confettiColors: ["hsl(160 70% 55%)", "hsl(180 65% 55%)", "hsl(140 60% 50%)", "hsl(200 60% 55%)", "hsl(45 90% 60%)", "hsl(170 60% 45%)"],
    decorIcon: Star,
  },
  {
    id: "royal",
    filter: "hue-rotate(220deg) saturate(1.05)",
    bg: "linear-gradient(135deg, hsl(260 35% 8%) 0%, hsl(290 30% 9%) 50%, hsl(230 30% 7%) 100%)",
    trophyIcon: Star,
    trophyAnim: {
      initial: { opacity: 0, scale: 0, rotate: 180 },
      animate: { opacity: 1, scale: [0, 1.15, 1], rotate: 0 },
      transition: { duration: 0.9, delay: 0.2, ease: "easeOut" },
    },
    confettiColors: ["hsl(280 80% 65%)", "hsl(310 75% 60%)", "hsl(250 70% 65%)", "hsl(200 70% 60%)", "hsl(45 90% 60%)", "hsl(330 70% 60%)"],
    decorIcon: Sparkles,
  },
];

interface Scholarship {
  id: string;
  title: string;
  provider: string | null;
  country: string | null;
  degree_level: string | null;
  funding_amount: string | null;
  funding_type: string | null;
  next_close_date: string | null;
  field_of_study: string | null;
  eligibility_criteria: string | null;
  description: string | null;
}

export default function ScholarshipWinner() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const [scholarship, setScholarship] = useState<Scholarship | null>(null);
  const [allScholarships, setAllScholarships] = useState<Scholarship[]>([]);
  const [selectedId, setSelectedId] = useState(id || "");
  const [showConfetti, setShowConfetti] = useState(false);
  const [matchData, setMatchData] = useState<{ score: number; chance: number; reason: string; chance_reason: string } | null>(null);
  const variant = useMemo(() => WINNER_VARIANTS[Math.floor(Math.random() * WINNER_VARIANTS.length)], []);
  const TrophyIcon = variant.trophyIcon;
  const DecorIcon = variant.decorIcon;

  // Fetch score data for current user
  useEffect(() => {
    if (!user) return;
    supabase
      .from("score_results")
      .select("scholarship_matches")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .then(({ data }) => {
        if (data?.[0]?.scholarship_matches) {
          const matches = data[0].scholarship_matches as unknown as Array<{ scholarship_id: string; score: number; chance: number; reason: string; chance_reason?: string }>;
          const currentId = selectedId || id;
          const found = matches.find((m) => m.scholarship_id === currentId);
          setMatchData(found ? { score: found.score, chance: found.chance, reason: found.reason, chance_reason: found.chance_reason ?? "" } : null);
        }
      });
  }, [user, selectedId, id]);

  useEffect(() => {
    supabase
      .from("scholarships")
      .select("id, title, provider, country, degree_level, funding_amount, funding_type, next_close_date, field_of_study, eligibility_criteria, description")
      .eq("is_active", true)
      .order("title")
      .then(({ data }) => {
        if (data) setAllScholarships(data);
      });
  }, []);

  useEffect(() => {
    const fetchId = selectedId || id;
    if (!fetchId) return;
    supabase
      .from("scholarships")
      .select("id, title, provider, country, degree_level, funding_amount, funding_type, next_close_date, field_of_study, eligibility_criteria, description")
      .eq("id", fetchId)
      .single()
      .then(({ data }) => {
        if (data) {
          setScholarship(data);
          setShowConfetti(false);
          setTimeout(() => setShowConfetti(true), 100);
        }
      });
  }, [selectedId, id]);

  const detailItems = scholarship
    ? [
        { icon: Award, label: "Provider", value: scholarship.provider },
        { icon: DollarSign, label: "Funding", value: scholarship.funding_amount },
        { icon: MapPin, label: "Country", value: scholarship.country },
        { icon: GraduationCap, label: "Degree", value: scholarship.degree_level },
        { icon: BookOpen, label: "Field", value: scholarship.field_of_study },
        { icon: Calendar, label: "Deadline", value: scholarship.next_close_date },
      ].filter((d) => d.value)
    : [];

  return (
    <div
      className="relative min-h-screen overflow-hidden flex flex-col items-center px-4 pt-20 pb-8 winner-bg"
      style={{ background: variant.bg, filter: variant.filter }}
      data-variant={variant.id}
    >
      <SEO title="Scholarship Winner | Brimsom" description="Celebrating a Brimsom scholarship winner." />
      {/* Brimsom AI header (top bar) */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="absolute top-0 inset-x-0 z-30 flex items-center justify-center gap-2 px-4 py-3 bg-black/30 border-b border-amber-400/30 backdrop-blur-md"
      >
        <Sparkles className="h-4 w-4 text-amber-300" />
        <span className="text-sm font-semibold tracking-wide text-amber-100">
          Powered by <span className="text-amber-300">Brimsom AI</span>
        </span>
      </motion.header>

      <div className="flex-1 flex flex-col items-center justify-center w-full">

      {/* Confetti */}
      {showConfetti && (
        <div className="pointer-events-none fixed inset-0 z-50">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="confetti-piece"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2.5 + Math.random() * 2}s`,
                backgroundColor: variant.confettiColors[i % variant.confettiColors.length],
              }}
            />
          ))}
        </div>
      )}

      {/* Selector (top, subtle) */}
      {!id && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm mb-8 z-10"
        >
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="bg-background/10 border-amber-500/30 text-foreground backdrop-blur-sm">
              <SelectValue placeholder="Select a scholarship to celebrate" />
            </SelectTrigger>
            <SelectContent>
              {allScholarships.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>
      )}

      {scholarship ? (
        <div className="flex flex-col items-center w-full max-w-lg z-10">
          {/* Sparkles */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-2"
          >
            <DecorIcon className="h-6 w-6 text-amber-400 animate-pulse" />
          </motion.div>

          {/* Trophy */}
          <motion.div
            initial={variant.trophyAnim.initial}
            animate={variant.trophyAnim.animate}
            transition={variant.trophyAnim.transition}
            className="relative mb-4"
          >
            <div className="trophy-glow rounded-full p-6">
              <TrophyIcon className="h-20 w-20 text-amber-400 drop-shadow-lg" strokeWidth={1.5} />
            </div>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-3xl sm:text-4xl font-bold text-center mb-2 winner-gradient-text"
          >
            Scholarship Matched!
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-amber-300/70 text-sm mb-6"
          >
            Congratulations to the recipient 🎉
          </motion.p>

          {/* Scholarship Title */}
          <motion.h2
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.5 }}
            className="text-xl sm:text-2xl font-semibold text-center mb-6 text-amber-100"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            {scholarship.title}
          </motion.h2>

          {/* Card */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 1.1, duration: 0.6 }}
            className="w-full rounded-2xl border border-amber-500/20 bg-gradient-to-b from-amber-950/40 to-amber-950/20 backdrop-blur-md p-6 shadow-2xl"
          >
            {/* Details Grid */}
            <div className="grid grid-cols-2 gap-4 mb-5">
              {detailItems.map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1.3 + i * 0.1 }}
                  className="flex items-start gap-2"
                >
                  <item.icon className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-amber-400/60">{item.label}</p>
                    <p className="text-sm text-amber-100/90 font-medium">{item.value}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Funding Type */}
            {scholarship.funding_type && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.9 }}
                className="inline-block mb-4 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30"
              >
                {scholarship.funding_type}
              </motion.div>
            )}

            {/* Score Summary Card */}
            {matchData && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.95 }}
                className="mb-4 rounded-xl border border-amber-500/20 bg-amber-950/30 p-4 space-y-3"
              >
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-amber-400" />
                  <h4 className="text-sm font-semibold text-amber-200">Scholarship Score Summary</h4>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-amber-950/40 border border-amber-500/15 p-3 text-center space-y-1.5">
                    <p className="text-[10px] uppercase tracking-wider text-amber-400/60 font-medium">Scholarship Match Score</p>
                    <div className={`text-2xl font-bold ${matchData.score >= 70 ? "text-amber-300" : matchData.score >= 40 ? "text-amber-400/70" : "text-amber-500/50"}`}>
                      {matchData.score}%
                    </div>
                    <p className="text-[10px] text-amber-300/50 leading-tight">
                      {matchData.score >= 70 ? "Strong match for your profile" : matchData.score >= 40 ? "Moderate match" : "Low match"}
                    </p>
                  </div>
                  <div className="rounded-lg bg-amber-950/40 border border-amber-500/15 p-3 text-center space-y-1.5">
                    <p className="text-[10px] uppercase tracking-wider text-amber-400/60 font-medium">Scholarship Chance of Winning</p>
                    <div className={`text-2xl font-bold ${matchData.chance >= 70 ? "text-amber-300" : matchData.chance >= 40 ? "text-amber-400/70" : "text-amber-500/50"}`}>
                      {matchData.chance}%
                    </div>
                    <p className="text-[10px] text-amber-300/50 leading-tight">
                      {matchData.chance >= 70 ? "High likelihood of success" : matchData.chance >= 40 ? "Moderate chances" : "Competitive"}
                    </p>
                  </div>
                </div>

                {(matchData.reason || matchData.chance_reason) && (
                  <div className="flex gap-2 rounded-lg bg-amber-950/40 border border-amber-500/15 p-3">
                    <Lightbulb className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                    <div className="space-y-1.5">
                      <p className="text-[10px] uppercase tracking-wider text-amber-400/60 font-medium mb-1">Why this scholarship</p>
                      {matchData.reason && <p className="text-xs text-amber-100/70 leading-relaxed">{matchData.reason}</p>}
                      {matchData.chance_reason && <p className="text-xs text-amber-100/70 leading-relaxed">{matchData.chance_reason}</p>}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Eligibility */}
            {scholarship.eligibility_criteria && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.0 }}
                className="mb-4"
              >
                <p className="text-[10px] uppercase tracking-wider text-amber-400/60 mb-1">Eligibility</p>
                <div className="text-sm leading-relaxed [&_.prose]:text-amber-100/80 [&_.prose_h1]:text-amber-200 [&_.prose_h2]:text-amber-200 [&_.prose_h3]:text-amber-200 [&_.prose_strong]:text-amber-200 [&_.prose_li]:text-amber-100/80 [&_.prose_p]:text-amber-100/80">
                  <MarkdownContent content={scholarship.eligibility_criteria} className="!text-amber-100/80 prose-headings:!text-amber-200 prose-p:!text-amber-100/80 prose-li:!text-amber-100/80 prose-strong:!text-amber-200" />
                </div>
              </motion.div>
            )}

            {/* Description */}
            {scholarship.description && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.1 }}
              >
                <p className="text-[10px] uppercase tracking-wider text-amber-400/60 mb-1">About</p>
                <div className="text-sm leading-relaxed">
                  <MarkdownContent content={scholarship.description} className="!text-amber-100/70 prose-headings:!text-amber-200 prose-p:!text-amber-100/70 prose-li:!text-amber-100/70 prose-strong:!text-amber-200" />
                </div>
              </motion.div>
            )}
          </motion.div>

          {/* Branding */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.4 }}
            className="mt-8 flex items-center gap-2"
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg">
              <Trophy className="h-4 w-4 text-background" />
            </div>
            <span className="text-lg font-bold text-amber-200/80" style={{ fontFamily: "'Fraunces', serif" }}>
              Brimsom AI
            </span>
          </motion.div>
        </div>
      ) : (
        !selectedId && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-amber-300/60 z-10"
          >
            Select a scholarship above to generate a celebration card
          </motion.p>
        )
      )}
      </div>
    </div>
  );
}
