import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { useChanceScore } from "@/hooks/useChanceScore";
import { useActivityLog } from "@/hooks/useActivityLog";
import { useProfileData } from "@/hooks/useProfileData";
import { useFeatureAccess, useTrackUsage } from "@/hooks/useFeatureAccess";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Lightbulb, ArrowLeft, UserCircle } from "lucide-react";
import { Link } from "react-router-dom";
import ScoreCard from "@/components/dashboard/ScoreCard";
import MatchedScholarships from "@/components/dashboard/MatchedScholarships";
import UpgradeBanner from "@/components/UpgradeBanner";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import SEO from "@/components/SEO";

export default function Score() {
  const profile = useProfileData();
  const completeness = profile.getCompleteness();
  const { score, loading, generating, generate } = useChanceScore();
  const { logActivity } = useActivityLog();
  const { canUse, remaining, limit, usage, plan, period, isLoading } = useFeatureAccess("score_generation");
  const trackUsage = useTrackUsage();
  const [showProfilePrompt, setShowProfilePrompt] = useState(false);

  const handleGenerate = async () => {
    if (completeness < 50) {
      setShowProfilePrompt(true);
      return;
    }
    if (!canUse) {
      toast.error("Usage limit reached — upgrade to continue");
      return;
    }
    await generate(logActivity);
    trackUsage.mutate("score_generation");
  };

  const remainingLabel = limit === Infinity ? "Unlimited" : `${remaining}/${limit} left this month`;

  return (
    <AppLayout>
      <SEO title="Chance Score | Brimsom" description="Generate your AI Scholarship Readiness Score and personalized improvement tips." path="/score" />
      <main className="container mx-auto px-4 py-12 space-y-8 max-w-3xl">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" asChild>
              <Link to="/dashboard"><ArrowLeft className="h-4 w-4" /></Link>
            </Button>
            <h1 className="text-2xl font-bold">Win Chance Score</h1>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="text-xs">
              {remainingLabel}
            </Badge>
            <Button onClick={handleGenerate} disabled={generating || isLoading}>
              <Sparkles className="h-4 w-4 mr-2" />
              {generating ? "Generating..." : score ? "Refresh Score" : "Generate Score"}
            </Button>
          </div>
        </div>

        {!isLoading && !canUse && (
          <UpgradeBanner
            feature="score_generation"
            currentPlan={plan}
            usage={usage}
            limit={limit === Infinity ? 999 : limit}
            period={period}
          />
        )}

        {score ? (
          <>
            <ScoreCard score={score.readiness_score} summary={score.readiness_summary} />

            {score.tips && score.tips.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-6">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-primary" /> Tips to Improve
                </h3>
                <ul className="space-y-2">
                  {score.tips.map((tip, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary font-medium shrink-0">{i + 1}.</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {score.scholarship_matches && score.scholarship_matches.length > 0 && (
              <MatchedScholarships matches={score.scholarship_matches} />
            )}
          </>
        ) : (
          <div className="rounded-xl border border-border bg-card p-6 text-center py-12">
            <div className="text-4xl font-bold text-muted-foreground mb-2">—</div>
            <p className="text-muted-foreground">
              Click "Generate Score" to get your personalized win chance score.
            </p>
          </div>
        )}
      </main>


      <Dialog open={showProfilePrompt} onOpenChange={setShowProfilePrompt}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <UserCircle className="h-6 w-6 text-primary" />
            </div>
            <DialogTitle className="text-center">Complete Your Profile First</DialogTitle>
            <DialogDescription className="text-center">
              Your profile is currently <strong>{completeness}%</strong> complete. You need at least 50% completion to generate match and win chance scores.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Progress value={completeness} className="h-2" />
            <p className="text-xs text-muted-foreground text-center">
              A more complete profile means more accurate results.
            </p>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setShowProfilePrompt(false)} className="w-full sm:w-auto">
              Close
            </Button>
            <Button asChild className="w-full sm:w-auto">
              <Link to="/profile">Go to Profile</Link>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
