import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { GraduationCap, ArrowRight, Calendar, Menu, MessageSquareQuote, Star, Quote, Share2, Copy, Check } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import AppLayout from "@/components/AppLayout";
import SubmitTestimonialDialog from "@/components/SubmitTestimonialDialog";
import BackButton from "@/components/BackButton";
import SEO from "@/components/SEO";

export default function Blog() {
  const { user } = useAuth();
  const { settings } = useSiteSettings();
  const logoUrl = settings.logo_url;
  const [mobileOpen, setMobileOpen] = useState(false);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["blog-posts-public"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("blog_posts")
        .select("id, title, slug, excerpt, thumbnail_url, published_at")
        .eq("is_published", true)
        .order("published_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: testimonials = [] } = useQuery({
    queryKey: ["public-testimonials"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("testimonials")
        .select("id, name, message, rating, image_url, created_at, published_at")
        .eq("is_approved", true)
        .order("published_at", { ascending: false, nullsFirst: false })
        .limit(12);
      if (error) throw error;
      return data as { id: string; name: string; message: string; rating: number | null; image_url: string | null; created_at: string; published_at: string | null }[];
    },
  });

  const blogContent = (
    <main className="relative z-10 container mx-auto px-4 py-6 md:py-10">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-12">
          <div>
            <h1 className="text-xl sm:text-4xl font-bold mb-2 flex items-center gap-2">
              <BackButton iconOnly />
              Blog
            </h1>
            <p className="text-muted-foreground">Tips, guides, and scholarship insights.</p>
          </div>
          <SubmitTestimonialDialog
            trigger={
              <Button className="gap-2 shrink-0">
                <MessageSquareQuote className="h-4 w-4" />
                Submit Testimonial
              </Button>
            }
          />
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="rounded-xl border border-border overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <div className="p-5 space-y-3">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <p className="text-center text-muted-foreground py-20">No posts yet. Check back soon!</p>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {posts.map((post: any) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>
        )}

        {testimonials.length > 0 && (
          <section className="mt-20">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold mb-2">What Our Users Say</h2>
              <p className="text-muted-foreground">Real stories from the Brimsom community.</p>
            </div>
            <div className="grid sm:grid-cols-2 gap-6">
              {testimonials.map((t) => (
                <div key={t.id} className="rounded-xl border border-border bg-card p-6 relative">
                  <Quote className="absolute top-4 right-4 h-6 w-6 text-primary/20" />
                  {t.rating && (
                    <div className="flex gap-0.5 mb-3">
                      {[1,2,3,4,5].map((n) => (
                        <Star key={n} className={cn("h-4 w-4", (t.rating ?? 0) >= n ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30")} />
                      ))}
                    </div>
                  )}
                  <p className="text-sm leading-relaxed mb-4 whitespace-pre-wrap">{t.message}</p>
                  {t.image_url && (
                    <img
                      src={t.image_url}
                      alt={`${t.name}'s photo`}
                      loading="lazy"
                      className="w-full max-h-64 object-cover rounded-lg border border-border mb-4"
                    />
                  )}
                  <p className="text-sm font-semibold">— {t.name}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );

  if (user) {
    return <AppLayout>{blogContent}</AppLayout>;
  }

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Blog | Brimsom — Scholarship tips, stories, and guides"
        description="Insights, success stories, and practical guides to help you find and win scholarships abroad."
        path="/blog"
      />
      <div className="fixed inset-x-0 top-0 h-32 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto flex items-center justify-between h-16 px-4">
          <Link to="/" className="flex items-center gap-2">
            {logoUrl ? (
              <img src={logoUrl} alt="Brimsom AI Logo" className="h-8 w-8 rounded-lg object-contain" />
            ) : (
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <GraduationCap className="h-5 w-5 text-primary-foreground" />
              </div>
            )}
            <span className="text-xl font-bold font-serif">Brimsom</span>
          </Link>
          <div className="hidden md:flex items-center gap-2">
            <Button variant="ghost" asChild size="sm">
              <Link to="/blog">Blog</Link>
            </Button>
            <ThemeToggle />
            <Button variant="ghost" asChild>
              <Link to="/auth">Log in</Link>
            </Button>
            <Button asChild>
              <Link to="/auth?tab=signup">Get Started</Link>
            </Button>
          </div>
          <div className="flex md:hidden items-center gap-1">
            <ThemeToggle />
            <Button variant="ghost" size="icon" aria-label="Open menu" onClick={() => setMobileOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="right" className="w-72 flex flex-col">
          <SheetHeader>
            <SheetTitle className="text-left">Menu</SheetTitle>
          </SheetHeader>
          <div className="flex flex-col gap-2 mt-4 flex-1">
            <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/blog">Blog</Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/auth">Log in</Link>
            </Button>
            <Button className="w-full mt-2" asChild onClick={() => setMobileOpen(false)}>
              <Link to="/auth?tab=signup">Get Started <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {blogContent}

      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Brimsom. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

function BlogPostCard({ post }: { post: any }) {
  const [copied, setCopied] = useState(false);
  const url = `${window.location.origin}/blog/${post.slug}`;
  const shareText = post.title;

  const handleCopy = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast({ title: "Link copied", description: "Share it anywhere." });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Copy failed", variant: "destructive" });
    }
  };

  const openShare = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    window.open(href, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="group relative rounded-xl border border-border bg-card overflow-hidden hover:shadow-lg transition-shadow">
      <Link to={`/blog/${post.slug}`} className="block">
        {post.thumbnail_url && (
          <div className="aspect-video overflow-hidden bg-muted">
            <img
              src={post.thumbnail_url}
              alt={post.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
          </div>
        )}
        <div className="p-5">
          {post.published_at && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
              <Calendar className="h-3 w-3" />
              {format(new Date(post.published_at), "MMM d, yyyy")}
            </div>
          )}
          <h2 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors pr-10">
            {post.title}
          </h2>
          {post.excerpt && (
            <p className="text-sm text-muted-foreground line-clamp-2">{post.excerpt}</p>
          )}
          <span className="inline-flex items-center gap-1 text-sm text-primary mt-3 font-medium">
            Read full article<span className="sr-only">: {post.title}</span> <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </span>
        </div>
      </Link>
      <div className="absolute top-3 right-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="secondary"
              size="icon"
              className="h-8 w-8 rounded-full shadow-sm"
              onClick={(e) => e.stopPropagation()}
              aria-label="Share post"
            >
              <Share2 className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={openShare(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(url)}`)}>
              <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              Share on X
            </DropdownMenuItem>
            <DropdownMenuItem onClick={openShare(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`)}>
              <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
              Share on LinkedIn
            </DropdownMenuItem>
            <DropdownMenuItem onClick={openShare(`https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareText} ${url}`)}`)}>
              <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
              Share on WhatsApp
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleCopy}>
              {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
              {copied ? "Copied!" : "Copy link"}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
