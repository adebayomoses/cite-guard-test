import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Shield } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import MarkdownContent from "@/components/MarkdownContent";
import SEO from "@/components/SEO";

const sections = [
  {
    title: "1. Information We Collect",
    content: `We collect information you provide directly when using Brimsom:

• **Account Information**: Email address, name, and password when you create an account.
• **Profile Data**: Academic level, nationality, country of residence, date of birth, education history, GPA, test scores, research experience, extracurricular activities, and uploaded documents (e.g., CVs, transcripts, SOPs).
• **Scholarship Preferences**: Saved scholarships, application tracking data, and scholarship search activity.
• **Chat & Community Data**: Messages sent in community chat rooms and direct messages, including any images shared.
• **Session Bookings**: Proposed dates, session type, and notes when booking advisory sessions.
• **Device Information**: Push notification subscription details (endpoint, keys) if you opt in to notifications.`
  },
  {
    title: "2. How We Use Your Information",
    content: `Your information is used to provide and improve Brimsom's services:

• **AI Scholarship Matching**: Your academic profile is analyzed by AI to calculate a Scholarship Readiness Score and match you with relevant scholarships.
• **Chance Scoring**: We compare your profile data against scholarship eligibility criteria to estimate your likelihood of success.
• **Scholarship Digest Emails**: If enabled, we send periodic email digests with new scholarship opportunities tailored to your profile.
• **Community Features**: Your display name is shown in chat rooms and direct messages to facilitate community interaction.
• **Document Review**: Submitted documents are stored securely and reviewed by authorized administrators.
• **Platform Improvement**: Aggregated, anonymized usage data helps us improve our matching algorithms and user experience.`
  },
  {
    title: "3. Data Storage & Security",
    content: `• Your data is stored securely using industry-standard cloud infrastructure with encryption at rest and in transit.
• Database access is controlled through Row-Level Security (RLS) policies, ensuring users can only access their own data.
• Authentication is handled through secure session management with email verification.
• File uploads (documents, chat images) are stored in secure cloud storage buckets with access controls.`
  },
  {
    title: "4. Third-Party Services",
    content: `Brimsom integrates with the following categories of services:

• **Cloud Infrastructure**: Our backend database, authentication, file storage, and serverless functions are powered by secure cloud services.
• **AI Processing**: Scholarship matching and scoring use AI models to analyze your profile. Your data is processed securely and not used to train third-party models.
• **Push Notifications**: If you enable push notifications, your browser subscription details are stored to deliver real-time updates.
• **Email Delivery**: Transactional and digest emails are sent through a secure email delivery service.`
  },
  {
    title: "5. Your Rights & Choices",
    content: `You have the following rights regarding your personal data:

• **Access & Export**: You can view all your profile data, education history, test scores, and other information through your profile page.
• **Correction**: You can update your profile information at any time through the profile editor.
• **Deletion**: You can request deletion of your account and all associated data by contacting us. This includes profile data, chat messages, saved scholarships, and uploaded documents.
• **Email Opt-Out**: You can disable scholarship digest emails through your notification preferences at any time.
• **Push Notification Opt-Out**: You can disable push notifications through your browser settings.
• **Data Portability**: You may request a copy of your data in a standard format.`
  },
  {
    title: "6. Cookies & Local Storage",
    content: `• **Authentication Tokens**: We use secure session tokens stored in your browser to keep you logged in.
• **Theme Preference**: Your light/dark mode preference is stored locally.
• **PWA Data**: If you install Brimsom as a Progressive Web App, a service worker caches essential assets for offline access.
• We do not use third-party tracking cookies or advertising cookies.`
  },
  {
    title: "7. Data Retention",
    content: `• Active account data is retained as long as your account exists.
• Chat messages and community content are retained to maintain conversation history for all participants.
• Chat images older than 30 days may be automatically cleaned up to manage storage.
• Deleted accounts have all associated personal data removed, though anonymized aggregated data may be retained.`
  },
  {
    title: "8. Children's Privacy",
    content: `Brimsom is intended for students and individuals seeking scholarship opportunities. We do not knowingly collect personal information from children under the age of 13. If you believe a child under 13 has provided personal information, please contact us so we can take appropriate action.`
  },
  {
    title: "9. Changes to This Policy",
    content: `We may update this Privacy Policy from time to time. When we make significant changes, we will notify users through the platform. Continued use of Brimsom after changes constitutes acceptance of the updated policy.`
  },
  {
    title: "10. Contact Us",
    content: `If you have questions about this Privacy Policy or wish to exercise your data rights, please reach out:

• **Email**: admin@brimsom.com
• **Platform**: Use the community chat or direct message feature to contact an administrator.`
  },
];

export default function Privacy() {
  const { settings } = useSiteSettings();
  const override = (settings.privacy_page_content ?? "").trim();
  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Privacy Policy | Brimsom"
        description="How Brimsom collects, uses, and protects your personal data — account info, profile details, documents, and chat activity."
        path="/privacy"
      />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="relative z-10">
        <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto flex items-center justify-between h-16 px-4">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Home</Link>
            </Button>
            <ThemeToggle />
          </div>
        </nav>

        <main className="container mx-auto px-4 py-12 max-w-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Privacy Policy</h1>
              <p className="text-sm text-muted-foreground">Last updated: March 2026</p>
            </div>
          </div>

          {override ? (
            <Card><CardContent className="pt-6"><MarkdownContent content={override} /></CardContent></Card>
          ) : (
            <>
              <p className="text-muted-foreground mb-8">
                At Brimsom, we are committed to protecting your privacy. This policy explains what data we collect, how we use it, and your rights as a user of our platform.
              </p>

              <div className="space-y-4">
                {sections.map((section) => (
                  <Card key={section.title}>
                    <CardHeader className="pb-2">
                      <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg">{section.title}</h2>
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                        {section.content.split(/(\*\*[^*]+\*\*)/).map((part, i) =>
                          part.startsWith("**") && part.endsWith("**") ? (
                            <strong key={i} className="text-foreground font-medium">{part.slice(2, -2)}</strong>
                          ) : (
                            <span key={i}>{part}</span>
                          )
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
