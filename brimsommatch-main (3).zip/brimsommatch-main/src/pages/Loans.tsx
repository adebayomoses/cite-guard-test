import AppLayout from "@/components/AppLayout";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Landmark, ExternalLink, CheckCircle2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import SEO from "@/components/SEO";

interface LoanProvider {
  id: string;
  name: string;
  description: string | null;
  requirements: string | null;
  rates: string | null;
  url: string | null;
  logo_url: string | null;
  is_active: boolean;
  sort_order: number;
}

export default function Loans() {
  const { data: providers = [], isLoading } = useQuery({
    queryKey: ["loan-providers"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("loan_providers").select("*").eq("is_active", true).order("sort_order");
      if (error) throw error;
      return data as LoanProvider[];
    },
  });

  const parseRequirements = (req: string | null): string[] => {
    if (!req) return [];
    return req.split(/\\n|\n/).map(l => l.replace(/^[•\-*]\s*/, "").trim()).filter(Boolean);
  };

  return (
    <AppLayout>
      <SEO title="Student Loans | Brimsom" description="Compare trusted student loan providers for your international studies." path="/loans" />
      <main className="container mx-auto px-4 py-12 max-w-5xl">
        <h1 className="text-2xl sm:text-3xl font-bold mb-2">Secure a Loan</h1>
        <p className="text-muted-foreground mb-8">Explore student loan options to fund your education abroad.</p>

        {isLoading ? (
          <div className="grid sm:grid-cols-2 gap-6">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-64 rounded-lg" />)}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-6">
            {providers.map((provider) => {
              const reqs = parseRequirements(provider.requirements);
              return (
                <Card key={provider.id} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center shrink-0 overflow-hidden">
                        {provider.logo_url ? (
                          <img
                            src={provider.logo_url}
                            alt={provider.name}
                            className="h-10 w-10 rounded-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = "none";
                              (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden");
                            }}
                          />
                        ) : null}
                        <Landmark className={`h-5 w-5 text-primary ${provider.logo_url ? "hidden" : ""}`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{provider.name}</CardTitle>
                        {provider.rates && <CardDescription className="text-xs">{provider.rates}</CardDescription>}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 space-y-3">
                    {provider.description && (
                      <p className="text-sm text-muted-foreground">{provider.description}</p>
                    )}
                    {reqs.length > 0 && (
                      <div className="space-y-1.5">
                        <p className="text-xs font-medium text-foreground">Requirements</p>
                        <ul className="space-y-1">
                          {reqs.map((r, i) => (
                            <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                              <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
                              <span>{r}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                  {provider.url && (
                    <div className="p-6 pt-0">
                      <Button variant="outline" size="sm" className="w-full" asChild>
                        <a href={provider.url} target="_blank" rel="noopener noreferrer">
                          Learn More <ExternalLink className="h-3.5 w-3.5 ml-1.5" />
                        </a>
                      </Button>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </AppLayout>
  );
}
