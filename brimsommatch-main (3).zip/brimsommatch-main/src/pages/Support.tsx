import { useState, useMemo, useCallback } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, LifeBuoy, Mail, Clock, MessageCircle, ShieldCheck, BookOpen, HelpCircle } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import SEO from "@/components/SEO";

const faqItems = [
  {
    q: "How do I update my profile?",
    a: "Navigate to the Profile page from the dashboard. You can edit your personal info, education, test scores, research, extracurriculars, and documents at any time.",
  },
  {
    q: "How is my Scholarship Readiness Score calculated?",
    a: "Our AI analyzes your education, GPA, test scores, research experience, extracurriculars, and documents to generate a score reflecting your competitiveness for scholarships in our database.",
  },
  {
    q: "Can I delete my account and data?",
    a: "Yes. Contact us using the form below with the subject 'Account Deletion' and we will process your request. All personal data, chat messages, and uploaded documents will be permanently removed.",
  },
  {
    q: "How do I opt out of scholarship digest emails?",
    a: "Go to your notification preferences and toggle off the digest email option. You can also use the unsubscribe link at the bottom of any digest email.",
  },
  {
    q: "Is my data shared with third parties?",
    a: "No. Your personal data is never sold or shared with third parties for marketing purposes. See our Privacy Policy for full details on data handling.",
  },
  {
    q: "How do I report inappropriate content in community chat?",
    a: "You can block users directly from chat. Additionally, contact us through this form with the category 'Report Issue' and provide details about the content.",
  },
];

const categories = [
  { value: "general", label: "General Inquiry" },
  { value: "account", label: "Account & Profile" },
  { value: "scholarships", label: "Scholarships & Matching" },
  { value: "technical", label: "Technical Issue / Bug" },
  { value: "billing", label: "Billing & Subscription" },
  { value: "report", label: "Report Issue / Abuse" },
  { value: "data", label: "Data & Privacy Request" },
  { value: "other", label: "Other" },
];

function generateMathChallenge() {
  const a = Math.floor(Math.random() * 20) + 1;
  const b = Math.floor(Math.random() * 20) + 1;
  return { a, b, answer: a + b };
}

export default function Support() {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("");
  const [message, setMessage] = useState("");
  const [captchaInput, setCaptchaInput] = useState("");
  const [challenge, setChallenge] = useState(generateMathChallenge);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const resetChallenge = useCallback(() => {
    setChallenge(generateMathChallenge());
    setCaptchaInput("");
  }, []);

  const validate = useCallback(() => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = "Name is required";
    else if (name.trim().length > 100) errs.name = "Name must be under 100 characters";
    if (!email.trim()) errs.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) errs.email = "Invalid email address";
    if (!subject.trim()) errs.subject = "Subject is required";
    else if (subject.trim().length > 200) errs.subject = "Subject must be under 200 characters";
    if (!category) errs.category = "Please select a category";
    if (!message.trim()) errs.message = "Message is required";
    else if (message.trim().length > 5000) errs.message = "Message must be under 5000 characters";
    if (!captchaInput.trim()) errs.captcha = "Please answer the math question";
    else if (parseInt(captchaInput.trim(), 10) !== challenge.answer) errs.captcha = "Incorrect answer — please try again";
    return errs;
  }, [name, email, subject, category, message, captchaInput, challenge]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      if (errs.captcha && errs.captcha.includes("Incorrect")) resetChallenge();
      return;
    }

    setSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase.from("support_requests" as any).insert({
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        category,
        message: message.trim(),
        user_id: user?.id || null,
      } as any);

      if (error) throw error;
      setSubmitted(true);
      toast({ title: "Message sent!", description: "We'll get back to you as soon as possible." });
    } catch {
      toast({ title: "Failed to send", description: "Something went wrong. Please try again later.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Support | Brimsom"
        description="Get help from the Brimsom team — answers to common questions and a direct contact form."
        path="/support"
      />
      <div className="fixed inset-x-0 top-0 h-72 pointer-events-none z-0" style={{ background: "var(--gradient-top)" }} />
      <div className="relative z-10">
        <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto flex items-center justify-between h-16 px-4">
            <Button variant="ghost" size="sm" asChild>
              <Link to="/"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Home</Link>
            </Button>
            <ThemeToggle />
          </div>
        </nav>

        <main className="container mx-auto px-4 py-12 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <LifeBuoy className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Support Center</h1>
              <p className="text-sm text-muted-foreground">We're here to help — reach out anytime</p>
            </div>
          </div>

          {/* Quick Info Cards */}
          <div className="grid sm:grid-cols-3 gap-4 mb-10">
            <Card>
              <CardContent className="pt-6 flex items-start gap-3">
                <Mail className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-sm">Email Us</h3>
                  <p className="text-xs text-muted-foreground mt-1">admin@brimsom.com</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 flex items-start gap-3">
                <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-sm">Response Time</h3>
                  <p className="text-xs text-muted-foreground mt-1">Usually within 24–48 hours</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6 flex items-start gap-3">
                <MessageCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-sm">In-App Chat</h3>
                  <p className="text-xs text-muted-foreground mt-1">DM an admin from the Community</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-5 gap-8">
            {/* Contact Form */}
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg">Contact Us</h2>
                  <CardDescription>Fill out the form and we'll get back to you.</CardDescription>
                </CardHeader>
                <CardContent>
                  {submitted ? (
                    <div className="text-center py-10">
                      <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <ShieldCheck className="h-7 w-7 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">Message Received!</h3>
                      <p className="text-sm text-muted-foreground mb-6">Thank you for reaching out. We'll respond to your email within 24–48 hours.</p>
                      <Button variant="outline" onClick={() => { setSubmitted(false); setName(""); setEmail(""); setSubject(""); setCategory(""); setMessage(""); resetChallenge(); setErrors({}); }}>
                        Send Another Message
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <Label htmlFor="name">Full Name</Label>
                          <Input id="name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} />
                          {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="email">Email Address</Label>
                          <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} />
                          {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <Label htmlFor="category">Category</Label>
                          <Select value={category} onValueChange={setCategory}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                            <SelectContent>
                              {categories.map((c) => (
                                <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {errors.category && <p className="text-xs text-destructive">{errors.category}</p>}
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="subject">Subject</Label>
                          <Input id="subject" placeholder="Brief summary" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={200} />
                          {errors.subject && <p className="text-xs text-destructive">{errors.subject}</p>}
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <Label htmlFor="message">Message</Label>
                        <Textarea id="message" placeholder="Describe your issue or question in detail..." rows={5} value={message} onChange={(e) => setMessage(e.target.value)} maxLength={5000} />
                        <div className="flex justify-between">
                          {errors.message && <p className="text-xs text-destructive">{errors.message}</p>}
                          <p className="text-xs text-muted-foreground ml-auto">{message.length}/5000</p>
                        </div>
                      </div>

                      {/* Math CAPTCHA */}
                      <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-2">
                        <div className="flex items-center gap-2 text-sm font-medium">
                          <ShieldCheck className="h-4 w-4 text-primary" />
                          Human Verification
                        </div>
                        <p className="text-sm text-muted-foreground">
                          What is <strong className="text-foreground">{challenge.a} + {challenge.b}</strong>?
                        </p>
                        <div className="flex items-center gap-3">
                          <Input
                            type="number"
                            placeholder="Your answer"
                            value={captchaInput}
                            onChange={(e) => setCaptchaInput(e.target.value)}
                            className="w-32"
                          />
                          <Button type="button" variant="ghost" size="sm" onClick={resetChallenge}>
                            New question
                          </Button>
                        </div>
                        {errors.captcha && <p className="text-xs text-destructive">{errors.captcha}</p>}
                      </div>

                      <Button type="submit" className="w-full" disabled={submitting}>
                        {submitting ? "Sending…" : "Send Message"}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* FAQ Sidebar */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <h2 className="text-2xl font-semibold leading-none tracking-tight text-lg flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-primary" aria-hidden="true" />
                    FAQs
                  </h2>
                </CardHeader>
                <CardContent className="space-y-4">
                  {faqItems.map((item, i) => (
                    <div key={i} className="space-y-1">
                      <h4 className="text-sm font-medium">{item.q}</h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">{item.a}</p>
                      {i < faqItems.length - 1 && <div className="border-b border-border pt-2" />}
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Additional Help */}
              <Card className="mt-4">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <BookOpen className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-sm mb-1">Helpful Links</h3>
                      <ul className="text-xs text-muted-foreground space-y-1.5">
                        <li><Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link> — How we handle your data</li>
                        <li><Link to="/about" className="text-primary hover:underline">About Brimsom</Link> — Learn about the platform</li>
                        <li><Link to="/blog" className="text-primary hover:underline">Blog</Link> — Tips and scholarship news</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
