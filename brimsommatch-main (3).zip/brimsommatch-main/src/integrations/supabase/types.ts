export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          action: string
          created_at: string
          detail: string | null
          id: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          detail?: string | null
          id?: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          detail?: string | null
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      advisor_conversations: {
        Row: {
          created_at: string
          id: string
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      advisor_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "advisor_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "advisor_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      app_downloads: {
        Row: {
          created_at: string
          file_name: string | null
          file_url: string | null
          id: string
          is_active: boolean
          platform: string
          updated_at: string
          version: string | null
        }
        Insert: {
          created_at?: string
          file_name?: string | null
          file_url?: string | null
          id?: string
          is_active?: boolean
          platform: string
          updated_at?: string
          version?: string | null
        }
        Update: {
          created_at?: string
          file_name?: string | null
          file_url?: string | null
          id?: string
          is_active?: boolean
          platform?: string
          updated_at?: string
          version?: string | null
        }
        Relationships: []
      }
      approval_team_members: {
        Row: {
          added_by: string | null
          created_at: string
          user_id: string
        }
        Insert: {
          added_by?: string | null
          created_at?: string
          user_id: string
        }
        Update: {
          added_by?: string | null
          created_at?: string
          user_id?: string
        }
        Relationships: []
      }
      blocked_users: {
        Row: {
          blocked_id: string
          blocker_id: string
          created_at: string
          id: string
        }
        Insert: {
          blocked_id: string
          blocker_id: string
          created_at?: string
          id?: string
        }
        Update: {
          blocked_id?: string
          blocker_id?: string
          created_at?: string
          id?: string
        }
        Relationships: []
      }
      blog_posts: {
        Row: {
          author_id: string | null
          content: string
          created_at: string
          excerpt: string | null
          id: string
          is_published: boolean
          published_at: string | null
          slug: string
          thumbnail_url: string | null
          title: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          content?: string
          created_at?: string
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string | null
          slug: string
          thumbnail_url?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          content?: string
          created_at?: string
          excerpt?: string | null
          id?: string
          is_published?: boolean
          published_at?: string | null
          slug?: string
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      challenge_submissions: {
        Row: {
          cgpa: string
          course_of_study: string
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string
          updated_at: string
          user_id: string
        }
        Insert: {
          cgpa: string
          course_of_study: string
          created_at?: string
          email: string
          full_name: string
          id?: string
          phone: string
          updated_at?: string
          user_id: string
        }
        Update: {
          cgpa?: string
          course_of_study?: string
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      chat_bans: {
        Row: {
          banned_by: string
          created_at: string
          id: string
          reason: string | null
          room_id: string | null
          user_id: string
        }
        Insert: {
          banned_by: string
          created_at?: string
          id?: string
          reason?: string | null
          room_id?: string | null
          user_id: string
        }
        Update: {
          banned_by?: string
          created_at?: string
          id?: string
          reason?: string | null
          room_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_bans_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          image_url: string | null
          room_id: string
          user_id: string
          user_name: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          image_url?: string | null
          room_id: string
          user_id: string
          user_name?: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          image_url?: string | null
          room_id?: string
          user_id?: string
          user_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_read_state: {
        Row: {
          id: string
          kind: string
          last_read_at: string
          target_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          id?: string
          kind: string
          last_read_at?: string
          target_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          id?: string
          kind?: string
          last_read_at?: string
          target_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      chat_rooms: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      community_moderators: {
        Row: {
          appointed_by: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          appointed_by: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          appointed_by?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      device_tokens: {
        Row: {
          app_id: string | null
          created_at: string
          id: string
          platform: string
          token: string
          updated_at: string
          user_id: string
        }
        Insert: {
          app_id?: string | null
          created_at?: string
          id?: string
          platform: string
          token: string
          updated_at?: string
          user_id: string
        }
        Update: {
          app_id?: string | null
          created_at?: string
          id?: string
          platform?: string
          token?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      direct_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          image_url: string | null
          receiver_id: string
          sender_id: string
          sender_name: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          image_url?: string | null
          receiver_id: string
          sender_id: string
          sender_name?: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          image_url?: string | null
          receiver_id?: string
          sender_id?: string
          sender_name?: string
        }
        Relationships: []
      }
      document_submissions: {
        Row: {
          admin_feedback: string | null
          created_at: string
          file_name: string
          file_url: string
          id: string
          notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          service_type: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_feedback?: string | null
          created_at?: string
          file_name: string
          file_url: string
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          service_type: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_feedback?: string | null
          created_at?: string
          file_name?: string
          file_url?: string
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          service_type?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      education_history: {
        Row: {
          created_at: string
          degree_level: string
          end_date: string | null
          field_of_study: string | null
          gpa: number | null
          gpa_scale: number | null
          id: string
          institution: string
          is_current: boolean | null
          start_date: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          degree_level: string
          end_date?: string | null
          field_of_study?: string | null
          gpa?: number | null
          gpa_scale?: number | null
          id?: string
          institution: string
          is_current?: boolean | null
          start_date?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          degree_level?: string
          end_date?: string | null
          field_of_study?: string | null
          gpa?: number | null
          gpa_scale?: number | null
          id?: string
          institution?: string
          is_current?: boolean | null
          start_date?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      email_preferences: {
        Row: {
          created_at: string
          digest_enabled: boolean
          id: string
          user_id: string
          weekly_focus_enabled: boolean
        }
        Insert: {
          created_at?: string
          digest_enabled?: boolean
          id?: string
          user_id: string
          weekly_focus_enabled?: boolean
        }
        Update: {
          created_at?: string
          digest_enabled?: boolean
          id?: string
          user_id?: string
          weekly_focus_enabled?: boolean
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      essay_profiles: {
        Row: {
          academic_explanations: string | null
          career_goals: string | null
          created_at: string
          id: string
          motivation: string | null
          project_or_achievement: string | null
          research_interests: string | null
          tools_software: string | null
          updated_at: string
          user_id: string
          why_study_abroad: string | null
        }
        Insert: {
          academic_explanations?: string | null
          career_goals?: string | null
          created_at?: string
          id?: string
          motivation?: string | null
          project_or_achievement?: string | null
          research_interests?: string | null
          tools_software?: string | null
          updated_at?: string
          user_id: string
          why_study_abroad?: string | null
        }
        Update: {
          academic_explanations?: string | null
          career_goals?: string | null
          created_at?: string
          id?: string
          motivation?: string | null
          project_or_achievement?: string | null
          research_interests?: string | null
          tools_software?: string | null
          updated_at?: string
          user_id?: string
          why_study_abroad?: string | null
        }
        Relationships: []
      }
      extracurriculars: {
        Row: {
          category: string
          created_at: string
          date: string | null
          description: string | null
          id: string
          organization: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string
          created_at?: string
          date?: string | null
          description?: string | null
          id?: string
          organization?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          date?: string | null
          description?: string | null
          id?: string
          organization?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      feature_usage: {
        Row: {
          feature: string
          id: string
          used_at: string
          user_id: string
        }
        Insert: {
          feature: string
          id?: string
          used_at?: string
          user_id: string
        }
        Update: {
          feature?: string
          id?: string
          used_at?: string
          user_id?: string
        }
        Relationships: []
      }
      funding_category_apply_steps: {
        Row: {
          category: string
          created_at: string
          id: string
          steps: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          steps?: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          steps?: string
          updated_at?: string
        }
        Relationships: []
      }
      guest_chat_usage: {
        Row: {
          count: number
          created_at: string
          guest_id: string
          reset_at: string | null
          updated_at: string
        }
        Insert: {
          count?: number
          created_at?: string
          guest_id: string
          reset_at?: string | null
          updated_at?: string
        }
        Update: {
          count?: number
          created_at?: string
          guest_id?: string
          reset_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      high_school_subjects: {
        Row: {
          created_at: string
          grade: string | null
          id: string
          subject_name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          grade?: string | null
          id?: string
          subject_name: string
          user_id: string
        }
        Update: {
          created_at?: string
          grade?: string | null
          id?: string
          subject_name?: string
          user_id?: string
        }
        Relationships: []
      }
      info_sources: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          name: string
          sort_order: number
          updated_at: string
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          sort_order?: number
          updated_at?: string
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          sort_order?: number
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      job_applications: {
        Row: {
          created_at: string
          email: string
          experience: string
          full_name: string
          id: string
          phone: string | null
          position: string
          resume_path: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          experience: string
          full_name: string
          id?: string
          phone?: string | null
          position: string
          resume_path?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          experience?: string
          full_name?: string
          id?: string
          phone?: string | null
          position?: string
          resume_path?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      loan_providers: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          logo_url: string | null
          name: string
          rates: string | null
          requirements: string | null
          sort_order: number
          updated_at: string
          url: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          logo_url?: string | null
          name: string
          rates?: string | null
          requirements?: string | null
          sort_order?: number
          updated_at?: string
          url?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          logo_url?: string | null
          name?: string
          rates?: string | null
          requirements?: string | null
          sort_order?: number
          updated_at?: string
          url?: string | null
        }
        Relationships: []
      }
      match_history: {
        Row: {
          created_at: string
          id: string
          result: Json
          scholarship_text: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          result: Json
          scholarship_text: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          result?: Json
          scholarship_text?: string
          user_id?: string
        }
        Relationships: []
      }
      moderator_permissions: {
        Row: {
          created_at: string
          id: string
          section: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          section: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          section?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          is_read: boolean
          title: string
          url: string | null
          user_id: string | null
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          title: string
          url?: string | null
          user_id?: string | null
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          title?: string
          url?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          academic_level: string | null
          avatar_url: string | null
          bio: string | null
          country_of_residence: string | null
          created_at: string
          date_of_birth: string | null
          full_name: string | null
          id: string
          intended_degree_level: string | null
          intended_field_of_study: string | null
          intended_program: string | null
          nationality: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          academic_level?: string | null
          avatar_url?: string | null
          bio?: string | null
          country_of_residence?: string | null
          created_at?: string
          date_of_birth?: string | null
          full_name?: string | null
          id?: string
          intended_degree_level?: string | null
          intended_field_of_study?: string | null
          intended_program?: string | null
          nationality?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          academic_level?: string | null
          avatar_url?: string | null
          bio?: string | null
          country_of_residence?: string | null
          created_at?: string
          date_of_birth?: string | null
          full_name?: string | null
          id?: string
          intended_degree_level?: string | null
          intended_field_of_study?: string | null
          intended_program?: string | null
          nationality?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          user_id?: string
        }
        Relationships: []
      }
      quick_actions: {
        Row: {
          created_at: string
          icon_name: string
          id: string
          is_enabled: boolean
          label: string
          route: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          icon_name: string
          id?: string
          is_enabled?: boolean
          label: string
          route: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          icon_name?: string
          id?: string
          is_enabled?: boolean
          label?: string
          route?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      research_experience: {
        Row: {
          created_at: string
          description: string | null
          end_date: string | null
          id: string
          organization: string | null
          publications: string[] | null
          start_date: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          organization?: string | null
          publications?: string[] | null
          start_date?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          end_date?: string | null
          id?: string
          organization?: string | null
          publications?: string[] | null
          start_date?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      resource_tabs: {
        Row: {
          created_at: string
          id: string
          is_default: boolean
          name: string
          sort_order: number
        }
        Insert: {
          created_at?: string
          id?: string
          is_default?: boolean
          name: string
          sort_order?: number
        }
        Update: {
          created_at?: string
          id?: string
          is_default?: boolean
          name?: string
          sort_order?: number
        }
        Relationships: []
      }
      resources: {
        Row: {
          created_at: string
          description: string | null
          id: string
          link_url: string | null
          sort_order: number
          tab_id: string
          title: string
          updated_at: string
          youtube_url: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          link_url?: string | null
          sort_order?: number
          tab_id: string
          title: string
          updated_at?: string
          youtube_url?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          link_url?: string | null
          sort_order?: number
          tab_id?: string
          title?: string
          updated_at?: string
          youtube_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "resources_tab_id_fkey"
            columns: ["tab_id"]
            isOneToOne: false
            referencedRelation: "resource_tabs"
            referencedColumns: ["id"]
          },
        ]
      }
      room_announcements: {
        Row: {
          content: string
          created_at: string
          created_by: string
          id: string
          room_id: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by: string
          id?: string
          room_id: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          id?: string
          room_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "room_announcements_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_scholarships: {
        Row: {
          created_at: string
          id: string
          scholarship_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          scholarship_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          scholarship_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_scholarships_scholarship_id_fkey"
            columns: ["scholarship_id"]
            isOneToOne: false
            referencedRelation: "scholarships"
            referencedColumns: ["id"]
          },
        ]
      }
      scholarship_applications: {
        Row: {
          created_at: string
          custom_name: string | null
          deadline: string | null
          id: string
          notes: string | null
          scholarship_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          custom_name?: string | null
          deadline?: string | null
          id?: string
          notes?: string | null
          scholarship_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          custom_name?: string | null
          deadline?: string | null
          id?: string
          notes?: string | null
          scholarship_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "scholarship_applications_scholarship_id_fkey"
            columns: ["scholarship_id"]
            isOneToOne: false
            referencedRelation: "scholarships"
            referencedColumns: ["id"]
          },
        ]
      }
      scholarship_apply_clicks: {
        Row: {
          clicked_at: string
          id: string
          scholarship_id: string
          user_id: string
        }
        Insert: {
          clicked_at?: string
          id?: string
          scholarship_id: string
          user_id: string
        }
        Update: {
          clicked_at?: string
          id?: string
          scholarship_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "scholarship_apply_clicks_scholarship_id_fkey"
            columns: ["scholarship_id"]
            isOneToOne: false
            referencedRelation: "scholarships"
            referencedColumns: ["id"]
          },
        ]
      }
      scholarship_duplicate_ignores: {
        Row: {
          a_id: string
          b_id: string
          created_at: string
          id: string
          ignored_by: string
        }
        Insert: {
          a_id: string
          b_id: string
          created_at?: string
          id?: string
          ignored_by: string
        }
        Update: {
          a_id?: string
          b_id?: string
          created_at?: string
          id?: string
          ignored_by?: string
        }
        Relationships: []
      }
      scholarship_intakes: {
        Row: {
          close_date: string | null
          created_at: string
          custom_label: string | null
          id: string
          open_date: string | null
          scholarship_id: string
          sort_order: number
          term: string
          updated_at: string
        }
        Insert: {
          close_date?: string | null
          created_at?: string
          custom_label?: string | null
          id?: string
          open_date?: string | null
          scholarship_id: string
          sort_order?: number
          term: string
          updated_at?: string
        }
        Update: {
          close_date?: string | null
          created_at?: string
          custom_label?: string | null
          id?: string
          open_date?: string | null
          scholarship_id?: string
          sort_order?: number
          term?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "scholarship_intakes_scholarship_id_fkey"
            columns: ["scholarship_id"]
            isOneToOne: false
            referencedRelation: "scholarships"
            referencedColumns: ["id"]
          },
        ]
      }
      scholarships: {
        Row: {
          admission_requirements_url: string | null
          application_fee_amount: string | null
          apply_steps: string | null
          approved_at: string | null
          approved_by: string | null
          assigned_reviewer_id: string | null
          auto_publish_enabled: boolean
          country: string | null
          created_at: string
          created_by: string | null
          deadline_source_url: string | null
          degree_level: string | null
          description: string | null
          eligibility_criteria: string | null
          field_of_study: string | null
          forwarded_to_admin: boolean
          funding_amount: string | null
          funding_category: string | null
          funding_type: string | null
          has_application_fee: boolean
          id: string
          is_active: boolean
          is_challenge: boolean
          min_cgpa_percentage: number | null
          min_cgpa_scale: number | null
          min_gpa: number | null
          next_close_date: string | null
          next_open_date: string | null
          previous_rejection_reason: string | null
          provider: string | null
          rejection_reason: string | null
          republished_at: string | null
          resubmission_count: number
          resubmitted_at: string | null
          reviewed_at: string | null
          status: string
          submission_notes: string | null
          submitted_at: string
          title: string
          updated_at: string
          updated_by: string | null
          url: string | null
        }
        Insert: {
          admission_requirements_url?: string | null
          application_fee_amount?: string | null
          apply_steps?: string | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_reviewer_id?: string | null
          auto_publish_enabled?: boolean
          country?: string | null
          created_at?: string
          created_by?: string | null
          deadline_source_url?: string | null
          degree_level?: string | null
          description?: string | null
          eligibility_criteria?: string | null
          field_of_study?: string | null
          forwarded_to_admin?: boolean
          funding_amount?: string | null
          funding_category?: string | null
          funding_type?: string | null
          has_application_fee?: boolean
          id?: string
          is_active?: boolean
          is_challenge?: boolean
          min_cgpa_percentage?: number | null
          min_cgpa_scale?: number | null
          min_gpa?: number | null
          next_close_date?: string | null
          next_open_date?: string | null
          previous_rejection_reason?: string | null
          provider?: string | null
          rejection_reason?: string | null
          republished_at?: string | null
          resubmission_count?: number
          resubmitted_at?: string | null
          reviewed_at?: string | null
          status?: string
          submission_notes?: string | null
          submitted_at?: string
          title: string
          updated_at?: string
          updated_by?: string | null
          url?: string | null
        }
        Update: {
          admission_requirements_url?: string | null
          application_fee_amount?: string | null
          apply_steps?: string | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_reviewer_id?: string | null
          auto_publish_enabled?: boolean
          country?: string | null
          created_at?: string
          created_by?: string | null
          deadline_source_url?: string | null
          degree_level?: string | null
          description?: string | null
          eligibility_criteria?: string | null
          field_of_study?: string | null
          forwarded_to_admin?: boolean
          funding_amount?: string | null
          funding_category?: string | null
          funding_type?: string | null
          has_application_fee?: boolean
          id?: string
          is_active?: boolean
          is_challenge?: boolean
          min_cgpa_percentage?: number | null
          min_cgpa_scale?: number | null
          min_gpa?: number | null
          next_close_date?: string | null
          next_open_date?: string | null
          previous_rejection_reason?: string | null
          provider?: string | null
          rejection_reason?: string | null
          republished_at?: string | null
          resubmission_count?: number
          resubmitted_at?: string | null
          reviewed_at?: string | null
          status?: string
          submission_notes?: string | null
          submitted_at?: string
          title?: string
          updated_at?: string
          updated_by?: string | null
          url?: string | null
        }
        Relationships: []
      }
      score_results: {
        Row: {
          created_at: string
          id: string
          profile_hash: string | null
          readiness_score: number
          readiness_summary: string | null
          scholarship_matches: Json | null
          tips: Json | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          profile_hash?: string | null
          readiness_score?: number
          readiness_summary?: string | null
          scholarship_matches?: Json | null
          tips?: Json | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          profile_hash?: string | null
          readiness_score?: number
          readiness_summary?: string | null
          scholarship_matches?: Json | null
          tips?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      session_bookings: {
        Row: {
          admin_notes: string | null
          confirmed_date: string | null
          created_at: string
          id: string
          notes: string | null
          proposed_date_1: string
          proposed_date_2: string
          proposed_date_3: string
          reviewed_by: string | null
          session_type: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          confirmed_date?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          proposed_date_1: string
          proposed_date_2: string
          proposed_date_3: string
          reviewed_by?: string | null
          session_type: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          confirmed_date?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          proposed_date_1?: string
          proposed_date_2?: string
          proposed_date_3?: string
          reviewed_by?: string | null
          session_type?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      shared_advisor_messages: {
        Row: {
          content: string
          created_at: string
          created_by: string
          id: string
          token: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by: string
          id?: string
          token: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          id?: string
          token?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          id: string
          key: string
          updated_at: string
          value: string | null
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string
          value?: string | null
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string
          value?: string | null
        }
        Relationships: []
      }
      slider_images: {
        Row: {
          alt_text: string | null
          created_at: string
          id: string
          image_url: string
          is_active: boolean
          sort_order: number
        }
        Insert: {
          alt_text?: string | null
          created_at?: string
          id?: string
          image_url: string
          is_active?: boolean
          sort_order?: number
        }
        Update: {
          alt_text?: string | null
          created_at?: string
          id?: string
          image_url?: string
          is_active?: boolean
          sort_order?: number
        }
        Relationships: []
      }
      sop_entries: {
        Row: {
          content: string
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      support_requests: {
        Row: {
          category: string
          created_at: string
          email: string
          id: string
          message: string
          name: string
          status: string
          subject: string
          user_id: string | null
        }
        Insert: {
          category?: string
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          status?: string
          subject: string
          user_id?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          status?: string
          subject?: string
          user_id?: string | null
        }
        Relationships: []
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      test_scores: {
        Row: {
          created_at: string
          date_taken: string | null
          id: string
          max_score: number | null
          score: number
          test_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          date_taken?: string | null
          id?: string
          max_score?: number | null
          score: number
          test_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          date_taken?: string | null
          id?: string
          max_score?: number | null
          score?: number
          test_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      testimonials: {
        Row: {
          created_at: string
          email: string | null
          id: string
          image_url: string | null
          is_approved: boolean
          message: string
          name: string
          published_at: string | null
          rating: number | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          image_url?: string | null
          is_approved?: boolean
          message: string
          name: string
          published_at?: string | null
          rating?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          image_url?: string | null
          is_approved?: boolean
          message?: string
          name?: string
          published_at?: string | null
          rating?: number | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_documents: {
        Row: {
          document_type: string
          file_name: string
          file_url: string
          id: string
          uploaded_at: string
          user_id: string
        }
        Insert: {
          document_type: string
          file_name: string
          file_url: string
          id?: string
          uploaded_at?: string
          user_id: string
        }
        Update: {
          document_type?: string
          file_name?: string
          file_url?: string
          id?: string
          uploaded_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_reports: {
        Row: {
          admin_notes: string | null
          created_at: string
          details: string | null
          id: string
          reason: string
          reported_message_id: string | null
          reported_user_id: string
          reporter_id: string
          reviewed_by: string | null
          room_id: string | null
          status: string
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          details?: string | null
          id?: string
          reason: string
          reported_message_id?: string | null
          reported_user_id: string
          reporter_id: string
          reviewed_by?: string | null
          room_id?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          details?: string | null
          id?: string
          reason?: string
          reported_message_id?: string | null
          reported_user_id?: string
          reporter_id?: string
          reviewed_by?: string | null
          room_id?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_reports_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chat_rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          plan: Database["public"]["Enums"]["subscription_plan"]
          started_at: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          plan?: Database["public"]["Enums"]["subscription_plan"]
          started_at?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          plan?: Database["public"]["Enums"]["subscription_plan"]
          started_at?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      winning_essays: {
        Row: {
          author_name: string | null
          content: string
          country: string | null
          created_at: string
          created_by: string
          degree_level: string | null
          document_type: string
          embedding: string | null
          embedding_updated_at: string | null
          field_of_study: string | null
          file_url: string | null
          id: string
          is_anonymized: boolean
          notes: string | null
          scholarship_name: string | null
          tags: string[]
          title: string
          updated_at: string
          year_won: number | null
        }
        Insert: {
          author_name?: string | null
          content: string
          country?: string | null
          created_at?: string
          created_by: string
          degree_level?: string | null
          document_type?: string
          embedding?: string | null
          embedding_updated_at?: string | null
          field_of_study?: string | null
          file_url?: string | null
          id?: string
          is_anonymized?: boolean
          notes?: string | null
          scholarship_name?: string | null
          tags?: string[]
          title: string
          updated_at?: string
          year_won?: number | null
        }
        Update: {
          author_name?: string | null
          content?: string
          country?: string | null
          created_at?: string
          created_by?: string
          degree_level?: string | null
          document_type?: string
          embedding?: string | null
          embedding_updated_at?: string | null
          field_of_study?: string | null
          file_url?: string | null
          id?: string
          is_anonymized?: boolean
          notes?: string | null
          scholarship_name?: string | null
          tags?: string[]
          title?: string
          updated_at?: string
          year_won?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_feature_usage_monthly: {
        Args: { _feature: string }
        Returns: {
          usage_count: number
          user_id: string
        }[]
      }
      admin_list_testimonials: {
        Args: never
        Returns: {
          created_at: string
          email: string
          id: string
          image_url: string
          is_approved: boolean
          message: string
          name: string
          published_at: string
          rating: number
        }[]
      }
      admin_platform_metrics: { Args: never; Returns: Json }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      email_queue_dispatch: { Args: never; Returns: undefined }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      find_duplicate_scholarship_clusters: {
        Args: { max_pairs?: number; similarity_threshold?: number }
        Returns: {
          a_country: string
          a_created_at: string
          a_id: string
          a_is_active: boolean
          a_provider: string
          a_status: string
          a_title: string
          b_country: string
          b_created_at: string
          b_id: string
          b_is_active: boolean
          b_provider: string
          b_status: string
          b_title: string
          similarity_score: number
        }[]
      }
      find_similar_scholarships: {
        Args: {
          exclude_id?: string
          max_results?: number
          query_country?: string
          query_provider?: string
          query_title: string
          similarity_threshold?: number
        }
        Returns: {
          country: string
          created_at: string
          id: string
          is_active: boolean
          provider: string
          provider_match: boolean
          similarity_score: number
          status: string
          title: string
        }[]
      }
      get_feature_usage_count: {
        Args: { _feature: string; _period?: string; _user_id: string }
        Returns: number
      }
      get_shared_advisor_message: {
        Args: { _token: string }
        Returns: {
          content: string
          created_at: string
        }[]
      }
      get_user_display_names: {
        Args: { user_ids: string[] }
        Returns: {
          full_name: string
          user_id: string
        }[]
      }
      has_mod_permission: {
        Args: { _section: string; _user_id: string }
        Returns: boolean
      }
      has_moderator_section: {
        Args: { _section: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_chat_banned: {
        Args: { _room_id: string; _user_id: string }
        Returns: boolean
      }
      is_community_moderator: { Args: { _user_id: string }; Returns: boolean }
      is_main_admin: { Args: { _user_id: string }; Returns: boolean }
      match_winning_essays: {
        Args: {
          filter_doc_type?: string
          match_count?: number
          query_embedding: string
        }
        Returns: {
          content: string
          country: string
          degree_level: string
          document_type: string
          field_of_study: string
          id: string
          scholarship_name: string
          similarity: number
          tags: string[]
          title: string
          year_won: number
        }[]
      }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      refresh_scholarship_next_close_date: {
        Args: { _scholarship_id: string }
        Returns: undefined
      }
      refresh_scholarship_next_dates: {
        Args: { _scholarship_id: string }
        Returns: undefined
      }
      run_auto_publish_sweep: {
        Args: never
        Returns: {
          scholarship_id: string
          title: string
        }[]
      }
      show_limit: { Args: never; Returns: number }
      show_trgm: { Args: { "": string }; Returns: string[] }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      subscription_plan: "free" | "standard" | "pro" | "pro_plus"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      subscription_plan: ["free", "standard", "pro", "pro_plus"],
    },
  },
} as const
