// Push Notification Service Worker + cache kill-switch
// IMPORTANT: This worker intentionally does NOT cache anything.
// It also wipes any caches left behind by previous Workbox/VitePWA versions
// so returning users always get the latest published build.

self.addEventListener("install", (event) => {
  // Activate immediately, don't wait for old SW to release control.
  event.waitUntil(self.skipWaiting());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    // Take control of all open tabs.
    await self.clients.claim();

    // Nuke every cache (Workbox precache, runtime caches, api-cache, etc.)
    try {
      const names = await caches.keys();
      await Promise.all(names.map((n) => caches.delete(n)));
    } catch (e) {
      // ignore
    }

    // NOTE: We intentionally do NOT force-reload clients here.
    // A mid-session navigation aborts in-flight pushManager.subscribe()
    // promises, which prevents the subscription from ever being saved.
    // Fresh HTML is served on the next natural navigation instead.
  })());
});

// Pass-through fetch — never cache, always go to network.
self.addEventListener("fetch", () => {
  // No-op: no respondWith means the browser handles it normally (network).
});

// ---------- Push notifications ----------
self.addEventListener("push", (event) => {
  let data = { title: "Brimsom", body: "You have a new notification", url: "/" };
  try {
    data = event.data?.json() ?? data;
  } catch {
    data.body = event.data?.text() ?? data.body;
  }

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/favicon.ico",
      badge: "/favicon.ico",
      data: { url: data.url || "/" },
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data?.url || "/";
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if (client.url.includes(self.location.origin) && "focus" in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      return clients.openWindow(url);
    })
  );
});
