export interface SharedSignal {
  id: string;
  user_id: string;
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  asset_type: 'forex' | 'crypto' | 'commodities' | 'indices' | 'stocks';
  timeframe: string;
  entry_price: string;
  stop_loss: string;
  take_profit: string;
  risk_reward_ratio: string;
  patterns: string[];
  trend: string | null;
  momentum: string | null;
  summary: string;
  created_at: string;
  expires_at: string;
}
