export interface AnalysisResult {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  riskRewardRatio: string;
  technicalBreakdown: {
    patterns: string[];
    supportLevels: string[];
    resistanceLevels: string[];
    trend: string;
    momentum: string;
    volatility: string;
  };
  timeframeAnalysis: string;
  summary: string;
}

export type AssetType = 'forex' | 'crypto' | 'commodities' | 'indices' | 'stocks';

export interface ChartUpload {
  id: string;
  file: File;
  preview: string;
  timeframe: string;
  assetType: AssetType;
  traderNotes?: string;
  analysis?: AnalysisResult;
  isAnalyzing: boolean;
  error?: string;
}

export interface RiskCalculation {
  accountSize: number;
  riskPercentage: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  positionSize: number;
  potentialLoss: number;
  potentialProfit: number;
  riskRewardRatio: number;
}
