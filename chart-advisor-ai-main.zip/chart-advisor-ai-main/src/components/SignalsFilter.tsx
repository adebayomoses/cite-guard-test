import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface SignalsFilterProps {
  assetType: string;
  signalType: string;
  sortBy: string;
  onAssetTypeChange: (value: string) => void;
  onSignalTypeChange: (value: string) => void;
  onSortByChange: (value: string) => void;
}

export const SignalsFilter = ({
  assetType,
  signalType,
  sortBy,
  onAssetTypeChange,
  onSignalTypeChange,
  onSortByChange,
}: SignalsFilterProps) => {
  return (
    <div className="flex flex-wrap gap-4">
      <div className="space-y-1.5">
        <Label className="text-xs text-muted-foreground">Asset Type</Label>
        <Select value={assetType} onValueChange={onAssetTypeChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="All Assets" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Assets</SelectItem>
            <SelectItem value="forex">Forex</SelectItem>
            <SelectItem value="crypto">Crypto</SelectItem>
            <SelectItem value="commodities">Commodities</SelectItem>
            <SelectItem value="indices">Indices</SelectItem>
            <SelectItem value="stocks">Stocks</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-muted-foreground">Signal</Label>
        <Select value={signalType} onValueChange={onSignalTypeChange}>
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="All Signals" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Signals</SelectItem>
            <SelectItem value="BUY">Buy</SelectItem>
            <SelectItem value="SELL">Sell</SelectItem>
            <SelectItem value="HOLD">Hold</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-muted-foreground">Sort By</Label>
        <Select value={sortBy} onValueChange={onSortByChange}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Newest First" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="created_at">Newest First</SelectItem>
            <SelectItem value="confidence">Highest Confidence</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};
