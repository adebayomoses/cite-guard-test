import { useSubscription } from '@/hooks/useSubscription';
import { Button } from '@/components/ui/button';
import { Crown, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

interface UpgradePromptProps {
  onUpgrade?: () => void;
  title?: string;
  description?: string;
  showAlways?: boolean;
}

export const UpgradePrompt = ({ 
  onUpgrade, 
  title = "Daily Limit Reached",
  description = "You've used your 2 free daily chart analyses. Upgrade to unlock more analyses and powerful features.",
  showAlways = false,
}: UpgradePromptProps) => {
  const { remainingAnalyses, isSubscribed } = useSubscription();

  if (!showAlways) {
    if (isSubscribed) return null;
    if (remainingAnalyses > 0) return null;
  }

  return (
    <div className="terminal-card p-6 md:p-8 text-center border-bearish/30 bg-bearish/5">
      <div className="w-16 h-16 bg-bearish/20 rounded-full flex items-center justify-center mx-auto mb-4">
        <Lock className="w-8 h-8 text-bearish" />
      </div>
      
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-muted-foreground mb-6">
        {description}
      </p>

      <Link to="/pricing" onClick={onUpgrade}>
        <Button size="lg" className="w-full bg-gradient-to-r from-primary to-bullish hover:opacity-90">
          <Crown className="w-5 h-5 mr-2" />
          View Pricing Plans
        </Button>
      </Link>
    </div>
  );
};

