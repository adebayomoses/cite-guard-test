import { useSubscription } from '@/hooks/useSubscription';
import { Button } from '@/components/ui/button';
import { Crown, Zap, Check, Loader2, ExternalLink, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

const TIER_DISPLAY = {
  free: { name: 'Free Plan', icon: Zap, color: 'text-muted-foreground', bgColor: 'bg-secondary' },
  social: { name: 'Social Plan', icon: Star, color: 'text-primary', bgColor: 'bg-primary/20' },
  standard: { name: 'Standard Plan', icon: Star, color: 'text-primary', bgColor: 'bg-primary/20' },
  pro: { name: 'Pro Plan', icon: Crown, color: 'text-primary', bgColor: 'bg-primary/20' },
} as const;

export const SubscriptionCard = () => {
  const { 
    isSubscribed, 
    subscriptionEnd, 
    dailyCount,
    dailyLimit,
    tier,
    remainingAnalyses,
    analysisCount,
    isLoading,
    openCustomerPortal,
  } = useSubscription();

  if (isLoading) {
    return (
      <div className="terminal-card p-4 md:p-6 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const tierInfo = TIER_DISPLAY[tier];
  const TierIcon = tierInfo.icon;
  const usedCount = dailyCount;
  const limitDisplay = dailyLimit;
  const usagePercent = Math.min(100, (usedCount / limitDisplay) * 100);

  if (isSubscribed) {
    return (
      <div className="terminal-card p-4 md:p-6 border-primary/30 bg-primary/5">
        <div className="flex items-center gap-3 mb-4">
          <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", tierInfo.bgColor)}>
            <TierIcon className={cn("w-5 h-5", tierInfo.color)} />
          </div>
          <div>
            <h3 className="font-bold">{tierInfo.name}</h3>
            <p className="text-xs text-muted-foreground">
              {dailyLimit} analyses/day
            </p>
          </div>
        </div>
        
        {/* Daily usage indicator */}
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Today's usage</span>
            <span className="font-mono font-bold">{dailyCount} / {dailyLimit}</span>
          </div>
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full transition-all duration-300",
                usagePercent >= 100 ? "bg-bearish" : usagePercent >= 80 ? "bg-hold" : "bg-bullish"
              )}
              style={{ width: `${usagePercent}%` }}
            />
          </div>
          {remainingAnalyses === 0 ? (
            <p className="text-xs text-bearish">Daily limit reached - resets at midnight</p>
          ) : (
            <p className="text-xs text-muted-foreground">{remainingAnalyses} analyses remaining today</p>
          )}
        </div>

        <div className="space-y-2 text-sm mb-4">
          <div className="flex items-center gap-2 text-bullish">
            <Check className="w-4 h-4" />
            <span>Full technical breakdowns</span>
          </div>
          <div className="flex items-center gap-2 text-bullish">
            <Check className="w-4 h-4" />
            <span>Multi-timeframe confluence</span>
          </div>
          {tier === 'pro' && (
            <>
              <div className="flex items-center gap-2 text-bullish">
                <Check className="w-4 h-4" />
                <span>Mentorship access</span>
              </div>
              <div className="flex items-center gap-2 text-bullish">
                <Check className="w-4 h-4" />
                <span>Trader support</span>
              </div>
            </>
          )}
        </div>

        {subscriptionEnd && (
          <p className="text-xs text-muted-foreground mb-4">
            Renews: {new Date(subscriptionEnd).toLocaleDateString()}
          </p>
        )}

        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={openCustomerPortal} className="flex-1">
            Manage <ExternalLink className="w-3.5 h-3.5 ml-1" />
          </Button>
          {tier === 'standard' && (
            <Link to="/pricing" className="flex-1">
              <Button variant="default" size="sm" className="w-full">
                Upgrade
              </Button>
            </Link>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="terminal-card p-4 md:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
            <Zap className="w-5 h-5 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-bold">Free Plan</h3>
            <p className="text-xs text-muted-foreground">Limited analyses</p>
          </div>
        </div>
      </div>

      {/* Usage indicator */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Analyses used</span>
          <span className="font-mono font-bold">{dailyCount} / {dailyLimit}</span>
        </div>
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div 
            className={cn(
              "h-full transition-all duration-300",
              usagePercent >= 100 ? "bg-bearish" : usagePercent >= 80 ? "bg-hold" : "bg-bullish"
            )}
            style={{ width: `${usagePercent}%` }}
          />
        </div>
        {remainingAnalyses === 0 ? (
          <p className="text-xs text-bearish">No free analyses remaining</p>
        ) : (
          <p className="text-xs text-muted-foreground">{remainingAnalyses} free {remainingAnalyses === 1 ? 'analysis' : 'analyses'} remaining</p>
        )}
      </div>

      {/* Upgrade CTA */}
      <div className="pt-2 border-t border-border">
        <div className="text-center mb-3">
          <p className="text-sm text-muted-foreground">Unlock more analyses</p>
        </div>
        <Link to="/pricing">
          <Button className="w-full bg-gradient-to-r from-primary to-bullish hover:opacity-90">
            <Crown className="w-4 h-4 mr-2" />
            View Plans
          </Button>
        </Link>
      </div>
    </div>
  );
};
