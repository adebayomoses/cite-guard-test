import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, ExternalLink, AlertCircle } from 'lucide-react';
import { useState } from 'react';

interface SubscriberInfo {
  email: string;
  tier: string;
  productId: string;
  status: string;
  startDate: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  customerId: string;
}

interface AdminSubscribersProps {
  subscribers: SubscriberInfo[];
  isLoading: boolean;
}

const STATUS_COLORS: Record<string, string> = {
  active: 'bg-bullish text-white',
  trialing: 'bg-primary text-primary-foreground',
  past_due: 'bg-hold text-hold-foreground',
  canceled: 'bg-muted text-muted-foreground',
  unpaid: 'bg-destructive text-destructive-foreground',
  incomplete: 'bg-hold text-hold-foreground',
  incomplete_expired: 'bg-muted text-muted-foreground',
};

const TIER_COLORS: Record<string, string> = {
  Social: 'bg-primary/20 text-primary border-primary/30',
  Standard: 'bg-primary/30 text-primary border-primary/40',
  Pro: 'bg-bullish/20 text-bullish border-bullish/30',
  Unknown: 'bg-muted text-muted-foreground border-muted',
};

export const AdminSubscribers = ({ subscribers, isLoading }: AdminSubscribersProps) => {
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredSubscribers = subscribers.filter(sub => {
    if (tierFilter !== 'all' && sub.tier !== tierFilter) return false;
    if (statusFilter !== 'all' && sub.status !== statusFilter) return false;
    return true;
  });

  const activeCount = subscribers.filter(s => s.status === 'active' || s.status === 'trialing').length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle>Subscribers</CardTitle>
            <CardDescription>
              {activeCount} active subscriptions • {subscribers.length} total
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Select value={tierFilter} onValueChange={setTierFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Filter tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="Social">Social</SelectItem>
                <SelectItem value="Standard">Standard</SelectItem>
                <SelectItem value="Pro">Pro</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="trialing">Trialing</SelectItem>
                <SelectItem value="past_due">Past Due</SelectItem>
                <SelectItem value="canceled">Canceled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredSubscribers.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <AlertCircle className="w-8 h-8 mx-auto mb-3 opacity-50" />
            <p>No subscribers found matching your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Tier</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Renews / Ends</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSubscribers.map((subscriber, index) => (
                  <TableRow key={`${subscriber.customerId}-${index}`}>
                    <TableCell className="font-medium">
                      <a 
                        href={`mailto:${subscriber.email}`}
                        className="text-primary hover:underline"
                      >
                        {subscriber.email}
                      </a>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={TIER_COLORS[subscriber.tier]}>
                        {subscriber.tier}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge className={STATUS_COLORS[subscriber.status] || 'bg-muted'}>
                          {subscriber.status.replace('_', ' ')}
                        </Badge>
                        {subscriber.cancelAtPeriodEnd && (
                          <span className="text-xs text-hold">Canceling</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(subscriber.startDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(subscriber.currentPeriodEnd).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        asChild
                      >
                        <a 
                          href={`https://dashboard.stripe.com/customers/${subscriber.customerId}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1"
                        >
                          Stripe
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
