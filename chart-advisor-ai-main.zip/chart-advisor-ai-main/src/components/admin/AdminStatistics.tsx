import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Activity, TrendingUp, UserPlus, Loader2 } from 'lucide-react';

interface AdminStatsData {
  totalUsers: number;
  totalAnalyses: number;
  activeToday: number;
  newUsersThisWeek: number;
  tierDistribution: Record<string, number>;
}

interface AdminStatisticsProps {
  stats: AdminStatsData | null;
  isLoading: boolean;
}

const StatCard = ({ 
  title, 
  value, 
  description, 
  icon: Icon,
  trend,
}: { 
  title: string; 
  value: number | string; 
  description: string;
  icon: React.ElementType;
  trend?: string;
}) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between pb-2">
      <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
        <Icon className="w-5 h-5 text-primary" />
      </div>
    </CardHeader>
    <CardContent>
      <div className="text-3xl font-bold">{value}</div>
      <p className="text-xs text-muted-foreground mt-1">{description}</p>
      {trend && (
        <p className="text-xs text-bullish mt-1">{trend}</p>
      )}
    </CardContent>
  </Card>
);

const TierDistributionChart = ({ distribution }: { distribution: Record<string, number> }) => {
  const total = Object.values(distribution).reduce((sum, count) => sum + count, 0);
  
  const tierColors: Record<string, string> = {
    'Free': 'bg-muted',
    'Social': 'bg-primary/60',
    'Standard': 'bg-primary',
    'Pro': 'bg-bullish',
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">User Distribution by Tier</CardTitle>
        <CardDescription>Breakdown of users across subscription tiers</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.entries(distribution).map(([tier, count]) => {
          const percentage = total > 0 ? (count / total) * 100 : 0;
          return (
            <div key={tier} className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="font-medium">{tier}</span>
                <span className="text-muted-foreground">{count} users ({percentage.toFixed(1)}%)</span>
              </div>
              <div className="h-2 bg-muted/30 rounded-full overflow-hidden">
                <div 
                  className={`h-full ${tierColors[tier] || 'bg-primary'} transition-all duration-500`}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export const AdminStatistics = ({ stats, isLoading }: AdminStatisticsProps) => {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        Failed to load statistics. Please try refreshing.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          description="Registered accounts"
          icon={Users}
        />
        <StatCard
          title="Total Analyses"
          value={stats.totalAnalyses.toLocaleString()}
          description="Charts analyzed all-time"
          icon={Activity}
        />
        <StatCard
          title="Active Today"
          value={stats.activeToday}
          description="Users with activity today"
          icon={TrendingUp}
        />
        <StatCard
          title="New This Week"
          value={stats.newUsersThisWeek}
          description="Users joined last 7 days"
          icon={UserPlus}
        />
      </div>

      <TierDistributionChart distribution={stats.tierDistribution} />
    </div>
  );
};
