import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Loader2, AlertCircle, Crown, CreditCard, User, Search } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface UserInfo {
  id: string;
  email: string;
  tier: string;
  source: 'stripe' | 'override' | 'free';
  created_at: string;
  override_expires_at?: string;
}

interface AdminUsersProps {
  users: UserInfo[];
  isLoading: boolean;
  onRefresh: () => void;
}

const TIER_COLORS: Record<string, string> = {
  Social: 'bg-primary/20 text-primary border-primary/30',
  Standard: 'bg-primary/30 text-primary border-primary/40',
  Pro: 'bg-bullish/20 text-bullish border-bullish/30',
  Free: 'bg-muted text-muted-foreground border-muted',
};

const SOURCE_ICONS: Record<string, React.ReactNode> = {
  stripe: <CreditCard className="w-3 h-3" />,
  override: <Crown className="w-3 h-3" />,
  free: <User className="w-3 h-3" />,
};

export const AdminUsers = ({ users, isLoading, onRefresh }: AdminUsersProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [assigningPlan, setAssigningPlan] = useState<string | null>(null);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTier = tierFilter === 'all' || user.tier === tierFilter;
    return matchesSearch && matchesTier;
  });

  const handleAssignPlan = async (userId: string, tier: string) => {
    setAssigningPlan(userId);
    
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      
      if (!token) {
        throw new Error('No session token');
      }

      const { data, error } = await supabase.functions.invoke('assign-plan', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: {
          user_id: userId,
          tier: tier.toLowerCase(),
        },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);
      
      toast.success(`Successfully assigned ${tier} plan`);
      onRefresh();
    } catch (error) {
      console.error('Error assigning plan:', error);
      toast.error('Failed to assign plan');
    } finally {
      setAssigningPlan(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle>Manage Users</CardTitle>
            <CardDescription>
              Assign subscription plans to users • {users.length} total users
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-[200px]"
              />
            </div>
            <Select value={tierFilter} onValueChange={setTierFilter}>
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder="Filter tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tiers</SelectItem>
                <SelectItem value="Free">Free</SelectItem>
                <SelectItem value="Social">Social</SelectItem>
                <SelectItem value="Standard">Standard</SelectItem>
                <SelectItem value="Pro">Pro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredUsers.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <AlertCircle className="w-8 h-8 mx-auto mb-3 opacity-50" />
            <p>No users found matching your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Current Tier</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Assign Plan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      <a 
                        href={`mailto:${user.email}`}
                        className="text-primary hover:underline"
                      >
                        {user.email}
                      </a>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={TIER_COLORS[user.tier] || TIER_COLORS.Free}>
                        {user.tier}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
                        {SOURCE_ICONS[user.source]}
                        <span className="capitalize">{user.source}</span>
                        {user.source === 'override' && user.override_expires_at && (
                          <span className="text-xs">
                            (expires {new Date(user.override_expires_at).toLocaleDateString()})
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(user.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Select
                          disabled={assigningPlan === user.id}
                          onValueChange={(value) => handleAssignPlan(user.id, value)}
                        >
                          <SelectTrigger className="w-[130px]">
                            {assigningPlan === user.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <SelectValue placeholder="Assign..." />
                            )}
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Free">Free</SelectItem>
                            <SelectItem value="Social">Social ($4/mo)</SelectItem>
                            <SelectItem value="Standard">Standard ($10/mo)</SelectItem>
                            <SelectItem value="Pro">Pro ($25/mo)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
