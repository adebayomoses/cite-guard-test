import { X, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChartUpload } from '@/types/analysis';
import { cn } from '@/lib/utils';

interface ChartPreviewProps {
  upload: ChartUpload;
  onRemove: (id: string) => void;
  onTimeframeChange: (id: string, timeframe: string) => void;
  onAnalyze: (id: string) => void;
}

const timeframes = [
  { value: '1m', label: '1M' },
  { value: '5m', label: '5M' },
  { value: '15m', label: '15M' },
  { value: '30m', label: '30M' },
  { value: '1h', label: '1H' },
  { value: '4h', label: '4H' },
  { value: '1d', label: '1D' },
  { value: '1w', label: '1W' },
];

export const ChartPreview = ({
  upload,
  onRemove,
  onTimeframeChange,
  onAnalyze,
}: ChartPreviewProps) => {
  return (
    <div className={cn(
      'terminal-card overflow-hidden transition-all',
      upload.analysis && upload.analysis.signal === 'BUY' && 'ring-2 ring-bullish/50',
      upload.analysis && upload.analysis.signal === 'SELL' && 'ring-2 ring-bearish/50',
      upload.analysis && upload.analysis.signal === 'HOLD' && 'ring-2 ring-hold/50',
    )}>
      <div className="relative aspect-video">
        <img
          src={upload.preview}
          alt="Chart"
          className="w-full h-full object-cover"
        />
        
        {/* Overlay during analysis */}
        {upload.isAnalyzing && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <Loader2 className="w-10 h-10 animate-spin text-primary" />
              <span className="text-sm font-mono">Analyzing chart...</span>
            </div>
          </div>
        )}

        {/* Remove button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-background/80 hover:bg-background"
          onClick={() => onRemove(upload.id)}
        >
          <X className="w-4 h-4" />
        </Button>

        {/* Signal badge */}
        {upload.analysis && (
          <div className={cn(
            'absolute top-2 left-2 px-3 py-1 rounded font-mono font-bold text-sm',
            upload.analysis.signal === 'BUY' && 'bg-bullish text-bullish-foreground',
            upload.analysis.signal === 'SELL' && 'bg-bearish text-bearish-foreground',
            upload.analysis.signal === 'HOLD' && 'bg-hold text-hold-foreground',
          )}>
            {upload.analysis.signal}
          </div>
        )}
      </div>

      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <Select
            value={upload.timeframe}
            onValueChange={(tf) => onTimeframeChange(upload.id, tf)}
            disabled={upload.isAnalyzing}
          >
            <SelectTrigger className="w-24 h-8 bg-secondary text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {timeframes.map(tf => (
                <SelectItem key={tf.value} value={tf.value}>
                  {tf.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            size="sm"
            variant={upload.analysis ? 'outline' : 'default'}
            onClick={() => onAnalyze(upload.id)}
            disabled={upload.isAnalyzing}
            className="h-8"
          >
            {upload.isAnalyzing ? (
              <Loader2 className="w-4 h-4 animate-spin mr-1" />
            ) : upload.analysis ? (
              <RefreshCw className="w-4 h-4 mr-1" />
            ) : null}
            {upload.analysis ? 'Re-analyze' : 'Analyze'}
          </Button>
        </div>

        {upload.error && (
          <p className="text-xs text-bearish">{upload.error}</p>
        )}

        {upload.analysis && (
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Confidence</span>
              <div className="flex items-center gap-2">
                <div className="w-20 h-2 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      'h-full rounded-full transition-all',
                      upload.analysis.confidence >= 70 && 'bg-bullish',
                      upload.analysis.confidence >= 40 && upload.analysis.confidence < 70 && 'bg-hold',
                      upload.analysis.confidence < 40 && 'bg-bearish',
                    )}
                    style={{ width: `${upload.analysis.confidence}%` }}
                  />
                </div>
                <span className="font-mono">{upload.analysis.confidence}%</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
