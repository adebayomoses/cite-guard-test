import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RiskCalculation } from '@/types/analysis';
import { Calculator, DollarSign, AlertTriangle } from 'lucide-react';

interface RiskCalculatorProps {
  entryPrice?: string;
  stopLoss?: string;
  takeProfit?: string;
}

export const RiskCalculator = ({ 
  entryPrice: defaultEntry, 
  stopLoss: defaultSL, 
  takeProfit: defaultTP 
}: RiskCalculatorProps) => {
  const [accountSize, setAccountSize] = useState(10000);
  const [riskPercentage, setRiskPercentage] = useState(2);
  const [entryPrice, setEntryPrice] = useState(parseFloat(defaultEntry || '0') || 0);
  const [stopLoss, setStopLoss] = useState(parseFloat(defaultSL || '0') || 0);
  const [takeProfit, setTakeProfit] = useState(parseFloat(defaultTP || '0') || 0);
  const [calculation, setCalculation] = useState<RiskCalculation | null>(null);

  useEffect(() => {
    setEntryPrice(parseFloat(defaultEntry || '0') || 0);
    setStopLoss(parseFloat(defaultSL || '0') || 0);
    setTakeProfit(parseFloat(defaultTP || '0') || 0);
  }, [defaultEntry, defaultSL, defaultTP]);

  useEffect(() => {
    if (accountSize > 0 && entryPrice > 0 && stopLoss > 0 && takeProfit > 0) {
      const riskAmount = accountSize * (riskPercentage / 100);
      const pipValue = Math.abs(entryPrice - stopLoss);
      const positionSize = pipValue > 0 ? riskAmount / pipValue : 0;
      
      const potentialLoss = riskAmount;
      const potentialProfit = positionSize * Math.abs(takeProfit - entryPrice);
      const riskRewardRatio = potentialLoss > 0 ? potentialProfit / potentialLoss : 0;

      setCalculation({
        accountSize,
        riskPercentage,
        entryPrice,
        stopLoss,
        takeProfit,
        positionSize,
        potentialLoss,
        potentialProfit,
        riskRewardRatio,
      });
    } else {
      setCalculation(null);
    }
  }, [accountSize, riskPercentage, entryPrice, stopLoss, takeProfit]);

  return (
    <div className="terminal-card p-4 md:p-6 space-y-4 md:space-y-6">
      <div className="flex items-center gap-3">
        <Calculator className="w-5 h-5 md:w-6 md:h-6 text-primary" />
        <h3 className="text-base md:text-lg font-bold">Risk Calculator</h3>
      </div>

      <div className="grid grid-cols-2 gap-3 md:gap-4">
        <div className="space-y-1.5 md:space-y-2">
          <Label htmlFor="accountSize" className="text-xs md:text-sm">Account Size ($)</Label>
          <Input
            id="accountSize"
            type="number"
            value={accountSize}
            onChange={(e) => setAccountSize(parseFloat(e.target.value) || 0)}
            className="font-mono text-sm"
          />
        </div>
        <div className="space-y-1.5 md:space-y-2">
          <Label htmlFor="riskPercentage" className="text-xs md:text-sm">Risk per Trade (%)</Label>
          <Input
            id="riskPercentage"
            type="number"
            step="0.5"
            min="0.5"
            max="10"
            value={riskPercentage}
            onChange={(e) => setRiskPercentage(parseFloat(e.target.value) || 0)}
            className="font-mono text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 md:gap-4">
        <div className="space-y-1.5 md:space-y-2">
          <Label htmlFor="entryPrice" className="text-xs md:text-sm">Entry</Label>
          <Input
            id="entryPrice"
            type="number"
            step="0.00001"
            value={entryPrice || ''}
            onChange={(e) => setEntryPrice(parseFloat(e.target.value) || 0)}
            className="font-mono text-sm"
          />
        </div>
        <div className="space-y-1.5 md:space-y-2">
          <Label htmlFor="stopLoss" className="text-xs md:text-sm">Stop Loss</Label>
          <Input
            id="stopLoss"
            type="number"
            step="0.00001"
            value={stopLoss || ''}
            onChange={(e) => setStopLoss(parseFloat(e.target.value) || 0)}
            className="font-mono text-sm"
          />
        </div>
        <div className="space-y-1.5 md:space-y-2">
          <Label htmlFor="takeProfit" className="text-xs md:text-sm">Take Profit</Label>
          <Input
            id="takeProfit"
            type="number"
            step="0.00001"
            value={takeProfit || ''}
            onChange={(e) => setTakeProfit(parseFloat(e.target.value) || 0)}
            className="font-mono text-sm"
          />
        </div>
      </div>

      {calculation && (
        <div className="space-y-3 md:space-y-4 pt-3 md:pt-4 border-t border-border">
          <div className="grid grid-cols-2 gap-2 md:gap-4">
            <div className="bg-secondary/50 rounded-lg p-2.5 md:p-4">
              <p className="text-[10px] md:text-xs text-muted-foreground mb-0.5 md:mb-1">Position Size</p>
              <p className="font-mono font-bold text-sm md:text-lg">
                {calculation.positionSize.toFixed(2)} units
              </p>
            </div>
            <div className="bg-secondary/50 rounded-lg p-2.5 md:p-4">
              <p className="text-[10px] md:text-xs text-muted-foreground mb-0.5 md:mb-1">Risk/Reward</p>
              <p className="font-mono font-bold text-sm md:text-lg">
                1:{calculation.riskRewardRatio.toFixed(2)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 md:gap-4">
            <div className="bg-bearish/10 rounded-lg p-2.5 md:p-4 border border-bearish/20">
              <div className="flex items-center gap-1.5 md:gap-2 mb-0.5 md:mb-1">
                <AlertTriangle className="w-3 h-3 md:w-4 md:h-4 text-bearish" />
                <p className="text-[10px] md:text-xs text-muted-foreground">Potential Loss</p>
              </div>
              <p className="font-mono font-bold text-sm md:text-lg text-bearish">
                ${calculation.potentialLoss.toFixed(2)}
              </p>
              <p className="text-[10px] md:text-xs text-muted-foreground">
                {calculation.riskPercentage}% of account
              </p>
            </div>
            <div className="bg-bullish/10 rounded-lg p-2.5 md:p-4 border border-bullish/20">
              <div className="flex items-center gap-1.5 md:gap-2 mb-0.5 md:mb-1">
                <DollarSign className="w-3 h-3 md:w-4 md:h-4 text-bullish" />
                <p className="text-[10px] md:text-xs text-muted-foreground">Potential Profit</p>
              </div>
              <p className="font-mono font-bold text-sm md:text-lg text-bullish">
                ${calculation.potentialProfit.toFixed(2)}
              </p>
              <p className="text-[10px] md:text-xs text-muted-foreground">
                {((calculation.potentialProfit / calculation.accountSize) * 100).toFixed(2)}% of account
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
