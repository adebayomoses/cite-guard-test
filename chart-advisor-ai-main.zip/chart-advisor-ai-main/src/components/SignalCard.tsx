import { SharedSignal } from '@/types/signal';
import { TrendingUp, TrendingDown, Minus, Target, Shield, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

interface SignalCardProps {
  signal: SharedSignal;
}

const assetTypeLabels: Record<string, string> = {
  forex: 'Forex',
  crypto: 'Crypto',
  commodities: 'Commodities',
  indices: 'Indices',
  stocks: 'Stocks',
};

export const SignalCard = ({ signal }: SignalCardProps) => {
  const SignalIcon = signal.signal === 'BUY' ? TrendingUp : 
                     signal.signal === 'SELL' ? TrendingDown : Minus;

  const timeAgo = formatDistanceToNow(new Date(signal.created_at), { addSuffix: true });

  return (
    <div className="terminal-card p-4 space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={cn(
            'w-10 h-10 rounded-lg flex items-center justify-center shrink-0',
            signal.signal === 'BUY' && 'bg-bullish/20 text-bullish',
            signal.signal === 'SELL' && 'bg-bearish/20 text-bearish',
            signal.signal === 'HOLD' && 'bg-hold/20 text-hold',
          )}>
            <SignalIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className={cn(
              'text-lg font-bold font-mono',
              signal.signal === 'BUY' && 'text-bullish',
              signal.signal === 'SELL' && 'text-bearish',
              signal.signal === 'HOLD' && 'text-hold',
            )}>
              {signal.signal}
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {assetTypeLabels[signal.asset_type] || signal.asset_type}
              </Badge>
              <Badge variant="outline" className="text-xs">
                {signal.timeframe}
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-xl font-bold font-mono">{signal.confidence}%</div>
          <p className="text-xs text-muted-foreground">Confidence</p>
        </div>
      </div>

      {/* Price Levels */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-secondary/50 rounded-lg p-2 text-center">
          <Target className="w-4 h-4 mx-auto mb-1 text-bullish" />
          <p className="text-[10px] text-muted-foreground">Entry</p>
          <p className="font-mono font-bold text-xs truncate">{signal.entry_price}</p>
        </div>
        <div className="bg-secondary/50 rounded-lg p-2 text-center">
          <Shield className="w-4 h-4 mx-auto mb-1 text-bearish" />
          <p className="text-[10px] text-muted-foreground">Stop Loss</p>
          <p className="font-mono font-bold text-xs text-bearish truncate">{signal.stop_loss}</p>
        </div>
        <div className="bg-secondary/50 rounded-lg p-2 text-center">
          <TrendingUp className="w-4 h-4 mx-auto mb-1 text-bullish" />
          <p className="text-[10px] text-muted-foreground">Take Profit</p>
          <p className="font-mono font-bold text-xs text-bullish truncate">{signal.take_profit}</p>
        </div>
      </div>

      {/* Risk Reward */}
      <div className="flex items-center justify-between bg-secondary/30 rounded-lg p-2">
        <span className="text-xs text-muted-foreground">R:R Ratio</span>
        <span className="font-mono font-bold text-sm">{signal.risk_reward_ratio}</span>
      </div>

      {/* Patterns */}
      {signal.patterns && signal.patterns.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {signal.patterns.slice(0, 3).map((pattern, i) => (
            <span key={i} className="px-2 py-0.5 bg-secondary rounded text-[10px] font-mono">
              {pattern}
            </span>
          ))}
          {signal.patterns.length > 3 && (
            <span className="px-2 py-0.5 bg-secondary rounded text-[10px] text-muted-foreground">
              +{signal.patterns.length - 3} more
            </span>
          )}
        </div>
      )}

      {/* Summary */}
      <p className="text-xs text-muted-foreground line-clamp-2">
        {signal.summary}
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between pt-2 border-t border-border">
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>{timeAgo}</span>
        </div>
        {signal.trend && (
          <span className="text-xs text-muted-foreground">
            Trend: {signal.trend}
          </span>
        )}
      </div>
    </div>
  );
};
