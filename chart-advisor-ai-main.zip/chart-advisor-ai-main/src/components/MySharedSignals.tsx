import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { SharedSignal } from '@/types/signal';
import { Share2, TrendingUp, TrendingDown, Minus, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { formatDistanceToNow } from 'date-fns';

const assetTypeLabels: Record<string, string> = {
  forex: 'Forex',
  crypto: 'Crypto',
  commodities: 'Commodities',
  indices: 'Indices',
  stocks: 'Stocks',
};

export const MySharedSignals = () => {
  const { user } = useAuth();
  const [signals, setSignals] = useState<SharedSignal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!user) return;

    const fetchMySignals = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('shared_signals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (!error && data) {
        setSignals(data as SharedSignal[]);
      }
      setLoading(false);
    };

    fetchMySignals();

    // Subscribe to changes
    const channel = supabase
      .channel('my_signals_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'shared_signals',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          setSignals((prev) => [payload.new as SharedSignal, ...prev].slice(0, 10));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  if (!user) return null;

  const SignalIcon = ({ signal }: { signal: string }) => {
    if (signal === 'BUY') return <TrendingUp className="w-3 h-3" />;
    if (signal === 'SELL') return <TrendingDown className="w-3 h-3" />;
    return <Minus className="w-3 h-3" />;
  };

  return (
    <div className="terminal-card p-4">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
            <div className="flex items-center gap-2">
              <Share2 className="w-4 h-4 text-primary" />
              <h3 className="font-medium text-sm">My Shared Signals</h3>
              <Badge variant="secondary" className="text-xs">
                {signals.length}
              </Badge>
            </div>
            {isOpen ? (
              <ChevronUp className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            )}
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent className="mt-3">
          {loading ? (
            <p className="text-xs text-muted-foreground text-center py-4">Loading...</p>
          ) : signals.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-4">
              You haven't shared any signals yet. Analyze a chart and click "Share Signal" to contribute!
            </p>
          ) : (
            <div className="space-y-2">
              {signals.map((signal) => {
                const isExpired = new Date(signal.expires_at) < new Date();
                const timeAgo = formatDistanceToNow(new Date(signal.created_at), { addSuffix: true });

                return (
                  <div
                    key={signal.id}
                    className={cn(
                      'flex items-center justify-between p-2 rounded-lg bg-secondary/30',
                      isExpired && 'opacity-50'
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        'w-6 h-6 rounded flex items-center justify-center',
                        signal.signal === 'BUY' && 'bg-bullish/20 text-bullish',
                        signal.signal === 'SELL' && 'bg-bearish/20 text-bearish',
                        signal.signal === 'HOLD' && 'bg-hold/20 text-hold',
                      )}>
                        <SignalIcon signal={signal.signal} />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={cn(
                            'text-xs font-bold font-mono',
                            signal.signal === 'BUY' && 'text-bullish',
                            signal.signal === 'SELL' && 'text-bearish',
                            signal.signal === 'HOLD' && 'text-hold',
                          )}>
                            {signal.signal}
                          </span>
                          <Badge variant="outline" className="text-[10px] px-1 py-0">
                            {assetTypeLabels[signal.asset_type]}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground">
                            {signal.timeframe}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                          <Clock className="w-2.5 h-2.5" />
                          {timeAgo}
                          {isExpired && <span className="text-bearish ml-1">(expired)</span>}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold font-mono">{signal.confidence}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};
