import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { X, Download, Smartphone } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const InstallBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    // Check if already dismissed or installed
    const isDismissed = localStorage.getItem('install-banner-dismissed');
    const isInstalled = window.matchMedia('(display-mode: standalone)').matches;
    
    // Only show on mobile/tablet
    const isMobileOrTablet = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || 
                             window.innerWidth < 1024;

    if (isDismissed || isInstalled || !isMobileOrTablet) {
      return;
    }

    // Listen for install prompt (Android/Chrome)
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setIsVisible(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // For iOS, show after a short delay
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    if (isIOS) {
      const timer = setTimeout(() => setIsVisible(true), 2000);
      return () => {
        clearTimeout(timer);
        window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      };
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        handleDismiss();
      }
      setDeferredPrompt(null);
    }
  };

  const handleDismiss = () => {
    setIsVisible(false);
    localStorage.setItem('install-banner-dismissed', 'true');
  };

  if (!isVisible) return null;

  return (
    <div className="bg-gradient-to-r from-primary/20 to-bullish/20 border border-primary/30 rounded-lg p-3 md:p-4 mb-4 md:mb-6 animate-in slide-in-from-top-2 duration-300">
      <div className="flex items-center gap-3 md:gap-4">
        <div className="w-10 h-10 md:w-12 md:h-12 bg-primary rounded-xl flex items-center justify-center shrink-0">
          <Smartphone className="w-5 h-5 md:w-6 md:h-6 text-primary-foreground" />
        </div>
        
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm md:text-base">Install UpTraView AI</p>
          <p className="text-xs md:text-sm text-muted-foreground truncate">
            Add to home screen for quick access
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {deferredPrompt ? (
            <Button size="sm" onClick={handleInstall} className="text-xs md:text-sm">
              <Download className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" />
              Install
            </Button>
          ) : (
            <Link to="/install">
              <Button size="sm" className="text-xs md:text-sm">
                <Download className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" />
                Install
              </Button>
            </Link>
          )}
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleDismiss}
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
