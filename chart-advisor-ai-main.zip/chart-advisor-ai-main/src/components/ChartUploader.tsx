import { useCallback, useState } from 'react';
import { Upload, Image as ImageIcon, MessageSquare, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import { AssetType } from '@/types/analysis';

interface ChartUploaderProps {
  onUpload: (file: File, timeframe: string, assetType: AssetType, traderNotes?: string) => void;
}

const timeframes = [
  { value: '1m', label: '1 Minute' },
  { value: '5m', label: '5 Minutes' },
  { value: '15m', label: '15 Minutes' },
  { value: '30m', label: '30 Minutes' },
  { value: '1h', label: '1 Hour' },
  { value: '4h', label: '4 Hours' },
  { value: '1d', label: 'Daily' },
  { value: '1w', label: 'Weekly' },
];

const assetTypes = [
  { value: 'forex', label: 'Forex', examples: 'EUR/USD, GBP/JPY' },
  { value: 'crypto', label: 'Crypto', examples: 'BTC/USD, ETH/USD' },
  { value: 'commodities', label: 'Commodities', examples: 'XAU/USD, WTI Oil' },
  { value: 'indices', label: 'Indices', examples: 'S&P 500, NASDAQ' },
  { value: 'stocks', label: 'Stocks', examples: 'AAPL, TSLA, NVDA' },
];

const MAX_NOTES_LENGTH = 500;

export const ChartUploader = ({ onUpload }: ChartUploaderProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');
  const [selectedAssetType, setSelectedAssetType] = useState<AssetType>('forex');
  const [traderNotes, setTraderNotes] = useState('');
  const [isNotesOpen, setIsNotesOpen] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => {
      if (file.type.startsWith('image/')) {
        onUpload(file, selectedTimeframe, selectedAssetType, traderNotes || undefined);
      }
    });
    // Clear notes after upload
    setTraderNotes('');
    setIsNotesOpen(false);
  }, [onUpload, selectedTimeframe, selectedAssetType, traderNotes]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      if (file.type.startsWith('image/')) {
        onUpload(file, selectedTimeframe, selectedAssetType, traderNotes || undefined);
      }
    });
    e.target.value = '';
    // Clear notes after upload
    setTraderNotes('');
    setIsNotesOpen(false);
  }, [onUpload, selectedTimeframe, selectedAssetType, traderNotes]);

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= MAX_NOTES_LENGTH) {
      setTraderNotes(value);
    }
  };

  return (
    <div className="space-y-3 md:space-y-4">
      <div className="flex flex-wrap items-center gap-2 md:gap-4">
        <Select value={selectedAssetType} onValueChange={(value) => setSelectedAssetType(value as AssetType)}>
          <SelectTrigger className="w-[110px] md:w-[140px] bg-secondary text-sm">
            <SelectValue placeholder="Asset type" />
          </SelectTrigger>
          <SelectContent>
            {assetTypes.map(at => (
              <SelectItem key={at.value} value={at.value}>
                {at.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
          <SelectTrigger className="w-[110px] md:w-[150px] bg-secondary text-sm">
            <SelectValue placeholder="Timeframe" />
          </SelectTrigger>
          <SelectContent>
            {timeframes.map(tf => (
              <SelectItem key={tf.value} value={tf.value}>
                {tf.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <span className="text-xs md:text-sm text-muted-foreground hidden sm:inline">
          {assetTypes.find(a => a.value === selectedAssetType)?.examples}
        </span>
      </div>

      <div
        className={cn(
          'upload-zone cursor-pointer flex flex-col items-center justify-center min-h-[150px] md:min-h-[200px] transition-all',
          isDragging && 'border-primary bg-primary/5 scale-[1.02]'
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => document.getElementById('chart-upload')?.click()}
      >
        <input
          id="chart-upload"
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={handleFileInput}
        />
        
        <div className="flex flex-col items-center gap-3 md:gap-4 text-muted-foreground p-4">
          <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-secondary flex items-center justify-center">
            <Upload className="w-6 h-6 md:w-8 md:h-8" />
          </div>
          <div className="text-center">
            <p className="text-base md:text-lg font-medium text-foreground">
              Drop chart images here
            </p>
            <p className="text-xs md:text-sm">
              or tap to browse files
            </p>
          </div>
          <div className="flex items-center gap-2 text-[10px] md:text-xs">
            <ImageIcon className="w-3 h-3 md:w-4 md:h-4" />
            <span>PNG, JPG, WEBP</span>
          </div>
        </div>
      </div>

      {/* Trader Notes Section */}
      <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
        <CollapsibleTrigger asChild>
          <Button 
            variant="ghost" 
            className="w-full flex items-center justify-between p-3 h-auto hover:bg-secondary/50"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MessageSquare className="w-4 h-4" />
              <span>Add Your Analysis Notes (Optional)</span>
            </div>
            {isNotesOpen ? (
              <ChevronUp className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            )}
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-2 pt-2">
          <Textarea
            placeholder="Share your thoughts on this chart... What patterns do you see? Where do you think the entry should be? What's your trade idea?"
            value={traderNotes}
            onChange={handleNotesChange}
            className="min-h-[100px] bg-secondary/30 resize-none"
            onClick={(e) => e.stopPropagation()}
          />
          <div className="flex justify-between items-center text-xs text-muted-foreground px-1">
            <span>The AI will consider your analysis and provide feedback</span>
            <span className={cn(
              traderNotes.length > MAX_NOTES_LENGTH * 0.9 && 'text-destructive'
            )}>
              {traderNotes.length}/{MAX_NOTES_LENGTH}
            </span>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};
