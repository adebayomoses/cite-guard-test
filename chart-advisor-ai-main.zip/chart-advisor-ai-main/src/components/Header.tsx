import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useSubscription } from '@/hooks/useSubscription';
import { useAdmin } from '@/hooks/useAdmin';
import { useNewSignalsCount } from '@/hooks/useNewSignalsCount';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { TrendingUp, LogOut, LayoutDashboard, Menu, CreditCard, MessageCircle, Shield, Radio } from 'lucide-react';

export const Header = () => {
  const { user, signOut } = useAuth();
  const { tier } = useSubscription();
  const { isAdmin } = useAdmin();
  const { count: newSignalsCount } = useNewSignalsCount();
  const [open, setOpen] = useState(false);
  const isPro = tier === 'pro';

  // Desktop Navigation - Order: Dashboard, Signals, Pricing, Sign Out
  const DesktopNav = () => (
    <>
      {user && (
        <Link to="/dashboard">
          <Button variant="ghost" size="sm">
            <LayoutDashboard className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </Link>
      )}
      {user && (
        <Link to="/signals">
          <Button variant="ghost" size="sm" className="relative">
            <Radio className="w-4 h-4 mr-2" />
            Signals
            {newSignalsCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-1 -right-1 h-5 min-w-5 px-1.5 text-xs flex items-center justify-center"
              >
                {newSignalsCount > 9 ? '9+' : newSignalsCount}
              </Badge>
            )}
          </Button>
        </Link>
      )}
      <Link to="/pricing">
        <Button variant="ghost" size="sm">
          <CreditCard className="w-4 h-4 mr-2" />
          Pricing
        </Button>
      </Link>
      {isPro && (
        <Link to="/contact">
          <Button variant="ghost" size="sm">
            <MessageCircle className="w-4 h-4 mr-2" />
            Support
          </Button>
        </Link>
      )}
      <ThemeToggle />
      {user ? (
        <>
          {isAdmin && (
            <Link to="/admin">
              <Button variant="ghost" size="sm" className="text-primary">
                <Shield className="w-4 h-4 mr-2" />
                Admin
              </Button>
            </Link>
          )}
          <Button variant="outline" size="sm" onClick={signOut}>
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </>
      ) : (
        <>
          <Link to="/login">
            <Button variant="ghost" size="sm">Sign In</Button>
          </Link>
          <Link to="/signup">
            <Button size="sm">Get Started</Button>
          </Link>
        </>
      )}
    </>
  );

  // Mobile Navigation - Ordered: Theme, Dashboard, Signals, Sign Out
  const MobileNav = () => (
    <>
      {user ? (
        <>
          <ThemeToggle showLabel onToggle={() => setOpen(false)} />
          <Link to="/dashboard" onClick={() => setOpen(false)}>
            <Button variant="ghost" size="sm" className="w-full justify-start">
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </Link>
          <Link to="/signals" onClick={() => setOpen(false)}>
            <Button variant="ghost" size="sm" className="w-full justify-start relative">
              <Radio className="w-4 h-4 mr-2" />
              Signals
              {newSignalsCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="ml-auto h-5 min-w-5 px-1.5 text-xs"
                >
                  {newSignalsCount > 9 ? '9+' : newSignalsCount}
                </Badge>
              )}
            </Button>
          </Link>
          <Link to="/pricing" onClick={() => setOpen(false)}>
            <Button variant="ghost" size="sm" className="w-full justify-start">
              <CreditCard className="w-4 h-4 mr-2" />
              Pricing
            </Button>
          </Link>
          <Button variant="outline" size="sm" onClick={() => { signOut(); setOpen(false); }} className="w-full justify-start">
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </>
      ) : (
        <>
          <ThemeToggle showLabel onToggle={() => setOpen(false)} />
          <Link to="/pricing" onClick={() => setOpen(false)}>
            <Button variant="ghost" size="sm" className="w-full justify-start">
              <CreditCard className="w-4 h-4 mr-2" />
              Pricing
            </Button>
          </Link>
          <Link to="/login" onClick={() => setOpen(false)}>
            <Button variant="ghost" size="sm" className="w-full justify-start">Sign In</Button>
          </Link>
          <Link to="/signup" onClick={() => setOpen(false)}>
            <Button size="sm" className="w-full">Get Started</Button>
          </Link>
        </>
      )}
    </>
  );

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container flex items-center justify-between h-14 md:h-16 px-4">
        <Link to="/" className="flex items-center gap-2 md:gap-3">
          <div className="w-8 h-8 md:w-10 md:h-10 bg-primary rounded-lg flex items-center justify-center">
            <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-primary-foreground" />
          </div>
          <span className="font-bold text-lg md:text-xl">UpTraView AI</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-3">
          <DesktopNav />
        </div>

        {/* Mobile Navigation */}
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-64">
            <div className="flex flex-col gap-4 mt-8">
              <MobileNav />
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};
