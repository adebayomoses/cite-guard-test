import { useState } from 'react';
import { AnalysisResult, AssetType } from '@/types/analysis';
import { TrendingUp, TrendingDown, Minus, Target, Shield, Share2, Check, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from '@/hooks/use-toast';

interface AnalysisCardProps {
  analysis: AnalysisResult;
  timeframe: string;
  assetType?: AssetType;
}

export const AnalysisCard = ({ analysis, timeframe, assetType = 'forex' }: AnalysisCardProps) => {
  const { user } = useAuth();
  const [isSharing, setIsSharing] = useState(false);
  const [isShared, setIsShared] = useState(false);

  const SignalIcon = analysis.signal === 'BUY' ? TrendingUp : 
                     analysis.signal === 'SELL' ? TrendingDown : Minus;

  const handleShare = async () => {
    if (!user || isShared) return;

    setIsSharing(true);
    try {
      const { data, error } = await supabase.functions.invoke('share-signal', {
        body: {
          signal: analysis.signal,
          confidence: analysis.confidence,
          assetType: assetType,
          timeframe: timeframe,
          entryPrice: analysis.entryPrice,
          stopLoss: analysis.stopLoss,
          takeProfit: analysis.takeProfit,
          riskRewardRatio: analysis.riskRewardRatio,
          patterns: analysis.technicalBreakdown.patterns,
          trend: analysis.technicalBreakdown.trend,
          momentum: analysis.technicalBreakdown.momentum,
          summary: analysis.summary,
        },
      });

      if (error) throw error;

      setIsShared(true);
      toast({
        title: 'Signal Shared!',
        description: 'Your signal is now visible to the community.',
      });
    } catch (error) {
      console.error('Error sharing signal:', error);
      toast({
        title: 'Failed to share',
        description: 'Could not share the signal. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSharing(false);
    }
  };

  return (
    <div className="terminal-card p-4 md:p-6 space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 md:gap-4">
          <div className={cn(
            'w-12 h-12 md:w-14 md:h-14 rounded-lg flex items-center justify-center shrink-0',
            analysis.signal === 'BUY' && 'bg-bullish/20 text-bullish',
            analysis.signal === 'SELL' && 'bg-bearish/20 text-bearish',
            analysis.signal === 'HOLD' && 'bg-hold/20 text-hold',
          )}>
            <SignalIcon className="w-6 h-6 md:w-8 md:h-8" />
          </div>
          <div>
            <h3 className={cn(
              'text-xl md:text-2xl font-bold font-mono',
              analysis.signal === 'BUY' && 'text-bullish',
              analysis.signal === 'SELL' && 'text-bearish',
              analysis.signal === 'HOLD' && 'text-hold',
            )}>
              {analysis.signal}
            </h3>
            <p className="text-xs md:text-sm text-muted-foreground">{timeframe} Analysis</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-2xl md:text-3xl font-bold font-mono">{analysis.confidence}%</div>
          <p className="text-xs md:text-sm text-muted-foreground">Confidence</p>
        </div>
      </div>

      {/* Price Levels */}
      <div className="grid grid-cols-3 gap-2 md:gap-4">
        <div className="bg-secondary/50 rounded-lg p-2 md:p-4 text-center">
          <Target className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1 md:mb-2 text-bullish" />
          <p className="text-[10px] md:text-xs text-muted-foreground mb-0.5 md:mb-1">Entry</p>
          <p className="font-mono font-bold text-xs md:text-base truncate">{analysis.entryPrice}</p>
        </div>
        <div className="bg-secondary/50 rounded-lg p-2 md:p-4 text-center">
          <Shield className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1 md:mb-2 text-bearish" />
          <p className="text-[10px] md:text-xs text-muted-foreground mb-0.5 md:mb-1">Stop Loss</p>
          <p className="font-mono font-bold text-xs md:text-base text-bearish truncate">{analysis.stopLoss}</p>
        </div>
        <div className="bg-secondary/50 rounded-lg p-2 md:p-4 text-center">
          <TrendingUp className="w-4 h-4 md:w-5 md:h-5 mx-auto mb-1 md:mb-2 text-bullish" />
          <p className="text-[10px] md:text-xs text-muted-foreground mb-0.5 md:mb-1">Take Profit</p>
          <p className="font-mono font-bold text-xs md:text-base text-bullish truncate">{analysis.takeProfit}</p>
        </div>
      </div>

      {/* Risk Reward */}
      <div className="flex items-center justify-between bg-secondary/30 rounded-lg p-3 md:p-4">
        <span className="text-xs md:text-sm text-muted-foreground">Risk/Reward Ratio</span>
        <span className="font-mono font-bold text-base md:text-lg">{analysis.riskRewardRatio}</span>
      </div>

      {/* Summary */}
      <div className="border-t border-border pt-4">
        <h4 className="font-medium mb-2">Analysis Summary</h4>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {analysis.summary}
        </p>
      </div>

      {/* Technical Breakdown */}
      <div className="space-y-3 md:space-y-4">
        <h4 className="font-medium text-sm md:text-base">Technical Breakdown</h4>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 text-xs md:text-sm">
          <div className="space-y-1">
            <p className="text-muted-foreground">Trend</p>
            <p className="font-medium">{analysis.technicalBreakdown.trend}</p>
          </div>
          <div className="space-y-1">
            <p className="text-muted-foreground">Momentum</p>
            <p className="font-medium">{analysis.technicalBreakdown.momentum}</p>
          </div>
          <div className="space-y-1 col-span-2 md:col-span-1">
            <p className="text-muted-foreground">Volatility</p>
            <p className="font-medium">{analysis.technicalBreakdown.volatility}</p>
          </div>
        </div>

        {analysis.technicalBreakdown.patterns.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Detected Patterns</p>
            <div className="flex flex-wrap gap-2">
              {analysis.technicalBreakdown.patterns.map((pattern, i) => (
                <span key={i} className="px-2 py-1 bg-secondary rounded text-xs font-mono">
                  {pattern}
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          {analysis.technicalBreakdown.supportLevels.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Support Levels</p>
              <div className="space-y-1">
                {analysis.technicalBreakdown.supportLevels.map((level, i) => (
                  <span key={i} className="block px-2 py-1 bg-bullish/10 text-bullish rounded text-xs font-mono">
                    {level}
                  </span>
                ))}
              </div>
            </div>
          )}
          {analysis.technicalBreakdown.resistanceLevels.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Resistance Levels</p>
              <div className="space-y-1">
                {analysis.technicalBreakdown.resistanceLevels.map((level, i) => (
                  <span key={i} className="block px-2 py-1 bg-bearish/10 text-bearish rounded text-xs font-mono">
                    {level}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Timeframe Analysis */}
      <div className="border-t border-border pt-4">
        <h4 className="font-medium mb-2">Timeframe Analysis</h4>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {analysis.timeframeAnalysis}
        </p>
      </div>

      {/* Share Button */}
      {user && (
        <div className="border-t border-border pt-4">
          <Button
            variant={isShared ? "secondary" : "outline"}
            size="sm"
            onClick={handleShare}
            disabled={isSharing || isShared}
            className="w-full"
          >
            {isSharing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Sharing...
              </>
            ) : isShared ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                Shared with Community
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4 mr-2" />
                Share Signal
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
};
