import { ChartUpload } from '@/types/analysis';
import { TrendingUp, TrendingDown, Minus, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MultiTimeframeSummaryProps {
  uploads: ChartUpload[];
}

export const MultiTimeframeSummary = ({ uploads }: MultiTimeframeSummaryProps) => {
  const analyzedUploads = uploads.filter(u => u.analysis);
  
  if (analyzedUploads.length < 2) {
    return null;
  }

  const signals = analyzedUploads.map(u => u.analysis!.signal);
  const buyCount = signals.filter(s => s === 'BUY').length;
  const sellCount = signals.filter(s => s === 'SELL').length;
  const holdCount = signals.filter(s => s === 'HOLD').length;

  const avgConfidence = analyzedUploads.reduce((acc, u) => acc + u.analysis!.confidence, 0) / analyzedUploads.length;

  let consolidatedSignal: 'BUY' | 'SELL' | 'HOLD' | 'MIXED';
  let signalStrength: 'strong' | 'moderate' | 'weak';

  if (buyCount > sellCount && buyCount > holdCount) {
    consolidatedSignal = 'BUY';
    signalStrength = buyCount === analyzedUploads.length ? 'strong' : buyCount >= analyzedUploads.length / 2 ? 'moderate' : 'weak';
  } else if (sellCount > buyCount && sellCount > holdCount) {
    consolidatedSignal = 'SELL';
    signalStrength = sellCount === analyzedUploads.length ? 'strong' : sellCount >= analyzedUploads.length / 2 ? 'moderate' : 'weak';
  } else if (holdCount > buyCount && holdCount > sellCount) {
    consolidatedSignal = 'HOLD';
    signalStrength = 'moderate';
  } else {
    consolidatedSignal = 'MIXED';
    signalStrength = 'weak';
  }

  const SignalIcon = consolidatedSignal === 'BUY' ? TrendingUp : 
                     consolidatedSignal === 'SELL' ? TrendingDown : 
                     consolidatedSignal === 'MIXED' ? AlertCircle : Minus;

  return (
    <div className={cn(
      'terminal-card p-4 md:p-6 border-2',
      consolidatedSignal === 'BUY' && 'border-bullish/30 glow-bullish',
      consolidatedSignal === 'SELL' && 'border-bearish/30 glow-bearish',
      consolidatedSignal === 'HOLD' && 'border-hold/30 glow-hold',
      consolidatedSignal === 'MIXED' && 'border-muted-foreground/30',
    )}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 md:mb-6 gap-2">
        <h3 className="text-base md:text-lg font-bold">Multi-Timeframe Confluence</h3>
        <span className="text-xs md:text-sm text-muted-foreground">
          {analyzedUploads.length} timeframes analyzed
        </span>
      </div>

      <div className="flex items-center gap-4 md:gap-6">
        <div className={cn(
          'w-16 h-16 md:w-20 md:h-20 rounded-xl flex items-center justify-center shrink-0',
          consolidatedSignal === 'BUY' && 'bg-bullish/20',
          consolidatedSignal === 'SELL' && 'bg-bearish/20',
          consolidatedSignal === 'HOLD' && 'bg-hold/20',
          consolidatedSignal === 'MIXED' && 'bg-muted',
        )}>
          <SignalIcon className={cn(
            'w-8 h-8 md:w-10 md:h-10',
            consolidatedSignal === 'BUY' && 'text-bullish',
            consolidatedSignal === 'SELL' && 'text-bearish',
            consolidatedSignal === 'HOLD' && 'text-hold',
            consolidatedSignal === 'MIXED' && 'text-muted-foreground',
          )} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-baseline gap-2 md:gap-3">
            <span className={cn(
              'text-2xl md:text-3xl font-bold font-mono',
              consolidatedSignal === 'BUY' && 'text-bullish',
              consolidatedSignal === 'SELL' && 'text-bearish',
              consolidatedSignal === 'HOLD' && 'text-hold',
              consolidatedSignal === 'MIXED' && 'text-muted-foreground',
            )}>
              {consolidatedSignal}
            </span>
            <span className={cn(
              'text-xs md:text-sm px-2 py-0.5 rounded uppercase font-medium',
              signalStrength === 'strong' && 'bg-bullish/20 text-bullish',
              signalStrength === 'moderate' && 'bg-hold/20 text-hold',
              signalStrength === 'weak' && 'bg-muted text-muted-foreground',
            )}>
              {signalStrength}
            </span>
          </div>
          <p className="text-xs md:text-sm text-muted-foreground mt-1">
            Avg confidence: {avgConfidence.toFixed(1)}%
          </p>
        </div>
      </div>

      {/* Signal breakdown */}
      <div className="mt-4 md:mt-6 grid grid-cols-3 gap-2 md:gap-4">
        <div className="text-center p-2 md:p-3 bg-bullish/10 rounded-lg">
          <p className="text-xl md:text-2xl font-bold text-bullish font-mono">{buyCount}</p>
          <p className="text-[10px] md:text-xs text-muted-foreground">BUY</p>
        </div>
        <div className="text-center p-2 md:p-3 bg-hold/10 rounded-lg">
          <p className="text-xl md:text-2xl font-bold text-hold font-mono">{holdCount}</p>
          <p className="text-[10px] md:text-xs text-muted-foreground">HOLD</p>
        </div>
        <div className="text-center p-2 md:p-3 bg-bearish/10 rounded-lg">
          <p className="text-xl md:text-2xl font-bold text-bearish font-mono">{sellCount}</p>
          <p className="text-[10px] md:text-xs text-muted-foreground">SELL</p>
        </div>
      </div>

      {/* Timeframe list */}
      <div className="mt-4 md:mt-6 space-y-2">
        <p className="text-xs md:text-sm text-muted-foreground">Signal by timeframe:</p>
        <div className="flex flex-wrap gap-1.5 md:gap-2">
          {analyzedUploads.map(upload => (
            <div 
              key={upload.id}
              className={cn(
                'px-2 md:px-3 py-1 md:py-1.5 rounded-md font-mono text-xs md:text-sm flex items-center gap-1 md:gap-2',
                upload.analysis?.signal === 'BUY' && 'bg-bullish/20 text-bullish',
                upload.analysis?.signal === 'SELL' && 'bg-bearish/20 text-bearish',
                upload.analysis?.signal === 'HOLD' && 'bg-hold/20 text-hold',
              )}
            >
              <span className="font-medium">{upload.timeframe}</span>
              <span className="hidden sm:inline">→</span>
              <span>{upload.analysis?.signal}</span>
              <span className="text-[10px] md:text-xs opacity-70 hidden sm:inline">({upload.analysis?.confidence}%)</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
