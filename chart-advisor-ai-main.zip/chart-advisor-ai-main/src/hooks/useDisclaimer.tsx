import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

const DEFAULT_DISCLAIMER = 'This does not constitute financial advice. Trading involves substantial risk of loss.';

export const useDisclaimer = () => {
  const [disclaimer, setDisclaimer] = useState(DEFAULT_DISCLAIMER);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchDisclaimer = async () => {
      try {
        const { data, error } = await supabase
          .from('app_settings')
          .select('value')
          .eq('key', 'risk_disclaimer')
          .maybeSingle();

        if (error) throw error;
        if (data?.value) {
          setDisclaimer(data.value);
        }
      } catch (error) {
        console.error('Error fetching disclaimer:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchDisclaimer();
  }, []);

  return { disclaimer, isLoading };
};
