import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AnalysisResult, ChartUpload, AssetType } from '@/types/analysis';
import { toast } from '@/hooks/use-toast';

export const useChartAnalysis = () => {
  const [uploads, setUploads] = useState<ChartUpload[]>([]);

  const addUpload = (file: File, timeframe: string, assetType: AssetType = 'forex', traderNotes?: string) => {
    const id = crypto.randomUUID();
    const preview = URL.createObjectURL(file);
    
    setUploads(prev => [...prev, {
      id,
      file,
      preview,
      timeframe,
      assetType,
      traderNotes,
      isAnalyzing: false,
    }]);

    return id;
  };

  const removeUpload = (id: string) => {
    setUploads(prev => {
      const upload = prev.find(u => u.id === id);
      if (upload) {
        URL.revokeObjectURL(upload.preview);
      }
      return prev.filter(u => u.id !== id);
    });
  };

  const updateTimeframe = (id: string, timeframe: string) => {
    setUploads(prev => prev.map(u => 
      u.id === id ? { ...u, timeframe } : u
    ));
  };

  const updateAssetType = (id: string, assetType: AssetType) => {
    setUploads(prev => prev.map(u => 
      u.id === id ? { ...u, assetType } : u
    ));
  };

  const updateNotes = (id: string, traderNotes: string) => {
    setUploads(prev => prev.map(u => 
      u.id === id ? { ...u, traderNotes } : u
    ));
  };

  const analyzeChart = async (id: string): Promise<AnalysisResult | null> => {
    const upload = uploads.find(u => u.id === id);
    if (!upload) return null;

    setUploads(prev => prev.map(u => 
      u.id === id ? { ...u, isAnalyzing: true, error: undefined } : u
    ));

    try {
      // Convert file to base64
      const reader = new FileReader();
      const base64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(upload.file);
      });

      const { data, error } = await supabase.functions.invoke('analyze-chart', {
        body: {
          imageBase64: base64,
          timeframe: upload.timeframe,
          assetType: upload.assetType,
          traderNotes: upload.traderNotes,
        }
      });

      if (error) {
        throw error;
      }

      if (data.error) {
        throw new Error(data.error);
      }

      const analysis = data as AnalysisResult;
      
      setUploads(prev => prev.map(u => 
        u.id === id ? { ...u, analysis, isAnalyzing: false } : u
      ));

      // Dispatch event to notify subscription hook to refresh counts
      window.dispatchEvent(new CustomEvent('analysis-completed'));

      return analysis;
    } catch (error) {
      let errorMessage = error instanceof Error ? error.message : 'Analysis failed';
      let toastTitle = 'Analysis Failed';
      
      // Check for upgrade-related errors in the error message
      if (errorMessage.includes('Daily analysis limit reached') || 
          errorMessage.includes('upgradeRequired') ||
          errorMessage.includes('limit reached')) {
        toastTitle = 'Daily Limit Reached';
        errorMessage = 'You\'ve used all your daily analyses. Upgrade your plan for more.';
        // Trigger subscription refresh to update UI
        window.dispatchEvent(new CustomEvent('analysis-completed'));
      }
      
      setUploads(prev => prev.map(u => 
        u.id === id ? { ...u, isAnalyzing: false, error: errorMessage } : u
      ));

      toast({
        title: toastTitle,
        description: errorMessage,
        variant: 'destructive',
      });

      return null;
    }
  };

  const analyzeAll = async () => {
    const promises = uploads
      .filter(u => !u.analysis && !u.isAnalyzing)
      .map(u => analyzeChart(u.id));
    
    await Promise.all(promises);
  };

  const clearAll = () => {
    uploads.forEach(u => URL.revokeObjectURL(u.preview));
    setUploads([]);
  };

  return {
    uploads,
    addUpload,
    removeUpload,
    updateTimeframe,
    updateAssetType,
    updateNotes,
    analyzeChart,
    analyzeAll,
    clearAll,
  };
};
