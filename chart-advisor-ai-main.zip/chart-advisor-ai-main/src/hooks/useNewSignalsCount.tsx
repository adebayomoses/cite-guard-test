import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useSubscription } from '@/hooks/useSubscription';

export const useNewSignalsCount = () => {
  const [count, setCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { hasSignalsAccess } = useSubscription();

  useEffect(() => {
    if (!hasSignalsAccess) {
      setCount(0);
      setIsLoading(false);
      return;
    }

    const fetchCount = async () => {
      try {
        // Get signals from last 4 hours (more "new" feeling)
        const fourHoursAgo = new Date();
        fourHoursAgo.setHours(fourHoursAgo.getHours() - 4);

        const { data, error } = await supabase.functions.invoke('get-signals');

        if (error || !data?.signals) {
          setCount(0);
          return;
        }

        // Count signals created in last 4 hours
        const newSignals = data.signals.filter((signal: any) => {
          const createdAt = new Date(signal.created_at);
          return createdAt > fourHoursAgo;
        });

        setCount(newSignals.length);
      } catch (err) {
        console.error('Error fetching signals count:', err);
        setCount(0);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCount();

    // Set up realtime subscription for new signals
    const channel = supabase
      .channel('new_signals_count')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'shared_signals',
        },
        () => {
          setCount((prev) => prev + 1);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [hasSignalsAccess]);

  return { count, isLoading };
};
