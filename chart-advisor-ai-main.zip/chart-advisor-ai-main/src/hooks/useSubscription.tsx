import { useState, useEffect, useCallback, createContext, useContext, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const FREE_DAILY_LIMIT = 2;
const ADMIN_DAILY_LIMIT = 999; // Effectively unlimited for admins

// Tier configuration with daily limits
const TIER_LIMITS = {
  free: { dailyLimit: FREE_DAILY_LIMIT, productId: null },
  social: { dailyLimit: 3, productId: 'prod_TniQZgTn0JIdZu' },
  standard: { dailyLimit: 9, productId: 'prod_TniVrNkPKLCj52' },
  pro: { dailyLimit: 20, productId: 'prod_TniYtMGtgQGAQ2' },
} as const;

type TierKey = keyof typeof TIER_LIMITS;

interface SubscriptionState {
  isSubscribed: boolean;
  productId: string | null;
  subscriptionEnd: string | null;
  analysisCount: number;
  dailyCount: number;
  dailyLimit: number;
  tier: TierKey;
  isLoading: boolean;
  canAnalyze: boolean;
  remainingAnalyses: number;
  hasSignalsAccess: boolean;
}

interface SubscriptionContextType extends SubscriptionState {
  checkSubscription: () => Promise<void>;
  incrementAnalysisCount: () => Promise<boolean>;
  openCheckout: () => Promise<void>;
  openCheckoutWithPrice: (priceId: string) => Promise<void>;
  openCustomerPortal: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

const getTierFromProductId = (productId: string | null): TierKey => {
  if (!productId) return 'free';
  if (productId === TIER_LIMITS.pro.productId) return 'pro';
  if (productId === TIER_LIMITS.standard.productId) return 'standard';
  if (productId === TIER_LIMITS.social.productId) return 'social';
  return 'free';
};

// Map tier override strings to TierKey
const getTierFromOverride = (tierOverride: string | null): TierKey | null => {
  if (!tierOverride) return null;
  if (['free', 'social', 'standard', 'pro'].includes(tierOverride)) {
    return tierOverride as TierKey;
  }
  return null;
};

export const SubscriptionProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [state, setState] = useState<SubscriptionState>({
    isSubscribed: false,
    productId: null,
    subscriptionEnd: null,
    analysisCount: 0,
    dailyCount: 0,
    dailyLimit: FREE_DAILY_LIMIT,
    tier: 'free',
    isLoading: true,
    canAnalyze: true,
    remainingAnalyses: FREE_DAILY_LIMIT,
    hasSignalsAccess: false,
  });

  const checkSubscription = useCallback(async () => {
    if (!user) {
      setState(prev => ({ ...prev, isLoading: false, isSubscribed: false }));
      return;
    }

    try {
      // Check if user is admin
      const { data: adminData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle();
      
      const isAdmin = !!adminData;

      // Check Stripe subscription (also checks for admin overrides)
      const { data: subData } = await supabase.functions.invoke('check-subscription');
      
      const isSubscribed = subData?.subscribed ?? false;
      const productId = subData?.product_id ?? null;
      const subscriptionEnd = subData?.subscription_end ?? null;
      
      // Check for admin-assigned tier override first
      const tierOverride = getTierFromOverride(subData?.tier_override);
      const tier = tierOverride ?? getTierFromProductId(productId);

      // Get total analysis count
      const { data: totalCount } = await supabase.rpc('get_analysis_count', { p_user_id: user.id });
      const analysisCount = totalCount ?? 0;

      // Get daily count for paid tiers
      const { data: dailyData } = await supabase.rpc('get_daily_count', { p_user_id: user.id });
      const dailyCount = dailyData ?? 0;

      // Calculate limits based on tier - admins get unlimited access
      let dailyLimit: number;
      let remainingAnalyses: number;
      let canAnalyze: boolean;

      if (isAdmin) {
        // Admins have unlimited access but display Pro tier limit in UI
        dailyLimit = TIER_LIMITS.pro.dailyLimit; // Show 25 in UI
        remainingAnalyses = Math.max(0, TIER_LIMITS.pro.dailyLimit - dailyCount);
        canAnalyze = true; // Admins can always analyze
      } else if (tier === 'free') {
        dailyLimit = FREE_DAILY_LIMIT;
        remainingAnalyses = Math.max(0, dailyLimit - dailyCount);
        canAnalyze = dailyCount < dailyLimit;
      } else {
        dailyLimit = TIER_LIMITS[tier].dailyLimit;
        remainingAnalyses = Math.max(0, dailyLimit - dailyCount);
        canAnalyze = dailyCount < dailyLimit;
      }

      // Admins and paid tiers have signals access
      const hasSignalsAccess = isAdmin || tier === 'social' || tier === 'standard' || tier === 'pro';

      setState({
        isSubscribed: isAdmin || isSubscribed,
        productId,
        subscriptionEnd,
        analysisCount,
        dailyCount,
        dailyLimit,
        tier: isAdmin ? 'pro' : tier, // Treat admins as pro tier for UI display
        isLoading: false,
        canAnalyze,
        remainingAnalyses,
        hasSignalsAccess,
      });
    } catch (error) {
      console.error('Error checking subscription:', error);
      setState(prev => ({ ...prev, isLoading: false }));
    }
  }, [user]);

  const incrementAnalysisCount = useCallback(async (): Promise<boolean> => {
    if (!user) return false;

    // Check current limits
    if (!state.canAnalyze) {
      return false;
    }

    try {
      const { error } = await supabase.rpc('increment_analysis_count', { p_user_id: user.id });
      
      if (error) throw error;

      // Recalculate state
      const newDailyCount = state.dailyCount + 1;
      const newTotalCount = state.analysisCount + 1;

      let remainingAnalyses: number;
      let canAnalyze: boolean;

      // All tiers now use daily count
      remainingAnalyses = Math.max(0, state.dailyLimit - newDailyCount);
      canAnalyze = newDailyCount < state.dailyLimit;
      
      setState(prev => ({
        ...prev,
        analysisCount: newTotalCount,
        dailyCount: newDailyCount,
        remainingAnalyses,
        canAnalyze,
      }));

      return true;
    } catch (error) {
      console.error('Error incrementing analysis count:', error);
      return false;
    }
  }, [user, state.canAnalyze, state.dailyCount, state.analysisCount, state.tier, state.dailyLimit]);

  const openCheckout = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('create-checkout');
      if (error) throw error;
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error opening checkout:', error);
    }
  }, []);

  const openCheckoutWithPrice = useCallback(async (priceId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: { price_id: priceId },
      });
      if (error) throw error;
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error opening checkout:', error);
    }
  }, []);

  const openCustomerPortal = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('customer-portal');
      if (error) throw error;
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
    }
  }, []);

  // Check subscription on mount and when user changes
  useEffect(() => {
    checkSubscription();
  }, [checkSubscription]);

  // Check subscription every minute
  useEffect(() => {
    const interval = setInterval(checkSubscription, 60000);
    return () => clearInterval(interval);
  }, [checkSubscription]);

  // Listen for analysis completion events to refresh counts
  useEffect(() => {
    const handleAnalysisCompleted = () => {
      checkSubscription();
    };
    window.addEventListener('analysis-completed', handleAnalysisCompleted);
    return () => window.removeEventListener('analysis-completed', handleAnalysisCompleted);
  }, [checkSubscription]);

  return (
    <SubscriptionContext.Provider value={{
      ...state,
      checkSubscription,
      incrementAnalysisCount,
      openCheckout,
      openCheckoutWithPrice,
      openCustomerPortal,
    }}>
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};
