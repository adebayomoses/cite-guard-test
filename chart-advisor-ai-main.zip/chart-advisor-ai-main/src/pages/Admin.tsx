import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/Header';
import { useAdmin } from '@/hooks/useAdmin';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Shield, Lock, Loader2, MessageSquare, Settings, Save, RefreshCw, BarChart3, Users, CreditCard } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { AdminStatistics } from '@/components/admin/AdminStatistics';
import { AdminSubscribers } from '@/components/admin/AdminSubscribers';
import { AdminUsers } from '@/components/admin/AdminUsers';

interface SupportInquiry {
  id: string;
  user_id: string;
  email: string | null;
  inquiry_type: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface SubscriberInfo {
  email: string;
  tier: string;
  productId: string;
  status: string;
  startDate: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  customerId: string;
}

interface UserInfo {
  id: string;
  email: string;
  tier: string;
  source: 'stripe' | 'override' | 'free';
  created_at: string;
  override_expires_at?: string;
}

interface AdminStats {
  totalUsers: number;
  totalAnalyses: number;
  activeToday: number;
  newUsersThisWeek: number;
  subscribers: SubscriberInfo[];
  users: UserInfo[];
  tierDistribution: Record<string, number>;
}

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-hold text-hold-foreground',
  in_progress: 'bg-primary text-primary-foreground',
  resolved: 'bg-bullish text-white',
  closed: 'bg-muted text-muted-foreground',
};

const Admin = () => {
  const { user } = useAuth();
  const { isAdmin, isLoading: adminLoading } = useAdmin();
  const [inquiries, setInquiries] = useState<SupportInquiry[]>([]);
  const [disclaimer, setDisclaimer] = useState('');
  const [originalDisclaimer, setOriginalDisclaimer] = useState('');
  const [isLoadingInquiries, setIsLoadingInquiries] = useState(true);
  const [isLoadingSettings, setIsLoadingSettings] = useState(true);
  const [isLoadingStats, setIsLoadingStats] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [adminStats, setAdminStats] = useState<AdminStats | null>(null);

  const fetchInquiries = async () => {
    setIsLoadingInquiries(true);
    try {
      const { data, error } = await supabase
        .from('support_inquiries')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInquiries((data as SupportInquiry[]) || []);
    } catch (error) {
      console.error('Error fetching inquiries:', error);
      toast.error('Failed to load inquiries');
    } finally {
      setIsLoadingInquiries(false);
    }
  };

  const fetchSettings = async () => {
    setIsLoadingSettings(true);
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'risk_disclaimer')
        .maybeSingle();

      if (error) throw error;
      const value = data?.value || '';
      setDisclaimer(value);
      setOriginalDisclaimer(value);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setIsLoadingSettings(false);
    }
  };

  const fetchAdminStats = useCallback(async () => {
    setIsLoadingStats(true);
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;
      
      if (!token) {
        throw new Error('No session token');
      }

      const { data, error } = await supabase.functions.invoke('get-admin-stats', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);
      
      setAdminStats(data);
    } catch (error) {
      console.error('Error fetching admin stats:', error);
      toast.error('Failed to load statistics');
    } finally {
      setIsLoadingStats(false);
    }
  }, []);

  const updateInquiryStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('support_inquiries')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;
      
      setInquiries(prev => 
        prev.map(inq => inq.id === id ? { ...inq, status } : inq)
      );
      toast.success('Status updated');
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update status');
    }
  };

  const saveDisclaimer = async () => {
    if (!user) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('app_settings')
        .update({ 
          value: disclaimer, 
          updated_at: new Date().toISOString(),
          updated_by: user.id 
        })
        .eq('key', 'risk_disclaimer');

      if (error) throw error;
      
      setOriginalDisclaimer(disclaimer);
      toast.success('Disclaimer saved successfully');
    } catch (error) {
      console.error('Error saving disclaimer:', error);
      toast.error('Failed to save disclaimer');
    } finally {
      setIsSaving(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchInquiries();
      fetchSettings();
      fetchAdminStats();
    }
  }, [isAdmin, fetchAdminStats]);

  if (adminLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </main>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16">
          <Card className="max-w-md mx-auto text-center">
            <CardHeader>
              <Lock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <CardTitle>Sign In Required</CardTitle>
              <CardDescription>Please sign in to access the admin dashboard.</CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/login">
                <Button>Sign In</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16">
          <Card className="max-w-md mx-auto text-center border-destructive/30">
            <CardHeader>
              <Shield className="w-12 h-12 mx-auto text-destructive mb-4" />
              <CardTitle>Access Denied</CardTitle>
              <CardDescription>
                You don't have permission to access the admin dashboard.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/dashboard">
                <Button variant="outline">Go to Dashboard</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage users, subscriptions, and app settings</p>
          </div>
        </div>

        <Tabs defaultValue="statistics" className="space-y-6">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="statistics" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Statistics
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="w-4 h-4" />
              Manage Users
            </TabsTrigger>
            <TabsTrigger value="subscribers" className="gap-2">
              <CreditCard className="w-4 h-4" />
              Stripe Subscribers
            </TabsTrigger>
            <TabsTrigger value="inquiries" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Support Inquiries
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="w-4 h-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="statistics">
            <div className="flex justify-end mb-4">
              <Button variant="outline" size="sm" onClick={fetchAdminStats}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <AdminStatistics 
              stats={adminStats ? {
                totalUsers: adminStats.totalUsers,
                totalAnalyses: adminStats.totalAnalyses,
                activeToday: adminStats.activeToday,
                newUsersThisWeek: adminStats.newUsersThisWeek,
                tierDistribution: adminStats.tierDistribution,
              } : null} 
              isLoading={isLoadingStats} 
            />
          </TabsContent>

          <TabsContent value="users">
            <div className="flex justify-end mb-4">
              <Button variant="outline" size="sm" onClick={fetchAdminStats}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <AdminUsers 
              users={adminStats?.users || []} 
              isLoading={isLoadingStats}
              onRefresh={fetchAdminStats}
            />
          </TabsContent>

          <TabsContent value="subscribers">
            <div className="flex justify-end mb-4">
              <Button variant="outline" size="sm" onClick={fetchAdminStats}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            <AdminSubscribers 
              subscribers={adminStats?.subscribers || []} 
              isLoading={isLoadingStats} 
            />
          </TabsContent>

          <TabsContent value="inquiries">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Support Inquiries</CardTitle>
                  <CardDescription>
                    {inquiries.length} total inquiries from Pro subscribers
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={fetchInquiries}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
              </CardHeader>
              <CardContent>
                {isLoadingInquiries ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                  </div>
                ) : inquiries.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No support inquiries yet.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Message</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {inquiries.map((inquiry) => (
                          <TableRow key={inquiry.id}>
                            <TableCell className="whitespace-nowrap">
                              {new Date(inquiry.created_at).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="max-w-[200px]">
                              {inquiry.email ? (
                                <a 
                                  href={`mailto:${inquiry.email}`} 
                                  className="text-primary hover:underline truncate block"
                                >
                                  {inquiry.email}
                                </a>
                              ) : (
                                <span className="text-muted-foreground">—</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {inquiry.inquiry_type}
                              </Badge>
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate">
                              {inquiry.subject}
                            </TableCell>
                            <TableCell className="max-w-[300px]">
                              <p className="truncate">{inquiry.message}</p>
                            </TableCell>
                            <TableCell>
                              <Badge className={STATUS_COLORS[inquiry.status]}>
                                {inquiry.status.replace('_', ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={inquiry.status}
                                onValueChange={(value) => updateInquiryStatus(inquiry.id, value)}
                              >
                                <SelectTrigger className="w-[130px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">Pending</SelectItem>
                                  <SelectItem value="in_progress">In Progress</SelectItem>
                                  <SelectItem value="resolved">Resolved</SelectItem>
                                  <SelectItem value="closed">Closed</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Risk Disclaimer</CardTitle>
                <CardDescription>
                  Edit the risk disclaimer banner shown throughout the app
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoadingSettings ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <>
                    <Textarea
                      value={disclaimer}
                      onChange={(e) => setDisclaimer(e.target.value)}
                      rows={6}
                      placeholder="Enter risk disclaimer text..."
                      className="font-mono text-sm"
                    />
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-muted-foreground">
                        {disclaimer.length} characters
                      </p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          onClick={() => setDisclaimer(originalDisclaimer)}
                          disabled={disclaimer === originalDisclaimer}
                        >
                          Reset
                        </Button>
                        <Button
                          onClick={saveDisclaimer}
                          disabled={isSaving || disclaimer === originalDisclaimer}
                        >
                          {isSaving ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <Save className="w-4 h-4 mr-2" />
                          )}
                          Save Disclaimer
                        </Button>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Admin;
