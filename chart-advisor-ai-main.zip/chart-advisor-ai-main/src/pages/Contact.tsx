import { useState } from 'react';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/hooks/useAuth';
import { MessageCircle, Users, Lock, Send, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';

const inquirySchema = z.object({
  subject: z.string().trim().min(1, 'Subject is required').max(200, 'Subject must be less than 200 characters'),
  message: z.string().trim().min(10, 'Message must be at least 10 characters').max(5000, 'Message must be less than 5000 characters'),
  inquiryType: z.enum(['mentorship', 'support']),
});

const Contact = () => {
  const { user } = useAuth();
  const { tier, isLoading } = useSubscription();
  const [formData, setFormData] = useState({
    subject: '',
    message: '',
    inquiryType: 'mentorship' as 'mentorship' | 'support',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const isPro = tier === 'pro';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isPro || !user) return;

    // Validate form
    const result = inquirySchema.safeParse(formData);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach(err => {
        if (err.path[0]) {
          fieldErrors[err.path[0] as string] = err.message;
        }
      });
      setErrors(fieldErrors);
      return;
    }

    setErrors({});
    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('support_inquiries')
        .insert({
          user_id: user.id,
          email: user.email,
          inquiry_type: formData.inquiryType,
          subject: formData.subject.trim(),
          message: formData.message.trim(),
        });

      if (error) throw error;

      setIsSubmitted(true);
      setFormData({ subject: '', message: '', inquiryType: 'mentorship' });
      toast.success('Your inquiry has been submitted! We\'ll get back to you within 24 hours.');
    } catch (error) {
      console.error('Error submitting inquiry:', error);
      toast.error('Failed to submit inquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16 flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">Loading...</div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-3">
              Pro <span className="text-primary">Support</span>
            </h1>
            <p className="text-muted-foreground">
              Get personalized mentorship and direct trader support as a Pro member.
            </p>
          </div>

          {!user ? (
            <Card className="text-center">
              <CardHeader>
                <Lock className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <CardTitle>Sign In Required</CardTitle>
                <CardDescription>
                  Please sign in to access Pro support features.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link to="/login">
                  <Button>Sign In</Button>
                </Link>
              </CardContent>
            </Card>
          ) : !isPro ? (
            <Card className="text-center border-hold/30 bg-hold/5">
              <CardHeader>
                <Lock className="w-12 h-12 mx-auto text-hold mb-4" />
                <CardTitle>Pro Feature</CardTitle>
                <CardDescription>
                  Mentorship and trader support is exclusively available for Pro subscribers.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2 text-left">
                  <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded-lg">
                    <Users className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-semibold">1-on-1 Mentorship</h4>
                      <p className="text-sm text-muted-foreground">
                        Get personalized guidance from experienced traders.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-4 bg-secondary/50 rounded-lg">
                    <MessageCircle className="w-5 h-5 text-primary mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Trader Support</h4>
                      <p className="text-sm text-muted-foreground">
                        Direct access to our trading support team.
                      </p>
                    </div>
                  </div>
                </div>
                <Link to="/pricing">
                  <Button className="w-full sm:w-auto">Upgrade to Pro - $20/month</Button>
                </Link>
              </CardContent>
            </Card>
          ) : isSubmitted ? (
            <Card className="text-center border-bullish/30 bg-bullish/5">
              <CardHeader>
                <CheckCircle className="w-16 h-16 mx-auto text-bullish mb-4" />
                <CardTitle>Inquiry Submitted!</CardTitle>
                <CardDescription>
                  Thank you for reaching out. Our team will get back to you within 24 hours.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" onClick={() => setIsSubmitted(false)}>
                  Submit Another Inquiry
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Support options */}
              <div className="grid gap-4 sm:grid-cols-2">
                <Card 
                  className={`cursor-pointer transition-all ${formData.inquiryType === 'mentorship' ? 'border-primary bg-primary/5' : 'hover:border-primary/50'}`}
                  onClick={() => setFormData(prev => ({ ...prev, inquiryType: 'mentorship' }))}
                >
                  <CardHeader className="pb-2">
                    <Users className="w-8 h-8 text-primary mb-2" />
                    <CardTitle className="text-lg">Mentorship</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Schedule sessions with experienced traders for personalized guidance.
                    </p>
                  </CardContent>
                </Card>
                
                <Card 
                  className={`cursor-pointer transition-all ${formData.inquiryType === 'support' ? 'border-primary bg-primary/5' : 'hover:border-primary/50'}`}
                  onClick={() => setFormData(prev => ({ ...prev, inquiryType: 'support' }))}
                >
                  <CardHeader className="pb-2">
                    <MessageCircle className="w-8 h-8 text-primary mb-2" />
                    <CardTitle className="text-lg">Trader Support</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Get help with trading strategies, chart analysis, or platform questions.
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Contact form */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {formData.inquiryType === 'mentorship' ? 'Request Mentorship Session' : 'Contact Trader Support'}
                  </CardTitle>
                  <CardDescription>
                    {formData.inquiryType === 'mentorship' 
                      ? 'Tell us about your trading goals and experience level.'
                      : 'Describe what you need help with and we\'ll get back to you.'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="subject">Subject</Label>
                      <Input
                        id="subject"
                        placeholder={formData.inquiryType === 'mentorship' 
                          ? 'e.g., Need help with technical analysis' 
                          : 'e.g., Question about chart patterns'}
                        value={formData.subject}
                        onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                        maxLength={200}
                        className={errors.subject ? 'border-destructive' : ''}
                      />
                      {errors.subject && (
                        <p className="text-sm text-destructive">{errors.subject}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        placeholder={formData.inquiryType === 'mentorship'
                          ? 'Describe your trading experience, goals, and what you\'d like to learn...'
                          : 'Describe your question or issue in detail...'}
                        value={formData.message}
                        onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                        rows={6}
                        maxLength={5000}
                        className={errors.message ? 'border-destructive' : ''}
                      />
                      {errors.message && (
                        <p className="text-sm text-destructive">{errors.message}</p>
                      )}
                      <p className="text-xs text-muted-foreground text-right">
                        {formData.message.length}/5000
                      </p>
                    </div>

                    <Button type="submit" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        'Submitting...'
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Submit Inquiry
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <p className="text-center text-sm text-muted-foreground">
                Typical response time: within 24 hours
              </p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Contact;
