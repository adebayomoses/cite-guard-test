import { Check, Zap, Crown, MessageCircle, Users, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/Header';
import { useSubscription } from '@/hooks/useSubscription';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';

// Tier configuration
export const SUBSCRIPTION_TIERS = {
  free: {
    name: 'Free',
    price: 0,
    priceId: null,
    productId: null,
    dailyLimit: 2,
    features: [
      '2 chart analyses per day',
      'Basic technical analysis',
      'Single timeframe view',
    ],
  },
  social: {
    name: 'Social',
    price: 4,
    priceId: 'price_1Sq706QZiHaLiahhZ1VrwrPe',
    productId: 'prod_TniQZgTn0JIdZu',
    dailyLimit: 3,
    features: [
      '3 chart analyses per day',
      'Basic technical analysis',
      'Community signals access',
    ],
  },
  standard: {
    name: 'Standard',
    price: 10,
    priceId: 'price_1Sq74xQZiHaLiahh4VJhpsLV',
    productId: 'prod_TniVrNkPKLCj52',
    dailyLimit: 9,
    features: [
      '9 chart analyses per day',
      'Full technical breakdowns',
      'Multi-timeframe confluence',
      'Community signals access',
    ],
  },
  pro: {
    name: 'Pro',
    price: 25,
    priceId: 'price_1Sq77dQZiHaLiahhMeA5vwVA',
    productId: 'prod_TniYtMGtgQGAQ2',
    dailyLimit: 20,
    features: [
      '20 chart analyses per day',
      'Full technical breakdowns',
      'Multi-timeframe confluence',
      'Community signals access',
      'Mentorship access',
      'Trader support chat',
    ],
  },
} as const;

export type TierKey = keyof typeof SUBSCRIPTION_TIERS;

const PricingCard = ({
  tier,
  isCurrentPlan,
  onSubscribe,
  isLoading,
  recommended,
}: {
  tier: typeof SUBSCRIPTION_TIERS[TierKey];
  isCurrentPlan: boolean;
  onSubscribe: () => void;
  isLoading: boolean;
  recommended?: boolean;
}) => {
  const isPaid = tier.price > 0;

  return (
    <Card className={`relative flex flex-col ${recommended ? 'border-primary glow-bullish' : ''} ${isCurrentPlan ? 'ring-2 ring-primary' : ''}`}>
      {recommended && (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground">
          Most Popular
        </Badge>
      )}
      {isCurrentPlan && (
        <Badge className="absolute -top-3 right-4 bg-bullish text-primary-foreground">
          Your Plan
        </Badge>
      )}
      
      <CardHeader className="text-center pb-2">
        <CardTitle className="text-2xl font-bold">{tier.name}</CardTitle>
        <CardDescription>
          <div className="mt-4">
            <span className="text-4xl font-bold text-foreground">${tier.price}</span>
            {isPaid && <span className="text-muted-foreground">/month</span>}
          </div>
        </CardDescription>
      </CardHeader>
      
      <CardContent className="flex-1">
        <ul className="space-y-3">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-start gap-3">
              <Check className="h-5 w-5 text-bullish shrink-0 mt-0.5" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
          {tier.name === 'Pro' && (
            <>
              <li className="flex items-start gap-3">
                <Users className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-sm font-medium text-primary">1-on-1 Mentorship Sessions</span>
              </li>
              <li className="flex items-start gap-3">
                <MessageCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-sm font-medium text-primary">Direct Trader Support</span>
              </li>
            </>
          )}
        </ul>
      </CardContent>
      
      <CardFooter>
        <Button 
          className="w-full" 
          variant={recommended ? 'default' : 'outline'}
          onClick={onSubscribe}
          disabled={isCurrentPlan || isLoading}
        >
          {isCurrentPlan ? 'Current Plan' : isPaid ? 'Subscribe' : 'Get Started'}
        </Button>
      </CardFooter>
    </Card>
  );
};

const Pricing = () => {
  const { user } = useAuth();
  const { isSubscribed, productId, isLoading, openCheckoutWithPrice } = useSubscription();
  const navigate = useNavigate();

  const getCurrentTier = (): TierKey => {
    if (!isSubscribed) return 'free';
    if (productId === SUBSCRIPTION_TIERS.pro.productId) return 'pro';
    if (productId === SUBSCRIPTION_TIERS.standard.productId) return 'standard';
    if (productId === SUBSCRIPTION_TIERS.social.productId) return 'social';
    return 'free';
  };

  const currentTier = getCurrentTier();

  const handleSubscribe = async (tierKey: TierKey) => {
    if (!user) {
      navigate('/signup');
      return;
    }

    if (tierKey === 'free') {
      navigate('/dashboard');
      return;
    }

    const tier = SUBSCRIPTION_TIERS[tierKey];
    if (tier.priceId) {
      await openCheckoutWithPrice(tier.priceId);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8 md:py-16">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">
            Choose Your <span className="text-bullish">Trading Edge</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Unlock powerful AI-driven chart analysis. From casual traders to serious professionals,
            we have a plan that fits your trading style.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          <PricingCard
            tier={SUBSCRIPTION_TIERS.free}
            isCurrentPlan={currentTier === 'free'}
            onSubscribe={() => handleSubscribe('free')}
            isLoading={isLoading}
          />
          <PricingCard
            tier={SUBSCRIPTION_TIERS.social}
            isCurrentPlan={currentTier === 'social'}
            onSubscribe={() => handleSubscribe('social')}
            isLoading={isLoading}
          />
          <PricingCard
            tier={SUBSCRIPTION_TIERS.standard}
            isCurrentPlan={currentTier === 'standard'}
            onSubscribe={() => handleSubscribe('standard')}
            isLoading={isLoading}
            recommended
          />
          <PricingCard
            tier={SUBSCRIPTION_TIERS.pro}
            isCurrentPlan={currentTier === 'pro'}
            onSubscribe={() => handleSubscribe('pro')}
            isLoading={isLoading}
          />
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-2 text-muted-foreground">
            <Zap className="h-5 w-5 text-hold" />
            <span>All plans include instant AI analysis results</span>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Questions? Need enterprise pricing?{' '}
            <a href="mailto:support@uptraview.ai" className="text-primary hover:underline">
              Contact us
            </a>
          </p>
        </div>
      </main>
    </div>
  );
};

export default Pricing;
