import { useEffect } from 'react';
import { Navigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useChartAnalysis } from '@/hooks/useChartAnalysis';
import { useSubscription } from '@/hooks/useSubscription';
import { useDisclaimer } from '@/hooks/useDisclaimer';
import { useIsMobile } from '@/hooks/use-mobile';
import { Header } from '@/components/Header';
import { ChartUploader } from '@/components/ChartUploader';
import { ChartPreview } from '@/components/ChartPreview';
import { AnalysisCard } from '@/components/AnalysisCard';
import { RiskCalculator } from '@/components/RiskCalculator';
import { MultiTimeframeSummary } from '@/components/MultiTimeframeSummary';
import { InstallBanner } from '@/components/InstallBanner';
import { SubscriptionCard } from '@/components/SubscriptionCard';
import { UpgradePrompt } from '@/components/UpgradePrompt';
import { MySharedSignals } from '@/components/MySharedSignals';
import { BottomNavigation } from '@/components/BottomNavigation';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from '@/hooks/use-toast';
import { Loader2, Trash2, Zap, AlertTriangle } from 'lucide-react';

const Dashboard = () => {
  const { user, isLoading: authLoading } = useAuth();
  const { uploads, addUpload, removeUpload, updateTimeframe, analyzeChart, analyzeAll, clearAll } = useChartAnalysis();
  const { canAnalyze, checkSubscription, isSubscribed } = useSubscription();
  const { disclaimer } = useDisclaimer();
  const isMobile = useIsMobile();
  const [searchParams] = useSearchParams();

  // Check for subscription success
  useEffect(() => {
    const subscriptionStatus = searchParams.get('subscription');
    if (subscriptionStatus === 'success') {
      toast({
        title: 'Subscription Activated!',
        description: 'Welcome to Pro! You now have unlimited chart analyses.',
      });
      checkSubscription();
    }
  }, [searchParams, checkSubscription]);

  if (authLoading) return null;
  if (!user) return <Navigate to="/login" replace />;

  const hasUploads = uploads.length > 0;
  const isAnalyzing = uploads.some(u => u.isAnalyzing);
  const hasAnalysis = uploads.some(u => u.analysis);
  const selectedAnalysis = uploads.find(u => u.analysis)?.analysis;

  const handleAnalyzeChart = async (id: string) => {
    if (!canAnalyze) {
      toast({
        title: 'Daily Limit Reached',
        description: 'Upgrade your plan for more analyses.',
        variant: 'destructive',
      });
      return;
    }

    await analyzeChart(id);
    // Refresh subscription state to get updated count from edge function
    checkSubscription();
  };

  const handleAnalyzeAll = async () => {
    const chartsToAnalyze = uploads.filter(u => !u.analysis && !u.isAnalyzing);
    
    for (const upload of chartsToAnalyze) {
      // Re-check subscription state before each analysis
      if (!canAnalyze) {
        toast({
          title: 'Daily Limit Reached',
          description: 'Upgrade your plan for more analyses.',
          variant: 'destructive',
        });
        break;
      }
      
      await analyzeChart(upload.id);
    }
    // Refresh subscription state after all analyses complete
    checkSubscription();
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-4 md:py-8 px-4 pb-28 md:pb-4">
        {/* Install Banner for Mobile */}
        <InstallBanner />
        
        {/* Disclaimer Banner */}
        <Alert className="mb-4 md:mb-6 border-yellow-500/50 bg-yellow-500/10">
          <AlertTriangle className="h-4 w-4 text-yellow-500 shrink-0" />
          <AlertDescription className="text-yellow-200 text-xs md:text-sm">
            <strong>Risk Disclaimer:</strong> {disclaimer}
          </AlertDescription>
        </Alert>

        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-1 md:mb-2">Chart Analysis</h1>
          <p className="text-sm md:text-base text-muted-foreground">Upload chart screenshots for AI-powered trading signals across forex, crypto, stocks, and more</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-4 md:gap-8">
          {/* Left: Upload & Charts */}
          <div className="lg:col-span-2 space-y-4 md:space-y-6">
            {/* Show upgrade prompt if limit reached */}
            {!canAnalyze && <UpgradePrompt />}
            
            {canAnalyze && (
              <>
                <ChartUploader onUpload={addUpload} />

                {hasUploads && (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <span className="text-sm text-muted-foreground">{uploads.length} chart(s) uploaded</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={clearAll} className="flex-1 sm:flex-none">
                        <Trash2 className="w-4 h-4 mr-1" /> Clear
                      </Button>
                      <Button size="sm" onClick={handleAnalyzeAll} disabled={isAnalyzing} className="flex-1 sm:flex-none">
                        {isAnalyzing ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Zap className="w-4 h-4 mr-1" />}
                        Analyze All
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
                  {uploads.map(upload => (
                    <ChartPreview
                      key={upload.id}
                      upload={upload}
                      onRemove={removeUpload}
                      onTimeframeChange={updateTimeframe}
                      onAnalyze={handleAnalyzeChart}
                    />
                  ))}
                </div>
              </>
            )}

            <MultiTimeframeSummary uploads={uploads} />
          </div>

          {/* Right: Subscription, Analysis & Risk */}
          <div className="space-y-4 md:space-y-6">
            {/* Subscription Status Card */}
            <SubscriptionCard />
            
            {/* My Shared Signals */}
            <MySharedSignals />
            
            {hasAnalysis && selectedAnalysis && (
              <AnalysisCard 
                analysis={selectedAnalysis} 
                timeframe={uploads.find(u => u.analysis)?.timeframe || ''} 
                assetType={uploads.find(u => u.analysis)?.assetType}
              />
            )}
            
            <RiskCalculator
              entryPrice={selectedAnalysis?.entryPrice}
              stopLoss={selectedAnalysis?.stopLoss}
              takeProfit={selectedAnalysis?.takeProfit}
            />
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
};

export default Dashboard;
