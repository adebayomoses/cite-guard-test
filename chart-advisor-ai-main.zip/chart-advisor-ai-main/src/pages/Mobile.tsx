import { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { LayoutDashboard, TrendingUp, GraduationCap, Loader2, Trash2, Zap, AlertTriangle, Radio, RefreshCw, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Header } from '@/components/Header';
import { useAuth } from '@/hooks/useAuth';
import { useChartAnalysis } from '@/hooks/useChartAnalysis';
import { useSubscription } from '@/hooks/useSubscription';
import { useDisclaimer } from '@/hooks/useDisclaimer';
import { ChartUploader } from '@/components/ChartUploader';
import { ChartPreview } from '@/components/ChartPreview';
import { AnalysisCard } from '@/components/AnalysisCard';
import { UpgradePrompt } from '@/components/UpgradePrompt';
import { SignalCard } from '@/components/SignalCard';
import { SignalsFilter } from '@/components/SignalsFilter';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { SharedSignal } from '@/types/signal';

type Tab = 'dashboard' | 'signals' | 'education';

const Mobile = () => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const { user, isLoading: authLoading } = useAuth();
  const { uploads, addUpload, removeUpload, updateTimeframe, analyzeChart, clearAll } = useChartAnalysis();
  const { canAnalyze, incrementAnalysisCount, hasSignalsAccess } = useSubscription();
  const { disclaimer } = useDisclaimer();

  // Signals state
  const [signals, setSignals] = useState<SharedSignal[]>([]);
  const [signalsLoading, setSignalsLoading] = useState(false);
  const [signalsError, setSignalsError] = useState<string | null>(null);
  const [assetType, setAssetType] = useState('all');
  const [signalType, setSignalType] = useState('all');
  const [sortBy, setSortBy] = useState('created_at');

  const tabs = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'signals' as Tab, label: 'Signals', icon: TrendingUp },
    { id: 'education' as Tab, label: 'Education', icon: GraduationCap },
  ];

  const fetchSignals = async () => {
    if (!hasSignalsAccess) return;
    
    setSignalsLoading(true);
    setSignalsError(null);

    try {
      const params = new URLSearchParams();
      if (assetType !== 'all') params.append('assetType', assetType);
      if (signalType !== 'all') params.append('signal', signalType);
      params.append('sortBy', sortBy);

      const { data: signalsData, error: signalsError } = await supabase.functions.invoke(
        `get-signals?${params.toString()}`
      );

      if (signalsError) {
        if (signalsError.message?.includes('SUBSCRIPTION_REQUIRED')) {
          setSignalsError('subscription_required');
        } else {
          throw signalsError;
        }
        return;
      }

      setSignals(signalsData?.signals || []);
    } catch (err) {
      console.error('Error fetching signals:', err);
      setSignalsError('Failed to load signals');
    } finally {
      setSignalsLoading(false);
    }
  };

  // Fetch signals when tab changes or filters change
  useEffect(() => {
    if (activeTab === 'signals' && hasSignalsAccess) {
      fetchSignals();
    }
  }, [activeTab, hasSignalsAccess, assetType, signalType, sortBy]);

  // Realtime subscription for signals
  useEffect(() => {
    if (!hasSignalsAccess) return;

    const channel = supabase
      .channel('mobile_signals_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'shared_signals',
        },
        (payload) => {
          const newSignal = payload.new as SharedSignal;
          setSignals((prev) => [newSignal, ...prev]);
          if (activeTab === 'signals') {
            toast({
              title: 'New Signal',
              description: `A new ${newSignal.signal} signal has been shared!`,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [hasSignalsAccess, activeTab]);

  if (authLoading) return null;
  if (!user) return <Navigate to="/login" replace />;

  const hasUploads = uploads.length > 0;
  const isAnalyzing = uploads.some(u => u.isAnalyzing);
  const hasAnalysis = uploads.some(u => u.analysis);
  const selectedAnalysis = uploads.find(u => u.analysis)?.analysis;

  const handleAnalyzeChart = async (id: string) => {
    if (!canAnalyze) {
      toast({
        title: 'Free Limit Reached',
        description: 'Upgrade to Pro for unlimited analyses.',
        variant: 'destructive',
      });
      return;
    }

    const allowed = await incrementAnalysisCount();
    if (!allowed) {
      toast({
        title: 'Free Limit Reached',
        description: 'Upgrade to Pro for unlimited analyses.',
        variant: 'destructive',
      });
      return;
    }

    await analyzeChart(id);
  };

  const handleAnalyzeAll = async () => {
    const chartsToAnalyze = uploads.filter(u => !u.analysis && !u.isAnalyzing);
    
    for (const upload of chartsToAnalyze) {
      if (!canAnalyze) {
        toast({
          title: 'Free Limit Reached',
          description: 'Upgrade to Pro for unlimited analyses.',
          variant: 'destructive',
        });
        break;
      }
      
      const allowed = await incrementAnalysisCount();
      if (!allowed) {
        toast({
          title: 'Free Limit Reached',
          description: 'Upgrade to Pro for unlimited analyses.',
          variant: 'destructive',
        });
        break;
      }
      
      await analyzeChart(upload.id);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      {/* Main Content Area */}
      <main className="flex-1 container mx-auto px-4 py-4 pb-24 overflow-y-auto">
        {activeTab === 'dashboard' && (
          <div className="space-y-4">
            {/* Disclaimer Banner */}
            <Alert className="border-yellow-500/50 bg-yellow-500/10">
              <AlertTriangle className="h-4 w-4 text-yellow-500 shrink-0" />
              <AlertDescription className="text-yellow-200 text-xs">
                <strong>Risk Disclaimer:</strong> {disclaimer}
              </AlertDescription>
            </Alert>

            <div>
              <h1 className="text-xl font-bold">Chart Analysis</h1>
              <p className="text-sm text-muted-foreground">Upload charts for AI-powered signals</p>
            </div>

            {/* Show upgrade prompt if limit reached */}
            {!canAnalyze && <UpgradePrompt />}
            
            {canAnalyze && (
              <>
                <ChartUploader onUpload={addUpload} />

                {hasUploads && (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm text-muted-foreground">{uploads.length} chart(s)</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={clearAll}>
                        <Trash2 className="w-4 h-4 mr-1" /> Clear
                      </Button>
                      <Button size="sm" onClick={handleAnalyzeAll} disabled={isAnalyzing}>
                        {isAnalyzing ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Zap className="w-4 h-4 mr-1" />}
                        Analyze
                      </Button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {uploads.map(upload => (
                    <ChartPreview
                      key={upload.id}
                      upload={upload}
                      onRemove={removeUpload}
                      onTimeframeChange={updateTimeframe}
                      onAnalyze={handleAnalyzeChart}
                    />
                  ))}
                </div>
              </>
            )}

            {hasAnalysis && selectedAnalysis && (
              <AnalysisCard 
                analysis={selectedAnalysis} 
                timeframe={uploads.find(u => u.analysis)?.timeframe || ''} 
                assetType={uploads.find(u => u.analysis)?.assetType}
              />
            )}
          </div>
        )}

        {activeTab === 'signals' && (
          <div className="space-y-4">
            {/* Header with Refresh */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl font-bold flex items-center gap-2">
                  <Radio className="w-5 h-5 text-primary" />
                  Signals
                </h1>
                <p className="text-xs text-muted-foreground">Real-time community signals</p>
              </div>
              {hasSignalsAccess && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={fetchSignals}
                  disabled={signalsLoading}
                >
                  <RefreshCw className={`w-4 h-4 ${signalsLoading ? 'animate-spin' : ''}`} />
                </Button>
              )}
            </div>

            {/* Show upgrade prompt for users without signals access */}
            {!hasSignalsAccess ? (
              <UpgradePrompt 
                title="Unlock Community Signals"
                description="Subscribe to access real-time trading signals shared by the community."
                showAlways
              />
            ) : (
              <>
                {/* Filters */}
                <SignalsFilter
                  assetType={assetType}
                  signalType={signalType}
                  sortBy={sortBy}
                  onAssetTypeChange={setAssetType}
                  onSignalTypeChange={setSignalType}
                  onSortByChange={setSortBy}
                />

                {/* Signals Content */}
                {signalsLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : signalsError ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground text-sm">{signalsError}</p>
                    <Button variant="outline" size="sm" onClick={fetchSignals} className="mt-4">
                      Try Again
                    </Button>
                  </div>
                ) : signals.length === 0 ? (
                  <div className="text-center py-12">
                    <Radio className="w-10 h-10 mx-auto mb-3 text-muted-foreground/50" />
                    <h2 className="font-medium mb-1">No signals yet</h2>
                    <p className="text-muted-foreground text-xs">
                      Be the first to share a signal!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {signals.map((signal) => (
                      <SignalCard key={signal.id} signal={signal} />
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {activeTab === 'education' && (
          <div className="space-y-4">
            <div>
              <h1 className="text-xl font-bold flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-primary" />
                Education
              </h1>
              <p className="text-xs text-muted-foreground">Beginner-friendly trading lessons</p>
            </div>

            <div className="space-y-3">
              {/* Lesson 1: Money Management */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">💰</span>
                    <div>
                      <h3 className="font-semibold text-sm">Money Management</h3>
                      <p className="text-xs text-muted-foreground">Protect your capital</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">Rule #1: Never risk more than you can afford to lose.</strong></p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Only trade with money you can afford to lose completely</li>
                    <li>Keep trading capital separate from living expenses</li>
                    <li>Start small and grow your account gradually</li>
                    <li>Never borrow money to trade</li>
                  </ul>
                  <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                    <p className="text-xs"><strong className="text-primary">Pro Tip:</strong> A good rule is to keep at least 6 months of living expenses in savings before trading with any additional funds.</p>
                  </div>
                </div>
              </details>

              {/* Lesson 2: Risk Management */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">🛡️</span>
                    <div>
                      <h3 className="font-semibold text-sm">Risk Management</h3>
                      <p className="text-xs text-muted-foreground">The key to survival</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">The 1-2% Rule:</strong> Never risk more than 1-2% of your total account on a single trade.</p>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs font-mono">Example: $10,000 account × 2% = $200 max risk per trade</p>
                  </div>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>Always use stop losses</strong> - No exceptions!</li>
                    <li>Calculate your risk BEFORE entering a trade</li>
                    <li>Aim for at least 1:2 risk-reward ratio</li>
                    <li>Accept that losses are part of trading</li>
                  </ul>
                  <div className="p-3 bg-bearish/10 rounded-lg border border-bearish/20">
                    <p className="text-xs"><strong className="text-bearish">Warning:</strong> Trading without stop losses is the #1 reason beginners blow their accounts.</p>
                  </div>
                </div>
              </details>

              {/* Lesson 3: How to Avoid FOMO */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">😰</span>
                    <div>
                      <h3 className="font-semibold text-sm">How to Avoid FOMO</h3>
                      <p className="text-xs text-muted-foreground">Fear of missing out</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">FOMO leads to poor decisions.</strong> The market will always provide new opportunities.</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>Stick to your trading plan</strong> - If you missed the entry, wait for the next setup</li>
                    <li>Never chase a trade that's already moved significantly</li>
                    <li>Remember: there are thousands of trading opportunities every week</li>
                    <li>The best traders are patient traders</li>
                  </ul>
                  <div className="p-3 bg-hold/10 rounded-lg border border-hold/20">
                    <p className="text-xs"><strong className="text-hold">Remember:</strong> "The market is a device for transferring money from the impatient to the patient." - Warren Buffett</p>
                  </div>
                </div>
              </details>

              {/* Lesson 4: Position Sizing */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">📏</span>
                    <div>
                      <h3 className="font-semibold text-sm">Position Sizing</h3>
                      <p className="text-xs text-muted-foreground">Calculate your lot size</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">Position size determines how much you risk.</strong></p>
                  <div className="p-3 bg-muted rounded-lg space-y-2">
                    <p className="text-xs font-semibold text-foreground">Formula:</p>
                    <p className="text-xs font-mono">Position Size = Risk Amount ÷ (Entry - Stop Loss)</p>
                    <p className="text-xs mt-2">Example: Risk $100, Entry at $50, Stop at $48</p>
                    <p className="text-xs font-mono">$100 ÷ ($50 - $48) = 50 shares</p>
                  </div>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Use our Risk Calculator in the Dashboard</li>
                    <li>Adjust position size based on stop loss distance</li>
                    <li>Larger stop loss = smaller position size</li>
                  </ul>
                </div>
              </details>

              {/* Lesson 5: Handling Drawdowns */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">📉</span>
                    <div>
                      <h3 className="font-semibold text-sm">Handling Drawdowns</h3>
                      <p className="text-xs text-muted-foreground">Surviving losing streaks</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">Every trader experiences drawdowns.</strong> It's how you handle them that matters.</p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>Reduce position size</strong> during losing streaks</li>
                    <li>Take a break if you lose 5+ trades in a row</li>
                    <li>Review your trades - look for patterns in your losses</li>
                    <li>Never revenge trade to "make back" losses</li>
                    <li>Set a maximum daily/weekly loss limit</li>
                  </ul>
                  <div className="p-3 bg-bearish/10 rounded-lg border border-bearish/20">
                    <p className="text-xs"><strong className="text-bearish">Recovery Math:</strong> A 50% loss requires a 100% gain to break even. Protect your capital!</p>
                  </div>
                </div>
              </details>

              {/* Lesson 6: How to Use AfriTrade Signals */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">🎯</span>
                    <div>
                      <h3 className="font-semibold text-sm">How to Use UpTraView Signals</h3>
                      <p className="text-xs text-muted-foreground">Get the most from our AI</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">UpTraView signals are tools, not guarantees.</strong></p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>Upload clear, complete charts</strong> - Include key support/resistance levels</li>
                    <li>Use signals as confirmation, not blind entries</li>
                    <li>Check multiple timeframes for confluence</li>
                    <li>Always apply your own risk management rules</li>
                    <li>Higher confidence scores = stronger setups</li>
                  </ul>
                  <div className="p-3 bg-bullish/10 rounded-lg border border-bullish/20">
                    <p className="text-xs"><strong className="text-bullish">Best Practice:</strong> Wait for signals that align with the overall market trend. Trade with the trend, not against it.</p>
                  </div>
                </div>
              </details>

              {/* Lesson 7: Common Beginner Mistakes */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">❌</span>
                    <div>
                      <h3 className="font-semibold text-sm">Common Beginner Mistakes</h3>
                      <p className="text-xs text-muted-foreground">Avoid these pitfalls</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">Learn from others' mistakes:</strong></p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li><strong>Overtrading</strong> - Quality over quantity</li>
                    <li><strong>No trading plan</strong> - Random entries = random results</li>
                    <li><strong>Moving stop losses</strong> - Set it and forget it</li>
                    <li><strong>Risking too much</strong> - The 1-2% rule exists for a reason</li>
                    <li><strong>Not keeping a journal</strong> - Track every trade</li>
                    <li><strong>Trading too many pairs</strong> - Master 2-3 instruments first</li>
                    <li><strong>Ignoring the trend</strong> - "The trend is your friend"</li>
                  </ul>
                </div>
              </details>

              {/* Lesson 8: Mindset */}
              <details className="group bg-card rounded-lg border overflow-hidden">
                <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">🧠</span>
                    <div>
                      <h3 className="font-semibold text-sm">Think in Probabilities</h3>
                      <p className="text-xs text-muted-foreground">The winning mindset</p>
                    </div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
                </summary>
                <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                  <p><strong className="text-foreground">Professional traders think in probabilities, not individual trades.</strong></p>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs">A strategy with 60% win rate will still lose 4 out of 10 trades. That's normal!</p>
                  </div>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Focus on the process, not individual outcomes</li>
                    <li>Judge your trading over 50-100 trades, not 5</li>
                    <li>A losing trade following your plan is a good trade</li>
                    <li>Detach emotions from money</li>
                    <li>Consistency beats occasional big wins</li>
                  </ul>
                  <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                    <p className="text-xs"><strong className="text-primary">Mindset Shift:</strong> Ask "Did I follow my plan?" instead of "Did I make money?"</p>
                  </div>
                </div>
              </details>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-background border-t z-50">
        <div className="flex justify-around items-center h-16 max-w-md mx-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "flex flex-col items-center justify-center w-full h-full gap-1 transition-colors",
                activeTab === tab.id
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default Mobile;
