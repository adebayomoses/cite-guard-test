import { useState, useEffect } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Header } from '@/components/Header';
import { SignalCard } from '@/components/SignalCard';
import { SignalsFilter } from '@/components/SignalsFilter';
import { UpgradePrompt } from '@/components/UpgradePrompt';
import { BottomNavigation } from '@/components/BottomNavigation';
import { useAuth } from '@/hooks/useAuth';
import { useSubscription } from '@/hooks/useSubscription';
import { useIsMobile } from '@/hooks/use-mobile';
import { supabase } from '@/integrations/supabase/client';
import { SharedSignal } from '@/types/signal';
import { Loader2, Radio, RefreshCw, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

const Signals = () => {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth();
  const { tier, isLoading: subLoading, hasSignalsAccess } = useSubscription();
  const isMobile = useIsMobile();
  const [signals, setSignals] = useState<SharedSignal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Filter state
  const [assetType, setAssetType] = useState('all');
  const [signalType, setSignalType] = useState('all');
  const [sortBy, setSortBy] = useState('created_at');

  const fetchSignals = async () => {
    if (!hasSignalsAccess) return;
    
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams();
      if (assetType !== 'all') params.append('assetType', assetType);
      if (signalType !== 'all') params.append('signal', signalType);
      params.append('sortBy', sortBy);

      const { data, error } = await supabase.functions.invoke('get-signals', {
        body: null,
        headers: {
          'Content-Type': 'application/json',
        },
      });

      // We need to pass query params differently - re-invoke with proper URL
      const { data: signalsData, error: signalsError } = await supabase.functions.invoke(
        `get-signals?${params.toString()}`
      );

      if (signalsError) {
        if (signalsError.message?.includes('SUBSCRIPTION_REQUIRED')) {
          setError('subscription_required');
        } else {
          throw signalsError;
        }
        return;
      }

      setSignals(signalsData?.signals || []);
    } catch (err) {
      console.error('Error fetching signals:', err);
      setError('Failed to load signals');
      toast({
        title: 'Error',
        description: 'Failed to load signals. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch signals on mount and when filters change
  useEffect(() => {
    if (hasSignalsAccess) {
      fetchSignals();
    } else {
      setLoading(false);
    }
  }, [hasSignalsAccess, assetType, signalType, sortBy]);

  // Set up realtime subscription
  useEffect(() => {
    if (!hasSignalsAccess) return;

    const channel = supabase
      .channel('shared_signals_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'shared_signals',
        },
        (payload) => {
          // Add new signal to the top of the list
          const newSignal = payload.new as SharedSignal;
          setSignals((prev) => [newSignal, ...prev]);
          toast({
            title: 'New Signal',
            description: `A new ${newSignal.signal} signal has been shared!`,
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [hasSignalsAccess]);

  // Show loading while checking auth
  if (authLoading || subLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Show upgrade prompt for users without signals access
  if (!hasSignalsAccess) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <main className="flex-1 container py-8 px-4">
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <Radio className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h1 className="text-2xl font-bold mb-2">Community Signals</h1>
              <p className="text-muted-foreground">
                Access trading signals shared by our community of traders
              </p>
            </div>
            <UpgradePrompt 
              title="Unlock Community Signals"
              description="Subscribe to the Social plan ($4/mo) or higher to access real-time trading signals shared by the community."
              showAlways
            />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <main className={`flex-1 container py-6 px-4 ${isMobile ? 'pb-24' : ''}`}>
        {/* Back Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>

        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Radio className="w-6 h-6 text-primary" />
              Community Signals
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Real-time trading signals from the community (expires after 24h)
            </p>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={fetchSignals}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {/* Filters */}
        <div className="mb-6">
          <SignalsFilter
            assetType={assetType}
            signalType={signalType}
            sortBy={sortBy}
            onAssetTypeChange={setAssetType}
            onSignalTypeChange={setSignalType}
            onSortByChange={setSortBy}
          />
        </div>

        {/* Content */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">{error}</p>
            <Button variant="outline" onClick={fetchSignals} className="mt-4">
              Try Again
            </Button>
          </div>
        ) : signals.length === 0 ? (
          <div className="text-center py-12">
            <Radio className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <h2 className="text-lg font-medium mb-2">No signals yet</h2>
            <p className="text-muted-foreground text-sm">
              Be the first to share a signal! Analyze a chart and click "Share Signal" to contribute.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {signals.map((signal) => (
              <SignalCard key={signal.id} signal={signal} />
            ))}
          </div>
        )}
      </main>

      <BottomNavigation />
    </div>
  );
};

export default Signals;
