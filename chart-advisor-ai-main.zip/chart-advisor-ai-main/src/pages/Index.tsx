import { Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { TrendingUp, Shield, Zap, BarChart3, ArrowRight } from 'lucide-react';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero */}
        <section className="container py-12 md:py-24 text-center px-4">
          <div className="inline-flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 bg-primary/10 rounded-full text-primary text-xs md:text-sm font-medium mb-6 md:mb-8">
            <Zap className="w-3 h-3 md:w-4 md:h-4" />
            AI-Powered Trading Signals
          </div>
          
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-4 md:mb-6 tracking-tight">
            Analyze Charts.<br />
            <span className="text-primary">Trade Smarter.</span>
          </h1>
          
          <p className="text-base md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 md:mb-10 px-4">
            Our AI is trained to read and analyze charts like a professional trader. Upload your screenshots and get instant signals with entry prices, stop losses, and take profit targets.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 md:gap-4 px-4">
            <Link to="/signup" className="w-full sm:w-auto">
              <Button size="lg" className="text-base md:text-lg px-6 md:px-8 w-full sm:w-auto">
                Start Analyzing <ArrowRight className="ml-2 w-4 h-4 md:w-5 md:h-5" />
              </Button>
            </Link>
            <Link to="/login" className="w-full sm:w-auto">
              <Button size="lg" variant="outline" className="text-base md:text-lg px-6 md:px-8 w-full sm:w-auto">
                Sign In
              </Button>
            </Link>
          </div>
        </section>

        {/* Features */}
        <section className="container py-12 md:py-24 border-t border-border px-4">
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-8">
            <div className="terminal-card p-6 md:p-8 text-center">
              <div className="w-12 h-12 md:w-14 md:h-14 bg-bullish/20 rounded-xl flex items-center justify-center mx-auto mb-3 md:mb-4">
                <TrendingUp className="w-6 h-6 md:w-7 md:h-7 text-bullish" />
              </div>
              <h3 className="text-lg md:text-xl font-bold mb-2">Instant Signals</h3>
              <p className="text-sm md:text-base text-muted-foreground">Get BUY, SELL, or HOLD recommendations with confidence scores in seconds.</p>
            </div>
            <div className="terminal-card p-6 md:p-8 text-center">
              <div className="w-12 h-12 md:w-14 md:h-14 bg-primary/20 rounded-xl flex items-center justify-center mx-auto mb-3 md:mb-4">
                <BarChart3 className="w-6 h-6 md:w-7 md:h-7 text-primary" />
              </div>
              <h3 className="text-lg md:text-xl font-bold mb-2">Technical Analysis</h3>
              <p className="text-sm md:text-base text-muted-foreground">AI detects patterns, support/resistance levels, and trend direction.</p>
            </div>
            <div className="terminal-card p-6 md:p-8 text-center sm:col-span-2 md:col-span-1">
              <div className="w-12 h-12 md:w-14 md:h-14 bg-hold/20 rounded-xl flex items-center justify-center mx-auto mb-3 md:mb-4">
                <Shield className="w-6 h-6 md:w-7 md:h-7 text-hold" />
              </div>
              <h3 className="text-lg md:text-xl font-bold mb-2">Risk Management</h3>
              <p className="text-sm md:text-base text-muted-foreground">Calculate position sizes and see potential profit/loss before trading.</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Index;
