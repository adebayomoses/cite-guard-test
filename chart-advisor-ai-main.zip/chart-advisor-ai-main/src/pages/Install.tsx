import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { Button } from '@/components/ui/button';
import { TrendingUp, Download, Smartphone, Check, Share, Plus } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const Install = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Detect iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent);
    setIsIOS(isIOSDevice);

    // Listen for install prompt
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container py-8 md:py-16 px-4">
        <div className="max-w-2xl mx-auto text-center">
          {/* Icon */}
          <div className="w-24 h-24 md:w-32 md:h-32 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-6 md:mb-8 shadow-2xl">
            <TrendingUp className="w-12 h-12 md:w-16 md:h-16 text-primary-foreground" />
          </div>

          <h1 className="text-3xl md:text-4xl font-bold mb-4">Install UpTraView AI</h1>
          <p className="text-muted-foreground text-base md:text-lg mb-8 md:mb-10">
            Add UpTraView AI to your home screen for quick access, offline capabilities, and a native app experience.
          </p>

          {isInstalled ? (
            <div className="terminal-card p-6 md:p-8 mb-8">
              <div className="w-16 h-16 bg-bullish/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-bullish" />
              </div>
              <h2 className="text-xl font-bold mb-2">Already Installed!</h2>
              <p className="text-muted-foreground mb-4">
                UpTraView AI is already installed on your device.
              </p>
              <Link to="/dashboard">
                <Button size="lg">Open Dashboard</Button>
              </Link>
            </div>
          ) : deferredPrompt ? (
            <Button size="lg" onClick={handleInstall} className="text-lg px-8 mb-8">
              <Download className="w-5 h-5 mr-2" />
              Install App
            </Button>
          ) : isIOS ? (
            <div className="terminal-card p-6 md:p-8 mb-8 text-left">
              <h2 className="text-xl font-bold mb-4 text-center">Install on iOS</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">1</span>
                  </div>
                  <div>
                    <p className="font-medium">Tap the Share button</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      Look for <Share className="w-4 h-4" /> at the bottom of Safari
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Scroll and tap "Add to Home Screen"</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      Look for <Plus className="w-4 h-4" /> Add to Home Screen
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Tap "Add" to confirm</p>
                    <p className="text-sm text-muted-foreground">The app will appear on your home screen</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="terminal-card p-6 md:p-8 mb-8 text-left">
              <h2 className="text-xl font-bold mb-4 text-center">Install on Android / Desktop</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">1</span>
                  </div>
                  <div>
                    <p className="font-medium">Open browser menu</p>
                    <p className="text-sm text-muted-foreground">Tap the three dots (⋮) in Chrome or your browser</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">2</span>
                  </div>
                  <div>
                    <p className="font-medium">Select "Install app" or "Add to Home screen"</p>
                    <p className="text-sm text-muted-foreground">The option name varies by browser</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center shrink-0">
                    <span className="font-bold">3</span>
                  </div>
                  <div>
                    <p className="font-medium">Confirm installation</p>
                    <p className="text-sm text-muted-foreground">The app will be added to your home screen or app drawer</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Benefits */}
          <div className="grid sm:grid-cols-3 gap-4 text-left">
            <div className="terminal-card p-4 md:p-6">
              <Smartphone className="w-8 h-8 text-primary mb-3" />
              <h3 className="font-bold mb-1">Native Feel</h3>
              <p className="text-sm text-muted-foreground">Full-screen experience without browser UI</p>
            </div>
            <div className="terminal-card p-4 md:p-6">
              <Download className="w-8 h-8 text-bullish mb-3" />
              <h3 className="font-bold mb-1">Works Offline</h3>
              <p className="text-sm text-muted-foreground">Access the app even without internet</p>
            </div>
            <div className="terminal-card p-4 md:p-6">
              <TrendingUp className="w-8 h-8 text-hold mb-3" />
              <h3 className="font-bold mb-1">Quick Access</h3>
              <p className="text-sm text-muted-foreground">Launch instantly from your home screen</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Install;
