import { GraduationCap, ChevronDown } from 'lucide-react';
import { Header } from '@/components/Header';
import { BottomNavigation } from '@/components/BottomNavigation';
import { useIsMobile } from '@/hooks/use-mobile';

const Education = () => {
  const isMobile = useIsMobile();

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className={`flex-1 container mx-auto px-4 py-6 ${isMobile ? 'pb-24' : ''}`}>
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="mb-6">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <GraduationCap className="w-6 h-6 text-primary" />
              Education
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Beginner-friendly trading lessons</p>
          </div>

          <div className="space-y-3">
            {/* Lesson 1: Money Management */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">💰</span>
                  <div>
                    <h3 className="font-semibold text-sm">Money Management</h3>
                    <p className="text-xs text-muted-foreground">Protect your capital</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Rule #1: Never risk more than you can afford to lose.</strong></p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Only trade with money you can afford to lose completely</li>
                  <li>Keep trading capital separate from living expenses</li>
                  <li>Start small and grow your account gradually</li>
                  <li>Never borrow money to trade</li>
                </ul>
                <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-xs"><strong className="text-primary">Pro Tip:</strong> A good rule is to keep at least 6 months of living expenses in savings before trading with any additional funds.</p>
                </div>
              </div>
            </details>

            {/* Lesson 2: Risk Management */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">🛡️</span>
                  <div>
                    <h3 className="font-semibold text-sm">Risk Management</h3>
                    <p className="text-xs text-muted-foreground">The key to survival</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">The 1-2% Rule:</strong> Never risk more than 1-2% of your total account on a single trade.</p>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs font-mono">Example: $10,000 account × 2% = $200 max risk per trade</p>
                </div>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Always use stop losses</strong> - No exceptions!</li>
                  <li>Calculate your risk BEFORE entering a trade</li>
                  <li>Aim for at least 1:2 risk-reward ratio</li>
                  <li>Accept that losses are part of trading</li>
                </ul>
                <div className="p-3 bg-bearish/10 rounded-lg border border-bearish/20">
                  <p className="text-xs"><strong className="text-bearish">Warning:</strong> Trading without stop losses is the #1 reason beginners blow their accounts.</p>
                </div>
              </div>
            </details>

            {/* Lesson 3: How to Avoid FOMO */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">😰</span>
                  <div>
                    <h3 className="font-semibold text-sm">How to Avoid FOMO</h3>
                    <p className="text-xs text-muted-foreground">Fear of missing out</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">FOMO leads to poor decisions.</strong> The market will always provide new opportunities.</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Stick to your trading plan</strong> - If you missed the entry, wait for the next setup</li>
                  <li>Never chase a trade that's already moved significantly</li>
                  <li>Remember: there are thousands of trading opportunities every week</li>
                  <li>The best traders are patient traders</li>
                </ul>
                <div className="p-3 bg-hold/10 rounded-lg border border-hold/20">
                  <p className="text-xs"><strong className="text-hold">Remember:</strong> "The market is a device for transferring money from the impatient to the patient." - Warren Buffett</p>
                </div>
              </div>
            </details>

            {/* Lesson 4: Position Sizing */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">📏</span>
                  <div>
                    <h3 className="font-semibold text-sm">Position Sizing</h3>
                    <p className="text-xs text-muted-foreground">Calculate your lot size</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Position sizing determines how much you trade based on your risk.</strong></p>
                <div className="p-3 bg-muted rounded-lg space-y-2">
                  <p className="text-xs font-semibold text-foreground">Formula:</p>
                  <p className="text-xs font-mono">Position Size = (Account × Risk %) ÷ (Entry - Stop Loss)</p>
                </div>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Always calculate position size before entering</li>
                  <li>Larger stop loss = smaller position size</li>
                  <li>Use our built-in Risk Calculator on the Dashboard</li>
                  <li>Never increase position size to "make back" losses</li>
                </ul>
              </div>
            </details>

            {/* Lesson 5: Handling Drawdowns */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">📉</span>
                  <div>
                    <h3 className="font-semibold text-sm">Handling Drawdowns & Losing Streaks</h3>
                    <p className="text-xs text-muted-foreground">Stay in the game</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Every trader experiences losing streaks. How you handle them matters most.</strong></p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Reduce position size</strong> after 3+ consecutive losses</li>
                  <li>Take a break - step away from the screens</li>
                  <li>Review your trades: was it bad luck or bad decisions?</li>
                  <li>Never try to "revenge trade" to recover losses quickly</li>
                  <li>Set a maximum daily/weekly loss limit and stick to it</li>
                </ul>
                <div className="p-3 bg-bearish/10 rounded-lg border border-bearish/20">
                  <p className="text-xs"><strong className="text-bearish">Critical:</strong> If you lose 10% of your account, stop trading and reassess your strategy.</p>
                </div>
              </div>
            </details>

            {/* Lesson 6: How to Use AfriTrade Signals */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">📡</span>
                  <div>
                    <h3 className="font-semibold text-sm">How to Use AfriTrade Signals</h3>
                    <p className="text-xs text-muted-foreground">Maximize your results</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Our AI signals are tools to assist your decision-making, not replace it.</strong></p>
                <ul className="list-disc pl-5 space-y-1">
                  <li><strong>Verify signals</strong> against your own analysis</li>
                  <li>Check the confidence level - higher is better</li>
                  <li>Always use the provided stop loss and take profit levels</li>
                  <li>Consider the timeframe - longer timeframes are more reliable</li>
                  <li>Don't blindly follow every signal - use discretion</li>
                </ul>
                <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
                  <p className="text-xs"><strong className="text-primary">Best Practice:</strong> Only trade signals that align with the overall market trend and your personal analysis.</p>
                </div>
              </div>
            </details>

            {/* Lesson 7: Common Beginner Mistakes */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">⚠️</span>
                  <div>
                    <h3 className="font-semibold text-sm">Common Beginner Mistakes</h3>
                    <p className="text-xs text-muted-foreground">Learn from others' errors</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Avoid these costly mistakes that most beginners make:</strong></p>
                <ol className="list-decimal pl-5 space-y-2">
                  <li><strong>Overtrading</strong> - Trading too frequently or with too much size</li>
                  <li><strong>No stop loss</strong> - "It will come back" mentality</li>
                  <li><strong>Moving stop losses</strong> - Widening stops to avoid being stopped out</li>
                  <li><strong>Taking profits too early</strong> - Fear of giving back gains</li>
                  <li><strong>Averaging down</strong> - Adding to losing positions</li>
                  <li><strong>Trading with emotions</strong> - Fear and greed drive bad decisions</li>
                  <li><strong>No trading plan</strong> - Entering trades randomly</li>
                </ol>
              </div>
            </details>

            {/* Lesson 8: Think in Probabilities */}
            <details className="group bg-card rounded-lg border overflow-hidden">
              <summary className="p-4 cursor-pointer flex items-center justify-between hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <span className="text-lg">🧠</span>
                  <div>
                    <h3 className="font-semibold text-sm">Think in Probabilities, Not Profits</h3>
                    <p className="text-xs text-muted-foreground">The professional mindset</p>
                  </div>
                </div>
                <ChevronDown className="w-4 h-4 text-muted-foreground group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-sm text-muted-foreground space-y-3">
                <p><strong className="text-foreground">Professional traders think differently than beginners.</strong></p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Every trade has an <strong>uncertain outcome</strong></li>
                  <li>You don't need to win every trade - just win more than you lose</li>
                  <li>A 40% win rate can be profitable with good risk-reward</li>
                  <li>Focus on <strong>executing your edge</strong> over many trades</li>
                  <li>Judge your trading by the quality of decisions, not individual outcomes</li>
                </ul>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs font-semibold text-foreground mb-2">Example:</p>
                  <p className="text-xs">If you risk $100 to make $200 (1:2 RR) and win 40% of trades:</p>
                  <p className="text-xs font-mono mt-1">10 trades = 4 wins × $200 - 6 losses × $100 = +$200 profit</p>
                </div>
                <div className="p-3 bg-bullish/10 rounded-lg border border-bullish/20">
                  <p className="text-xs"><strong className="text-bullish">Key Insight:</strong> Trading is a game of probabilities. Your job is to find edges and exploit them consistently over time.</p>
                </div>
              </div>
            </details>
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  );
};

export default Education;
