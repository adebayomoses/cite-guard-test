-- Create a function to validate email matches authenticated user
CREATE OR REPLACE FUNCTION public.validate_support_inquiry_email()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_email TEXT;
BEGIN
  -- Get the authenticated user's email from auth.users
  SELECT email INTO user_email
  FROM auth.users
  WHERE id = NEW.user_id;
  
  -- Validate that the email matches the authenticated user's email
  IF NEW.email IS NOT NULL AND NEW.email != user_email THEN
    RAISE EXCEPTION 'Email must match the authenticated user''s email address';
  END IF;
  
  -- If email is null, set it to the user's email
  IF NEW.email IS NULL THEN
    NEW.email := user_email;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to validate email on insert
CREATE TRIGGER validate_support_inquiry_email_trigger
BEFORE INSERT ON public.support_inquiries
FOR EACH ROW
EXECUTE FUNCTION public.validate_support_inquiry_email();