-- Add column to track daily reset
ALTER TABLE public.user_usage 
ADD COLUMN IF NOT EXISTS daily_count INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_reset_date DATE NOT NULL DEFAULT CURRENT_DATE;

-- Update the increment function to handle daily resets
CREATE OR REPLACE FUNCTION public.increment_analysis_count(p_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_count INTEGER;
  current_daily INTEGER;
  last_reset DATE;
BEGIN
  -- Get current values or insert new record
  SELECT daily_count, last_reset_date INTO current_daily, last_reset
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    -- New user, create record
    INSERT INTO public.user_usage (user_id, analysis_count, daily_count, last_reset_date, last_analysis_at)
    VALUES (p_user_id, 1, 1, CURRENT_DATE, now())
    RETURNING analysis_count INTO new_count;
  ELSIF last_reset < CURRENT_DATE THEN
    -- New day, reset daily count
    UPDATE public.user_usage
    SET 
      analysis_count = analysis_count + 1,
      daily_count = 1,
      last_reset_date = CURRENT_DATE,
      last_analysis_at = now(),
      updated_at = now()
    WHERE user_id = p_user_id
    RETURNING analysis_count INTO new_count;
  ELSE
    -- Same day, increment both counts
    UPDATE public.user_usage
    SET 
      analysis_count = analysis_count + 1,
      daily_count = daily_count + 1,
      last_analysis_at = now(),
      updated_at = now()
    WHERE user_id = p_user_id
    RETURNING analysis_count INTO new_count;
  END IF;
  
  RETURN new_count;
END;
$$;

-- Create function to get daily count (resets if new day)
CREATE OR REPLACE FUNCTION public.get_daily_count(p_user_id uuid)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  count_val INTEGER;
  last_reset DATE;
BEGIN
  SELECT daily_count, last_reset_date INTO count_val, last_reset
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- If it's a new day, return 0 (count will be reset on next increment)
  IF last_reset < CURRENT_DATE THEN
    RETURN 0;
  END IF;
  
  RETURN COALESCE(count_val, 0);
END;
$$;