-- Add restrictive UPDATE policy to user_usage table
-- This prevents users from directly modifying their usage counts
-- All legitimate updates must go through the increment_analysis_count RPC function

CREATE POLICY "No direct user updates to usage"
ON public.user_usage
FOR UPDATE
USING (false)
WITH CHECK (false);