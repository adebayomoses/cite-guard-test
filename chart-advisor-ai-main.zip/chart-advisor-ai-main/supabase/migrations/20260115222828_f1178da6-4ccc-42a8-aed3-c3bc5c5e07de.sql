-- Create shared_signals table for community signals
CREATE TABLE public.shared_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  signal TEXT NOT NULL CHECK (signal IN ('BUY', 'SELL', 'HOLD')),
  confidence INTEGER NOT NULL CHECK (confidence >= 0 AND confidence <= 100),
  asset_type TEXT NOT NULL CHECK (asset_type IN ('forex', 'crypto', 'commodities', 'indices', 'stocks')),
  timeframe TEXT NOT NULL,
  entry_price TEXT NOT NULL,
  stop_loss TEXT NOT NULL,
  take_profit TEXT NOT NULL,
  risk_reward_ratio TEXT NOT NULL,
  patterns TEXT[] DEFAULT '{}',
  trend TEXT,
  momentum TEXT,
  summary TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '24 hours')
);

-- Enable RLS
ALTER TABLE public.shared_signals ENABLE ROW LEVEL SECURITY;

-- Users can insert their own signals
CREATE POLICY "Users can insert their own signals"
ON public.shared_signals
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can view their own signals (for tracking what they shared)
CREATE POLICY "Users can view their own signals"
ON public.shared_signals
FOR SELECT
USING (auth.uid() = user_id);

-- Create index for efficient querying
CREATE INDEX idx_shared_signals_expires_at ON public.shared_signals(expires_at);
CREATE INDEX idx_shared_signals_created_at ON public.shared_signals(created_at DESC);
CREATE INDEX idx_shared_signals_asset_type ON public.shared_signals(asset_type);
CREATE INDEX idx_shared_signals_signal ON public.shared_signals(signal);

-- Enable realtime for this table
ALTER PUBLICATION supabase_realtime ADD TABLE public.shared_signals;