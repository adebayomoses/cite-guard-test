-- Create table to track user chart analysis usage
CREATE TABLE public.user_usage (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  analysis_count INTEGER NOT NULL DEFAULT 0,
  last_analysis_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_usage ENABLE ROW LEVEL SECURITY;

-- Users can only view their own usage
CREATE POLICY "Users can view their own usage"
ON public.user_usage
FOR SELECT
USING (auth.uid() = user_id);

-- Users can update their own usage (incrementing count happens via edge function with service role)
CREATE POLICY "Users can insert their own usage"
ON public.user_usage
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Create function to increment analysis count
CREATE OR REPLACE FUNCTION public.increment_analysis_count(p_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_count INTEGER;
BEGIN
  INSERT INTO public.user_usage (user_id, analysis_count, last_analysis_at)
  VALUES (p_user_id, 1, now())
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    analysis_count = user_usage.analysis_count + 1,
    last_analysis_at = now(),
    updated_at = now()
  RETURNING analysis_count INTO new_count;
  
  RETURN new_count;
END;
$$;

-- Create function to get user analysis count
CREATE OR REPLACE FUNCTION public.get_analysis_count(p_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  count_val INTEGER;
BEGIN
  SELECT analysis_count INTO count_val
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  RETURN COALESCE(count_val, 0);
END;
$$;