-- Create table for admin-assigned subscription overrides
CREATE TABLE public.subscription_overrides (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  tier TEXT NOT NULL CHECK (tier IN ('free', 'social', 'standard', 'pro')),
  assigned_by UUID NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.subscription_overrides ENABLE ROW LEVEL SECURITY;

-- Admins can view all overrides
CREATE POLICY "Admins can view all subscription overrides"
ON public.subscription_overrides
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can insert overrides
CREATE POLICY "Admins can insert subscription overrides"
ON public.subscription_overrides
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Admins can update overrides
CREATE POLICY "Admins can update subscription overrides"
ON public.subscription_overrides
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Admins can delete overrides
CREATE POLICY "Admins can delete subscription overrides"
ON public.subscription_overrides
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Users can view their own override (for subscription checking)
CREATE POLICY "Users can view their own subscription override"
ON public.subscription_overrides
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_subscription_overrides_updated_at
BEFORE UPDATE ON public.subscription_overrides
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add index for faster lookups
CREATE INDEX idx_subscription_overrides_user_id ON public.subscription_overrides(user_id);