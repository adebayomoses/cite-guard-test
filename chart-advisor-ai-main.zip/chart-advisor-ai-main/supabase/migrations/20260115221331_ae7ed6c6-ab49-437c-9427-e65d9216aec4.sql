-- Add email column to support_inquiries
ALTER TABLE public.support_inquiries ADD COLUMN email text;

-- Update existing rows to set email to null (they'll be updated manually if needed)
-- New inquiries will have email populated from the submission