-- Fix usage tracking functions to validate caller authorization

-- Drop and recreate get_analysis_count with authorization check
CREATE OR REPLACE FUNCTION public.get_analysis_count(p_user_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  count_val INTEGER;
BEGIN
  -- Validate that the caller is authorized to access this user's data
  IF auth.uid() IS NULL OR auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Unauthorized access';
  END IF;

  SELECT analysis_count INTO count_val
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  RETURN COALESCE(count_val, 0);
END;
$function$;

-- Drop and recreate get_daily_count with authorization check
CREATE OR REPLACE FUNCTION public.get_daily_count(p_user_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  count_val INTEGER;
  last_reset DATE;
BEGIN
  -- Validate that the caller is authorized to access this user's data
  IF auth.uid() IS NULL OR auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Unauthorized access';
  END IF;

  SELECT daily_count, last_reset_date INTO count_val, last_reset
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- If it's a new day, return 0 (count will be reset on next increment)
  IF last_reset < CURRENT_DATE THEN
    RETURN 0;
  END IF;
  
  RETURN COALESCE(count_val, 0);
END;
$function$;

-- Drop and recreate increment_analysis_count with authorization check
CREATE OR REPLACE FUNCTION public.increment_analysis_count(p_user_id uuid)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  new_count INTEGER;
  current_daily INTEGER;
  last_reset DATE;
BEGIN
  -- Validate that the caller is authorized to access this user's data
  IF auth.uid() IS NULL OR auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Unauthorized access';
  END IF;

  -- Get current values or insert new record
  SELECT daily_count, last_reset_date INTO current_daily, last_reset
  FROM public.user_usage
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    -- New user, create record
    INSERT INTO public.user_usage (user_id, analysis_count, daily_count, last_reset_date, last_analysis_at)
    VALUES (p_user_id, 1, 1, CURRENT_DATE, now())
    RETURNING analysis_count INTO new_count;
  ELSIF last_reset < CURRENT_DATE THEN
    -- New day, reset daily count
    UPDATE public.user_usage
    SET 
      analysis_count = analysis_count + 1,
      daily_count = 1,
      last_reset_date = CURRENT_DATE,
      last_analysis_at = now(),
      updated_at = now()
    WHERE user_id = p_user_id
    RETURNING analysis_count INTO new_count;
  ELSE
    -- Same day, increment both counts
    UPDATE public.user_usage
    SET 
      analysis_count = analysis_count + 1,
      daily_count = daily_count + 1,
      last_analysis_at = now(),
      updated_at = now()
    WHERE user_id = p_user_id
    RETURNING analysis_count INTO new_count;
  END IF;
  
  RETURN new_count;
END;
$function$;