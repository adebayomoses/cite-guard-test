import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[GET-ADMIN-STATS] ${step}${detailsStr}`);
};

// Safe timestamp conversion to prevent "Invalid time value" errors
const safeTimestampToISO = (timestamp: number | null | undefined): string => {
  if (!timestamp || typeof timestamp !== 'number') {
    return 'N/A';
  }
  try {
    return new Date(timestamp * 1000).toISOString();
  } catch {
    return 'N/A';
  }
};

// Map Stripe product IDs to tier names
const PRODUCT_TIER_MAP: Record<string, string> = {
  'prod_SWGk93dJGx2t5C': 'Social',
  'prod_SWGjFgN68FqAJO': 'Standard',
  'prod_SWGhwxZEJcmFHN': 'Pro',
};

interface SubscriberInfo {
  email: string;
  tier: string;
  productId: string;
  status: string;
  startDate: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  customerId: string;
}

interface UserInfo {
  id: string;
  email: string;
  tier: string;
  source: 'stripe' | 'override' | 'free';
  created_at: string;
  override_expires_at?: string;
}

interface AdminStats {
  totalUsers: number;
  totalAnalyses: number;
  activeToday: number;
  newUsersThisWeek: number;
  subscribers: SubscriberInfo[];
  users: UserInfo[];
  tierDistribution: Record<string, number>;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Function started");

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error("Configuration error: Missing Supabase configuration");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 503,
      });
    }
    if (!stripeKey) {
      console.error("Configuration error: STRIPE_SECRET_KEY is not set");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 503,
      });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false }
    });

    // Verify admin role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Authentication required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseAdmin.auth.getUser(token);
    if (userError) {
      console.error("Auth error:", userError.message);
      return new Response(JSON.stringify({ error: "Authentication failed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }
    
    const userId = userData.user?.id;
    if (!userId) {
      return new Response(JSON.stringify({ error: "Authentication failed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Check if user is admin
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .eq('role', 'admin')
      .maybeSingle();

    if (roleError) {
      console.error("Role check error:", roleError.message);
      return new Response(JSON.stringify({ error: "Access denied" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    if (!roleData) {
      return new Response(JSON.stringify({ error: "Access denied" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }

    logStep("Admin verified", { userId });

    // Get total users count from auth.users
    const { data: allUsersData, error: usersError } = await supabaseAdmin.auth.admin.listUsers({
      perPage: 1000,
      page: 1,
    });
    
    if (usersError) {
      logStep("Error fetching users", { error: usersError.message });
    }
    const actualTotalUsers = allUsersData?.users?.length || 0;
    logStep("Total users fetched", { totalUsers: actualTotalUsers });

    // Get usage statistics
    const { data: usageData, error: usageError } = await supabaseAdmin
      .from('user_usage')
      .select('analysis_count, daily_count, last_reset_date, last_analysis_at');

    if (usageError) {
      logStep("Error fetching usage data", { error: usageError.message });
    }

    const today = new Date().toISOString().split('T')[0];
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    let totalAnalyses = 0;
    let activeToday = 0;
    
    if (usageData) {
      totalAnalyses = usageData.reduce((sum, u) => sum + (u.analysis_count || 0), 0);
      activeToday = usageData.filter(u => {
        if (!u.last_analysis_at) return false;
        return u.last_analysis_at.split('T')[0] === today;
      }).length;
    }

    logStep("Usage stats calculated", { totalAnalyses, activeToday });

    // Count new users this week
    const newUsersThisWeek = allUsersData?.users?.filter(u => {
      const createdAt = new Date(u.created_at);
      return createdAt >= oneWeekAgo;
    }).length || 0;

    // Get subscription overrides
    const { data: overrides, error: overridesError } = await supabaseAdmin
      .from('subscription_overrides')
      .select('user_id, tier, expires_at');
    
    if (overridesError) {
      logStep("Error fetching overrides", { error: overridesError.message });
    }

    const overrideMap = new Map<string, { tier: string; expires_at: string | null }>();
    if (overrides) {
      const now = new Date();
      for (const o of overrides) {
        const expiresAt = o.expires_at ? new Date(o.expires_at) : null;
        if (!expiresAt || expiresAt > now) {
          overrideMap.set(o.user_id, { tier: o.tier, expires_at: o.expires_at });
        }
      }
    }

    logStep("Subscription overrides fetched", { count: overrideMap.size });

    // Get Stripe subscriptions
    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    
    const subscriptions = await stripe.subscriptions.list({
      limit: 100,
      expand: ['data.customer'],
    });

    logStep("Stripe subscriptions fetched", { count: subscriptions.data.length });

    const subscribers: SubscriberInfo[] = [];
    const stripeEmailToTier = new Map<string, string>();
    const tierDistribution: Record<string, number> = {
      'Social': 0,
      'Standard': 0,
      'Pro': 0,
      'Free': actualTotalUsers,
    };

    for (const sub of subscriptions.data) {
      const customer = sub.customer as Stripe.Customer;
      const productId = sub.items.data[0]?.price?.product as string;
      const tier = PRODUCT_TIER_MAP[productId] || 'Unknown';
      
      subscribers.push({
        email: customer.email || 'N/A',
        tier,
        productId,
        status: sub.status,
        startDate: safeTimestampToISO(sub.start_date),
        currentPeriodEnd: safeTimestampToISO(sub.current_period_end),
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        customerId: customer.id,
      });

      // Track email to tier mapping for active subscriptions
      if ((sub.status === 'active' || sub.status === 'trialing') && customer.email) {
        stripeEmailToTier.set(customer.email.toLowerCase(), tier);
        if (tierDistribution[tier] !== undefined) {
          tierDistribution[tier]++;
          tierDistribution['Free']--;
        }
      }
    }

    // Build users list with tier info
    const users: UserInfo[] = [];
    if (allUsersData?.users) {
      for (const authUser of allUsersData.users) {
        const override = overrideMap.get(authUser.id);
        const stripeTier = authUser.email ? stripeEmailToTier.get(authUser.email.toLowerCase()) : null;
        
        let tier = 'Free';
        let source: 'stripe' | 'override' | 'free' = 'free';
        let overrideExpiresAt: string | undefined;

        if (override) {
          // Admin override takes priority
          tier = override.tier.charAt(0).toUpperCase() + override.tier.slice(1);
          source = 'override';
          overrideExpiresAt = override.expires_at || undefined;
          
          // Adjust tier distribution for overrides (that aren't already counted by Stripe)
          if (!stripeTier && override.tier !== 'free') {
            const tierName = tier;
            if (tierDistribution[tierName] !== undefined) {
              tierDistribution[tierName]++;
              tierDistribution['Free']--;
            }
          }
        } else if (stripeTier) {
          tier = stripeTier;
          source = 'stripe';
        }

        users.push({
          id: authUser.id,
          email: authUser.email || 'N/A',
          tier,
          source,
          created_at: authUser.created_at,
          override_expires_at: overrideExpiresAt,
        });
      }
    }

    // Ensure Free count doesn't go negative
    tierDistribution['Free'] = Math.max(0, tierDistribution['Free']);

    const stats: AdminStats = {
      totalUsers: actualTotalUsers,
      totalAnalyses,
      activeToday,
      newUsersThisWeek,
      subscribers,
      users,
      tierDistribution,
    };

    logStep("Stats compiled successfully");

    return new Response(JSON.stringify(stats), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: "Unable to fetch admin statistics" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
