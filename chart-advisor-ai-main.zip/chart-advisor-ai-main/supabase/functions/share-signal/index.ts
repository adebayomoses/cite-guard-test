import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SignalData {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  assetType: string;
  timeframe: string;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  riskRewardRatio: string;
  patterns: string[];
  trend: string;
  momentum: string;
  summary: string;
}

// Validation constants
const MAX_SUMMARY_LENGTH = 5000;
const MAX_PRICE_LENGTH = 50;
const MAX_PATTERN_LENGTH = 100;
const MAX_PATTERNS_COUNT = 20;
const MAX_TIMEFRAME_LENGTH = 20;
const MAX_ASSET_TYPE_LENGTH = 50;
const VALID_SIGNALS = ['BUY', 'SELL', 'HOLD'];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get the auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase client with user's auth
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    // Get the authenticated user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Not authenticated' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse request body
    const signalData: SignalData = await req.json();

    // Validate required fields
    if (!signalData.signal || signalData.confidence === undefined || !signalData.assetType || 
        !signalData.timeframe || !signalData.entryPrice || !signalData.stopLoss || 
        !signalData.takeProfit || !signalData.summary) {
      return new Response(
        JSON.stringify({ error: 'Missing required signal data' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate signal type
    if (!VALID_SIGNALS.includes(signalData.signal)) {
      return new Response(
        JSON.stringify({ error: 'Invalid signal type' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate confidence is a number between 0-100
    if (typeof signalData.confidence !== 'number' || signalData.confidence < 0 || signalData.confidence > 100) {
      return new Response(
        JSON.stringify({ error: 'Confidence must be a number between 0 and 100' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate string length limits
    if (signalData.summary.length > MAX_SUMMARY_LENGTH) {
      return new Response(
        JSON.stringify({ error: 'Summary too long (max 5000 characters)' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (signalData.entryPrice.length > MAX_PRICE_LENGTH || 
        signalData.stopLoss.length > MAX_PRICE_LENGTH || 
        signalData.takeProfit.length > MAX_PRICE_LENGTH) {
      return new Response(
        JSON.stringify({ error: 'Price values too long' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (signalData.timeframe.length > MAX_TIMEFRAME_LENGTH) {
      return new Response(
        JSON.stringify({ error: 'Timeframe too long' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (signalData.assetType.length > MAX_ASSET_TYPE_LENGTH) {
      return new Response(
        JSON.stringify({ error: 'Asset type too long' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate patterns array
    const patterns = signalData.patterns || [];
    if (!Array.isArray(patterns)) {
      return new Response(
        JSON.stringify({ error: 'Patterns must be an array' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (patterns.length > MAX_PATTERNS_COUNT) {
      return new Response(
        JSON.stringify({ error: 'Too many patterns (max 20)' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate each pattern
    for (const pattern of patterns) {
      if (typeof pattern !== 'string' || pattern.length > MAX_PATTERN_LENGTH) {
        return new Response(
          JSON.stringify({ error: 'Invalid pattern format' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Insert the signal using service role to bypass RLS for insert
    const supabaseAdmin = createClient(
      supabaseUrl,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data, error } = await supabaseAdmin
      .from('shared_signals')
      .insert({
        user_id: user.id,
        signal: signalData.signal,
        confidence: Math.round(signalData.confidence), // Ensure integer
        asset_type: signalData.assetType.slice(0, MAX_ASSET_TYPE_LENGTH),
        timeframe: signalData.timeframe.slice(0, MAX_TIMEFRAME_LENGTH),
        entry_price: signalData.entryPrice.slice(0, MAX_PRICE_LENGTH),
        stop_loss: signalData.stopLoss.slice(0, MAX_PRICE_LENGTH),
        take_profit: signalData.takeProfit.slice(0, MAX_PRICE_LENGTH),
        risk_reward_ratio: (signalData.riskRewardRatio || '').slice(0, MAX_PRICE_LENGTH),
        patterns: patterns.slice(0, MAX_PATTERNS_COUNT).map(p => String(p).slice(0, MAX_PATTERN_LENGTH)),
        trend: (signalData.trend || '').slice(0, 100),
        momentum: (signalData.momentum || '').slice(0, 100),
        summary: signalData.summary.slice(0, MAX_SUMMARY_LENGTH),
      })
      .select()
      .single();

    if (error) {
      console.error('Error inserting signal:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to share signal' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, signalId: data.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in share-signal function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
