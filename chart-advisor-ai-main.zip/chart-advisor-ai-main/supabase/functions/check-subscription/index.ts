import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Map product IDs to tier names
const PRODUCT_TIER_MAP: Record<string, string> = {
  'prod_TniQZgTn0JIdZu': 'social',
  'prod_TniVrNkPKLCj52': 'standard',
  'prod_TniYtMGtgQGAQ2': 'pro',
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) {
      console.error("Configuration error: STRIPE_SECRET_KEY is not set");
      return new Response(JSON.stringify({ error: "Service temporarily unavailable" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 503,
      });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Authentication required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Extract the JWT token
    const token = authHeader.replace("Bearer ", "");

    // Create client with anon key and user's auth header for token verification
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Use getClaims to verify the token (works with ES256 signing keys)
    const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(token);
    
    // Log the actual structure to debug
    console.log("getClaims result:", JSON.stringify({ data: claimsData, error: claimsError?.message }));
    
    if (claimsError || !claimsData) {
      console.error("Auth error:", claimsError?.message || "No claims data");
      return new Response(JSON.stringify({ error: "Authentication failed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }
    
    // Handle the claims - extract from the nested structure
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const claimsObj = (claimsData as any).claims || claimsData;
    const userId = claimsObj?.sub as string;
    const userEmail = claimsObj?.email as string;
    
    if (!userId) {
      console.error("Auth error: missing sub claim in", JSON.stringify(claimsData));
      return new Response(JSON.stringify({ error: "Authentication failed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Create service role client for database operations
    const supabaseClient = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false }
    });

    if (!userEmail) {
      return new Response(JSON.stringify({ error: "Authentication failed" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // First check for admin-assigned subscription override
    const { data: override, error: overrideError } = await supabaseClient
      .from('subscription_overrides')
      .select('tier, expires_at')
      .eq('user_id', userId)
      .maybeSingle();

    if (!overrideError && override) {
      // Check if override has expired
      const now = new Date();
      const expiresAt = override.expires_at ? new Date(override.expires_at) : null;
      
      if (!expiresAt || expiresAt > now) {
        // Override is valid - use admin-assigned tier
        return new Response(JSON.stringify({
          subscribed: override.tier !== 'free',
          product_id: null,
          subscription_end: override.expires_at,
          tier_override: override.tier,
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 200,
        });
      }
    }

    // No valid override - check Stripe subscription
    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    const customers = await stripe.customers.list({ email: userEmail, limit: 1 });

    if (customers.data.length === 0) {
      // No customer = no subscription
      return new Response(JSON.stringify({ subscribed: false }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const customerId = customers.data[0].id;
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "active",
      limit: 1,
    });

    const hasActiveSub = subscriptions.data.length > 0;
    let subscriptionEnd = null;
    let productId = null;

    if (hasActiveSub) {
      const subscription = subscriptions.data[0];
      console.log('Stripe subscription data:', JSON.stringify({
        id: subscription.id,
        current_period_end: subscription.current_period_end,
        items_first: subscription.items?.data?.[0]
      }));
      
      // Safely parse subscription end date - handle multiple possible locations
      const periodEnd = subscription.current_period_end 
        || subscription.items?.data?.[0]?.current_period_end
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        || (subscription.items?.data?.[0]?.plan as any)?.current_period_end;
      
      if (periodEnd && typeof periodEnd === 'number') {
        try {
          subscriptionEnd = new Date(periodEnd * 1000).toISOString();
        } catch (dateError) {
          console.error('Failed to parse subscription end date:', dateError);
          // Continue without end date - subscription status is more important
        }
      }
      
      productId = subscription.items?.data?.[0]?.price?.product 
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        || (subscription.items?.data?.[0]?.plan as any)?.product;
    }

    return new Response(JSON.stringify({
      subscribed: hasActiveSub,
      product_id: productId,
      subscription_end: subscriptionEnd,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("Check subscription error:", errorMessage);
    return new Response(JSON.stringify({ error: "Unable to check subscription status" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
