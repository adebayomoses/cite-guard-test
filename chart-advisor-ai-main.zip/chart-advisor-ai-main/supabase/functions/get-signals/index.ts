import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Product IDs for tiers with signals access
const SIGNALS_ACCESS_PRODUCT_IDS = [
  'prod_TniQZgTn0JIdZu', // Social
  'prod_TniVrNkPKLCj52', // Standard
  'prod_TniYtMGtgQGAQ2', // Pro
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get the auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create Supabase client with user's auth
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    // Get the authenticated user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Not authenticated' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user is an admin (admins have full access)
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: adminData } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .maybeSingle();

    const isAdmin = !!adminData;

    // Skip subscription check if user is admin
    let isSubscriber = isAdmin;

    if (!isAdmin) {
      // Check if user has an active subscription using Stripe
      const stripeKey = Deno.env.get('STRIPE_SECRET_KEY');
      if (!stripeKey) {
        return new Response(
          JSON.stringify({ error: 'Payment service not configured' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Search for customer by email
      const customerResponse = await fetch(
        `https://api.stripe.com/v1/customers/search?query=email:'${user.email}'`,
        {
          headers: {
            'Authorization': `Bearer ${stripeKey}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );
      const customerData = await customerResponse.json();

      if (customerData.data && customerData.data.length > 0) {
        const customerId = customerData.data[0].id;

        // Check for active subscriptions
        const subscriptionResponse = await fetch(
          `https://api.stripe.com/v1/subscriptions?customer=${customerId}&status=active`,
          {
            headers: {
              'Authorization': `Bearer ${stripeKey}`,
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        );
        const subscriptionData = await subscriptionResponse.json();

        if (subscriptionData.data && subscriptionData.data.length > 0) {
          // Check if any subscription matches our signals access product IDs
          for (const sub of subscriptionData.data) {
            for (const item of sub.items.data) {
              if (SIGNALS_ACCESS_PRODUCT_IDS.includes(item.price.product)) {
                isSubscriber = true;
                break;
              }
            }
            if (isSubscriber) break;
          }
        }
      }
    }

    if (!isSubscriber) {
      return new Response(
        JSON.stringify({ error: 'Subscription required', code: 'SUBSCRIPTION_REQUIRED' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse query params for filtering
    const url = new URL(req.url);
    const assetType = url.searchParams.get('assetType');
    const signalType = url.searchParams.get('signal');
    const sortBy = url.searchParams.get('sortBy') || 'created_at';

    // Reuse supabaseAdmin for querying signals (already created above)

    let query = supabaseAdmin
      .from('shared_signals')
      .select('*')
      .gt('expires_at', new Date().toISOString());

    // Apply filters
    if (assetType && assetType !== 'all') {
      query = query.eq('asset_type', assetType);
    }
    if (signalType && signalType !== 'all') {
      query = query.eq('signal', signalType);
    }

    // Apply sorting
    if (sortBy === 'confidence') {
      query = query.order('confidence', { ascending: false });
    } else {
      query = query.order('created_at', { ascending: false });
    }

    // Limit results
    query = query.limit(50);

    const { data: signals, error } = await query;

    if (error) {
      console.error('Error fetching signals:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch signals' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ signals }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in get-signals function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
