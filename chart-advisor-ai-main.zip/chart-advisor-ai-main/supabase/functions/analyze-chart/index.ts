import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalysisResult {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  riskRewardRatio: string;
  technicalBreakdown: {
    patterns: string[];
    supportLevels: string[];
    resistanceLevels: string[];
    trend: string;
    momentum: string;
    volatility: string;
  };
  timeframeAnalysis: string;
  summary: string;
}

// Tier-based daily limits
const TIER_LIMITS: Record<string, number> = {
  free: 2,
  social: 3,
  standard: 9,
  pro: 20,
};

// Product IDs for tier determination (Live mode)
const PRODUCT_TIERS: Record<string, string> = {
  'prod_TniQZgTn0JIdZu': 'social',
  'prod_TniVrNkPKLCj52': 'standard',
  'prod_TniYtMGtgQGAQ2': 'pro',
};

// Valid asset types
const VALID_ASSET_TYPES = ['forex', 'crypto', 'commodities', 'indices', 'stocks'];

// Valid timeframes
const VALID_TIMEFRAMES = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w', '1M', 'M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1', 'MN'];

// Max image size (10MB as base64 = ~13.7MB)
const MAX_IMAGE_SIZE = 10 * 1024 * 1024 * 1.37;

// Valid image MIME types
const VALID_MIME_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authentication check
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with user's auth
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user authentication using getUser
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid authentication token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userId = user.id;
    const userEmail = user.email;

    // Initialize admin Supabase client for privileged queries
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const adminSupabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if user is an admin (bypass all limits)
    let isAdmin = false;
    try {
      const { data: adminRole } = await adminSupabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .eq('role', 'admin')
        .maybeSingle();

      isAdmin = !!adminRole;
      console.log(`User ${userId} - isAdmin: ${isAdmin}`);
    } catch (adminCheckError) {
      console.error('Admin check error:', adminCheckError);
      // Continue without admin privileges
    }

    // Check user's subscription tier to determine limits
    let tier = isAdmin ? 'admin' : 'free';

    // First check for admin-assigned subscription override (skip for admins)
    if (!isAdmin) {
      try {
        const { data: override } = await adminSupabase
          .from('subscription_overrides')
          .select('tier, expires_at')
          .eq('user_id', userId)
          .maybeSingle();

        if (override && (!override.expires_at || new Date(override.expires_at) > new Date())) {
          tier = override.tier;
        }
      } catch (overrideError) {
        console.error('Override lookup error:', overrideError);
        // Continue to check Stripe
      }
    }

    // If no valid override, check Stripe subscription (skip for admins)
    if (!isAdmin && tier === 'free') {
      const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY');
      
      if (stripeSecretKey && userEmail) {
        try {
          // Search for customer by email
          const customerSearchResponse = await fetch(
            `https://api.stripe.com/v1/customers/search?query=email:'${userEmail}'`,
            {
              headers: {
                'Authorization': `Bearer ${stripeSecretKey}`,
                'Content-Type': 'application/x-www-form-urlencoded',
              },
            }
          );

          const customerSearchData = await customerSearchResponse.json();
          const customerId = customerSearchData.data?.[0]?.id;

          if (customerId) {
            // Get active subscriptions
            const subscriptionsResponse = await fetch(
              `https://api.stripe.com/v1/subscriptions?customer=${customerId}&status=active`,
              {
                headers: {
                  'Authorization': `Bearer ${stripeSecretKey}`,
                },
              }
            );

            const subscriptionsData = await subscriptionsResponse.json();
            const activeSubscription = subscriptionsData.data?.[0];

            if (activeSubscription) {
              const productId = activeSubscription.items?.data?.[0]?.price?.product;
              if (productId && PRODUCT_TIERS[productId]) {
                tier = PRODUCT_TIERS[productId];
              }
            }
          }
        } catch (stripeError) {
          console.error('Stripe lookup error:', stripeError);
          // Continue with free tier on Stripe errors
        }
      }
    }

    // Get current daily usage count
    const { data: dailyCountData, error: dailyCountError } = await supabase
      .rpc('get_daily_count', { p_user_id: userId });

    if (dailyCountError) {
      console.error('Error getting daily count:', dailyCountError);
    }

    const currentDailyCount = dailyCountData ?? 0;
    const dailyLimit = isAdmin ? 999 : (TIER_LIMITS[tier] ?? 3);

    // Check if user has exceeded their limit (admins bypass this check)
    if (!isAdmin && currentDailyCount >= dailyLimit) {
      return new Response(
        JSON.stringify({ 
          error: 'Daily analysis limit reached',
          limit: dailyLimit,
          tier: tier,
          upgradeRequired: tier !== 'pro'
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse request body
    const { imageBase64, timeframe, assetType = 'forex', traderNotes } = await req.json();

    // Sanitize trader notes (max 500 chars, trim whitespace)
    const sanitizedTraderNotes = traderNotes 
      ? String(traderNotes).trim().slice(0, 500) 
      : null;

    // Validate image is provided
    if (!imageBase64) {
      return new Response(
        JSON.stringify({ error: 'No image provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate image size
    if (imageBase64.length > MAX_IMAGE_SIZE) {
      return new Response(
        JSON.stringify({ error: 'Image too large (max 10MB)' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate image format (must be data URL or valid base64)
    if (imageBase64.startsWith('data:')) {
      const mimeMatch = imageBase64.match(/^data:(image\/[a-z]+);base64,/i);
      if (!mimeMatch) {
        return new Response(
          JSON.stringify({ error: 'Invalid image format' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const mimeType = mimeMatch[1].toLowerCase();
      if (!VALID_MIME_TYPES.includes(mimeType)) {
        return new Response(
          JSON.stringify({ error: 'Unsupported image type. Use PNG, JPEG, or WebP' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Validate asset type
    if (!VALID_ASSET_TYPES.includes(assetType)) {
      return new Response(
        JSON.stringify({ error: 'Invalid asset type' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate timeframe if provided (optional validation - allow flexible input)
    if (timeframe && typeof timeframe !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Invalid timeframe format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Sanitize timeframe - limit length
    const sanitizedTimeframe = timeframe ? String(timeframe).slice(0, 20) : '';

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('Configuration error: LOVABLE_API_KEY is not configured');
      return new Response(
        JSON.stringify({ error: 'Service temporarily unavailable' }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const getAssetContext = (type: string) => {
      switch (type) {
        case 'crypto':
          return `You are an expert cryptocurrency chart analyst AI specializing in crypto assets like Bitcoin (BTC), Ethereum (ETH), and other digital currencies.
         
Consider crypto-specific factors:
- 24/7 market operation (no market open/close gaps)
- Higher volatility typical of crypto markets
- Whale movements and large order impacts
- Exchange-specific patterns and volume
- Bitcoin dominance influence on altcoins
- Common crypto patterns: bart formations, liquidation cascades
- Consider wider stop losses due to crypto volatility`;
        case 'commodities':
          return `You are an expert commodities chart analyst AI specializing in precious metals (Gold, Silver), energy (Crude Oil, Natural Gas), and agricultural commodities.
         
Consider commodities-specific factors:
- Supply and demand fundamentals impact
- Seasonal patterns and cycles
- Geopolitical events and their influence
- USD correlation (inverse relationship with gold)
- Storage costs and contango/backwardation
- OPEC decisions for oil markets
- Weather impacts on agricultural commodities
- Trading hours for different commodity exchanges`;
        case 'indices':
          return `You are an expert stock indices chart analyst AI specializing in major indices like S&P 500, NASDAQ, Dow Jones, DAX, FTSE, and Nikkei.
         
Consider indices-specific factors:
- Market session hours and pre/post market gaps
- Sector rotation and component weighting
- Economic data releases impact (NFP, CPI, GDP)
- Earnings season effects
- VIX correlation for S&P 500
- Tech sector influence on NASDAQ
- Central bank policy impacts
- Risk-on/risk-off sentiment shifts`;
        case 'stocks':
          return `You are an expert individual stock chart analyst AI specializing in equities like AAPL, TSLA, NVDA, AMZN, and other publicly traded companies.
         
Consider stock-specific factors:
- Earnings reports and guidance impact
- Pre-market and after-hours trading gaps
- Sector and industry trends
- Company-specific news and catalysts
- Institutional ownership and buying/selling
- Options flow and unusual activity
- Analyst ratings and price targets
- Volume profile and relative volume`;
        default:
          return `You are an expert forex/currency chart analyst AI specializing in forex pairs.
         
Consider forex-specific factors:
- Trading session overlaps (London, New York, Tokyo, Sydney)
- Session-specific volatility patterns
- Major economic news impact windows
- Central bank policy influences
- Currency correlation patterns
- Typical forex pip ranges for the pair`;
      }
    };

    const assetContext = getAssetContext(assetType);

    // Build trader notes context if provided
    const traderNotesContext = sanitizedTraderNotes 
      ? `

TRADER'S ANALYSIS:
The trader has shared their own analysis and thoughts:
"${sanitizedTraderNotes}"

Please consider their analysis and in your summary:
1. Acknowledge their observations if relevant
2. Validate what they identified correctly (if anything)
3. Point out any patterns or signals they may have missed
4. Agree or politely disagree with their assessment, providing reasoning
5. Give them brief educational feedback to improve their chart reading skills`
      : '';

    const systemPrompt = `${assetContext}

Analyze the provided chart image and return a detailed trading signal analysis.

Your analysis must be based on technical analysis principles including:
- Price action and candlestick patterns
- Support and resistance levels
- Trend analysis (uptrend, downtrend, sideways)
- Momentum indicators visible in the chart
- Chart patterns (head and shoulders, triangles, channels, etc.)
${traderNotesContext}

IMPORTANT: You must respond with a valid JSON object matching this exact structure:
{
  "signal": "BUY" | "SELL" | "HOLD",
  "confidence": <number between 0-100>,
  "entryPrice": "<estimated entry price based on chart>",
  "stopLoss": "<recommended stop loss price>",
  "takeProfit": "<recommended take profit price>",
  "riskRewardRatio": "<ratio like 1:2 or 1:3>",
  "technicalBreakdown": {
    "patterns": ["<list of detected patterns>"],
    "supportLevels": ["<identified support levels>"],
    "resistanceLevels": ["<identified resistance levels>"],
    "trend": "<current trend direction and strength>",
    "momentum": "<momentum assessment>",
    "volatility": "<volatility assessment>"
  },
  "timeframeAnalysis": "<analysis specific to the ${timeframe || 'provided'} timeframe>",
  "summary": "<2-3 sentence summary of the analysis and recommendation${sanitizedTraderNotes ? ", including feedback on the trader's analysis" : ""}>"
}

Be precise with price levels based on what you see in the chart. If you cannot determine exact prices, provide reasonable estimates based on visible price action.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-pro',
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `Analyze this ${sanitizedTimeframe} ${assetType} chart and provide your trading signal analysis. Return ONLY valid JSON.`
              },
              {
                type: 'image_url',
                image_url: {
                  url: imageBase64.startsWith('data:') ? imageBase64 : `data:image/png;base64,${imageBase64}`
                }
              }
            ]
          }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again in a moment.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits to continue.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI');
    }

    // Parse JSON from the response (handle markdown code blocks)
    let analysisResult: AnalysisResult;
    try {
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/) || [null, content];
      const jsonStr = jsonMatch[1]?.trim() || content.trim();
      analysisResult = JSON.parse(jsonStr);
    } catch (parseError) {
      console.error('Failed to parse AI response:', content);
      throw new Error('Failed to parse AI analysis response');
    }

    // Increment usage count after successful analysis
    const { error: incrementError } = await supabase
      .rpc('increment_analysis_count', { p_user_id: userId });

    if (incrementError) {
      console.error('Error incrementing analysis count:', incrementError);
      // Don't fail the request if increment fails - analysis was already done
    }

    return new Response(
      JSON.stringify(analysisResult),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Analysis error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Analysis failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
