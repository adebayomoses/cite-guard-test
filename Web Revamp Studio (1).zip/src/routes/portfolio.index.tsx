import { createFileRoute, Link } from "@tanstack/react-router";

import { PageShell } from "@/components/page-shell";
import { projects } from "@/data/site";

export const Route = createFileRoute("/portfolio/")({
  component: PortfolioPage,
  head: () => ({
    meta: [
      { title: "Portfolio — Inwebtify Projects" },
      {
        name: "description",
        content:
          "Selected websites, platforms and product work delivered by Inwebtify for businesses across technology, energy, logistics, retail and wellbeing.",
      },
      { property: "og:title", content: "Portfolio — Inwebtify Projects" },
      {
        property: "og:description",
        content: "Selected websites, platforms and product work delivered by Inwebtify.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function PortfolioPage() {
  return (
    <PageShell
      eyebrow="Portfolio"
      title={
        <>
          Work we've <span className="font-light italic text-muted-foreground/40">shipped</span>.
        </>
      }
      lead="A selection of websites, platforms and products built for clients across technology, energy, logistics, retail and wellbeing."
    >
      <section className="px-6 pb-32">
        <div className="mx-auto grid max-w-7xl gap-12 md:grid-cols-2">
          {projects.map((p) => (
            <Link
              key={p.slug}
              to="/portfolio/$slug"
              params={{ slug: p.slug }}
              className="group block"
            >
              <div className="overflow-hidden rounded-2xl border border-foreground/10 bg-card">
                <img
                  src={p.image}
                  alt={`${p.title} website design by Inwebtify`}
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.03]"
                />
              </div>
              <span className="mt-6 block text-xs font-bold uppercase tracking-widest text-accent">
                {p.category}
              </span>
              <h2 className="mt-2 text-3xl font-bold tracking-tight">{p.title}</h2>
              <p className="mt-2 max-w-md leading-relaxed text-muted-foreground">{p.summary}</p>
            </Link>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
