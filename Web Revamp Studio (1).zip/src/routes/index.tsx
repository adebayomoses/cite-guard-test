import { createFileRoute, Link } from "@tanstack/react-router";

import heroImage from "@/assets/hero-office.jpg";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { posts, projects } from "@/data/site";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Inwebtify — Digital Solutions" },
      {
        name: "description",
        content:
          "At Inwebtify, we craft secure, modern websites and applications tailored to elevate your business. Our solutions deliver measurable growth.",
      },
      { property: "og:title", content: "Inwebtify — Digital Solutions" },
      {
        property: "og:description",
        content:
          "At Inwebtify, we craft secure, modern websites and applications tailored to elevate your business.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-accent selection:text-accent-foreground">
      <SiteHeader />


      {/* Hero Section */}
      <section className="px-6 pt-40 pb-24">
        <div className="mx-auto max-w-7xl">
          <div className="grid items-end gap-12 lg:grid-cols-12">
            <div className="lg:col-span-8">
              <span className="mb-6 block text-xs font-bold uppercase tracking-widest text-accent">
                Digital Excellence
              </span>
              <h1 className="text-balance text-6xl leading-[0.9] font-extrabold tracking-tight md:text-8xl">
                Digital <br />
                <span className="text-muted-foreground/30 font-light italic">Solutions</span>
              </h1>
              <p className="mt-8 max-w-xl text-xl leading-relaxed text-muted-foreground">
                At Inwebtify, we craft secure, modern websites and applications tailored to elevate
                your business. Our solutions deliver measurable growth and set you apart in a
                competitive digital world.
              </p>
            </div>
            <div className="flex flex-col items-start gap-6 lg:col-span-4 lg:items-end">
              <div className="flex -space-x-3">
                <div className="h-12 w-12 rounded-full border-2 border-background bg-steel-200" />
                <div className="h-12 w-12 rounded-full border-2 border-background bg-steel-600" />
                <div className="h-12 w-12 rounded-full border-2 border-background bg-accent" />
              </div>
              <p className="text-right text-sm font-medium text-muted-foreground">
                Trusted by innovators
                <br />
                worldwide.
              </p>
            </div>
          </div>

          <div className="mt-16">
            <div className="relative h-[400px] w-full overflow-hidden rounded-3xl md:h-[600px]">
              <img
                src={heroImage}
                alt="Modern Inwebtify workspace"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Band */}
      <section className="border-y border-foreground/5 bg-card px-6 py-16">
        <div className="mx-auto max-w-7xl">
          <div className="grid grid-cols-1 gap-12 sm:grid-cols-3">
            <div className="text-center sm:text-left">
              <div className="font-display text-5xl font-bold">115</div>
              <div className="mt-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Projects Completed
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="font-display text-5xl font-bold">98</div>
              <div className="mt-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Happy Clients
              </div>
            </div>
            <div className="text-center sm:text-left">
              <div className="font-display text-5xl font-bold">76</div>
              <div className="mt-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                Businesses Served
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="bg-foreground px-6 py-24 text-background">
        <div className="mx-auto max-w-7xl">
          <div className="mb-20 flex flex-col items-baseline justify-between gap-8 md:flex-row">
            <h2 className="text-4xl font-bold tracking-tight md:text-6xl">What We Do</h2>
            <p className="max-w-xs text-muted-foreground/80">
              Turning complex problems into elegant, functional digital solutions.
            </p>
          </div>

          <div className="grid gap-px overflow-hidden rounded-2xl border border-background/10 bg-background/10 md:grid-cols-3">
            <div className="group bg-foreground p-12 transition-colors hover:bg-background/5">
              <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 transition-transform group-hover:scale-110">
                <div className="h-6 w-6 border-2 border-accent" />
              </div>
              <h3 className="mb-4 text-2xl font-bold">Software Development</h3>
              <p className="leading-relaxed text-muted-foreground/80">
                Secure, scalable applications engineered to solve real business problems and
                drive operational efficiency.
              </p>
            </div>
            <div className="group bg-foreground p-12 transition-colors hover:bg-background/5">
              <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 transition-transform group-hover:scale-110">
                <div className="h-6 w-6 rounded-full border-2 border-accent" />
              </div>
              <h3 className="mb-4 text-2xl font-bold">Website Development</h3>
              <p className="leading-relaxed text-muted-foreground/80">
                Modern, responsive websites that elevate your brand and convert visitors into loyal
                customers.
              </p>
            </div>
            <div className="group bg-foreground p-12 transition-colors hover:bg-background/5">
              <div className="mb-8 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 transition-transform group-hover:scale-110">
                <div className="h-0 w-0 border-r-[12px] border-b-[20px] border-l-[12px] border-b-accent border-l-transparent border-r-transparent" />
              </div>
              <h3 className="mb-4 text-2xl font-bold">Web & App Optimization</h3>
              <p className="leading-relaxed text-muted-foreground/80">
                Performance tuning and user-experience refinements that keep your digital products
                fast, accessible, and effective.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Work */}
      <section id="work" className="px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 flex items-end justify-between">
            <div>
              <h2 className="mb-4 text-5xl font-bold tracking-tight">Selected Works</h2>
              <div className="h-1 w-24 bg-accent" />
            </div>
            <Link
              to="/portfolio"
              className="hidden border-b-2 border-foreground pb-1 text-sm font-bold uppercase tracking-widest sm:block"
            >
              View Archive
            </Link>
          </div>

          <div className="grid gap-12 md:grid-cols-2">
            {projects.slice(0, 4).map((project) => (
              <Link
                key={project.slug}
                to="/portfolio/$slug"
                params={{ slug: project.slug }}
                className="group cursor-pointer"
              >
                <div className="relative mb-6 aspect-[4/3] w-full overflow-hidden rounded-2xl bg-steel-100">
                  <img
                    src={project.image}
                    alt={`${project.title} project preview`}
                    className="h-full w-full object-cover transition-all duration-500 group-hover:-translate-y-2 group-hover:shadow-2xl"
                  />
                </div>
                <h4 className="text-xl font-bold">{project.title}</h4>
                <p className="text-muted-foreground">{project.category}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Blog / Recent Posts */}
      <section id="insights" className="bg-steel-100 px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16 flex items-end justify-between">
            <div>
              <h2 className="mb-4 text-5xl font-bold tracking-tight">Recent Posts</h2>
              <div className="h-1 w-24 bg-accent" />
            </div>
            <Link
              to="/blog"
              className="hidden border-b-2 border-foreground pb-1 text-sm font-bold uppercase tracking-widest sm:block"
            >
              All Insights
            </Link>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {posts.map((post) => (
              <Link
                key={post.slug}
                to="/blog/$slug"
                params={{ slug: post.slug }}
                className="group rounded-2xl bg-background p-8 transition-all hover:shadow-lg"
              >
                <span className="mb-4 block text-xs font-bold uppercase tracking-widest text-accent">
                  {post.date}
                </span>
                <h3 className="mb-4 text-2xl font-bold transition-colors group-hover:text-accent">
                  {post.title}
                </h3>
                <p className="text-muted-foreground">{post.excerpt}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

