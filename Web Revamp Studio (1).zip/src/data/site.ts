import caxustech from "@/assets/work/caxustech.jpg.asset.json";
import cedar from "@/assets/work/cedar-fuel-services.jpg.asset.json";
import deedee from "@/assets/work/deedee-oguma-home.jpg.asset.json";
import diy from "@/assets/work/diy-deedee.jpg.asset.json";
import forwarder from "@/assets/work/forwarder-one.jpg.asset.json";
import fytted from "@/assets/work/fyttedstudio.jpg.asset.json";
import mysanity from "@/assets/work/mysanity-app.jpg.asset.json";
import lezama from "@/assets/work/thelezama-group.jpg.asset.json";
import warrington from "@/assets/work/warrington-fireplace.jpg.asset.json";
import blogMysanity from "@/assets/work/blog-413-2.jpg.asset.json";
import blogTraining from "@/assets/work/blog-free-software-develo.jpg.asset.json";
import blogTools from "@/assets/work/blog-mahindra-to-lead-for.jpg.asset.json";

export type Project = {
  slug: string;
  title: string;
  category: string;
  summary: string;
  image: string;
  url?: string;
};

export const projects: Project[] = [
  {
    slug: "mysanity-app",
    title: "MySanity App",
    category: "Product Design & Development",
    summary:
      "MySanity app supports proactive mental well-being by helping people intervene early, before overwhelm turns into crisis.",
    image: mysanity.url,
    url: "https://mysanityapp.com/",
  },
  {
    slug: "caxustech",
    title: "Caxustech",
    category: "Website Development",
    summary: "A modern corporate web presence built for a growing technology services company.",
    image: caxustech.url,
    url: "https://www.caxustech.com/",
  },
  {
    slug: "cedar-fuel-services",
    title: "Cedar Fuel Services",
    category: "Website Development",
    summary: "Clear, trust-building website for an energy and fuel distribution business.",
    image: cedar.url,
    url: "https://cedarfuelservices.com/",
  },
  {
    slug: "deedee-oguma-home",
    title: "DeeDee Oguma Home",
    category: "Web Development & Brand Strategy",
    summary: "A warm, editorial home and lifestyle brand experience.",
    image: deedee.url,
    url: "https://deedeeogumahome.com/",
  },
  {
    slug: "diy-deedee",
    title: "Transformation Pursuit Life Coaching",
    category: "Website Development",
    summary: "A calm, conversion-focused site for a life coaching practice.",
    image: diy.url,
    url: "https://catherinermccray.wixsite.com/my-site",
  },
  {
    slug: "forwarder-one",
    title: "Forwarder One",
    category: "Web Development",
    summary: "A logistics platform front-end built for clarity, speed, and trust.",
    image: forwarder.url,
    url: "https://www.forwarderone.com/",
  },
  {
    slug: "fyttedstudio",
    title: "Fytted Studio",
    category: "Website Development",
    summary: "A bold studio presence for a logistics and solutions brand.",
    image: fytted.url,
    url: "https://www.foslogisticsolutions.com/lander",
  },
  {
    slug: "thelezama-group",
    title: "The Lezama Group",
    category: "Web Development & Brand Strategy",
    summary: "A refined corporate identity and website for a multi-service group.",
    image: lezama.url,
    url: "https://thelezamagroup.com/",
  },
  {
    slug: "warrington-fireplace",
    title: "Warrington Fireplace",
    category: "Web Development & Brand Strategy",
    summary: "A showroom-quality digital experience for a premium fireplace retailer.",
    image: warrington.url,
    url: "https://www.warringtonfireplace.com/",
  },
];

export type Post = {
  slug: string;
  title: string;
  date: string;
  category: string;
  excerpt: string;
  image: string;
  body: string[];
};

export const posts: Post[] = [
  {
    slug: "mysanity-proactive-mental-wellbeing",
    title: "MySanity supports proactive mental well-being",
    date: "December 25, 2025",
    category: "Mental Health Companion",
    excerpt:
      "MySanity supports proactive mental well-being by helping people intervene early, before overwhelm turns into crisis.",
    image: blogMysanity.url,
    body: [
      "MySanity supports proactive mental well-being by helping people intervene early, before overwhelm turns into crisis.",
      "MySanity is a mental wellbeing app designed to help people protect their mental health before reaching crisis point. Built around prevention rather than reaction, it uses guided journaling, mental health tracking, and a supportive community to help users process their thoughts, recognise early warning signs, and manage stress effectively.",
      "By identifying changes in mental wellbeing early, MySanity empowers users to take control of their mental health, build healthier habits, and prevent emotional and mental breakdowns before they happen.",
    ],
  },
  {
    slug: "free-software-development-training-program",
    title: "Free Software Development Training Program – 20 Slots Available",
    date: "April 19, 2024",
    category: "Announcements",
    excerpt:
      "Inwebtify Inc is pleased to announce an upcoming Free Software Development Training Program, created to support aspiring developers.",
    image: blogTraining.url,
    body: [
      "Inwebtify Inc is pleased to announce an upcoming Free Software Development Training Program, created to support aspiring developers and individuals looking to build practical, in-demand tech skills.",
      "This initiative is part of our commitment to skills development and talent growth in the digital economy. The training is completely free, with only 20 slots available, making it a highly selective opportunity for motivated participants.",
      "What the training will cover: web development fundamentals, front-end and back-end concepts, practical coding workflows, real-world project exposure, and industry best practices in software development. The program is designed to be practical and beginner-friendly, while also providing value to participants with some existing technical knowledge.",
      "Who can apply: beginners interested in starting a career in tech, students and recent graduates, professionals looking to transition into software development, and anyone passionate about learning practical digital skills. No prior professional experience is required — just a strong willingness to learn and commit.",
      "At Inwebtify Inc, we work on real digital products and solutions. Our training focuses on practical learning, mentorship, and exposure to real-world development processes that help participants understand how software is built in professional environments.",
      "Only 20 participants will be selected. To apply or learn more, send your full name and contact details to support@inwebtify.com with the subject “Software Development Training”.",
    ],
  },
  {
    slug: "building-digital-tools-that-solve-nigerias-challenges",
    title: "Building Digital Tools That Solve Nigeria’s Challenges",
    date: "October 20, 2022",
    category: "Community",
    excerpt:
      "Nigeria is a country rich in talent, creativity, and opportunity — and technology can address its most persistent challenges.",
    image: blogTools.url,
    body: [
      "Nigeria is a country rich in talent, creativity, and opportunity. Yet, many individuals and businesses continue to face persistent challenges such as unemployment, low digital literacy, data limitations, cybersecurity risks, and a growing mismatch between skills and available jobs. At Inwebtify, we believe technology can play a powerful role in addressing these issues, when it is built with purpose, context, and impact in mind.",
      "Inwebtify hosted a knowledge-driven session titled “Building Digital Tools That Solve Nigeria’s Challenges” at LT ART, Ekiti State University. The event brought together students, tech enthusiasts, and professionals to explore how digital innovation can be used as a practical solution to real societal problems.",
      "Why this conversation matters: unemployment continues to limit opportunities for young people, digital illiteracy slows adoption of modern tools, data shortages affect decision-making and innovation, cybersecurity threats put businesses and users at risk, and skill mismatches leave capable individuals disconnected from jobs. Rather than viewing these problems as barriers, Inwebtify sees them as opportunities for intentional technology design.",
      "Olaosebikan Samuel, Founder of Inwebtify, spoke about building user-centred digital products that are locally relevant yet globally scalable. Bankole Falana, Machine Learning Engineer, discussed how data and AI can improve decision-making, employment matching, and innovation. Adebayo Ayomide, Software Engineer, shared practical lessons on developing secure, scalable software systems.",
      "Beyond theory, the event focused on empowering attendees to build solutions for real problems around them, develop relevant digital skills, and think beyond code to impact, sustainability, and users. The goal was not just to inspire, but to equip.",
      "As we continue to collaborate with institutions, developers, and innovators, we remain committed to one principle: technology works best when it serves people.",
    ],
  },
];

export const contact = {
  address: ["4 Barika Street,", "Ibadan, Oyo, Nigeria"],
  phones: ["+234 813 198 5194", "+234 816 744 1861"],
  email: "support@inwebtify.com",
  hours: "24 hours a day, 7 days a week",
};
