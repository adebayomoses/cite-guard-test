import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface JournalEntry {
  id: string;
  user_id: string;
  title: string;
  content: string;
  mood: string;
  tags: string[];
  tickers_mentioned: string[];
  is_published: boolean;
  created_at: string;
  updated_at: string;
}

export interface JournalEntryInput {
  title: string;
  content: string;
  mood?: string;
  tags?: string[];
  tickers_mentioned?: string[];
  is_published?: boolean;
}

export const useJournal = (userId: string | undefined, isOwnProfile: boolean) => {
  const { user } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEntries = useCallback(async () => {
    if (!userId) {
      setEntries([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // If own profile, show all entries; otherwise show only published
      const query = supabase
        .from('journal_entries')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (!isOwnProfile) {
        query.eq('is_published', true);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      setEntries(data || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching journal entries:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch journal entries');
    } finally {
      setLoading(false);
    }
  }, [userId, isOwnProfile]);

  useEffect(() => {
    fetchEntries();
  }, [fetchEntries]);

  const createEntry = async (input: JournalEntryInput) => {
    if (!user) {
      toast.error('You must be logged in to create a journal entry');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('journal_entries')
        .insert({
          ...input,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      setEntries(prev => [data, ...prev]);
      toast.success('Journal entry created successfully');
      return data;
    } catch (err) {
      console.error('Error creating journal entry:', err);
      toast.error('Failed to create journal entry');
      return null;
    }
  };

  const updateEntry = async (id: string, input: Partial<JournalEntryInput>) => {
    if (!user) {
      toast.error('You must be logged in to update a journal entry');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('journal_entries')
        .update(input)
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      setEntries(prev => prev.map(e => e.id === id ? data : e));
      toast.success('Journal entry updated successfully');
      return data;
    } catch (err) {
      console.error('Error updating journal entry:', err);
      toast.error('Failed to update journal entry');
      return null;
    }
  };

  const deleteEntry = async (id: string) => {
    if (!user) {
      toast.error('You must be logged in to delete a journal entry');
      return false;
    }

    try {
      const { error } = await supabase
        .from('journal_entries')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      setEntries(prev => prev.filter(e => e.id !== id));
      toast.success('Journal entry deleted successfully');
      return true;
    } catch (err) {
      console.error('Error deleting journal entry:', err);
      toast.error('Failed to delete journal entry');
      return false;
    }
  };

  const togglePublish = async (id: string, isPublished: boolean) => {
    return updateEntry(id, { is_published: isPublished });
  };

  return { entries, loading, error, createEntry, updateEntry, deleteEntry, togglePublish, refetch: fetchEntries };
};
