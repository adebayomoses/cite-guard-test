import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface SiteSettings {
  siteName: string;
  siteLogoUrl: string | null;
}

export const useSiteSettings = () => {
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['site-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', ['site_name', 'site_logo_url']);

      if (error) throw error;

      const settings: SiteSettings = {
        siteName: 'UpTraView', // fallback
        siteLogoUrl: null,
      };

      data?.forEach(setting => {
        if (setting.key === 'site_name' && setting.value) {
          settings.siteName = typeof setting.value === 'string' 
            ? setting.value 
            : String(setting.value);
        }
        if (setting.key === 'site_logo_url' && setting.value) {
          settings.siteLogoUrl = typeof setting.value === 'string'
            ? setting.value
            : String(setting.value);
        }
      });

      return settings;
    },
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  return {
    siteName: data?.siteName || 'UpTraView',
    siteLogoUrl: data?.siteLogoUrl || null,
    loading: isLoading,
    refetch,
  };
};
