import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface SavedPost {
  id: string;
  content: string;
  tickers: string[];
  risk_level: string | null;
  market_type: string | null;
  trade_direction: string | null;
  trade_meta: any;
  image_url: string | null;
  created_at: string;
  saved_at: string;
  author: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
    verified_status: string | null;
    reputation_last30: number;
  };
  scores: {
    useful_count: number;
    not_useful_count: number;
    net_score: number;
  } | null;
}

export const useUserSavedPosts = (userId: string | undefined, isOwnProfile: boolean) => {
  const { user } = useAuth();
  const [savedPosts, setSavedPosts] = useState<SavedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSavedPosts = async () => {
      // Only show saved posts for own profile
      if (!userId || !isOwnProfile || !user || user.id !== userId) {
        setSavedPosts([]);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        
        // Fetch saved post IDs
        const { data: savedData, error: savedError } = await supabase
          .from('saved_posts')
          .select('post_id, created_at')
          .eq('user_id', userId)
          .order('created_at', { ascending: false });

        if (savedError) throw savedError;
        if (!savedData || savedData.length === 0) {
          setSavedPosts([]);
          setLoading(false);
          return;
        }

        const postIds = savedData.map((s: any) => s.post_id);
        const savedAtMap = new Map(savedData.map((s: any) => [s.post_id, s.created_at]));

        // Fetch posts without relationship
        const { data: postsData, error: postsError } = await supabase
          .from('posts')
          .select('*')
          .in('id', postIds);

        if (postsError) throw postsError;

        // Fetch post scores separately
        let scoresMap = new Map();
        if (postIds.length > 0) {
          const { data: scoresData } = await supabase
            .from('post_scores')
            .select('post_id, useful_count, not_useful_count, net_score')
            .in('post_id', postIds);
          scoresMap = new Map((scoresData || []).map((s: any) => [s.post_id, s]));
        }

        // Get unique author IDs and fetch profiles
        const authorIds = [...new Set((postsData || []).map((p: any) => p.author_id))];
        const { data: profilesData } = await supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url, verified_status, reputation_last30')
          .in('id', authorIds);

        const profilesMap = new Map((profilesData || []).map((p: any) => [p.id, p]));

        const formattedPosts = (postsData || []).map((post: any) => {
          const profile = profilesMap.get(post.author_id);
          return {
            id: post.id,
            content: post.content,
            tickers: post.tickers || [],
            risk_level: post.risk_level,
            market_type: post.market_type,
            trade_direction: post.trade_direction,
            trade_meta: post.trade_meta,
            image_url: post.image_url,
            created_at: post.created_at,
            saved_at: savedAtMap.get(post.id) || post.created_at,
            author: profile ? {
              id: profile.id,
              handle: profile.handle,
              display_name: profile.display_name,
              avatar_url: profile.avatar_url,
              verified_status: profile.verified_status,
              reputation_last30: profile.reputation_last30 || 0,
            } : null,
            scores: scoresMap.get(post.id) || null,
          };
        });

        setSavedPosts(formattedPosts);
        setError(null);
      } catch (err) {
        console.error('Error fetching saved posts:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch saved posts');
      } finally {
        setLoading(false);
      }
    };

    fetchSavedPosts();
  }, [userId, isOwnProfile, user]);

  return { savedPosts, loading, error };
};
