import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface PriceAlert {
  id: string;
  user_id: string;
  ticker: string;
  market_type: string;
  condition: 'above' | 'below';
  target_price: number;
  triggered: boolean;
  triggered_at?: string;
  created_at: string;
}

export const usePriceAlerts = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ['price-alerts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('price_alerts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as PriceAlert[];
    },
  });

  const createAlert = useMutation({
    mutationFn: async (alert: {
      ticker: string;
      market_type: string;
      condition: 'above' | 'below';
      target_price: number;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('price_alerts')
        .insert({
          ...alert,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-alerts'] });
      toast({
        title: "Alert created",
        description: "You'll be notified when the price condition is met.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create alert",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteAlert = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-alerts'] });
      toast({
        title: "Alert deleted",
        description: "Price alert has been removed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete alert",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return {
    alerts,
    isLoading,
    createAlert: createAlert.mutate,
    deleteAlert: deleteAlert.mutate,
    isCreating: createAlert.isPending,
    isDeleting: deleteAlert.isPending,
  };
};
