import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Signal {
  id: string;
  content: string;
  trade_direction: string | null;
  market_type: string | null;
  risk_level: string | null;
  entry_price: number | null;
  target_price: number | null;
  stop_loss: number | null;
  timeframe: string | null;
  image_url: string | null;
  created_at: string;
  challenge_id: string;
}

export const useUserSignals = (userId: string | undefined) => {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSignals = async () => {
      if (!userId) {
        setSignals([]);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const { data, error: fetchError } = await supabase
          .from('challenge_signals')
          .select('*')
          .eq('author_id', userId)
          .order('created_at', { ascending: false });

        if (fetchError) throw fetchError;

        setSignals(data || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching user signals:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch signals');
      } finally {
        setLoading(false);
      }
    };

    fetchSignals();
  }, [userId]);

  return { signals, loading, error };
};
