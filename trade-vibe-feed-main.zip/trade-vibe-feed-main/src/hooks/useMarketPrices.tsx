import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type MarketType = 'all' | 'crypto' | 'forex' | 'stocks';

export interface MarketPrice {
  symbol: string;
  name: string;
  current_price: number;
  price_change_24h: number;
  percent_change_24h: number;
  market_type: string;
  last_updated: string;
}

export const useMarketPrices = (marketType: MarketType = 'all') => {
  return useQuery({
    queryKey: ['market-prices', marketType],
    queryFn: async () => {
      console.log('Fetching market prices:', marketType);
      
      // Call edge function to get live prices
      const { data, error } = await supabase.functions.invoke('market-data-api/prices', {
        body: { market: marketType === 'all' ? 'crypto' : marketType }
      });

      if (error) {
        console.error('Error fetching prices:', error);
        throw error;
      }

      return data as MarketPrice[];
    },
    refetchInterval: 60000, // Refetch every 60 seconds to reduce API calls
    staleTime: 55000, // Data is fresh for 55 seconds
  });
};