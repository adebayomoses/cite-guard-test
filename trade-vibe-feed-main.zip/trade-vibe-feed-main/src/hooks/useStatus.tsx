import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface UserXP {
  user_id: string;
  total_xp: number;
  weekly_xp: number;
  current_rank: string;
  current_streak: number;
  longest_streak: number;
  last_activity_date: string | null;
  rank_updated_at: string | null;
}

export interface Achievement {
  id: string;
  key: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  xp_reward: number;
  unlock_condition: Record<string, any>;
  rarity: string;
  sort_order: number;
}

export interface UserAchievement {
  achievement_id: string;
  unlocked_at: string;
  achievement: Achievement;
}

export interface XPTransaction {
  id: string;
  amount: number;
  source_type: string;
  description: string | null;
  created_at: string;
}

export interface TopClimber {
  user_id: string;
  weekly_xp: number;
  total_xp: number;
  current_rank: string;
  profile: {
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
    verified_status: string | null;
  };
}

// Rank thresholds and definitions
export const RANKS = [
  { key: 'rookie', name: 'Rookie', minXP: 0, icon: '🌟', stars: 0, color: 'text-muted-foreground' },
  { key: 'trader', name: 'Trader', minXP: 100, icon: '⭐', stars: 1, color: 'text-yellow-500' },
  { key: 'pro', name: 'Pro', minXP: 500, icon: '⭐⭐', stars: 2, color: 'text-yellow-500' },
  { key: 'elite', name: 'Elite', minXP: 2000, icon: '⭐⭐⭐', stars: 3, color: 'text-yellow-500' },
  { key: 'legend', name: 'Legend', minXP: 5000, icon: '👑', stars: 5, color: 'text-amber-400' },
];

export const getRankByXP = (xp: number) => {
  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (xp >= RANKS[i].minXP) return RANKS[i];
  }
  return RANKS[0];
};

export const getNextRank = (currentRank: string) => {
  const currentIndex = RANKS.findIndex(r => r.key === currentRank);
  if (currentIndex < RANKS.length - 1) {
    return RANKS[currentIndex + 1];
  }
  return null;
};

export const getProgressToNextRank = (xp: number) => {
  const currentRank = getRankByXP(xp);
  const nextRank = getNextRank(currentRank.key);
  
  if (!nextRank) return { progress: 100, xpNeeded: 0, xpToNext: 0 };
  
  const xpInCurrentRank = xp - currentRank.minXP;
  const xpNeededForNext = nextRank.minXP - currentRank.minXP;
  const progress = Math.min((xpInCurrentRank / xpNeededForNext) * 100, 100);
  
  return {
    progress,
    xpNeeded: nextRank.minXP - xp,
    xpToNext: xpNeededForNext,
  };
};

export const useStatus = () => {
  const { user } = useAuth();

  const { data: userXP, isLoading: xpLoading, refetch: refetchXP } = useQuery({
    queryKey: ['user-xp', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('user_xp')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (error) throw error;
      return data as UserXP | null;
    },
    enabled: !!user?.id,
  });

  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ['achievements'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return data as Achievement[];
    },
  });

  const { data: userAchievements, isLoading: userAchievementsLoading } = useQuery({
    queryKey: ['user-achievements', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('user_achievements')
        .select(`
          achievement_id,
          unlocked_at,
          achievement:achievements(*)
        `)
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data as unknown as UserAchievement[];
    },
    enabled: !!user?.id,
  });

  const { data: xpTransactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ['xp-transactions', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('xp_transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      return data as XPTransaction[];
    },
    enabled: !!user?.id,
  });

  const { data: topClimbers, isLoading: climbersLoading } = useQuery({
    queryKey: ['top-climbers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_xp')
        .select(`
          user_id,
          weekly_xp,
          total_xp,
          current_rank,
          profile:profiles!user_xp_user_id_fkey(handle, display_name, avatar_url, verified_status)
        `)
        .order('weekly_xp', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data as unknown as TopClimber[];
    },
  });

  const { data: allTimeLeaders, isLoading: leadersLoading } = useQuery({
    queryKey: ['all-time-leaders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_xp')
        .select(`
          user_id,
          weekly_xp,
          total_xp,
          current_rank,
          profile:profiles!user_xp_user_id_fkey(handle, display_name, avatar_url, verified_status)
        `)
        .order('total_xp', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data as unknown as TopClimber[];
    },
  });

  return {
    userXP,
    achievements,
    userAchievements,
    xpTransactions,
    topClimbers,
    allTimeLeaders,
    loading: xpLoading || achievementsLoading || userAchievementsLoading || transactionsLoading || climbersLoading || leadersLoading,
    refetchXP,
  };
};
