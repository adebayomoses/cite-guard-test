import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Event {
  id: string;
  title: string;
  description: string;
  start_at: string;
  end_at: string;
  location: string;
  url: string;
  tags: string[];
  host: {
    id: string;
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

const SUPABASE_URL = 'https://jyonjxvfjshkjdtjwcqo.supabase.co';

export const useEvents = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(false);
  const { session } = useAuth();
  const { toast } = useToast();

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {};
    if (session?.access_token) {
      headers.Authorization = `Bearer ${session.access_token}`;
    }
    return headers;
  };

  const fetchEvents = async (status: 'upcoming' | 'past' | 'all' = 'all', limit?: number) => {
    setLoading(true);
    try {
      const url = new URL(`${SUPABASE_URL}/functions/v1/events-api/list`);
      if (status !== 'all') {
        url.searchParams.set('status', status);
      }
      if (limit) {
        url.searchParams.set('limit', limit.toString());
      }

      const response = await fetch(url.toString(), {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch events');
      }

      const data = await response.json();
      setEvents(data.events || []);
      return data.events || [];
    } catch (error) {
      console.error('Error fetching events:', error);
      toast({
        title: 'Error',
        description: 'Failed to load events',
        variant: 'destructive',
      });
      return [];
    } finally {
      setLoading(false);
    }
  };

  const fetchEventDetails = async (eventId: string) => {
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/events-api/${eventId}`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch event details');
      }

      const data = await response.json();
      return data.event as Event;
    } catch (error) {
      console.error('Error fetching event details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load event details',
        variant: 'destructive',
      });
      return null;
    }
  };

  const downloadEventICS = async (eventId: string, eventTitle?: string) => {
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/events-api/${eventId}/ics`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to download calendar file');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${eventTitle?.replace(/[^a-zA-Z0-9]/g, '_') || 'event'}.ics`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: 'Calendar file downloaded',
        description: 'Event has been saved to your downloads',
      });
      
      return true;
    } catch (error) {
      console.error('Error downloading ICS:', error);
      toast({
        title: 'Error',
        description: 'Failed to download calendar file',
        variant: 'destructive',
      });
      return false;
    }
  };

  const createEvent = async (eventData: {
    title: string;
    description: string;
    start_at: string;
    end_at?: string;
    location?: string;
    url?: string;
    tags?: string[];
  }) => {
    if (!session) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to create events',
        variant: 'destructive',
      });
      return null;
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/events-api`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(eventData),
      });

      if (!response.ok) {
        throw new Error('Failed to create event');
      }

      const data = await response.json();
      toast({
        title: 'Event created!',
        description: 'Your event has been created successfully',
      });

      return data.event;
    } catch (error) {
      console.error('Error creating event:', error);
      toast({
        title: 'Error',
        description: 'Failed to create event',
        variant: 'destructive',
      });
      return null;
    }
  };

  return {
    events,
    loading,
    fetchEvents,
    fetchEventDetails,
    downloadEventICS,
    createEvent,
  };
};