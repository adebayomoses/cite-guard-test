import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface ChatMessage {
  id: string;
  body: string | null;
  attachment_path: string | null;
  mime_type: string | null;
  created_at: string;
  author_id: string;
  profiles: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
  };
}

export interface ChatConversation {
  id: string;
  otherUser: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
  };
  lastMessage: {
    body: string | null;
    created_at: string;
    author_id: string;
    attachment_path: string | null;
  } | null;
  unreadCount: number;
  updatedAt: string;
  isGroup?: boolean;
  groupInfo?: {
    name: string;
    avatar_url: string | null;
    memberCount: number;
  };
  memberCount?: number;
}

export const useChat = (conversationId?: string) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [typingUsers, setTypingUsers] = useState<Record<string, boolean>>({});

  // Load messages for a conversation
  const loadMessages = useCallback(async (before?: string) => {
    if (!conversationId || !user) return;

    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (before) params.append('before', before);
      params.append('limit', '50');

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/${conversationId}/messages?${params}`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
          }
        }
      );

      if (!response.ok) throw new Error('Failed to load messages');

      const result = await response.json();
      
      if (before) {
        setMessages(prev => [...result.messages, ...prev]);
      } else {
        setMessages(result.messages);
      }
      
      setHasMore(result.messages.length === 50);
    } catch (error) {
      console.error('Error loading messages:', error);
    } finally {
      setLoading(false);
    }
  }, [conversationId, user]);

  // Send message
  const sendMessage = useCallback(async (
    body?: string, 
    attachmentPath?: string, 
    mimeType?: string
  ) => {
    if (!conversationId || !user || (!body && !attachmentPath)) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/${conversationId}/send`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            body,
            attachmentPath,
            mimeType
          })
        }
      );

      if (!response.ok) throw new Error('Failed to send message');

      const result = await response.json();
      return result.message;
    } catch (error) {
      console.error('Error sending message:', error);
      return null;
    }
  }, [conversationId, user]);

  // Mark conversation as read
  const markAsRead = useCallback(async () => {
    if (!conversationId || !user) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/${conversationId}/read`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          }
        }
      );
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  }, [conversationId, user]);

  // Set up real-time subscriptions
  useEffect(() => {
    if (!conversationId || !user) return;

    // Subscribe to new messages
    const messagesChannel = supabase
      .channel('messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`
        },
        async (payload) => {
          // Fetch the complete message with profile data
          const { data: messageData } = await supabase
            .from('messages')
            .select(`
              id,
              body,
              attachment_path,
              mime_type,
              created_at,
              author_id,
              profiles (
                id,
                handle,
                display_name,
                avatar_url
              )
            `)
            .eq('id', payload.new.id)
            .single();

          if (messageData) {
            setMessages(prev => [...prev, messageData as ChatMessage]);
          }
        }
      )
      .subscribe();

    // Subscribe to typing indicators via presence
    const presenceChannel = supabase
      .channel(`chat:${conversationId}`)
      .on('presence', { event: 'sync' }, () => {
        const state = presenceChannel.presenceState();
        const typing: Record<string, boolean> = {};
        
        Object.values(state).forEach((presences: any) => {
          presences.forEach((presence: any) => {
            if (presence.userId !== user.id && presence.typing) {
              typing[presence.userId] = true;
            }
          });
        });
        
        setTypingUsers(typing);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(messagesChannel);
      supabase.removeChannel(presenceChannel);
    };
  }, [conversationId, user]);

  // Broadcast typing indicator
  const setTyping = useCallback((isTyping: boolean) => {
    if (!conversationId || !user) return;

    const channel = supabase.channel(`chat:${conversationId}`);
    
    if (isTyping) {
      channel.track({ userId: user.id, typing: true });
    } else {
      channel.untrack();
    }
  }, [conversationId, user]);

  // Load initial messages
  useEffect(() => {
    if (conversationId && user) {
      loadMessages();
      markAsRead();
    }
  }, [conversationId, user, loadMessages, markAsRead]);

  return {
    messages,
    loading,
    hasMore,
    typingUsers,
    loadMessages,
    sendMessage,
    markAsRead,
    setTyping
  };
};