import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface Achievement {
  id: string;
  key: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  xp_reward: number;
  rarity: string;
}

export interface UserAchievement {
  achievement_id: string;
  unlocked_at: string;
  achievement: Achievement;
}

export const useProfileAchievements = (userId: string | undefined) => {
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ['achievements'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return data as Achievement[];
    },
  });

  const { data: userAchievements, isLoading: userAchievementsLoading } = useQuery({
    queryKey: ['user-achievements', userId],
    queryFn: async () => {
      if (!userId) return [];
      
      const { data, error } = await supabase
        .from('user_achievements')
        .select(`
          achievement_id,
          unlocked_at,
          achievement:achievements(*)
        `)
        .eq('user_id', userId);
      
      if (error) throw error;
      return data as unknown as UserAchievement[];
    },
    enabled: !!userId,
  });

  const unlockedCount = userAchievements?.length || 0;
  const totalCount = achievements?.length || 0;

  return {
    achievements,
    userAchievements,
    unlockedCount,
    totalCount,
    loading: achievementsLoading || userAchievementsLoading,
  };
};
