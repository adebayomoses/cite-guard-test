import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail_url?: string;
  caption?: string;
  created_at: string;
  source: 'post' | 'lifestyle';
}

export const useUserMedia = (userId: string | undefined, isOwnProfile: boolean) => {
  const { user } = useAuth();
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMedia = async () => {
      if (!userId) {
        setMedia([]);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const mediaItems: MediaItem[] = [];

        // Fetch images from posts
        const { data: posts, error: postsError } = await supabase
          .from('posts')
          .select('id, image_url, content, created_at')
          .eq('author_id', userId)
          .not('image_url', 'is', null)
          .order('created_at', { ascending: false });

        if (postsError) throw postsError;

        (posts || []).forEach((post: any) => {
          if (post.image_url) {
            mediaItems.push({
              id: post.id,
              type: 'image',
              url: post.image_url,
              caption: post.content?.substring(0, 100),
              created_at: post.created_at,
              source: 'post',
            });
          }
        });

        // Fetch videos from lifestyle_videos (respect visibility)
        const videoQuery = supabase
          .from('lifestyle_videos')
          .select('id, video_url, thumbnail_url, caption, created_at, visibility')
          .eq('author_id', userId)
          .order('created_at', { ascending: false });

        // If not own profile, only show public videos
        if (!isOwnProfile) {
          videoQuery.eq('visibility', 'public');
        }

        const { data: videos, error: videosError } = await videoQuery;

        if (videosError) throw videosError;

        (videos || []).forEach((video: any) => {
          mediaItems.push({
            id: video.id,
            type: 'video',
            url: video.video_url,
            thumbnail_url: video.thumbnail_url,
            caption: video.caption,
            created_at: video.created_at,
            source: 'lifestyle',
          });
        });

        // Sort by created_at descending
        mediaItems.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

        setMedia(mediaItems);
        setError(null);
      } catch (err) {
        console.error('Error fetching media:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch media');
      } finally {
        setLoading(false);
      }
    };

    fetchMedia();
  }, [userId, isOwnProfile, user]);

  return { media, loading, error };
};
