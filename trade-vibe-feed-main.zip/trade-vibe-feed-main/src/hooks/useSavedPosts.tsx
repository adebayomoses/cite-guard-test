import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import type { SaveResponse } from '@/types';

export const useSavedPosts = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const toggleSavePost = useCallback(async (postId: string): Promise<SaveResponse | null> => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You must be signed in to save posts.',
        variant: 'destructive',
      });
      return null;
    }

    setLoading(true);
    try {
      // Check if post is already saved
      const { data: existingSave } = await supabase
        .from('saved_posts')
        .select('*')
        .eq('user_id', user.id)
        .eq('post_id', postId)
        .maybeSingle();

      if (existingSave) {
        // Remove from saved posts
        const { error } = await supabase
          .from('saved_posts')
          .delete()
          .eq('user_id', user.id)
          .eq('post_id', postId);

        if (error) throw error;

        toast({
          title: 'Removed from journal',
          description: 'Post removed from your saved journal.',
        });

        return { saved: false };
      } else {
        // Add to saved posts
        const { error } = await supabase
          .from('saved_posts')
          .insert({ user_id: user.id, post_id: postId });

        if (error) throw error;

        toast({
          title: 'Saved to journal',
          description: 'Post saved to your journal.',
        });

        return { saved: true };
      }

    } catch (error) {
      console.error('Error saving post:', error);
      toast({
        title: 'Error saving post',
        description: 'Failed to save post. Please try again.',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  const getSavedPosts = useCallback(async () => {
    if (!user) return [];

    try {
      const { data, error } = await supabase
        .from('saved_posts')
        .select('post_id, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];

    } catch (error) {
      console.error('Error fetching saved posts:', error);
      return [];
    }
  }, [user]);

  return {
    toggleSavePost,
    getSavedPosts,
    loading,
  };
};