import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface ChatRequest {
  id: string;
  from_user_id: string;
  to_user_id: string;
  intro_message: string | null;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  created_at: string;
  updated_at: string;
  expires_at: string;
  profiles: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
    verified_status: string | null;
  };
}

export const useChatRequests = () => {
  const { user } = useAuth();
  const [incomingRequests, setIncomingRequests] = useState<ChatRequest[]>([]);
  const [outgoingRequests, setOutgoingRequests] = useState<ChatRequest[]>([]);
  const [loading, setLoading] = useState(false);

  // Send chat request
  const sendChatRequest = useCallback(async (
    userId: string, 
    introMessage?: string
  ) => {
    if (!user) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/request`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userId,
            introMessage
          })
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send request');
      }

      const result = await response.json();
      return result.request;
    } catch (error) {
      console.error('Error sending chat request:', error);
      throw error;
    }
  }, [user]);

  // Load incoming requests
  const loadIncomingRequests = useCallback(async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/requests/incoming`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
          }
        }
      );

      if (!response.ok) throw new Error('Failed to load incoming requests');

      const result = await response.json();
      setIncomingRequests(result.requests);
    } catch (error) {
      console.error('Error loading incoming requests:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Load outgoing requests
  const loadOutgoingRequests = useCallback(async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/requests/outgoing`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
          }
        }
      );

      if (!response.ok) throw new Error('Failed to load outgoing requests');

      const result = await response.json();
      setOutgoingRequests(result.requests);
    } catch (error) {
      console.error('Error loading outgoing requests:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Accept chat request
  const acceptRequest = useCallback(async (requestId: string) => {
    if (!user) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/requests/${requestId}/accept`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          }
        }
      );

      if (!response.ok) throw new Error('Failed to accept request');

      const result = await response.json();
      
      // Reload requests to update UI
      loadIncomingRequests();
      
      return result.conversationId;
    } catch (error) {
      console.error('Error accepting request:', error);
      throw error;
    }
  }, [user, loadIncomingRequests]);

  // Decline chat request
  const declineRequest = useCallback(async (requestId: string) => {
    if (!user) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/requests/${requestId}/decline`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          }
        }
      );

      if (!response.ok) throw new Error('Failed to decline request');

      // Reload requests to update UI
      loadIncomingRequests();
      
      return true;
    } catch (error) {
      console.error('Error declining request:', error);
      throw error;
    }
  }, [user, loadIncomingRequests]);

  // Set up real-time subscriptions for chat requests
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('chat_requests')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'chat_requests',
          filter: `to_user_id=eq.${user.id}`
        },
        () => {
          // Reload incoming requests when there are changes
          loadIncomingRequests();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, loadIncomingRequests]);

  // Initial load
  useEffect(() => {
    if (user) {
      loadIncomingRequests();
      loadOutgoingRequests();
    }
  }, [user, loadIncomingRequests, loadOutgoingRequests]);

  // Get pending requests count
  const pendingCount = incomingRequests.filter(req => req.status === 'pending').length;

  return {
    incomingRequests,
    outgoingRequests,
    loading,
    sendChatRequest,
    acceptRequest,
    declineRequest,
    loadIncomingRequests,
    loadOutgoingRequests,
    pendingCount
  };
};