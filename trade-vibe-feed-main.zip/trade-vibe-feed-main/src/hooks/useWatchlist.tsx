import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const useWatchlist = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: watchlist = [], isLoading } = useQuery({
    queryKey: ['watchlist'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from('profiles')
        .select('watchlist')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      return (data?.watchlist || []) as string[];
    },
  });

  const addToWatchlist = useMutation({
    mutationFn: async (ticker: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const currentWatchlist = watchlist || [];
      if (currentWatchlist.includes(ticker)) {
        throw new Error('Already in watchlist');
      }

      const { error } = await supabase
        .from('profiles')
        .update({ watchlist: [...currentWatchlist, ticker] })
        .eq('id', user.id);

      if (error) throw error;
      return ticker;
    },
    onSuccess: (ticker) => {
      queryClient.invalidateQueries({ queryKey: ['watchlist'] });
      toast({
        title: "Added to watchlist",
        description: `${ticker} has been added to your watchlist.`,
      });
    },
    onError: (error: any) => {
      if (error.message !== 'Already in watchlist') {
        toast({
          title: "Failed to add to watchlist",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  const removeFromWatchlist = useMutation({
    mutationFn: async (ticker: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const currentWatchlist = watchlist || [];
      const { error } = await supabase
        .from('profiles')
        .update({ watchlist: currentWatchlist.filter(t => t !== ticker) })
        .eq('id', user.id);

      if (error) throw error;
      return ticker;
    },
    onSuccess: (ticker) => {
      queryClient.invalidateQueries({ queryKey: ['watchlist'] });
      toast({
        title: "Removed from watchlist",
        description: `${ticker} has been removed from your watchlist.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to remove from watchlist",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const isInWatchlist = (ticker: string) => {
    return watchlist.includes(ticker);
  };

  return {
    watchlist,
    isLoading,
    addToWatchlist: addToWatchlist.mutate,
    removeFromWatchlist: removeFromWatchlist.mutate,
    isInWatchlist,
    isAdding: addToWatchlist.isPending,
    isRemoving: removeFromWatchlist.isPending,
  };
};
