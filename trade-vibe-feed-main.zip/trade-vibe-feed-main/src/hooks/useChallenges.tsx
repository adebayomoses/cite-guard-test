import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Challenge {
  id: string;
  title: string;
  description: string;
  scope: string;
  metric: string;
  start_at: string;
  end_at: string;
  status: string;
  entry_count: number;
  isParticipating: boolean;
  risk_management?: string;
  created_by: string;
  created_by_profile: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

interface ChallengeDetails extends Challenge {
  userRank?: number;
}

interface LeaderboardEntry {
  user_id: string;
  rank: number;
  score: number;
  handle: string;
  display_name: string;
  avatar_url: string;
  verified_status: string;
}

interface ChallengeSignal {
  id: string;
  challenge_id: string;
  author_id: string;
  content: string;
  image_url?: string;
  market_type: string;
  trade_direction: string;
  risk_level: string;
  timeframe?: string;
  entry_price?: number;
  stop_loss?: number;
  target_price?: number;
  created_at: string;
  profiles: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

interface ChallengeDiscussion {
  id: string;
  challenge_id: string;
  author_id: string;
  content: string;
  created_at: string;
  profiles: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

const SUPABASE_URL = 'https://jyonjxvfjshkjdtjwcqo.supabase.co';

export const useChallenges = () => {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(false);
  const { session } = useAuth();
  const { toast } = useToast();

  const getAuthHeaders = () => {
    const headers: Record<string, string> = {};
    if (session?.access_token) {
      headers.Authorization = `Bearer ${session.access_token}`;
    }
    return headers;
  };

  const fetchChallenges = async (status?: string) => {
    setLoading(true);
    try {
      const url = new URL(`${SUPABASE_URL}/functions/v1/challenges-api/list`);
      if (status && status !== 'all') {
        url.searchParams.set('status', status);
      }

      const response = await fetch(url.toString(), {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch challenges');
      }

      const data = await response.json();
      setChallenges(data.challenges || []);
    } catch (error) {
      console.error('Error fetching challenges:', error);
      toast({
        title: 'Error',
        description: 'Failed to load challenges',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchChallengeDetails = async (challengeId: string) => {
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch challenge details');
      }

      const data = await response.json();
      return {
        challenge: data.challenge as ChallengeDetails,
        leaderboard: data.leaderboard as LeaderboardEntry[],
      };
    } catch (error) {
      console.error('Error fetching challenge details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load challenge details',
        variant: 'destructive',
      });
      return null;
    }
  };

  const joinChallenge = async (challengeId: string) => {
    if (!session) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to join challenges',
        variant: 'destructive',
      });
      return false;
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}/join`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to join challenge');
      }

      const data = await response.json();
      toast({
        title: data.joined ? 'Joined challenge!' : 'Left challenge',
        description: data.joined 
          ? "You're now participating in this challenge" 
          : "You've left this challenge",
      });

      return data.joined;
    } catch (error) {
      console.error('Error joining challenge:', error);
      toast({
        title: 'Error',
        description: 'Failed to join challenge',
        variant: 'destructive',
      });
      return false;
    }
  };

  const fetchChallengeSignals = async (challengeId: string) => {
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}/signals`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch signals');
      }

      const data = await response.json();
      // Handle both array and object shapes from the edge function
      const signals = Array.isArray(data) ? data : (data.signals || []);
      return signals as ChallengeSignal[];
    } catch (error) {
      console.error('Error fetching signals:', error);
      toast({
        title: 'Error',
        description: 'Failed to load signals',
        variant: 'destructive',
      });
      return [];
    }
  };

  const fetchChallengeDiscussions = async (challengeId: string) => {
    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}/discussions`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch discussions');
      }

      const data = await response.json();
      const discussions = Array.isArray(data) ? data : (data.discussions || []);
      return discussions as ChallengeDiscussion[];
    } catch (error) {
      console.error('Error fetching discussions:', error);
      toast({
        title: 'Error',
        description: 'Failed to load discussions',
        variant: 'destructive',
      });
      return [];
    }
  };

  const createSignal = async (challengeId: string, signalData: any) => {
    if (!session) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to post signals',
        variant: 'destructive',
      });
      return null;
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}/signals`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(signalData),
      });

      if (!response.ok) {
        throw new Error('Failed to create signal');
      }

      const data = await response.json();
      toast({
        title: 'Signal posted!',
        description: 'Your signal has been posted successfully',
      });

      const signal = (data && 'signal' in data) ? data.signal : data;
      return signal;
    } catch (error) {
      console.error('Error creating signal:', error);
      toast({
        title: 'Error',
        description: 'Failed to post signal',
        variant: 'destructive',
      });
      return null;
    }
  };

  const createDiscussion = async (challengeId: string, content: string) => {
    if (!session) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to post discussions',
        variant: 'destructive',
      });
      return null;
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api/${challengeId}/discussions`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      });

      if (!response.ok) {
        throw new Error('Failed to create discussion');
      }

      const data = await response.json();
      toast({
        title: 'Discussion posted!',
        description: 'Your discussion has been posted successfully',
      });

      const discussion = (data && 'discussion' in data) ? data.discussion : data;
      return discussion;
    } catch (error) {
      console.error('Error creating discussion:', error);
      toast({
        title: 'Error',
        description: 'Failed to post discussion',
        variant: 'destructive',
      });
      return null;
    }
  };

  const createChallenge = async (challengeData: {
    title: string;
    description: string;
    scope: string;
    metric: string;
    start_at: string;
    end_at: string;
    risk_management?: string;
  }) => {
    if (!session) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to create challenges',
        variant: 'destructive',
      });
      return null;
    }

    try {
      const response = await fetch(`${SUPABASE_URL}/functions/v1/challenges-api`, {
        method: 'POST',
        headers: {
          ...getAuthHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(challengeData),
      });

      if (!response.ok) {
        throw new Error('Failed to create challenge');
      }

      const data = await response.json();
      toast({
        title: 'Challenge created!',
        description: 'Your challenge has been created successfully',
      });

      return data.challenge;
    } catch (error) {
      console.error('Error creating challenge:', error);
      toast({
        title: 'Error',
        description: 'Failed to create challenge',
        variant: 'destructive',
      });
      return null;
    }
  };

  return {
    challenges,
    loading,
    fetchChallenges,
    fetchChallengeDetails,
    fetchChallengeSignals,
    fetchChallengeDiscussions,
    joinChallenge,
    createChallenge,
    createSignal,
    createDiscussion,
  };
};
