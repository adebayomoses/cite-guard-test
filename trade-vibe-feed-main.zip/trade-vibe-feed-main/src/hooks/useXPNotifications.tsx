import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { getRankByXP, RANKS } from '@/hooks/useStatus';

interface XPTransaction {
  id: string;
  user_id: string;
  amount: number;
  source_type: string;
  description: string | null;
  created_at: string;
}

const SOURCE_LABELS: Record<string, string> = {
  // Content
  post_created: 'creating a post',
  comment_created: 'posting a comment',
  lifestyle_video_posted: 'posting a lifestyle video',
  
  // Voting
  vote_useful: 'receiving a useful vote',
  vote_not_useful: 'receiving a downvote',
  useful_vote: 'receiving a useful vote',
  not_useful_vote: 'receiving a downvote',
  vote_changed: 'vote change',
  vote_removed: 'vote removed',
  
  // Signals
  signal_won: 'winning a signal',
  signal_lost: 'losing a signal',
  
  // Challenges
  challenge_created: 'creating a challenge',
  challenge_joined: 'joining a challenge',
  challenge_won: 'winning a challenge',
  challenge_top3: 'placing in top 3',
  
  // Events
  event_created: 'creating an event',
  
  // Mentorship
  mentorship_channel_created: 'creating a mentorship channel',
  mentorship_subscriber_gained: 'gaining a subscriber',
  mentorship_session_completed: 'completing a mentorship session',
  
  // Achievements & Other
  achievement_unlocked: 'unlocking an achievement',
  historical_backfill: 'historical activity',
};

const getSourceLabel = (sourceType: string): string => {
  return SOURCE_LABELS[sourceType] || sourceType.replace(/_/g, ' ');
};

export const useXPNotifications = (onRankUp?: (newRank: string, oldRank: string) => void) => {
  const { user } = useAuth();
  const previousXPRef = useRef<number | null>(null);
  const previousRankRef = useRef<string | null>(null);

  const handleXPChange = useCallback((newXP: number, oldXP: number | null) => {
    if (oldXP === null) {
      previousXPRef.current = newXP;
      previousRankRef.current = getRankByXP(newXP).key;
      return;
    }

    const oldRank = getRankByXP(oldXP);
    const newRank = getRankByXP(newXP);

    // Check for rank up
    if (newRank.key !== oldRank.key && RANKS.findIndex(r => r.key === newRank.key) > RANKS.findIndex(r => r.key === oldRank.key)) {
      onRankUp?.(newRank.key, oldRank.key);
    }

    previousXPRef.current = newXP;
    previousRankRef.current = newRank.key;
  }, [onRankUp]);

  useEffect(() => {
    if (!user?.id) return;

    // Subscribe to new XP transactions
    const channel = supabase
      .channel(`xp-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'xp_transactions',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const transaction = payload.new as XPTransaction;
          const isPositive = transaction.amount > 0;
          const sourceLabel = getSourceLabel(transaction.source_type);
          
          toast({
            title: isPositive ? `+${transaction.amount} XP` : `${transaction.amount} XP`,
            description: `${isPositive ? 'Earned' : 'Lost'} for ${sourceLabel}`,
            variant: isPositive ? 'default' : 'destructive',
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'user_xp',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newData = payload.new as { total_xp: number };
          handleXPChange(newData.total_xp, previousXPRef.current);
        }
      )
      .subscribe();

    // Initialize previous XP value
    const initializePreviousXP = async () => {
      const { data } = await supabase
        .from('user_xp')
        .select('total_xp')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (data) {
        previousXPRef.current = data.total_xp;
        previousRankRef.current = getRankByXP(data.total_xp).key;
      }
    };

    initializePreviousXP();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, handleXPChange]);
};
