import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface MentorshipChannel {
  id: string;
  conversation_id: string;
  name: string;
  description?: string;
  avatar_url?: string;
  mentorship_type: 'free' | 'paid';
  mentorship_price?: number;
  mentorship_billing_cycle: string;
  max_mentees?: number;
  current_mentees: number;
  memberCount: number;
  isFull: boolean;
  isUserMember: boolean;
  created_at: string;
  mentor: {
    id: string;
    handle: string;
    display_name?: string;
    avatar_url?: string;
    verified_status: string;
    reputation_last30: number;
    markets?: string[];
  };
}

export const useMentorshipChannels = (type: 'free' | 'paid') => {
  return useQuery({
    queryKey: ['mentorship-channels', type],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke(
        `chat-api/mentorship/list?type=${type}`
      );

      if (error) throw error;
      return data?.channels as MentorshipChannel[];
    },
  });
};
