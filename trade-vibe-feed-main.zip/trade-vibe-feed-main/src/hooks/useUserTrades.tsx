import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface Trade {
  id: string;
  user_id: string;
  ticker: string;
  market_type: string;
  direction: string;
  entry_price: number;
  exit_price: number | null;
  quantity: number;
  entry_date: string;
  exit_date: string | null;
  pnl_amount: number | null;
  pnl_percent: number | null;
  notes: string | null;
  image_url: string | null;
  is_public: boolean;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface TradeInput {
  ticker: string;
  market_type?: string;
  direction?: string;
  entry_price: number;
  exit_price?: number | null;
  quantity: number;
  entry_date: string;
  exit_date?: string | null;
  pnl_amount?: number | null;
  pnl_percent?: number | null;
  notes?: string | null;
  image_url?: string | null;
  is_public?: boolean;
  status?: string;
}

export const useUserTrades = (userId: string | undefined, isOwnProfile: boolean) => {
  const { user } = useAuth();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTrades = useCallback(async () => {
    if (!userId) {
      setTrades([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // If own profile, show all trades; otherwise show only public
      const query = supabase
        .from('trades')
        .select('*')
        .eq('user_id', userId)
        .order('entry_date', { ascending: false });

      if (!isOwnProfile) {
        query.eq('is_public', true);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      setTrades(data || []);
      setError(null);
    } catch (err) {
      console.error('Error fetching trades:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch trades');
    } finally {
      setLoading(false);
    }
  }, [userId, isOwnProfile]);

  useEffect(() => {
    fetchTrades();
  }, [fetchTrades]);

  const createTrade = async (input: TradeInput) => {
    if (!user) {
      toast.error('You must be logged in to create a trade');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('trades')
        .insert({
          ...input,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      setTrades(prev => [data, ...prev]);
      toast.success('Trade created successfully');
      return data;
    } catch (err) {
      console.error('Error creating trade:', err);
      toast.error('Failed to create trade');
      return null;
    }
  };

  const updateTrade = async (id: string, input: Partial<TradeInput>) => {
    if (!user) {
      toast.error('You must be logged in to update a trade');
      return null;
    }

    try {
      const { data, error } = await supabase
        .from('trades')
        .update(input)
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      setTrades(prev => prev.map(t => t.id === id ? data : t));
      toast.success('Trade updated successfully');
      return data;
    } catch (err) {
      console.error('Error updating trade:', err);
      toast.error('Failed to update trade');
      return null;
    }
  };

  const deleteTrade = async (id: string) => {
    if (!user) {
      toast.error('You must be logged in to delete a trade');
      return false;
    }

    try {
      const { error } = await supabase
        .from('trades')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      setTrades(prev => prev.filter(t => t.id !== id));
      toast.success('Trade deleted successfully');
      return true;
    } catch (err) {
      console.error('Error deleting trade:', err);
      toast.error('Failed to delete trade');
      return false;
    }
  };

  return { trades, loading, error, createTrade, updateTrade, deleteTrade, refetch: fetchTrades };
};
