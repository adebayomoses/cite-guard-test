import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { getRankByXP } from '@/hooks/useStatus';

export const useUserRank = (userId: string | undefined) => {
  const { data, isLoading } = useQuery({
    queryKey: ['user-rank', userId],
    queryFn: async () => {
      if (!userId) return null;
      
      const { data, error } = await supabase
        .from('user_xp')
        .select('total_xp, current_rank, weekly_xp')
        .eq('user_id', userId)
        .maybeSingle();
      
      if (error) throw error;
      
      if (!data) {
        return { rank: getRankByXP(0), xp: 0, weeklyXp: 0 };
      }
      
      return {
        rank: getRankByXP(data.total_xp || 0),
        xp: data.total_xp || 0,
        weeklyXp: data.weekly_xp || 0,
      };
    },
    enabled: !!userId,
    staleTime: 60000,
  });

  return {
    rank: data?.rank,
    xp: data?.xp || 0,
    weeklyXp: data?.weeklyXp || 0,
    loading: isLoading,
  };
};
