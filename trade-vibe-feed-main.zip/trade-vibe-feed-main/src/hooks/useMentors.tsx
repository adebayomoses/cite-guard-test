import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Mentor {
  id: string;
  handle: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  verified_status: string;
  reputation_last30: number;
  markets: string[] | null;
  is_mentor: boolean;
  mentor_type: 'free' | 'paid' | 'both' | null;
  mentor_price: number | null;
  mentor_bio: string | null;
  mentor_available: boolean;
}

type MentorType = 'free' | 'paid';

export const useMentors = (type: MentorType) => {
  return useQuery({
    queryKey: ['mentors', type],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('is_mentor', true)
        .eq('mentor_available', true)
        .in('mentor_type', type === 'free' ? ['free', 'both'] : ['paid', 'both'])
        .order('reputation_last30', { ascending: false });

      if (error) throw error;
      return data as Mentor[];
    },
  });
};
