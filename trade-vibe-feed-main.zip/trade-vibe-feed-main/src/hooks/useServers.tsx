import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Server {
  id: string;
  groupInfo: {
    name: string;
    description?: string;
    avatar_url?: string;
  };
  memberCount: number;
  channelCount?: number;
  unreadCount: number;
  updatedAt: string;
}

export interface ServerDetails extends Server {
  channels: {
    id: string;
    name: string;
    description?: string;
    order: number;
    isDefault: boolean;
  }[];
  userRole?: 'admin' | 'member';
}

export const useServers = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const loadServers = async (): Promise<Server[]> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error } = await supabase.functions.invoke('chat-api/servers');
      
      if (error) throw error;
      return data?.servers || [];
    } catch (error) {
      console.error('Error loading servers:', error);
      toast({
        title: 'Error',
        description: 'Failed to load servers',
        variant: 'destructive',
      });
      return [];
    }
  };

  const getServerDetails = async (serverId: string): Promise<ServerDetails | null> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error } = await supabase.functions.invoke(`chat-api/server/${serverId}`);
      
      if (error) throw error;
      return data?.server || null;
    } catch (error) {
      console.error('Error loading server details:', error);
      toast({
        title: 'Error',
        description: 'Failed to load server details',
        variant: 'destructive',
      });
      return null;
    }
  };

  const createServer = async (
    name: string,
    description: string,
    avatarUrl?: string,
    defaultChannels: string[] = ['general', 'announcements']
  ): Promise<string | null> => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error } = await supabase.functions.invoke('chat-api/server/create', {
        body: { name, description, avatarUrl, defaultChannels },
      });
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Server created successfully',
      });
      
      return data?.serverId || null;
    } catch (error) {
      console.error('Error creating server:', error);
      toast({
        title: 'Error',
        description: 'Failed to create server',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    loadServers,
    getServerDetails,
    createServer,
  };
};
