import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Channel {
  id: string;
  name: string;
  description?: string;
  order: number;
  isDefault: boolean;
}

export const useServerChannels = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const loadChannels = async (serverId: string): Promise<Channel[]> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error } = await supabase.functions.invoke(`chat-api/server/${serverId}/channels`);
      
      if (error) throw error;
      return data?.channels || [];
    } catch (error) {
      console.error('Error loading channels:', error);
      toast({
        title: 'Error',
        description: 'Failed to load channels',
        variant: 'destructive',
      });
      return [];
    }
  };

  const createChannel = async (
    serverId: string,
    name: string,
    description?: string
  ): Promise<string | null> => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error } = await supabase.functions.invoke(`chat-api/server/${serverId}/channels`, {
        method: 'POST',
        body: { name, description },
      });
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Channel created successfully',
      });
      
      return data?.channelId || null;
    } catch (error) {
      console.error('Error creating channel:', error);
      toast({
        title: 'Error',
        description: 'Failed to create channel',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateChannel = async (
    serverId: string,
    channelId: string,
    updates: { name?: string; description?: string; order?: number }
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { error } = await supabase.functions.invoke(`chat-api/server/${serverId}/channels/${channelId}`, {
        method: 'PUT',
        body: updates,
      });
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Channel updated successfully',
      });
      
      return true;
    } catch (error) {
      console.error('Error updating channel:', error);
      toast({
        title: 'Error',
        description: 'Failed to update channel',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const deleteChannel = async (serverId: string, channelId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { error } = await supabase.functions.invoke(`chat-api/server/${serverId}/channels/${channelId}`, {
        method: 'DELETE',
      });
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Channel deleted successfully',
      });
      
      return true;
    } catch (error) {
      console.error('Error deleting channel:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete channel',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    loadChannels,
    createChannel,
    updateChannel,
    deleteChannel,
  };
};
