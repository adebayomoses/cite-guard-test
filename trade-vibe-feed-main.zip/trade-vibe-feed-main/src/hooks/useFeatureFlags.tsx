import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useFeatureFlags = () => {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['feature_flags'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('feature_flags')
        .select('key, enabled');
      
      if (error) throw error;
      
      // Convert array to object for easier access
      return (data || []).reduce((acc, flag) => ({
        ...acc,
        [flag.key]: flag.enabled
      }), {} as Record<string, boolean>);
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  return {
    flags: data || {},
    loading: isLoading,
    error,
    refetch
  };
};
