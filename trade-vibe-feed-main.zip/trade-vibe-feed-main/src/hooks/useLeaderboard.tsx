import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface LeaderboardEntry {
  id: string;
  rank: number;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  reputation: number;
  totalVotes: number;
  verified: boolean;
  badges: string[];
}

export function useLeaderboard(limit: number = 50) {
  return useQuery({
    queryKey: ["leaderboard", limit],
    queryFn: async (): Promise<LeaderboardEntry[]> => {
      // Fetch profiles with reputation > 0
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, handle, display_name, avatar_url, reputation_last30, verified_status, strategy_tags")
        .gt("reputation_last30", 0)
        .order("reputation_last30", { ascending: false })
        .limit(limit);

      if (profilesError) throw profilesError;
      if (!profiles || profiles.length === 0) return [];

      // Get posts for these users
      const userIds = profiles.map(p => p.id);
      
      const { data: posts, error: postsError } = await supabase
        .from("posts")
        .select("id, author_id")
        .in("author_id", userIds);

      if (postsError) throw postsError;

      // Get vote counts for those posts
      const votesByUser: Record<string, number> = {};
      
      if (posts && posts.length > 0) {
        const postIds = posts.map(p => p.id);
        
        const { data: scores, error: scoresError } = await supabase
          .from("post_scores")
          .select("post_id, useful_count, not_useful_count")
          .in("post_id", postIds);

        if (scoresError) throw scoresError;

        // Create post -> author mapping
        const postAuthorMap: Record<string, string> = {};
        posts.forEach(p => { postAuthorMap[p.id] = p.author_id; });

        // Aggregate votes per user
        scores?.forEach(score => {
          const authorId = postAuthorMap[score.post_id];
          if (authorId) {
            votesByUser[authorId] = (votesByUser[authorId] || 0) + 
              (score.useful_count || 0) + (score.not_useful_count || 0);
          }
        });
      }

      // Map to leaderboard entries with rank
      return profiles.map((profile, index) => ({
        id: profile.id,
        rank: index + 1,
        handle: profile.handle,
        displayName: profile.display_name,
        avatarUrl: profile.avatar_url,
        reputation: Math.round(profile.reputation_last30 || 0),
        totalVotes: votesByUser[profile.id] || 0,
        verified: profile.verified_status === "manual",
        badges: (profile.strategy_tags as string[]) || [],
      }));
    },
    staleTime: 60000, // 1 minute
  });
}
