import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

export interface GroupMember {
  user_id: string;
  role: 'admin' | 'member';
  joined_at: string;
  profiles: {
    id: string;
    handle: string;
    display_name: string;
    avatar_url?: string;
    verified_status?: string;
  };
}

export interface GroupInfo {
  id: string;
  conversation_id: string;
  name: string;
  description?: string;
  avatar_url?: string;
  created_by: string;
  allow_member_messages: boolean;
  allow_member_add: boolean;
  max_members: number;
  memberCount?: number;
  created_at: string;
  updated_at: string;
  isServerChannel?: boolean;
}

export const useGroupChat = () => {
  const [loading, setLoading] = useState(false);

  const createGroup = async (
    name: string,
    description: string,
    memberIds: string[],
    settings?: {
      allowMemberMessages?: boolean;
      allowMemberAdd?: boolean;
      maxMembers?: number;
    }
  ): Promise<string | null> => {
    setLoading(true);
    try {
      const response = await fetch(
        'https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/create',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ name, description, memberIds, settings }),
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Group created successfully' });
      return data.conversationId;
    } catch (error) {
      console.error('Error creating group:', error);
      toast({ title: 'Error', description: 'Failed to create group', variant: 'destructive' });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getGroupInfo = async (conversationId: string): Promise<GroupInfo | null> => {
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/info`,
        {
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      return data;
    } catch (error) {
      console.error('Error fetching group info:', error);
      return null;
    }
  };

  const updateGroup = async (
    conversationId: string,
    updates: {
      name?: string;
      description?: string;
      avatarUrl?: string;
      settings?: {
        allowMemberMessages?: boolean;
        allowMemberAdd?: boolean;
        maxMembers?: number;
      };
    }
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/update`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updates),
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Group updated successfully' });
      return true;
    } catch (error) {
      console.error('Error updating group:', error);
      toast({ title: 'Error', description: 'Failed to update group', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const getGroupMembers = async (conversationId: string): Promise<GroupMember[]> => {
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/members`,
        {
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      return data.members || [];
    } catch (error) {
      console.error('Error fetching members:', error);
      return [];
    }
  };

  const addMembers = async (conversationId: string, userIds: string[]): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/members/add`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userIds }),
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Members added successfully' });
      return true;
    } catch (error) {
      console.error('Error adding members:', error);
      toast({ title: 'Error', description: 'Failed to add members', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const removeMember = async (conversationId: string, userId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/members/${userId}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Member removed successfully' });
      return true;
    } catch (error) {
      console.error('Error removing member:', error);
      toast({ title: 'Error', description: 'Failed to remove member', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const promoteMember = async (conversationId: string, userId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/members/${userId}/promote`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Member promoted to admin' });
      return true;
    } catch (error) {
      console.error('Error promoting member:', error);
      toast({ title: 'Error', description: 'Failed to promote member', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const demoteMember = async (conversationId: string, userId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}/members/${userId}/demote`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Member demoted to regular member' });
      return true;
    } catch (error) {
      console.error('Error demoting member:', error);
      toast({ title: 'Error', description: 'Failed to demote member', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const leaveGroup = async (conversationId: string, userId: string): Promise<boolean> => {
    return await removeMember(conversationId, userId);
  };

  const deleteGroup = async (conversationId: string): Promise<boolean> => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/group/${conversationId}`,
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
          },
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || `HTTP error ${response.status}`);
      }

      const data = await response.json();
      if (data.error) throw new Error(data.error);

      toast({ title: 'Success', description: 'Group deleted successfully' });
      return true;
    } catch (error) {
      console.error('Error deleting group:', error);
      toast({ title: 'Error', description: 'Failed to delete group', variant: 'destructive' });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    createGroup,
    getGroupInfo,
    updateGroup,
    getGroupMembers,
    addMembers,
    removeMember,
    promoteMember,
    demoteMember,
    leaveGroup,
    deleteGroup,
  };
};
