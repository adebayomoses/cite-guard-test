import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import type { Comment } from '@/types';

export const useComments = (postId: string) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fetchComments = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('comments')
        .select(`
          id,
          post_id,
          author_id,
          text,
          created_at,
          updated_at
        `)
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Get unique author IDs to fetch profiles separately
      const authorIds = [...new Set(data.map(c => c.author_id))];
      
      // Fetch author profiles
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, handle, avatar_url, verified_status')
        .in('id', authorIds);

      const profilesMap = new Map(profiles?.map(p => [p.id, p]) || []);

      const formattedComments: Comment[] = data.map(comment => {
        const profile = profilesMap.get(comment.author_id);
        return {
          id: comment.id,
          post_id: comment.post_id,
          author_id: comment.author_id,
          author: profile ? {
            username: profile.handle,
            avatar: profile.avatar_url,
            verified: profile.verified_status !== 'unverified',
          } : undefined,
          text: comment.text,
          created_at: comment.created_at,
          updated_at: comment.updated_at,
        };
      });

      setComments(formattedComments);

    } catch (error) {
      console.error('Error fetching comments:', error);
      toast({
        title: 'Error loading comments',
        description: 'Failed to load comments. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [postId, toast]);

  const addComment = useCallback(async (text: string) => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You must be signed in to comment.',
        variant: 'destructive',
      });
      return false;
    }

    if (!text.trim()) {
      toast({
        title: 'Comment required',
        description: 'Please enter a comment before submitting.',
        variant: 'destructive',
      });
      return false;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase
        .from('comments')
        .insert({
          post_id: postId,
          author_id: user.id,
          text: text.trim(),
        });

      if (error) throw error;

      // Refresh comments to include the new one
      await fetchComments();

      toast({
        title: 'Comment added',
        description: 'Your comment has been posted.',
      });

      return true;

    } catch (error) {
      console.error('Error adding comment:', error);
      toast({
        title: 'Error posting comment',
        description: 'Failed to post comment. Please try again.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setSubmitting(false);
    }
  }, [user, postId, toast, fetchComments]);

  // Set up realtime subscription for comments
  useEffect(() => {
    fetchComments();

    const channel = supabase
      .channel('comments-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'comments',
          filter: `post_id=eq.${postId}`,
        },
        () => {
          fetchComments();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [postId, fetchComments]);

  return {
    comments,
    loading,
    submitting,
    addComment,
    refetch: fetchComments,
  };
};