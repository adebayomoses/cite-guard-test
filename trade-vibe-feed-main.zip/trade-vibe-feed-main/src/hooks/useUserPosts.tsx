import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Post {
  id: string;
  content: string;
  tickers: string[];
  risk_level: string | null;
  market_type: string | null;
  trade_direction: string | null;
  trade_meta: any;
  image_url: string | null;
  created_at: string;
  author: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
    verified_status: string | null;
    reputation_last30: number;
  };
  scores: {
    useful_count: number;
    not_useful_count: number;
    net_score: number;
  } | null;
}

export const useUserPosts = (userId: string | undefined) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPosts = async () => {
      if (!userId) {
        setPosts([]);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        // Fetch posts without relationship
        const { data: postsData, error: fetchError } = await supabase
          .from('posts')
          .select('*')
          .eq('author_id', userId)
          .order('created_at', { ascending: false });

        if (fetchError) throw fetchError;

        // Fetch author profile separately
        const { data: profileData } = await supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url, verified_status, reputation_last30')
          .eq('id', userId)
          .single();

        // Fetch post scores separately
        const postIds = (postsData || []).map((p: any) => p.id);
        let scoresMap = new Map();
        if (postIds.length > 0) {
          const { data: scoresData } = await supabase
            .from('post_scores')
            .select('post_id, useful_count, not_useful_count, net_score')
            .in('post_id', postIds);
          scoresMap = new Map((scoresData || []).map((s: any) => [s.post_id, s]));
        }

        const formattedPosts = (postsData || []).map((post: any) => ({
          id: post.id,
          content: post.content,
          tickers: post.tickers || [],
          risk_level: post.risk_level,
          market_type: post.market_type,
          trade_direction: post.trade_direction,
          trade_meta: post.trade_meta,
          image_url: post.image_url,
          created_at: post.created_at,
          author: profileData ? {
            id: profileData.id,
            handle: profileData.handle,
            display_name: profileData.display_name,
            avatar_url: profileData.avatar_url,
            verified_status: profileData.verified_status,
            reputation_last30: profileData.reputation_last30 || 0,
          } : null,
          scores: scoresMap.get(post.id) || null,
        }));

        setPosts(formattedPosts);
        setError(null);
      } catch (err) {
        console.error('Error fetching user posts:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch posts');
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, [userId]);

  return { posts, loading, error };
};
