import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface VerificationRequest {
  id: string;
  user_id: string;
  proof_type: "screenshot" | "myfxbook" | "mt4_password" | "statement";
  image_urls: string[];
  myfxbook_url: string | null;
  mt4_investor_password: string | null;
  mt4_server: string | null;
  mt4_account_number: string | null;
  additional_notes: string | null;
  status: "pending" | "approved" | "rejected";
  reviewed_by: string | null;
  reviewed_at: string | null;
  admin_notes: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
  // Joined profile data for admin view
  profile?: {
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
  };
}

interface SubmitVerificationData {
  proof_type: "screenshot" | "myfxbook" | "mt4_password" | "statement";
  image_urls?: string[];
  myfxbook_url?: string;
  mt4_investor_password?: string;
  mt4_server?: string;
  mt4_account_number?: string;
  additional_notes?: string;
}

export function useVerificationRequests() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<VerificationRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchUserRequests = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("verification_requests")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setRequests(data as VerificationRequest[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch requests");
    } finally {
      setLoading(false);
    }
  };

  const submitVerification = async (data: SubmitVerificationData) => {
    if (!user) throw new Error("User not authenticated");

    // Insert the verification request
    const { error: insertError } = await supabase
      .from("verification_requests")
      .insert({
        user_id: user.id,
        proof_type: data.proof_type,
        image_urls: data.image_urls || [],
        myfxbook_url: data.myfxbook_url || null,
        mt4_investor_password: data.mt4_investor_password || null,
        mt4_server: data.mt4_server || null,
        mt4_account_number: data.mt4_account_number || null,
        additional_notes: data.additional_notes || null,
      });

    if (insertError) throw insertError;

    // Update profile status to pending
    const { error: profileError } = await supabase
      .from("profiles")
      .update({ verified_status: "pending" })
      .eq("id", user.id);

    if (profileError) throw profileError;

    await fetchUserRequests();
  };

  const uploadVerificationImage = async (file: File): Promise<string> => {
    if (!user) throw new Error("User not authenticated");

    const fileExt = file.name.split(".").pop();
    const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("verification-docs")
      .upload(fileName, file);

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from("verification-docs")
      .getPublicUrl(fileName);

    return data.publicUrl;
  };

  const getLatestRequest = () => {
    return requests[0] || null;
  };

  useEffect(() => {
    if (user) {
      fetchUserRequests();
    }
  }, [user]);

  return {
    requests,
    loading,
    error,
    submitVerification,
    uploadVerificationImage,
    getLatestRequest,
    refetch: fetchUserRequests,
  };
}

// Admin hook for managing all verification requests
export function useAdminVerificationRequests() {
  const [requests, setRequests] = useState<VerificationRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAllRequests = async (statusFilter?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from("verification_requests")
        .select("*")
        .order("created_at", { ascending: false });

      if (statusFilter && statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      // Fetch profile data separately for each request
      const requestsWithProfiles = await Promise.all(
        (data || []).map(async (request) => {
          const { data: profileData } = await supabase
            .from("profiles")
            .select("handle, display_name, avatar_url")
            .eq("id", request.user_id)
            .single();
          
          return {
            ...request,
            profile: profileData || undefined,
          } as VerificationRequest;
        })
      );
      
      setRequests(requestsWithProfiles);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch requests");
    } finally {
      setLoading(false);
    }
  };

  const approveRequest = async (requestId: string, adminNotes?: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Admin not authenticated");

    // Get the request to find user_id
    const { data: request, error: fetchError } = await supabase
      .from("verification_requests")
      .select("user_id")
      .eq("id", requestId)
      .single();

    if (fetchError) throw fetchError;

    // Update the request status
    const { error: updateError } = await supabase
      .from("verification_requests")
      .update({
        status: "approved",
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString(),
        admin_notes: adminNotes || null,
      })
      .eq("id", requestId);

    if (updateError) throw updateError;

    // Update the user's profile to verified
    const { error: profileError } = await supabase
      .from("profiles")
      .update({ verified_status: "manual" })
      .eq("id", request.user_id);

    if (profileError) throw profileError;

    await fetchAllRequests();
  };

  const rejectRequest = async (requestId: string, rejectionReason: string, adminNotes?: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Admin not authenticated");

    // Get the request to find user_id
    const { data: request, error: fetchError } = await supabase
      .from("verification_requests")
      .select("user_id")
      .eq("id", requestId)
      .single();

    if (fetchError) throw fetchError;

    // Update the request status
    const { error: updateError } = await supabase
      .from("verification_requests")
      .update({
        status: "rejected",
        reviewed_by: user.id,
        reviewed_at: new Date().toISOString(),
        rejection_reason: rejectionReason,
        admin_notes: adminNotes || null,
      })
      .eq("id", requestId);

    if (updateError) throw updateError;

    // Update the user's profile back to unverified
    const { error: profileError } = await supabase
      .from("profiles")
      .update({ verified_status: "unverified" })
      .eq("id", request.user_id);

    if (profileError) throw profileError;

    await fetchAllRequests();
  };

  const getSignedUrl = async (path: string): Promise<string> => {
    // Extract the file path from the URL if it's a full URL
    const filePath = path.includes("verification-docs/") 
      ? path.split("verification-docs/")[1] 
      : path;

    const { data, error } = await supabase.storage
      .from("verification-docs")
      .createSignedUrl(filePath, 3600); // 1 hour expiry

    if (error) throw error;
    return data.signedUrl;
  };

  useEffect(() => {
    fetchAllRequests();
  }, []);

  return {
    requests,
    loading,
    error,
    approveRequest,
    rejectRequest,
    getSignedUrl,
    refetch: fetchAllRequests,
  };
}
