import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface RankConfig {
  key: string;
  name: string;
  minXP: number;
  icon: string;
  stars: number;
  color: string;
}

const DEFAULT_RANKS: RankConfig[] = [
  { key: 'rookie', name: 'Rookie', minXP: 0, icon: '🌟', stars: 0, color: 'text-muted-foreground' },
  { key: 'trader', name: 'Trader', minXP: 100, icon: '⭐', stars: 1, color: 'text-yellow-500' },
  { key: 'pro', name: 'Pro', minXP: 500, icon: '⭐⭐', stars: 2, color: 'text-yellow-500' },
  { key: 'elite', name: 'Elite', minXP: 2000, icon: '⭐⭐⭐', stars: 3, color: 'text-yellow-500' },
  { key: 'legend', name: 'Legend', minXP: 5000, icon: '👑', stars: 5, color: 'text-amber-400' },
];

const getRankByXP = (xp: number, ranks: RankConfig[]) => {
  const sortedRanks = [...ranks].sort((a, b) => b.minXP - a.minXP);
  for (const rank of sortedRanks) {
    if (xp >= rank.minXP) return rank;
  }
  return ranks[0] || DEFAULT_RANKS[0];
};

export const useCanCreatePremiumContent = () => {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ['can-create-premium-content', user?.id],
    queryFn: async () => {
      // Fetch ranks config and premium content min rank setting
      const [ranksResult, minRankResult] = await Promise.all([
        supabase.from('site_settings').select('value').eq('key', 'ranks_config').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'premium_content_min_rank').maybeSingle(),
      ]);

      let ranks: RankConfig[] = DEFAULT_RANKS;
      if (ranksResult.data?.value && typeof ranksResult.data.value === 'string') {
        try {
          ranks = JSON.parse(ranksResult.data.value);
        } catch (e) {
          console.error('Error parsing ranks config:', e);
        }
      }

      let minRankKey = 'pro';
      if (minRankResult.data?.value) {
        const val = minRankResult.data.value;
        if (typeof val === 'string') {
          minRankKey = val.replace(/"/g, '');
        }
      }

      // Find the threshold XP for the required rank
      const requiredRank = ranks.find(r => r.key === minRankKey) || ranks.find(r => r.key === 'pro') || DEFAULT_RANKS[2];
      const threshold = requiredRank.minXP;

      if (!user?.id) {
        return { 
          canCreate: false, 
          isAdmin: false, 
          currentXP: 0, 
          xpNeeded: threshold,
          threshold,
          requiredRank,
          ranks,
        };
      }
      
      // Check if user is admin and get XP in parallel
      const [roleResult, xpResult] = await Promise.all([
        supabase.from('user_roles').select('role').eq('user_id', user.id).eq('role', 'admin').maybeSingle(),
        supabase.from('user_xp').select('total_xp').eq('user_id', user.id).maybeSingle(),
      ]);
      
      const isAdmin = !!roleResult.data;
      const currentXP = xpResult.data?.total_xp || 0;
      const hasRequiredRank = currentXP >= threshold;
      
      return {
        canCreate: isAdmin || hasRequiredRank,
        isAdmin,
        currentXP,
        xpNeeded: Math.max(0, threshold - currentXP),
        currentRank: getRankByXP(currentXP, ranks),
        threshold,
        requiredRank,
        ranks,
      };
    },
    enabled: true,
    staleTime: 60000,
  });

  return {
    canCreate: data?.canCreate ?? false,
    isAdmin: data?.isAdmin ?? false,
    currentXP: data?.currentXP ?? 0,
    xpNeeded: data?.xpNeeded ?? 500,
    currentRank: data?.currentRank,
    loading: isLoading,
    proRankThreshold: data?.threshold ?? 500,
    requiredRank: data?.requiredRank,
  };
};
