import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { LifestyleVideo } from '@/types/lifestyle';

export const useLifestyleFeed = (mode: 'forYou' | 'following' = 'forYou') => {
  const [videos, setVideos] = useState<LifestyleVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);

  const fetchVideos = async (offset = 0, limit = 20) => {
    try {
      setLoading(true);
      setError(null);
      
      const { data: { session } } = await supabase.auth.getSession();
      const token = session?.access_token;
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/feed?mode=${mode}&limit=${limit}&offset=${offset}`, {
        method: 'GET',
        headers: {
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          'Content-Type': 'application/json'
        },
        cache: 'no-store'
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Anonymous user or expired token - show empty state
          setVideos([]);
          setHasMore(false);
          setLoading(false);
          return;
        }
        throw new Error(`Lifestyle feed error ${response.status}`);
      }
      
      const data = await response.json();

      if (offset === 0) {
        setVideos(data || []);
      } else {
        setVideos(prev => [...prev, ...(data || [])]);
      }
      
      setHasMore((data || []).length === limit);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch lifestyle videos:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch videos');
    } finally {
      setLoading(false);
    }
  };

  const loadMore = () => {
    if (!loading && hasMore) {
      fetchVideos(videos.length);
    }
  };

  const refreshFeed = () => {
    fetchVideos(0);
  };

  useEffect(() => {
    fetchVideos(0);
  }, [mode]);

  return {
    videos,
    loading,
    error,
    hasMore,
    loadMore,
    refreshFeed,
    setVideos
  };
};

export const useLifestyleActions = () => {
  const toggleLike = async (videoId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/${videoId}/like`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      return data;
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Failed to toggle like');
    }
  };

  const addComment = async (videoId: string, text: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/${videoId}/comments`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text })
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      return data;
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Failed to add comment');
    }
  };

  const uploadVideo = async (videoData: {
    caption?: string;
    hashtags?: string[];
    tickers?: string[];
    visibility?: 'public' | 'followers';
    video_url: string;
    thumbnail_url?: string;
    duration_seconds?: number;
  }) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(videoData)
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      return data;
    } catch (err) {
      throw new Error(err instanceof Error ? err.message : 'Failed to upload video');
    }
  };

  return {
    toggleLike,
    addComment,
    uploadVideo
  };
};