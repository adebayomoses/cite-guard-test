import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import type { ChatConversation } from './useChat';

export const useChatList = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load conversations list
  const loadConversations = useCallback(async () => {
    if (!user) return;

    setLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/list`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
          }
        }
      );

      if (!response.ok) throw new Error('Failed to load conversations');

      const result = await response.json();
      setConversations(result.conversations);
    } catch (err) {
      console.error('Error loading conversations:', err);
      setError('Failed to load conversations');
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Start new conversation
  const startConversation = useCallback(async (userId: string) => {
    if (!user) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/start`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId })
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to start conversation');
      }

      const result = await response.json();
      
      // Refresh conversations list
      await loadConversations();
      
      return result.conversationId;
    } catch (err) {
      console.error('Error starting conversation:', err);
      setError(err instanceof Error ? err.message : 'Failed to start conversation');
      return null;
    }
  }, [user, loadConversations]);

  // Block/unblock user
  const toggleBlock = useCallback(async (userId: string) => {
    if (!user) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/block`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ blockedUserId: userId })
        }
      );

      if (!response.ok) throw new Error('Failed to toggle block');

      const result = await response.json();
      return result.blocked;
    } catch (err) {
      console.error('Error toggling block:', err);
      setError('Failed to update block status');
      return null;
    }
  }, [user]);

  // Report message
  const reportMessage = useCallback(async (messageId: string, reason: string) => {
    if (!user) return false;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('No valid session');
      }

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/report`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ messageId, reason })
        }
      );

      if (!response.ok) throw new Error('Failed to report message');

      return true;
    } catch (err) {
      console.error('Error reporting message:', err);
      setError('Failed to report message');
      return false;
    }
  }, [user]);

  // Set up real-time subscription for conversation updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('conversations-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages'
        },
        () => {
          // Reload conversations when any message changes
          loadConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, loadConversations]);

  // Load conversations on mount
  useEffect(() => {
    if (user) {
      loadConversations();
    }
  }, [user, loadConversations]);

  return {
    conversations,
    loading,
    error,
    loadConversations,
    startConversation,
    toggleBlock,
    reportMessage
  };
};