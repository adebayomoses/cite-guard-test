import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Profile {
  id: string;
  handle: string;
  display_name?: string;
  bio?: string;
  avatar_url?: string;
  markets: string[];
  strategy_tags: string[];
  experience_level: 'beginner' | 'intermediate' | 'advanced';
  verified_status: 'unverified' | 'manual' | 'broker';
  timezone?: string;
  links: Record<string, string>;
  watchlist: string[];
  reputation_last30: number;
  created_at: string;
  updated_at: string;
}

export interface ProfilePrivacy {
  user_id: string;
  is_public: boolean;
  show_stats: boolean;
}

export const useProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [privacy, setPrivacy] = useState<ProfilePrivacy | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async () => {
    if (!user) {
      setProfile(null);
      setPrivacy(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // Fetch profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (profileError) throw profileError;

      // Fetch privacy settings
      const { data: privacyData, error: privacyError } = await supabase
        .from('profile_privacy')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (privacyError) throw privacyError;

      setProfile(profileData as Profile);
      setPrivacy(privacyData);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [user]);

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return { error: 'Not authenticated' };

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;
      
      await fetchProfile(); // Refresh profile data
      return { error: null };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      return { error: errorMessage };
    }
  };

  const updatePrivacy = async (updates: Partial<ProfilePrivacy>) => {
    if (!user) return { error: 'Not authenticated' };

    try {
      const { error } = await supabase
        .from('profile_privacy')
        .update(updates)
        .eq('user_id', user.id);

      if (error) throw error;
      
      await fetchProfile(); // Refresh privacy data
      return { error: null };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMessage);
      return { error: errorMessage };
    }
  };

  const checkHandleAvailability = async (handle: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id')
        .eq('handle', handle.toLowerCase())
        .maybeSingle();

      if (error) throw error;
      
      return { available: !data, error: null };
    } catch (err) {
      return { 
        available: false, 
        error: err instanceof Error ? err.message : 'An error occurred' 
      };
    }
  };

  return {
    profile,
    privacy,
    loading,
    error,
    updateProfile,
    updatePrivacy,
    checkHandleAvailability,
    refetch: fetchProfile,
  };
};