import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type NewsCategory = 'general' | 'economy' | 'crypto' | 'forex' | 'stocks';

export interface MarketNews {
  id?: string;
  title: string;
  summary: string;
  url: string;
  source: string;
  published_at: string;
  image_url?: string;
  category: string;
}

export const useMarketNews = (category: NewsCategory = 'general', limit: number = 20) => {
  return useQuery({
    queryKey: ['market-news', category, limit],
    queryFn: async () => {
      console.log('Fetching market news:', category);
      
      // Call edge function to get news
      const { data, error } = await supabase.functions.invoke('market-data-api/news', {
        body: { category, limit }
      });

      if (error) {
        console.error('Error fetching news:', error);
        throw error;
      }

      return data as MarketNews[];
    },
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
    staleTime: 4 * 60 * 1000, // Data is fresh for 4 minutes
  });
};