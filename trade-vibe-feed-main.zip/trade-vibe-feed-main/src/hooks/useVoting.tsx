import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import type { VoteResponse } from '@/types';

export const useVoting = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const voteOnPost = useCallback(async (postId: string, value: 1 | -1): Promise<VoteResponse | null> => {
    if (!user) {
      toast({
        title: 'Please sign in',
        description: 'You must be signed in to vote on posts.',
        variant: 'destructive',
      });
      return null;
    }

    setLoading(true);
    try {
      // Check if user is voting on their own post (this would be done server-side in real app)
      // For now, we'll allow all votes in the mock implementation
      
      // First, check if user has already voted
      const { data: existingVote } = await supabase
        .from('votes')
        .select('value')
        .eq('user_id', user.id)
        .eq('post_id', postId)
        .maybeSingle();

      if (existingVote) {
        if (existingVote.value === value) {
          // Same vote - remove it (toggle off)
          const { error } = await supabase
            .from('votes')
            .delete()
            .eq('user_id', user.id)
            .eq('post_id', postId);

          if (error) throw error;
        } else {
          // Different vote - update it
          const { error } = await supabase
            .from('votes')
            .update({ value })
            .eq('user_id', user.id)
            .eq('post_id', postId);

          if (error) throw error;
        }
      } else {
        // No existing vote - create new one
        const { error } = await supabase
          .from('votes')
          .insert({ user_id: user.id, post_id: postId, value });

        if (error) throw error;
      }

      // Get updated scores
      const { data: scores } = await supabase
        .from('post_scores')
        .select('useful_count, not_useful_count, net_score')
        .eq('post_id', postId)
        .single();

      // Get user's current vote
      const { data: userVote } = await supabase
        .from('votes')
        .select('value')
        .eq('user_id', user.id)
        .eq('post_id', postId)
        .maybeSingle();

      return {
        useful: scores?.useful_count || 0,
        notUseful: scores?.not_useful_count || 0,
        net: scores?.net_score || 0,
        userVote: (userVote?.value as 1 | -1) || null,
      };

    } catch (error) {
      console.error('Error voting on post:', error);
      toast({
        title: 'Error voting',
        description: 'Failed to register your vote. Please try again.',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  return {
    voteOnPost,
    loading,
  };
};