import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from 'next-themes';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AvatarUploader } from '@/components/AvatarUploader';
import { LinkFields } from '@/components/LinkFields';
import { TickerInput } from '@/components/TickerInput';
import { useProfile } from '@/hooks/useProfile';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, X, Sun, Moon, Monitor } from 'lucide-react';

const AVAILABLE_MARKETS = [
  'Stocks', 'Crypto', 'Forex', 'Options', 'Futures', 'Commodities', 'Bonds', 'ETFs',
];

const AVAILABLE_STRATEGIES = [
  'scalper', 'swing', 'longterm', 'options', 'quant', 'momentum', 'value', 'growth', 'dividend', 'arbitrage',
];

const TIMEZONES = [
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Asia/Tokyo', 'Asia/Shanghai',
  'Asia/Kolkata', 'Australia/Sydney', 'UTC',
];

export default function ProfileSettings() {
  const { profile, updateProfile, loading } = useProfile();
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [formData, setFormData] = useState({
    display_name: '',
    bio: '',
    avatar_url: '',
    markets: [] as string[],
    strategy_tags: [] as string[],
    experience_level: 'beginner' as 'beginner' | 'intermediate' | 'advanced',
    timezone: '',
    links: {} as Record<string, string>,
    watchlist: [] as string[],
  });
  const [newTicker, setNewTicker] = useState('');
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (profile) {
      setFormData({
        display_name: profile.display_name || '',
        bio: profile.bio || '',
        avatar_url: profile.avatar_url || '',
        markets: profile.markets || [],
        strategy_tags: profile.strategy_tags || [],
        experience_level: profile.experience_level || 'beginner',
        timezone: profile.timezone || '',
        links: profile.links || {},
        watchlist: profile.watchlist || [],
      });
    }
  }, [profile]);

  const updateFormData = (updates: Partial<typeof formData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleMarketToggle = (market: string) => {
    const markets = formData.markets.includes(market)
      ? formData.markets.filter(m => m !== market)
      : [...formData.markets, market];
    updateFormData({ markets });
  };

  const handleStrategyToggle = (strategy: string) => {
    const strategy_tags = formData.strategy_tags.includes(strategy)
      ? formData.strategy_tags.filter(s => s !== strategy)
      : [...formData.strategy_tags, strategy];
    updateFormData({ strategy_tags });
  };

  const handleAddTicker = (ticker: string) => {
    if (ticker && !formData.watchlist.includes(ticker)) {
      updateFormData({ 
        watchlist: [...formData.watchlist, ticker] 
      });
    }
    setNewTicker('');
  };

  const handleRemoveTicker = (ticker: string) => {
    updateFormData({ 
      watchlist: formData.watchlist.filter(t => t !== ticker) 
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    const { error } = await updateProfile(formData);
    
    if (error) {
      toast({
        title: 'Error',
        description: error,
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Profile updated',
        description: 'Your profile has been successfully updated.',
      });
    }
    
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="container mx-auto max-w-2xl p-4 pt-20">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">Profile Settings</h1>
          <p className="text-muted-foreground">
            Manage your profile information and preferences
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>
                Your public profile information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-center">
                <AvatarUploader
                  currentUrl={formData.avatar_url}
                  onUpload={(url) => updateFormData({ avatar_url: url })}
                  size="md"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="display_name">Display Name</Label>
                <Input
                  id="display_name"
                  value={formData.display_name}
                  onChange={(e) => updateFormData({ display_name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell other traders about yourself..."
                  value={formData.bio}
                  onChange={(e) => updateFormData({ bio: e.target.value })}
                  className="min-h-[100px]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={formData.timezone}
                  onValueChange={(value) => updateFormData({ timezone: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map((tz) => (
                      <SelectItem key={tz} value={tz}>
                        {tz.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Choose your preferred theme
              </CardDescription>
            </CardHeader>
            <CardContent>
              {mounted ? (
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setTheme('light')}
                    className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-colors ${
                      theme === 'light'
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-background hover:bg-muted border-border'
                    }`}
                  >
                    <Sun className="h-6 w-6" />
                    <span className="text-sm font-medium">Light</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('dark')}
                    className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-colors ${
                      theme === 'dark'
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-background hover:bg-muted border-border'
                    }`}
                  >
                    <Moon className="h-6 w-6" />
                    <span className="text-sm font-medium">Dark</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('system')}
                    className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-colors ${
                      theme === 'system'
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-background hover:bg-muted border-border'
                    }`}
                  >
                    <Monitor className="h-6 w-6" />
                    <span className="text-sm font-medium">System</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-20 rounded-lg bg-muted animate-pulse" />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Social Links</CardTitle>
              <CardDescription>
                Connect your social media and trading accounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <LinkFields
                links={formData.links}
                onChange={(links) => updateFormData({ links })}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Watchlist</CardTitle>
              <CardDescription>
                Tickers you're actively following
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <TickerInput
                value={newTicker}
                onChange={setNewTicker}
                onAdd={handleAddTicker}
                placeholder="Add ticker symbols (e.g., AAPL, BTC, EURUSD)"
              />
              
              {formData.watchlist.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {formData.watchlist.map((ticker) => (
                    <Badge key={ticker} variant="secondary" className="px-2 py-1">
                      ${ticker}
                      <button
                        type="button"
                        onClick={() => handleRemoveTicker(ticker)}
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              <Save className="mr-2 h-4 w-4" />
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}