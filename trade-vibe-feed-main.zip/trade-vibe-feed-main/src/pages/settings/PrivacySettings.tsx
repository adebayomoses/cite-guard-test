import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useProfile } from '@/hooks/useProfile';
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Shield, Eye } from 'lucide-react';

export default function PrivacySettings() {
  const { privacy, updatePrivacy, loading } = useProfile();
  const [isPublic, setIsPublic] = useState(true);
  const [showStats, setShowStats] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (privacy) {
      setIsPublic(privacy.is_public);
      setShowStats(privacy.show_stats);
    }
  }, [privacy]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await updatePrivacy({
        is_public: isPublic,
        show_stats: showStats,
      });

      if (error) throw new Error(error);

      toast({
        title: 'Privacy settings updated',
        description: 'Your privacy preferences have been saved.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update privacy settings. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pt-14 pb-20">
        <div className="max-w-2xl mx-auto p-4">
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-14 pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Privacy Settings</h1>
          <p className="text-muted-foreground">
            Control who can see your profile and activity
          </p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Profile Visibility
              </CardTitle>
              <CardDescription>
                Choose who can view your profile and trading activity
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="public-profile" className="text-base">
                    Public Profile
                  </Label>
                  <div className="text-sm text-muted-foreground">
                    Allow anyone to view your profile, posts, and trading activity
                  </div>
                </div>
                <Switch
                  id="public-profile"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show-stats" className="text-base">
                    Show Statistics
                  </Label>
                  <div className="text-sm text-muted-foreground">
                    Display follower count, reputation, and other metrics
                  </div>
                </div>
                <Switch
                  id="show-stats"
                  checked={showStats}
                  onCheckedChange={setShowStats}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Privacy Effects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <strong>Public Profile:</strong> When enabled, anyone can view your profile page, posts, and trading journal. When disabled, only signed-in users can view limited information.
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <strong>Show Statistics:</strong> Controls whether follower counts, reputation scores, and performance metrics are visible to others.
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <strong>Note:</strong> Your posts will still appear in public feeds regardless of these settings, but your profile link will show limited information if private.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button 
              onClick={handleSave}
              disabled={saving}
            >
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}