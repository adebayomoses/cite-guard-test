import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, X, Hash, TrendingUp, Target, StopCircle, Clock, ArrowUp, ArrowDown, BarChart3 } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { TickerInput } from "@/components/TickerInput";

export default function CreatePost() {
  const navigate = useNavigate();
  const [postText, setPostText] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [riskLevel, setRiskLevel] = useState("medium");
  const [detectedTickers, setDetectedTickers] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Market and direction selection
  const [marketType, setMarketType] = useState("stocks");
  const [tradeDirection, setTradeDirection] = useState("long");
  
  // Trading metadata
  const [timeframe, setTimeframe] = useState("");
  const [entryPrice, setEntryPrice] = useState("");
  const [stopPrice, setStopPrice] = useState("");
  const [targetPrice, setTargetPrice] = useState("");
  
  // Manual ticker input
  const [primaryTicker, setPrimaryTicker] = useState("");
  const [tickerInputValue, setTickerInputValue] = useState("");
  const [manualTickers, setManualTickers] = useState<string[]>([]);

  // Auto-detect tickers in text
  const detectTickers = (text: string) => {
    const tickerRegex = /\$[A-Z]{1,5}/g;
    const matches = text.match(tickerRegex) || [];
    const uniqueTickers = [...new Set(matches)];
    setDetectedTickers(uniqueTickers);
  };

  const handleTextChange = (text: string) => {
    setPostText(text);
    detectTickers(text);
  };

  const handleAddTicker = (ticker: string) => {
    const cleanTicker = ticker.toUpperCase();
    if (!manualTickers.includes(cleanTicker)) {
      setManualTickers([...manualTickers, cleanTicker]);
      if (manualTickers.length === 0) {
        setPrimaryTicker(cleanTicker); // First ticker is primary
      }
    }
    setTickerInputValue(""); // Clear input
  };

  const handleRemoveTicker = (tickerToRemove: string) => {
    const updatedTickers = manualTickers.filter(t => t !== tickerToRemove);
    setManualTickers(updatedTickers);
    if (primaryTicker === tickerToRemove && updatedTickers.length > 0) {
      setPrimaryTicker(updatedTickers[0]); // Set new primary
    } else if (updatedTickers.length === 0) {
      setPrimaryTicker("");
    }
  };

  const handleSetPrimaryTicker = (ticker: string) => {
    setPrimaryTicker(ticker);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low": return "text-profit border-profit bg-profit/10";
      case "medium": return "text-neutral border-neutral bg-neutral/10";
      case "high": return "text-loss border-loss bg-loss/10";
      default: return "text-neutral border-neutral bg-neutral/10";
    }
  };

  const handleSubmit = async () => {
    if (!postText.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your post.",
        variant: "destructive",
      });
      return;
    }

    // Check if trading details are filled but no ticker is specified
    const hasTradingDetails = entryPrice && targetPrice;
    if (hasTradingDetails && manualTickers.length === 0) {
      toast({
        title: "Ticker Required",
        description: "Please add at least one ticker symbol for your signal.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      let imageUrl = null;
      
      // Upload image to Supabase Storage if present
      if (selectedImage) {
        const file = await fetch(selectedImage).then(r => r.blob());
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.jpg`;
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('post-images')
          .upload(fileName, file, {
            contentType: 'image/jpeg',
            upsert: false
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          throw new Error('Failed to upload image');
        }

        const { data: urlData } = supabase.storage
          .from('post-images')
          .getPublicUrl(fileName);
        
        imageUrl = urlData.publicUrl;
      }

      // Combine manual tickers with detected tickers
      const allTickers = [...new Set([...manualTickers, ...detectedTickers.map(t => t.replace('$', ''))])];

      // Create the post data
      const postData = {
        content: postText,
        tickers: allTickers,
        risk_level: riskLevel,
        market_type: marketType,
        trade_direction: tradeDirection,
        trading_info: {
          timeframe: timeframe || null,
          entry_price: entryPrice || null,
          stop_price: stopPrice || null,
          target_price: targetPrice || null,
        },
        image_url: imageUrl,
      };

      console.log('Submitting post data:', postData);

      // Call the posts API using direct fetch for better error handling
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/posts-api`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp5b25qeHZmanNoa2pkdGp3Y3FvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1MTI2NTYsImV4cCI6MjA3NDA4ODY1Nn0.jJLyCVuoDQUxr_lA3BPDGVza_zwAeVUFILAz0S1pR34'
        },
        body: JSON.stringify(postData)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API response error:', errorText);
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      console.log('API result:', result);
      
      toast({
        title: "Success!",
        description: "Your trade has been shared successfully.",
      });
      
      // Navigate back to feed
      navigate("/");
      
    } catch (error) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to share your trade. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-bold text-foreground">Create Post</h1>
          <Button 
            size="sm" 
            className="bg-gradient-primary text-primary-foreground"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? "Sharing..." : "Share Trade"}
          </Button>
        </div>
      </div>

      {/* Create Form */}
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        <Card className="bg-gradient-card border-border shadow-card p-6">
          {/* Text Input */}
          <div className="space-y-3 mb-6">
            <Label htmlFor="post-text" className="text-sm font-medium text-foreground">
              Share your trade analysis
            </Label>
            <Textarea
              id="post-text"
              placeholder="What's your take on the market? Use $TICKER to tag stocks/crypto..."
              value={postText}
              onChange={(e) => handleTextChange(e.target.value)}
              className="min-h-32 resize-none bg-background border-border focus:border-primary focus:ring-primary"
            />
            
            {/* Auto-detected Tickers */}
            {detectedTickers.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Hash className="h-3 w-3" />
                  Detected:
                </span>
                {detectedTickers.map((ticker) => (
                  <Badge key={ticker} variant="outline" className="text-primary border-primary/50 bg-primary/10">
                    {ticker}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Image Upload */}
          <div className="space-y-3 mb-6">
            <Label className="text-sm font-medium text-foreground">
              Chart or Screenshot
            </Label>
            
            {selectedImage ? (
              <div className="relative">
                <img 
                  src={selectedImage} 
                  alt="Upload preview" 
                  className="w-full h-48 object-cover rounded-lg border border-border"
                />
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={removeImage}
                  className="absolute top-2 right-2 h-8 w-8 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors">
                <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground mb-2">
                  Upload your trading chart or screenshot
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="image-upload"
                />
                <Label
                  htmlFor="image-upload"
                  className="inline-flex items-center px-4 py-2 bg-primary text-primary-foreground rounded-lg cursor-pointer hover:bg-primary/90 transition-colors"
                >
                  Choose File
                </Label>
              </div>
            )}
          </div>

          {/* Market Type & Trade Direction */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Market Type */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Market Type
              </Label>
              <Select value={marketType} onValueChange={setMarketType}>
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder="Select market" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stocks">📈 Stocks</SelectItem>
                  <SelectItem value="crypto">₿ Crypto</SelectItem>
                  <SelectItem value="forex">💱 Forex</SelectItem>
                  <SelectItem value="options">🎯 Options</SelectItem>
                  <SelectItem value="futures">⚡ Futures</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Trade Direction */}
            <div className="space-y-3">
              <Label className="text-sm font-medium text-foreground">
                Trade Direction
              </Label>
              <RadioGroup
                value={tradeDirection}
                onValueChange={setTradeDirection}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem
                    value="long"
                    id="long"
                    className="text-primary border-primary"
                  />
                  <Label
                    htmlFor="long"
                    className={`cursor-pointer font-medium flex items-center gap-1 ${
                      tradeDirection === "long" ? "text-profit" : "text-muted-foreground"
                    }`}
                  >
                    <ArrowUp className="h-3 w-3" />
                    Long/Buy
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem
                    value="short"
                    id="short"
                    className="text-primary border-primary"
                  />
                  <Label
                    htmlFor="short"
                    className={`cursor-pointer font-medium flex items-center gap-1 ${
                      tradeDirection === "short" ? "text-loss" : "text-muted-foreground"
                    }`}
                  >
                    <ArrowDown className="h-3 w-3" />
                    Short/Sell
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          {/* Risk Level */}
          <div className="space-y-3 mb-6">
            <Label className="text-sm font-medium text-foreground">
              Risk Level
            </Label>
            <RadioGroup
              value={riskLevel}
              onValueChange={setRiskLevel}
              className="flex gap-4"
            >
              {["low", "medium", "high"].map((risk) => (
                <div key={risk} className="flex items-center space-x-2">
                  <RadioGroupItem
                    value={risk}
                    id={risk}
                    className="text-primary border-primary"
                  />
                  <Label
                    htmlFor={risk}
                    className={`capitalize cursor-pointer font-medium ${
                      riskLevel === risk ? getRiskColor(risk) : "text-muted-foreground"
                    }`}
                  >
                    {risk} Risk
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Trading Information */}
          <Card className="bg-background/30 border-border/50 p-4 space-y-4 mb-6">
            <Label className="text-sm font-medium text-foreground flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Trading Details (Optional)
            </Label>
            
            <div className="grid grid-cols-2 gap-4">
              {/* Ticker Input */}
              <div className="space-y-2 col-span-2">
                <Label className="text-xs text-muted-foreground flex items-center gap-1">
                  <Hash className="h-3 w-3" />
                  Ticker Symbol {(entryPrice || targetPrice) && <span className="text-loss">*</span>}
                </Label>
                <TickerInput
                  value={tickerInputValue}
                  onChange={setTickerInputValue}
                  onAdd={handleAddTicker}
                  placeholder="e.g., BTC, ETH, AAPL"
                />
                
                {/* Display added tickers */}
                {manualTickers.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {manualTickers.map((ticker) => (
                      <Badge 
                        key={ticker} 
                        variant={ticker === primaryTicker ? "default" : "outline"}
                        className={`cursor-pointer ${ticker === primaryTicker ? 'bg-primary text-primary-foreground' : 'text-foreground border-border'}`}
                        onClick={() => handleSetPrimaryTicker(ticker)}
                      >
                        {ticker}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveTicker(ticker);
                          }}
                          className="ml-1 hover:text-destructive"
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
                {manualTickers.length > 0 && (
                  <p className="text-xs text-muted-foreground">
                    Click a ticker to set it as primary for tracking
                  </p>
                )}
              </div>

              {/* Timeframe */}
              <div className="space-y-2">
                <Label htmlFor="timeframe" className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Timeframe
                </Label>
                <Select value={timeframe} onValueChange={setTimeframe}>
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Select timeframe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1m">1 Minute</SelectItem>
                    <SelectItem value="5m">5 Minutes</SelectItem>
                    <SelectItem value="15m">15 Minutes</SelectItem>
                    <SelectItem value="30m">30 Minutes</SelectItem>
                    <SelectItem value="1h">1 Hour</SelectItem>
                    <SelectItem value="4h">4 Hours</SelectItem>
                    <SelectItem value="1d">1 Day</SelectItem>
                    <SelectItem value="1w">1 Week</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Entry Price */}
              <div className="space-y-2">
                <Label htmlFor="entry" className="text-xs text-muted-foreground flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  Entry Price
                </Label>
                <Input
                  id="entry"
                  type="text"
                  placeholder="$43,200"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(e.target.value)}
                  className="bg-background border-border"
                />
              </div>

              {/* Stop Loss */}
              <div className="space-y-2">
                <Label htmlFor="stop" className="text-xs text-muted-foreground flex items-center gap-1">
                  <StopCircle className="h-3 w-3" />
                  Stop Loss
                </Label>
                <Input
                  id="stop"
                  type="text"
                  placeholder="$41,800"
                  value={stopPrice}
                  onChange={(e) => setStopPrice(e.target.value)}
                  className="bg-background border-border"
                />
              </div>

              {/* Target Price */}
              <div className="space-y-2">
                <Label htmlFor="target" className="text-xs text-muted-foreground flex items-center gap-1">
                  <Target className="h-3 w-3" />
                  Target Price
                </Label>
                <Input
                  id="target"
                  type="text"
                  placeholder="$48,000"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  className="bg-background border-border"
                />
              </div>
            </div>
          </Card>
        </Card>

        {/* Preview Card */}
        {(postText || selectedImage || timeframe || entryPrice || stopPrice || targetPrice) && (
          <Card className="bg-gradient-card border-border shadow-card p-4">
            <h3 className="text-sm font-medium text-foreground mb-3">Preview</h3>
            <div className="space-y-3">
              <div className="flex flex-wrap gap-1">
                {/* Market and Direction Badges */}
                <Badge variant="outline" className="text-primary border-primary/50 bg-primary/10 capitalize">
                  {marketType === "stocks" ? "📈" : marketType === "crypto" ? "₿" : marketType === "forex" ? "💱" : marketType === "options" ? "🎯" : "⚡"} {marketType}
                </Badge>
                <Badge variant="outline" className={`${tradeDirection === "long" ? "text-profit border-profit/50 bg-profit/10" : "text-loss border-loss/50 bg-loss/10"}`}>
                  {tradeDirection === "long" ? "↗️" : "↘️"} {tradeDirection.toUpperCase()}
                </Badge>
                {detectedTickers.map((ticker) => (
                  <Badge key={ticker} variant="outline" className="text-primary border-primary/50 bg-primary/10">
                    {ticker}
                  </Badge>
                ))}
                <Badge variant="outline" className={getRiskColor(riskLevel)}>
                  {riskLevel.toUpperCase()} RISK
                </Badge>
              </div>
              {postText && (
                <p className="text-foreground text-sm">{postText}</p>
              )}
              {selectedImage && (
                <img 
                  src={selectedImage} 
                  alt="Preview" 
                  className="w-full h-32 object-cover rounded-lg"
                />
              )}
              
              {/* Trading Info Preview */}
              {(timeframe || entryPrice || stopPrice || targetPrice) && (
                <div className="grid grid-cols-2 gap-2 p-3 bg-background/50 rounded-lg border border-border/50 text-xs">
                  {timeframe && (
                    <div className="text-muted-foreground">
                      <span className="text-foreground font-medium">Timeframe:</span> {timeframe.toUpperCase()}
                    </div>
                  )}
                  {entryPrice && (
                    <div className="text-muted-foreground">
                      <span className="text-foreground font-medium">Entry:</span> {entryPrice}
                    </div>
                  )}
                  {stopPrice && (
                    <div className="text-loss">
                      <span className="text-foreground font-medium">Stop:</span> {stopPrice}
                    </div>
                  )}
                  {targetPrice && (
                    <div className="text-profit">
                      <span className="text-foreground font-medium">Target:</span> {targetPrice}
                    </div>
                  )}
                </div>
              )}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}