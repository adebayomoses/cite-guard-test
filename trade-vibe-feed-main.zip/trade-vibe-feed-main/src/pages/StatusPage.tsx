import { PageHeader } from '@/components/PageHeader';
import { GlobalHeader } from '@/components/GlobalHeader';
import { RankCard } from '@/components/status/RankCard';
import { RankLadder } from '@/components/status/RankLadder';
import { AchievementsGrid } from '@/components/status/AchievementsGrid';
import { TopClimbers } from '@/components/status/TopClimbers';
import { XPHistory } from '@/components/status/XPHistory';
import { useStatus } from '@/hooks/useStatus';
import { Skeleton } from '@/components/ui/skeleton';

const StatusPage = () => {
  const { 
    userXP, 
    achievements, 
    userAchievements, 
    xpTransactions, 
    topClimbers, 
    allTimeLeaders,
    loading 
  } = useStatus();

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <PageHeader 
          title="Status" 
          subtitle="Your trading rank and achievements"
        />
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          <Skeleton className="h-48 w-full rounded-xl" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Skeleton className="h-64 w-full rounded-xl" />
            <Skeleton className="h-64 w-full rounded-xl" />
          </div>
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <GlobalHeader />
      <PageHeader 
        title="Status" 
        subtitle="Your trading rank and achievements"
      />
      
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Main Rank Card */}
        <RankCard userXP={userXP} />
        
        {/* Two Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            <RankLadder currentXP={userXP?.total_xp || 0} />
            <XPHistory transactions={xpTransactions || []} />
          </div>
          
          {/* Right Column */}
          <div className="space-y-6">
            <TopClimbers 
              weeklyClimbers={topClimbers || []} 
              allTimeLeaders={allTimeLeaders || []} 
            />
          </div>
        </div>
        
        {/* Achievements - Full Width */}
        <AchievementsGrid 
          achievements={achievements || []} 
          userAchievements={userAchievements || []} 
        />
      </div>
    </div>
  );
};

export default StatusPage;
