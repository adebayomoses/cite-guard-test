import { useState, useEffect } from "react";
import { TradingPost } from "@/components/TradingPost";
import { MarketTabs } from "@/components/MarketTabs";
import { GlobalHeader } from "@/components/GlobalHeader";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Sparkles, TrendingUp } from "lucide-react";
import { ChallengeBanner } from "@/components/ChallengeBanner";
import { supabase } from "@/integrations/supabase/client";
import heroChart from "@/assets/hero-chart.jpg";

// Mock data with proper UUIDs
const mockPosts = [
  {
    id: "550e8400-e29b-41d4-a716-446655440001",
    author: {
      username: "cryptowolf",
      avatar: "/placeholder.svg",
      verified: true,
      reputation: 87,
      isFollowed: true,
    },
    content: {
      text: "Massive breakout on $BTC! This pattern has been forming for weeks. Volume confirmation is strong. Looking for $48k next. Risk management is key here - tight stops below $42k support.",
      image: heroChart,
      tickers: ["$BTC", "$ETH"],
      riskLevel: "medium" as const,
    },
    engagement: {
      useful: 142,
      notUseful: 8,
      userVote: 1 as const,
      isSaved: false,
    },
    tradeMeta: {
      timeframe: "4H",
      entry: "$43,200",
      stop: "$41,800",
      target: "$48,000",
    },
    timestamp: "2h ago",
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440002",
    author: {
      username: "stockmaster",
      avatar: "/placeholder.svg",
      verified: false,
      reputation: 72,
      isFollowed: false,
    },
    content: {
      text: "$AAPL earnings play looking juicy. Historical data shows strong Q4 performance. iPhone 15 sales data suggests positive surprise. Conservative position size due to macro uncertainty.",
      tickers: ["$AAPL", "$MSFT"],
      riskLevel: "low" as const,
    },
    engagement: {
      useful: 89,
      notUseful: 12,
      userVote: null,
      isSaved: true,
    },
    tradeMeta: {
      timeframe: "Daily",
      entry: "$190.50",
      stop: "$185.00",
      target: "$205.00",
    },
    timestamp: "4h ago",
  },
  {
    id: "550e8400-e29b-41d4-a716-446655440003",
    author: {
      username: "forexking",
      avatar: "/placeholder.svg",
      verified: true,
      reputation: 94,
      isFollowed: true,
    },
    content: {
      text: "EUR/USD showing classic reversal pattern. DXY weakness + ECB hawkish signals = perfect storm. Multiple confirmations across different timeframes. High conviction trade.",
      tickers: ["$EURUSD", "$DXY"],
      riskLevel: "high" as const,
    },
    engagement: {
      useful: 203,
      notUseful: 5,
      userVote: null,
      isSaved: false,
    },
    tradeMeta: {
      timeframe: "1H",
      entry: "1.0850",
      stop: "1.0820",
      target: "1.0920",
    },
    timestamp: "6h ago",
  },
];

// Helper function to infer market type from post
const inferMarket = (post: any): string => {
  // Check if post has explicit marketType
  if (post.content?.marketType) {
    return post.content.marketType;
  }
  
  // Infer from tickers
  const tickers = post.content?.tickers || [];
  
  for (const ticker of tickers) {
    const tickerUpper = ticker.toUpperCase();
    
    // Crypto patterns
    if (tickerUpper.includes('BTC') || tickerUpper.includes('ETH') || 
        tickerUpper.includes('SOL') || tickerUpper.includes('ADA') ||
        tickerUpper.includes('DOT') || tickerUpper.includes('DOGE')) {
      return 'crypto';
    }
    
    // Forex patterns (currency pairs)
    if (tickerUpper.includes('EUR') || tickerUpper.includes('USD') || 
        tickerUpper.includes('GBP') || tickerUpper.includes('JPY') ||
        tickerUpper.includes('DXY') || tickerUpper.match(/^[A-Z]{6}$/)) {
      return 'forex';
    }
    
    // Options patterns
    if (tickerUpper.includes('C') || tickerUpper.includes('P') || 
        tickerUpper.includes('CALL') || tickerUpper.includes('PUT')) {
      return 'options';
    }
    
    // Futures patterns
    if (tickerUpper.includes('/') || tickerUpper.includes('ES') ||
        tickerUpper.includes('NQ') || tickerUpper.includes('CL')) {
      return 'futures';
    }
  }
  
  // Default to stocks for traditional tickers like AAPL, MSFT, etc.
  return 'stocks';
};

export default function Feed() {
  const [activeMarket, setActiveMarket] = useState("all");
  const [feedType, setFeedType] = useState<"public" | "following" | "trending">("public");
  const [filteredTicker, setFilteredTicker] = useState<string | null>(null);
  const [trendingData, setTrendingData] = useState<any>(null);
  const [publicPosts, setPublicPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch public posts
  const fetchPublicPosts = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('posts-api', {
        method: 'GET'
      });
      
      if (error) {
        console.error('Error fetching public posts:', error);
        setPublicPosts(mockPosts); // Fallback to mock data
      } else {
        setPublicPosts(data.posts || []);
      }
    } catch (err) {
      console.error('Public posts fetch error:', err);
      setPublicPosts(mockPosts); // Fallback to mock data
    } finally {
      setLoading(false);
    }
  };

  // Fetch trending data
  const fetchTrendingData = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('trending');
      if (error) {
        console.error('Error fetching trending data:', error);
        // Use mock data as fallback
        setTrendingData({
          trendingTickers: [
            { ticker: '$BTC', score: 150, post_count: 12, unique_authors: 8, change: 5.2 },
            { ticker: '$ETH', score: 120, post_count: 9, unique_authors: 6, change: 3.1 },
            { ticker: '$AAPL', score: 95, post_count: 8, unique_authors: 5, change: -1.8 },
          ],
          posts: mockPosts.slice(0, 2)
        });
      } else {
        setTrendingData(data);
      }
    } catch (err) {
      console.error('Trending fetch error:', err);
      // Use mock data as fallback
      setTrendingData({
        trendingTickers: [
          { ticker: '$BTC', score: 150, post_count: 12, unique_authors: 8, change: 5.2 },
          { ticker: '$ETH', score: 120, post_count: 9, unique_authors: 6, change: 3.1 },
          { ticker: '$AAPL', score: 95, post_count: 8, unique_authors: 5, change: -1.8 },
        ],
        posts: mockPosts.slice(0, 2)
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch data when feed type changes
  useEffect(() => {
    if (feedType === "public") {
      fetchPublicPosts();
    } else if (feedType === "trending") {
      fetchTrendingData();
    }
  }, [feedType]);

  // Auto-refresh trending data every 5 minutes
  useEffect(() => {
    if (feedType === "trending") {
      const interval = setInterval(fetchTrendingData, 5 * 60 * 1000);
      return () => clearInterval(interval);
    }
  }, [feedType]);

  const handleTickerClick = (ticker: string) => {
    setFilteredTicker(ticker);
    // Navigate to ticker page in future
    console.log('Navigate to ticker:', ticker);
  };

  const getScoreColor = (score: number) => {
    if (score >= 100) return "text-green-500";
    if (score >= 50) return "text-yellow-500";
    return "text-red-500";
  };

  const getPageTitle = () => {
    switch (feedType) {
      case "following":
        return "Following Feed";
      case "trending":
        return "Trending Feed";
      case "public":
        return "Public Feed";
      default:
        return "Live Trading Feed";
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Global Header */}
      <GlobalHeader />
      
      {/* Page Header - Title Only */}
      <PageHeader title={getPageTitle()} />

      {/* Sticky Tabs Section */}
      <div className="sticky top-0 z-40 bg-background border-b border-border">
        <div className="px-4 py-3 space-y-3">
          {/* Market Tabs */}
          <MarketTabs activeMarket={activeMarket} onMarketChange={setActiveMarket} />
          
          {/* Feed Type Toggle */}
          <div className="flex bg-muted/50 rounded-lg p-1 max-w-sm mx-auto">
            <Button
              variant={feedType === "public" ? "secondary" : "ghost"}
              size="sm"
              className="flex-1 gap-2"
              onClick={() => setFeedType("public")}
            >
              <Sparkles className="h-4 w-4" />
              Public
            </Button>
            <Button
              variant={feedType === "following" ? "secondary" : "ghost"}
              size="sm"
              className="flex-1 gap-2"
              onClick={() => setFeedType("following")}
            >
              <Users className="h-4 w-4" />
              Following
            </Button>
            <Button
              variant={feedType === "trending" ? "secondary" : "ghost"}
              size="sm"
              className="flex-1 gap-2"
              onClick={() => setFeedType("trending")}
            >
              <TrendingUp className="h-4 w-4" />
              Trending
            </Button>
          </div>
        </div>
      </div>

      {/* Feed Content */}
      <div className="max-w-2xl mx-auto px-4 space-y-4">
        {/* Live Challenge Banner */}
        <ChallengeBanner />
        {/* Trending Ticker Bar */}
        {feedType === "trending" && trendingData?.trendingTickers && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">Trending Now</span>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {trendingData.trendingTickers.map((ticker: any) => (
                <Badge
                  key={ticker.ticker}
                  variant="outline"
                  className={`cursor-pointer whitespace-nowrap hover:bg-primary/10 border-primary/30 ${getScoreColor(ticker.score)}`}
                  onClick={() => handleTickerClick(ticker.ticker)}
                >
                  {ticker.ticker} {(ticker.change || 0) > 0 ? '+' : ''}{(ticker.change || 0).toFixed(1)}%
                  <span className="ml-1 text-xs opacity-60">({ticker.post_count})</span>
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Filtered Ticker Banner */}
        {filteredTicker && (
          <div className="flex items-center justify-between bg-primary/10 border border-primary/20 rounded-lg p-3">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Showing posts for:</span>
              <Badge variant="outline" className="text-primary border-primary/50 bg-primary/10">
                {filteredTicker}
              </Badge>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setFilteredTicker(null)}
              className="text-xs"
            >
              Clear filter
            </Button>
          </div>
        )}

        {/* Posts */}
        {loading ? (
          <div className="text-center py-8">
            <div className="text-muted-foreground">
              Loading {feedType === "trending" ? "trending" : feedType} posts...
            </div>
          </div>
        ) : (
          (() => {
            let posts = [];
            if (feedType === "trending") {
              posts = trendingData?.posts || [];
            } else if (feedType === "public") {
              posts = publicPosts;
            } else {
              posts = mockPosts;
            }
            
            return posts
              .filter(post => {
                // Filter by active market
                if (activeMarket !== "all") {
                  const postMarket = inferMarket(post);
                  if (postMarket !== activeMarket) {
                    return false;
                  }
                }
                
                if (filteredTicker) {
                  return post.content.tickers.includes(filteredTicker);
                }
                if (feedType === "following") {
                  return post.author.isFollowed;
                }
                return true;
              })
              .map((post) => (
                <div key={post.id} className="animate-slide-up">
                  <TradingPost 
                    id={post.id}
                    author={post.author}
                    content={post.content}
                    engagement={post.engagement}
                    tradeMeta={post.tradeMeta}
                    signalTracking={post.signalTracking}
                    timestamp={post.timestamp}
                    onTickerClick={setFilteredTicker}
                    onFollowToggle={() => console.log('Follow toggled for', post.author.username)}
                    onVote={(type) => console.log('Voted', type, 'on post', post.id)}
                    onSave={() => console.log('Saved post', post.id)}
                    onDiscuss={() => console.log('Discuss post', post.id)}
                  />
                </div>
              ));
          })()
        )}

        {/* Empty State */}
        {!loading && (() => {
          let posts = [];
          if (feedType === "trending") {
            posts = trendingData?.posts || [];
          } else if (feedType === "public") {
            posts = publicPosts;
          } else {
            posts = mockPosts;
          }
          
          return posts.filter(post => {
            // Filter by active market
            if (activeMarket !== "all") {
              const postMarket = inferMarket(post);
              if (postMarket !== activeMarket) {
                return false;
              }
            }
            
            if (filteredTicker) {
              return post.content.tickers.includes(filteredTicker);
            }
            if (feedType === "following") {
              return post.author.isFollowed;
            }
            return true;
          }).length === 0;
        })() && (
          <div className="text-center py-12 space-y-4">
            <div className="text-muted-foreground">
              {filteredTicker 
                ? `No posts found for ${filteredTicker}`
                : feedType === "following" 
                ? "No posts from followed traders"
                : feedType === "trending"
                ? "No trending posts available"
                : feedType === "public"
                ? "No public posts yet — create the first one!"
                : "No posts yet — follow tickers or create your first post"
              }
            </div>
            {!filteredTicker && feedType !== "trending" && (
              <Button variant="outline" size="sm" onClick={() => setFeedType("public")}>
                Explore Public feed
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}