import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, Award, CheckCircle, Clock, X, Loader2, AlertCircle } from "lucide-react";
import { useProfile } from "@/hooks/useProfile";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { VerificationForm } from "@/components/verify/VerificationForm";
import { useVerificationRequests } from "@/hooks/useVerificationRequests";

type VerificationStatus = "unverified" | "manual" | "broker" | "pending";

const getStatusConfig = (status: VerificationStatus) => {
  switch (status) {
    case "broker":
      return {
        icon: <CheckCircle className="h-5 w-5 text-profit" />,
        label: "Broker Verified",
        description: "Your trading history has been verified through broker connection",
        badgeVariant: "default" as const,
        badgeClass: "bg-profit text-profit-foreground",
      };
    case "manual":
      return {
        icon: <CheckCircle className="h-5 w-5 text-primary" />,
        label: "Manually Verified",
        description: "Your verification has been approved by our team",
        badgeVariant: "default" as const,
        badgeClass: "bg-primary text-primary-foreground",
      };
    case "pending":
      return {
        icon: <Clock className="h-5 w-5 text-warning" />,
        label: "Verification Pending",
        description: "Your verification request is being reviewed",
        badgeVariant: "outline" as const,
        badgeClass: "border-warning text-warning",
      };
    default:
      return {
        icon: <X className="h-5 w-5 text-muted-foreground" />,
        label: "Unverified",
        description: "No verification submitted yet",
        badgeVariant: "outline" as const,
        badgeClass: "",
      };
  }
};

export default function VerifyPage() {
  const { profile, loading: profileLoading, refetch } = useProfile();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [showVerificationForm, setShowVerificationForm] = useState(false);
  const { getLatestRequest, loading: requestsLoading } = useVerificationRequests();

  const verificationStatus = (profile?.verified_status || "unverified") as VerificationStatus;
  const statusConfig = getStatusConfig(verificationStatus);
  const isVerified = verificationStatus === "broker" || verificationStatus === "manual";
  const isPending = verificationStatus === "pending";
  const latestRequest = getLatestRequest();

  const handleApplyClick = () => {
    if (!user) {
      toast({
        title: "Sign in required",
        description: "Please sign in to apply for verification",
        variant: "destructive",
      });
      navigate("/auth/signin");
      return;
    }

    setShowVerificationForm(true);
  };

  const handleVerificationSuccess = async () => {
    await refetch();
  };

  const isLoading = profileLoading || authLoading || requestsLoading;

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-2xl font-bold text-foreground">Verification</h1>
          <Badge variant="outline" className="text-xs">
            Build Credibility
          </Badge>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Overview */}
        <Card className="bg-gradient-card border-border shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Trader Verification
            </CardTitle>
            <CardDescription>
              Increase your credibility and reputation by verifying your trading experience
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Verification Methods */}
        <div className="space-y-4">
          {/* Broker Verification */}
          <Card className="bg-gradient-card border-border shadow-card">
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Shield className="h-5 w-5 text-profit" />
                    <h3 className="font-semibold text-foreground">Broker Verification</h3>
                    <Badge className="bg-profit text-profit-foreground">Highest Tier</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Connect your broker account to verify your trading history and performance
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <Badge variant="outline" className="text-xs">
                      Interactive Brokers
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      TD Ameritrade
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Binance
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Coinbase Pro
                    </Badge>
                  </div>
                </div>
                <Button className="shrink-0" disabled>
                  Coming Soon
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Manual Verification */}
          <Card className="bg-gradient-card border-border shadow-card">
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Award className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold text-foreground">Manual Verification</h3>
                    <Badge variant="secondary">Standard</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Submit a verification request for manual review by our team
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Review time: 2-5 business days
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  className="shrink-0"
                  onClick={handleApplyClick}
                  disabled={isVerified || isPending || isLoading}
                >
                  {isVerified ? (
                    "Verified"
                  ) : isPending ? (
                    "Pending Review"
                  ) : (
                    "Apply Now"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Current Status */}
        <Card className="bg-gradient-card border-border shadow-card">
          <CardHeader>
            <CardTitle className="text-lg">Your Verification Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              <div className="flex items-center justify-center p-4">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  {statusConfig.icon}
                  <div>
                    <p className="font-medium text-foreground">{statusConfig.label}</p>
                    <p className="text-sm text-muted-foreground">{statusConfig.description}</p>
                  </div>
                </div>
                <Badge variant={statusConfig.badgeVariant} className={statusConfig.badgeClass}>
                  {statusConfig.label}
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rejection Reason (if rejected) */}
        {latestRequest?.status === "rejected" && latestRequest.rejection_reason && (
          <Card className="bg-gradient-card border-loss/50 shadow-card">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-loss shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-foreground">Previous Request Rejected</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {latestRequest.rejection_reason}
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    You can submit a new verification request with updated proof.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Benefits */}
        <Card className="bg-gradient-card border-border shadow-card">
          <CardHeader>
            <CardTitle className="text-lg">Verification Benefits</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-4 w-4 text-profit" />
              <span className="text-sm">Verified badge on your profile</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-4 w-4 text-profit" />
              <span className="text-sm">Higher ranking in leaderboards</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-4 w-4 text-profit" />
              <span className="text-sm">Increased post visibility</span>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-4 w-4 text-profit" />
              <span className="text-sm">Access to exclusive features</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Verification Form Modal */}
      <VerificationForm
        open={showVerificationForm}
        onOpenChange={setShowVerificationForm}
        onSuccess={handleVerificationSuccess}
      />
    </div>
  );
}
