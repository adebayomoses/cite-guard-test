import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { TradingPost } from "@/components/TradingPost";
import { GlobalHeader } from "@/components/GlobalHeader";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useComments } from "@/hooks/useComments";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState("");
  
  const { comments, loading: commentsLoading, submitting, addComment } = useComments(id || "");

  useEffect(() => {
    if (id) {
      fetchPost();
    }
  }, [id]);

  const fetchPost = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('posts-api', {
        method: 'GET'
      });
      
      if (error) throw error;
      
      // Find the specific post by ID from all posts
      if (data.posts && data.posts.length > 0) {
        const foundPost = data.posts.find((p: any) => p.id === id);
        setPost(foundPost || null);
      } else {
        setPost(null);
      }
    } catch (err) {
      console.error('Error fetching post:', err);
      toast({
        title: "Error loading post",
        description: "Failed to load post details. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const success = await addComment(newComment);
    if (success) {
      setNewComment("");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="flex items-center justify-center h-[calc(100vh-64px)]">
          <div className="text-muted-foreground">Loading post...</div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="max-w-2xl mx-auto px-4 py-8">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div className="text-center py-12">
            <h2 className="text-xl font-semibold mb-2">Post not found</h2>
            <p className="text-muted-foreground">This post may have been deleted or doesn't exist.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      <GlobalHeader />
      
      <div className="max-w-2xl mx-auto px-4 py-4">
        {/* Back Button */}
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        {/* Post Card */}
        <div className="mb-6">
          <TradingPost 
            id={post.id}
            author={post.author}
            content={post.content}
            engagement={post.engagement}
            tradeMeta={post.tradeMeta}
            signalTracking={post.signalTracking}
            timestamp={post.timestamp}
            onTickerClick={(ticker) => console.log('Ticker clicked:', ticker)}
            onFollowToggle={() => console.log('Follow toggled')}
            onVote={(type) => console.log('Voted', type)}
            onSave={() => console.log('Saved')}
            onDiscuss={() => {}} // Don't open drawer on detail page
            hideDiscussButton={true} // Hide the discuss button on detail page
          />
        </div>

        {/* Comments Section */}
        <div className="bg-card rounded-lg border border-border p-4 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-border">
            <MessageCircle className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">
              Discussion ({comments.length})
            </h2>
          </div>

          {/* Comment Form */}
          <form onSubmit={handleSubmitComment} className="space-y-3">
            <Textarea
              placeholder="Share your thoughts..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="min-h-[100px] resize-none"
              disabled={submitting}
            />
            <div className="flex justify-end">
              <Button 
                type="submit" 
                disabled={submitting || !newComment.trim()}
                size="sm"
              >
                {submitting ? "Posting..." : "Post Comment"}
              </Button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-4 pt-2">
            {commentsLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading comments...
              </div>
            ) : comments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No comments yet. Be the first to share your thoughts!
              </div>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="flex gap-3 pb-4 border-b border-border last:border-0">
                  <Avatar className="h-8 w-8 mt-1">
                    <AvatarImage src={comment.author?.avatar} />
                    <AvatarFallback>
                      {comment.author?.username?.[0]?.toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">
                        @{comment.author?.username || "anonymous"}
                      </span>
                      {comment.author?.verified && (
                        <Badge variant="secondary" className="h-4 px-1.5 text-[10px]">
                          ✓
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm text-foreground whitespace-pre-wrap">
                      {comment.text}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
