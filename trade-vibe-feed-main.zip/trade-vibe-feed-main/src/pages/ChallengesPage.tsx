import { useState, useEffect } from "react";
import { GlobalHeader } from "@/components/GlobalHeader";
import { PageHeader } from "@/components/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, Users, Clock, Calendar, ExternalLink, Star, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Link } from "react-router-dom";
import { useCanCreatePremiumContent } from "@/hooks/useCanCreatePremiumContent";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface Challenge {
  id: string;
  title: string;
  description: string;
  scope: string;
  metric: string;
  start_at: string;
  end_at: string;
  status: string;
  entry_count: number;
  isParticipating: boolean;
  created_by_profile: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}


export default function ChallengesPage() {
  const [activeTab, setActiveTab] = useState("live");
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const { session } = useAuth();
  const { toast } = useToast();
  const { canCreate, currentXP, proRankThreshold, currentRank } = useCanCreatePremiumContent();

  const fetchChallenges = async (status?: string) => {
    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
      }

      const url = new URL(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/challenges-api/list`);
      if (status && status !== 'all') {
        url.searchParams.set('status', status);
      }

      const response = await fetch(url.toString(), { headers });
      if (!response.ok) throw new Error('Failed to fetch challenges');
      
      const data = await response.json();
      setChallenges(data.challenges || []);
    } catch (error) {
      console.error('Error fetching challenges:', error);
      toast({
        title: "Error",
        description: "Failed to load challenges",
        variant: "destructive",
      });
    }
  };


  const handleJoinChallenge = async (challengeId: string) => {
    if (!session) {
      toast({
        title: "Authentication required",
        description: "Please sign in to join challenges",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/challenges-api/${challengeId}/join`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (!response.ok) throw new Error('Failed to join challenge');
      
      const data = await response.json();
      toast({
        title: data.joined ? "Joined challenge!" : "Left challenge",
        description: data.joined ? "You're now participating in this challenge" : "You've left this challenge",
      });

      // Refresh challenges
      await fetchChallenges(activeTab === 'all' ? undefined : activeTab);
    } catch (error) {
      console.error('Error joining challenge:', error);
      toast({
        title: "Error",
        description: "Failed to join challenge",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchChallenges(activeTab === 'all' ? undefined : activeTab);
      setLoading(false);
    };

    loadData();
  }, [activeTab, session]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-500';
      case 'upcoming': return 'bg-blue-500';
      case 'ended': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getScopeIcon = (scope: string) => {
    switch (scope) {
      case 'stocks': return '📈';
      case 'crypto': return '₿';
      case 'forex': return '💱';
      case 'options': return '📊';
      case 'futures': return '⏳';
      default: return '🌐';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <PageHeader title="Challenges" />
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">Loading challenges...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      <PageHeader title="Trade Challenges" subtitle="Compete with fellow traders and improve your skills" />

      {/* Create Challenge Button */}
      {session && (
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex justify-end">
            {canCreate ? (
              <Link to="/create-challenge">
                <Button className="gap-2">
                  <Trophy className="h-4 w-4" />
                  Create Challenge
                </Button>
              </Link>
            ) : (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button disabled className="gap-2">
                      <Lock className="h-4 w-4" />
                      Create Challenge
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="font-medium">Pro Trader rank required</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {currentRank?.icon} {currentRank?.name} • {currentXP}/{proRankThreshold} XP
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="live">Live</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="ended">Ended</TabsTrigger>
            <TabsTrigger value="all">All</TabsTrigger>
          </TabsList>

          <div className="mt-6">
            {/* Main Content */}
            <TabsContent value={activeTab} className="space-y-4">
                {challenges.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center py-12">
                        <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">No challenges found</h3>
                        <p className="text-muted-foreground">
                          {activeTab === 'live' ? 'No live challenges at the moment' :
                           activeTab === 'upcoming' ? 'No upcoming challenges scheduled' :
                           activeTab === 'ended' ? 'No ended challenges to show' :
                           'No challenges available'}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  challenges.map((challenge) => (
                    <Card key={challenge.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="text-2xl">{getScopeIcon(challenge.scope)}</span>
                              <CardTitle className="text-xl">{challenge.title}</CardTitle>
                              <Badge className={`text-white ${getStatusColor(challenge.status)}`}>
                                {challenge.status}
                              </Badge>
                            </div>
                            <CardDescription>{challenge.description}</CardDescription>
                          </div>
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={challenge.created_by_profile?.avatar_url} />
                            <AvatarFallback>
                              {challenge.created_by_profile?.display_name?.charAt(0) || '?'}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>Starts: {formatDate(challenge.start_at)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>Ends: {formatDate(challenge.end_at)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{challenge.entry_count} participants</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Star className="h-4 w-4 text-muted-foreground" />
                            <span>Metric: {challenge.metric.replace('_', ' ')}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <Link to={`/challenges/${challenge.id}`}>
                          <Button variant="outline">View Details</Button>
                        </Link>
                        {challenge.status !== 'ended' && (
                          <Button 
                            onClick={() => handleJoinChallenge(challenge.id)}
                            variant={challenge.isParticipating ? "secondary" : "default"}
                          >
                            {challenge.isParticipating ? "Leave Challenge" : "Join Challenge"}
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  ))
                )}
              </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}