import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useServers, ServerDetails } from '@/hooks/useServers';
import { PageHeader } from '@/components/PageHeader';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Hash, Settings, Users, ArrowLeft } from 'lucide-react';
import { ServerSettings } from '@/components/chat/ServerSettings';

const ServerDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getServerDetails } = useServers();
  const [server, setServer] = useState<ServerDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    const loadServerDetails = async () => {
      if (!id) return;
      
      setLoading(true);
      const data = await getServerDetails(id);
      setServer(data);
      setLoading(false);
    };

    loadServerDetails();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader title="Loading..." />
        <div className="container mx-auto px-4 py-6 space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!server) {
    return (
      <div className="min-h-screen bg-background">
        <PageHeader title="Server Not Found" />
        <div className="container mx-auto px-4 py-6">
          <Card className="p-6 text-center">
            <p className="text-muted-foreground">Server not found</p>
            <Button onClick={() => navigate('/servers')} className="mt-4">
              Back to Servers
            </Button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <PageHeader title={server.groupInfo.name}>
        <Button variant="ghost" size="sm" onClick={() => navigate('/servers')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
      </PageHeader>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Server Info Card */}
        <Card className="p-6">
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={server.groupInfo.avatar_url} />
              <AvatarFallback>{server.groupInfo.name[0]?.toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-bold">{server.groupInfo.name}</h2>
              {server.groupInfo.description && (
                <p className="text-muted-foreground mt-1">{server.groupInfo.description}</p>
              )}
              <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>{server.memberCount} members</span>
                </div>
                <div className="flex items-center gap-1">
                  <Hash className="h-4 w-4" />
                  <span>{server.channels?.length || 0} channels</span>
                </div>
              </div>
            </div>
            {server.userRole === 'admin' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowSettings(true)}
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            )}
          </div>
        </Card>

        {/* Channels List */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Channels</h3>
          <div className="space-y-2">
            {server.channels && server.channels.length > 0 ? (
              server.channels
                .sort((a, b) => a.order - b.order)
                .map((channel) => (
                  <Card
                    key={channel.id}
                    className="p-4 cursor-pointer hover:bg-accent transition-colors"
                    onClick={() => navigate(`/chat/${channel.id}`)}
                  >
                    <div className="flex items-center gap-3">
                      <Hash className="h-5 w-5 text-muted-foreground" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{channel.name}</span>
                          {channel.isDefault && (
                            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">
                              Default
                            </span>
                          )}
                        </div>
                        {channel.description && (
                          <p className="text-sm text-muted-foreground mt-1">
                            {channel.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))
            ) : (
              <Card className="p-6 text-center">
                <p className="text-muted-foreground">No channels found</p>
              </Card>
            )}
          </div>
        </div>

        {/* Server Settings Modal */}
        {server && server.userRole === 'admin' && (
          <ServerSettings
            serverId={id!}
            serverInfo={server.groupInfo}
            channels={server.channels || []}
            open={showSettings}
            onOpenChange={setShowSettings}
            onUpdate={async () => {
              const data = await getServerDetails(id!);
              setServer(data);
            }}
          />
        )}
      </div>
    </div>
  );
};

export default ServerDetailPage;
