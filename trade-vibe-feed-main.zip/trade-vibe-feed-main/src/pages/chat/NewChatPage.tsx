import React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { NewChat } from '@/components/chat/NewChat';

const NewChatPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <PageHeader title="New Chat" />
      
      <div className="container mx-auto px-4 py-6">
        <NewChat />
      </div>
    </div>
  );
};

export default NewChatPage;