import React from 'react';
import { ChatThread } from '@/components/chat/ChatThread';

const ChatThreadPage = () => {
  return (
    <div className="h-full bg-background">
      <div className="h-full max-w-4xl mx-auto">
        <ChatThread />
      </div>
    </div>
  );
};

export default ChatThreadPage;