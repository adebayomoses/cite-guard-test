import React, { useEffect, useState } from 'react';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Plus, Users, Hash } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useServers, type Server } from '@/hooks/useServers';
import { Skeleton } from '@/components/ui/skeleton';
import { CreateServer } from '@/components/chat/CreateServer';

const ServerListPage = () => {
  const navigate = useNavigate();
  const [servers, setServers] = useState<Server[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const { loadServers } = useServers();

  useEffect(() => {
    const fetchServers = async () => {
      setLoading(true);
      const data = await loadServers();
      
      // Log the data to verify channelCount is present
      console.log('Loaded servers:', data.map(s => ({ 
        id: s.id, 
        name: s.groupInfo.name, 
        channelCount: s.channelCount 
      })));
      
      setServers(data);
      setLoading(false);
    };

    fetchServers();
  }, []);

  const handleServerCreated = async () => {
    const data = await loadServers();
    setServers(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <PageHeader title="Branch Servers">
        <Button onClick={() => setShowCreate(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Server
        </Button>
      </PageHeader>

      <div className="container mx-auto px-4 py-6">
        {loading ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <div className="p-4 flex items-center gap-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-48 mb-2" />
                    <Skeleton className="h-4 w-64" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : servers.length === 0 ? (
          <div className="text-center py-12">
            <Hash className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No servers yet</h3>
            <p className="text-muted-foreground mb-4">
              Create your first server to start chatting with channels
            </p>
            <Button onClick={() => setShowCreate(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Server
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            {servers.map((server) => (
              <Card
                key={server.id}
                className="cursor-pointer hover:bg-accent/50 transition-colors"
                onClick={() => navigate(`/servers/${server.id}`)}
              >
                <div className="p-4 flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={server.groupInfo.avatar_url} />
                    <AvatarFallback>
                      {server.groupInfo.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="font-semibold truncate">{server.groupInfo.name}</h3>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground shrink-0">
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {server.memberCount}
                        </div>
                        <div className="flex items-center gap-1">
                          <Hash className="h-4 w-4" />
                          {server.channelCount || 0}
                        </div>
                        {server.unreadCount > 0 && (
                          <span className="inline-flex items-center justify-center h-5 px-2 text-xs font-medium rounded-full bg-primary text-primary-foreground">
                            {server.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                    {server.groupInfo.description && (
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {server.groupInfo.description}
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <CreateServer 
        open={showCreate} 
        onOpenChange={setShowCreate}
        onServerCreated={handleServerCreated}
      />
    </div>
  );
};

export default ServerListPage;
