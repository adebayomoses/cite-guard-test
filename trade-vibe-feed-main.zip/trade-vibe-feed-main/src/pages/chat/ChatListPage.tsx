import React from 'react';
import { PageHeader } from '@/components/PageHeader';
import { ChatsList } from '@/components/chat/ChatsList';

const ChatListPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <PageHeader title="Messages" />
      
      <div className="container mx-auto px-4 py-6">
        <ChatsList />
      </div>
    </div>
  );
};

export default ChatListPage;