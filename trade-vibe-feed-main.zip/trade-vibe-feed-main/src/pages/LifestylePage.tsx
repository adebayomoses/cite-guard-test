import React, { useState, useEffect } from 'react';
import { GlobalHeader } from '@/components/GlobalHeader';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Users, Sparkles, Plus } from 'lucide-react';
import { VerticalSwiper } from '@/components/lifestyle/VerticalSwiper';
import { useLifestyleFeed } from '@/hooks/useLifestyle';
import { useNavigate } from 'react-router-dom';
import { LifestyleVideo } from '@/types/lifestyle';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';

export default function LifestylePage() {
  const [feedMode, setFeedMode] = useState<'forYou' | 'following'>('forYou');
  const navigate = useNavigate();
  const { flags } = useFeatureFlags();
  
  const { 
    videos, 
    loading, 
    error, 
    hasMore, 
    loadMore, 
    setVideos 
  } = useLifestyleFeed(feedMode);

  // Redirect if lifestyle is disabled
  useEffect(() => {
    if (flags.lifestyle_enabled === false) {
      navigate('/');
    }
  }, [flags.lifestyle_enabled, navigate]);

  const handleVideoUpdate = (videoId: string, updates: Partial<LifestyleVideo>) => {
    setVideos(prev => 
      prev.map(video => 
        video.id === videoId 
          ? { ...video, ...updates }
          : video
      )
    );
  };

  if (loading && videos.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="flex items-center justify-center h-[calc(100vh-3.5rem)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading lifestyle videos...</p>
          </div>
        </div>
      </div>
    );
  }

  // Handle auth errors as empty state instead of error
  if (error && !error.includes('Unauthorized') && !error.includes('401')) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="flex items-center justify-center h-[calc(100vh-3.5rem)]">
          <div className="text-center">
            <p className="text-red-500 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <GlobalHeader />
      
      {videos.length === 0 ? (
        <>
          <PageHeader title="Lifestyle">
            {/* Feed Mode Toggle */}
            <div className="flex bg-muted/50 rounded-lg p-1 max-w-sm mx-auto">
              <Button
                variant={feedMode === 'forYou' ? 'secondary' : 'ghost'}
                size="sm"
                className="flex-1 gap-2"
                onClick={() => setFeedMode('forYou')}
              >
                <Sparkles className="h-4 w-4" />
                For You
              </Button>
              <Button
                variant={feedMode === 'following' ? 'secondary' : 'ghost'}
                size="sm"
                className="flex-1 gap-2"
                onClick={() => setFeedMode('following')}
              >
                <Users className="h-4 w-4" />
                Following
              </Button>
            </div>
          </PageHeader>
          
          <div className="flex items-center justify-center h-[calc(100vh-8rem)]">
            <div className="text-center space-y-4">
              <p className="text-muted-foreground">
                {feedMode === 'following' 
                  ? "No videos from people you follow yet"
                  : "No lifestyle videos available"
                }
              </p>
              <Button onClick={() => navigate('/lifestyle/upload')}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Video
              </Button>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Feed Mode Toggle - Floating */}
          <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-40">
            <div className="flex bg-black/50 backdrop-blur-sm rounded-lg p-1">
              <Button
                variant={feedMode === 'forYou' ? 'secondary' : 'ghost'}
                size="sm"
                className="gap-2 text-white"
                onClick={() => setFeedMode('forYou')}
              >
                <Sparkles className="h-4 w-4" />
                For You
              </Button>
              <Button
                variant={feedMode === 'following' ? 'secondary' : 'ghost'}
                size="sm"
                className="gap-2 text-white"
                onClick={() => setFeedMode('following')}
              >
                <Users className="h-4 w-4" />
                Following
              </Button>
            </div>
          </div>

          {/* Upload Button - Floating */}
          <Button
            className="fixed bottom-20 left-1/2 transform -translate-x-1/2 z-40 w-14 h-14 rounded-full shadow-lg"
            onClick={() => navigate('/lifestyle/upload')}
          >
            <Plus className="h-6 w-6" />
          </Button>

          {/* Video Swiper */}
          <div className="fixed inset-0 top-14 bottom-16 bg-black">
            <div className="h-full w-full flex items-center justify-center">
              <div className="relative h-full w-full max-w-sm sm:max-w-md lg:max-w-lg mx-auto">
                <VerticalSwiper
                  videos={videos}
                  onVideoUpdate={handleVideoUpdate}
                  onLoadMore={loadMore}
                  hasMore={hasMore}
                />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}