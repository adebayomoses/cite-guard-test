import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useChallenges } from '@/hooks/useChallenges';
import { Crown, Medal, Award, ArrowLeft, Users, Calendar, Target, Info, MessageSquare, Radio, Send, Shield } from 'lucide-react';
import { GlobalHeader } from '@/components/GlobalHeader';
import { SignalForm } from '@/components/SignalForm';
import { ImageModal } from '@/components/ImageModal';

interface Challenge {
  id: string;
  title: string;
  description: string;
  scope: string;
  metric: string;
  start_at: string;
  end_at: string;
  status: string;
  entry_count: number;
  isParticipating: boolean;
  risk_management?: string;
  created_by: string;
  created_by_profile: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

interface LeaderboardEntry {
  user_id: string;
  rank: number;
  score: number;
  handle: string;
  display_name: string;
  avatar_url: string;
  verified_status: string;
}

interface ChallengeSignal {
  id: string;
  challenge_id: string;
  author_id: string;
  content: string;
  image_url?: string;
  market_type: string;
  trade_direction: string;
  risk_level: string;
  timeframe?: string;
  entry_price?: number;
  stop_loss?: number;
  target_price?: number;
  created_at: string;
  profiles: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

interface ChallengeDiscussion {
  id: string;
  challenge_id: string;
  author_id: string;
  content: string;
  created_at: string;
  profiles: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

const ChallengeDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { session } = useAuth();
  const { toast } = useToast();
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [signals, setSignals] = useState<ChallengeSignal[]>([]);
  const [discussions, setDiscussions] = useState<ChallengeDiscussion[]>([]);
  const [loading, setLoading] = useState(true);
  const [discussionContent, setDiscussionContent] = useState('');
  const [isPosting, setIsPosting] = useState(false);

  const { 
    fetchChallengeDetails, 
    fetchChallengeSignals, 
    fetchChallengeDiscussions,
    joinChallenge,
    createSignal,
    createDiscussion
  } = useChallenges();

  const loadChallengeData = async () => {
    if (!id) return;
    
    try {
      const [challengeData, signalsData, discussionsData] = await Promise.all([
        fetchChallengeDetails(id),
        fetchChallengeSignals(id),
        fetchChallengeDiscussions(id)
      ]);

      if (challengeData) {
        setChallenge(challengeData.challenge);
        setLeaderboard(challengeData.leaderboard);
      }
      
      setSignals(signalsData);
      setDiscussions(discussionsData);
    } catch (error) {
      console.error('Error loading challenge data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinChallenge = async () => {
    if (!session || !challenge) return;

    const result = await joinChallenge(challenge.id);
    if (result !== false) {
      setChallenge(prev => prev ? { ...prev, isParticipating: result } : null);
    }
  };

  const handlePostSignal = async (signalData: any) => {
    if (!id) return;
    
    setIsPosting(true);
    const result = await createSignal(id, signalData);
    if (result) {
      setSignals(prev => [result, ...prev]);
    }
    setIsPosting(false);
  };

  const handlePostDiscussion = async () => {
    if (!id || !discussionContent.trim()) return;
    
    setIsPosting(true);
    const result = await createDiscussion(id, discussionContent.trim());
    if (result) {
      setDiscussionContent('');
      setDiscussions(prev => [result, ...prev]);
    }
    setIsPosting(false);
  };

  useEffect(() => {
    loadChallengeData();

    // Auto-refresh for live challenges
    const interval = setInterval(() => {
      if (challenge?.status === 'live') {
        loadChallengeData();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [id, challenge?.status]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live': return 'bg-green-500';
      case 'upcoming': return 'bg-blue-500';
      case 'ended': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-5 w-5 text-yellow-500" />;
      case 2: return <Medal className="h-5 w-5 text-gray-400" />;
      case 3: return <Award className="h-5 w-5 text-orange-500" />;
      default: return <span className="text-muted-foreground">#{rank}</span>;
    }
  };

  const getMetricDescription = (metric: string) => {
    switch (metric) {
      case 'useful_rate':
        return 'Percentage of posts marked as useful during the challenge period';
      case 'net_votes':
        return 'Total net score (useful votes minus not useful votes) on posts';
      case 'pnl_self_report':
        return 'Self-reported profit and loss performance';
      case 'consistency':
        return 'Weighted combination of useful rate (60%) and posts with charts (40%)';
      default:
        return 'Custom scoring metric for this challenge';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">Loading challenge details...</div>
        </div>
      </div>
    );
  }

  if (!challenge) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Challenge not found</h1>
            <Button onClick={() => navigate('/challenges')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Challenges
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <GlobalHeader />
      
      <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Back Button */}
        <Button variant="ghost" onClick={() => navigate('/challenges')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Challenges
        </Button>

        {/* Challenge Header */}
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-4 flex-1">
                <div className="flex items-center gap-3">
                  <h1 className="text-3xl font-bold">{challenge.title}</h1>
                  <Badge className={`text-white ${getStatusColor(challenge.status)}`}>
                    {challenge.status}
                  </Badge>
                </div>
                
                <p className="text-lg text-muted-foreground">{challenge.description}</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Starts: {formatDate(challenge.start_at)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Ends: {formatDate(challenge.end_at)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{challenge.entry_count} participants</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-muted-foreground" />
                    <span>Scope: {challenge.scope}</span>
                  </div>
                </div>
              </div>
              
              {challenge.status !== 'ended' && (
                <Button 
                  onClick={handleJoinChallenge}
                  size="lg"
                  variant={challenge.isParticipating ? "secondary" : "default"}
                >
                  {challenge.isParticipating ? "Leave Challenge" : "Join Challenge"}
                </Button>
              )}
            </div>
          </CardHeader>
        </Card>

        {/* Risk Management Section */}
        {challenge.risk_management && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Risk Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p className="whitespace-pre-wrap">{challenge.risk_management}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Challenge Rooms */}
        <Card>
          <CardHeader>
            <CardTitle>Challenge Rooms</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signals" className="space-y-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="signals" className="flex items-center gap-2">
                  <Radio className="h-4 w-4" />
                  Signals
                </TabsTrigger>
                <TabsTrigger value="discussions" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Discussion
                </TabsTrigger>
                <TabsTrigger value="leaderboard" className="flex items-center gap-2">
                  <Target className="h-4 w-4" />
                  Leaderboard
                </TabsTrigger>
              </TabsList>

              <TabsContent value="signals" className="space-y-4">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">
                    <Radio className="h-4 w-4 inline mr-2" />
                    Only the challenge creator can post signals in this room
                  </p>
                </div>
                
                {session && session.user?.id === challenge.created_by && (
                  <SignalForm onSubmit={handlePostSignal} isLoading={isPosting} />
                )}

                <div className="space-y-3">
                  {(signals ?? []).map((signal) => (
                    <Card key={signal.id} className="border bg-card">
                      <CardContent className="pt-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={signal.profiles.avatar_url} />
                            <AvatarFallback>
                              {signal.profiles.display_name?.charAt(0) || signal.profiles.handle?.charAt(0) || '?'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-3">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium text-foreground">
                                {signal.profiles.display_name || signal.profiles.handle}
                              </span>
                              <Badge variant="secondary" className="text-xs">Creator</Badge>
                              <span className="text-xs text-muted-foreground">
                                {formatDate(signal.created_at)}
                              </span>
                            </div>

                            {/* Signal Content */}
                            <div className="bg-muted/50 p-3 rounded-lg border">
                              <p className="text-sm text-foreground whitespace-pre-wrap font-medium">
                                {signal.content}
                              </p>
                            </div>

                            {/* Trading Details */}
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className="bg-background">
                                {signal.market_type === 'stocks' && '📈 Stocks'}
                                {signal.market_type === 'crypto' && '₿ Crypto'}
                                {signal.market_type === 'forex' && '💱 Forex'}
                                {signal.market_type === 'options' && '⚡ Options'}
                                {signal.market_type === 'futures' && '📊 Futures'}
                              </Badge>
                              <Badge variant={signal.trade_direction === 'long' ? 'default' : 'destructive'}>
                                {signal.trade_direction === 'long' ? '↗ Long' : '↘ Short'}
                              </Badge>
                              <Badge variant="secondary">
                                {signal.risk_level === 'low_risk' && '🟢 Low Risk'}
                                {signal.risk_level === 'medium_risk' && '🟡 Medium Risk'}
                                {signal.risk_level === 'high_risk' && '🔴 High Risk'}
                              </Badge>
                              {signal.timeframe && <Badge variant="outline">⏱ {signal.timeframe}</Badge>}
                            </div>

                            {/* Chart Image */}
                            {signal.image_url && (
                              <ImageModal 
                                src={signal.image_url} 
                                alt="Trading chart" 
                                className="w-full max-w-sm"
                              />
                            )}

                            {/* Price Levels - Show structure even if empty */}
                            {(signal.entry_price || signal.stop_loss || signal.target_price) ? (
                              <div className="grid grid-cols-3 gap-2 text-xs">
                                {signal.entry_price && (
                                  <div className="bg-blue-100 dark:bg-blue-900 border border-blue-200 dark:border-blue-700 p-3 rounded">
                                    <div className="text-blue-700 dark:text-blue-300 font-medium mb-1">Entry</div>
                                    <div className="text-blue-900 dark:text-blue-100 font-bold text-sm">
                                      ${signal.entry_price.toFixed(4)}
                                    </div>
                                  </div>
                                )}
                                {signal.stop_loss && (
                                  <div className="bg-red-100 dark:bg-red-900 border border-red-200 dark:border-red-700 p-3 rounded">
                                    <div className="text-red-700 dark:text-red-300 font-medium mb-1">Stop Loss</div>
                                    <div className="text-red-900 dark:text-red-100 font-bold text-sm">
                                      ${signal.stop_loss.toFixed(4)}
                                    </div>
                                  </div>
                                )}
                                {signal.target_price && (
                                  <div className="bg-green-100 dark:bg-green-900 border border-green-200 dark:border-green-700 p-3 rounded">
                                    <div className="text-green-700 dark:text-green-300 font-medium mb-1">Target</div>
                                    <div className="text-green-900 dark:text-green-100 font-bold text-sm">
                                      ${signal.target_price.toFixed(4)}
                                    </div>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="text-xs text-muted-foreground italic border border-dashed border-muted p-3 rounded text-center">
                                No price levels specified
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {signals.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No signals posted yet
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="discussions" className="space-y-4">
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">
                    <MessageSquare className="h-4 w-4 inline mr-2" />
                    Only challenge participants can post in this discussion room
                  </p>
                </div>

                {session && challenge.isParticipating && (
                  <div className="space-y-2">
                    <Textarea
                      placeholder="Join the discussion..."
                      value={discussionContent}
                      onChange={(e) => setDiscussionContent(e.target.value)}
                      className="min-h-20"
                    />
                    <Button 
                      onClick={handlePostDiscussion}
                      disabled={!discussionContent.trim() || isPosting}
                      className="w-full"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Post Discussion
                    </Button>
                  </div>
                )}

                <div className="space-y-3">
                  {(discussions ?? []).map((discussion) => (
                    <Card key={discussion.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={discussion.profiles.avatar_url} />
                            <AvatarFallback>
                              {discussion.profiles.display_name?.charAt(0) || discussion.profiles.handle?.charAt(0) || '?'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">
                                {discussion.profiles.display_name || discussion.profiles.handle}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {formatDate(discussion.created_at)}
                              </span>
                            </div>
                            <p className="text-sm whitespace-pre-wrap">{discussion.content}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {discussions.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No discussions yet
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="leaderboard" className="space-y-4">
                {leaderboard.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Rank</TableHead>
                        <TableHead>Trader</TableHead>
                        <TableHead>Score</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(leaderboard ?? []).map((entry) => (
                        <TableRow key={entry.user_id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {getRankIcon(entry.rank)}
                              {entry.rank > 3 && entry.rank}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={entry.avatar_url} />
                                <AvatarFallback>
                                  {entry.display_name?.charAt(0) || entry.handle?.charAt(0) || '?'}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">
                                  {entry.display_name || entry.handle}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  @{entry.handle}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">
                              {entry.score?.toFixed(1) ?? '0.0'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No participants yet
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Scoring Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Scoring Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-2">Metric: {challenge.metric.replace('_', ' ')}</h4>
                <p className="text-sm text-muted-foreground">
                  {getMetricDescription(challenge.metric)}
                </p>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Scope: {challenge.scope}</h4>
                <p className="text-sm text-muted-foreground">
                  {challenge.scope === 'all' 
                    ? 'All trading instruments and markets are included'
                    : `Only ${challenge.scope} trades count toward your score`
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ChallengeDetail;