import { useState } from "react";
import { Search as SearchIcon, X } from "lucide-react";
import { GlobalHeader } from "@/components/GlobalHeader";
import { PageHeader } from "@/components/PageHeader";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const popularTickers = ["$BTC", "$ETH", "$AAPL", "$TSLA", "$SPY", "$NVDA"];
  const trendingTopics = ["Options", "Swing Trading", "Day Trading", "Technical Analysis"];

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // TODO: Implement actual search functionality
    console.log("Searching for:", query);
  };

  const clearSearch = () => {
    setSearchQuery("");
    setSearchResults([]);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Global Header */}
      <GlobalHeader />
      
      {/* Page Header */}
      <PageHeader title="Search">
        {/* Search Input */}
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search traders, tickers, or trading strategies..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10 pr-10"
            autoFocus
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 h-6 w-6 -translate-y-1/2"
              onClick={clearSearch}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </PageHeader>

      {/* Search Content */}
      <div className="max-w-2xl mx-auto px-4 space-y-6">
        {!searchQuery ? (
          <div className="space-y-6">
            {/* Popular Tickers */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-foreground">Popular Tickers</h3>
              <div className="flex flex-wrap gap-2">
                {popularTickers.map((ticker) => (
                  <Badge
                    key={ticker}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary/10 border-primary/30"
                    onClick={() => handleSearch(ticker)}
                  >
                    {ticker}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Trending Topics */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-foreground">Trending Topics</h3>
              <div className="flex flex-wrap gap-2">
                {trendingTopics.map((topic) => (
                  <Badge
                    key={topic}
                    variant="secondary"
                    className="cursor-pointer hover:bg-secondary/80"
                    onClick={() => handleSearch(topic)}
                  >
                    {topic}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Search results for:
              </span>
              <Badge variant="outline" className="text-primary border-primary/50">
                {searchQuery}
              </Badge>
            </div>
            
            {searchResults.length === 0 ? (
              <div className="text-center py-12">
                <SearchIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-lg text-muted-foreground mb-2">No results found</p>
                <p className="text-sm text-muted-foreground">
                  Try searching for traders, tickers like $BTC, or trading strategies
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Search results would go here */}
                <p className="text-muted-foreground">Search functionality coming soon...</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}