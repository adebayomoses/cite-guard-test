import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Trophy, Target, Clock } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { GlobalHeader } from "@/components/GlobalHeader";
import { CollaboratorSelector } from "@/components/challenge/CollaboratorSelector";
import { useCanCreatePremiumContent } from "@/hooks/useCanCreatePremiumContent";
import { PremiumContentGate } from "@/components/PremiumContentGate";

interface Profile {
  id: string;
  handle: string;
  display_name: string | null;
  avatar_url: string | null;
}

export default function CreateChallenge() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { canCreate, loading: rankLoading } = useCanCreatePremiumContent();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Redirect if user can't create
  useEffect(() => {
    if (!rankLoading && !canCreate) {
      navigate('/challenges');
    }
  }, [canCreate, rankLoading, navigate]);
  
  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [scope, setScope] = useState("all");
  const [metric, setMetric] = useState("useful_rate");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [collaborators, setCollaborators] = useState<Profile[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create a challenge.",
        variant: "destructive",
      });
      return;
    }

    if (!title.trim() || !description.trim() || !startDate || !endDate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    if (new Date(startDate) >= new Date(endDate)) {
      toast({
        title: "Error",
        description: "End date must be after start date.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('challenges-api', {
        body: {
          action: 'create',
          title: title.trim(),
          description: description.trim(),
          scope,
          metric,
          start_at: new Date(startDate).toISOString(),
          end_at: new Date(endDate).toISOString(),
          collaborator_ids: collaborators.map(c => c.id),
        }
      });

      if (error) {
        console.error('API error:', error);
        throw new Error('Failed to create challenge');
      }

      // Check if data contains an error field (like Pro rank required)
      if (data?.error) {
        throw new Error(data.message || data.error);
      }
      
      toast({
        title: "Success!",
        description: "Challenge created successfully.",
      });
      
      navigate("/challenges");
      
    } catch (error: any) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create challenge. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (rankLoading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="text-center text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  if (!canCreate) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-2xl mx-auto px-4 py-6">
          <PremiumContentGate featureName="challenges" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-bold text-foreground">Create Challenge</h1>
          <Button 
            form="challenge-form"
            type="submit"
            size="sm" 
            className="bg-gradient-primary text-primary-foreground"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Creating..." : "Create Challenge"}
          </Button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="p-6">
          <form id="challenge-form" onSubmit={handleSubmit} className="space-y-6">
            {/* Challenge Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Challenge Title *
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Weekly Forex Trading Championship"
                required
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your challenge, rules, and what makes it exciting..."
                rows={4}
                required
              />
            </div>

            {/* Scope */}
            <div className="space-y-2">
              <Label htmlFor="scope" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Market Scope
              </Label>
              <Select value={scope} onValueChange={setScope}>
                <SelectTrigger>
                  <SelectValue placeholder="Select market scope" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Markets</SelectItem>
                  <SelectItem value="crypto">Cryptocurrency</SelectItem>
                  <SelectItem value="forex">Forex</SelectItem>
                  <SelectItem value="stocks">Stocks</SelectItem>
                  <SelectItem value="commodities">Commodities</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Metric */}
            <div className="space-y-2">
              <Label htmlFor="metric">Success Metric</Label>
              <Select value={metric} onValueChange={setMetric}>
                <SelectTrigger>
                  <SelectValue placeholder="Select success metric" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="useful_rate">Useful Rate (%)</SelectItem>
                  <SelectItem value="net_score">Net Score</SelectItem>
                  <SelectItem value="post_count">Post Count</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Start Date */}
            <div className="space-y-2">
              <Label htmlFor="startDate" className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                Start Date *
              </Label>
              <Input
                id="startDate"
                type="datetime-local"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />
            </div>

            {/* End Date */}
            <div className="space-y-2">
              <Label htmlFor="endDate" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                End Date *
              </Label>
              <Input
                id="endDate"
                type="datetime-local"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                required
              />
            </div>

            {/* Collaborators */}
            <CollaboratorSelector
              selectedCollaborators={collaborators}
              onCollaboratorsChange={setCollaborators}
              maxCollaborators={5}
            />

            {/* Challenge Preview */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <h3 className="font-medium text-foreground">Challenge Preview</h3>
              <div className="text-sm text-muted-foreground space-y-1">
                <p><strong>Title:</strong> {title || "Your challenge title"}</p>
                <p><strong>Scope:</strong> {scope}</p>
                <p><strong>Metric:</strong> {metric.replace('_', ' ')}</p>
                {startDate && endDate && (
                  <p><strong>Duration:</strong> {new Date(startDate).toLocaleDateString()} - {new Date(endDate).toLocaleDateString()}</p>
                )}
              </div>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}