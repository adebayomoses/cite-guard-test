import { Leaderboard } from "@/components/Leaderboard";
import { GlobalHeader } from "@/components/GlobalHeader";
import { PageHeader } from "@/components/PageHeader";
import { useLeaderboard } from "@/hooks/useLeaderboard";
import { Skeleton } from "@/components/ui/skeleton";

export default function LeaderboardPage() {
  const { data: traders, isLoading, error } = useLeaderboard(50);

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      <PageHeader 
        title="Leaderboard"
        subtitle="Ranked by 30-day reputation"
      />

      <div className="max-w-2xl mx-auto px-4">
        {isLoading ? (
          <div className="space-y-3 p-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12 text-muted-foreground">
            Failed to load leaderboard
          </div>
        ) : traders && traders.length > 0 ? (
          <Leaderboard traders={traders} />
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No traders on the leaderboard yet
          </div>
        )}
      </div>
    </div>
  );
}
