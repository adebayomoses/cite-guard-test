import React from "react";
import { Link } from "react-router-dom";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable } from "@/components/admin/AdminTable";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

const AdminEvents = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Event Management</h1>
            <p className="text-muted-foreground">
              Create and manage trading events
            </p>
          </div>
          <Link to="/create-event">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create Event
            </Button>
          </Link>
        </div>

        <AdminTable
          columns={[
            { key: "title", label: "Event", render: () => "Coming Soon" },
            { key: "date", label: "Date", render: () => "Coming Soon" },
            { key: "status", label: "Status", render: () => "Coming Soon" },
          ]}
          data={[]}
          searchPlaceholder="Search events..."
          emptyMessage="No events found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminEvents;