import { useEffect, useState } from "react";
import { Users, FileText, Video, Flag, Shield, Trophy, Calendar, TrendingUp } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { KpiCard } from "@/components/admin/KpiCard";
import { AdminTable, AdminTableColumn, StatusBadge } from "@/components/admin/AdminTable";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "@/lib/admin/auth";

interface DashboardStats {
  totalUsers: number;
  newUsers7d: number;
  totalPosts: number;
  postsToday: number;
  totalVideos: number;
  videosToday: number;
  openReports: number;
  pendingVerifications: number;
  liveChallenges: number;
  upcomingEvents: number;
}

const AdminOverview = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [trendingTickers, setTrendingTickers] = useState<any[]>([]);
  const [topAuthors, setTopAuthors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        await requireAdminAccess();
        setLoading(true);

        // Fetch basic stats
        const [
          usersCount,
          newUsers7d,
          postsCount,
          postsToday,
          videosCount,
          videosToday,
          reportsCount,
          challengesCount,
          eventsCount
        ] = await Promise.all([
          supabase.from('profiles').select('id', { count: 'exact' }),
          supabase.from('kpi_new_users_7d').select('*'),
          supabase.from('posts').select('id', { count: 'exact' }),
          supabase.from('posts').select('id', { count: 'exact' }).gte('created_at', new Date().toISOString().split('T')[0]),
          supabase.from('lifestyle_videos').select('id', { count: 'exact' }),
          supabase.from('lifestyle_videos').select('id', { count: 'exact' }).gte('created_at', new Date().toISOString().split('T')[0]),
          supabase.from('reports').select('id', { count: 'exact' }).eq('status', 'open'),
          supabase.from('challenges_with_status').select('id', { count: 'exact' }).eq('status', 'live'),
          supabase.from('events').select('id', { count: 'exact' }).gte('start_at', new Date().toISOString())
        ]);

        // Calculate new users in last 7 days
        const newUsersSum = newUsers7d.data?.reduce((sum, day) => sum + (day.c || 0), 0) || 0;

        setStats({
          totalUsers: usersCount.count || 0,
          newUsers7d: newUsersSum,
          totalPosts: postsCount.count || 0,
          postsToday: postsToday.count || 0,
          totalVideos: videosCount.count || 0,
          videosToday: videosToday.count || 0,
          openReports: reportsCount.count || 0,
          pendingVerifications: 0, // Would need to implement verification status tracking
          liveChallenges: challengesCount.count || 0,
          upcomingEvents: eventsCount.count || 0
        });

        // Fetch trending tickers
        const { data: trending } = await supabase.rpc('get_trending_tickers_24h');
        setTrendingTickers(trending?.slice(0, 5) || []);

        // Fetch top authors by reputation
        const { data: authors } = await supabase
          .from('profiles')
          .select('handle, display_name, reputation_last30')
          .order('reputation_last30', { ascending: false })
          .limit(5);
        setTopAuthors(authors || []);

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const trendingColumns: AdminTableColumn[] = [
    {
      key: 'ticker',
      label: 'Ticker',
      render: (value) => <Badge variant="outline">{value}</Badge>
    },
    {
      key: 'post_count',
      label: 'Posts',
      sortable: true
    },
    {
      key: 'unique_authors',
      label: 'Authors',
      sortable: true
    },
    {
      key: 'score',
      label: 'Score',
      sortable: true,
      render: (value) => Math.round(value)
    }
  ];

  const authorsColumns: AdminTableColumn[] = [
    {
      key: 'display_name',
      label: 'Author',
      render: (value, row) => (
        <div>
          <div className="font-medium">{value || row.handle}</div>
          <div className="text-sm text-muted-foreground">@{row.handle}</div>
        </div>
      )
    },
    {
      key: 'reputation_last30',
      label: 'Reputation',
      sortable: true,
      render: (value) => (
        <Badge variant="secondary">
          {Math.round(value || 0)}%
        </Badge>
      )
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of platform activity and moderation status
          </p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard
            title="Total Users"
            value={stats?.totalUsers.toLocaleString() || '0'}
            change={stats?.newUsers7d}
            changeLabel="new this week"
            icon={<Users className="h-4 w-4" />}
            loading={loading}
            trend={stats?.newUsers7d && stats.newUsers7d > 0 ? "up" : "neutral"}
          />
          <KpiCard
            title="Posts Today"
            value={stats?.postsToday || 0}
            icon={<FileText className="h-4 w-4" />}
            loading={loading}
          />
          <KpiCard
            title="Videos Today"
            value={stats?.videosToday || 0}
            icon={<Video className="h-4 w-4" />}
            loading={loading}
          />
          <KpiCard
            title="Open Reports"
            value={stats?.openReports || 0}
            icon={<Flag className="h-4 w-4" />}
            loading={loading}
            trend={stats?.openReports && stats.openReports > 0 ? "down" : "neutral"}
          />
        </div>

        {/* Moderation Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard
            title="Pending Verifications"
            value={stats?.pendingVerifications || 0}
            icon={<Shield className="h-4 w-4" />}
            loading={loading}
          />
          <KpiCard
            title="Live Challenges"
            value={stats?.liveChallenges || 0}
            icon={<Trophy className="h-4 w-4" />}
            loading={loading}
          />
          <KpiCard
            title="Upcoming Events"
            value={stats?.upcomingEvents || 0}
            icon={<Calendar className="h-4 w-4" />}
            loading={loading}
          />
          <KpiCard
            title="Total Content"
            value={((stats?.totalPosts || 0) + (stats?.totalVideos || 0)).toLocaleString()}
            icon={<TrendingUp className="h-4 w-4" />}
            loading={loading}
          />
        </div>

        {/* Data Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Trending Tickers (24h)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AdminTable
                columns={trendingColumns}
                data={trendingTickers}
                loading={loading}
                emptyMessage="No trending tickers available"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Top Authors (30d Rep)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AdminTable
                columns={authorsColumns}
                data={topAuthors}
                loading={loading}
                emptyMessage="No authors data available"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminOverview;