import React from "react";
import { Link } from "react-router-dom";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable } from "@/components/admin/AdminTable";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

const AdminChallenges = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Challenge Management</h1>
            <p className="text-muted-foreground">
              Create and manage trading challenges
            </p>
          </div>
          <Link to="/create-challenge">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create Challenge
            </Button>
          </Link>
        </div>

        <AdminTable
          columns={[
            { key: "title", label: "Challenge", render: () => "Coming Soon" },
            { key: "status", label: "Status", render: () => "Coming Soon" },
            { key: "participants", label: "Participants", render: () => "Coming Soon" },
          ]}
          data={[]}
          searchPlaceholder="Search challenges..."
          emptyMessage="No challenges found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminChallenges;