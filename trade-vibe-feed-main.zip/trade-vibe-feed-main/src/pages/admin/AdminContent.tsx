import React from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable } from "@/components/admin/AdminTable";

const AdminContent = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Content Management</h1>
          <p className="text-muted-foreground">
            Manage posts, comments, and user-generated content
          </p>
        </div>

        <AdminTable
          columns={[
            { key: "content", label: "Content", render: () => "Coming Soon" },
            { key: "author", label: "Author", render: () => "Coming Soon" },
            { key: "status", label: "Status", render: () => "Coming Soon" },
          ]}
          data={[]}
          searchPlaceholder="Search content..."
          emptyMessage="No content found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminContent;