import { useEffect, useState } from "react";
import { Users, Shield, Ban, Eye, UserX } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable, AdminTableColumn, StatusBadge } from "@/components/admin/AdminTable";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "@/lib/admin/auth";
import { toggleUserAdmin, toggleUserShadowBan, suspendUser, unsuspendUser } from "@/lib/admin/actions";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: string;
  handle: string;
  display_name: string;
  avatar_url: string;
  is_admin: boolean;
  shadow_banned: boolean;
  verified_status: string;
  created_at: string;
  suspension?: {
    reason: string;
    until: string;
  }[];
}

const AdminUsers = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [suspendReason, setSuspendReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      await requireAdminAccess();
      setLoading(true);

      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          suspension:user_suspensions!user_suspensions_user_id_fkey (
            reason,
            until
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Map the data to ensure suspension is always an array
      const mappedUsers = (data || []).map(user => ({
        ...user,
        suspension: Array.isArray(user.suspension) ? user.suspension : (user.suspension ? [user.suspension] : [])
      }));
      
      setUsers(mappedUsers);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error fetching users",
        description: "Failed to load users data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToggleAdmin = async (userId: string, isAdmin: boolean) => {
    try {
      setActionLoading(true);
      await toggleUserAdmin(userId, !isAdmin);
      toast({
        title: isAdmin ? "Admin privileges revoked" : "Admin privileges granted",
        description: `User ${isAdmin ? 'is no longer' : 'is now'} an admin`
      });
      fetchUsers();
    } catch (error) {
      console.error('Error toggling admin status:', error);
      toast({
        title: "Error updating admin status",
        description: "Failed to update user admin privileges",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleShadowBan = async (userId: string, shadowBanned: boolean) => {
    try {
      setActionLoading(true);
      await toggleUserShadowBan(userId, !shadowBanned);
      toast({
        title: shadowBanned ? "Shadow ban removed" : "User shadow banned",
        description: `User ${shadowBanned ? 'is no longer' : 'is now'} shadow banned`
      });
      fetchUsers();
    } catch (error) {
      console.error('Error toggling shadow ban:', error);
      toast({
        title: "Error updating shadow ban",
        description: "Failed to update user shadow ban status",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleSuspendUser = async (userId: string) => {
    if (!suspendReason.trim()) {
      toast({
        title: "Reason required",
        description: "Please provide a reason for suspension",
        variant: "destructive"
      });
      return;
    }

    try {
      setActionLoading(true);
      await suspendUser(userId, suspendReason);
      toast({
        title: "User suspended",
        description: "The user has been suspended"
      });
      setSelectedUser(null);
      setSuspendReason('');
      fetchUsers();
    } catch (error) {
      console.error('Error suspending user:', error);
      toast({
        title: "Error suspending user",
        description: "Failed to suspend the user",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleUnsuspendUser = async (userId: string) => {
    try {
      setActionLoading(true);
      await unsuspendUser(userId);
      toast({
        title: "User unsuspended",
        description: "The user suspension has been lifted"
      });
      fetchUsers();
    } catch (error) {
      console.error('Error unsuspending user:', error);
      toast({
        title: "Error unsuspending user",
        description: "Failed to lift user suspension",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadges = (user: User) => {
    const badges = [];
    
    if (user.is_admin) {
      badges.push(
        <Badge key="admin" className="bg-red-500/10 text-red-500 border-red-500/20">
          Admin
        </Badge>
      );
    }
    
    if (user.verified_status === 'manual' || user.verified_status === 'broker') {
      badges.push(
        <Badge key="verified" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
          Verified
        </Badge>
      );
    }
    
    if (user.shadow_banned) {
      badges.push(
        <Badge key="shadow" variant="destructive">
          Shadow Banned
        </Badge>
      );
    }
    
    if (user.suspension && user.suspension.length > 0) {
      badges.push(
        <Badge key="suspended" variant="destructive">
          Suspended
        </Badge>
      );
    }

    return badges;
  };

  const columns: AdminTableColumn[] = [
    {
      key: 'user',
      label: 'User',
      render: (_, row) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={row.avatar_url} />
            <AvatarFallback>
              {(row.display_name || row.handle)?.charAt(0)?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{row.display_name || row.handle}</div>
            <div className="text-sm text-muted-foreground">@{row.handle}</div>
          </div>
        </div>
      )
    },
    {
      key: 'status',
      label: 'Status',
      render: (_, row) => (
        <div className="flex flex-wrap gap-1">
          {getStatusBadges(row)}
        </div>
      )
    },
    {
      key: 'created_at',
      label: 'Joined',
      sortable: true,
      render: (value) => new Date(value).toLocaleDateString()
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex gap-1">
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setSelectedUser(row)}
              >
                <Eye className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Manage User: @{row.handle}</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={row.avatar_url} />
                    <AvatarFallback className="text-lg">
                      {(row.display_name || row.handle)?.charAt(0)?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-lg">
                      {row.display_name || row.handle}
                    </h3>
                    <p className="text-muted-foreground">@{row.handle}</p>
                    <div className="flex gap-1 mt-2">
                      {getStatusBadges(row)}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Admin Privileges</Label>
                      <Switch
                        checked={row.is_admin}
                        onCheckedChange={() => handleToggleAdmin(row.id, row.is_admin)}
                        disabled={actionLoading}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label>Shadow Ban</Label>
                      <Switch
                        checked={row.shadow_banned}
                        onCheckedChange={() => handleToggleShadowBan(row.id, row.shadow_banned)}
                        disabled={actionLoading}
                      />
                    </div>
                  </div>
                </div>

                {!row.suspension || row.suspension.length === 0 ? (
                  <div className="space-y-4">
                    <Label>Suspend User</Label>
                    <Textarea
                      placeholder="Reason for suspension..."
                      value={suspendReason}
                      onChange={(e) => setSuspendReason(e.target.value)}
                    />
                    <Button
                      variant="destructive"
                      onClick={() => handleSuspendUser(row.id)}
                      disabled={actionLoading || !suspendReason.trim()}
                      className="w-full"
                    >
                      <Ban className="h-4 w-4 mr-2" />
                      Suspend User
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 border border-red-200 bg-red-50 rounded-lg">
                      <h4 className="font-medium text-red-800">Currently Suspended</h4>
                      <p className="text-sm text-red-600 mt-1">
                        Reason: {row.suspension[0]?.reason}
                      </p>
                      {row.suspension[0]?.until && (
                        <p className="text-sm text-red-600">
                          Until: {new Date(row.suspension[0].until).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleUnsuspendUser(row.id)}
                      disabled={actionLoading}
                      className="w-full"
                    >
                      <UserX className="h-4 w-4 mr-2" />
                      Lift Suspension
                    </Button>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      )
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Users className="h-8 w-8" />
              User Management
            </h1>
            <p className="text-muted-foreground">
              Manage user accounts, privileges, and moderation actions
            </p>
          </div>
        </div>

        <AdminTable
          columns={columns}
          data={users}
          loading={loading}
          searchable
          searchPlaceholder="Search users by handle or name..."
          emptyMessage="No users found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminUsers;