import { useState } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { useAdminVerificationRequests, VerificationRequest } from "@/hooks/useVerificationRequests";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import {
  Camera,
  Link as LinkIcon,
  KeyRound,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  Eye,
  Search,
  ExternalLink,
} from "lucide-react";

const PROOF_TYPE_CONFIG = {
  screenshot: { icon: Camera, label: "Screenshots", color: "bg-blue-500/10 text-blue-500" },
  myfxbook: { icon: LinkIcon, label: "Myfxbook", color: "bg-green-500/10 text-green-500" },
  mt4_password: { icon: KeyRound, label: "MT4/MT5", color: "bg-purple-500/10 text-purple-500" },
  statement: { icon: FileText, label: "Statement", color: "bg-orange-500/10 text-orange-500" },
};

const STATUS_CONFIG = {
  pending: { icon: Clock, label: "Pending", color: "bg-warning/10 text-warning" },
  approved: { icon: CheckCircle, label: "Approved", color: "bg-profit/10 text-profit" },
  rejected: { icon: XCircle, label: "Rejected", color: "bg-loss/10 text-loss" },
};

const AdminVerifications = () => {
  const { requests, loading, approveRequest, rejectRequest, getSignedUrl, refetch } = useAdminVerificationRequests();
  const { toast } = useToast();
  
  const [statusFilter, setStatusFilter] = useState<string>("pending");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRequest, setSelectedRequest] = useState<VerificationRequest | null>(null);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");
  const [adminNotes, setAdminNotes] = useState("");
  const [processing, setProcessing] = useState(false);
  const [signedImageUrls, setSignedImageUrls] = useState<string[]>([]);
  const [loadingImages, setLoadingImages] = useState(false);

  const handleFilterChange = (value: string) => {
    setStatusFilter(value);
    refetch(value);
  };

  const handleViewRequest = async (request: VerificationRequest) => {
    setSelectedRequest(request);
    setAdminNotes(request.admin_notes || "");
    
    // Load signed URLs for images
    if (request.image_urls && request.image_urls.length > 0) {
      setLoadingImages(true);
      try {
        const urls = await Promise.all(
          request.image_urls.map((url) => getSignedUrl(url))
        );
        setSignedImageUrls(urls);
      } catch (error) {
        console.error("Failed to load images:", error);
        setSignedImageUrls([]);
      } finally {
        setLoadingImages(false);
      }
    } else {
      setSignedImageUrls([]);
    }
  };

  const handleApprove = async () => {
    if (!selectedRequest) return;
    
    setProcessing(true);
    try {
      await approveRequest(selectedRequest.id, adminNotes);
      toast({
        title: "Request approved",
        description: "User has been verified successfully",
      });
      setSelectedRequest(null);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve request",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!selectedRequest || !rejectionReason.trim()) {
      toast({
        title: "Rejection reason required",
        description: "Please provide a reason for rejection",
        variant: "destructive",
      });
      return;
    }
    
    setProcessing(true);
    try {
      await rejectRequest(selectedRequest.id, rejectionReason, adminNotes);
      toast({
        title: "Request rejected",
        description: "User has been notified of the rejection",
      });
      setShowRejectDialog(false);
      setSelectedRequest(null);
      setRejectionReason("");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject request",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const filteredRequests = requests.filter((request) => {
    if (!searchQuery) return true;
    const searchLower = searchQuery.toLowerCase();
    return (
      request.profile?.handle?.toLowerCase().includes(searchLower) ||
      request.profile?.display_name?.toLowerCase().includes(searchLower)
    );
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Verification Management</h1>
          <p className="text-muted-foreground">
            Review and manage user verification requests
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by username..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={handleFilterChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Requests</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Requests List */}
        {loading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : filteredRequests.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center p-12 text-center">
              <Clock className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No verification requests</h3>
              <p className="text-muted-foreground">
                {statusFilter === "pending"
                  ? "No pending verification requests at this time"
                  : "No requests match your filters"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredRequests.map((request) => {
              const proofConfig = PROOF_TYPE_CONFIG[request.proof_type as keyof typeof PROOF_TYPE_CONFIG];
              const statusConfig = STATUS_CONFIG[request.status as keyof typeof STATUS_CONFIG];
              const ProofIcon = proofConfig?.icon || FileText;
              const StatusIcon = statusConfig?.icon || Clock;

              return (
                <Card key={request.id} className="bg-gradient-card">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={request.profile?.avatar_url || ""} />
                          <AvatarFallback>
                            {request.profile?.handle?.charAt(0).toUpperCase() || "?"}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">
                              {request.profile?.display_name || request.profile?.handle || "Unknown User"}
                            </span>
                            <Badge variant="outline" className={proofConfig?.color}>
                              <ProofIcon className="h-3 w-3 mr-1" />
                              {proofConfig?.label}
                            </Badge>
                            <Badge variant="outline" className={statusConfig?.color}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {statusConfig?.label}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            @{request.profile?.handle} • Submitted{" "}
                            {formatDistanceToNow(new Date(request.created_at), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                      <Button variant="outline" onClick={() => handleViewRequest(request)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Review
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Review Dialog */}
        <Dialog open={!!selectedRequest} onOpenChange={(open) => !open && setSelectedRequest(null)}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Review Verification Request</DialogTitle>
              <DialogDescription>
                Review the submitted proof and approve or reject this request
              </DialogDescription>
            </DialogHeader>

            {selectedRequest && (
              <div className="space-y-6 py-4">
                {/* User Info */}
                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <Avatar className="h-14 w-14">
                    <AvatarImage src={selectedRequest.profile?.avatar_url || ""} />
                    <AvatarFallback>
                      {selectedRequest.profile?.handle?.charAt(0).toUpperCase() || "?"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-lg">
                      {selectedRequest.profile?.display_name || selectedRequest.profile?.handle}
                    </p>
                    <p className="text-muted-foreground">@{selectedRequest.profile?.handle}</p>
                  </div>
                </div>

                {/* Proof Details */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      {(() => {
                        const config = PROOF_TYPE_CONFIG[selectedRequest.proof_type as keyof typeof PROOF_TYPE_CONFIG];
                        const Icon = config?.icon || FileText;
                        return (
                          <>
                            <Icon className="h-4 w-4" />
                            {config?.label || "Proof"} Verification
                          </>
                        );
                      })()}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Screenshots/Statements */}
                    {(selectedRequest.proof_type === "screenshot" || selectedRequest.proof_type === "statement") && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Uploaded Images</p>
                        {loadingImages ? (
                          <div className="flex items-center justify-center p-8">
                            <Loader2 className="h-6 w-6 animate-spin" />
                          </div>
                        ) : signedImageUrls.length > 0 ? (
                          <div className="grid grid-cols-2 gap-2">
                            {signedImageUrls.map((url, index) => (
                              <a
                                key={index}
                                href={url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="relative aspect-video rounded-lg overflow-hidden border border-border hover:border-primary transition-colors"
                              >
                                <img
                                  src={url}
                                  alt={`Proof ${index + 1}`}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-background/50 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity">
                                  <ExternalLink className="h-6 w-6" />
                                </div>
                              </a>
                            ))}
                          </div>
                        ) : (
                          <p className="text-sm text-muted-foreground">No images available</p>
                        )}
                      </div>
                    )}

                    {/* Myfxbook URL */}
                    {selectedRequest.proof_type === "myfxbook" && selectedRequest.myfxbook_url && (
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Profile URL</p>
                        <a
                          href={selectedRequest.myfxbook_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-primary hover:underline break-all"
                        >
                          <ExternalLink className="h-4 w-4 shrink-0" />
                          {selectedRequest.myfxbook_url}
                        </a>
                      </div>
                    )}

                    {/* MT4/MT5 Credentials */}
                    {selectedRequest.proof_type === "mt4_password" && (
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium">Server</p>
                          <p className="text-sm text-muted-foreground font-mono">
                            {selectedRequest.mt4_server || "Not provided"}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Account Number</p>
                          <p className="text-sm text-muted-foreground font-mono">
                            {selectedRequest.mt4_account_number || "Not provided"}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Investor Password</p>
                          <p className="text-sm text-muted-foreground font-mono">
                            {selectedRequest.mt4_investor_password || "Not provided"}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Additional Notes from User */}
                    {selectedRequest.additional_notes && (
                      <div className="space-y-2 pt-2 border-t border-border">
                        <p className="text-sm font-medium">User Notes</p>
                        <p className="text-sm text-muted-foreground">
                          {selectedRequest.additional_notes}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Admin Notes */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Admin Notes (Internal)</label>
                  <Textarea
                    placeholder="Add internal notes about this request..."
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    rows={3}
                    disabled={selectedRequest.status !== "pending"}
                  />
                </div>

                {/* Previous Review Info */}
                {selectedRequest.status !== "pending" && (
                  <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                    <p className="text-sm font-medium">
                      {selectedRequest.status === "approved" ? "Approved" : "Rejected"}{" "}
                      {selectedRequest.reviewed_at &&
                        formatDistanceToNow(new Date(selectedRequest.reviewed_at), { addSuffix: true })}
                    </p>
                    {selectedRequest.rejection_reason && (
                      <p className="text-sm text-muted-foreground">
                        Reason: {selectedRequest.rejection_reason}
                      </p>
                    )}
                    {selectedRequest.admin_notes && (
                      <p className="text-sm text-muted-foreground">
                        Notes: {selectedRequest.admin_notes}
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Actions */}
            {selectedRequest?.status === "pending" && (
              <DialogFooter className="gap-2 sm:gap-0">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowRejectDialog(true);
                  }}
                  disabled={processing}
                >
                  <XCircle className="h-4 w-4 mr-2" />
                  Reject
                </Button>
                <Button onClick={handleApprove} disabled={processing}>
                  {processing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Approve
                    </>
                  )}
                </Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>

        {/* Rejection Dialog */}
        <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reject Verification Request</DialogTitle>
              <DialogDescription>
                Please provide a reason for rejection. This will be shown to the user.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Textarea
                placeholder="Reason for rejection..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleReject}
                disabled={processing || !rejectionReason.trim()}
              >
                {processing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Rejecting...
                  </>
                ) : (
                  "Confirm Rejection"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
};

export default AdminVerifications;
