import { useEffect, useState } from "react";
import { Flag, Eye, Trash2, Ban, MessageSquare } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable, AdminTableColumn, StatusBadge } from "@/components/admin/AdminTable";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "@/lib/admin/auth";
import { dismissReport, actionReport, addAdminNote } from "@/lib/admin/actions";
import { useToast } from "@/hooks/use-toast";

interface Report {
  id: string;
  target_type: string;
  target_id: string;
  reason: string;
  status: string;
  created_at: string;
  reporter: {
    handle: string;
    display_name: string;
  };
}

const AdminReports = () => {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [actionType, setActionType] = useState<string>('');
  const [actionReason, setActionReason] = useState('');
  const [adminNote, setAdminNote] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      await requireAdminAccess();
      setLoading(true);

      const { data, error } = await supabase
        .from('reports')
        .select(`
          *,
          reporter:profiles!reports_reporter_fkey (
            handle,
            display_name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReports(data || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
      toast({
        title: "Error fetching reports",
        description: "Failed to load reports data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDismissReport = async (reportId: string) => {
    if (!actionReason.trim()) {
      toast({
        title: "Reason required",
        description: "Please provide a reason for dismissing this report",
        variant: "destructive"
      });
      return;
    }

    try {
      setActionLoading(true);
      await dismissReport(reportId, actionReason);
      
      if (adminNote.trim()) {
        await addAdminNote('report', reportId, adminNote);
      }

      toast({
        title: "Report dismissed",
        description: "The report has been dismissed successfully"
      });
      
      setSelectedReport(null);
      setActionReason('');
      setAdminNote('');
      fetchReports();
    } catch (error) {
      console.error('Error dismissing report:', error);
      toast({
        title: "Error dismissing report",
        description: "Failed to dismiss the report",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleActionReport = async (reportId: string) => {
    if (!actionType || !actionReason.trim()) {
      toast({
        title: "Action and reason required",
        description: "Please select an action and provide a reason",
        variant: "destructive"
      });
      return;
    }

    try {
      setActionLoading(true);
      await actionReport(reportId, actionType, actionReason);
      
      if (adminNote.trim()) {
        await addAdminNote('report', reportId, adminNote);
      }

      toast({
        title: "Report actioned",
        description: `Report has been actioned: ${actionType}`
      });
      
      setSelectedReport(null);
      setActionType('');
      setActionReason('');
      setAdminNote('');
      fetchReports();
    } catch (error) {
      console.error('Error actioning report:', error);
      toast({
        title: "Error actioning report",
        description: "Failed to action the report",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const getTargetTypeBadge = (type: string) => {
    const colors = {
      post: "bg-blue-500/10 text-blue-500 border-blue-500/20",
      video: "bg-purple-500/10 text-purple-500 border-purple-500/20", 
      comment: "bg-green-500/10 text-green-500 border-green-500/20",
      profile: "bg-orange-500/10 text-orange-500 border-orange-500/20"
    };
    
    return (
      <Badge variant="outline" className={colors[type as keyof typeof colors] || ""}>
        {type}
      </Badge>
    );
  };

  const columns: AdminTableColumn[] = [
    {
      key: 'target_type',
      label: 'Type',
      render: (value) => getTargetTypeBadge(value)
    },
    {
      key: 'reason',
      label: 'Reason',
      render: (value) => (
        <div className="max-w-xs truncate" title={value}>
          {value || 'No reason provided'}
        </div>
      )
    },
    {
      key: 'reporter',
      label: 'Reporter',
      render: (value) => (
        <div>
          <div className="font-medium">{value?.display_name || value?.handle}</div>
          <div className="text-sm text-muted-foreground">@{value?.handle}</div>
        </div>
      )
    },
    {
      key: 'status',
      label: 'Status',
      render: (value) => <StatusBadge status={value} />
    },
    {
      key: 'created_at',
      label: 'Reported',
      sortable: true,
      render: (value) => new Date(value).toLocaleDateString()
    },
    {
      key: 'actions',
      label: 'Actions',
      render: (_, row) => (
        <div className="flex gap-1">
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setSelectedReport(row)}
              >
                <Eye className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Review Report</DialogTitle>
                <DialogDescription>
                  Report for {row.target_type} by @{row.reporter?.handle}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Target Type</Label>
                  <div className="mt-1">
                    {getTargetTypeBadge(row.target_type)}
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium">Reason</Label>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {row.reason || 'No reason provided'}
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="action-type">Action</Label>
                  <Select value={actionType} onValueChange={setActionType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select action" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hide">Hide Content</SelectItem>
                      <SelectItem value="delete">Delete Content</SelectItem>
                      <SelectItem value="suspend">Suspend User</SelectItem>
                      <SelectItem value="warning">Issue Warning</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="action-reason">Reason for Action</Label>
                  <Textarea
                    id="action-reason"
                    placeholder="Explain why this action is being taken..."
                    value={actionReason}
                    onChange={(e) => setActionReason(e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="admin-note">Admin Note (optional)</Label>
                  <Textarea
                    id="admin-note"
                    placeholder="Internal note about this report..."
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                  />
                </div>
              </div>
              
              <DialogFooter className="gap-2">
                <Button
                  variant="outline"
                  onClick={() => handleDismissReport(row.id)}
                  disabled={actionLoading}
                >
                  Dismiss Report
                </Button>
                <Button
                  onClick={() => handleActionReport(row.id)}
                  disabled={actionLoading}
                >
                  {actionLoading ? 'Processing...' : 'Take Action'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      )
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Flag className="h-8 w-8" />
              Reports Management
            </h1>
            <p className="text-muted-foreground">
              Review and moderate user reports
            </p>
          </div>
        </div>

        <AdminTable
          columns={columns}
          data={reports}
          loading={loading}
          searchable
          searchPlaceholder="Search reports..."
          emptyMessage="No reports found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminReports;