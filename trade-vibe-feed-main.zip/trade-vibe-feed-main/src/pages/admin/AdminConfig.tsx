import { useEffect, useState } from "react";
import { Settings, Save, RotateCcw, RefreshCw, TrendingUp } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { KpiCard } from "@/components/admin/KpiCard";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "@/lib/admin/auth";
import { toggleFeatureFlag, updateSiteSetting } from "@/lib/admin/actions";
import { useToast } from "@/hooks/use-toast";
import LogoUploader from "@/components/admin/LogoUploader";

interface FeatureFlag {
  key: string;
  enabled: boolean;
  updated_at: string;
}

interface SiteSetting {
  key: string;
  value: any;
  updated_at: string;
}

const AdminConfig = () => {
  const [featureFlags, setFeatureFlags] = useState<FeatureFlag[]>([]);
  const [siteSettings, setSiteSettings] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [recalculating, setRecalculating] = useState(false);
  const [localSettings, setLocalSettings] = useState<Record<string, any>>({
    brand_name: '',
    support_email: '',
    site_disclaimer: '',
    site_name: 'UpTraView',
    site_logo_url: null,
    // Reputation weights (must sum to 100)
    reputation_trading_weight: 50,
    reputation_engagement_weight: 20,
    reputation_quality_weight: 20,
    reputation_activity_weight: 10,
    // Anti-gaming thresholds
    reputation_min_signals: 5,
    reputation_min_votes: 10,
    reputation_follower_cap: 100,
    reputation_comments_cap: 30,
    reputation_content_cap: 10,
    reputation_challenges_cap: 3,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    fetchConfig();
  }, []);

  const weightTotal = 
    Number(localSettings.reputation_trading_weight || 0) +
    Number(localSettings.reputation_engagement_weight || 0) +
    Number(localSettings.reputation_quality_weight || 0) +
    Number(localSettings.reputation_activity_weight || 0);

  const handleRecalculateReputation = async () => {
    try {
      setRecalculating(true);
      const { data, error } = await supabase.functions.invoke('reputation-cron');
      
      if (error) throw error;
      
      toast({
        title: "Reputation recalculated",
        description: `Updated ${data?.updated || 0} profiles with new scores`
      });
    } catch (error) {
      console.error('Error recalculating reputation:', error);
      toast({
        title: "Error recalculating",
        description: "Failed to recalculate reputation scores",
        variant: "destructive"
      });
    } finally {
      setRecalculating(false);
    }
  };

  const fetchConfig = async () => {
    try {
      await requireAdminAccess();
      setLoading(true);

      const [flagsResult, settingsResult] = await Promise.all([
        supabase.from('feature_flags').select('*').order('key'),
        supabase.from('site_settings').select('*').order('key')
      ]);

      if (flagsResult.error) throw flagsResult.error;
      if (settingsResult.error) throw settingsResult.error;

      setFeatureFlags(flagsResult.data || []);
      
      const settingsObj = (settingsResult.data || []).reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {});
      
      setSiteSettings(settingsObj);
      setLocalSettings(settingsObj);
    } catch (error) {
      console.error('Error fetching config:', error);
      toast({
        title: "Error fetching configuration",
        description: "Failed to load configuration data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFeatureFlagToggle = async (key: string, enabled: boolean) => {
    try {
      await toggleFeatureFlag(key, enabled);
      
      setFeatureFlags(flags => 
        flags.map(flag => 
          flag.key === key ? { ...flag, enabled } : flag
        )
      );
      
      // Invalidate feature flags cache to update UI immediately
      queryClient.invalidateQueries({ queryKey: ['feature_flags'] });
      
      toast({
        title: "Feature flag updated",
        description: `${key} has been ${enabled ? 'enabled' : 'disabled'}`
      });
    } catch (error) {
      console.error('Error toggling feature flag:', error);
      toast({
        title: "Error updating feature flag",
        description: "Failed to update the feature flag",
        variant: "destructive"
      });
    }
  };

  const handleSaveSettings = async () => {
    try {
      setSaving(true);
      
      for (const [key, value] of Object.entries(localSettings)) {
        if (siteSettings[key] !== value) {
          await updateSiteSetting(key, value);
        }
      }
      
      setSiteSettings(localSettings);
      
      toast({
        title: "Settings saved",
        description: "Site settings have been updated successfully"
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Error saving settings",
        description: "Failed to save site settings",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleResetSettings = () => {
    setLocalSettings(siteSettings);
  };

  const updateLocalSetting = (key: string, value: any) => {
    setLocalSettings(prev => ({ ...prev, [key]: value }));
  };

  const hasUnsavedChanges = JSON.stringify(localSettings) !== JSON.stringify(siteSettings);

  const flagDescriptions = {
    lifestyle_enabled: "Enable lifestyle video features and uploads",
    trending_tab: "Show trending tab in the main feed",
    events_enabled: "Enable events functionality and calendar",
    market_watch_enabled: "Enable Market Watch with live prices and trading news",
    video_compression: "Automatically compress large videos before upload for faster uploads"
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded-lg animate-pulse"></div>
            ))}
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Settings className="h-8 w-8" />
              Configuration
            </h1>
            <p className="text-muted-foreground">
              Manage feature flags and site settings
            </p>
          </div>
        </div>

        {/* Environment Info */}
        <KpiCard
          title="Environment"
          value="Production"
          icon={<Settings className="h-4 w-4" />}
        />

        {/* Branding Section */}
        <Card>
          <CardHeader>
            <CardTitle>Branding</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="site_logo">Site Logo</Label>
              <div className="mt-2">
                <LogoUploader
                  currentUrl={localSettings.site_logo_url}
                  onUpload={(url) => updateLocalSetting('site_logo_url', url)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="site_name">Site Name</Label>
              <Input
                id="site_name"
                value={localSettings.site_name || ''}
                onChange={(e) => updateLocalSetting('site_name', e.target.value)}
                placeholder="UpTraView"
                className="mt-2"
              />
              <p className="text-sm text-muted-foreground mt-1">
                This will be displayed throughout the application
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Reputation Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Reputation Settings
                </CardTitle>
                <CardDescription>
                  Configure how user reputation scores are calculated
                </CardDescription>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRecalculateReputation}
                disabled={recalculating}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${recalculating ? 'animate-spin' : ''}`} />
                {recalculating ? 'Recalculating...' : 'Recalculate Now'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Category Weights */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Category Weights</h4>
                <span className={`text-sm font-medium ${weightTotal === 100 ? 'text-green-500' : 'text-destructive'}`}>
                  Total: {weightTotal}% {weightTotal !== 100 && '(must equal 100%)'}
                </span>
              </div>
              
              <div className="grid gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Trading Performance</Label>
                    <span className="text-sm text-muted-foreground">{localSettings.reputation_trading_weight}%</span>
                  </div>
                  <Slider
                    value={[Number(localSettings.reputation_trading_weight) || 0]}
                    onValueChange={([v]) => updateLocalSetting('reputation_trading_weight', v)}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">Win rate and P&L performance</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Community Engagement</Label>
                    <span className="text-sm text-muted-foreground">{localSettings.reputation_engagement_weight}%</span>
                  </div>
                  <Slider
                    value={[Number(localSettings.reputation_engagement_weight) || 0]}
                    onValueChange={([v]) => updateLocalSetting('reputation_engagement_weight', v)}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">Followers and comments given</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Content Quality</Label>
                    <span className="text-sm text-muted-foreground">{localSettings.reputation_quality_weight}%</span>
                  </div>
                  <Slider
                    value={[Number(localSettings.reputation_quality_weight) || 0]}
                    onValueChange={([v]) => updateLocalSetting('reputation_quality_weight', v)}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">Useful vote rate and saves received</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Consistency & Activity</Label>
                    <span className="text-sm text-muted-foreground">{localSettings.reputation_activity_weight}%</span>
                  </div>
                  <Slider
                    value={[Number(localSettings.reputation_activity_weight) || 0]}
                    onValueChange={([v]) => updateLocalSetting('reputation_activity_weight', v)}
                    max={100}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">Posts, videos, and challenge entries</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Anti-Gaming Thresholds */}
            <div className="space-y-4">
              <h4 className="font-medium">Anti-Gaming Thresholds</h4>
              <p className="text-sm text-muted-foreground">
                Minimum requirements and caps to prevent gaming the system
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="min_signals">Min Signals for Trading Score</Label>
                  <Input
                    id="min_signals"
                    type="number"
                    value={localSettings.reputation_min_signals || 5}
                    onChange={(e) => updateLocalSetting('reputation_min_signals', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="min_votes">Min Votes for Quality Score</Label>
                  <Input
                    id="min_votes"
                    type="number"
                    value={localSettings.reputation_min_votes || 10}
                    onChange={(e) => updateLocalSetting('reputation_min_votes', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="follower_cap">Follower Cap</Label>
                  <Input
                    id="follower_cap"
                    type="number"
                    value={localSettings.reputation_follower_cap || 100}
                    onChange={(e) => updateLocalSetting('reputation_follower_cap', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="comments_cap">Comments/Month Cap</Label>
                  <Input
                    id="comments_cap"
                    type="number"
                    value={localSettings.reputation_comments_cap || 30}
                    onChange={(e) => updateLocalSetting('reputation_comments_cap', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="content_cap">Content/Month Cap</Label>
                  <Input
                    id="content_cap"
                    type="number"
                    value={localSettings.reputation_content_cap || 10}
                    onChange={(e) => updateLocalSetting('reputation_content_cap', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="challenges_cap">Challenges Cap</Label>
                  <Input
                    id="challenges_cap"
                    type="number"
                    value={localSettings.reputation_challenges_cap || 3}
                    onChange={(e) => updateLocalSetting('reputation_challenges_cap', parseInt(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Feature Flags */}
        <Card>
          <CardHeader>
            <CardTitle>Feature Flags</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {featureFlags.map((flag) => (
              <div key={flag.key} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <Label className="font-medium">{flag.key}</Label>
                  <p className="text-sm text-muted-foreground">
                    {flagDescriptions[flag.key as keyof typeof flagDescriptions] || 
                     "No description available"}
                  </p>
                </div>
                <Switch
                  checked={flag.enabled}
                  onCheckedChange={(enabled) => handleFeatureFlagToggle(flag.key, enabled)}
                />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Site Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Site Settings</CardTitle>
              {hasUnsavedChanges && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleResetSettings}
                    disabled={saving}
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleSaveSettings}
                    disabled={saving}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="brand_name">Brand Name</Label>
                <Input
                  id="brand_name"
                  value={localSettings.brand_name || ''}
                  onChange={(e) => updateLocalSetting('brand_name', e.target.value)}
                  placeholder="Your app name"
                />
              </div>
              
              <div>
                <Label htmlFor="support_email">Support Email</Label>
                <Input
                  id="support_email"
                  type="email"
                  value={localSettings.support_email || ''}
                  onChange={(e) => updateLocalSetting('support_email', e.target.value)}
                  placeholder="support@example.com"
                />
              </div>
              
              <div>
                <Label htmlFor="site_disclaimer">Site Disclaimer</Label>
                <Textarea
                  id="site_disclaimer"
                  value={localSettings.site_disclaimer || ''}
                  onChange={(e) => updateLocalSetting('site_disclaimer', e.target.value)}
                  placeholder="Legal disclaimer text..."
                  rows={3}
                />
              </div>
            </div>

            <Separator />

            {hasUnsavedChanges && (
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={handleResetSettings}
                  disabled={saving}
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset Changes
                </Button>
                <Button
                  onClick={handleSaveSettings}
                  disabled={saving}
                >
                  <Save className="h-4 w-4 mr-2" />
                  {saving ? 'Saving...' : 'Save Settings'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default AdminConfig;