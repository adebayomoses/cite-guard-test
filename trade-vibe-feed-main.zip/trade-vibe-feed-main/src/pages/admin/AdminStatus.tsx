import { AdminLayout } from '@/components/admin/AdminLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trophy, Zap, Award, Users, BarChart3 } from 'lucide-react';
import { RankConfigTab } from '@/components/admin/status/RankConfigTab';
import { XPRewardsTab } from '@/components/admin/status/XPRewardsTab';
import { AchievementsTab } from '@/components/admin/status/AchievementsTab';
import { UserXPTab } from '@/components/admin/status/UserXPTab';
import { StatusAnalyticsTab } from '@/components/admin/status/StatusAnalyticsTab';

const AdminStatus = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Status & Gamification</h1>
          <p className="text-muted-foreground">
            Manage ranks, XP rewards, achievements, and user status data
          </p>
        </div>

        <Tabs defaultValue="ranks" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="ranks" className="flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              <span className="hidden sm:inline">Ranks</span>
            </TabsTrigger>
            <TabsTrigger value="xp" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">XP Rewards</span>
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center gap-2">
              <Award className="h-4 w-4" />
              <span className="hidden sm:inline">Achievements</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">User XP</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ranks">
            <RankConfigTab />
          </TabsContent>

          <TabsContent value="xp">
            <XPRewardsTab />
          </TabsContent>

          <TabsContent value="achievements">
            <AchievementsTab />
          </TabsContent>

          <TabsContent value="users">
            <UserXPTab />
          </TabsContent>

          <TabsContent value="analytics">
            <StatusAnalyticsTab />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default AdminStatus;
