import { useEffect, useState } from "react";
import { FileSearch, User, Target, Calendar } from "lucide-react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { AdminTable, AdminTableColumn } from "@/components/admin/AdminTable";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "@/lib/admin/auth";
import { useToast } from "@/hooks/use-toast";

interface AuditLogEntry {
  id: number;
  action: string;
  subject_type: string;
  subject_id: string;
  metadata: any;
  created_at: string;
  admin: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

const AdminAudit = () => {
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchAuditLogs();
  }, []);

  const fetchAuditLogs = async () => {
    try {
      await requireAdminAccess();
      setLoading(true);

      const { data, error } = await supabase
        .from('admin_audit_log')
        .select(`
          *,
          admin:profiles!admin_audit_log_admin_id_fkey (
            handle,
            display_name,
            avatar_url
          )
        `)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setAuditLogs(data || []);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      toast({
        title: "Error fetching audit logs",
        description: "Failed to load audit log data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getActionBadge = (action: string) => {
    const actionTypes = {
      create: "bg-green-500/10 text-green-500 border-green-500/20",
      update: "bg-blue-500/10 text-blue-500 border-blue-500/20",
      delete: "bg-red-500/10 text-red-500 border-red-500/20",
      suspend: "bg-orange-500/10 text-orange-500 border-orange-500/20",
      grant: "bg-purple-500/10 text-purple-500 border-purple-500/20",
      revoke: "bg-gray-500/10 text-gray-500 border-gray-500/20"
    };

    const getType = (action: string) => {
      if (action.includes('delete')) return 'delete';
      if (action.includes('suspend') || action.includes('ban')) return 'suspend';
      if (action.includes('grant') || action.includes('admin')) return 'grant';
      if (action.includes('revoke')) return 'revoke';
      if (action.includes('update') || action.includes('toggle')) return 'update';
      return 'create';
    };

    const type = getType(action);
    const colorClass = actionTypes[type as keyof typeof actionTypes] || actionTypes.create;

    return (
      <Badge variant="outline" className={colorClass}>
        {action}
      </Badge>
    );
  };

  const getSubjectIcon = (subjectType: string) => {
    const icons = {
      user: User,
      post: FileSearch,
      video: FileSearch,
      challenge: Target,
      event: Calendar,
      report: FileSearch,
      config: FileSearch
    };

    const Icon = icons[subjectType as keyof typeof icons] || FileSearch;
    return <Icon className="h-4 w-4" />;
  };

  const columns: AdminTableColumn[] = [
    {
      key: 'admin',
      label: 'Admin',
      render: (value) => (
        <div className="flex items-center gap-2">
          <Avatar className="h-6 w-6">
            <AvatarImage src={value?.avatar_url} />
            <AvatarFallback className="text-xs">
              {(value?.display_name || value?.handle)?.charAt(0)?.toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm">
            {value?.display_name || value?.handle}
          </span>
        </div>
      )
    },
    {
      key: 'action',
      label: 'Action',
      render: (value) => getActionBadge(value)
    },
    {
      key: 'subject_type',
      label: 'Target',
      render: (value, row) => (
        <div className="flex items-center gap-2">
          {getSubjectIcon(value)}
          <div>
            <div className="font-medium text-sm capitalize">{value}</div>
            <div className="text-xs text-muted-foreground font-mono">
              {row.subject_id?.substring(0, 8)}...
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'metadata',
      label: 'Details',
      render: (value) => {
        if (!value || Object.keys(value).length === 0) {
          return <span className="text-muted-foreground text-sm">No details</span>;
        }

        const details = Object.entries(value).slice(0, 2).map(([key, val]) => 
          `${key}: ${typeof val === 'string' ? val.substring(0, 20) : String(val)}`
        ).join(', ');

        return (
          <div className="max-w-xs">
            <span className="text-sm truncate" title={JSON.stringify(value, null, 2)}>
              {details}
            </span>
          </div>
        );
      }
    },
    {
      key: 'created_at',
      label: 'Time',
      sortable: true,
      render: (value) => (
        <div className="text-sm">
          <div>{new Date(value).toLocaleDateString()}</div>
          <div className="text-xs text-muted-foreground">
            {new Date(value).toLocaleTimeString()}
          </div>
        </div>
      )
    }
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <FileSearch className="h-8 w-8" />
              Audit Log
            </h1>
            <p className="text-muted-foreground">
              Track all administrative actions and changes
            </p>
          </div>
        </div>

        <AdminTable
          columns={columns}
          data={auditLogs}
          loading={loading}
          searchable
          searchPlaceholder="Search audit logs..."
          emptyMessage="No audit logs found"
        />
      </div>
    </AdminLayout>
  );
};

export default AdminAudit;