import { useState, useEffect } from "react";
import { GlobalHeader } from "@/components/GlobalHeader";
import { useFeatureFlags } from "@/hooks/useFeatureFlags";
import { PageHeader } from "@/components/PageHeader";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, Clock, MapPin, ExternalLink, Users, Download, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";
import { format } from "date-fns";
import { useCanCreatePremiumContent } from "@/hooks/useCanCreatePremiumContent";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface Event {
  id: string;
  title: string;
  description: string;
  start_at: string;
  end_at: string;
  location: string;
  url: string;
  tags: string[];
  host: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

export default function EventsPage() {
  const [activeTab, setActiveTab] = useState("upcoming");
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const { session } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { flags } = useFeatureFlags();
  const { canCreate, currentXP, proRankThreshold, currentRank } = useCanCreatePremiumContent();

  // Redirect if events are disabled
  useEffect(() => {
    if (flags.events_enabled === false) {
      navigate('/');
    }
  }, [flags.events_enabled, navigate]);

  const fetchEvents = async (status: string) => {
    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
      }

      const url = new URL(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/events-api/list`);
      if (status === 'upcoming') {
        url.searchParams.set('status', 'upcoming');
      } else if (status === 'past') {
        url.searchParams.set('status', 'past');
      }

      const response = await fetch(url.toString(), { headers });
      if (!response.ok) throw new Error('Failed to fetch events');
      
      const data = await response.json();
      setEvents(data.events || []);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast({
        title: "Error",
        description: "Failed to load events",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    const loadEvents = async () => {
      setLoading(true);
      await fetchEvents(activeTab);
      setLoading(false);
    };

    loadEvents();
  }, [activeTab, session]);

  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'MMM dd, yyyy • h:mm a');
  };

  const getUniqueTagsFromEvents = () => {
    const allTags = events.flatMap(event => event.tags || []);
    return [...new Set(allTags)];
  };

  const filteredEvents = events.filter(event => {
    if (selectedTags.length === 0) return true;
    return selectedTags.some(tag => event.tags?.includes(tag));
  });

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const downloadICS = async (eventId: string) => {
    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
      }

      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/events-api/${eventId}/ics`, { headers });
      if (!response.ok) throw new Error('Failed to download calendar file');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'event.ics';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading ICS:', error);
      toast({
        title: "Error",
        description: "Failed to download calendar file",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <PageHeader title="Events" />
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="text-center">Loading events...</div>
        </div>
      </div>
    );
  }

  const uniqueTags = getUniqueTagsFromEvents();

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      <div className="flex items-center justify-between px-4 py-6 border-b border-border">
        <div>
          <h1 className="text-2xl font-bold">Trading Events</h1>
          <p className="text-muted-foreground">
            Join webinars, workshops, and live trading sessions
          </p>
        </div>
        {session && (
          canCreate ? (
            <Link to="/create-event">
              <Button className="gap-2">
                <Calendar className="h-4 w-4" />
                Create Event
              </Button>
            </Link>
          ) : (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button disabled className="gap-2">
                    <Lock className="h-4 w-4" />
                    Create Event
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="font-medium">Pro Trader rank required</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {currentRank?.icon} {currentRank?.name} • {currentXP}/{proRankThreshold} XP
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )
        )}
      </div>

      <div className="max-w-6xl mx-auto px-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="past">Past</TabsTrigger>
          </TabsList>

          {/* Tag Filters */}
          {uniqueTags.length > 0 && (
            <div className="mt-6 mb-4">
              <h3 className="text-sm font-medium mb-3">Filter by topic:</h3>
              <div className="flex flex-wrap gap-2">
                {uniqueTags.map(tag => (
                  <Badge
                    key={tag}
                    variant={selectedTags.includes(tag) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleTag(tag)}
                  >
                    {tag}
                  </Badge>
                ))}
                {selectedTags.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedTags([])}
                    className="h-auto px-2 py-1 text-xs"
                  >
                    Clear filters
                  </Button>
                )}
              </div>
            </div>
          )}

          <TabsContent value={activeTab} className="mt-6">
            {filteredEvents.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12">
                    <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">
                      {selectedTags.length > 0 ? 'No events match your filters' : 'No events found'}
                    </h3>
                    <p className="text-muted-foreground">
                      {activeTab === 'upcoming' 
                        ? 'No upcoming events scheduled at the moment'
                        : 'No past events to display'
                      }
                    </p>
                    {selectedTags.length > 0 && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setSelectedTags([])}
                        className="mt-4"
                      >
                        Clear filters
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((event) => (
                  <Card key={event.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-2">
                        <CardTitle className="text-lg line-clamp-2">{event.title}</CardTitle>
                        <Avatar className="h-8 w-8 flex-shrink-0">
                          <AvatarImage src={event.host?.avatar_url} />
                          <AvatarFallback>
                            {event.host?.display_name?.charAt(0) || '?'}
                          </AvatarFallback>
                        </Avatar>
                      </div>
                      <CardDescription className="line-clamp-2">
                        {event.description}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{formatEventDate(event.start_at)}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{event.location || 'Online'}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>Host: @{event.host?.handle}</span>
                      </div>

                      {event.tags && event.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {event.tags.slice(0, 3).map(tag => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {event.tags.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{event.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      )}
                    </CardContent>
                    
                    <CardFooter className="flex gap-2">
                      <Link to={`/events/${event.id}`} className="flex-1">
                        <Button variant="outline" className="w-full">
                          View Details
                        </Button>
                      </Link>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => downloadICS(event.id)}
                        className="px-3"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      
                      {event.url && (
                        <Button
                          variant="default"
                          size="sm"
                          asChild
                          className="px-3"
                        >
                          <a
                            href={event.url}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}