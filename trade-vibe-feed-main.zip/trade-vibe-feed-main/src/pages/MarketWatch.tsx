import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageHeader } from "@/components/PageHeader";
import { PriceFeedWidget } from "@/components/market/PriceFeedWidget";
import { NewsFeed } from "@/components/market/NewsFeed";
import { AlertsManager } from "@/components/market/AlertsManager";
import { WatchlistWidget } from "@/components/market/WatchlistWidget";
import { TrendingUp, Bell, Newspaper, Star } from "lucide-react";

export default function MarketWatch() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <PageHeader
        title="Market Watch"
        subtitle="Live prices and trading news"
      />

      <div className="px-4 py-6">
        <Tabs defaultValue="prices" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="prices" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Prices</span>
            </TabsTrigger>
            <TabsTrigger value="watchlist" className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              <span className="hidden sm:inline">Watchlist</span>
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Alerts</span>
            </TabsTrigger>
            <TabsTrigger value="news" className="flex items-center gap-2">
              <Newspaper className="h-4 w-4" />
              <span className="hidden sm:inline">News</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="prices" className="mt-0">
            <PriceFeedWidget />
          </TabsContent>

          <TabsContent value="watchlist" className="mt-0">
            <WatchlistWidget />
          </TabsContent>

          <TabsContent value="alerts" className="mt-0">
            <AlertsManager />
          </TabsContent>

          <TabsContent value="news" className="mt-0">
            <NewsFeed />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}