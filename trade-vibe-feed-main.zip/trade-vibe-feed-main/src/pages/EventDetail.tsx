import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { GlobalHeader } from "@/components/GlobalHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, Clock, MapPin, ExternalLink, Download, Share2, Users } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Link } from "react-router-dom";

interface Event {
  id: string;
  title: string;
  description: string;
  start_at: string;
  end_at: string;
  location: string;
  url: string;
  tags: string[];
  host: {
    id: string;
    handle: string;
    display_name: string;
    avatar_url: string;
  };
}

export default function EventDetail() {
  const { id } = useParams<{ id: string }>();
  const [event, setEvent] = useState<Event | null>(null);
  const [relatedEvents, setRelatedEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const { session } = useAuth();
  const { toast } = useToast();

  const fetchEventDetails = async () => {
    if (!id) return;

    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
      }

      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/events-api/${id}`, { headers });
      if (!response.ok) throw new Error('Failed to fetch event');
      
      const data = await response.json();
      setEvent(data.event);

      // Fetch related events (same tags)
      if (data.event?.tags?.length > 0) {
        const relatedResponse = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/events-api/list?limit=3`, { headers });
        if (relatedResponse.ok) {
          const relatedData = await relatedResponse.json();
          const filtered = relatedData.events.filter((e: Event) => 
            e.id !== id && e.tags?.some(tag => data.event.tags.includes(tag))
          );
          setRelatedEvents(filtered.slice(0, 3));
        }
      }
    } catch (error) {
      console.error('Error fetching event:', error);
      toast({
        title: "Error",
        description: "Failed to load event details",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEventDetails();
  }, [id, session]);

  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'EEEE, MMMM dd, yyyy • h:mm a');
  };

  const downloadICS = async () => {
    if (!id) return;
    
    try {
      const headers: Record<string, string> = {};
      if (session?.access_token) {
        headers.Authorization = `Bearer ${session.access_token}`;
      }

      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/events-api/${id}/ics`, { headers });
      if (!response.ok) throw new Error('Failed to download calendar file');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${event?.title || 'event'}.ics`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Calendar file downloaded",
        description: "Event has been saved to your downloads",
      });
    } catch (error) {
      console.error('Error downloading ICS:', error);
      toast({
        title: "Error",
        description: "Failed to download calendar file",
        variant: "destructive",
      });
    }
  };

  const shareEvent = async () => {
    const url = window.location.href;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: event?.title,
          text: event?.description,
          url: url,
        });
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback: copy to clipboard
      try {
        await navigator.clipboard.writeText(url);
        toast({
          title: "Link copied",
          description: "Event link has been copied to clipboard",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to copy link",
          variant: "destructive",
        });
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center">Loading event details...</div>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center">Event not found</div>
        </div>
      </div>
    );
  }

  const isUpcoming = new Date(event.start_at) > new Date();

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Event Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-4">{event.title}</h1>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-6">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{formatEventDate(event.start_at)}</span>
                </div>
                
                {event.end_at && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Ends: {format(new Date(event.end_at), 'h:mm a')}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{event.location || 'Online'}</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <Link 
                    to={`/profile/${event.host.handle}`}
                    className="hover:underline"
                  >
                    Host: @{event.host.handle}
                  </Link>
                </div>
              </div>

              {event.tags && event.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {event.tags.map(tag => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
            
            <Avatar className="h-16 w-16 ml-4">
              <AvatarImage src={event.host.avatar_url} />
              <AvatarFallback>{event.host.display_name?.charAt(0) || '?'}</AvatarFallback>
            </Avatar>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={downloadICS}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Add to Calendar
            </Button>
            
            <Button
              onClick={shareEvent}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Share2 className="h-4 w-4" />
              Share
            </Button>
            
            {event.url && (
              <Button
                asChild
                className="flex items-center gap-2"
              >
                <a
                  href={event.url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <ExternalLink className="h-4 w-4" />
                  {isUpcoming ? 'Join Event' : 'View Recording'}
                </a>
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Event Description */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>About This Event</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {event.description ? (
                    <p className="whitespace-pre-wrap">{event.description}</p>
                  ) : (
                    <p className="text-muted-foreground">No description provided.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Related Events */}
          <div className="lg:col-span-1">
            {relatedEvents.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Related Events</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {relatedEvents.map((relatedEvent) => (
                    <Link
                      key={relatedEvent.id}
                      to={`/events/${relatedEvent.id}`}
                      className="block p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <h4 className="font-medium text-sm line-clamp-2 mb-1">
                        {relatedEvent.title}
                      </h4>
                      <div className="text-xs text-muted-foreground">
                        {format(new Date(relatedEvent.start_at), 'MMM dd • h:mm a')}
                      </div>
                    </Link>
                  ))}
                  
                  <Link to="/events">
                    <Button variant="ghost" size="sm" className="w-full">
                      View All Events
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}