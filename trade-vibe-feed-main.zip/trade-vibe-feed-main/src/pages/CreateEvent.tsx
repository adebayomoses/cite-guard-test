import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, MapPin, ExternalLink, Clock } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { GlobalHeader } from "@/components/GlobalHeader";
import { useCanCreatePremiumContent } from "@/hooks/useCanCreatePremiumContent";
import { PremiumContentGate } from "@/components/PremiumContentGate";

export default function CreateEvent() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { canCreate, loading: rankLoading } = useCanCreatePremiumContent();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Redirect if user can't create
  useEffect(() => {
    if (!rankLoading && !canCreate) {
      navigate('/events');
    }
  }, [canCreate, rankLoading, navigate]);
  
  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("online");
  const [customLocation, setCustomLocation] = useState("");
  const [url, setUrl] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [tags, setTags] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create an event.",
        variant: "destructive",
      });
      return;
    }

    if (!title.trim() || !description.trim() || !startDate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const eventLocation = location === "custom" ? customLocation : location;
      const eventTags = tags.split(',').map(tag => tag.trim()).filter(tag => tag);

      const { data, error } = await supabase.functions.invoke('events-api', {
        body: {
          action: 'create',
          title: title.trim(),
          description: description.trim(),
          location: eventLocation,
          url: url || null,
          start_at: new Date(startDate).toISOString(),
          end_at: endDate ? new Date(endDate).toISOString() : null,
          tags: eventTags,
        }
      });

      if (error) {
        console.error('API error:', error);
        throw new Error('Failed to create event');
      }

      // Check if data contains an error field (like Pro rank required)
      if (data?.error) {
        throw new Error(data.message || data.error);
      }
      
      toast({
        title: "Success!",
        description: "Event created successfully.",
      });
      
      navigate("/events");
      
    } catch (error: any) {
      console.error('Submit error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create event. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (rankLoading) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="text-center text-muted-foreground">Loading...</div>
        </div>
      </div>
    );
  }

  if (!canCreate) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <GlobalHeader />
        <div className="max-w-2xl mx-auto px-4 py-6">
          <PremiumContentGate featureName="events" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-bold text-foreground">Create Event</h1>
          <Button 
            form="event-form"
            type="submit"
            size="sm" 
            className="bg-gradient-primary text-primary-foreground"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Creating..." : "Create Event"}
          </Button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card className="p-6">
          <form id="event-form" onSubmit={handleSubmit} className="space-y-6">
            {/* Event Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                Event Title *
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Advanced Trading Strategies Webinar"
                required
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your event, agenda, and what attendees will learn..."
                rows={4}
                required
              />
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location" className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Location
              </Label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="online">Online</SelectItem>
                  <SelectItem value="custom">Custom Location</SelectItem>
                </SelectContent>
              </Select>
              
              {location === "custom" && (
                <Input
                  value={customLocation}
                  onChange={(e) => setCustomLocation(e.target.value)}
                  placeholder="Enter location details"
                  className="mt-2"
                />
              )}
            </div>

            {/* Event URL */}
            <div className="space-y-2">
              <Label htmlFor="url" className="flex items-center gap-2">
                <ExternalLink className="h-4 w-4" />
                Event URL (optional)
              </Label>
              <Input
                id="url"
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/event"
              />
            </div>

            {/* Start Date */}
            <div className="space-y-2">
              <Label htmlFor="startDate" className="flex items-center gap-2">
                <CalendarIcon className="h-4 w-4" />
                Start Date & Time *
              </Label>
              <Input
                id="startDate"
                type="datetime-local"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />
            </div>

            {/* End Date */}
            <div className="space-y-2">
              <Label htmlFor="endDate" className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                End Date & Time (optional)
              </Label>
              <Input
                id="endDate"
                type="datetime-local"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="e.g., webinar, advanced, strategy, forex"
              />
            </div>

            {/* Event Preview */}
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <h3 className="font-medium text-foreground">Event Preview</h3>
              <div className="text-sm text-muted-foreground space-y-1">
                <p><strong>Title:</strong> {title || "Your event title"}</p>
                <p><strong>Location:</strong> {location === "custom" ? customLocation || "Custom location" : location}</p>
                {startDate && (
                  <p><strong>Start:</strong> {new Date(startDate).toLocaleString()}</p>
                )}
                {endDate && (
                  <p><strong>End:</strong> {new Date(endDate).toLocaleString()}</p>
                )}
                {tags && (
                  <p><strong>Tags:</strong> {tags}</p>
                )}
              </div>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}