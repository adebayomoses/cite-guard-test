import React, { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlobalHeader } from '@/components/GlobalHeader';
import { PageHeader } from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, X, Play, Zap } from 'lucide-react';
import { useLifestyleActions } from '@/hooks/useLifestyle';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { compressVideo, shouldCompress, formatFileSize } from '@/lib/videoCompression';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';

export default function LifestyleUpload() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { uploadVideo } = useLifestyleActions();
  const { flags } = useFeatureFlags();
  const isCompressionEnabled = flags.video_compression !== false; // Default to true if not set
  
  const [selectedVideo, setSelectedVideo] = useState<File | null>(null);
  const [selectedThumbnail, setSelectedThumbnail] = useState<File | null>(null);
  const [caption, setCaption] = useState('');
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [tickers, setTickers] = useState<string[]>([]);
  const [visibility, setVisibility] = useState<'public' | 'followers'>('public');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [thumbnailProgress, setThumbnailProgress] = useState(0);
  const [uploadStage, setUploadStage] = useState<'idle' | 'compressing' | 'video' | 'thumbnail' | 'complete'>('idle');
  const [compressionProgress, setCompressionProgress] = useState(0);
  const [compressionInfo, setCompressionInfo] = useState<{ original: number; compressed: number } | null>(null);
  const [hashtagInput, setHashtagInput] = useState('');
  const [tickerInput, setTickerInput] = useState('');
  
  const videoInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);

  const handleVideoSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('video/')) {
      toast.error('Please select a valid video file');
      return;
    }

    // Validate file size (max 100MB)
    if (file.size > 100 * 1024 * 1024) {
      toast.error('Video file too large. Maximum size is 100MB');
      return;
    }

    setSelectedVideo(file);
    
    // Auto-extract thumbnail at 1 second
    const video = videoPreviewRef.current;
    if (video) {
      video.onloadedmetadata = () => {
        video.currentTime = 1;
      };
      video.onseeked = () => {
        generateThumbnail();
      };
      video.src = URL.createObjectURL(file);
    }
  };

  const generateThumbnail = () => {
    const video = videoPreviewRef.current;
    if (!video) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.drawImage(video, 0, 0);
    
    canvas.toBlob((blob) => {
      if (blob) {
        const thumbnailFile = new File([blob], 'thumbnail.jpg', { type: 'image/jpeg' });
        setSelectedThumbnail(thumbnailFile);
      }
    }, 'image/jpeg', 0.8);
  };

  const handleThumbnailSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please select a valid image file');
      return;
    }

    setSelectedThumbnail(file);
  };

  const addHashtag = () => {
    const tag = hashtagInput.trim().replace('#', '');
    if (tag && !hashtags.includes(tag)) {
      setHashtags([...hashtags, tag]);
      setHashtagInput('');
    }
  };

  const addTicker = () => {
    const ticker = tickerInput.trim().replace('$', '').toUpperCase();
    if (ticker && !tickers.includes(ticker)) {
      setTickers([...tickers, ticker]);
      setTickerInput('');
    }
  };

  const removeHashtag = (index: number) => {
    setHashtags(hashtags.filter((_, i) => i !== index));
  };

  const removeTicker = (index: number) => {
    setTickers(tickers.filter((_, i) => i !== index));
  };

  const extractTickersFromCaption = useCallback((text: string) => {
    const tickerRegex = /\$([A-Z]{1,5})/g;
    const matches = text.match(tickerRegex);
    if (matches) {
      const extractedTickers = matches.map(match => match.replace('$', ''));
      const newTickers = extractedTickers.filter(ticker => !tickers.includes(ticker));
      if (newTickers.length > 0) {
        setTickers(prev => [...prev, ...newTickers]);
      }
    }
  }, [tickers]);

  // Debounced ticker extraction to prevent UI jumping
  const debouncedExtractTickers = useCallback(
    (() => {
      let timeoutId: NodeJS.Timeout;
      return (text: string) => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => extractTickersFromCaption(text), 500);
      };
    })(),
    [extractTickersFromCaption]
  );

  const handleCaptionChange = (text: string) => {
    setCaption(text);
    debouncedExtractTickers(text);
  };

  const uploadWithProgress = async (
    file: File,
    bucket: string,
    path: string,
    onProgress: (percentage: number) => void
  ): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          reject(new Error('No session found'));
          return;
        }

        const xhr = new XMLHttpRequest();
        
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percentage = Math.round((event.loaded / event.total) * 100);
            onProgress(percentage);
          }
        };
        
        xhr.onload = () => {
          if (xhr.status === 200) {
            resolve();
          } else {
            reject(new Error(`Upload failed: ${xhr.statusText}`));
          }
        };
        
        xhr.onerror = () => reject(new Error('Upload failed'));
        
        const SUPABASE_URL = 'https://jyonjxvfjshkjdtjwcqo.supabase.co';
        const url = `${SUPABASE_URL}/storage/v1/object/${bucket}/${path}`;
        
        xhr.open('POST', url);
        xhr.setRequestHeader('Authorization', `Bearer ${session.access_token}`);
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.send(file);
      } catch (error) {
        reject(error);
      }
    });
  };

  const getPublicUrl = (bucket: string, path: string) => {
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
  };

  const handleUpload = async () => {
    if (!selectedVideo || !user) {
      toast.error('Please select a video file');
      return;
    }

    try {
      setUploading(true);
      setUploadProgress(0);
      setThumbnailProgress(0);
      setCompressionProgress(0);
      setCompressionInfo(null);
      
      let videoToUpload = selectedVideo;
      
      // Compress video if it's large (>10MB) and compression is enabled
      if (isCompressionEnabled && shouldCompress(selectedVideo)) {
        setUploadStage('compressing');
        toast.info('Compressing video for faster upload...');
        
        try {
          const result = await compressVideo(selectedVideo, {
            onProgress: setCompressionProgress,
            onStage: (stage) => {
              if (stage === 'loading') {
                toast.info('Loading compression engine...');
              }
            }
          });
          
          videoToUpload = result.compressedFile;
          setCompressionInfo({
            original: result.originalSize,
            compressed: result.compressedSize
          });
          toast.success(`Compressed: ${formatFileSize(result.originalSize)} → ${formatFileSize(result.compressedSize)} (${result.compressionRatio}% saved)`);
        } catch (compressError) {
          console.warn('Compression failed, uploading original:', compressError);
          toast.warning('Compression failed, uploading original file');
        }
      }
      
      setUploadStage('video');
      const videoId = crypto.randomUUID();
      const videoPath = `${user.id}/${videoId}.${videoToUpload.name.split('.').pop()}`;
      
      // Upload video with progress
      await uploadWithProgress(
        videoToUpload,
        'lifestyle-videos',
        videoPath,
        (percentage) => setUploadProgress(percentage)
      );
      const videoUrl = getPublicUrl('lifestyle-videos', videoPath);
      
      let thumbnailUrl: string | undefined;
      
      // Upload thumbnail if available
      if (selectedThumbnail) {
        setUploadStage('thumbnail');
        const thumbnailPath = `${user.id}/${videoId}_thumb.jpg`;
        await uploadWithProgress(
          selectedThumbnail,
          'lifestyle-thumbs',
          thumbnailPath,
          (percentage) => setThumbnailProgress(percentage)
        );
        thumbnailUrl = getPublicUrl('lifestyle-thumbs', thumbnailPath);
      }

      setUploadStage('complete');

      // Get video duration
      const video = videoPreviewRef.current;
      const duration = video ? Math.round(video.duration) : undefined;

      // Create video record
      await uploadVideo({
        caption: caption.trim() || undefined,
        hashtags,
        tickers,
        visibility,
        video_url: videoUrl,
        thumbnail_url: thumbnailUrl,
        duration_seconds: duration
      });

      toast.success('Video uploaded successfully!');
      navigate('/lifestyle');
      
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload video. Please try again.');
      setUploadStage('idle');
      setUploadProgress(0);
      setThumbnailProgress(0);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      
      <PageHeader title="Upload Lifestyle Video" />
      
      <div className="max-w-2xl mx-auto px-4 space-y-6">
        {/* Video Upload */}
        <div className="space-y-4">
          <Label>Video File</Label>
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            {selectedVideo ? (
              <div className="space-y-4">
                <video
                  ref={videoPreviewRef}
                  controls
                  className="w-full max-h-64 rounded-lg"
                  src={selectedVideo ? URL.createObjectURL(selectedVideo) : ''}
                />
                <div className="flex items-center justify-center gap-2">
                  <span className="text-sm">{selectedVideo.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedVideo(null)}
                    disabled={uploading}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                
                {/* Upload Progress */}
                {uploading && (
                  <div className="space-y-2 p-4 bg-muted/50 rounded-lg mt-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {uploadStage === 'compressing' && (
                          <span className="flex items-center gap-2">
                            <Zap className="h-4 w-4 text-amber-500" />
                            Compressing video... {compressionProgress}%
                          </span>
                        )}
                        {uploadStage === 'video' && `Uploading video... ${uploadProgress}%`}
                        {uploadStage === 'thumbnail' && `Uploading thumbnail... ${thumbnailProgress}%`}
                        {uploadStage === 'complete' && 'Processing...'}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {uploadStage === 'compressing' ? 'This may take a moment' : 
                         uploadProgress < 100 ? 'Please wait' : 'Almost done!'}
                      </span>
                    </div>
                    <Progress 
                      value={
                        uploadStage === 'compressing' ? compressionProgress :
                        uploadStage === 'video' ? uploadProgress : 
                        uploadStage === 'thumbnail' ? thumbnailProgress : 100
                      } 
                      className="h-2"
                    />
                    {compressionInfo && uploadStage !== 'compressing' && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Zap className="h-3 w-3 text-green-500" />
                        Saved {formatFileSize(compressionInfo.original - compressionInfo.compressed)} 
                        ({formatFileSize(compressionInfo.original)} → {formatFileSize(compressionInfo.compressed)})
                      </p>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div
                className="cursor-pointer"
                onClick={() => videoInputRef.current?.click()}
              >
                <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-lg font-medium">Select a video file</p>
                <p className="text-sm text-muted-foreground">
                  MP4, WebM up to 100MB
                </p>
              </div>
            )}
          </div>
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={handleVideoSelect}
          />
        </div>

        {/* Thumbnail Upload */}
        {selectedVideo && (
          <div className="space-y-4">
            <Label>Thumbnail (Optional)</Label>
            <div className="flex items-center gap-4">
              {selectedThumbnail && (
                <img
                  src={URL.createObjectURL(selectedThumbnail)}
                  alt="Thumbnail preview"
                  className="w-24 h-24 object-cover rounded-lg"
                />
              )}
              <Button
                variant="outline"
                onClick={() => thumbnailInputRef.current?.click()}
              >
                {selectedThumbnail ? 'Change Thumbnail' : 'Upload Custom Thumbnail'}
              </Button>
              <input
                ref={thumbnailInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleThumbnailSelect}
              />
            </div>
          </div>
        )}

        {/* Caption */}
        <div className="space-y-2">
          <Label htmlFor="caption">Caption</Label>
          <Textarea
            id="caption"
            placeholder="What's this video about? Use $TICKER for cashtags..."
            value={caption}
            onChange={(e) => handleCaptionChange(e.target.value)}
            rows={3}
          />
        </div>

        {/* Hashtags */}
        <div className="space-y-2">
          <Label>Hashtags</Label>
          <div className="flex gap-2">
            <Input
              placeholder="Add hashtag (without #)"
              value={hashtagInput}
              onChange={(e) => setHashtagInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addHashtag())}
            />
            <Button onClick={addHashtag} disabled={!hashtagInput.trim()}>
              Add
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {hashtags.map((hashtag, index) => (
              <Badge key={index} variant="secondary" className="gap-1">
                #{hashtag}
                <button onClick={() => removeHashtag(index)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>

        {/* Tickers */}
        <div className="space-y-2">
          <Label>Tickers/Cashtags</Label>
          <div className="flex gap-2">
            <Input
              placeholder="Add ticker (without $)"
              value={tickerInput}
              onChange={(e) => setTickerInput(e.target.value.toUpperCase())}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTicker())}
            />
            <Button onClick={addTicker} disabled={!tickerInput.trim()}>
              Add
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {tickers.map((ticker, index) => (
              <Badge key={index} variant="outline" className="gap-1">
                ${ticker}
                <button onClick={() => removeTicker(index)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </div>

        {/* Visibility */}
        <div className="space-y-2">
          <Label>Visibility</Label>
          <Select value={visibility} onValueChange={(value: 'public' | 'followers') => setVisibility(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="public">Public - Anyone can see</SelectItem>
              <SelectItem value="followers">Followers only</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Upload Button */}
        <div className="flex gap-4">
          <Button
            onClick={handleUpload}
            disabled={!selectedVideo || uploading}
            className="flex-1"
          >
            {uploading ? 'Uploading...' : 'Upload Video'}
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate('/lifestyle')}
            disabled={uploading}
          >
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}