import { GlobalHeader } from "@/components/GlobalHeader";
import { PageHeader } from "@/components/PageHeader";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Plus, Lock } from "lucide-react";
import { MentorshipChannelGrid } from "@/components/MentorshipChannelGrid";
import { CreateMentorshipChannel } from "@/components/CreateMentorshipChannel";
import { useMentorshipChannels } from "@/hooks/useMentorshipChannels";
import { useState } from "react";
import { useCanCreatePremiumContent } from "@/hooks/useCanCreatePremiumContent";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function MentorshipPage() {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState<'free' | 'paid'>('free');
  
  const { data: channels, isLoading, refetch } = useMentorshipChannels(selectedTab);
  const { canCreate, currentXP, proRankThreshold, currentRank } = useCanCreatePremiumContent();

  return (
    <div className="min-h-screen bg-background pb-20">
      <GlobalHeader />
      
      <div className="sticky top-0 z-10 bg-background border-b">
        <PageHeader 
          title="Mentorship Channels" 
          subtitle="Join trading communities led by experienced mentors"
        />
        
        <div className="flex items-center justify-between px-4 pb-4">
          <Tabs value={selectedTab} onValueChange={(v) => setSelectedTab(v as 'free' | 'paid')} className="flex-1">
            <TabsList className="w-full md:w-auto">
              <TabsTrigger value="free" className="flex-1 md:flex-none">
                Free Channels
              </TabsTrigger>
              <TabsTrigger value="paid" className="flex-1 md:flex-none">
                Paid Channels
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          {canCreate ? (
            <Button onClick={() => setCreateDialogOpen(true)} size="sm" className="ml-4">
              <Plus className="h-4 w-4 mr-2" />
              Create Channel
            </Button>
          ) : (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button disabled size="sm" className="ml-4">
                    <Lock className="h-4 w-4 mr-2" />
                    Create Channel
                  </Button>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="font-medium">Pro Trader rank required</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {currentRank?.icon} {currentRank?.name} • {currentXP}/{proRankThreshold} XP
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4">
        <MentorshipChannelGrid 
          channels={channels} 
          type={selectedTab}
          isLoading={isLoading}
          onJoinSuccess={refetch}
        />
      </div>

      <CreateMentorshipChannel
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onSuccess={() => {
          refetch();
          setCreateDialogOpen(false);
        }}
      />
    </div>
  );
}
