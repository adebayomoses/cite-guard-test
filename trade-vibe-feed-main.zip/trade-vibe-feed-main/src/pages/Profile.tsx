import { useParams, useNavigate } from 'react-router-dom';
import { useProfile } from '@/hooks/useProfile';
import { useAuth } from '@/contexts/AuthContext';
import { useState, useEffect } from 'react';
import { ProfileHeader } from '@/components/ProfileHeader';
import { StatsRow } from '@/components/StatsRow';
import { ReputationPillWithSparkline } from '@/components/ReputationPillWithSparkline';
import { ChipList } from '@/components/ChipList';
import { ProfileAchievements } from '@/components/ProfileAchievements';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { profileApi } from '@/lib/api/profile';
import { 
  ProfileOverviewTab, 
  ProfileSavedTab, 
  ProfileSignalsTab, 
  ProfileTradesTab, 
  ProfileMediaTab, 
  ProfileJournalTab 
} from '@/components/profile';
import { Loader2, AlertCircle, Settings } from 'lucide-react';

export default function Profile() {
  const { handle } = useParams();
  const { profile: currentUserProfile, loading: profileLoading } = useProfile();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [profileData, setProfileData] = useState<any>(null);
  const [stats, setStats] = useState({ posts: 0, followers: 0, following: 0 });
  const [reputation, setReputation] = useState(0);
  const [sparklineData, setSparklineData] = useState<number[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const isOwnProfile = !handle || (currentUserProfile && handle === currentUserProfile.handle);

  useEffect(() => {
    const fetchProfileData = async () => {
      try {
        setLoading(true);
        setError(null);

        if (isOwnProfile && currentUserProfile) {
          setProfileData(currentUserProfile);
          
          const profileStats = await profileApi.getProfileStats(currentUserProfile.id);
          setStats({
            posts: 0,
            followers: profileStats.followers,
            following: profileStats.following,
          });
          setReputation(profileStats.usefulRate30d);
          setSparklineData(profileStats.sparkline);
          
        } else if (handle) {
          const profile = await profileApi.getProfileByHandle(handle);
          
          if (!profile) {
            setError('Profile not found');
            return;
          }

          setProfileData(profile);
          
          const profileStats = await profileApi.getProfileStats(profile.id);
          setStats({
            posts: 0,
            followers: profileStats.followers,
            following: profileStats.following,
          });
          setReputation(profileStats.usefulRate30d);
          setSparklineData(profileStats.sparkline);

          if (user) {
            const followStatus = await profileApi.checkFollowStatus(profile.id);
            setIsFollowing(followStatus);
          }
        }
      } catch (err) {
        console.error('Error fetching profile:', err);
        setError('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };

    if (!profileLoading) {
      fetchProfileData();
    }
  }, [handle, currentUserProfile, profileLoading, user, isOwnProfile]);

  const handleFollowChange = (newIsFollowing: boolean, newFollowerCount: number) => {
    setIsFollowing(newIsFollowing);
    setStats(prev => ({ ...prev, followers: newFollowerCount }));
  };

  const handleEditProfile = () => {
    navigate('/settings/profile');
  };

  if (loading || profileLoading) {
    return (
      <div className="min-h-screen bg-background pt-14 pb-20">
        <div className="max-w-2xl mx-auto p-4">
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background pt-14 pb-20">
        <div className="max-w-2xl mx-auto p-4">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (!profileData) {
    return (
      <div className="min-h-screen bg-background pt-14 pb-20">
        <div className="max-w-2xl mx-auto p-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>Profile not found</AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const isPrivateProfile = !profileData.is_public && !user && !isOwnProfile;

  if (isPrivateProfile) {
    return (
      <div className="min-h-screen bg-background pt-14 pb-20">
        <div className="max-w-2xl mx-auto p-4">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="space-y-4">
                <div className="text-4xl">🔒</div>
                <h2 className="text-xl font-semibold">Private Profile</h2>
                <p className="text-muted-foreground">
                  This profile is private. Sign in to view more details.
                </p>
                <Button onClick={() => navigate('/auth')}>
                  Sign In
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const shouldShowEmptyStateBanner = 
    isOwnProfile && 
    (!profileData.markets?.length || !profileData.strategy_tags?.length);

  return (
    <div className="min-h-screen bg-background pt-14 pb-20">
      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="p-0">
            <ProfileHeader
              profile={{
                id: profileData.id,
                username: profileData.handle,
                display_name: profileData.display_name,
                avatar: profileData.avatar_url,
                bio: profileData.bio,
                verified: profileData.verified_status,
                followers: stats.followers,
                following: stats.following,
              }}
              isOwnProfile={isOwnProfile}
              isFollowing={isFollowing}
              onFollowChange={handleFollowChange}
              onEditClick={handleEditProfile}
            />
          </CardContent>
        </Card>

        {/* Reputation */}
        <Card>
          <CardContent className="p-4">
            <ReputationPillWithSparkline
              reputation={reputation}
              sparklineData={sparklineData}
            />
          </CardContent>
        </Card>

        {/* Achievements Trophy Case */}
        <ProfileAchievements userId={profileData.id} />

        {/* Stats Row */}
        <Card>
          <CardContent className="p-4">
            <StatsRow stats={stats} userId={profileData.id} />
          </CardContent>
        </Card>

        {/* Empty State Banner */}
        {shouldShowEmptyStateBanner && (
          <Alert>
            <Settings className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>Complete your profile to get better recommendations</span>
              <Button variant="outline" size="sm" onClick={handleEditProfile}>
                Complete Profile
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Markets and Strategies */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <ChipList
                title="Markets Traded"
                items={profileData.markets || []}
                emptyMessage="No markets specified"
                showAddButton={isOwnProfile}
                onAddClick={handleEditProfile}
              />
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <ChipList
                title="Trading Strategies"
                items={profileData.strategy_tags || []}
                emptyMessage="No strategies specified"
                showAddButton={isOwnProfile}
                onAddClick={handleEditProfile}
              />
            </CardContent>
          </Card>
        </div>

        {/* Content Tabs */}
        <Card>
          <CardContent className="p-0">
            <Tabs defaultValue="overview" className="w-full">
              <div className="border-b overflow-x-auto">
                <TabsList className="inline-flex w-auto min-w-full h-12 bg-transparent p-0">
                  <TabsTrigger value="overview" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Overview</TabsTrigger>
                  <TabsTrigger value="saved" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Saved</TabsTrigger>
                  <TabsTrigger value="signals" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Signals</TabsTrigger>
                  <TabsTrigger value="trades" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Trades</TabsTrigger>
                  <TabsTrigger value="media" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Media</TabsTrigger>
                  <TabsTrigger value="journal" className="flex-1 min-w-[80px] data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">Journal</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="overview" className="p-4">
                <ProfileOverviewTab userId={profileData.id} />
              </TabsContent>
              
              <TabsContent value="saved" className="p-4">
                <ProfileSavedTab userId={profileData.id} isOwnProfile={isOwnProfile} />
              </TabsContent>
              
              <TabsContent value="signals" className="p-4">
                <ProfileSignalsTab userId={profileData.id} />
              </TabsContent>
              
              <TabsContent value="trades" className="p-4">
                <ProfileTradesTab userId={profileData.id} isOwnProfile={isOwnProfile} />
              </TabsContent>
              
              <TabsContent value="media" className="p-4">
                <ProfileMediaTab userId={profileData.id} isOwnProfile={isOwnProfile} />
              </TabsContent>
              
              <TabsContent value="journal" className="p-4">
                <ProfileJournalTab userId={profileData.id} isOwnProfile={isOwnProfile} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
