import { supabase } from "@/integrations/supabase/client";
import { requireAdminAccess } from "./auth";

interface AuditLogEntry {
  action: string;
  subject_type: string;
  subject_id: string;
  metadata?: Record<string, any>;
}

export async function logAdminAction(entry: AuditLogEntry) {
  await requireAdminAccess();
  
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  const { error } = await supabase
    .from('admin_audit_log')
    .insert({
      admin_id: user.id,
      ...entry
    });

  if (error) {
    console.error('Failed to log admin action:', error);
  }
}

// User Management Actions
export async function toggleUserAdmin(userId: string, isAdmin: boolean) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('profiles')
    .update({ is_admin: isAdmin })
    .eq('id', userId);

  if (error) throw error;
  
  await logAdminAction({
    action: isAdmin ? 'user.grant_admin' : 'user.revoke_admin',
    subject_type: 'user',
    subject_id: userId
  });
}

export async function toggleUserShadowBan(userId: string, shadowBanned: boolean) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('profiles')
    .update({ shadow_banned: shadowBanned })
    .eq('id', userId);

  if (error) throw error;
  
  await logAdminAction({
    action: shadowBanned ? 'user.shadow_ban' : 'user.unshadow_ban',
    subject_type: 'user',
    subject_id: userId
  });
}

export async function suspendUser(userId: string, reason: string, until?: Date) {
  await requireAdminAccess();
  
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { error } = await supabase
    .from('user_suspensions')
    .upsert({
      user_id: userId,
      reason,
      until: until?.toISOString(),
      created_by: user.id
    });

  if (error) throw error;
  
  await logAdminAction({
    action: 'user.suspend',
    subject_type: 'user',
    subject_id: userId,
    metadata: { reason, until: until?.toISOString() }
  });
}

export async function unsuspendUser(userId: string) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('user_suspensions')
    .delete()
    .eq('user_id', userId);

  if (error) throw error;
  
  await logAdminAction({
    action: 'user.unsuspend',
    subject_type: 'user',
    subject_id: userId
  });
}

// Content Management Actions
export async function deletePost(postId: string, reason: string) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('posts')
    .delete()
    .eq('id', postId);

  if (error) throw error;
  
  await logAdminAction({
    action: 'post.delete',
    subject_type: 'post',
    subject_id: postId,
    metadata: { reason }
  });
}

export async function deleteLifestyleVideo(videoId: string, reason: string) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('lifestyle_videos')
    .delete()
    .eq('id', videoId);

  if (error) throw error;
  
  await logAdminAction({
    action: 'video.delete',
    subject_type: 'video',
    subject_id: videoId,
    metadata: { reason }
  });
}

// Reports Management
export async function dismissReport(reportId: string, reason: string) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('reports')
    .update({ status: 'dismissed' })
    .eq('id', reportId);

  if (error) throw error;
  
  await logAdminAction({
    action: 'report.dismiss',
    subject_type: 'report',
    subject_id: reportId,
    metadata: { reason }
  });
}

export async function actionReport(reportId: string, action: string, reason: string) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('reports')
    .update({ status: 'actioned' })
    .eq('id', reportId);

  if (error) throw error;
  
  await logAdminAction({
    action: 'report.action',
    subject_type: 'report',
    subject_id: reportId,
    metadata: { action, reason }
  });
}

// Feature Flags
export async function toggleFeatureFlag(key: string, enabled: boolean) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('feature_flags')
    .upsert({ key, enabled });

  if (error) throw error;
  
  await logAdminAction({
    action: 'feature_flag.toggle',
    subject_type: 'config',
    subject_id: key,
    metadata: { enabled }
  });
}

// Site Settings
export async function updateSiteSetting(key: string, value: any) {
  await requireAdminAccess();
  
  const { error } = await supabase
    .from('site_settings')
    .upsert({ key, value });

  if (error) throw error;
  
  await logAdminAction({
    action: 'site_setting.update',
    subject_type: 'config',
    subject_id: key,
    metadata: { value }
  });
}

// Admin Notes
export async function addAdminNote(subjectType: string, subjectId: string, note: string) {
  await requireAdminAccess();
  
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { error } = await supabase
    .from('admin_notes')
    .insert({
      subject_type: subjectType,
      subject_id: subjectId,
      author: user.id,
      note
    });

  if (error) throw error;
  
  await logAdminAction({
    action: 'admin_note.create',
    subject_type: subjectType,
    subject_id: subjectId,
    metadata: { note }
  });
}