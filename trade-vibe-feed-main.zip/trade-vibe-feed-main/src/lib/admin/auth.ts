import { supabase } from "@/integrations/supabase/client";

export async function checkAdminAccess(): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    // Check user_roles table for admin role (proper RBAC)
    const { data: roles, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin');

    if (error) {
      console.error('Error checking admin role:', error);
      return false;
    }

    return roles && roles.length > 0;
  } catch (error) {
    console.error('Error checking admin access:', error);
    return false;
  }
}

export async function requireAdminAccess(): Promise<void> {
  const isAdmin = await checkAdminAccess();
  if (!isAdmin) {
    throw new Error('Admin access required');
  }
}