import { supabase } from '@/integrations/supabase/client';
import type { Profile } from '@/hooks/useProfile';

export interface ProfileUpdateData {
  display_name?: string;
  handle?: string;
  bio?: string;
  avatar_url?: string;
  markets?: string[];
  strategy_tags?: string[];
  experience_level?: 'beginner' | 'intermediate' | 'advanced';
  timezone?: string;
  links?: Record<string, string>;
  watchlist?: string[];
}

export interface ProfilePrivacyData {
  is_public?: boolean;
  show_stats?: boolean;
}

export interface FollowResponse {
  isFollowing: boolean;
  followers: number;
  following: number;
}

export interface ProfileStats {
  followers: number;
  following: number;
  usefulRate30d: number;
  sparkline: number[];
}

export const profileApi = {
  async updateProfile(data: ProfileUpdateData) {
    const { data: result, error } = await supabase
      .from('profiles')
      .update(data)
      .eq('id', (await supabase.auth.getUser()).data.user?.id)
      .select()
      .single();

    if (error) throw error;
    return result;
  },

  async updatePrivacy(data: ProfilePrivacyData) {
    const { data: result, error } = await supabase
      .from('profile_privacy')
      .update(data)
      .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
      .select()
      .single();

    if (error) throw error;
    return result;
  },

  async toggleFollow(targetUserId: string): Promise<FollowResponse> {
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) throw new Error('Not authenticated');

    // Check if already following
    const { data: existingFollow } = await supabase
      .from('follows')
      .select('*')
      .eq('user_id', user.user.id)
      .eq('target_id', targetUserId)
      .maybeSingle();

    if (existingFollow) {
      // Unfollow
      const { error } = await supabase
        .from('follows')
        .delete()
        .eq('user_id', user.user.id)
        .eq('target_id', targetUserId);

      if (error) throw error;
    } else {
      // Follow
      const { error } = await supabase
        .from('follows')
        .insert({ user_id: user.user.id, target_id: targetUserId });

      if (error) throw error;
    }

    // Get updated counts
    const { data: counts } = await supabase
      .from('user_follow_counts')
      .select('*')
      .eq('user_id', targetUserId)
      .single();

    return {
      isFollowing: !existingFollow,
      followers: counts?.followers || 0,
      following: counts?.following || 0,
    };
  },

  async getProfileStats(userId: string): Promise<ProfileStats> {
    // Get follow counts
    const { data: followCounts } = await supabase
      .from('user_follow_counts')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    // Get the multi-factor reputation score from profiles
    const { data: profile } = await supabase
      .from('profiles')
      .select('reputation_last30')
      .eq('id', userId)
      .maybeSingle();

    // Get real sparkline data from reputation snapshots (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const { data: snapshots } = await supabase
      .from('reputation_snapshots')
      .select('reputation, snapshot_date')
      .eq('user_id', userId)
      .gte('snapshot_date', thirtyDaysAgo.toISOString().split('T')[0])
      .order('snapshot_date', { ascending: true });

    // Convert snapshots to sparkline array
    let sparkline: number[] = [];
    if (snapshots && snapshots.length > 0) {
      sparkline = snapshots.map(s => Number(s.reputation));
    }
    
    // If not enough data points, pad with current value
    const currentRep = profile?.reputation_last30 || 0;
    while (sparkline.length < 7) {
      sparkline.unshift(currentRep);
    }

    return {
      followers: followCounts?.followers || 0,
      following: followCounts?.following || 0,
      usefulRate30d: profile?.reputation_last30 || 0,
      sparkline,
    };
  },

  async getProfileByHandle(handle: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('handle', handle.toLowerCase())
      .maybeSingle();

    if (error) throw error;
    return data as Profile | null;
  },

  async startVerification() {
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) throw new Error('Not authenticated');

    const { error } = await supabase
      .from('profiles')
      .update({ verified_status: 'pending' })
      .eq('id', user.user.id);

    if (error) throw error;
    return { success: true };
  },

  async checkFollowStatus(targetUserId: string): Promise<boolean> {
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) return false;

    const { data } = await supabase
      .from('follows')
      .select('*')
      .eq('user_id', user.user.id)
      .eq('target_id', targetUserId)
      .maybeSingle();

    return !!data;
  }
};