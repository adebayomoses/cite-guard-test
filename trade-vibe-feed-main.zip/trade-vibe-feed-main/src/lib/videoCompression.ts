import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

let ffmpeg: FFmpeg | null = null;
let loadPromise: Promise<void> | null = null;

const loadFFmpeg = async (onProgress?: (progress: number) => void) => {
  if (ffmpeg && ffmpeg.loaded) return ffmpeg;
  
  if (loadPromise) {
    await loadPromise;
    return ffmpeg!;
  }

  ffmpeg = new FFmpeg();
  
  loadPromise = (async () => {
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    
    ffmpeg!.on('progress', ({ progress }) => {
      onProgress?.(Math.round(progress * 100));
    });

    await ffmpeg!.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
  })();

  await loadPromise;
  return ffmpeg!;
};

export interface CompressionResult {
  compressedFile: File;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
}

export interface CompressionOptions {
  maxHeight?: number;
  crf?: number;
  onProgress?: (progress: number) => void;
  onStage?: (stage: 'loading' | 'compressing') => void;
}

export const compressVideo = async (
  file: File,
  options: CompressionOptions = {}
): Promise<CompressionResult> => {
  const { 
    maxHeight = 720, 
    crf = 28, 
    onProgress, 
    onStage 
  } = options;

  onStage?.('loading');
  const ff = await loadFFmpeg(onProgress);
  
  onStage?.('compressing');
  
  const inputName = 'input.mp4';
  const outputName = 'output.mp4';
  
  await ff.writeFile(inputName, await fetchFile(file));
  
  // WhatsApp-like compression settings
  await ff.exec([
    '-i', inputName,
    '-vcodec', 'libx264',
    '-crf', crf.toString(),
    '-preset', 'fast',
    '-vf', `scale=-2:${maxHeight}`,
    '-acodec', 'aac',
    '-b:a', '128k',
    '-movflags', '+faststart',
    outputName
  ]);
  
  const data = await ff.readFile(outputName);
  const uint8Array = new Uint8Array(data as Uint8Array);
  const blob = new Blob([uint8Array], { type: 'video/mp4' });
  const compressedFile = new File([blob], file.name.replace(/\.[^/.]+$/, '.mp4'), { 
    type: 'video/mp4' 
  });
  
  // Cleanup
  await ff.deleteFile(inputName);
  await ff.deleteFile(outputName);
  
  return {
    compressedFile,
    originalSize: file.size,
    compressedSize: compressedFile.size,
    compressionRatio: Math.round((1 - compressedFile.size / file.size) * 100)
  };
};

export const shouldCompress = (file: File): boolean => {
  // Skip compression for files under 10MB
  const TEN_MB = 10 * 1024 * 1024;
  return file.size > TEN_MB;
};

export const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};
