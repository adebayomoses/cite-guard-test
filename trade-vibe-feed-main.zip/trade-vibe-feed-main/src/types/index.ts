// Base types for the trading social platform

export interface TradingPost {
  id: string;
  author: {
    username: string;
    avatar?: string;
    verified: boolean;
    reputation: number;
    isFollowed?: boolean;
  };
  content: {
    text: string;
    image?: string;
    tickers: string[];
    riskLevel: "low" | "medium" | "high";
    marketType?: string;
    tradeDirection?: string;
  };
  engagement: {
    useful: number;
    notUseful: number;
    userVote?: 1 | -1 | null;
    isSaved?: boolean;
  };
  tradeMeta?: {
    timeframe: string;
    entry_price: string;
    stop_price: string;
    target_price: string;
  };
  signalTracking?: SignalTracking;
  timestamp: string;
}

export interface PostVote {
  user_id: string;
  post_id: string;
  value: 1 | -1;
  created_at: string;
}

export interface PostScore {
  post_id: string;
  useful_count: number;
  not_useful_count: number;
  net_score: number;
  updated_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  author?: {
    username: string;
    avatar?: string;
    verified: boolean;
  };
  text: string;
  created_at: string;
  updated_at: string;
}

export interface SavedPost {
  user_id: string;
  post_id: string;
  created_at: string;
}

export interface UserMetrics {
  user_id: string;
  useful_rate_30d: number;
  useful_count_30d: number;
  not_useful_count_30d: number;
}

export interface VoteResponse {
  useful: number;
  notUseful: number;
  net: number;
  userVote: 1 | -1 | null;
}

export interface SaveResponse {
  saved: boolean;
}

export interface SignalTracking {
  id: string;
  signal_id: string;
  signal_type: 'post' | 'challenge_signal';
  ticker: string;
  entry_price: number;
  target_price: number | null;
  stop_loss: number | null;
  current_price: number | null;
  pnl_percentage: number | null;
  status: 'ongoing' | 'win' | 'loss' | 'expired';
  trade_direction: 'long' | 'short';
  market_type: string;
  created_at: string;
  updated_at: string | null;
  last_checked_at: string | null;
  closed_at: string | null;
}

export interface Conversation {
  id: string;
  isGroup: boolean;
  groupType?: 'single' | 'branch_server';
  groupInfo?: {
    name: string;
    description?: string;
    avatar_url?: string;
  };
  otherUser?: {
    id: string;
    handle: string;
    display_name?: string;
    avatar_url?: string;
  };
  lastMessage?: {
    body: string;
    created_at: string;
    author_id: string;
    attachment_path?: string;
  };
  memberCount?: number;
  unreadCount: number;
  updatedAt: string;
}