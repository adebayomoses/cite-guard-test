export interface LifestyleVideo {
  id: string;
  author_id: string;
  video_url: string;
  thumbnail_url?: string;
  caption?: string;
  hashtags: string[];
  tickers: string[];
  visibility: 'public' | 'followers';
  like_count: number;
  comment_count: number;
  duration_seconds?: number;
  created_at: string;
  updated_at: string;
  profiles?: {
    id: string;
    handle: string;
    display_name?: string;
    avatar_url?: string;
    verified_status: string;
  };
  user_liked?: boolean;
  user_following?: boolean;
}

export interface LifestyleLike {
  user_id: string;
  video_id: string;
  created_at: string;
}

export interface LifestyleComment {
  id: string;
  video_id: string;
  author_id: string;
  text: string;
  created_at: string;
  updated_at: string;
  profiles?: {
    id: string;
    handle: string;
    display_name?: string;
    avatar_url?: string;
    verified_status: string;
  };
}

export interface UploadVideoRequest {
  caption?: string;
  hashtags?: string[];
  tickers?: string[];
  visibility?: 'public' | 'followers';
  video_url: string;
  thumbnail_url?: string;
  duration_seconds?: number;
}

export interface FeedMode {
  forYou: 'forYou';
  following: 'following';
}