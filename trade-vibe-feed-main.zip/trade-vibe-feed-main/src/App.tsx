import React, { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AuthProvider } from "./contexts/AuthContext";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { useFeatureFlags } from "./hooks/useFeatureFlags";
import { ThemeProvider } from "./components/ThemeProvider";
import Feed from "./pages/Feed";
import Profile from "./pages/Profile";
import PostDetail from "./pages/PostDetail";
import LeaderboardPage from "./pages/LeaderboardPage";
import MentorshipPage from "./pages/MentorshipPage";
import CreatePost from "./pages/CreatePost";
import CreateChallenge from "./pages/CreateChallenge";
import CreateEvent from "./pages/CreateEvent";
import VerifyPage from "./pages/VerifyPage";
import NotFound from "./pages/NotFound";
import SignIn from "./pages/auth/SignIn";
import SignUp from "./pages/auth/SignUp";
import Reset from "./pages/auth/Reset";
import Onboarding from "./pages/Onboarding";
import ProfileSettings from "./pages/settings/ProfileSettings";
import PrivacySettings from "./pages/settings/PrivacySettings";
import Search from "./pages/Search";
import LifestylePage from "./pages/LifestylePage";
import LifestyleUpload from "./pages/LifestyleUpload";
import MarketWatch from "./pages/MarketWatch";
import StatusPage from "./pages/StatusPage";
import ChallengesPage from "./pages/ChallengesPage";
import ChallengeDetail from "./pages/ChallengeDetail";
import EventsPage from "./pages/EventsPage";
import EventDetail from "./pages/EventDetail";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminReports from "./pages/admin/AdminReports";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminConfig from "./pages/admin/AdminConfig";
import AdminAudit from "./pages/admin/AdminAudit";
import AdminVerifications from "./pages/admin/AdminVerifications";
import AdminContent from "./pages/admin/AdminContent";
import AdminChallenges from "./pages/admin/AdminChallenges";
import AdminEvents from "./pages/admin/AdminEvents";
import AdminStatus from "./pages/admin/AdminStatus";
import ChatListPage from "./pages/chat/ChatListPage";
import ChatRequestsPage from "./pages/chat/ChatRequestsPage";
import NewChatPage from "./pages/chat/NewChatPage";
import ChatThreadPage from "@/pages/chat/ChatThreadPage";
import { BottomNav } from "./components/BottomNav";
import { XPNotificationProvider } from "./components/status/XPNotificationProvider";

// Lazy load server pages
const ServerListPage = lazy(() => import("./pages/chat/ServerListPage"));
const ServerDetailPage = lazy(() => import("./pages/chat/ServerDetailPage"));

// Create a client for React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
});


const RouterContent = () => {
  const location = useLocation();
  const { flags, loading } = useFeatureFlags();
  const isChatThread = location.pathname.startsWith("/chat/") && location.pathname !== "/chat/new" && location.pathname !== "/chat/requests";
  const wrapperClass = isChatThread
    ? "h-screen overflow-hidden bg-background"
    : "min-h-screen bg-background pb-20";

  // Show loading only on first load
  if (loading && !flags) {
    return null;
  }

  return (
    <div className={wrapperClass}>
      <Routes>
        {/* Public Auth Routes */}
        <Route path="/auth/signin" element={<SignIn />} />
        <Route path="/auth/signup" element={<SignUp />} />
        <Route path="/auth/reset" element={<Reset />} />
        
        {/* Onboarding Route */}
        <Route path="/onboarding" element={
          <ProtectedRoute requireOnboarding={true}>
            <Onboarding />
          </ProtectedRoute>
        } />
        
        {/* Protected App Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Feed />
          </ProtectedRoute>
        } />
        <Route path="/profile" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
        <Route path="/profile/:handle" element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        } />
          <Route path="/leaderboard" element={
            <ProtectedRoute>
              <LeaderboardPage />
            </ProtectedRoute>
          } />
          <Route path="/mentorship" element={
            <ProtectedRoute>
              <MentorshipPage />
            </ProtectedRoute>
          } />
        <Route path="/create" element={<ProtectedRoute><CreatePost /></ProtectedRoute>} />
        <Route path="/verify" element={
          <ProtectedRoute>
            <VerifyPage />
          </ProtectedRoute>
        } />
        <Route path="/settings/profile" element={
          <ProtectedRoute>
            <ProfileSettings />
          </ProtectedRoute>
        } />
        <Route path="/settings/privacy" element={
          <ProtectedRoute>
            <PrivacySettings />
          </ProtectedRoute>
        } />
        <Route path="/settings" element={
          <ProtectedRoute>
            <ProfileSettings />
          </ProtectedRoute>
        } />
        <Route path="/search" element={
          <ProtectedRoute>
            <Search />
          </ProtectedRoute>
        } />
        <Route path="/notifications" element={
          <ProtectedRoute>
            <NotFound />
          </ProtectedRoute>
        } />
        <Route path="/feed" element={
          <ProtectedRoute>
            <Feed />
          </ProtectedRoute>
        } />
        <Route path="/post/:id" element={
          <ProtectedRoute>
            <PostDetail />
          </ProtectedRoute>
        } />
        
        {/* Lifestyle routes - conditionally registered */}
        {flags.lifestyle_enabled !== false && (
          <>
            <Route path="/lifestyle" element={
              <ProtectedRoute>
                <LifestylePage />
              </ProtectedRoute>
            } />
            <Route path="/lifestyle/upload" element={
              <ProtectedRoute>
                <LifestyleUpload />
              </ProtectedRoute>
            } />
          </>
        )}
        
        {/* Market Watch route - conditionally registered */}
        {flags.market_watch_enabled !== false && (
          <Route path="/market-watch" element={
            <ProtectedRoute>
              <MarketWatch />
            </ProtectedRoute>
          } />
        )}
        
        {/* Status Page */}
        <Route path="/status" element={
          <ProtectedRoute>
            <StatusPage />
          </ProtectedRoute>
        } />
        
        <Route path="/challenges" element={
          <ProtectedRoute>
            <ChallengesPage />
          </ProtectedRoute>
        } />
        <Route path="/challenges/:id" element={
          <ProtectedRoute>
            <ChallengeDetail />
          </ProtectedRoute>
        } />
        
        {/* Challenge and Event creation routes - conditionally registered */}
        <Route path="/create-challenge" element={<ProtectedRoute><CreateChallenge /></ProtectedRoute>} />
        {flags.events_enabled !== false && (
          <>
            <Route path="/create-event" element={<ProtectedRoute><CreateEvent /></ProtectedRoute>} />
            <Route path="/events" element={
              <ProtectedRoute>
                <EventsPage />
              </ProtectedRoute>
            } />
            <Route path="/events/:id" element={
              <ProtectedRoute>
                <EventDetail />
              </ProtectedRoute>
            } />
          </>
        )}
        
        {/* Chat Routes */}
        <Route path="/chat" element={
          <ProtectedRoute>
            <ChatListPage />
          </ProtectedRoute>
        } />
        <Route path="/chat/new" element={
          <ProtectedRoute>
            <NewChatPage />
          </ProtectedRoute>
        } />
        <Route path="/chat/requests" element={
          <ProtectedRoute>
            <ChatRequestsPage />
          </ProtectedRoute>
        } />
        <Route path="/chat/:id" element={
          <ProtectedRoute>
            <ChatThreadPage />
          </ProtectedRoute>
        } />
        
        {/* Branch Server Routes */}
        <Route path="/servers" element={
          <ProtectedRoute>
            <Suspense fallback={<div className="flex items-center justify-center h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
              <ServerListPage />
            </Suspense>
          </ProtectedRoute>
        } />
        <Route path="/servers/:id" element={
          <ProtectedRoute>
            <Suspense fallback={<div className="flex items-center justify-center h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>}>
              <ServerDetailPage />
            </Suspense>
          </ProtectedRoute>
        } />
        
        {/* Admin Routes */}
        <Route path="/admin" element={
          <ProtectedRoute>
            <AdminOverview />
          </ProtectedRoute>
        } />
        <Route path="/admin/reports" element={
          <ProtectedRoute>
            <AdminReports />
          </ProtectedRoute>
        } />
        <Route path="/admin/users" element={
          <ProtectedRoute>
            <AdminUsers />
          </ProtectedRoute>
        } />
        <Route path="/admin/config" element={
          <ProtectedRoute>
            <AdminConfig />
          </ProtectedRoute>
        } />
        <Route path="/admin/audit" element={
          <ProtectedRoute>
            <AdminAudit />
          </ProtectedRoute>
        } />
        <Route path="/admin/verifications" element={
          <ProtectedRoute>
            <AdminVerifications />
          </ProtectedRoute>
        } />
        <Route path="/admin/content" element={
          <ProtectedRoute>
            <AdminContent />
          </ProtectedRoute>
        } />
        <Route path="/admin/challenges" element={
          <ProtectedRoute>
            <AdminChallenges />
          </ProtectedRoute>
        } />
        <Route path="/admin/events" element={
          <ProtectedRoute>
            <AdminEvents />
          </ProtectedRoute>
        } />
        <Route path="/admin/status" element={
          <ProtectedRoute>
            <AdminStatus />
          </ProtectedRoute>
        } />
        
        {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
        <Route path="*" element={<NotFound />} />
      </Routes>
      
      <BottomNav />
    </div>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <XPNotificationProvider />
            <RouterContent />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
