import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

interface Following {
  id: string;
  handle: string;
  display_name?: string;
  avatar_url?: string;
  verified_status: string;
}

interface FollowingModalProps {
  userId: string;
}

export const FollowingModal = ({ userId }: FollowingModalProps) => {
  const [following, setFollowing] = useState<Following[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFollowing = async () => {
      try {
        // Get following by joining follows with profiles
        const { data, error } = await supabase
          .from('follows')
          .select('target_id')
          .eq('user_id', userId);

        if (error) throw error;

        if (data && data.length > 0) {
          const userIds = data.map(follow => follow.target_id);
          
          const { data: profiles, error: profilesError } = await supabase
            .from('profiles')
            .select('id, handle, display_name, avatar_url, verified_status')
            .in('id', userIds);

          if (profilesError) throw profilesError;
          setFollowing(profiles || []);
        }
      } catch (error) {
        console.error('Error fetching following:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFollowing();
  }, [userId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (following.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-8">
        Not following anyone yet
      </div>
    );
  }

  return (
    <ScrollArea className="h-80">
      <div className="space-y-3">
        {following.map((user) => (
          <div key={user.id} className="flex items-center justify-between p-2">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={user.avatar_url || undefined} />
                <AvatarFallback>
                  {user.display_name?.[0] || user.handle[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm truncate">
                    {user.display_name || user.handle}
                  </p>
                  {user.verified_status !== 'unverified' && (
                    <Badge variant="secondary" className="text-xs">
                      Verified
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">@{user.handle}</p>
              </div>
            </div>
            
            <Button variant="outline" size="sm">
              View
            </Button>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};