import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

interface TickerInputProps {
  value: string;
  onChange: (value: string) => void;
  onAdd: (ticker: string) => void;
  placeholder?: string;
}

export const TickerInput = ({ value, onChange, onAdd, placeholder }: TickerInputProps) => {
  const validateTicker = (ticker: string) => {
    // Remove $ prefix if present and convert to uppercase
    const cleanTicker = ticker.replace(/^\$/, '').toUpperCase();
    
    // Basic validation: 1-10 characters, letters/numbers only
    const tickerRegex = /^[A-Z0-9]{1,10}$/;
    return tickerRegex.test(cleanTicker) ? cleanTicker : null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const validatedTicker = validateTicker(value);
    if (validatedTicker) {
      onAdd(validatedTicker);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const validatedTicker = validateTicker(value);
      if (validatedTicker) {
        onAdd(validatedTicker);
      }
    }
  };

  const isValid = value ? validateTicker(value) !== null : false;

  return (
    <form onSubmit={handleSubmit} className="flex space-x-2">
      <Input
        type="text"
        placeholder={placeholder || "Enter ticker symbol"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyPress={handleKeyPress}
        className="flex-1"
      />
      <Button
        type="submit"
        size="sm"
        disabled={!isValid}
      >
        <Plus className="h-4 w-4" />
      </Button>
    </form>
  );
};