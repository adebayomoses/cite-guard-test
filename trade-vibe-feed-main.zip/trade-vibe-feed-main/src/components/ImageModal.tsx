import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { TrendingUp } from "lucide-react";

interface ImageModalProps {
  src: string;
  alt: string;
  className?: string;
}

export function ImageModal({ src, alt, className = "" }: ImageModalProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <div className={`relative rounded-lg overflow-hidden bg-muted cursor-pointer hover:opacity-90 transition-opacity group ${className}`}>
          <img 
            src={src} 
            alt={alt} 
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
            <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 rounded-full p-2">
              <TrendingUp className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="max-w-4xl w-full p-0 bg-transparent border-none">
        <div className="relative">
          <img 
            src={src} 
            alt={`${alt} - Full view`} 
            className="w-full h-auto max-h-[90vh] object-contain rounded-lg"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}