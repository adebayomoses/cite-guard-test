import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, MessageCircle } from "lucide-react";
import { ReputationTooltip } from "@/components/ReputationTooltip";
import { useNavigate } from "react-router-dom";
import type { Mentor } from "@/hooks/useMentors";

interface MentorCardProps {
  mentor: Mentor;
  type: 'free' | 'paid';
}

export const MentorCard = ({ mentor, type }: MentorCardProps) => {
  const navigate = useNavigate();

  const handleContact = () => {
    navigate(`/profile/${mentor.handle}`);
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src={mentor.avatar_url || undefined} />
            <AvatarFallback>
              {mentor.display_name?.[0] || mentor.handle[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-foreground truncate">
                {mentor.display_name || `@${mentor.handle}`}
              </h3>
              {mentor.verified_status === 'verified' && (
                <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-2">@{mentor.handle}</p>
            <ReputationTooltip 
              reputation={mentor.reputation_last30 || 0} 
              variant="outline"
            />
          </div>
        </div>

        {mentor.mentor_bio && (
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {mentor.mentor_bio}
          </p>
        )}

        {mentor.markets && mentor.markets.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-2">
            {mentor.markets.slice(0, 3).map((market, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs">
                {market}
              </Badge>
            ))}
            {mentor.markets.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{mentor.markets.length - 3}
              </Badge>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${mentor.mentor_available ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span className="text-sm text-muted-foreground">
              {mentor.mentor_available ? 'Available' : 'Unavailable'}
            </span>
            {type === 'paid' && mentor.mentor_price && (
              <>
                <span className="text-muted-foreground">•</span>
                <span className="text-sm font-semibold text-foreground">
                  ${mentor.mentor_price}/hr
                </span>
              </>
            )}
          </div>

          <Button 
            size="sm" 
            onClick={handleContact}
            className="gap-2"
          >
            <MessageCircle className="h-4 w-4" />
            Contact
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
