import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Clock, CheckCircle2, XCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface SignalStatusBadgeProps {
  status: 'ongoing' | 'win' | 'loss' | 'expired';
  pnl_percentage: number | null;
  current_price: number | null;
  entry_price: number;
  target_price: number | null;
  stop_loss: number | null;
  ticker: string;
  trade_direction: 'long' | 'short';
}

export const SignalStatusBadge = ({ 
  status, 
  pnl_percentage, 
  current_price,
  entry_price,
  target_price,
  stop_loss,
  ticker,
  trade_direction
}: SignalStatusBadgeProps) => {
  
  const getStatusConfig = () => {
    switch (status) {
      case 'win':
        return {
          icon: <CheckCircle2 className="h-3 w-3" />,
          label: 'TARGET HIT',
          variant: 'default' as const,
          className: 'bg-profit text-profit-foreground border-profit',
          tooltip: `🎯 Signal reached target! ${pnl_percentage ? `+${pnl_percentage.toFixed(2)}%` : ''}`
        };
      case 'loss':
        return {
          icon: <XCircle className="h-3 w-3" />,
          label: 'STOP HIT',
          variant: 'destructive' as const,
          className: 'bg-loss text-loss-foreground border-loss',
          tooltip: `🛑 Stop loss triggered. ${pnl_percentage ? `${pnl_percentage.toFixed(2)}%` : ''}`
        };
      case 'expired':
        return {
          icon: <Clock className="h-3 w-3" />,
          label: 'EXPIRED',
          variant: 'outline' as const,
          className: 'text-muted-foreground border-muted',
          tooltip: '⏰ Signal expired without hitting target or stop'
        };
      case 'ongoing':
      default:
        const isPositive = pnl_percentage && pnl_percentage > 0;
        return {
          icon: isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />,
          label: 'ACTIVE',
          variant: 'outline' as const,
          className: `${isPositive ? 'text-profit border-profit/50 bg-profit/10' : 'text-loss border-loss/50 bg-loss/10'}`,
          tooltip: `📊 Signal active: ${current_price ? `$${current_price.toLocaleString()}` : 'Checking price...'}`
        };
    }
  };

  const config = getStatusConfig();

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant={config.variant} 
            className={`gap-1 ${status === 'ongoing' ? 'animate-pulse-subtle' : ''} ${config.className}`}
          >
            {config.icon}
            <span className="text-[10px] font-bold">{config.label}</span>
            {pnl_percentage !== null && status === 'ongoing' && (
              <span className="text-[10px] font-mono ml-1">
                {pnl_percentage > 0 ? '+' : ''}{pnl_percentage.toFixed(2)}%
              </span>
            )}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="space-y-1">
            <p className="font-semibold">{config.tooltip}</p>
            <div className="text-xs space-y-0.5">
              <div>Entry: ${entry_price.toLocaleString()}</div>
              {current_price && <div>Current: ${current_price.toLocaleString()}</div>}
              {target_price && <div>Target: ${target_price.toLocaleString()}</div>}
              {stop_loss && <div>Stop: ${stop_loss.toLocaleString()}</div>}
            </div>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
