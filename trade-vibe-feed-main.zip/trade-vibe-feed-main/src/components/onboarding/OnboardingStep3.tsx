import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { TickerInput } from '@/components/TickerInput';
import { LinkFields } from '@/components/LinkFields';
import { Clock, User, Globe, X } from 'lucide-react';

interface OnboardingStep3Props {
  formData: {
    timezone: string;
    bio: string;
    links: Record<string, string>;
    watchlist: string[];
  };
  updateFormData: (updates: any) => void;
  onComplete: () => void;
  onBack: () => void;
}

const TIMEZONES = [
  'America/New_York',
  'America/Chicago', 
  'America/Denver',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Asia/Kolkata',
  'Australia/Sydney',
  'UTC',
];

export const OnboardingStep3 = ({ formData, updateFormData, onComplete, onBack }: OnboardingStep3Props) => {
  const [newTicker, setNewTicker] = useState('');

  const handleAddTicker = (ticker: string) => {
    if (ticker && !formData.watchlist.includes(ticker)) {
      updateFormData({ 
        watchlist: [...formData.watchlist, ticker] 
      });
    }
    setNewTicker('');
  };

  const handleRemoveTicker = (ticker: string) => {
    updateFormData({ 
      watchlist: formData.watchlist.filter(t => t !== ticker) 
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete();
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Final Details</h3>
        <p className="text-muted-foreground">
          Add some finishing touches to your profile
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="timezone">Timezone</Label>
          <Select
            value={formData.timezone}
            onValueChange={(value) => updateFormData({ timezone: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your timezone" />
            </SelectTrigger>
            <SelectContent>
              {TIMEZONES.map((tz) => (
                <SelectItem key={tz} value={tz}>
                  {tz.replace('_', ' ')}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bio">Bio (optional)</Label>
          <Textarea
            id="bio"
            placeholder="Tell other traders about yourself..."
            value={formData.bio}
            onChange={(e) => updateFormData({ bio: e.target.value })}
            className="min-h-[100px]"
          />
          <p className="text-xs text-muted-foreground">
            Share your trading philosophy, experience, or anything that helps others understand your approach
          </p>
        </div>

        <div className="space-y-3">
          <Label>Social Links (optional)</Label>
          <LinkFields
            links={formData.links}
            onChange={(links) => updateFormData({ links })}
          />
        </div>

        <div className="space-y-3">
          <Label>Initial Watchlist (optional)</Label>
          <TickerInput
            value={newTicker}
            onChange={setNewTicker}
            onAdd={handleAddTicker}
            placeholder="Add ticker symbols (e.g., AAPL, BTC, EURUSD)"
          />
          
          {formData.watchlist.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {formData.watchlist.map((ticker) => (
                <Badge key={ticker} variant="secondary" className="px-2 py-1">
                  ${ticker}
                  <button
                    type="button"
                    onClick={() => handleRemoveTicker(ticker)}
                    className="ml-1 hover:text-destructive"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Add symbols you want to follow. You can always modify your watchlist later.
          </p>
        </div>

        <div className="flex space-x-3">
          <Button type="button" variant="outline" onClick={onBack} className="flex-1">
            Back
          </Button>
          <Button type="submit" className="flex-1">
            Complete Setup
          </Button>
        </div>
      </form>
    </div>
  );
};