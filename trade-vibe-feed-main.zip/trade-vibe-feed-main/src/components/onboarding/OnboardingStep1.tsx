import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AvatarUploader } from '@/components/AvatarUploader';
import { useProfile } from '@/hooks/useProfile';
import { User, AtSign } from 'lucide-react';

interface OnboardingStep1Props {
  formData: {
    handle: string;
    display_name: string;
    avatar_url: string;
  };
  updateFormData: (updates: any) => void;
  onNext: () => void;
}

export const OnboardingStep1 = ({ formData, updateFormData, onNext }: OnboardingStep1Props) => {
  const [handleError, setHandleError] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const { checkHandleAvailability } = useProfile();

  const validateHandle = (handle: string) => {
    const handleRegex = /^[a-zA-Z0-9_-]{3,20}$/;
    if (!handleRegex.test(handle)) {
      return 'Handle must be 3-20 characters and contain only letters, numbers, hyphens, and underscores';
    }
    return '';
  };

  const handleHandleChange = async (value: string) => {
    const lowercaseHandle = value.toLowerCase();
    updateFormData({ handle: lowercaseHandle });
    
    const validationError = validateHandle(lowercaseHandle);
    if (validationError) {
      setHandleError(validationError);
      return;
    }

    setIsChecking(true);
    const { available, error } = await checkHandleAvailability(lowercaseHandle);
    setIsChecking(false);

    if (error) {
      setHandleError('Error checking handle availability');
    } else if (!available) {
      setHandleError('This handle is already taken');
    } else {
      setHandleError('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.handle || !formData.display_name || handleError || isChecking) {
      return;
    }
    
    onNext();
  };

  const isValid = formData.handle && formData.display_name && !handleError && !isChecking;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Create Your Profile</h3>
        <p className="text-muted-foreground">
          Set up your basic profile information and avatar
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex justify-center">
          <AvatarUploader
            currentUrl={formData.avatar_url}
            onUpload={(url) => updateFormData({ avatar_url: url })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="handle">Handle *</Label>
          <div className="relative">
            <AtSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="handle"
              type="text"
              placeholder="your_handle"
              value={formData.handle}
              onChange={(e) => handleHandleChange(e.target.value)}
              className="pl-10"
              required
            />
          </div>
          {handleError && (
            <Alert variant="destructive">
              <AlertDescription>{handleError}</AlertDescription>
            </Alert>
          )}
          {isChecking && (
            <p className="text-sm text-muted-foreground">Checking availability...</p>
          )}
          {formData.handle && !handleError && !isChecking && (
            <p className="text-sm text-green-600">Handle is available!</p>
          )}
          <p className="text-xs text-muted-foreground">
            This will be your unique identifier. Choose wisely - you can't change it later.
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="display_name">Display Name *</Label>
          <div className="relative">
            <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="display_name"
              type="text"
              placeholder="John Doe"
              value={formData.display_name}
              onChange={(e) => updateFormData({ display_name: e.target.value })}
              className="pl-10"
              required
            />
          </div>
          <p className="text-xs text-muted-foreground">
            This is how your name will appear to other users
          </p>
        </div>

        <Button type="submit" className="w-full" disabled={!isValid}>
          Continue
        </Button>
      </form>
    </div>
  );
};