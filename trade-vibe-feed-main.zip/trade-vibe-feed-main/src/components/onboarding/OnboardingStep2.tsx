import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';

interface OnboardingStep2Props {
  formData: {
    markets: string[];
    strategy_tags: string[];
    experience_level: 'beginner' | 'intermediate' | 'advanced';
  };
  updateFormData: (updates: any) => void;
  onNext: () => void;
  onBack: () => void;
}

const AVAILABLE_MARKETS = [
  'Stocks',
  'Crypto',
  'Forex',
  'Options',
  'Futures',
  'Commodities',
  'Bonds',
  'ETFs',
];

const AVAILABLE_STRATEGIES = [
  'scalper',
  'swing',
  'longterm',
  'options',
  'quant',
  'momentum',
  'value',
  'growth',
  'dividend',
  'arbitrage',
];

export const OnboardingStep2 = ({ formData, updateFormData, onNext, onBack }: OnboardingStep2Props) => {
  const handleMarketToggle = (market: string) => {
    const markets = formData.markets.includes(market)
      ? formData.markets.filter(m => m !== market)
      : [...formData.markets, market];
    updateFormData({ markets });
  };

  const handleStrategyToggle = (strategy: string) => {
    const strategy_tags = formData.strategy_tags.includes(strategy)
      ? formData.strategy_tags.filter(s => s !== strategy)
      : [...formData.strategy_tags, strategy];
    updateFormData({ strategy_tags });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Trading Preferences</h3>
        <p className="text-muted-foreground">
          Tell us about your trading style and interests
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-3">
          <Label>Markets you're interested in</Label>
          <div className="grid grid-cols-2 gap-2">
            {AVAILABLE_MARKETS.map((market) => (
              <button
                key={market}
                type="button"
                onClick={() => handleMarketToggle(market)}
                className={`p-3 rounded-md border text-sm transition-colors ${
                  formData.markets.includes(market)
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-background hover:bg-muted border-border'
                }`}
              >
                {market}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            Select all markets that interest you (you can change this later)
          </p>
        </div>

        <div className="space-y-3">
          <Label>Trading strategies</Label>
          <div className="grid grid-cols-2 gap-2">
            {AVAILABLE_STRATEGIES.map((strategy) => (
              <button
                key={strategy}
                type="button"
                onClick={() => handleStrategyToggle(strategy)}
                className={`p-3 rounded-md border text-sm transition-colors capitalize ${
                  formData.strategy_tags.includes(strategy)
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-background hover:bg-muted border-border'
                }`}
              >
                {strategy}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            Choose your preferred trading strategies
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="experience">Experience Level</Label>
          <Select
            value={formData.experience_level}
            onValueChange={(value) => updateFormData({ experience_level: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your experience level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="beginner">Beginner (less than 1 year)</SelectItem>
              <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
              <SelectItem value="advanced">Advanced (3+ years)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex space-x-3">
          <Button type="button" variant="outline" onClick={onBack} className="flex-1">
            Back
          </Button>
          <Button type="submit" className="flex-1">
            Continue
          </Button>
        </div>
      </form>
    </div>
  );
};