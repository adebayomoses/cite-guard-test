import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { X, Users, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface Profile {
  id: string;
  handle: string;
  display_name: string | null;
  avatar_url: string | null;
}

interface CollaboratorSelectorProps {
  selectedCollaborators: Profile[];
  onCollaboratorsChange: (collaborators: Profile[]) => void;
  maxCollaborators?: number;
}

export const CollaboratorSelector = ({
  selectedCollaborators,
  onCollaboratorsChange,
  maxCollaborators = 5,
}: CollaboratorSelectorProps) => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Debounced search
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("id, handle, display_name, avatar_url")
          .or(`handle.ilike.%${searchQuery}%,display_name.ilike.%${searchQuery}%`)
          .neq("id", user?.id || "") // Exclude current user
          .limit(10);

        if (!error && data) {
          // Filter out already selected collaborators
          const selectedIds = selectedCollaborators.map((c) => c.id);
          const filtered = data.filter((profile) => !selectedIds.includes(profile.id));
          setSearchResults(filtered);
        }
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, user?.id, selectedCollaborators]);

  const handleAddCollaborator = (profile: Profile) => {
    if (selectedCollaborators.length < maxCollaborators) {
      onCollaboratorsChange([...selectedCollaborators, profile]);
      setSearchQuery("");
      setSearchResults([]);
    }
  };

  const handleRemoveCollaborator = (profileId: string) => {
    onCollaboratorsChange(selectedCollaborators.filter((c) => c.id !== profileId));
  };

  return (
    <div className="space-y-3">
      <Label htmlFor="collaborators" className="flex items-center gap-2">
        <Users className="h-4 w-4" />
        Add Collaborators (Optional)
        <span className="text-xs text-muted-foreground ml-2">
          {selectedCollaborators.length}/{maxCollaborators}
        </span>
      </Label>

      <div className="space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            id="collaborators"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by username..."
            disabled={selectedCollaborators.length >= maxCollaborators}
            className="pl-9"
          />
        </div>

        {/* Search Results */}
        {searchResults.length > 0 && (
          <div className="border border-border rounded-lg bg-card max-h-48 overflow-y-auto">
            {searchResults.map((profile) => (
              <button
                key={profile.id}
                onClick={() => handleAddCollaborator(profile)}
                className="w-full flex items-center gap-3 p-3 hover:bg-muted/50 transition-colors text-left"
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src={profile.avatar_url || undefined} />
                  <AvatarFallback className="text-xs">
                    {profile.handle?.[0]?.toUpperCase() || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {profile.display_name || profile.handle}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">@{profile.handle}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Empty State */}
        {searchQuery.length >= 2 && searchResults.length === 0 && !isSearching && (
          <div className="text-center py-4 text-sm text-muted-foreground">
            No users found
          </div>
        )}

        {/* Selected Collaborators */}
        {selectedCollaborators.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Selected collaborators:</p>
            <div className="flex flex-wrap gap-2">
              {selectedCollaborators.map((profile) => (
                <div
                  key={profile.id}
                  className="flex items-center gap-2 bg-muted px-3 py-1.5 rounded-full"
                >
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={profile.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">
                      {profile.handle?.[0]?.toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium">@{profile.handle}</span>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-4 w-4 p-0 hover:bg-transparent"
                    onClick={() => handleRemoveCollaborator(profile.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Help Text */}
        <p className="text-xs text-muted-foreground">
          Collaborators can post signals and manage the challenge alongside you.
        </p>
      </div>
    </div>
  );
};
