import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';

interface ReputationTooltipProps {
  reputation: number;
  className?: string;
  variant?: 'default' | 'outline' | 'secondary' | 'destructive';
}

export const ReputationTooltip = ({ 
  reputation, 
  className = "",
  variant = "outline" 
}: ReputationTooltipProps) => {
  const getReputationBadge = (rep: number) => {
    if (rep >= 80) return { label: "Elite", color: "bg-profit text-profit-foreground" };
    if (rep >= 60) return { label: "Pro", color: "bg-primary text-primary-foreground" };
    if (rep >= 40) return { label: "Rising", color: "bg-accent text-accent-foreground" };
    return { label: "New", color: "bg-muted text-muted-foreground" };
  };

  const repBadge = getReputationBadge(reputation);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center gap-2 cursor-help">
            <Badge 
              variant={variant} 
              className={`text-xs ${repBadge.color} border-none ${className}`}
            >
              {repBadge.label}
            </Badge>
            <span className="text-xs text-muted-foreground">{reputation}% rep</span>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>Rep = Trading performance, community engagement, content quality & activity (30-day rolling)</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};