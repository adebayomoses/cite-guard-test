import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';

interface ReputationPillWithSparklineProps {
  reputation: number;
  sparklineData: number[];
  className?: string;
}

const Sparkline = ({ data }: { data: number[] }) => {
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * 100;
    const y = 100 - ((value - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg 
      width="60" 
      height="20" 
      className="inline-block ml-2"
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
    >
      <polyline
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        points={points}
        className="text-primary"
      />
    </svg>
  );
};

export const ReputationPillWithSparkline = ({ 
  reputation, 
  sparklineData, 
  className = '' 
}: ReputationPillWithSparklineProps) => {
  const getReputationBadge = (rep: number) => {
    if (rep >= 80) return { label: "Elite", color: "bg-profit text-profit-foreground" };
    if (rep >= 60) return { label: "Pro", color: "bg-primary text-primary-foreground" };
    if (rep >= 40) return { label: "Rising", color: "bg-accent text-accent-foreground" };
    return { label: "New", color: "bg-muted text-muted-foreground" };
  };

  const repBadge = getReputationBadge(reputation);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`flex items-center gap-2 cursor-help ${className}`}>
            <Badge 
              variant="outline" 
              className={`text-xs ${repBadge.color} border-none`}
            >
              {repBadge.label}
            </Badge>
            <div className="flex items-center text-xs text-muted-foreground">
              <span>{reputation}% rep</span>
              <Sparkline data={sparklineData} />
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>Rep = Trading performance, community engagement, content quality & activity (30-day rolling)</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};