import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useState } from 'react';
import { FollowersModal } from './FollowersModal';
import { FollowingModal } from './FollowingModal';

interface StatsRowProps {
  stats: {
    posts: number;
    followers: number;
    following: number;
  };
  userId: string;
  showFollowModals?: boolean;
}

export const StatsRow = ({ stats, userId, showFollowModals = true }: StatsRowProps) => {
  const [followersOpen, setFollowersOpen] = useState(false);
  const [followingOpen, setFollowingOpen] = useState(false);

  return (
    <div className="flex items-center gap-6 py-4 text-center">
      <div>
        <div className="text-lg font-bold">{stats.posts}</div>
        <div className="text-sm text-muted-foreground">Posts</div>
      </div>
      
      {showFollowModals ? (
        <>
          <Dialog open={followersOpen} onOpenChange={setFollowersOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" className="flex flex-col h-auto p-2">
                <div className="text-lg font-bold">{stats.followers}</div>
                <div className="text-sm text-muted-foreground">Followers</div>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Followers</DialogTitle>
              </DialogHeader>
              <FollowersModal userId={userId} />
            </DialogContent>
          </Dialog>

          <Dialog open={followingOpen} onOpenChange={setFollowingOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" className="flex flex-col h-auto p-2">
                <div className="text-lg font-bold">{stats.following}</div>
                <div className="text-sm text-muted-foreground">Following</div>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Following</DialogTitle>
              </DialogHeader>
              <FollowingModal userId={userId} />
            </DialogContent>
          </Dialog>
        </>
      ) : (
        <>
          <div>
            <div className="text-lg font-bold">{stats.followers}</div>
            <div className="text-sm text-muted-foreground">Followers</div>
          </div>
          <div>
            <div className="text-lg font-bold">{stats.following}</div>
            <div className="text-sm text-muted-foreground">Following</div>
          </div>
        </>
      )}
    </div>
  );
};