import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Bell, Trash2, TrendingUp, TrendingDown } from "lucide-react";
import { usePriceAlerts } from "@/hooks/usePriceAlerts";
import { formatDistanceToNow } from "date-fns";

export const AlertsManager = () => {
  const { alerts, createAlert, deleteAlert, isCreating, isDeleting, isLoading } = usePriceAlerts();
  const [ticker, setTicker] = useState("");
  const [marketType, setMarketType] = useState("stocks");
  const [condition, setCondition] = useState<"above" | "below">("above");
  const [targetPrice, setTargetPrice] = useState("");

  const handleCreateAlert = () => {
    if (!ticker || !targetPrice) return;

    createAlert({
      ticker: ticker.toUpperCase(),
      market_type: marketType,
      condition,
      target_price: parseFloat(targetPrice),
    });

    // Reset form
    setTicker("");
    setTargetPrice("");
  };

  const activeAlerts = alerts.filter(a => !a.triggered);
  const triggeredAlerts = alerts.filter(a => a.triggered);

  return (
    <div className="space-y-6">
      {/* Create Alert Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Create Price Alert
          </CardTitle>
          <CardDescription>
            Get notified when a price reaches your target
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ticker">Ticker Symbol</Label>
              <Input
                id="ticker"
                placeholder="e.g., AAPL, EUR/USD, BTC"
                value={ticker}
                onChange={(e) => setTicker(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="market-type">Market Type</Label>
              <Select value={marketType} onValueChange={setMarketType}>
                <SelectTrigger id="market-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stocks">Stocks</SelectItem>
                  <SelectItem value="forex">Forex</SelectItem>
                  <SelectItem value="crypto">Crypto</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="condition">Condition</Label>
              <Select 
                value={condition} 
                onValueChange={(val) => setCondition(val as "above" | "below")}
              >
                <SelectTrigger id="condition">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="above">Price goes above</SelectItem>
                  <SelectItem value="below">Price goes below</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="target-price">Target Price</Label>
              <Input
                id="target-price"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
              />
            </div>
          </div>

          <Button 
            onClick={handleCreateAlert} 
            disabled={!ticker || !targetPrice || isCreating}
            className="w-full"
          >
            {isCreating ? "Creating..." : "Create Alert"}
          </Button>
        </CardContent>
      </Card>

      {/* Active Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Active Alerts ({activeAlerts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Loading alerts...</p>
          ) : activeAlerts.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active alerts</p>
          ) : (
            <div className="space-y-3">
              {activeAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="flex items-center justify-between p-4 border rounded-lg bg-card"
                >
                  <div className="flex items-center gap-3">
                    {alert.condition === 'above' ? (
                      <TrendingUp className="h-5 w-5 text-success" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-destructive" />
                    )}
                    <div>
                      <div className="font-medium">
                        {alert.ticker}
                        <Badge variant="outline" className="ml-2 text-xs">
                          {alert.market_type}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Notify when {alert.condition} ${alert.target_price.toFixed(2)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Created {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => deleteAlert(alert.id)}
                    disabled={isDeleting}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Triggered Alerts */}
      {triggeredAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Triggered Alerts ({triggeredAlerts.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {triggeredAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="flex items-center justify-between p-4 border rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-3">
                    <Bell className="h-5 w-5 text-primary" />
                    <div>
                      <div className="font-medium">
                        {alert.ticker}
                        <Badge variant="outline" className="ml-2 text-xs">
                          {alert.market_type}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Triggered {alert.condition} ${alert.target_price.toFixed(2)}
                      </div>
                      {alert.triggered_at && (
                        <div className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(alert.triggered_at), { addSuffix: true })}
                        </div>
                      )}
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => deleteAlert(alert.id)}
                    disabled={isDeleting}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
