import { Card } from "@/components/ui/card";

export const NewsFeed = () => {
  return (
    <Card className="overflow-hidden">
      <div className="w-full min-h-[700px] h-[calc(100vh-280px)]">
        <iframe 
          src="https://widget.myfxbook.com/widget/calendar.html?lang=en&impacts=0,1,2,3&symbols=AUD,CAD,CHF,CNY,EUR,GBP,JPY,NZD,USD" 
          style={{ border: 0, width: '100%', height: '100%' }}
          title="Economic Calendar"
        />
      </div>
      <div className="text-center py-2 text-sm text-muted-foreground">
        <a 
          href="https://www.myfxbook.com/forex-economic-calendar" 
          target="_blank" 
          rel="noopener noreferrer"
          className="font-semibold hover:underline"
        >
          Economic Calendar
        </a>
        {" "}by Myfxbook.com
      </div>
    </Card>
  );
};