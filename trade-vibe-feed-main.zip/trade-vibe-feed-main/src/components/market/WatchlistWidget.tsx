import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useMarketPrices } from "@/hooks/useMarketPrices";
import { useWatchlist } from "@/hooks/useWatchlist";
import { TrendingUp, TrendingDown, Trash2, Star } from "lucide-react";

export const WatchlistWidget = () => {
  const { data: allPrices, isLoading: pricesLoading } = useMarketPrices('all');
  const { watchlist, removeFromWatchlist, isLoading: watchlistLoading, isRemoving } = useWatchlist();

  const watchlistPrices = allPrices?.filter(price => 
    watchlist.includes(price.symbol)
  );

  const isLoading = pricesLoading || watchlistLoading;

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="p-4">
            <Skeleton className="h-6 w-24 mb-2" />
            <Skeleton className="h-8 w-32 mb-1" />
            <Skeleton className="h-5 w-20" />
          </Card>
        ))}
      </div>
    );
  }

  if (watchlist.length === 0) {
    return (
      <div className="text-center py-12">
        <Star className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-semibold mb-2">Your Watchlist is Empty</h3>
        <p className="text-muted-foreground mb-4">
          Add currencies to your watchlist from the Prices tab
        </p>
      </div>
    );
  }

  if (!watchlistPrices || watchlistPrices.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">
          Loading watchlist prices...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">
          Your Watchlist ({watchlistPrices.length})
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {watchlistPrices.map((price) => {
          const isPositive = price.percent_change_24h >= 0;
          
          return (
            <Card 
              key={price.symbol}
              className="p-4 hover:bg-accent/50 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <p className="font-semibold text-sm text-muted-foreground">
                    {price.symbol}
                  </p>
                  <p className="text-xs text-muted-foreground">{price.name}</p>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`flex items-center gap-1 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                    {isPositive ? (
                      <TrendingUp className="h-4 w-4" />
                    ) : (
                      <TrendingDown className="h-4 w-4" />
                    )}
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7 shrink-0 text-destructive hover:text-destructive"
                    onClick={() => removeFromWatchlist(price.symbol)}
                    disabled={isRemoving}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-2xl font-bold">
                  ${price.current_price.toLocaleString(undefined, { 
                    minimumFractionDigits: 2,
                    maximumFractionDigits: price.current_price < 1 ? 6 : 2 
                  })}
                </p>
                <div className="flex gap-2 text-sm">
                  <span className={isPositive ? 'text-green-600' : 'text-red-600'}>
                    {isPositive ? '+' : ''}{price.percent_change_24h.toFixed(2)}%
                  </span>
                  <span className={isPositive ? 'text-green-600' : 'text-red-600'}>
                    {isPositive ? '+' : ''}${Math.abs(price.price_change_24h).toFixed(2)}
                  </span>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
