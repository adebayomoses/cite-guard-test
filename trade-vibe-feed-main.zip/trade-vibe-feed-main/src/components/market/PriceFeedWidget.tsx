import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useMarketPrices, MarketType } from "@/hooks/useMarketPrices";
import { useWatchlist } from "@/hooks/useWatchlist";
import { Search, TrendingUp, TrendingDown, Plus, Check } from "lucide-react";

export const PriceFeedWidget = () => {
  const [selectedMarket, setSelectedMarket] = useState<MarketType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const { data: prices, isLoading, error } = useMarketPrices(selectedMarket);
  const { addToWatchlist, removeFromWatchlist, isInWatchlist, isAdding, isRemoving } = useWatchlist();

  const filteredPrices = prices?.filter(price => 
    price.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    price.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (error) {
    return (
      <div className="text-center py-8 text-destructive">
        Failed to load market prices. Please try again later.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        {(['all', 'crypto', 'forex', 'stocks'] as MarketType[]).map((market) => (
          <Button
            key={market}
            variant={selectedMarket === market ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedMarket(market)}
            className="capitalize"
          >
            {market}
          </Button>
        ))}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search symbols..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Price Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="p-4">
              <Skeleton className="h-6 w-24 mb-2" />
              <Skeleton className="h-8 w-32 mb-1" />
              <Skeleton className="h-5 w-20" />
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPrices?.map((price) => {
            const isPositive = price.percent_change_24h >= 0;
            const inWatchlist = isInWatchlist(price.symbol);
            
            return (
              <Card 
                key={price.symbol}
                className="p-4 hover:bg-accent/50 transition-colors"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className="font-semibold text-sm text-muted-foreground">
                      {price.symbol}
                    </p>
                    <p className="text-xs text-muted-foreground">{price.name}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`flex items-center gap-1 ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                      {isPositive ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                    </div>
                    <Button
                      size="icon"
                      variant={inWatchlist ? "default" : "outline"}
                      className="h-7 w-7 shrink-0"
                      onClick={() => inWatchlist ? removeFromWatchlist(price.symbol) : addToWatchlist(price.symbol)}
                      disabled={isAdding || isRemoving}
                    >
                      {inWatchlist ? (
                        <Check className="h-3.5 w-3.5" />
                      ) : (
                        <Plus className="h-3.5 w-3.5" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-2xl font-bold">
                    ${price.current_price.toLocaleString(undefined, { 
                      minimumFractionDigits: 2,
                      maximumFractionDigits: price.current_price < 1 ? 6 : 2 
                    })}
                  </p>
                  <div className="flex gap-2 text-sm">
                    <span className={isPositive ? 'text-green-600' : 'text-red-600'}>
                      {isPositive ? '+' : ''}{price.percent_change_24h.toFixed(2)}%
                    </span>
                    <span className={isPositive ? 'text-green-600' : 'text-red-600'}>
                      {isPositive ? '+' : ''}${Math.abs(price.price_change_24h).toFixed(2)}
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {!isLoading && filteredPrices?.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          No results found
        </div>
      )}
    </div>
  );
};