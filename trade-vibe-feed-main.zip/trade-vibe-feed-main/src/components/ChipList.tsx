import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

interface ChipListProps {
  title: string;
  items: string[];
  emptyMessage?: string;
  showAddButton?: boolean;
  onAddClick?: () => void;
  variant?: 'default' | 'secondary' | 'outline';
}

export const ChipList = ({ 
  title, 
  items, 
  emptyMessage,
  showAddButton,
  onAddClick,
  variant = 'secondary'
}: ChipListProps) => {
  const isEmpty = !items || items.length === 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm">{title}</h3>
        {showAddButton && (
          <Button
            variant="outline"
            size="sm"
            onClick={onAddClick}
            className="h-7 text-xs"
          >
            <Plus className="h-3 w-3 mr-1" />
            Add
          </Button>
        )}
      </div>
      
      {isEmpty ? (
        <div className="text-sm text-muted-foreground italic">
          {emptyMessage || `No ${title.toLowerCase()} added yet`}
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {items.map((item, index) => (
            <Badge key={index} variant={variant} className="text-xs">
              {item}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
};