import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, DollarSign, TrendingUp, TrendingDown, Target, Shield, Clock, BarChart } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SignalFormProps {
  onSubmit: (signalData: any) => Promise<void>;
  isLoading: boolean;
}

export function SignalForm({ onSubmit, isLoading }: SignalFormProps) {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [marketType, setMarketType] = useState('stocks');
  const [tradeDirection, setTradeDirection] = useState('long');
  const [riskLevel, setRiskLevel] = useState('medium_risk');
  const [timeframe, setTimeframe] = useState('');
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 5MB",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('post-images')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('post-images')
        .getPublicUrl(fileName);

      setImageUrl(publicUrl);
      toast({
        title: "Image uploaded successfully",
        description: "Your chart has been uploaded"
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please add signal content",
        variant: "destructive"
      });
      return;
    }

    const signalData = {
      content: content.trim(),
      image_url: imageUrl || null,
      market_type: marketType,
      trade_direction: tradeDirection,
      risk_level: riskLevel,
      timeframe: timeframe || null,
      entry_price: entryPrice ? parseFloat(entryPrice) : null,
      stop_loss: stopLoss ? parseFloat(stopLoss) : null,
      target_price: targetPrice ? parseFloat(targetPrice) : null
    };

    await onSubmit(signalData);
    
    // Reset form
    setContent('');
    setImageUrl('');
    setMarketType('stocks');
    setTradeDirection('long');
    setRiskLevel('medium_risk');
    setTimeframe('');
    setEntryPrice('');
    setStopLoss('');
    setTargetPrice('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Chart/Screenshot Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-sm">
            <BarChart className="h-4 w-4" />
            Chart or Screenshot
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover:border-muted-foreground/50 transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="h-8 w-8 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground mb-2">Upload your trading chart or screenshot</p>
            <Button type="button" variant="secondary" size="sm">
              Choose File
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>
          {imageUrl && (
            <div className="mt-4">
              <img src={imageUrl} alt="Uploaded chart" className="w-full max-w-md mx-auto rounded-lg" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Market Type & Trade Direction */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Market Type
          </Label>
          <Select value={marketType} onValueChange={setMarketType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="stocks">📈 Stocks</SelectItem>
              <SelectItem value="crypto">₿ Crypto</SelectItem>
              <SelectItem value="forex">💱 Forex</SelectItem>
              <SelectItem value="options">⚡ Options</SelectItem>
              <SelectItem value="futures">📊 Futures</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Trade Direction</Label>
          <RadioGroup 
            value={tradeDirection} 
            onValueChange={setTradeDirection}
            className="flex gap-6"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="long" id="long" />
              <Label htmlFor="long" className="flex items-center gap-2 cursor-pointer">
                <TrendingUp className="h-4 w-4 text-green-500" />
                Long/Buy
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="short" id="short" />
              <Label htmlFor="short" className="flex items-center gap-2 cursor-pointer">
                <TrendingDown className="h-4 w-4 text-red-500" />
                Short/Sell
              </Label>
            </div>
          </RadioGroup>
        </div>
      </div>

      {/* Risk Level */}
      <div className="space-y-2">
        <Label className="flex items-center gap-2">
          <Shield className="h-4 w-4" />
          Risk Level
        </Label>
        <RadioGroup 
          value={riskLevel} 
          onValueChange={setRiskLevel}
          className="flex gap-6"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="low_risk" id="low" />
            <Label htmlFor="low" className="cursor-pointer">Low Risk</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="medium_risk" id="medium" />
            <Label htmlFor="medium" className="cursor-pointer">Medium Risk</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="high_risk" id="high" />
            <Label htmlFor="high" className="cursor-pointer">High Risk</Label>
          </div>
        </RadioGroup>
      </div>

      {/* Trading Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-sm">
            <Target className="h-4 w-4" />
            Trading Details (Optional)
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Timeframe
            </Label>
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger>
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1m">1 Minute</SelectItem>
                <SelectItem value="5m">5 Minutes</SelectItem>
                <SelectItem value="15m">15 Minutes</SelectItem>
                <SelectItem value="1h">1 Hour</SelectItem>
                <SelectItem value="4h">4 Hours</SelectItem>
                <SelectItem value="1d">1 Day</SelectItem>
                <SelectItem value="1w">1 Week</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Entry Price
            </Label>
            <Input
              type="number"
              step="0.01"
              placeholder="$43,200"
              value={entryPrice}
              onChange={(e) => setEntryPrice(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Stop Loss
            </Label>
            <Input
              type="number"
              step="0.01"
              placeholder="$41,800"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Target Price
            </Label>
            <Input
              type="number"
              step="0.01"
              placeholder="$48,000"
              value={targetPrice}
              onChange={(e) => setTargetPrice(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Signal Content */}
      <div className="space-y-2">
        <Label>Signal Analysis</Label>
        <Textarea
          placeholder="Share your trading signal analysis..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-24"
        />
      </div>

      <Button 
        type="submit" 
        disabled={!content.trim() || isLoading || uploading}
        className="w-full"
      >
        {isLoading ? 'Posting Signal...' : 'Post Signal'}
      </Button>
    </form>
  );
}