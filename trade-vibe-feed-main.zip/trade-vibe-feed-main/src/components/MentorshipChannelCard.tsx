import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Lock, Check } from "lucide-react";
import { ReputationTooltip } from "@/components/ReputationTooltip";
import { MentorshipChannel } from "@/hooks/useMentorshipChannels";

interface Props {
  channel: MentorshipChannel;
  onJoin: (channelId: string) => void;
  isJoining: boolean;
}

export const MentorshipChannelCard = ({ channel, onJoin, isJoining }: Props) => {
  const { mentor, memberCount, isFull, isUserMember, mentorship_price, max_mentees } = channel;
  
  const getActionButton = () => {
    if (isUserMember) {
      return (
        <Button variant="outline" className="w-full" disabled>
          <Check className="h-4 w-4 mr-2" />
          Joined
        </Button>
      );
    }
    
    if (isFull) {
      return (
        <Button variant="outline" className="w-full" disabled>
          Full ({memberCount}/{max_mentees})
        </Button>
      );
    }
    
    if (channel.mentorship_type === 'paid') {
      return (
        <Button 
          className="w-full" 
          onClick={() => onJoin(channel.conversation_id)}
          disabled={isJoining}
        >
          <Lock className="h-4 w-4 mr-2" />
          Join - ${mentorship_price}/{channel.mentorship_billing_cycle}
        </Button>
      );
    }
    
    return (
      <Button 
        className="w-full"
        onClick={() => onJoin(channel.conversation_id)}
        disabled={isJoining}
      >
        Join Free
      </Button>
    );
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start gap-3">
          <Avatar className="h-12 w-12">
            <AvatarImage src={channel.avatar_url} />
            <AvatarFallback>{channel.name[0]}</AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold truncate">{channel.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-muted-foreground">by @{mentor.handle}</span>
              {mentor.verified_status === 'verified' && (
                <Badge variant="secondary" className="text-xs">✓ Verified</Badge>
              )}
            </div>
            <ReputationTooltip reputation={mentor.reputation_last30} />
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {channel.description || "No description provided"}
        </p>
        
        {mentor.markets && mentor.markets.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {mentor.markets.slice(0, 3).map((market) => (
              <Badge key={market} variant="outline" className="text-xs">
                {market}
              </Badge>
            ))}
          </div>
        )}
        
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{memberCount} members</span>
          </div>
          
          {!isFull && max_mentees && (
            <span className="text-xs text-muted-foreground">
              {max_mentees - memberCount} spots left
            </span>
          )}
        </div>
      </CardContent>
      
      <CardFooter>
        {getActionButton()}
      </CardFooter>
    </Card>
  );
};
