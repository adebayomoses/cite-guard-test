import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { X, Plus, Twitter, Globe, TrendingUp } from 'lucide-react';

interface LinkFieldsProps {
  links: Record<string, string>;
  onChange: (links: Record<string, string>) => void;
}

const LINK_TYPES = [
  { key: 'twitter', label: 'Twitter/X', icon: Twitter, placeholder: 'https://twitter.com/username' },
  { key: 'website', label: 'Website', icon: Globe, placeholder: 'https://yourwebsite.com' },
  { key: 'tradingview', label: 'TradingView', icon: TrendingUp, placeholder: 'https://tradingview.com/u/username' },
];

export const LinkFields = ({ links, onChange }: LinkFieldsProps) => {
  const [customKey, setCustomKey] = useState('');
  const [customValue, setCustomValue] = useState('');

  const updateLink = (key: string, value: string) => {
    const newLinks = { ...links };
    if (value) {
      newLinks[key] = value;
    } else {
      delete newLinks[key];
    }
    onChange(newLinks);
  };

  const addCustomLink = () => {
    if (customKey && customValue && !links[customKey]) {
      updateLink(customKey, customValue);
      setCustomKey('');
      setCustomValue('');
    }
  };

  const removeLink = (key: string) => {
    const newLinks = { ...links };
    delete newLinks[key];
    onChange(newLinks);
  };

  return (
    <div className="space-y-4">
      {/* Predefined link types */}
      {LINK_TYPES.map(({ key, label, icon: Icon, placeholder }) => (
        <div key={key} className="space-y-2">
          <Label htmlFor={key} className="flex items-center space-x-2">
            <Icon className="h-4 w-4" />
            <span>{label}</span>
          </Label>
          <div className="flex space-x-2">
            <Input
              id={key}
              type="url"
              placeholder={placeholder}
              value={links[key] || ''}
              onChange={(e) => updateLink(key, e.target.value)}
              className="flex-1"
            />
            {links[key] && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => removeLink(key)}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      ))}

      {/* Custom links */}
      {Object.entries(links).map(([key, value]) => {
        if (LINK_TYPES.some(type => type.key === key)) return null;
        
        return (
          <Card key={key}>
            <CardContent className="pt-4">
              <div className="flex items-center space-x-2">
                <div className="flex-1">
                  <Label className="text-sm font-medium capitalize">{key}</Label>
                  <Input
                    type="url"
                    value={value}
                    onChange={(e) => updateLink(key, e.target.value)}
                    className="mt-1"
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => removeLink(key)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {/* Add custom link */}
      <Card>
        <CardContent className="pt-4">
          <Label className="text-sm font-medium">Add Custom Link</Label>
          <div className="flex space-x-2 mt-2">
            <Input
              placeholder="Label (e.g., LinkedIn)"
              value={customKey}
              onChange={(e) => setCustomKey(e.target.value.toLowerCase())}
              className="flex-1"
            />
            <Input
              type="url"
              placeholder="URL"
              value={customValue}
              onChange={(e) => setCustomValue(e.target.value)}
              className="flex-1"
            />
            <Button
              type="button"
              size="sm"
              onClick={addCustomLink}
              disabled={!customKey || !customValue || !!links[customKey]}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};