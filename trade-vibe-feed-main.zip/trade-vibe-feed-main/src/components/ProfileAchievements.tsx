import { useProfileAchievements } from '@/hooks/useProfileAchievements';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Trophy, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ProfileAchievementsProps {
  userId: string;
  showViewAll?: boolean;
}

const rarityColors: Record<string, string> = {
  common: 'bg-muted',
  uncommon: 'bg-green-500/20 ring-1 ring-green-500/40',
  rare: 'bg-blue-500/20 ring-1 ring-blue-500/40',
  epic: 'bg-purple-500/20 ring-1 ring-purple-500/40',
  legendary: 'bg-amber-500/20 ring-1 ring-amber-500/40',
};

const rarityGlow: Record<string, string> = {
  common: '',
  uncommon: 'hover:shadow-green-500/20',
  rare: 'hover:shadow-blue-500/30',
  epic: 'hover:shadow-purple-500/30',
  legendary: 'hover:shadow-amber-500/40',
};

export function ProfileAchievements({ userId, showViewAll = true }: ProfileAchievementsProps) {
  const navigate = useNavigate();
  const { achievements, userAchievements, unlockedCount, totalCount, loading } = useProfileAchievements(userId);

  if (loading) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-5 w-12" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-10 w-10 rounded-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const unlockedIds = new Set(userAchievements?.map(ua => ua.achievement_id) || []);
  const unlockedAchievements = userAchievements?.map(ua => ua.achievement) || [];

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Trophy className="h-4 w-4 text-amber-500" />
            Achievements
          </CardTitle>
          <span className="text-sm text-muted-foreground">
            {unlockedCount}/{totalCount}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2">
          {/* Scrollable achievements row */}
          <div className="flex-1 overflow-x-auto scrollbar-hide">
            <div className="flex gap-2 pb-1">
              {unlockedAchievements.length > 0 ? (
                <TooltipProvider delayDuration={200}>
                  {unlockedAchievements.map((achievement) => (
                    <Tooltip key={achievement.id}>
                      <TooltipTrigger asChild>
                        <div
                          className={`
                            flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center
                            text-lg cursor-pointer transition-all duration-200
                            hover:scale-110 hover:shadow-lg
                            ${rarityColors[achievement.rarity] || rarityColors.common}
                            ${rarityGlow[achievement.rarity] || ''}
                          `}
                        >
                          {achievement.icon}
                        </div>
                      </TooltipTrigger>
                      <TooltipContent side="bottom" className="max-w-[200px]">
                        <div className="space-y-1">
                          <p className="font-semibold">{achievement.name}</p>
                          <p className="text-xs text-muted-foreground">{achievement.description}</p>
                          <p className="text-xs text-amber-500">+{achievement.xp_reward} XP</p>
                        </div>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </TooltipProvider>
              ) : (
                <p className="text-sm text-muted-foreground py-2">No achievements yet</p>
              )}
            </div>
          </div>

          {/* View All button */}
          {showViewAll && totalCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="flex-shrink-0 text-muted-foreground hover:text-foreground"
              onClick={() => navigate('/status')}
            >
              View All
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
