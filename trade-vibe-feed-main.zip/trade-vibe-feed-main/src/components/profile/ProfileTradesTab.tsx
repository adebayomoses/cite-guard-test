import { useState } from 'react';
import { useUserTrades, Trade, TradeInput } from '@/hooks/useUserTrades';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { TrendingUp, TrendingDown, BarChart2, Plus, Lock, Trash2 } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';

interface ProfileTradesTabProps {
  userId: string;
  isOwnProfile: boolean;
}

export const ProfileTradesTab = ({ userId, isOwnProfile }: ProfileTradesTabProps) => {
  const { trades, loading, error, createTrade, deleteTrade } = useUserTrades(userId, isOwnProfile);
  const [displayCount, setDisplayCount] = useState(5);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState<TradeInput>({
    ticker: '',
    market_type: 'stocks',
    direction: 'long',
    entry_price: 0,
    exit_price: null,
    quantity: 1,
    entry_date: new Date().toISOString().split('T')[0],
    exit_date: null,
    notes: '',
    is_public: false,
    status: 'closed',
  });

  const handleCreate = async () => {
    if (!formData.ticker || formData.entry_price <= 0) return;
    
    // Calculate P&L
    let pnl_amount = null;
    let pnl_percent = null;
    if (formData.exit_price) {
      const multiplier = formData.direction === 'long' ? 1 : -1;
      pnl_amount = (formData.exit_price - formData.entry_price) * formData.quantity * multiplier;
      pnl_percent = ((formData.exit_price - formData.entry_price) / formData.entry_price) * 100 * multiplier;
    }

    await createTrade({
      ...formData,
      pnl_amount,
      pnl_percent,
    });
    setDialogOpen(false);
    setFormData({
      ticker: '',
      market_type: 'stocks',
      direction: 'long',
      entry_price: 0,
      exit_price: null,
      quantity: 1,
      entry_date: new Date().toISOString().split('T')[0],
      exit_date: null,
      notes: '',
      is_public: false,
      status: 'closed',
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-24 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load trades
      </div>
    );
  }

  // Stats summary
  const closedTrades = trades.filter(t => t.status === 'closed' && t.pnl_amount !== null);
  const totalPnL = closedTrades.reduce((sum, t) => sum + (t.pnl_amount || 0), 0);
  const winningTrades = closedTrades.filter(t => (t.pnl_amount || 0) > 0).length;
  const winRate = closedTrades.length > 0 ? (winningTrades / closedTrades.length * 100).toFixed(1) : 0;

  return (
    <div className="space-y-4">
      {/* Stats Summary */}
      {trades.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">Total P&L</div>
              <div className={`font-bold ${totalPnL >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {totalPnL >= 0 ? '+' : ''}{totalPnL.toFixed(2)}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">Win Rate</div>
              <div className="font-bold">{winRate}%</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <div className="text-xs text-muted-foreground">Total Trades</div>
              <div className="font-bold">{closedTrades.length}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add Trade Button */}
      {isOwnProfile && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full" variant="outline">
              <Plus className="h-4 w-4 mr-2" /> Log Trade
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Log a Trade</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Ticker</Label>
                  <Input
                    placeholder="e.g., AAPL"
                    value={formData.ticker}
                    onChange={(e) => setFormData({ ...formData, ticker: e.target.value.toUpperCase() })}
                  />
                </div>
                <div>
                  <Label>Direction</Label>
                  <Select value={formData.direction} onValueChange={(v) => setFormData({ ...formData, direction: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="long">Long</SelectItem>
                      <SelectItem value="short">Short</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Entry Price</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.entry_price || ''}
                    onChange={(e) => setFormData({ ...formData, entry_price: parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <Label>Exit Price</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.exit_price || ''}
                    onChange={(e) => setFormData({ ...formData, exit_price: parseFloat(e.target.value) || null })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Quantity</Label>
                  <Input
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: parseFloat(e.target.value) || 1 })}
                  />
                </div>
                <div>
                  <Label>Market</Label>
                  <Select value={formData.market_type} onValueChange={(v) => setFormData({ ...formData, market_type: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stocks">Stocks</SelectItem>
                      <SelectItem value="crypto">Crypto</SelectItem>
                      <SelectItem value="forex">Forex</SelectItem>
                      <SelectItem value="options">Options</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Entry Date</Label>
                  <Input
                    type="date"
                    value={formData.entry_date}
                    onChange={(e) => setFormData({ ...formData, entry_date: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Exit Date</Label>
                  <Input
                    type="date"
                    value={formData.exit_date || ''}
                    onChange={(e) => setFormData({ ...formData, exit_date: e.target.value || null })}
                  />
                </div>
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea
                  placeholder="What was your thesis? Lessons learned?"
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Make Public</Label>
                <Switch
                  checked={formData.is_public}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_public: checked })}
                />
              </div>
              <Button onClick={handleCreate} className="w-full">
                Save Trade
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Trade List */}
      {trades.length === 0 ? (
        <div className="text-center py-12">
          <BarChart2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No trades logged yet</p>
          {isOwnProfile && (
            <p className="text-sm text-muted-foreground mt-2">
              Start logging your trades to track performance
            </p>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {trades.slice(0, displayCount).map((trade) => (
            <Card key={trade.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {trade.direction === 'long' ? (
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500" />
                    )}
                    <span className="font-bold">{trade.ticker}</span>
                    <Badge variant="outline" className="text-xs">
                      {trade.market_type}
                    </Badge>
                    {!trade.is_public && isOwnProfile && (
                      <Lock className="h-3 w-3 text-muted-foreground" />
                    )}
                  </div>
                  {trade.pnl_amount !== null && (
                    <span className={`font-bold ${trade.pnl_amount >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {trade.pnl_amount >= 0 ? '+' : ''}{trade.pnl_amount.toFixed(2)}
                      {trade.pnl_percent !== null && (
                        <span className="text-xs ml-1">({trade.pnl_percent.toFixed(1)}%)</span>
                      )}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>Entry: ${trade.entry_price}</span>
                  {trade.exit_price && <span>Exit: ${trade.exit_price}</span>}
                  <span>Qty: {trade.quantity}</span>
                </div>
                {trade.notes && (
                  <p className="text-sm mt-2 text-muted-foreground line-clamp-2">{trade.notes}</p>
                )}
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(trade.entry_date), 'MMM d, yyyy')}
                    {trade.exit_date && ` → ${format(new Date(trade.exit_date), 'MMM d, yyyy')}`}
                  </span>
                  {isOwnProfile && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                      onClick={() => deleteTrade(trade.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          {trades.length > displayCount && (
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setDisplayCount(prev => prev + 5)}
            >
              Load More ({trades.length - displayCount} remaining)
            </Button>
          )}
        </div>
      )}
    </div>
  );
};
