import { useState } from 'react';
import { useUserPosts } from '@/hooks/useUserPosts';
import { TradingPost } from '@/components/TradingPost';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';

interface ProfileOverviewTabProps {
  userId: string;
  onSaveToggle?: () => void;
}

export const ProfileOverviewTab = ({ userId, onSaveToggle }: ProfileOverviewTabProps) => {
  const { posts, loading, error } = useUserPosts(userId);
  const [displayCount, setDisplayCount] = useState(5);

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2].map((i) => (
          <Skeleton key={i} className="h-48 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load posts
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No posts yet</p>
      </div>
    );
  }

  const displayedPosts = posts.slice(0, displayCount);

  return (
    <div className="space-y-4">
      {displayedPosts.map((post) => (
        <TradingPost
          key={post.id}
          id={post.id}
          author={{
            username: post.author?.handle || 'unknown',
            avatar: post.author?.avatar_url || null,
            verified: post.author?.verified_status !== 'unverified',
            reputation: post.author?.reputation_last30 || 0,
          }}
          content={{
            text: post.content,
            tickers: post.tickers,
            riskLevel: (post.risk_level as 'low' | 'medium' | 'high') || undefined,
            image: post.image_url || undefined,
          }}
          engagement={{
            useful: post.scores?.useful_count || 0,
            notUseful: post.scores?.not_useful_count || 0,
            userVote: null,
            isSaved: false,
          }}
          tradeMeta={post.trade_meta}
          timestamp={post.created_at}
          onSave={onSaveToggle}
        />
      ))}
      {posts.length > displayCount && (
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => setDisplayCount(prev => prev + 5)}
        >
          Load More ({posts.length - displayCount} remaining)
        </Button>
      )}
    </div>
  );
};
