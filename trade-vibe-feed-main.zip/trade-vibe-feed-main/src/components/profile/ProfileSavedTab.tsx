import { useState } from 'react';
import { useUserSavedPosts } from '@/hooks/useUserSavedPosts';
import { TradingPost } from '@/components/TradingPost';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Bookmark, Lock } from 'lucide-react';

interface ProfileSavedTabProps {
  userId: string;
  isOwnProfile: boolean;
  onSaveToggle?: () => void;
}

export const ProfileSavedTab = ({ userId, isOwnProfile, onSaveToggle }: ProfileSavedTabProps) => {
  const { savedPosts, loading, error } = useUserSavedPosts(userId, isOwnProfile);
  const [displayCount, setDisplayCount] = useState(5);

  if (!isOwnProfile) {
    return (
      <div className="text-center py-12">
        <Lock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">Saved posts are private</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2].map((i) => (
          <Skeleton key={i} className="h-48 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load saved posts
      </div>
    );
  }

  if (savedPosts.length === 0) {
    return (
      <div className="text-center py-12">
        <Bookmark className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No saved posts yet</p>
        <p className="text-sm text-muted-foreground mt-2">
          Bookmark posts to save them here
        </p>
      </div>
    );
  }

  const displayedPosts = savedPosts.slice(0, displayCount);

  return (
    <div className="space-y-4">
      {displayedPosts.map((post) => (
        <TradingPost
          key={post.id}
          id={post.id}
          author={{
            username: post.author?.handle || 'unknown',
            avatar: post.author?.avatar_url || null,
            verified: post.author?.verified_status !== 'unverified',
            reputation: post.author?.reputation_last30 || 0,
          }}
          content={{
            text: post.content,
            tickers: post.tickers,
            riskLevel: (post.risk_level as 'low' | 'medium' | 'high') || undefined,
            image: post.image_url || undefined,
          }}
          engagement={{
            useful: post.scores?.useful_count || 0,
            notUseful: post.scores?.not_useful_count || 0,
            userVote: null,
            isSaved: true,
          }}
          tradeMeta={post.trade_meta}
          timestamp={post.created_at}
          onSave={onSaveToggle}
        />
      ))}
      {savedPosts.length > displayCount && (
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => setDisplayCount(prev => prev + 5)}
        >
          Load More ({savedPosts.length - displayCount} remaining)
        </Button>
      )}
    </div>
  );
};
