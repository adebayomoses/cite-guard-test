import { useState } from 'react';
import { useJournal, JournalEntry, JournalEntryInput } from '@/hooks/useJournal';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { BookOpen, Plus, Lock, Globe, Trash2, Edit2, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';

interface ProfileJournalTabProps {
  userId: string;
  isOwnProfile: boolean;
}

const moodOptions = [
  { value: 'bullish', label: '🐂 Bullish', icon: TrendingUp, color: 'text-green-500' },
  { value: 'bearish', label: '🐻 Bearish', icon: TrendingDown, color: 'text-red-500' },
  { value: 'neutral', label: '😐 Neutral', icon: Minus, color: 'text-muted-foreground' },
];

export const ProfileJournalTab = ({ userId, isOwnProfile }: ProfileJournalTabProps) => {
  const { entries, loading, error, createEntry, updateEntry, deleteEntry, togglePublish } = useJournal(userId, isOwnProfile);
  const [displayCount, setDisplayCount] = useState(5);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [formData, setFormData] = useState<JournalEntryInput>({
    title: '',
    content: '',
    mood: 'neutral',
    tags: [],
    tickers_mentioned: [],
    is_published: false,
  });
  const [tagInput, setTagInput] = useState('');
  const [tickerInput, setTickerInput] = useState('');

  const resetForm = () => {
    setFormData({
      title: '',
      content: '',
      mood: 'neutral',
      tags: [],
      tickers_mentioned: [],
      is_published: false,
    });
    setTagInput('');
    setTickerInput('');
    setEditingEntry(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setFormData({
      title: entry.title,
      content: entry.content,
      mood: entry.mood,
      tags: entry.tags,
      tickers_mentioned: entry.tickers_mentioned,
      is_published: entry.is_published,
    });
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formData.title.trim() || !formData.content.trim()) return;

    if (editingEntry) {
      await updateEntry(editingEntry.id, formData);
    } else {
      await createEntry(formData);
    }
    setDialogOpen(false);
    resetForm();
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), tagInput.trim()],
      });
      setTagInput('');
    }
  };

  const removeTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter(t => t !== tag) || [],
    });
  };

  const addTicker = () => {
    const ticker = tickerInput.trim().toUpperCase();
    if (ticker && !formData.tickers_mentioned?.includes(ticker)) {
      setFormData({
        ...formData,
        tickers_mentioned: [...(formData.tickers_mentioned || []), ticker],
      });
      setTickerInput('');
    }
  };

  const removeTicker = (ticker: string) => {
    setFormData({
      ...formData,
      tickers_mentioned: formData.tickers_mentioned?.filter(t => t !== ticker) || [],
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2].map((i) => (
          <Skeleton key={i} className="h-40 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load journal entries
      </div>
    );
  }

  const getMoodInfo = (mood: string) => {
    return moodOptions.find(m => m.value === mood) || moodOptions[2];
  };

  return (
    <div className="space-y-4">
      {/* Create Entry Button */}
      {isOwnProfile && (
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="w-full" variant="outline" onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" /> New Journal Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingEntry ? 'Edit Entry' : 'New Journal Entry'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label>Title</Label>
                <Input
                  placeholder="Today's trading insights..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>

              <div>
                <Label>Content</Label>
                <Textarea
                  placeholder="Write about your trades, market observations, lessons learned..."
                  className="min-h-[150px]"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                />
              </div>

              <div>
                <Label>Mood</Label>
                <div className="flex gap-2 mt-2">
                  {moodOptions.map((option) => (
                    <Button
                      key={option.value}
                      type="button"
                      variant={formData.mood === option.value ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFormData({ ...formData, mood: option.value })}
                      className="flex-1"
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Tags</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="Add tag..."
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  />
                  <Button type="button" variant="outline" onClick={addTag}>Add</Button>
                </div>
                {formData.tags && formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {formData.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
                        {tag} ×
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <Label>Tickers Mentioned</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder="e.g., AAPL"
                    value={tickerInput}
                    onChange={(e) => setTickerInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTicker())}
                  />
                  <Button type="button" variant="outline" onClick={addTicker}>Add</Button>
                </div>
                {formData.tickers_mentioned && formData.tickers_mentioned.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {formData.tickers_mentioned.map((ticker) => (
                      <Badge key={ticker} variant="outline" className="cursor-pointer" onClick={() => removeTicker(ticker)}>
                        ${ticker} ×
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between border-t pt-4">
                <div className="flex items-center gap-2">
                  {formData.is_published ? (
                    <Globe className="h-4 w-4 text-green-500" />
                  ) : (
                    <Lock className="h-4 w-4 text-muted-foreground" />
                  )}
                  <Label>{formData.is_published ? 'Public' : 'Private'}</Label>
                </div>
                <Switch
                  checked={formData.is_published}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_published: checked })}
                />
              </div>

              <Button onClick={handleSubmit} className="w-full">
                {editingEntry ? 'Update Entry' : 'Create Entry'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Entries List */}
      {entries.length === 0 ? (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">
            {isOwnProfile ? 'Start your trading journal' : 'No published journal entries'}
          </p>
          {isOwnProfile && (
            <p className="text-sm text-muted-foreground mt-2">
              Document your trading journey, lessons, and insights
            </p>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {entries.slice(0, displayCount).map((entry) => {
            const moodInfo = getMoodInfo(entry.mood);
            return (
              <Card key={entry.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <moodInfo.icon className={`h-4 w-4 ${moodInfo.color}`} />
                        {!entry.is_published && isOwnProfile && (
                          <Lock className="h-3 w-3 text-muted-foreground" />
                        )}
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(entry.created_at), 'MMM d, yyyy')}
                        </span>
                      </div>
                      <CardTitle className="text-lg">{entry.title}</CardTitle>
                    </div>
                    {isOwnProfile && (
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => openEditDialog(entry)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          onClick={() => deleteEntry(entry.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap line-clamp-4">
                    {entry.content}
                  </p>
                  
                  {(entry.tickers_mentioned?.length > 0 || entry.tags?.length > 0) && (
                    <div className="flex flex-wrap gap-1 mt-3">
                      {entry.tickers_mentioned?.map((ticker) => (
                        <Badge key={ticker} variant="outline" className="text-xs">
                          ${ticker}
                        </Badge>
                      ))}
                      {entry.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  {isOwnProfile && (
                    <div className="flex items-center justify-between mt-3 pt-3 border-t">
                      <span className="text-xs text-muted-foreground">
                        {entry.is_published ? 'Visible to everyone' : 'Only you can see this'}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => togglePublish(entry.id, !entry.is_published)}
                      >
                        {entry.is_published ? (
                          <>
                            <Lock className="h-3 w-3 mr-1" /> Make Private
                          </>
                        ) : (
                          <>
                            <Globe className="h-3 w-3 mr-1" /> Publish
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
          {entries.length > displayCount && (
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setDisplayCount(prev => prev + 5)}
            >
              Load More ({entries.length - displayCount} remaining)
            </Button>
          )}
        </div>
      )}
    </div>
  );
};
