import { useState } from 'react';
import { useUserMedia } from '@/hooks/useUserMedia';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ImageIcon, Play } from 'lucide-react';

interface ProfileMediaTabProps {
  userId: string;
  isOwnProfile: boolean;
}

export const ProfileMediaTab = ({ userId, isOwnProfile }: ProfileMediaTabProps) => {
  const { media, loading, error } = useUserMedia(userId, isOwnProfile);
  const [selectedMedia, setSelectedMedia] = useState<typeof media[0] | null>(null);
  const [displayCount, setDisplayCount] = useState(6);

  if (loading) {
    return (
      <div className="grid grid-cols-3 gap-1">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="aspect-square rounded" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load media
      </div>
    );
  }

  if (media.length === 0) {
    return (
      <div className="text-center py-12">
        <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No media uploaded yet</p>
      </div>
    );
  }

  const displayedMedia = media.slice(0, displayCount);

  return (
    <>
      <div className="grid grid-cols-3 gap-1">
        {displayedMedia.map((item) => (
          <button
            key={item.id}
            onClick={() => setSelectedMedia(item)}
            className="relative aspect-square overflow-hidden rounded bg-muted group"
          >
            {item.type === 'video' ? (
              <>
                {item.thumbnail_url ? (
                  <img
                    src={item.thumbnail_url}
                    alt={item.caption || 'Video thumbnail'}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-muted">
                    <Play className="h-8 w-8 text-muted-foreground" />
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Play className="h-8 w-8 text-white" />
                </div>
              </>
            ) : (
              <img
                src={item.url}
                alt={item.caption || 'Image'}
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
          </button>
        ))}
      </div>

      {media.length > displayCount && (
        <Button 
          variant="outline" 
          className="w-full mt-4"
          onClick={() => setDisplayCount(prev => prev + 6)}
        >
          Load More ({media.length - displayCount} remaining)
        </Button>
      )}

      <Dialog open={!!selectedMedia} onOpenChange={() => setSelectedMedia(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          {selectedMedia?.type === 'video' ? (
            <video
              src={selectedMedia.url}
              controls
              autoPlay
              className="w-full max-h-[80vh]"
            />
          ) : selectedMedia?.type === 'image' ? (
            <img
              src={selectedMedia.url}
              alt={selectedMedia.caption || 'Image'}
              className="w-full max-h-[80vh] object-contain"
            />
          ) : null}
          {selectedMedia?.caption && (
            <div className="p-4 bg-background">
              <p className="text-sm">{selectedMedia.caption}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
