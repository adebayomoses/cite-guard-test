import { useState } from 'react';
import { useUserSignals } from '@/hooks/useUserSignals';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Target, AlertTriangle, Clock, Signal } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface ProfileSignalsTabProps {
  userId: string;
}

export const ProfileSignalsTab = ({ userId }: ProfileSignalsTabProps) => {
  const { signals, loading, error } = useUserSignals(userId);
  const [displayCount, setDisplayCount] = useState(5);

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-destructive py-8">
        Failed to load signals
      </div>
    );
  }

  if (signals.length === 0) {
    return (
      <div className="text-center py-12">
        <Signal className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-muted-foreground">No signals posted yet</p>
      </div>
    );
  }

  const getRiskColor = (risk: string | null) => {
    switch (risk) {
      case 'low_risk': return 'bg-green-500/10 text-green-500';
      case 'medium_risk': return 'bg-yellow-500/10 text-yellow-500';
      case 'high_risk': return 'bg-red-500/10 text-red-500';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const formatRisk = (risk: string | null) => {
    if (!risk) return 'Unknown';
    return risk.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const displayedSignals = signals.slice(0, displayCount);

  return (
    <div className="grid grid-cols-1 gap-4">
      {displayedSignals.map((signal) => (
        <Card key={signal.id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                {signal.trade_direction === 'long' ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
                <Badge variant="outline" className={signal.trade_direction === 'long' ? 'border-green-500 text-green-500' : 'border-red-500 text-red-500'}>
                  {signal.trade_direction?.toUpperCase() || 'LONG'}
                </Badge>
                <Badge variant="secondary">{signal.market_type || 'stocks'}</Badge>
              </div>
              <Badge className={getRiskColor(signal.risk_level)}>
                {formatRisk(signal.risk_level)}
              </Badge>
            </div>

            <p className="text-sm mb-3 line-clamp-2">{signal.content}</p>

            <div className="grid grid-cols-3 gap-2 text-xs">
              {signal.entry_price && (
                <div className="bg-muted/50 rounded p-2 text-center">
                  <div className="text-muted-foreground mb-1">Entry</div>
                  <div className="font-semibold">${signal.entry_price}</div>
                </div>
              )}
              {signal.target_price && (
                <div className="bg-green-500/10 rounded p-2 text-center">
                  <div className="text-muted-foreground mb-1 flex items-center justify-center gap-1">
                    <Target className="h-3 w-3" /> Target
                  </div>
                  <div className="font-semibold text-green-500">${signal.target_price}</div>
                </div>
              )}
              {signal.stop_loss && (
                <div className="bg-red-500/10 rounded p-2 text-center">
                  <div className="text-muted-foreground mb-1 flex items-center justify-center gap-1">
                    <AlertTriangle className="h-3 w-3" /> Stop
                  </div>
                  <div className="font-semibold text-red-500">${signal.stop_loss}</div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
              {signal.timeframe && (
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {signal.timeframe}
                </div>
              )}
              <span>{formatDistanceToNow(new Date(signal.created_at), { addSuffix: true })}</span>
            </div>
          </CardContent>
        </Card>
      ))}
      {signals.length > displayCount && (
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => setDisplayCount(prev => prev + 5)}
        >
          Load More ({signals.length - displayCount} remaining)
        </Button>
      )}
    </div>
  );
};
