import { MentorshipChannelCard } from "./MentorshipChannelCard";
import { Skeleton } from "@/components/ui/skeleton";
import { GraduationCap } from "lucide-react";
import { MentorshipChannel } from "@/hooks/useMentorshipChannels";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  channels?: MentorshipChannel[];
  type: 'free' | 'paid';
  isLoading: boolean;
  onJoinSuccess: () => void;
}

export const MentorshipChannelGrid = ({ channels, type, isLoading, onJoinSuccess }: Props) => {
  const [joiningId, setJoiningId] = useState<string | null>(null);
  const { toast } = useToast();

  const handleJoin = async (channelId: string) => {
    setJoiningId(channelId);
    try {
      const { data, error } = await supabase.functions.invoke(
        `chat-api/mentorship/${channelId}/join`,
        { method: 'POST' }
      );

      if (error) throw error;
      
      if (data.requiresPayment) {
        toast({
          title: "Payment Required",
          description: `This channel costs $${data.price}/${data.billingCycle}`,
        });
        return;
      }

      toast({
        title: "Success!",
        description: "You've joined the mentorship channel",
      });
      
      onJoinSuccess();
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to join channel",
        variant: "destructive",
      });
    } finally {
      setJoiningId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Skeleton key={i} className="h-80" />
        ))}
      </div>
    );
  }

  if (!channels || channels.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <GraduationCap className="h-16 w-16 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">
          No {type} mentorship channels yet
        </h3>
        <p className="text-muted-foreground max-w-md">
          {type === 'free' 
            ? "Be the first to create a free mentorship channel!"
            : "No paid mentorship channels available right now."}
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {channels.map((channel) => (
        <MentorshipChannelCard
          key={channel.conversation_id}
          channel={channel}
          onJoin={handleJoin}
          isJoining={joiningId === channel.conversation_id}
        />
      ))}
    </div>
  );
};
