import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

interface Follower {
  id: string;
  handle: string;
  display_name?: string;
  avatar_url?: string;
  verified_status: string;
}

interface FollowersModalProps {
  userId: string;
}

export const FollowersModal = ({ userId }: FollowersModalProps) => {
  const [followers, setFollowers] = useState<Follower[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFollowers = async () => {
      try {
        // Get followers by joining follows with profiles
        const { data, error } = await supabase
          .from('follows')
          .select('user_id')
          .eq('target_id', userId);

        if (error) throw error;

        if (data && data.length > 0) {
          const userIds = data.map(follow => follow.user_id);
          
          const { data: profiles, error: profilesError } = await supabase
            .from('profiles')
            .select('id, handle, display_name, avatar_url, verified_status')
            .in('id', userIds);

          if (profilesError) throw profilesError;
          setFollowers(profiles || []);
        }
      } catch (error) {
        console.error('Error fetching followers:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFollowers();
  }, [userId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (followers.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-8">
        No followers yet
      </div>
    );
  }

  return (
    <ScrollArea className="h-80">
      <div className="space-y-3">
        {followers.map((follower) => (
          <div key={follower.id} className="flex items-center justify-between p-2">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={follower.avatar_url || undefined} />
                <AvatarFallback>
                  {follower.display_name?.[0] || follower.handle[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm truncate">
                    {follower.display_name || follower.handle}
                  </p>
                  {follower.verified_status !== 'unverified' && (
                    <Badge variant="secondary" className="text-xs">
                      Verified
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">@{follower.handle}</p>
              </div>
            </div>
            
            <Button variant="outline" size="sm">
              View
            </Button>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};