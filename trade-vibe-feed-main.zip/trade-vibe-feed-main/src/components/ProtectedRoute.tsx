import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireOnboarding?: boolean;
}

export const ProtectedRoute = ({ children, requireOnboarding = false }: ProtectedRouteProps) => {
  const { user, loading: authLoading } = useAuth();
  const { profile, loading: profileLoading } = useProfile();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading) {
      // Redirect to signin if not authenticated
      if (!user) {
        navigate('/auth/signin');
        return;
      }

      // Check onboarding status once profile is loaded
      if (!profileLoading && profile) {
        const needsOnboarding = !profile.handle;
        
        if (requireOnboarding && !needsOnboarding) {
          // Already onboarded, redirect to home
          navigate('/');
        } else if (!requireOnboarding && needsOnboarding) {
          // Needs onboarding, redirect to onboarding
          navigate('/onboarding');
        }
      }
    }
  }, [user, profile, authLoading, profileLoading, navigate, requireOnboarding]);

  // Show loading while checking auth and profile status
  if (authLoading || (user && profileLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Don't render children if user is not authenticated
  if (!user) {
    return null;
  }

  return <>{children}</>;
};