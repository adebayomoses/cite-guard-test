import React from 'react';

interface TypingIndicatorProps {
  userHandle: string;
}

export const TypingIndicator = ({ userHandle }: TypingIndicatorProps) => {
  return (
    <div className="flex justify-start">
      <div className="max-w-xs lg:max-w-md mr-4">
        <div className="bg-muted px-4 py-2 rounded-lg">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">
              @{userHandle} is typing
            </span>
            <div className="flex space-x-1">
              <div className="w-1 h-1 bg-muted-foreground rounded-full animate-bounce"></div>
              <div className="w-1 h-1 bg-muted-foreground rounded-full animate-bounce delay-100"></div>
              <div className="w-1 h-1 bg-muted-foreground rounded-full animate-bounce delay-200"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};