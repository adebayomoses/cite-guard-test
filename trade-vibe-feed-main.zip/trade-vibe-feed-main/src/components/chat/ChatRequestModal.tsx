import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useChatRequests } from '@/hooks/useChatRequests';
import { toast } from 'sonner';

interface ChatRequestModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
    verified_status: string | null;
  };
}

export const ChatRequestModal = ({ open, onOpenChange, user }: ChatRequestModalProps) => {
  const [introMessage, setIntroMessage] = useState('');
  const [sending, setSending] = useState(false);
  const { sendChatRequest } = useChatRequests();

  const handleSendRequest = async () => {
    setSending(true);
    try {
      await sendChatRequest(user.id, introMessage);
      toast.success('Chat request sent successfully!');
      onOpenChange(false);
      setIntroMessage('');
    } catch (error: any) {
      toast.error(error.message || 'Failed to send chat request');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Send Chat Request</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar_url || ''} alt={user.display_name || user.handle} />
              <AvatarFallback>
                {(user.display_name || user.handle).slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-medium">{user.display_name || user.handle}</span>
                {user.verified_status === 'verified' && (
                  <Badge variant="secondary" className="text-xs">Verified</Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">@{user.handle}</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Introduce yourself (optional)</label>
            <Textarea
              placeholder="Hi! I'd like to connect and discuss trading strategies..."
              value={introMessage}
              onChange={(e) => setIntroMessage(e.target.value)}
              rows={3}
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground">
              {introMessage.length}/500 characters
            </p>
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={sending}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSendRequest}
              disabled={sending}
            >
              {sending ? 'Sending...' : 'Send Request'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};