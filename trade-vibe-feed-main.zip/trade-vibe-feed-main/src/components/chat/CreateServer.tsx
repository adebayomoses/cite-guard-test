import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { AvatarUploader } from '@/components/AvatarUploader';
import { useServers } from '@/hooks/useServers';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

interface CreateServerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onServerCreated?: () => void;
}

export const CreateServer: React.FC<CreateServerProps> = ({
  open,
  onOpenChange,
  onServerCreated,
}) => {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | undefined>();
  const { createServer, loading } = useServers();

  const handleCreate = async () => {
    if (!name.trim()) return;

    const serverId = await createServer(name, description, avatarUrl);
    if (serverId) {
      setName('');
      setDescription('');
      setAvatarUrl(undefined);
      onOpenChange(false);
      onServerCreated?.();
      navigate(`/servers/${serverId}`);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Branch Server</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex justify-center">
            <AvatarUploader
              currentUrl={avatarUrl}
              onUpload={setAvatarUrl}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="server-name">Server Name *</Label>
            <Input
              id="server-name"
              placeholder="My Trading Server"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={50}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="server-description">Description</Label>
            <Textarea
              id="server-description"
              placeholder="Describe your server..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              maxLength={500}
            />
          </div>

          <p className="text-sm text-muted-foreground">
            Your server will be created with default channels: #general and #announcements
          </p>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleCreate} disabled={!name.trim() || loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Server
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
