import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { MoreHorizontal, Flag, Download } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import type { ChatMessage } from '@/hooks/useChat';
import { cn } from '@/lib/utils';

interface MessageBubbleProps {
  message: ChatMessage;
  onReport?: (messageId: string) => void;
}

export const MessageBubble = ({ message, onReport }: MessageBubbleProps) => {
  const { user } = useAuth();
  const isOwn = message.author_id === user?.id;
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  // Generate full URL for attachment
  const getAttachmentUrl = (path: string) => {
    return `https://jyonjxvfjshkjdtjwcqo.supabase.co/storage/v1/object/public/chat-attachments/${path}`;
  };

  const handleDownload = (path: string) => {
    const url = getAttachmentUrl(path);
    window.open(url, '_blank');
  };

  const isImage = message.mime_type?.startsWith('image/');
  const isVideo = message.mime_type?.startsWith('video/');

  return (
    <div className={cn(
      "flex flex-col",
      isOwn ? "items-end" : "items-start"
    )}>
      <div className={cn(
        "relative group",
        isImage || isVideo ? "max-w-sm" : "max-w-xs lg:max-w-md"
      )}>
        {message.attachment_path ? (
          <div className="space-y-2">
            {isImage ? (
              <div className={cn(
                "rounded-2xl overflow-hidden shadow-md",
                isOwn ? "ml-4" : "mr-4"
              )}>
                {imageLoading && !imageError && (
                  <div className="w-[300px] h-[200px] bg-muted animate-pulse" />
                )}
                {imageError ? (
                  <div className={cn(
                    "px-4 py-2 rounded-lg flex items-center space-x-2",
                    isOwn 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  )}>
                    <Download className="h-4 w-4 flex-shrink-0" />
                    <button
                      onClick={() => handleDownload(message.attachment_path!)}
                      className="text-xs underline"
                    >
                      Download Image
                    </button>
                  </div>
                ) : (
                  <img 
                    src={getAttachmentUrl(message.attachment_path)} 
                    alt="Chat attachment" 
                    className={cn(
                      "w-full max-w-[300px] h-auto cursor-pointer hover:opacity-90 transition-opacity",
                      imageLoading ? "hidden" : "block"
                    )}
                    onClick={() => handleDownload(message.attachment_path!)}
                    onLoad={() => setImageLoading(false)}
                    onError={() => {
                      setImageError(true);
                      setImageLoading(false);
                    }}
                  />
                )}
                {message.body && (
                  <div className={cn(
                    "px-3 py-2",
                    isOwn 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  )}>
                    <p className="text-sm">{message.body}</p>
                  </div>
                )}
              </div>
            ) : isVideo ? (
              <div className={cn(
                "rounded-2xl overflow-hidden shadow-md",
                isOwn ? "ml-4" : "mr-4"
              )}>
                <video 
                  src={getAttachmentUrl(message.attachment_path)} 
                  controls 
                  className="w-full max-w-[300px] h-auto"
                />
                {message.body && (
                  <div className={cn(
                    "px-3 py-2",
                    isOwn 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  )}>
                    <p className="text-sm">{message.body}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className={cn(
                "px-4 py-2 rounded-lg",
                isOwn 
                  ? "bg-primary text-primary-foreground ml-4" 
                  : "bg-muted mr-4"
              )}>
                <button
                  onClick={() => handleDownload(message.attachment_path!)}
                  className="flex items-center space-x-2 p-2 bg-background/10 rounded hover:bg-background/20 transition-colors w-full text-left"
                >
                  <Download className="h-4 w-4 flex-shrink-0" />
                  <div className="text-xs truncate">
                    {message.attachment_path.split('/').pop()}
                  </div>
                </button>
                {message.body && (
                  <p className="text-sm mt-2">{message.body}</p>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className={cn(
            "px-4 py-2 rounded-lg",
            isOwn 
              ? "bg-primary text-primary-foreground ml-4" 
              : "bg-muted mr-4"
          )}>
            <p className="text-sm">{message.body}</p>
          </div>
        )}

        <div className="flex items-center justify-between mt-1 px-1">
          <div className={cn(
            "text-xs text-muted-foreground",
            isOwn ? "order-1" : "order-2"
          )}>
            {formatDistanceToNow(new Date(message.created_at), { addSuffix: true })}
          </div>

          {!isOwn && onReport && (
            <div className={cn(
              "opacity-0 group-hover:opacity-100 transition-opacity",
              isOwn ? "order-2" : "order-1"
            )}>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                    <MoreHorizontal className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="bg-popover border">
                  <DropdownMenuItem 
                    onClick={() => onReport(message.id)}
                    className="text-destructive cursor-pointer"
                  >
                    <Flag className="h-3 w-3 mr-2" />
                    Report
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};