import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useGroupChat, GroupInfo } from '@/hooks/useGroupChat';

interface GroupSettingsProps {
  conversationId: string;
  groupInfo: GroupInfo;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: () => void;
}

export const GroupSettings = ({ conversationId, groupInfo, open, onOpenChange, onUpdate }: GroupSettingsProps) => {
  const [name, setName] = useState(groupInfo.name);
  const [description, setDescription] = useState(groupInfo.description || '');
  const [allowMemberMessages, setAllowMemberMessages] = useState(groupInfo.allow_member_messages);
  const [allowMemberAdd, setAllowMemberAdd] = useState(groupInfo.allow_member_add);
  const [maxMembers, setMaxMembers] = useState(groupInfo.max_members);

  const { updateGroup, loading } = useGroupChat();
  
  const isServerChannel = groupInfo.isServerChannel === true;

  const handleSave = async () => {
    const updates: any = {
      name,
      description,
    };

    // Only include settings for regular groups, not server channels
    if (!isServerChannel) {
      updates.settings = {
        allowMemberMessages,
        allowMemberAdd,
        maxMembers,
      };
    }

    const success = await updateGroup(conversationId, updates);

    if (success) {
      onUpdate();
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{isServerChannel ? 'Channel Settings' : 'Group Settings'}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="group-name">{isServerChannel ? 'Channel Name' : 'Group Name'}</Label>
            <Input
              id="group-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={50}
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={200}
              rows={3}
            />
          </div>

          {!isServerChannel && (
            <div className="space-y-3 pt-4 border-t">
              <h4 className="text-sm font-medium">Permissions</h4>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="member-messages">Allow members to send messages</Label>
                <Switch
                  id="member-messages"
                  checked={allowMemberMessages}
                  onCheckedChange={setAllowMemberMessages}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="member-add">Allow members to add others</Label>
                <Switch
                  id="member-add"
                  checked={allowMemberAdd}
                  onCheckedChange={setAllowMemberAdd}
                />
              </div>

              <div>
                <Label htmlFor="max-members">Max Members</Label>
                <Input
                  id="max-members"
                  type="number"
                  min={2}
                  max={500}
                  value={maxMembers}
                  onChange={(e) => setMaxMembers(parseInt(e.target.value) || 100)}
                />
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={loading || !name.trim()}
              className="flex-1"
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
