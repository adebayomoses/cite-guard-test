import React, { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Upload, DollarSign, TrendingUp, TrendingDown, Target, Shield, Clock, Send } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ChatSignalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSendSignal: (text: string, attachmentPath?: string, mimeType?: string) => Promise<boolean>;
}

export function ChatSignalDialog({ open, onOpenChange, onSendSignal }: ChatSignalDialogProps) {
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [imagePath, setImagePath] = useState('');
  const [marketType, setMarketType] = useState('stocks');
  const [tradeDirection, setTradeDirection] = useState('long');
  const [riskLevel, setRiskLevel] = useState('medium_risk');
  const [timeframe, setTimeframe] = useState('');
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 5MB",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('chat-attachments')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('chat-attachments')
        .getPublicUrl(fileName);

      setImageUrl(publicUrl);
      setImagePath(fileName);
      toast({
        title: "Chart uploaded",
        description: "Your chart has been uploaded"
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const formatSignalMessage = (): string => {
    const marketEmoji = {
      stocks: '📈',
      crypto: '₿',
      forex: '💱',
      options: '⚡',
      futures: '📊'
    }[marketType] || '📊';

    const directionEmoji = tradeDirection === 'long' ? '🟢' : '🔴';
    const directionText = tradeDirection === 'long' ? 'LONG' : 'SHORT';

    const riskEmoji = {
      low_risk: '🟢',
      medium_risk: '🟡',
      high_risk: '🔴'
    }[riskLevel] || '🟡';

    const riskText = riskLevel.replace('_', ' ').toUpperCase();

    let message = `📊 TRADE SIGNAL\n━━━━━━━━━━━━━━━\n`;
    message += `${marketEmoji} Market: ${marketType.charAt(0).toUpperCase() + marketType.slice(1)}\n`;
    message += `${directionEmoji} Direction: ${directionText}\n`;
    message += `${riskEmoji} Risk: ${riskText}\n`;

    if (timeframe) {
      message += `⏱️ Timeframe: ${timeframe}\n`;
    }

    if (entryPrice || stopLoss || targetPrice) {
      message += `\n`;
      if (entryPrice) message += `💰 Entry: $${entryPrice}\n`;
      if (stopLoss) message += `🛡️ Stop Loss: $${stopLoss}\n`;
      if (targetPrice) message += `🎯 Target: $${targetPrice}\n`;
    }

    if (content.trim()) {
      message += `\n📝 Analysis:\n${content.trim()}`;
    }

    return message;
  };

  const handleSubmit = async () => {
    setSending(true);
    try {
      const signalText = formatSignalMessage();
      const success = await onSendSignal(
        signalText,
        imagePath || undefined,
        imagePath ? 'image/png' : undefined
      );

      if (success) {
        // Reset form
        setContent('');
        setImageUrl('');
        setImagePath('');
        setMarketType('stocks');
        setTradeDirection('long');
        setRiskLevel('medium_risk');
        setTimeframe('');
        setEntryPrice('');
        setStopLoss('');
        setTargetPrice('');
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
        onOpenChange(false);
        toast({
          title: 'Signal sent',
          description: 'Your trade signal has been shared'
        });
      }
    } catch (error) {
      console.error('Error sending signal:', error);
      toast({
        title: 'Failed to send signal',
        description: 'Please try again',
        variant: 'destructive'
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] p-0">
        <DialogHeader className="p-4 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Create Trade Signal
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[calc(90vh-100px)] px-4 pb-4">
          <div className="space-y-4 pt-2">
            {/* Chart Upload */}
            <div 
              className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4 text-center hover:border-muted-foreground/50 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              {imageUrl ? (
                <img src={imageUrl} alt="Chart" className="w-full rounded-lg" />
              ) : (
                <>
                  <Upload className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Upload chart (optional)</p>
                </>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>

            {/* Market & Direction */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Market</Label>
                <Select value={marketType} onValueChange={setMarketType}>
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stocks">📈 Stocks</SelectItem>
                    <SelectItem value="crypto">₿ Crypto</SelectItem>
                    <SelectItem value="forex">💱 Forex</SelectItem>
                    <SelectItem value="options">⚡ Options</SelectItem>
                    <SelectItem value="futures">📊 Futures</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">Direction</Label>
                <RadioGroup 
                  value={tradeDirection} 
                  onValueChange={setTradeDirection}
                  className="flex gap-3"
                >
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="long" id="chat-long" />
                    <Label htmlFor="chat-long" className="flex items-center gap-1 cursor-pointer text-xs">
                      <TrendingUp className="h-3 w-3 text-green-500" />
                      Long
                    </Label>
                  </div>
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="short" id="chat-short" />
                    <Label htmlFor="chat-short" className="flex items-center gap-1 cursor-pointer text-xs">
                      <TrendingDown className="h-3 w-3 text-red-500" />
                      Short
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </div>

            {/* Risk Level */}
            <div className="space-y-1">
              <Label className="text-xs flex items-center gap-1">
                <Shield className="h-3 w-3" />
                Risk Level
              </Label>
              <RadioGroup 
                value={riskLevel} 
                onValueChange={setRiskLevel}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="low_risk" id="chat-low" />
                  <Label htmlFor="chat-low" className="cursor-pointer text-xs">Low</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="medium_risk" id="chat-medium" />
                  <Label htmlFor="chat-medium" className="cursor-pointer text-xs">Medium</Label>
                </div>
                <div className="flex items-center space-x-1">
                  <RadioGroupItem value="high_risk" id="chat-high" />
                  <Label htmlFor="chat-high" className="cursor-pointer text-xs">High</Label>
                </div>
              </RadioGroup>
            </div>

            {/* Trading Details */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Timeframe
                </Label>
                <Select value={timeframe} onValueChange={setTimeframe}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Optional" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1m">1 Min</SelectItem>
                    <SelectItem value="5m">5 Min</SelectItem>
                    <SelectItem value="15m">15 Min</SelectItem>
                    <SelectItem value="1h">1 Hour</SelectItem>
                    <SelectItem value="4h">4 Hour</SelectItem>
                    <SelectItem value="1d">Daily</SelectItem>
                    <SelectItem value="1w">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1">
                <Label className="text-xs flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  Entry Price
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="Optional"
                  value={entryPrice}
                  onChange={(e) => setEntryPrice(e.target.value)}
                  className="h-9"
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  Stop Loss
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="Optional"
                  value={stopLoss}
                  onChange={(e) => setStopLoss(e.target.value)}
                  className="h-9"
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs flex items-center gap-1">
                  <Target className="h-3 w-3" />
                  Target Price
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="Optional"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  className="h-9"
                />
              </div>
            </div>

            {/* Analysis */}
            <div className="space-y-1">
              <Label className="text-xs">Analysis (Optional)</Label>
              <Textarea
                placeholder="Share your signal analysis..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="min-h-16 resize-none"
              />
            </div>

            {/* Submit */}
            <Button 
              onClick={handleSubmit}
              disabled={sending || uploading}
              className="w-full"
            >
              <Send className="h-4 w-4 mr-2" />
              {sending ? 'Sending...' : 'Send Signal'}
            </Button>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
