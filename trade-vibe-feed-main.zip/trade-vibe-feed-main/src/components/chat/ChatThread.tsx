import React, { useRef, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, MoreVertical, Paperclip, Send, User, Info, TrendingUp, Plus } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useChat } from '@/hooks/useChat';
import { useChatList } from '@/hooks/useChatList';
import { useGroupChat } from '@/hooks/useGroupChat';
import { MessageBubble } from './MessageBubble';
import { TypingIndicator } from './TypingIndicator';
import { GroupInfo } from './GroupInfo';
import { ChatSignalDialog } from './ChatSignalDialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const ChatThread = () => {
  const { id: conversationId } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [message, setMessage] = useState('');
  const [otherUser, setOtherUser] = useState<any>(null);
  const [isGroup, setIsGroup] = useState(false);
  const [groupInfo, setGroupInfo] = useState<any>(null);
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showSignalDialog, setShowSignalDialog] = useState(false);
  const [attachmentMenuOpen, setAttachmentMenuOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const { 
    messages, 
    loading, 
    hasMore, 
    typingUsers, 
    loadMessages, 
    sendMessage, 
    setTyping 
  } = useChat(conversationId);
  
  const { conversations, reportMessage, toggleBlock } = useChatList();
  const { getGroupInfo } = useGroupChat();

  // Get conversation info (group or 1:1)
  useEffect(() => {
    const conversation = conversations.find(c => c.id === conversationId);
    if (conversation) {
      setIsGroup(conversation.isGroup || false);
      if (conversation.isGroup && conversation.groupInfo) {
        setGroupInfo(conversation.groupInfo);
      } else {
        setOtherUser(conversation.otherUser);
      }
    } else if (conversationId) {
      // Fetch conversation details directly
      const fetchConversationDetails = async () => {
        const { data: conv } = await supabase
          .from('conversations')
          .select('is_group')
          .eq('id', conversationId)
          .single();

        if (conv?.is_group) {
          setIsGroup(true);
          const info = await getGroupInfo(conversationId);
          setGroupInfo(info);
        } else {
          setIsGroup(false);
          const { data: { user } } = await supabase.auth.getUser();
          if (!user) return;

          const { data: participants } = await supabase
            .from('conversation_participants')
            .select(`
              user_id,
              profiles (
                id,
                handle,
                display_name,
                avatar_url
              )
            `)
            .eq('conversation_id', conversationId)
            .neq('user_id', user.id)
            .limit(1);

          if (participants && participants.length > 0 && participants[0].profiles) {
            setOtherUser(participants[0].profiles);
          }
        }
      };
      
      fetchConversationDetails();
    }
  }, [conversations, conversationId, getGroupInfo]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle typing indicator
  const handleTyping = () => {
    setTyping(true);
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    typingTimeoutRef.current = setTimeout(() => {
      setTyping(false);
    }, 2000);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Maximum file size is 10MB',
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Upload to chat-attachments bucket
      const fileName = `${user.id}/${Date.now()}-${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('chat-attachments')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Send message with attachment
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/${conversationId}/send`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            body: message.trim() || null,
            attachmentPath: fileName,
            mimeType: file.type
          })
        }
      );

      if (!response.ok) throw new Error('Failed to send attachment');

      setMessage('');
      toast({
        title: 'File sent',
        description: 'Your attachment has been sent'
      });
    } catch (error) {
      console.error('Error uploading file:', error);
      toast({
        title: 'Failed to send file',
        description: 'Please try again',
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const messageText = message.trim();
    setMessage('');
    setTyping(false);

    const sent = await sendMessage(messageText);
    if (!sent) {
      toast({
        title: 'Failed to send message',
        description: 'Please try again',
        variant: 'destructive'
      });
      setMessage(messageText);
    }
  };

  const handleBlock = async () => {
    if (!otherUser) return;
    
    const blocked = await toggleBlock(otherUser.id);
    if (blocked !== null) {
      toast({
        title: blocked ? 'User blocked' : 'User unblocked',
        description: blocked 
          ? 'You will no longer receive messages from this user'
          : 'You can now receive messages from this user'
      });
      
      if (blocked) {
        navigate('/chat');
      }
    }
  };

  const handleReport = async (messageId: string) => {
    const success = await reportMessage(messageId, 'Inappropriate content');
    if (success) {
      toast({
        title: 'Message reported',
        description: 'Thank you for helping keep the community safe'
      });
    }
  };

  const handleSendSignal = async (text: string, attachmentPath?: string, mimeType?: string): Promise<boolean> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');

      const response = await fetch(
        `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/chat-api/${conversationId}/send`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            body: text,
            attachmentPath: attachmentPath || null,
            mimeType: mimeType || null
          })
        }
      );

      if (!response.ok) throw new Error('Failed to send signal');
      return true;
    } catch (error) {
      console.error('Error sending signal:', error);
      return false;
    }
  };

  if (!conversationId) {
    return <div>Conversation not found</div>;
  }

  const isLoadingInfo = isGroup ? !groupInfo : !otherUser;
  const displayName = isGroup ? groupInfo?.name : (otherUser?.display_name || otherUser?.handle);
  const avatarUrl = isGroup ? groupInfo?.avatar_url : otherUser?.avatar_url;
  const avatarFallback = isGroup 
    ? groupInfo?.name?.slice(0, 2).toUpperCase() || 'GR'
    : otherUser?.handle?.slice(0, 2).toUpperCase() || 'U';
  const currentConversation = conversations.find(c => c.id === conversationId);
  const headerMemberCount = isGroup ? (groupInfo?.memberCount ?? currentConversation?.memberCount ?? 0) : 0;

  return (
    <>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-card">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            
            {isLoadingInfo ? (
              <>
                <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
                <div className="space-y-2">
                  <div className="h-4 w-24 bg-muted rounded animate-pulse" />
                  <div className="h-3 w-16 bg-muted rounded animate-pulse" />
                </div>
              </>
            ) : (
              <>
                <Avatar className="h-8 w-8">
                  <AvatarImage src={avatarUrl || undefined} alt={displayName} />
                  <AvatarFallback>{avatarFallback}</AvatarFallback>
                </Avatar>
                
                <div>
                  <p className="font-medium text-sm">{displayName}</p>
                  {isGroup ? (
                    <p className="text-xs text-muted-foreground">{headerMemberCount} members</p>
                  ) : (
                    <p className="text-xs text-muted-foreground">@{otherUser?.handle}</p>
                  )}
                </div>
              </>
            )}
          </div>

          {!isLoadingInfo && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover border">
                {isGroup ? (
                  <DropdownMenuItem onClick={() => setShowGroupInfo(true)} className="cursor-pointer">
                    <Info className="h-4 w-4 mr-2" />
                    Group Info
                  </DropdownMenuItem>
                ) : (
                  <>
                    <DropdownMenuItem asChild>
                      <Link to={`/profile/${otherUser.handle}`} className="flex items-center cursor-pointer">
                        <User className="h-4 w-4 mr-2" />
                        View Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={handleBlock}
                      className="text-destructive cursor-pointer"
                    >
                      Block User
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {hasMore && (
          <div className="text-center">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => loadMessages(messages[0]?.created_at)}
              disabled={loading}
            >
              {loading ? 'Loading...' : 'Load more messages'}
            </Button>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble 
            key={msg.id} 
            message={msg} 
            onReport={handleReport}
          />
        ))}

        {Object.keys(typingUsers).length > 0 && !isLoadingInfo && !isGroup && (
          <TypingIndicator userHandle={otherUser.handle} />
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Composer */}
      <form onSubmit={handleSendMessage} className="p-4 border-t bg-card mb-16">
        <div className="flex items-center space-x-2">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileSelect}
            accept="image/*,video/*,.pdf,.doc,.docx"
          />
          
          <Popover open={attachmentMenuOpen} onOpenChange={setAttachmentMenuOpen}>
            <PopoverTrigger asChild>
              <Button 
                type="button" 
                variant="ghost" 
                size="sm" 
                disabled={uploading}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-48 p-1 bg-popover border">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => {
                  fileInputRef.current?.click();
                  setAttachmentMenuOpen(false);
                }}
              >
                <Paperclip className="h-4 w-4 mr-2" />
                Attach File
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => {
                  setShowSignalDialog(true);
                  setAttachmentMenuOpen(false);
                }}
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                Trade Signal
              </Button>
            </PopoverContent>
          </Popover>
          
          <Input
            ref={inputRef}
            value={message}
            onChange={(e) => {
              setMessage(e.target.value);
              handleTyping();
            }}
            placeholder="Type a message..."
            className="flex-1"
            disabled={uploading}
          />
          
          <Button type="submit" size="sm" disabled={!message.trim() || uploading}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
        {uploading && (
          <p className="text-xs text-muted-foreground mt-2">Uploading file...</p>
        )}
      </form>
    </div>

    {isGroup && groupInfo && (
      <GroupInfo 
        conversationId={conversationId} 
        open={showGroupInfo} 
        onOpenChange={setShowGroupInfo}
      />
    )}

    <ChatSignalDialog
      open={showSignalDialog}
      onOpenChange={setShowSignalDialog}
      onSendSignal={handleSendSignal}
    />
  </>
  );
};