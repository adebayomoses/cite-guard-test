import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { MessageCircle, Plus, Search, UserPlus, Hash, Users } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useChatList } from '@/hooks/useChatList';
import { useChatRequests } from '@/hooks/useChatRequests';
import { CreateGroup } from '@/components/chat/CreateGroup';

export const ChatsList = () => {
  const { conversations, loading, error } = useChatList();
  const { pendingCount } = useChatRequests();
  const [searchQuery, setSearchQuery] = React.useState('');
  const [showCreateGroup, setShowCreateGroup] = React.useState(false);

  const filteredConversations = conversations.filter(conv => {
    if (conv.isGroup && conv.groupInfo) {
      return conv.groupInfo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        conv.lastMessage?.body?.toLowerCase().includes(searchQuery.toLowerCase());
    }
    return conv.otherUser?.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.otherUser?.display_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.lastMessage?.body?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-destructive">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Messages</h1>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/chat/requests" className="relative">
              <UserPlus className="h-4 w-4 mr-2" />
              Requests
              {pendingCount > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 min-w-[20px] px-1.5 flex items-center justify-center text-xs">
                  {pendingCount}
                </Badge>
              )}
            </Link>
          </Button>
          <Button variant="default" size="sm" onClick={() => setShowCreateGroup(true)}>
            <Users className="h-4 w-4 mr-2" />
            New Group
          </Button>
          <Button variant="outline" size="sm" asChild>
            <Link to="/chat/new">
              <Plus className="h-4 w-4 mr-2" />
              New Chat
            </Link>
          </Button>
        </div>
      </div>

      {/* Tabs for Single Groups vs Servers */}
      <Tabs defaultValue="single" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="single">
            <Users className="h-4 w-4 mr-2" />
            Chats
          </TabsTrigger>
          <TabsTrigger value="servers" asChild>
            <Link to="/servers" className="flex items-center">
              <Hash className="h-4 w-4 mr-2" />
              Branch Servers
            </Link>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single" className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

      {/* Conversations List */}
      {filteredConversations.length === 0 ? (
        <div className="text-center py-12">
          <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No conversations yet</h3>
          <p className="text-muted-foreground mb-4">Start a conversation to connect with other traders</p>
          <Button asChild>
            <Link to="/chat/new">Start chatting</Link>
          </Button>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredConversations.map((conversation) => {
            const displayName = conversation.isGroup && conversation.groupInfo
              ? conversation.groupInfo.name
              : conversation.otherUser?.display_name || conversation.otherUser?.handle;
            
            const avatarUrl = conversation.isGroup && conversation.groupInfo
              ? conversation.groupInfo.avatar_url
              : conversation.otherUser?.avatar_url;
            
            const avatarFallback = conversation.isGroup && conversation.groupInfo
              ? conversation.groupInfo.name.slice(0, 2).toUpperCase()
              : conversation.otherUser?.handle.slice(0, 2).toUpperCase();

            return (
              <Link key={conversation.id} to={`/chat/${conversation.id}`}>
                <Card className="hover:bg-accent/50 transition-colors cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage 
                          src={avatarUrl || undefined} 
                          alt={displayName}
                        />
                        <AvatarFallback>
                          {avatarFallback}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <p className="text-sm font-medium truncate">
                              {displayName}
                            </p>
                            {conversation.isGroup && (
                              <Badge variant="secondary" className="text-xs">
                                {conversation.memberCount} members
                              </Badge>
                            )}
                            {conversation.unreadCount > 0 && (
                              <Badge variant="default" className="text-xs">
                                {conversation.unreadCount}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(conversation.updatedAt), { addSuffix: true })}
                          </p>
                        </div>
                        
                        <div className="flex items-center space-x-1 mt-1">
                          <p className="text-sm text-muted-foreground truncate">
                            {conversation.lastMessage ? (
                              conversation.lastMessage.attachment_path ? (
                                <span className="flex items-center">
                                  📎 Attachment
                                </span>
                              ) : (
                                conversation.lastMessage.body
                              )
                            ) : (
                              'No messages yet'
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
        </TabsContent>
      </Tabs>

      <CreateGroup open={showCreateGroup} onOpenChange={setShowCreateGroup} />
    </div>
  );
};