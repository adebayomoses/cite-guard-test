import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useServerChannels } from '@/hooks/useServerChannels';
import { Hash, Plus, Trash2 } from 'lucide-react';

interface ServerSettingsProps {
  serverId: string;
  serverInfo: {
    name: string;
    description?: string;
    avatar_url?: string;
  };
  channels: {
    id: string;
    name: string;
    description?: string;
    order: number;
    isDefault: boolean;
  }[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: () => void;
}

export const ServerSettings = ({
  serverId,
  serverInfo,
  channels,
  open,
  onOpenChange,
  onUpdate
}: ServerSettingsProps) => {
  const [name, setName] = useState(serverInfo.name);
  const [description, setDescription] = useState(serverInfo.description || '');
  const [newChannelName, setNewChannelName] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { createChannel, deleteChannel } = useServerChannels();

  const handleUpdateServer = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from('group_settings')
        .update({
          name: name.trim(),
          description: description.trim(),
          updated_at: new Date().toISOString()
        })
        .eq('conversation_id', serverId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Server settings updated',
      });

      onUpdate();
    } catch (error) {
      console.error('Error updating server:', error);
      toast({
        title: 'Error',
        description: 'Failed to update server settings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddChannel = async () => {
    if (!newChannelName.trim()) return;

    const channelId = await createChannel(serverId, newChannelName.trim());
    if (channelId) {
      setNewChannelName('');
      onUpdate();
    }
  };

  const handleDeleteChannel = async (channelId: string) => {
    const success = await deleteChannel(serverId, channelId);
    if (success) {
      onUpdate();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Server Settings</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Server Info Section */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Server Information</h3>
            
            <div>
              <Label htmlFor="server-name">Server Name</Label>
              <Input
                id="server-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={50}
                placeholder="Enter server name"
              />
            </div>

            <div>
              <Label htmlFor="server-description">Description</Label>
              <Textarea
                id="server-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                maxLength={200}
                rows={3}
                placeholder="Enter server description"
              />
            </div>

            <Button
              onClick={handleUpdateServer}
              disabled={loading || !name.trim()}
              className="w-full"
            >
              {loading ? 'Saving...' : 'Save Server Info'}
            </Button>
          </div>

          {/* Channels Management Section */}
          <div className="space-y-4 pt-4 border-t">
            <h3 className="text-sm font-semibold">Channels</h3>
            
            {/* Add New Channel */}
            <div className="flex gap-2">
              <Input
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
                placeholder="New channel name"
                maxLength={30}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleAddChannel();
                  }
                }}
              />
              <Button
                onClick={handleAddChannel}
                disabled={!newChannelName.trim()}
                size="sm"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {/* Existing Channels */}
            <div className="space-y-2">
              {channels.map((channel) => (
                <Card key={channel.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <Hash className="h-4 w-4 text-muted-foreground" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{channel.name}</span>
                          {channel.isDefault && (
                            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">
                              Default
                            </span>
                          )}
                        </div>
                        {channel.description && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {channel.description}
                          </p>
                        )}
                      </div>
                    </div>
                    {!channel.isDefault && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteChannel(channel.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

