import React, { useEffect, useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Users, Settings, LogOut, Trash2, UserPlus, Link2, Edit } from 'lucide-react';
import { useGroupChat, GroupMember, GroupInfo as GroupInfoType } from '@/hooks/useGroupChat';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { GroupSettings } from './GroupSettings';
import { AddGroupMembers } from './AddGroupMembers';

interface GroupInfoProps {
  conversationId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const GroupInfo = ({ conversationId, open, onOpenChange }: GroupInfoProps) => {
  const [groupInfo, setGroupInfo] = useState<GroupInfoType | null>(null);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showAddMembers, setShowAddMembers] = useState(false);
  const [showEditInfo, setShowEditInfo] = useState(false);
  const [isServerChannel, setIsServerChannel] = useState(false);
  const { getGroupInfo, getGroupMembers, removeMember, promoteMember, demoteMember, leaveGroup, deleteGroup, loading } = useGroupChat();
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleCopyGroupLink = () => {
    const groupLink = `${window.location.origin}/chat/${conversationId}`;
    navigator.clipboard.writeText(groupLink);
    toast.success('Group link copied to clipboard');
  };

  const loadGroupData = async () => {
    const info = await getGroupInfo(conversationId);
    if (info) {
      setGroupInfo(info);
      // Check if this is a server channel
      setIsServerChannel(!!info.isServerChannel);
    }

    const membersList = await getGroupMembers(conversationId);
    setMembers(membersList);
  };

  useEffect(() => {
    if (open) {
      loadGroupData();
    }
  }, [open, conversationId]);

  const currentUserMember = members.find(m => m.user_id === user?.id);
  const isAdmin = currentUserMember?.role === 'admin';
  const isCreator = groupInfo?.created_by === user?.id;

  const handleRemoveMember = async (userId: string) => {
    const success = await removeMember(conversationId, userId);
    if (success) loadGroupData();
  };

  const handlePromote = async (userId: string) => {
    const success = await promoteMember(conversationId, userId);
    if (success) loadGroupData();
  };

  const handleDemote = async (userId: string) => {
    const success = await demoteMember(conversationId, userId);
    if (success) loadGroupData();
  };

  const handleLeave = async () => {
    if (!user) return;
    const success = await leaveGroup(conversationId, user.id);
    if (success) {
      onOpenChange(false);
      navigate('/chat');
    }
  };

  const handleDelete = async () => {
    const success = await deleteGroup(conversationId);
    if (success) {
      onOpenChange(false);
      navigate('/chat');
    }
  };

  if (!groupInfo) return null;

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Group Info</SheetTitle>
          </SheetHeader>

          <div className="space-y-6 py-4">
            {/* Group Avatar & Name */}
            <div className="flex flex-col items-center gap-2">
              <Avatar className="h-24 w-24">
                <AvatarImage src={groupInfo.avatar_url} />
                <AvatarFallback>{groupInfo.name.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <h3 className="text-xl font-semibold">{groupInfo.name}</h3>
              {groupInfo.description && (
                <p className="text-sm text-muted-foreground text-center">{groupInfo.description}</p>
              )}
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>{members.length > 0 ? members.length : (groupInfo.memberCount || 0)} members</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              {isAdmin && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => setShowEditInfo(true)}>
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Info
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => setShowAddMembers(true)}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add Members
                  </Button>
                </div>
              )}
              <Button variant="outline" size="sm" className="w-full" onClick={handleCopyGroupLink}>
                <Link2 className="h-4 w-4 mr-2" />
                Copy Group Link
              </Button>
              {isAdmin && (
                <Button variant="outline" size="sm" className="w-full" onClick={() => setShowSettings(true)}>
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              )}
            </div>

            {/* Members List */}
            <div>
              <h4 className="text-sm font-medium mb-3">Members</h4>
              <div className="space-y-2">
                {members.map((member) => (
                  <div key={member.user_id} className="flex items-center justify-between p-2 rounded-lg hover:bg-accent">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={member.profiles.avatar_url} />
                        <AvatarFallback>{member.profiles.handle.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{member.profiles.display_name}</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-muted-foreground">@{member.profiles.handle}</p>
                          {member.role === 'admin' && (
                            <Badge variant="secondary" className="text-xs">Admin</Badge>
                          )}
                          {member.user_id === groupInfo.created_by && (
                            <Badge variant="default" className="text-xs">Creator</Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {isAdmin && member.user_id !== user?.id && member.user_id !== groupInfo.created_by && (
                      <div className="flex gap-1">
                        {member.role === 'member' ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handlePromote(member.user_id)}
                            disabled={loading}
                          >
                            Promote
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDemote(member.user_id)}
                            disabled={loading}
                          >
                            Demote
                          </Button>
                        )}
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="text-destructive">
                              Remove
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove Member</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to remove {member.profiles.display_name} from this group?
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleRemoveMember(member.user_id)}>
                                Remove
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Leave/Delete Group */}
            <div className="pt-4 border-t space-y-2">
              {!isCreator && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" className="w-full" disabled={loading}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Leave Group
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Leave Group</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to leave this group? You'll need to be re-invited to join again.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleLeave}>Leave</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}

              {(isCreator || (isServerChannel && isAdmin)) && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" className="w-full" disabled={loading}>
                      <Trash2 className="h-4 w-4 mr-2" />
                      {isServerChannel ? 'Delete Channel' : 'Delete Group'}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>{isServerChannel ? 'Delete Channel' : 'Delete Group'}</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete this {isServerChannel ? 'channel' : 'group'}? This action cannot be undone and all messages will be lost.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDelete} className="bg-destructive">
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {showEditInfo && groupInfo && (
        <GroupSettings
          conversationId={conversationId}
          groupInfo={groupInfo}
          open={showEditInfo}
          onOpenChange={setShowEditInfo}
          onUpdate={loadGroupData}
        />
      )}

      {showSettings && groupInfo && (
        <GroupSettings
          conversationId={conversationId}
          groupInfo={groupInfo}
          open={showSettings}
          onOpenChange={setShowSettings}
          onUpdate={loadGroupData}
        />
      )}

      {showAddMembers && (
        <AddGroupMembers
          conversationId={conversationId}
          open={showAddMembers}
          onOpenChange={setShowAddMembers}
          onMembersAdded={loadGroupData}
        />
      )}
    </>
  );
};
