import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, MessageSquare } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { ChatRequestModal } from './ChatRequestModal';
import { toast } from 'sonner';

interface UserProfile {
  id: string;
  handle: string;
  display_name: string | null;
  avatar_url: string | null;
  verified_status: string;
}

export const NewChat = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    try {
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('id, handle, display_name, avatar_url, verified_status')
        .or(`handle.ilike.%${query}%,display_name.ilike.%${query}%`)
        .limit(20);

      if (error) throw error;

      setSearchResults(profiles || []);
    } catch (error) {
      console.error('Error searching users:', error);
      toast.error('Failed to search users. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendRequest = (profile: UserProfile) => {
    setSelectedUser(profile);
    setShowRequestModal(true);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <Button variant="ghost" size="sm" onClick={() => navigate('/chat')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">New Chat</h1>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input
          placeholder="Search by handle or name..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Search Results */}
      {loading && (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      )}

      {!loading && searchQuery.length >= 2 && searchResults.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No users found for "{searchQuery}"</p>
        </div>
      )}

      {!loading && searchResults.length > 0 && (
        <div className="space-y-2">
          {searchResults.map((profile) => (
            <Card key={profile.id} className="hover:bg-accent/50 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage 
                        src={profile.avatar_url || undefined} 
                        alt={profile.handle}
                      />
                      <AvatarFallback>
                        {profile.handle.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <div className="flex items-center space-x-2">
                        <p className="font-medium">
                          {profile.display_name || profile.handle}
                        </p>
                        {profile.verified_status === 'verified' && (
                          <Badge variant="secondary" className="text-xs">
                            ✓
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">@{profile.handle}</p>
                    </div>
                  </div>

                  <Button 
                    size="sm" 
                    onClick={() => handleSendRequest(profile)}
                  >
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Send Request
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {searchQuery.length < 2 && (
        <div className="text-center py-12">
          <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Find someone to chat with</h3>
          <p className="text-muted-foreground">
            Search for users by their handle or display name to send a chat request
          </p>
        </div>
      )}

      {selectedUser && (
        <ChatRequestModal
          open={showRequestModal}
          onOpenChange={setShowRequestModal}
          user={selectedUser}
        />
      )}
    </div>
  );
};