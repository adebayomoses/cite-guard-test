import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Lock, Star, Trophy } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCanCreatePremiumContent } from '@/hooks/useCanCreatePremiumContent';
import { Progress } from '@/components/ui/progress';

interface PremiumContentGateProps {
  children?: React.ReactNode;
  featureName?: string;
}

export const PremiumContentGate = ({ children, featureName = 'this feature' }: PremiumContentGateProps) => {
  const { canCreate, loading, currentXP, xpNeeded, proRankThreshold, currentRank, requiredRank } = useCanCreatePremiumContent();

  if (loading) {
    return null;
  }

  if (canCreate && children) {
    return <>{children}</>;
  }
  
  // If canCreate but no children, this is just being used as a gate display
  if (canCreate) {
    return null;
  }

  const progress = (currentXP / proRankThreshold) * 100;
  const requiredRankName = requiredRank?.name || 'Pro Trader';

  return (
    <Alert className="border-primary/30 bg-primary/5">
      <Lock className="h-4 w-4" />
      <AlertTitle className="flex items-center gap-2">
        {requiredRankName} Rank Required
      </AlertTitle>
      <AlertDescription className="mt-3 space-y-4">
        <p className="text-sm text-muted-foreground">
          Creating {featureName} requires <strong>{requiredRankName} rank</strong> ({proRankThreshold}+ XP). 
          Keep engaging with the community to level up!
        </p>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              <span>{currentRank?.icon}</span>
              <span>{currentRank?.name}</span>
            </span>
            <span className="text-muted-foreground">
              {currentXP} / {proRankThreshold} XP
            </span>
          </div>
          <Progress value={progress} className="h-2" />
          <p className="text-xs text-muted-foreground">
            {xpNeeded} XP needed to unlock
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link to="/status" className="gap-2">
              <Trophy className="h-4 w-4" />
              View Status
            </Link>
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
};

interface PremiumCreateButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  asChild?: boolean;
  className?: string;
}

export const PremiumCreateButton = ({ children, onClick, asChild, className }: PremiumCreateButtonProps) => {
  const { canCreate, loading, currentXP, proRankThreshold, currentRank, requiredRank } = useCanCreatePremiumContent();

  if (loading) {
    return (
      <Button disabled className={className}>
        {children}
      </Button>
    );
  }

  const requiredRankName = requiredRank?.name || 'Pro Trader';

  if (!canCreate) {
    return (
      <div className="relative group">
        <Button disabled className={className}>
          <Lock className="h-4 w-4 mr-2" />
          {children}
        </Button>
        <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 hidden group-hover:block z-50">
          <div className="bg-popover border rounded-lg shadow-lg p-3 text-sm w-64">
            <p className="font-medium mb-1">{requiredRankName} rank required</p>
            <p className="text-muted-foreground text-xs">
              {currentRank?.icon} {currentRank?.name} • {currentXP}/{proRankThreshold} XP
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Button onClick={onClick} className={className}>
      {children}
    </Button>
  );
};
