import { Button } from "@/components/ui/button";

const markets = [
  { id: "all", label: "All", icon: "📊" },
  { id: "stocks", label: "Stocks", icon: "📈" },
  { id: "crypto", label: "Crypto", icon: "₿" },
  { id: "forex", label: "Forex", icon: "💱" },
  { id: "options", label: "Options", icon: "🎯" },
  { id: "futures", label: "Futures", icon: "⚡" },
];

interface MarketTabsProps {
  activeMarket: string;
  onMarketChange: (market: string) => void;
}

export const MarketTabs = ({ activeMarket, onMarketChange }: MarketTabsProps) => {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 px-4 scrollbar-hide">
      {markets.map((market) => (
        <Button
          key={market.id}
          variant={activeMarket === market.id ? "default" : "outline"}
          size="sm"
          onClick={() => onMarketChange(market.id)}
          className="flex items-center gap-2 whitespace-nowrap transition-all duration-200 relative z-10 cursor-pointer"
        >
          <span className="text-sm">{market.icon}</span>
          <span className="font-medium">{market.label}</span>
        </Button>
      ))}
    </div>
  );
};