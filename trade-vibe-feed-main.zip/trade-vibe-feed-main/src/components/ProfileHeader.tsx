import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, ShieldCheck, Crown, Users, Edit, CheckCircle, Share } from 'lucide-react';
import { useState } from 'react';
import { profileApi } from '@/lib/api/profile';
import { useToast } from '@/hooks/use-toast';
import { RankBadge } from '@/components/status/RankBadge';

interface ProfileHeaderProps {
  profile: {
    id: string;
    username: string;
    display_name?: string;
    avatar?: string;
    bio?: string;
    verified: 'unverified' | 'manual' | 'broker';
    followers: number;
    following: number;
  };
  isOwnProfile: boolean;
  isFollowing?: boolean;
  onFollowChange?: (isFollowing: boolean, newFollowerCount: number) => void;
  onEditClick?: () => void;
}

const getVerificationIcon = (status: string) => {
  switch (status) {
    case 'broker':
      return <Crown className="h-4 w-4" />;
    case 'manual':
      return <ShieldCheck className="h-4 w-4" />;
    default:
      return <Shield className="h-4 w-4" />;
  }
};

const getVerificationLabel = (status: string) => {
  switch (status) {
    case 'broker':
      return 'Broker Verified';
    case 'manual':
      return 'Verified';
    default:
      return 'Unverified';
  }
};

export const ProfileHeader = ({ 
  profile, 
  isOwnProfile, 
  isFollowing, 
  onFollowChange,
  onEditClick 
}: ProfileHeaderProps) => {
  const [isFollowLoading, setIsFollowLoading] = useState(false);
  const [isVerifyLoading, setIsVerifyLoading] = useState(false);
  const { toast } = useToast();

  const handleFollow = async () => {
    setIsFollowLoading(true);
    try {
      const result = await profileApi.toggleFollow(profile.id);
      onFollowChange?.(result.isFollowing, result.followers);
      toast({
        title: result.isFollowing ? 'Following' : 'Unfollowed',
        description: result.isFollowing 
          ? `You are now following ${profile.display_name || profile.username}`
          : `You unfollowed ${profile.display_name || profile.username}`,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update follow status',
        variant: 'destructive',
      });
    } finally {
      setIsFollowLoading(false);
    }
  };

  const handleShare = async () => {
    const profileUrl = `${window.location.origin}/profile/${profile.username}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${profile.display_name || profile.username}'s Profile`,
          text: `Check out ${profile.display_name || profile.username}'s trading profile`,
          url: profileUrl
        });
      } catch (error) {
        // User cancelled sharing, fallback to clipboard
        if (navigator.clipboard) {
          await navigator.clipboard.writeText(profileUrl);
          toast({
            title: 'Profile link copied!',
            description: 'The profile link has been copied to your clipboard.',
          });
        }
      }
    } else if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(profileUrl);
        toast({
          title: 'Profile link copied!',
          description: 'The profile link has been copied to your clipboard.',
        });
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to copy profile link',
          variant: 'destructive',
        });
      }
    } else {
      toast({
        title: 'Error',
        description: 'Sharing not supported on this device',
        variant: 'destructive',
      });
    }
  };

  const handleVerify = async () => {
    setIsVerifyLoading(true);
    try {
      await profileApi.startVerification();
      toast({
        title: 'Verification Started',
        description: 'Your verification request has been submitted.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to start verification process',
        variant: 'destructive',
      });
    } finally {
      setIsVerifyLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 p-6">
      <div className="flex items-start gap-4">
        <Avatar className="h-20 w-20">
          <AvatarImage src={profile.avatar} />
          <AvatarFallback>{profile.display_name?.[0] || profile.username[0]}</AvatarFallback>
        </Avatar>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-bold truncate">
              {profile.display_name || profile.username}
            </h1>
            <RankBadge userId={profile.id} size="sm" />
            <Badge 
              variant={profile.verified === 'unverified' ? 'outline' : 'default'}
              className="flex items-center gap-1"
            >
              {getVerificationIcon(profile.verified)}
              {getVerificationLabel(profile.verified)}
            </Badge>
          </div>
          
          <p className="text-muted-foreground text-sm mb-2">@{profile.username}</p>
          
          {profile.bio && (
            <p className="text-sm leading-relaxed">{profile.bio}</p>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span className="font-medium">{profile.followers}</span>
            <span className="text-muted-foreground">followers</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="font-medium">{profile.following}</span>
            <span className="text-muted-foreground">following</span>
          </div>
        </div>

        <div className="flex gap-2">
          {/* Share button - available for all profiles */}
          <Button variant="outline" onClick={handleShare}>
            <Share className="h-4 w-4 mr-2" />
            Share
          </Button>
          
          {isOwnProfile ? (
            <>
              <Button variant="outline" onClick={onEditClick}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
              {profile.verified === 'unverified' && (
                <Button 
                  onClick={handleVerify}
                  disabled={isVerifyLoading}
                  className="bg-primary"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {isVerifyLoading ? 'Verifying...' : 'Verify'}
                </Button>
              )}
            </>
          ) : (
            <Button 
              onClick={handleFollow}
              disabled={isFollowLoading}
              variant={isFollowing ? 'outline' : 'default'}
            >
              {isFollowLoading ? 'Loading...' : isFollowing ? 'Unfollow' : 'Follow'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};