import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { AvatarUploader } from "@/components/AvatarUploader";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export const CreateMentorshipChannel = ({ open, onOpenChange, onSuccess }: Props) => {
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string>();
  const [type, setType] = useState<'free' | 'paid'>('free');
  const [price, setPrice] = useState('');
  const [maxMentees, setMaxMentees] = useState('50');
  const { toast } = useToast();

  const handleCreate = async () => {
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "Channel name is required",
        variant: "destructive",
      });
      return;
    }

    if (type === 'paid' && (!price || parseFloat(price) <= 0)) {
      toast({
        title: "Error",
        description: "Please enter a valid price",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('chat-api/mentorship/create', {
        body: {
          name,
          description,
          avatarUrl,
          mentorshipType: type,
          price: type === 'paid' ? parseFloat(price) : null,
          billingCycle: 'monthly',
          maxMentees: parseInt(maxMentees) || 50,
        },
      });

      if (error) {
        const errorMessage = error.message || "Failed to create mentorship channel";
        throw new Error(errorMessage);
      }

      // Check if data contains an error field
      if (data?.error) {
        throw new Error(data.message || data.error);
      }

      toast({
        title: "Success!",
        description: "Your mentorship channel has been created",
      });

      onSuccess();
    } catch (error: any) {
      console.error('Mentorship channel creation error:', error);
      toast({
        title: "Unable to Create Channel",
        description: error.message || "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Mentorship Channel</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">

          <div className="flex justify-center">
            <AvatarUploader currentUrl={avatarUrl} onUpload={setAvatarUrl} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Channel Name *</Label>
            <Input
              id="name"
              placeholder="Forex Trading Masterclass"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={80}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="What will members learn? What topics will you cover?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              maxLength={500}
            />
          </div>

          <div className="space-y-2">
            <Label>Channel Type *</Label>
            <RadioGroup value={type} onValueChange={(v) => setType(v as 'free' | 'paid')}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="free" id="free" />
                <Label htmlFor="free" className="font-normal cursor-pointer">
                  Free - Open to all
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="paid" id="paid" />
                <Label htmlFor="paid" className="font-normal cursor-pointer">
                  Paid - Monthly subscription
                </Label>
              </div>
            </RadioGroup>
          </div>

          {type === 'paid' && (
            <div className="space-y-2">
              <Label htmlFor="price">Monthly Price (USD) *</Label>
              <Input
                id="price"
                type="number"
                placeholder="29.99"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                min="1"
                step="0.01"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="maxMentees">Max Members</Label>
            <Input
              id="maxMentees"
              type="number"
              placeholder="50"
              value={maxMentees}
              onChange={(e) => setMaxMentees(e.target.value)}
              min="1"
            />
            <p className="text-sm text-muted-foreground">
              Limit the number of members to maintain quality
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleCreate} disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Channel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
