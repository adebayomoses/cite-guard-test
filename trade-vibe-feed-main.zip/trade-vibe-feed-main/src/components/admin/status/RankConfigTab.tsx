import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Plus, Save, GripVertical, Lock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface RankConfig {
  key: string;
  name: string;
  minXP: number;
  icon: string;
  stars: number;
  color: string;
}

const DEFAULT_RANKS: RankConfig[] = [
  { key: 'rookie', name: 'Rookie', minXP: 0, icon: '🌟', stars: 0, color: 'text-muted-foreground' },
  { key: 'trader', name: 'Trader', minXP: 100, icon: '⭐', stars: 1, color: 'text-yellow-500' },
  { key: 'pro', name: 'Pro', minXP: 500, icon: '⭐⭐', stars: 2, color: 'text-yellow-500' },
  { key: 'elite', name: 'Elite', minXP: 2000, icon: '⭐⭐⭐', stars: 3, color: 'text-yellow-500' },
  { key: 'legend', name: 'Legend', minXP: 5000, icon: '👑', stars: 5, color: 'text-amber-400' },
];

export const RankConfigTab = () => {
  const [ranks, setRanks] = useState<RankConfig[]>(DEFAULT_RANKS);
  const [premiumContentMinRank, setPremiumContentMinRank] = useState('pro');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const [ranksResult, minRankResult] = await Promise.all([
        supabase.from('site_settings').select('value').eq('key', 'ranks_config').maybeSingle(),
        supabase.from('site_settings').select('value').eq('key', 'premium_content_min_rank').maybeSingle(),
      ]);

      if (ranksResult.error) throw ranksResult.error;
      if (ranksResult.data?.value && typeof ranksResult.data.value === 'string') {
        setRanks(JSON.parse(ranksResult.data.value));
      }

      if (minRankResult.data?.value) {
        const val = minRankResult.data.value;
        if (typeof val === 'string') {
          setPremiumContentMinRank(val.replace(/"/g, ''));
        }
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error: ranksError } = await supabase
        .from('site_settings')
        .upsert({
          key: 'ranks_config',
          value: JSON.stringify(ranks),
          updated_at: new Date().toISOString(),
        });

      if (ranksError) throw ranksError;

      const { error: minRankError } = await supabase
        .from('site_settings')
        .upsert({
          key: 'premium_content_min_rank',
          value: JSON.stringify(premiumContentMinRank),
          updated_at: new Date().toISOString(),
        });

      if (minRankError) throw minRankError;

      toast({ title: 'Settings saved', description: 'Rank and premium content settings updated successfully.' });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({ title: 'Error', description: 'Failed to save settings.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const updateRank = (index: number, field: keyof RankConfig, value: string | number) => {
    const updated = [...ranks];
    updated[index] = { ...updated[index], [field]: value };
    setRanks(updated);
  };

  const addRank = () => {
    const maxXP = Math.max(...ranks.map(r => r.minXP), 0);
    setRanks([
      ...ranks,
      {
        key: `rank_${Date.now()}`,
        name: 'New Rank',
        minXP: maxXP + 1000,
        icon: '⭐',
        stars: ranks.length,
        color: 'text-yellow-500',
      },
    ]);
  };

  const removeRank = (index: number) => {
    if (ranks.length <= 1) return;
    setRanks(ranks.filter((_, i) => i !== index));
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Premium Content Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Premium Content Settings
          </CardTitle>
          <CardDescription>
            Define which rank is required to create premium content (Events, Challenges, Mentorship Channels).
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Required Rank for Creation</Label>
            <Select value={premiumContentMinRank} onValueChange={setPremiumContentMinRank}>
              <SelectTrigger className="w-full md:w-[300px]">
                <SelectValue placeholder="Select required rank" />
              </SelectTrigger>
              <SelectContent>
                {[...ranks].sort((a, b) => a.minXP - b.minXP).map((rank) => (
                  <SelectItem key={rank.key} value={rank.key}>
                    <span className="flex items-center gap-2">
                      <span>{rank.icon}</span>
                      <span>{rank.name}</span>
                      <span className="text-muted-foreground text-xs">({rank.minXP}+ XP)</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Users must reach this rank to create Events, Challenges, and Mentorship Channels. Admins can always create premium content.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Rank Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Rank Configuration</CardTitle>
          <CardDescription>
            Define the rank tiers and XP thresholds for users. Ranks should be ordered from lowest to highest XP.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
        <div className="space-y-3">
          {ranks.map((rank, index) => (
            <div key={rank.key} className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
              <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
              
              <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Icon</Label>
                  <Input
                    value={rank.icon}
                    onChange={(e) => updateRank(index, 'icon', e.target.value)}
                    className="text-center text-lg"
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Name</Label>
                  <Input
                    value={rank.name}
                    onChange={(e) => updateRank(index, 'name', e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Min XP</Label>
                  <Input
                    type="number"
                    value={rank.minXP}
                    onChange={(e) => updateRank(index, 'minXP', parseInt(e.target.value) || 0)}
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Stars</Label>
                  <Input
                    type="number"
                    value={rank.stars}
                    onChange={(e) => updateRank(index, 'stars', parseInt(e.target.value) || 0)}
                    min={0}
                    max={10}
                  />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Color Class</Label>
                  <Input
                    value={rank.color}
                    onChange={(e) => updateRank(index, 'color', e.target.value)}
                    placeholder="text-yellow-500"
                  />
                </div>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeRank(index)}
                disabled={ranks.length <= 1}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Button variant="outline" onClick={addRank}>
            <Plus className="h-4 w-4 mr-2" />
            Add Rank
          </Button>
          <Button onClick={saveSettings} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>

        {/* Preview */}
        <div className="pt-4 border-t">
          <h4 className="font-medium mb-3">Rank Ladder Preview</h4>
          <div className="flex flex-wrap gap-2">
            {[...ranks].sort((a, b) => a.minXP - b.minXP).map((rank) => (
              <div
                key={rank.key}
                className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg"
              >
                <span className="text-lg">{rank.icon}</span>
                <span className={rank.color}>{rank.name}</span>
                <span className="text-xs text-muted-foreground">({rank.minXP}+ XP)</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
      </Card>
    </div>
  );
};
