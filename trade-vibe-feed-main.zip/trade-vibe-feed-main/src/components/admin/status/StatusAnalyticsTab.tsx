import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/integrations/supabase/client';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const RANK_COLORS: Record<string, string> = {
  rookie: '#6b7280',
  trader: '#eab308',
  pro: '#f59e0b',
  elite: '#f97316',
  legend: '#dc2626',
};

export const StatusAnalyticsTab = () => {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['admin-status-analytics'],
    queryFn: async () => {
      // Get rank distribution
      const { data: rankData } = await supabase
        .from('user_xp')
        .select('current_rank');

      const rankCounts = (rankData || []).reduce(
        (acc, row) => {
          acc[row.current_rank] = (acc[row.current_rank] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      );

      // Get top weekly earners
      const { data: topWeekly } = await supabase
        .from('user_xp')
        .select(`
          user_id,
          weekly_xp,
          total_xp,
          current_rank,
          profile:profiles!user_xp_user_id_fkey(handle, display_name, avatar_url)
        `)
        .order('weekly_xp', { ascending: false })
        .limit(10);

      // Get achievement unlock stats
      const { data: achievements } = await supabase.from('achievements').select('id, name, icon');

      const { data: unlockCounts } = await supabase
        .from('user_achievements')
        .select('achievement_id');

      const achievementStats = (achievements || []).map((a) => ({
        ...a,
        unlocks: (unlockCounts || []).filter((u) => u.achievement_id === a.id).length,
      }));

      // Get XP distribution histogram
      const { data: xpData } = await supabase.from('user_xp').select('total_xp');

      const xpBuckets = [
        { range: '0-100', min: 0, max: 100, count: 0 },
        { range: '101-500', min: 101, max: 500, count: 0 },
        { range: '501-2000', min: 501, max: 2000, count: 0 },
        { range: '2001-5000', min: 2001, max: 5000, count: 0 },
        { range: '5000+', min: 5001, max: Infinity, count: 0 },
      ];

      (xpData || []).forEach((row) => {
        const bucket = xpBuckets.find((b) => row.total_xp >= b.min && row.total_xp <= b.max);
        if (bucket) bucket.count++;
      });

      // Total stats
      const totalUsers = xpData?.length || 0;
      const totalXP = (xpData || []).reduce((sum, row) => sum + row.total_xp, 0);
      const avgXP = totalUsers > 0 ? Math.round(totalXP / totalUsers) : 0;

      return {
        rankCounts,
        topWeekly: topWeekly || [],
        achievementStats,
        xpBuckets,
        totalUsers,
        totalXP,
        avgXP,
      };
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  const rankPieData = Object.entries(stats?.rankCounts || {}).map(([rank, count]) => ({
    name: rank.charAt(0).toUpperCase() + rank.slice(1),
    value: count,
    color: RANK_COLORS[rank] || '#6b7280',
  }));

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Users with XP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats?.totalUsers || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total XP Earned
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{(stats?.totalXP || 0).toLocaleString()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Average XP per User
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats?.avgXP || 0}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Rank Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Rank Distribution</CardTitle>
            <CardDescription>Users by current rank</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={rankPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}`}
                  >
                    {rankPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* XP Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>XP Distribution</CardTitle>
            <CardDescription>Users by XP range</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats?.xpBuckets}>
                  <XAxis dataKey="range" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Weekly Earners */}
      <Card>
        <CardHeader>
          <CardTitle>Top Weekly XP Earners</CardTitle>
          <CardDescription>Users with most XP earned this week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stats?.topWeekly.slice(0, 10).map((user: any, index: number) => (
              <div key={user.user_id} className="flex items-center gap-3">
                <div className="text-lg font-bold text-muted-foreground w-6">
                  #{index + 1}
                </div>
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.profile?.avatar_url || ''} />
                  <AvatarFallback>
                    {user.profile?.handle?.charAt(0).toUpperCase() || '?'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <span className="font-medium">
                    {user.profile?.display_name || user.profile?.handle}
                  </span>
                </div>
                <Badge variant="outline">{user.current_rank}</Badge>
                <div className="text-right">
                  <div className="font-bold text-primary">+{user.weekly_xp} XP</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievement Unlock Rates */}
      <Card>
        <CardHeader>
          <CardTitle>Achievement Unlock Rates</CardTitle>
          <CardDescription>How many users have unlocked each achievement</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {stats?.achievementStats
              .sort((a: any, b: any) => b.unlocks - a.unlocks)
              .slice(0, 10)
              .map((achievement: any) => {
                const percentage =
                  stats.totalUsers > 0
                    ? Math.round((achievement.unlocks / stats.totalUsers) * 100)
                    : 0;
                return (
                  <div key={achievement.id} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span>{achievement.icon}</span>
                        <span className="font-medium">{achievement.name}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {achievement.unlocks} users ({percentage}%)
                      </span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
