import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Save, RefreshCw, ChevronDown, FileText, TrendingUp, Trophy, Calendar, Users, MessageSquare } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface XPSettings {
  // Content Creation
  xp_post_created: number;
  xp_comment_created: number;
  xp_lifestyle_video_posted: number;
  
  // Signals & Voting
  xp_vote_useful: number;
  xp_vote_not_useful: number;
  xp_signal_won: number;
  xp_signal_lost: number;
  
  // Challenges
  xp_challenge_created: number;
  xp_challenge_joined: number;
  xp_challenge_won: number;
  xp_challenge_top3: number;
  
  // Events
  xp_event_created: number;
  
  // Mentorship
  xp_mentorship_channel_created: number;
  xp_mentorship_subscriber_gained: number;
  xp_mentorship_session_completed: number;
  
  // Achievements & Streaks
  xp_achievement_unlocked: number;
  xp_streak_bonus_enabled: boolean;
  xp_streak_bonus_multiplier: number;
}

const DEFAULT_SETTINGS: XPSettings = {
  // Content Creation
  xp_post_created: 5,
  xp_comment_created: 1,
  xp_lifestyle_video_posted: 10,
  
  // Signals & Voting
  xp_vote_useful: 2,
  xp_vote_not_useful: -1,
  xp_signal_won: 25,
  xp_signal_lost: -5,
  
  // Challenges
  xp_challenge_created: 20,
  xp_challenge_joined: 10,
  xp_challenge_won: 100,
  xp_challenge_top3: 50,
  
  // Events
  xp_event_created: 15,
  
  // Mentorship
  xp_mentorship_channel_created: 50,
  xp_mentorship_subscriber_gained: 10,
  xp_mentorship_session_completed: 25,
  
  // Achievements & Streaks
  xp_achievement_unlocked: 0,
  xp_streak_bonus_enabled: true,
  xp_streak_bonus_multiplier: 1.5,
};

interface XPCategory {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  settings: {
    key: keyof XPSettings;
    label: string;
    description?: string;
  }[];
}

const XP_CATEGORIES: XPCategory[] = [
  {
    id: 'content',
    title: 'Content Creation',
    description: 'XP for creating posts, comments, and videos',
    icon: <FileText className="h-4 w-4" />,
    settings: [
      { key: 'xp_post_created', label: 'Creating a Post', description: 'Base XP for publishing a new post' },
      { key: 'xp_comment_created', label: 'Posting a Comment', description: 'XP for commenting on posts' },
      { key: 'xp_lifestyle_video_posted', label: 'Posting a Lifestyle Video', description: 'XP for uploading a video' },
    ],
  },
  {
    id: 'signals',
    title: 'Signals & Voting',
    description: 'XP for trading signals and receiving votes',
    icon: <TrendingUp className="h-4 w-4" />,
    settings: [
      { key: 'xp_vote_useful', label: 'Receiving a Useful Vote', description: 'XP when your post is marked useful' },
      { key: 'xp_vote_not_useful', label: 'Receiving a Not Useful Vote', description: 'XP deduction for not useful votes' },
      { key: 'xp_signal_won', label: 'Signal Win', description: 'XP when your signal hits target' },
      { key: 'xp_signal_lost', label: 'Signal Loss', description: 'XP deduction when signal hits stop loss' },
    ],
  },
  {
    id: 'challenges',
    title: 'Challenges',
    description: 'XP for challenge participation and success',
    icon: <Trophy className="h-4 w-4" />,
    settings: [
      { key: 'xp_challenge_created', label: 'Creating a Challenge', description: 'XP for hosting a new challenge' },
      { key: 'xp_challenge_joined', label: 'Joining a Challenge', description: 'XP for participating in a challenge' },
      { key: 'xp_challenge_won', label: 'Winning a Challenge', description: 'XP for 1st place finish' },
      { key: 'xp_challenge_top3', label: 'Top 3 in Challenge', description: 'XP for 2nd or 3rd place' },
    ],
  },
  {
    id: 'events',
    title: 'Events',
    description: 'XP for event creation and participation',
    icon: <Calendar className="h-4 w-4" />,
    settings: [
      { key: 'xp_event_created', label: 'Creating an Event', description: 'XP for hosting an event' },
    ],
  },
  {
    id: 'mentorship',
    title: 'Mentorship',
    description: 'XP for mentoring and teaching others',
    icon: <Users className="h-4 w-4" />,
    settings: [
      { key: 'xp_mentorship_channel_created', label: 'Creating a Mentorship Channel', description: 'XP for starting a mentorship program' },
      { key: 'xp_mentorship_subscriber_gained', label: 'Gaining a Subscriber', description: 'XP when someone joins your mentorship' },
      { key: 'xp_mentorship_session_completed', label: 'Completing a Session', description: 'XP for finishing a mentorship session' },
    ],
  },
];

export const XPRewardsTab = () => {
  const [settings, setSettings] = useState<XPSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [openCategories, setOpenCategories] = useState<string[]>(['content', 'signals', 'challenges', 'mentorship']);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const keys = Object.keys(DEFAULT_SETTINGS);
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', keys);

      if (error) throw error;

      const newSettings = { ...DEFAULT_SETTINGS };
      data?.forEach((item) => {
        const key = item.key as keyof XPSettings;
        const value = typeof item.value === 'string' ? item.value : String(item.value);
        if (key === 'xp_streak_bonus_enabled') {
          newSettings[key] = value === 'true';
        } else if (key === 'xp_streak_bonus_multiplier') {
          newSettings[key] = parseFloat(value) || 1.5;
        } else {
          (newSettings as any)[key] = parseInt(value) || 0;
        }
      });
      setSettings(newSettings);
    } catch (error) {
      console.error('Error fetching XP settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const updates = Object.entries(settings).map(([key, value]) => ({
        key,
        value: String(value),
        updated_at: new Date().toISOString(),
      }));

      for (const update of updates) {
        const { error } = await supabase
          .from('site_settings')
          .upsert(update);
        if (error) throw error;
      }

      toast({ title: 'XP Settings saved', description: 'XP reward configuration updated successfully.' });
    } catch (error) {
      console.error('Error saving XP settings:', error);
      toast({ title: 'Error', description: 'Failed to save XP settings.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const resetToDefaults = () => {
    setSettings(DEFAULT_SETTINGS);
  };

  const toggleCategory = (categoryId: string) => {
    setOpenCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const getCategoryTotal = (category: XPCategory) => {
    return category.settings.reduce((sum, setting) => {
      const value = settings[setting.key];
      return sum + (typeof value === 'number' ? Math.abs(value) : 0);
    }, 0);
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>XP Rewards Configuration</CardTitle>
        <CardDescription>
          Configure how much XP users earn or lose for various actions. Negative values deduct XP.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Category Collapsibles */}
        {XP_CATEGORIES.map((category) => (
          <Collapsible
            key={category.id}
            open={openCategories.includes(category.id)}
            onOpenChange={() => toggleCategory(category.id)}
          >
            <CollapsibleTrigger asChild>
              <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg cursor-pointer hover:bg-muted transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg text-primary">
                    {category.icon}
                  </div>
                  <div>
                    <h4 className="font-medium">{category.title}</h4>
                    <p className="text-xs text-muted-foreground">{category.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground">
                    Max: <span className="font-medium text-foreground">{getCategoryTotal(category)} XP</span>
                  </span>
                  <ChevronDown
                    className={`h-4 w-4 transition-transform ${
                      openCategories.includes(category.id) ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </div>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border border-t-0 rounded-b-lg">
                {category.settings.map((setting) => (
                  <div key={setting.key} className="space-y-2">
                    <Label htmlFor={setting.key}>{setting.label}</Label>
                    <Input
                      id={setting.key}
                      type="number"
                      value={settings[setting.key] as number}
                      onChange={(e) =>
                        setSettings({ ...settings, [setting.key]: parseInt(e.target.value) || 0 })
                      }
                    />
                    {setting.description && (
                      <p className="text-xs text-muted-foreground">{setting.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        ))}

        {/* Streak & Achievement Settings */}
        <Collapsible
          open={openCategories.includes('streaks')}
          onOpenChange={() => toggleCategory('streaks')}
        >
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg cursor-pointer hover:bg-muted transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg text-primary">
                  <MessageSquare className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="font-medium">Achievements & Streaks</h4>
                  <p className="text-xs text-muted-foreground">Bonus multipliers and achievement rewards</p>
                </div>
              </div>
              <ChevronDown
                className={`h-4 w-4 transition-transform ${
                  openCategories.includes('streaks') ? 'rotate-180' : ''
                }`}
              />
            </div>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="p-4 border border-t-0 rounded-b-lg space-y-4">
              <div className="space-y-2">
                <Label htmlFor="xp_achievement_unlocked">Base Achievement XP</Label>
                <Input
                  id="xp_achievement_unlocked"
                  type="number"
                  value={settings.xp_achievement_unlocked}
                  onChange={(e) =>
                    setSettings({ ...settings, xp_achievement_unlocked: parseInt(e.target.value) || 0 })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Additional XP added to each achievement's reward
                </p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div>
                  <Label>Enable Streak Bonus</Label>
                  <p className="text-xs text-muted-foreground">
                    Apply bonus multiplier when users have active streaks
                  </p>
                </div>
                <Switch
                  checked={settings.xp_streak_bonus_enabled}
                  onCheckedChange={(checked) =>
                    setSettings({ ...settings, xp_streak_bonus_enabled: checked })
                  }
                />
              </div>

              {settings.xp_streak_bonus_enabled && (
                <div className="space-y-2">
                  <Label htmlFor="multiplier">Streak Bonus Multiplier</Label>
                  <Input
                    id="multiplier"
                    type="number"
                    step="0.1"
                    min="1"
                    max="5"
                    value={settings.xp_streak_bonus_multiplier}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        xp_streak_bonus_multiplier: parseFloat(e.target.value) || 1,
                      })
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    Users with streaks will earn XP × {settings.xp_streak_bonus_multiplier}
                  </p>
                </div>
              )}
            </div>
          </CollapsibleContent>
        </Collapsible>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4 border-t">
          <Button variant="outline" onClick={resetToDefaults}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
          <Button onClick={saveSettings} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
