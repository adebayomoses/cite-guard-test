import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit, Trash2, Award } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Achievement {
  id: string;
  key: string;
  name: string;
  description: string;
  icon: string;
  category: string;
  xp_reward: number;
  rarity: string;
  sort_order: number;
  is_active: boolean;
}

const RARITIES = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
const CATEGORIES = ['content', 'engagement', 'progression', 'trading', 'general'];

const RARITY_COLORS: Record<string, string> = {
  common: 'bg-gray-500/20 text-gray-300',
  uncommon: 'bg-green-500/20 text-green-400',
  rare: 'bg-blue-500/20 text-blue-400',
  epic: 'bg-purple-500/20 text-purple-400',
  legendary: 'bg-amber-500/20 text-amber-400',
};

export const AchievementsTab = () => {
  const [editingAchievement, setEditingAchievement] = useState<Achievement | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: achievements, isLoading } = useQuery({
    queryKey: ['admin-achievements'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('achievements')
        .select('*')
        .order('sort_order', { ascending: true });
      if (error) throw error;
      return data as Achievement[];
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (achievement: Partial<Achievement> & { id: string }) => {
      const { error } = await supabase
        .from('achievements')
        .update(achievement)
        .eq('id', achievement.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-achievements'] });
      toast({ title: 'Achievement updated' });
      setIsDialogOpen(false);
      setEditingAchievement(null);
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to update achievement', variant: 'destructive' });
    },
  });

  const createMutation = useMutation({
    mutationFn: async (achievement: Omit<Achievement, 'id'>) => {
      const { error } = await supabase.from('achievements').insert(achievement);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-achievements'] });
      toast({ title: 'Achievement created' });
      setIsDialogOpen(false);
      setEditingAchievement(null);
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to create achievement', variant: 'destructive' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('achievements').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-achievements'] });
      toast({ title: 'Achievement deleted' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to delete achievement', variant: 'destructive' });
    },
  });

  const toggleActive = async (id: string, isActive: boolean) => {
    updateMutation.mutate({ id, is_active: isActive });
  };

  const handleSave = () => {
    if (!editingAchievement) return;

    if (editingAchievement.id) {
      updateMutation.mutate(editingAchievement);
    } else {
      const { id, ...rest } = editingAchievement;
      createMutation.mutate(rest as Omit<Achievement, 'id'>);
    }
  };

  const openNewDialog = () => {
    setEditingAchievement({
      id: '',
      key: `achievement_${Date.now()}`,
      name: '',
      description: '',
      icon: '🏆',
      category: 'general',
      xp_reward: 10,
      rarity: 'common',
      sort_order: (achievements?.length || 0) + 1,
      is_active: true,
    });
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return <div className="flex items-center justify-center p-8">Loading...</div>;
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Achievements Manager</CardTitle>
          <CardDescription>
            Create and manage achievements that users can unlock
          </CardDescription>
        </div>
        <Button onClick={openNewDialog}>
          <Plus className="h-4 w-4 mr-2" />
          New Achievement
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {achievements?.map((achievement) => (
            <div
              key={achievement.id}
              className={`flex items-center justify-between p-4 border rounded-lg ${
                achievement.is_active ? 'bg-muted/30' : 'bg-muted/10 opacity-60'
              }`}
            >
              <div className="flex items-center gap-4">
                <span className="text-2xl">{achievement.icon}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{achievement.name}</span>
                    <Badge className={RARITY_COLORS[achievement.rarity]}>
                      {achievement.rarity}
                    </Badge>
                    <Badge variant="outline">{achievement.category}</Badge>
                    {!achievement.is_active && (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{achievement.description}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-medium text-primary">+{achievement.xp_reward} XP</div>
                </div>
                <Switch
                  checked={achievement.is_active}
                  onCheckedChange={(checked) => toggleActive(achievement.id, checked)}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setEditingAchievement(achievement);
                    setIsDialogOpen(true);
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-destructive"
                  onClick={() => {
                    if (confirm('Delete this achievement?')) {
                      deleteMutation.mutate(achievement.id);
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingAchievement?.id ? 'Edit Achievement' : 'New Achievement'}
              </DialogTitle>
              <DialogDescription>
                Configure the achievement details
              </DialogDescription>
            </DialogHeader>

            {editingAchievement && (
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-3">
                  <div>
                    <Label>Icon</Label>
                    <Input
                      value={editingAchievement.icon}
                      onChange={(e) =>
                        setEditingAchievement({ ...editingAchievement, icon: e.target.value })
                      }
                      className="text-center text-xl"
                    />
                  </div>
                  <div className="col-span-3">
                    <Label>Name</Label>
                    <Input
                      value={editingAchievement.name}
                      onChange={(e) =>
                        setEditingAchievement({ ...editingAchievement, name: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={editingAchievement.description}
                    onChange={(e) =>
                      setEditingAchievement({ ...editingAchievement, description: e.target.value })
                    }
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Category</Label>
                    <Select
                      value={editingAchievement.category}
                      onValueChange={(value) =>
                        setEditingAchievement({ ...editingAchievement, category: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CATEGORIES.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Rarity</Label>
                    <Select
                      value={editingAchievement.rarity}
                      onValueChange={(value) =>
                        setEditingAchievement({ ...editingAchievement, rarity: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {RARITIES.map((rarity) => (
                          <SelectItem key={rarity} value={rarity}>
                            {rarity.charAt(0).toUpperCase() + rarity.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>XP Reward</Label>
                    <Input
                      type="number"
                      value={editingAchievement.xp_reward}
                      onChange={(e) =>
                        setEditingAchievement({
                          ...editingAchievement,
                          xp_reward: parseInt(e.target.value) || 0,
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Sort Order</Label>
                    <Input
                      type="number"
                      value={editingAchievement.sort_order}
                      onChange={(e) =>
                        setEditingAchievement({
                          ...editingAchievement,
                          sort_order: parseInt(e.target.value) || 0,
                        })
                      }
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label>Active</Label>
                  <Switch
                    checked={editingAchievement.is_active}
                    onCheckedChange={(checked) =>
                      setEditingAchievement({ ...editingAchievement, is_active: checked })
                    }
                  />
                </div>

                <Button onClick={handleSave} className="w-full">
                  Save Achievement
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};
