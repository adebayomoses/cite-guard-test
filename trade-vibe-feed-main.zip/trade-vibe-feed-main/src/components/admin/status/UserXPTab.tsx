import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Search, Edit, Plus, Minus, RotateCcw, Award } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface UserXPData {
  user_id: string;
  total_xp: number;
  weekly_xp: number;
  current_rank: string;
  current_streak: number;
  longest_streak: number;
  profile: {
    handle: string;
    display_name: string | null;
    avatar_url: string | null;
  };
}

export const UserXPTab = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserXPData | null>(null);
  const [xpAdjustment, setXpAdjustment] = useState(0);
  const [adjustmentReason, setAdjustmentReason] = useState('');
  const [isAdjustDialogOpen, setIsAdjustDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ['admin-user-xp', searchQuery],
    queryFn: async () => {
      let query = supabase
        .from('user_xp')
        .select(`
          user_id,
          total_xp,
          weekly_xp,
          current_rank,
          current_streak,
          longest_streak,
          profile:profiles!user_xp_user_id_fkey(handle, display_name, avatar_url)
        `)
        .order('total_xp', { ascending: false })
        .limit(50);

      if (searchQuery) {
        // Search by handle
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id')
          .ilike('handle', `%${searchQuery}%`)
          .limit(50);

        if (profiles?.length) {
          const userIds = profiles.map((p) => p.id);
          query = query.in('user_id', userIds);
        } else {
          return [];
        }
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as unknown as UserXPData[];
    },
  });

  const adjustXPMutation = useMutation({
    mutationFn: async ({
      userId,
      amount,
      reason,
    }: {
      userId: string;
      amount: number;
      reason: string;
    }) => {
      // Insert XP transaction
      const { error: txError } = await supabase.from('xp_transactions').insert({
        user_id: userId,
        amount,
        source_type: 'admin_adjustment',
        description: reason || 'Admin XP adjustment',
      });
      if (txError) throw txError;

      // Update user_xp
      const { data: current } = await supabase
        .from('user_xp')
        .select('total_xp, weekly_xp')
        .eq('user_id', userId)
        .single();

      const newTotal = Math.max((current?.total_xp || 0) + amount, 0);
      const newWeekly = Math.max((current?.weekly_xp || 0) + amount, 0);

      const { error: updateError } = await supabase
        .from('user_xp')
        .update({ total_xp: newTotal, weekly_xp: newWeekly })
        .eq('user_id', userId);

      if (updateError) throw updateError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-user-xp'] });
      toast({ title: 'XP adjusted successfully' });
      setIsAdjustDialogOpen(false);
      setXpAdjustment(0);
      setAdjustmentReason('');
      setSelectedUser(null);
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to adjust XP', variant: 'destructive' });
    },
  });

  const resetUserXPMutation = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase
        .from('user_xp')
        .update({ total_xp: 0, weekly_xp: 0, current_rank: 'rookie' })
        .eq('user_id', userId);
      if (error) throw error;

      // Log the reset
      await supabase.from('xp_transactions').insert({
        user_id: userId,
        amount: 0,
        source_type: 'admin_reset',
        description: 'Admin reset XP to 0',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-user-xp'] });
      toast({ title: 'User XP reset' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to reset XP', variant: 'destructive' });
    },
  });

  const handleAdjustXP = () => {
    if (!selectedUser || xpAdjustment === 0) return;
    adjustXPMutation.mutate({
      userId: selectedUser.user_id,
      amount: xpAdjustment,
      reason: adjustmentReason,
    });
  };

  const openAdjustDialog = (user: UserXPData, preset: number = 0) => {
    setSelectedUser(user);
    setXpAdjustment(preset);
    setIsAdjustDialogOpen(true);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>User XP Management</CardTitle>
        <CardDescription>
          Search users and manually adjust their XP, streaks, or achievements
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by handle..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* User List */}
        <div className="space-y-2">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading...</div>
          ) : users?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No users found</div>
          ) : (
            users?.map((user) => (
              <div
                key={user.user_id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
              >
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={user.profile?.avatar_url || ''} />
                    <AvatarFallback>
                      {user.profile?.handle?.charAt(0).toUpperCase() || '?'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">
                        {user.profile?.display_name || user.profile?.handle}
                      </span>
                      <Badge variant="outline">{user.current_rank}</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      @{user.profile?.handle} • Streak: {user.current_streak} days
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="font-bold text-primary">{user.total_xp} XP</div>
                    <div className="text-xs text-muted-foreground">
                      +{user.weekly_xp} this week
                    </div>
                  </div>

                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openAdjustDialog(user, 100)}
                      title="Add XP"
                    >
                      <Plus className="h-4 w-4 text-green-500" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openAdjustDialog(user, -100)}
                      title="Remove XP"
                    >
                      <Minus className="h-4 w-4 text-red-500" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openAdjustDialog(user)}
                      title="Custom adjustment"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        if (confirm(`Reset all XP for @${user.profile?.handle}?`)) {
                          resetUserXPMutation.mutate(user.user_id);
                        }
                      }}
                      title="Reset XP"
                    >
                      <RotateCcw className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Adjust XP Dialog */}
        <Dialog open={isAdjustDialogOpen} onOpenChange={setIsAdjustDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adjust XP</DialogTitle>
              <DialogDescription>
                Manually adjust XP for @{selectedUser?.profile?.handle}
              </DialogDescription>
            </DialogHeader>

            {selectedUser && (
              <div className="space-y-4">
                <div className="text-center py-4">
                  <div className="text-sm text-muted-foreground">Current XP</div>
                  <div className="text-3xl font-bold">{selectedUser.total_xp}</div>
                </div>

                <div>
                  <Label>XP Adjustment (negative to remove)</Label>
                  <Input
                    type="number"
                    value={xpAdjustment}
                    onChange={(e) => setXpAdjustment(parseInt(e.target.value) || 0)}
                    placeholder="Enter amount..."
                  />
                  <div className="text-sm text-muted-foreground mt-1">
                    New total: {Math.max(selectedUser.total_xp + xpAdjustment, 0)} XP
                  </div>
                </div>

                <div>
                  <Label>Reason (optional)</Label>
                  <Textarea
                    value={adjustmentReason}
                    onChange={(e) => setAdjustmentReason(e.target.value)}
                    placeholder="Reason for adjustment..."
                    rows={2}
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setIsAdjustDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={handleAdjustXP}
                    disabled={xpAdjustment === 0 || adjustXPMutation.isPending}
                  >
                    {xpAdjustment >= 0 ? 'Add' : 'Remove'} {Math.abs(xpAdjustment)} XP
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
};
