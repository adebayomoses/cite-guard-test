import { ReactNode, useEffect, useState } from "react";
import { Navigate, NavLink, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Flag, 
  Shield, 
  Users, 
  FileText, 
  Target, 
  Calendar, 
  Settings, 
  FileSearch,
  Menu,
  X,
  LogOut,
  Trophy
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { checkAdminAccess } from "@/lib/admin/auth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface AdminLayoutProps {
  children: ReactNode;
}

const adminNavItems = [
  { to: "/admin", icon: LayoutDashboard, label: "Overview", exact: true },
  { to: "/admin/reports", icon: Flag, label: "Reports" },
  { to: "/admin/verifications", icon: Shield, label: "Verifications" },
  { to: "/admin/users", icon: Users, label: "Users" },
  { to: "/admin/content", icon: FileText, label: "Content" },
  { to: "/admin/challenges", icon: Target, label: "Challenges" },
  { to: "/admin/events", icon: Calendar, label: "Events" },
  { to: "/admin/status", icon: Trophy, label: "Status" },
  { to: "/admin/config", icon: Settings, label: "Config" },
  { to: "/admin/audit", icon: FileSearch, label: "Audit" },
];

export const AdminLayout = ({ children }: AdminLayoutProps) => {
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const location = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const checkAccess = async () => {
      try {
        const hasAccess = await checkAdminAccess();
        setIsAdmin(hasAccess);
        
        if (hasAccess) {
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', user.id)
              .single();
            setProfile(profileData);
          }
        }
      } catch (error) {
        console.error('Error checking admin access:', error);
        setIsAdmin(false);
      }
    };

    checkAccess();
  }, []);

  const handleSignOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({
        title: "Error signing out",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  if (isAdmin === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Checking admin access...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Header */}
      <header className="lg:hidden flex items-center justify-between p-4 border-b border-border bg-background/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">Admin Dashboard</h1>
        </div>
        <Badge variant="secondary" className="bg-red-500/10 text-red-500 border-red-500/20">
          Admin
        </Badge>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`
          fixed lg:sticky top-0 left-0 z-50 h-screen w-64 bg-background border-r border-border
          transform transition-transform duration-200 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}>
          {/* Sidebar Header */}
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary/60 rounded-lg flex items-center justify-center">
                  <LayoutDashboard className="h-4 w-4 text-primary-foreground" />
                </div>
                <div>
                  <h2 className="font-semibold text-sm">Admin Dashboard</h2>
                  <Badge variant="secondary" className="bg-red-500/10 text-red-500 border-red-500/20 text-xs">
                    Admin Mode
                  </Badge>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Profile Info */}
          {profile && (
            <div className="p-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-xs font-medium text-primary">
                    {profile.display_name?.charAt(0) || profile.handle?.charAt(0) || 'A'}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">
                    {profile.display_name || profile.handle}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    @{profile.handle}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="p-2 space-y-1 flex-1 overflow-y-auto">
            {adminNavItems.map((item) => {
              const isActive = item.exact 
                ? location.pathname === item.to
                : location.pathname.startsWith(item.to) && location.pathname !== '/admin';
              
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={() => setSidebarOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-200 ${
                    isActive
                      ? "bg-primary/10 text-primary font-medium"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }`}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
            
            <Separator className="my-4" />
            
            <NavLink
              to="/"
              onClick={() => setSidebarOpen(false)}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200"
            >
              <LayoutDashboard className="h-4 w-4 shrink-0" />
              <span>Back to App</span>
            </NavLink>
            
            <button
              onClick={handleSignOut}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-all duration-200 w-full"
            >
              <LogOut className="h-4 w-4 shrink-0" />
              <span>Sign Out</span>
            </button>
          </nav>
        </aside>

        {/* Mobile Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/20 z-40 lg:hidden" 
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 lg:ml-0">
          <div className="p-6 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};