import { useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Upload, X } from "lucide-react";

interface LogoUploaderProps {
  currentUrl: string | null;
  onUpload: (url: string | null) => void;
}

const LogoUploader = ({ currentUrl, onUpload }: LogoUploaderProps) => {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const uploadLogo = async (file: File) => {
    try {
      setUploading(true);

      const fileExt = file.name.split('.').pop();
      const filePath = `logo.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('site-logos')
        .upload(filePath, file, { 
          upsert: true,
          contentType: file.type 
        });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('site-logos')
        .getPublicUrl(filePath);

      onUpload(data.publicUrl);
      
      toast({
        title: "Success",
        description: "Site logo uploaded successfully",
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Error",
        description: "Failed to upload logo",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const isImage = file.type.startsWith('image/');
    if (!isImage) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file (PNG, JPG, or SVG)",
        variant: "destructive",
      });
      return;
    }

    const maxSize = 2 * 1024 * 1024; // 2MB
    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: "Please select an image smaller than 2MB",
        variant: "destructive",
      });
      return;
    }

    await uploadLogo(file);
  };

  const handleRemoveLogo = () => {
    onUpload(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-4">
      {currentUrl && (
        <div className="relative inline-block">
          <img 
            src={currentUrl} 
            alt="Site logo" 
            className="h-20 max-w-xs object-contain rounded-lg border border-border"
          />
          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute -top-2 -right-2 h-6 w-6"
            onClick={handleRemoveLogo}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
      
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
        >
          <Upload className="h-4 w-4 mr-2" />
          {uploading ? "Uploading..." : currentUrl ? "Change Logo" : "Upload Logo"}
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
      
      <p className="text-sm text-muted-foreground">
        Recommended: PNG or SVG format, max 2MB. Transparent background works best.
      </p>
    </div>
  );
};

export default LogoUploader;
