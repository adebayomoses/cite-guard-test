import { useState } from "react";
import { Bookmark, MessageCircle, TrendingUp, TrendingDown, MoreHorizontal, UserPlus, UserCheck, Flag, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { CommentsDrawer } from "@/components/CommentsDrawer";
import { ReputationTooltip } from "@/components/ReputationTooltip";
import { ImageModal } from "@/components/ImageModal";
import { useVoting } from "@/hooks/useVoting";
import { useSavedPosts } from "@/hooks/useSavedPosts";
import { SignalStatusBadge } from "@/components/SignalStatusBadge";
import { RankBadge } from "@/components/status/RankBadge";
import type { SignalTracking } from "@/types";
import { useNavigate } from "react-router-dom";

interface TradingPostProps {
  id: string;
  author: {
    id?: string;
    username: string;
    avatar?: string;
    verified: boolean;
    reputation: number;
    isFollowed?: boolean;
  };
  content: {
    text: string;
    image?: string;
    tickers: string[];
    riskLevel: "low" | "medium" | "high";
    marketType?: string;
    tradeDirection?: string;
  };
  engagement: {
    useful: number;
    notUseful: number;
    userVote?: 1 | -1 | null;
    isSaved?: boolean;
  };
  tradeMeta?: {
    timeframe: string;
    entry: string;
    stop: string;
    target: string;
  };
  signalTracking?: SignalTracking;
  timestamp: string;
  onTickerClick?: (ticker: string) => void;
  onFollowToggle?: () => void;
  onVote?: (type: 1 | -1) => void;
  onSave?: () => void;
  onDiscuss?: () => void;
  hideDiscussButton?: boolean;
}

export const TradingPost = ({ 
  id,
  author, 
  content, 
  engagement: initialEngagement, 
  tradeMeta,
  signalTracking,
  timestamp, 
  onTickerClick,
  onFollowToggle,
  onVote,
  onSave,
  onDiscuss,
  hideDiscussButton = false
}: TradingPostProps) => {
  const navigate = useNavigate();
  const [engagement, setEngagement] = useState(initialEngagement);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const { voteOnPost } = useVoting();
  const { toggleSavePost } = useSavedPosts();

  const handleVote = async (value: 1 | -1) => {
    // Optimistic update
    const currentVote = engagement.userVote;
    const isRemoving = currentVote === value;
    const newUseful = engagement.useful + (value === 1 ? (isRemoving ? -1 : currentVote === -1 ? 2 : 1) : (currentVote === 1 ? -1 : 0));
    const newNotUseful = engagement.notUseful + (value === -1 ? (isRemoving ? -1 : currentVote === 1 ? 2 : 1) : (currentVote === -1 ? -1 : 0));
    
    setEngagement({
      ...engagement,
      useful: newUseful,
      notUseful: newNotUseful,
      userVote: isRemoving ? null : value,
    });

    // Call the API
    const result = await voteOnPost(id, value);
    if (result) {
      setEngagement({
        ...engagement,
        useful: result.useful,
        notUseful: result.notUseful,
        userVote: result.userVote,
      });
    } else {
      // Rollback on error
      setEngagement(initialEngagement);
    }
    
    onVote?.(value);
  };

  const handleSave = async () => {
    // Optimistic update
    setEngagement({
      ...engagement,
      isSaved: !engagement.isSaved,
    });

    const result = await toggleSavePost(id);
    if (result) {
      setEngagement({
        ...engagement,
        isSaved: result.saved,
      });
    } else {
      // Rollback on error
      setEngagement(initialEngagement);
    }
    
    onSave?.();
  };

  const handleCardClick = (e: React.MouseEvent) => {
    // Don't navigate if clicking on interactive elements
    const target = e.target as HTMLElement;
    if (
      target.closest('button') ||
      target.closest('a') ||
      target.closest('[role="button"]')
    ) {
      return;
    }
    navigate(`/post/${id}`);
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low": return "text-profit";
      case "medium": return "text-neutral";
      case "high": return "text-loss";
      default: return "text-neutral";
    }
  };

  const getReputationBadge = (reputation: number) => {
    if (reputation >= 80) return { label: "Elite", color: "bg-profit" };
    if (reputation >= 60) return { label: "Pro", color: "bg-primary" };
    if (reputation >= 40) return { label: "Rising", color: "bg-accent" };
    return { label: "New", color: "bg-muted" };
  };

  const safeAuthor = author ?? { id: undefined, username: 'user', avatar: undefined, verified: false, reputation: 0, isFollowed: false };

  const repBadge = getReputationBadge(safeAuthor.reputation);

  return (
    <Card 
      className="bg-gradient-card border-border shadow-card hover:shadow-trading transition-all duration-300 overflow-hidden cursor-pointer"
      onClick={handleCardClick}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 pb-2">
        <div className="flex items-center gap-3 flex-1">
          <Avatar className="h-10 w-10 ring-2 ring-primary/20">
            <AvatarImage src={safeAuthor.avatar} />
            <AvatarFallback className="bg-secondary text-secondary-foreground">
              {(safeAuthor.username || 'user').slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex flex-col flex-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-foreground">@{safeAuthor.username}</span>
              {safeAuthor.id && <RankBadge userId={safeAuthor.id} size="sm" />}
              {safeAuthor.verified && (
                <Badge variant="secondary" className="text-xs bg-profit text-profit-foreground">
                  Verified
                </Badge>
              )}
            </div>
            <ReputationTooltip reputation={safeAuthor.reputation} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={safeAuthor.isFollowed ? "secondary" : "default"} 
            size="sm" 
            className="text-xs"
            onClick={onFollowToggle}
          >
            {safeAuthor.isFollowed ? (
              <>
                <UserCheck className="h-3 w-3 mr-1" />
                Following
              </>
            ) : (
              <>
                <UserPlus className="h-3 w-3 mr-1" />
                Follow
              </>
            )}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Flag className="h-4 w-4 mr-2" />
                Report
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Shield className="h-4 w-4 mr-2" />
                Block User
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pb-3">
        <div className="flex flex-wrap gap-1 mb-2">
          {/* Market Type & Direction Badges */}
          {content.marketType && (
            <Badge variant="outline" className="text-primary border-primary/50 bg-primary/10 capitalize">
              {content.marketType === "stocks" ? "📈" : 
               content.marketType === "crypto" ? "₿" : 
               content.marketType === "forex" ? "💱" : 
               content.marketType === "options" ? "🎯" : "⚡"} {content.marketType}
            </Badge>
          )}
          {content.tradeDirection && (
            <Badge variant="outline" className={`${
              content.tradeDirection === "long" ? "text-profit border-profit/50 bg-profit/10" : 
              "text-loss border-loss/50 bg-loss/10"
            }`}>
              {content.tradeDirection === "long" ? "↗️" : "↘️"} {content.tradeDirection.toUpperCase()}
            </Badge>
          )}
          
          {/* Signal Tracking Badge */}
          {signalTracking && (
            <SignalStatusBadge
              status={signalTracking.status}
              pnl_percentage={signalTracking.pnl_percentage}
              current_price={signalTracking.current_price}
              entry_price={signalTracking.entry_price}
              target_price={signalTracking.target_price}
              stop_loss={signalTracking.stop_loss}
              ticker={signalTracking.ticker}
              trade_direction={signalTracking.trade_direction}
            />
          )}
          
          {content.tickers.map((ticker) => (
            <Badge 
              key={ticker} 
              variant="outline" 
              className="text-primary border-primary/50 bg-primary/10 cursor-pointer hover:bg-primary/20 transition-colors"
              onClick={() => onTickerClick?.(ticker)}
            >
              {ticker}
            </Badge>
          ))}
          <Badge 
            variant="outline" 
            className={`${getRiskColor(content.riskLevel)} border-current bg-current/10`}
          >
            {content.riskLevel.toUpperCase()} RISK
          </Badge>
        </div>
        <p className="text-foreground leading-relaxed mb-3">{content.text}</p>
        
        {/* Trade Meta */}
        {tradeMeta && Object.keys(tradeMeta).length > 0 && (
          <div className="bg-muted/50 rounded-lg p-3 mb-3 space-y-2">
            {/* Signal Status & Current Price */}
            {signalTracking && (
              <div className="pb-2 mb-2 border-b border-border/50">
                {/* Status Line */}
                <div className="flex items-center justify-between mb-1">
                  <div className="text-xs flex items-center gap-2">
                    {/* Status */}
                    <div>
                      <span className="text-muted-foreground">Status:</span>
                      <span className="ml-1 font-semibold text-foreground">
                        {signalTracking.status === 'win' && '🟢 TARGET HIT'}
                        {signalTracking.status === 'loss' && '🔴 STOP HIT'}
                        {signalTracking.status === 'ongoing' && '🟡 ACTIVE'}
                        {signalTracking.status === 'expired' && '⚪ EXPIRED'}
                      </span>
                    </div>
                    
                    {/* Current Price (if available) */}
                    {signalTracking.current_price && (
                      <>
                        <span className="text-muted-foreground">•</span>
                        <span className={`font-semibold font-mono ${
                          signalTracking.pnl_percentage && signalTracking.pnl_percentage >= 0 ? 'text-profit' : 'text-loss'
                        }`}>
                          ${signalTracking.current_price.toLocaleString()}
                        </span>
                      </>
                    )}
                  </div>
                  
                  {/* P&L Percentage on the right */}
                  {signalTracking.pnl_percentage !== null && (
                    <span className={`text-xs font-bold font-mono ${
                      signalTracking.pnl_percentage >= 0 ? 'text-profit' : 'text-loss'
                    }`}>
                      {signalTracking.pnl_percentage > 0 ? '+' : ''}{signalTracking.pnl_percentage.toFixed(2)}%
                    </span>
                  )}
                </div>
              </div>
            )}
            
            {/* Existing Trade Meta Fields */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {tradeMeta.timeframe && (
                <div>
                  <span className="text-muted-foreground">Timeframe:</span>
                  <span className="ml-1 font-medium text-foreground">{tradeMeta.timeframe}</span>
                </div>
              )}
              {(tradeMeta as any).entry_price && (
                <div>
                  <span className="text-muted-foreground">Entry:</span>
                  <span className="ml-1 font-medium text-foreground">{(tradeMeta as any).entry_price}</span>
                </div>
              )}
              {(tradeMeta as any).stop_price && (
                <div>
                  <span className="text-muted-foreground">Stop:</span>
                  <span className="ml-1 font-medium text-loss">{(tradeMeta as any).stop_price}</span>
                </div>
              )}
              {(tradeMeta as any).target_price && (
                <div>
                  <span className="text-muted-foreground">Target:</span>
                  <span className="ml-1 font-medium text-profit">{(tradeMeta as any).target_price}</span>
                </div>
              )}
            </div>
          </div>
        )}
        
        {content.image && (
          <ImageModal 
            src={content.image} 
            alt="Trading chart" 
          />
        )}
      </div>

      {/* Actions */}
      <div className="px-4 py-3 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={engagement.userVote === 1 ? "default" : "ghost"} 
                    size="sm" 
                    className="gap-1 h-8"
                    onClick={() => handleVote(1)}
                  >
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-sm font-medium">{engagement.useful}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mark as useful</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={engagement.userVote === -1 ? "destructive" : "ghost"} 
                    size="sm" 
                    className="gap-1 h-8"
                    onClick={() => handleVote(-1)}
                  >
                    <TrendingDown className="h-4 w-4" />
                    <span className="text-sm font-medium">{engagement.notUseful}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mark as not useful</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            {!hideDiscussButton && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="gap-1 h-8" 
                      onClick={() => setIsCommentsOpen(true)}
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span className="text-sm">Discuss</span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Join the discussion</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
          <div className="flex items-center gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={engagement.isSaved ? "secondary" : "ghost"} 
                    size="sm" 
                    className="h-8 w-8 p-0"
                    onClick={handleSave}
                  >
                    <Bookmark className={`h-4 w-4 ${engagement.isSaved ? 'fill-current' : ''}`} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Save to Journal</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <span className="text-xs text-muted-foreground">{timestamp}</span>
          </div>
        </div>
      </div>
      
      <CommentsDrawer 
        postId={id}
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
      />
    </Card>
  );
};