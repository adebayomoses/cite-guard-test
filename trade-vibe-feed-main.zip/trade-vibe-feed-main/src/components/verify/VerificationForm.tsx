import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useVerificationRequests } from "@/hooks/useVerificationRequests";
import { useToast } from "@/hooks/use-toast";
import { Camera, Link, KeyRound, FileText, Loader2, X, Upload } from "lucide-react";

type ProofType = "screenshot" | "myfxbook" | "mt4_password" | "statement";

interface VerificationFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

const PROOF_TYPES = [
  {
    value: "screenshot" as ProofType,
    label: "Trade Screenshots",
    description: "Upload screenshots of your trading history or account",
    icon: Camera,
  },
  {
    value: "myfxbook" as ProofType,
    label: "Myfxbook Profile",
    description: "Share your public Myfxbook or FXBlue profile link",
    icon: Link,
  },
  {
    value: "mt4_password" as ProofType,
    label: "MT4/MT5 Investor Password",
    description: "Provide read-only access to your trading account",
    icon: KeyRound,
  },
  {
    value: "statement" as ProofType,
    label: "Broker Statement",
    description: "Upload your broker account statement (PDF or images)",
    icon: FileText,
  },
];

export function VerificationForm({ open, onOpenChange, onSuccess }: VerificationFormProps) {
  const { submitVerification, uploadVerificationImage } = useVerificationRequests();
  const { toast } = useToast();
  
  const [proofType, setProofType] = useState<ProofType>("screenshot");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadingImages, setUploadingImages] = useState(false);
  
  // Form data
  const [images, setImages] = useState<File[]>([]);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [myfxbookUrl, setMyfxbookUrl] = useState("");
  const [mt4Server, setMt4Server] = useState("");
  const [mt4AccountNumber, setMt4AccountNumber] = useState("");
  const [mt4InvestorPassword, setMt4InvestorPassword] = useState("");
  const [additionalNotes, setAdditionalNotes] = useState("");

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    // Limit to 5 images
    const newImages = [...images, ...files].slice(0, 5);
    setImages(newImages);

    // Upload images immediately
    setUploadingImages(true);
    try {
      const uploadPromises = files.map((file) => uploadVerificationImage(file));
      const newUrls = await Promise.all(uploadPromises);
      setImageUrls((prev) => [...prev, ...newUrls].slice(0, 5));
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload some images. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingImages(false);
    }
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
    setImageUrls((prev) => prev.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setProofType("screenshot");
    setImages([]);
    setImageUrls([]);
    setMyfxbookUrl("");
    setMt4Server("");
    setMt4AccountNumber("");
    setMt4InvestorPassword("");
    setAdditionalNotes("");
  };

  const validateForm = (): boolean => {
    switch (proofType) {
      case "screenshot":
      case "statement":
        if (imageUrls.length === 0) {
          toast({
            title: "Images required",
            description: "Please upload at least one image",
            variant: "destructive",
          });
          return false;
        }
        break;
      case "myfxbook":
        if (!myfxbookUrl.trim()) {
          toast({
            title: "URL required",
            description: "Please enter your Myfxbook or FXBlue profile URL",
            variant: "destructive",
          });
          return false;
        }
        if (!myfxbookUrl.includes("myfxbook.com") && !myfxbookUrl.includes("fxblue.com")) {
          toast({
            title: "Invalid URL",
            description: "Please enter a valid Myfxbook or FXBlue URL",
            variant: "destructive",
          });
          return false;
        }
        break;
      case "mt4_password":
        if (!mt4Server.trim() || !mt4AccountNumber.trim() || !mt4InvestorPassword.trim()) {
          toast({
            title: "All fields required",
            description: "Please fill in server, account number, and investor password",
            variant: "destructive",
          });
          return false;
        }
        break;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await submitVerification({
        proof_type: proofType,
        image_urls: imageUrls,
        myfxbook_url: myfxbookUrl || undefined,
        mt4_server: mt4Server || undefined,
        mt4_account_number: mt4AccountNumber || undefined,
        mt4_investor_password: mt4InvestorPassword || undefined,
        additional_notes: additionalNotes || undefined,
      });

      toast({
        title: "Verification submitted",
        description: "Your verification request has been submitted for review. This usually takes 2-5 business days.",
      });

      resetForm();
      onOpenChange(false);
      onSuccess();
    } catch (error) {
      toast({
        title: "Submission failed",
        description: error instanceof Error ? error.message : "Failed to submit verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Verify Your Trading Experience</DialogTitle>
          <DialogDescription>
            Submit proof of your trading activity to get verified. Choose one of the options below.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Proof Type Selection */}
          <div className="space-y-3">
            <Label>Select Verification Method</Label>
            <RadioGroup
              value={proofType}
              onValueChange={(value) => setProofType(value as ProofType)}
              className="space-y-3"
            >
              {PROOF_TYPES.map((type) => (
                <label
                  key={type.value}
                  className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    proofType === type.value
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-muted-foreground/50"
                  }`}
                >
                  <RadioGroupItem value={type.value} className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <type.icon className="h-4 w-4 text-primary" />
                      <span className="font-medium text-foreground">{type.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{type.description}</p>
                  </div>
                </label>
              ))}
            </RadioGroup>
          </div>

          {/* Dynamic Fields based on proof type */}
          {(proofType === "screenshot" || proofType === "statement") && (
            <div className="space-y-3">
              <Label>
                Upload {proofType === "screenshot" ? "Screenshots" : "Statements"} (max 5)
              </Label>
              
              {/* Image Preview Grid */}
              {images.length > 0 && (
                <div className="grid grid-cols-3 gap-2">
                  {images.map((file, index) => (
                    <div key={index} className="relative aspect-square rounded-lg overflow-hidden border border-border">
                      <img
                        src={URL.createObjectURL(file)}
                        alt={`Upload ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        onClick={() => removeImage(index)}
                        className="absolute top-1 right-1 p-1 bg-background/80 rounded-full hover:bg-background"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Upload Button */}
              {images.length < 5 && (
                <div className="relative">
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    multiple
                    onChange={handleImageSelect}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    disabled={uploadingImages}
                  />
                  <Button
                    variant="outline"
                    className="w-full"
                    disabled={uploadingImages}
                  >
                    {uploadingImages ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Images
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}

          {proofType === "myfxbook" && (
            <div className="space-y-3">
              <Label htmlFor="myfxbook-url">Myfxbook / FXBlue Profile URL</Label>
              <Input
                id="myfxbook-url"
                placeholder="https://www.myfxbook.com/members/yourusername/yourportfolio/123456"
                value={myfxbookUrl}
                onChange={(e) => setMyfxbookUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Make sure your profile is set to public so we can verify it
              </p>
            </div>
          )}

          {proofType === "mt4_password" && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="mt4-server">Broker Server</Label>
                <Input
                  id="mt4-server"
                  placeholder="e.g., ICMarkets-Demo, XM-Real-3"
                  value={mt4Server}
                  onChange={(e) => setMt4Server(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mt4-account">Account Number</Label>
                <Input
                  id="mt4-account"
                  placeholder="e.g., 12345678"
                  value={mt4AccountNumber}
                  onChange={(e) => setMt4AccountNumber(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="mt4-password">Investor Password (Read-Only)</Label>
                <Input
                  id="mt4-password"
                  type="password"
                  placeholder="Your investor password"
                  value={mt4InvestorPassword}
                  onChange={(e) => setMt4InvestorPassword(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  The investor password only allows viewing trades, not executing them
                </p>
              </div>
            </div>
          )}

          {/* Additional Notes (always visible) */}
          <div className="space-y-2">
            <Label htmlFor="notes">Additional Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any additional information you'd like to share..."
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-border">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || uploadingImages}>
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              "Submit for Review"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
