import { ReactNode } from "react";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}

export const PageHeader = ({ title, subtitle, children }: PageHeaderProps) => {
  return (
    <div className="bg-background border-b border-border">
      <div className="px-4 py-4">
        {/* Page Title */}
        <div className="mb-4">
          <h1 className="text-xl font-semibold text-foreground">{title}</h1>
          {subtitle && (
            <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>

        {/* Content (filters, controls, etc.) */}
        {children && (
          <div className="space-y-3">
            {children}
          </div>
        )}
      </div>
      
      {/* Subtle divider */}
      <div className="border-b border-white/5" />
    </div>
  );
};