import React, { useState, useEffect } from 'react';
import { X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { LifestyleComment } from '@/types/lifestyle';
import { supabase } from '@/integrations/supabase/client';
import { useLifestyleActions } from '@/hooks/useLifestyle';
import { toast } from 'sonner';

interface CommentsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  videoId: string | null;
}

export const CommentsDrawer = ({ isOpen, onClose, videoId }: CommentsDrawerProps) => {
  const [comments, setComments] = useState<LifestyleComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const { addComment } = useLifestyleActions();

  // Fetch comments when drawer opens
  useEffect(() => {
    if (isOpen && videoId) {
      fetchComments();
    }
  }, [isOpen, videoId]);

  const fetchComments = async () => {
    if (!videoId) return;

    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No valid session');
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/${videoId}/comments`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const data = await response.json();
      setComments(data || []);
    } catch (error) {
      toast.error('Failed to load comments');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newComment.trim() || !videoId || submitting) return;

    try {
      setSubmitting(true);
      const comment = await addComment(videoId, newComment.trim());
      
      setComments(prev => [...prev, comment]);
      setNewComment('');
      toast.success('Comment added!');
    } catch (error) {
      toast.error('Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  };

  // Real-time comment updates
  useEffect(() => {
    if (!videoId || !isOpen) return;

    const channel = supabase
      .channel(`video-comments-${videoId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'lifestyle_comments',
          filter: `video_id=eq.${videoId}`
        },
        (payload) => {
          // Don't add if it's the user's own comment (already added optimistically)
          const newComment = payload.new as LifestyleComment;
          setComments(prev => {
            const exists = prev.some(c => c.id === newComment.id);
            if (exists) return prev;
            return [...prev, newComment];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [videoId, isOpen]);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="h-[70vh] p-0">
        <SheetHeader className="p-4 border-b">
          <SheetTitle className="text-left">Comments</SheetTitle>
        </SheetHeader>

        <div className="flex flex-col h-full">
          {/* Comments List */}
          <ScrollArea className="flex-1 p-4">
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading comments...
              </div>
            ) : comments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No comments yet. Be the first to comment!
              </div>
            ) : (
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex space-x-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={comment.profiles?.avatar_url} />
                      <AvatarFallback>
                        {comment.profiles?.display_name?.charAt(0) || 
                         comment.profiles?.handle?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium">
                          @{comment.profiles?.handle}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatTime(comment.created_at)}
                        </p>
                      </div>
                      <p className="text-sm text-foreground mt-1">
                        {comment.text}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Comment Input */}
          <div className="border-t p-4">
            <form onSubmit={handleSubmitComment} className="flex space-x-2">
              <Input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1"
                disabled={submitting}
              />
              <Button 
                type="submit" 
                size="icon"
                disabled={!newComment.trim() || submitting}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};