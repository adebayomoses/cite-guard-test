import React, { useState, useEffect, useRef } from 'react';
import { LifestyleVideo } from '@/types/lifestyle';
import { LifestylePlayer } from './LifestylePlayer';
import { VideoActions, VideoInfo } from './VideoActions';
import { CommentsDrawer } from './CommentsDrawer';

interface VerticalSwiperProps {
  videos: LifestyleVideo[];
  onVideoUpdate: (videoId: string, updates: Partial<LifestyleVideo>) => void;
  onLoadMore: () => void;
  hasMore: boolean;
}

export const VerticalSwiper = ({ 
  videos, 
  onVideoUpdate, 
  onLoadMore, 
  hasMore 
}: VerticalSwiperProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStart = useRef<number>(0);
  const touchEnd = useRef<number>(0);

  const currentVideo = videos[currentIndex];

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowUp' || e.code === 'ArrowDown') {
        e.preventDefault();
        
        if (e.code === 'ArrowUp' && currentIndex > 0) {
          setCurrentIndex(prev => prev - 1);
        } else if (e.code === 'ArrowDown' && currentIndex < videos.length - 1) {
          setCurrentIndex(prev => prev + 1);
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, videos.length]);

  // Handle touch gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStart.current = e.targetTouches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEnd.current = e.targetTouches[0].clientY;
  };

  const handleTouchEnd = () => {
    if (!touchStart.current || !touchEnd.current) return;
    
    const distance = touchStart.current - touchEnd.current;
    const isUpSwipe = distance > 50;
    const isDownSwipe = distance < -50;

    if (isUpSwipe && currentIndex < videos.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else if (isDownSwipe && currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }

    touchStart.current = 0;
    touchEnd.current = 0;
  };

  // Load more videos when approaching the end
  useEffect(() => {
    if (currentIndex >= videos.length - 3 && hasMore) {
      onLoadMore();
    }
  }, [currentIndex, videos.length, hasMore, onLoadMore]);

  // Handle wheel scroll
  const handleWheel = (e: WheelEvent) => {
    e.preventDefault();
    
    if (e.deltaY > 0 && currentIndex < videos.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else if (e.deltaY < 0 && currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    }
  };

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [currentIndex, videos.length]);

  const handleVideoUpdate = (updates: Partial<LifestyleVideo>) => {
    if (!currentVideo) return;
    onVideoUpdate(currentVideo.id, updates);
  };

  const handleCommentClick = () => {
    setSelectedVideoId(currentVideo?.id || null);
    setIsCommentsOpen(true);
  };

  if (!currentVideo) {
    return (
      <div className="h-screen flex items-center justify-center">
        <p className="text-muted-foreground">No videos available</p>
      </div>
    );
  }

  return (
    <>
      <div
        ref={containerRef}
        className="h-full w-full overflow-hidden bg-black relative"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="absolute inset-0">
          <div className="relative w-full h-full">
            <LifestylePlayer
              src={currentVideo.video_url}
              poster={currentVideo.thumbnail_url}
              autoplay={true}
              muted={true}
              loop={true}
              className="w-full h-full"
            />
            
            <VideoInfo video={currentVideo} />
            
            <VideoActions
              video={currentVideo}
              onCommentClick={handleCommentClick}
              onVideoUpdate={handleVideoUpdate}
            />
          </div>
        </div>

        {/* Navigation hints */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 text-white/60 text-sm">
          {currentIndex + 1} / {videos.length}
        </div>
        
        {currentIndex > 0 && (
          <div className="absolute top-1/2 left-4 transform -translate-y-1/2 text-white/60">
            ↑ Previous
          </div>
        )}
        
        {currentIndex < videos.length - 1 && (
          <div className="absolute bottom-1/2 left-4 transform translate-y-1/2 text-white/60">
            ↓ Next
          </div>
        )}
      </div>

      {/* Comments Drawer */}
      <CommentsDrawer
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
        videoId={selectedVideoId}
      />
    </>
  );
};