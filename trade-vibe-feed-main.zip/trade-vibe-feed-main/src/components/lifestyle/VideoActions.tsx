import React, { useState } from 'react';
import { Heart, MessageCircle, Bookmark, Share, UserPlus, UserCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { LifestyleVideo } from '@/types/lifestyle';
import { useLifestyleActions } from '@/hooks/useLifestyle';
import { profileApi } from '@/lib/api/profile';
import { toast } from 'sonner';

interface VideoActionsProps {
  video: LifestyleVideo;
  onCommentClick: () => void;
  onVideoUpdate: (updatedVideo: Partial<LifestyleVideo>) => void;
}

export const VideoActions = ({ video, onCommentClick, onVideoUpdate }: VideoActionsProps) => {
  const { toggleLike } = useLifestyleActions();
  const [isLiking, setIsLiking] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  const handleLike = async () => {
    if (isLiking) return;
    
    try {
      setIsLiking(true);
      const result = await toggleLike(video.id);
      
      onVideoUpdate({
        user_liked: result.liked,
        like_count: result.likeCount
      });
    } catch (error) {
      toast.error('Failed to toggle like');
    } finally {
      setIsLiking(false);
    }
  };

  const handleShare = async () => {
    const url = `${window.location.origin}/lifestyle`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: video.caption || 'Check out this lifestyle video',
          text: video.caption || 'Check out this lifestyle video',
          url: url
        });
      } catch (error) {
        // User cancelled sharing, fallback to clipboard
        if (navigator.clipboard) {
          await navigator.clipboard.writeText(url);
          toast.success('Link copied to clipboard!');
        } else {
          toast.error('Sharing not supported on this device');
        }
      }
    } else if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(url);
        toast.success('Link copied to clipboard!');
      } catch (error) {
        toast.error('Failed to copy link');
      }
    } else {
      toast.error('Sharing not supported on this device');
    }
  };

  const handleSave = () => {
    // TODO: Implement save to profile journal
    toast.success('Video saved to your journal!');
  };

  const handleFollow = async () => {
    if (isFollowing || !video.author_id) return;
    
    try {
      setIsFollowing(true);
      const result = await profileApi.toggleFollow(video.author_id);
      
      onVideoUpdate({
        user_following: result.isFollowing
      });
      
      const action = result.isFollowing ? 'Following' : 'Unfollowed';
      toast.success(`${action} ${video.profiles?.display_name || video.profiles?.handle}!`);
    } catch (error) {
      toast.error('Failed to update follow status');
    } finally {
      setIsFollowing(false);
    }
  };

  return (
    <div className="absolute right-4 bottom-4 flex flex-col items-center space-y-4">
      {/* Author Avatar */}
      <div className="relative">
        <Avatar className="w-12 h-12 border-2 border-white">
          <AvatarImage src={video.profiles?.avatar_url} />
          <AvatarFallback>
            {video.profiles?.display_name?.charAt(0) || video.profiles?.handle?.charAt(0) || 'U'}
          </AvatarFallback>
        </Avatar>
        <Button
          size="icon"
          className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full text-white ${
            video.user_following 
              ? 'bg-green-500 hover:bg-green-600' 
              : 'bg-red-500 hover:bg-red-600'
          }`}
          onClick={handleFollow}
          disabled={isFollowing}
        >
          {video.user_following ? (
            <UserCheck className="h-3 w-3" />
          ) : (
            <UserPlus className="h-3 w-3" />
          )}
        </Button>
      </div>

      {/* Like Button */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="icon"
          className={`w-12 h-12 rounded-full ${
            video.user_liked 
              ? 'text-red-500 bg-white/20' 
              : 'text-white bg-black/30 hover:bg-black/50'
          }`}
          onClick={handleLike}
          disabled={isLiking}
        >
          <Heart className={`h-6 w-6 ${video.user_liked ? 'fill-current' : ''}`} />
        </Button>
        <span className="text-white text-xs mt-1">{video.like_count}</span>
      </div>

      {/* Comment Button */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 rounded-full text-white bg-black/30 hover:bg-black/50"
          onClick={onCommentClick}
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
        <span className="text-white text-xs mt-1">{video.comment_count}</span>
      </div>

      {/* Save Button */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 rounded-full text-white bg-black/30 hover:bg-black/50"
          onClick={handleSave}
        >
          <Bookmark className="h-6 w-6" />
        </Button>
      </div>

      {/* Share Button */}
      <div className="flex flex-col items-center">
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 rounded-full text-white bg-black/30 hover:bg-black/50"
          onClick={handleShare}
        >
          <Share className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
};

interface VideoInfoProps {
  video: LifestyleVideo;
}

export const VideoInfo = ({ video }: VideoInfoProps) => {
  const [showFullCaption, setShowFullCaption] = useState(false);
  
  const caption = video.caption || '';
  const shouldTruncate = caption.length > 100;
  const displayCaption = shouldTruncate && !showFullCaption 
    ? caption.slice(0, 100) + '...' 
    : caption;

  return (
    <div className="absolute bottom-4 left-4 right-20 text-white">
      {/* Author Info */}
      <div className="flex items-center mb-2">
        <span className="font-semibold">
          {video.profiles?.display_name || `@${video.profiles?.handle}`}
        </span>
        {video.profiles?.display_name && (
          <span className="text-white/70 text-sm ml-2">
            @{video.profiles?.handle}
          </span>
        )}
        {video.profiles?.verified_status === 'verified' && (
          <Badge variant="secondary" className="ml-2 text-xs">
            Verified
          </Badge>
        )}
      </div>

      {/* Caption */}
      {caption && (
        <div className="mb-2">
          <p className="text-sm">
            {displayCaption}
            {shouldTruncate && (
              <button
                onClick={() => setShowFullCaption(!showFullCaption)}
                className="ml-2 text-white/80 hover:text-white text-xs underline"
              >
                {showFullCaption ? 'Show less' : 'Show more'}
              </button>
            )}
          </p>
        </div>
      )}

      {/* Hashtags and Tickers */}
      <div className="flex flex-wrap gap-1">
        {video.hashtags.map((hashtag, index) => (
          <Badge
            key={`hashtag-${index}`}
            variant="outline"
            className="text-xs bg-black/30 border-white/30 text-white hover:bg-white/20"
          >
            #{hashtag}
          </Badge>
        ))}
        {video.tickers.map((ticker, index) => (
          <Badge
            key={`ticker-${index}`}
            variant="outline"
            className="text-xs bg-primary/30 border-primary/50 text-white hover:bg-primary/40"
          >
            ${ticker}
          </Badge>
        ))}
      </div>
    </div>
  );
};