import React, { useState, useEffect } from 'react';
import { LifestyleVideo } from '@/types/lifestyle';
import { supabase } from '@/integrations/supabase/client';
import { Play } from 'lucide-react';

interface LifestyleGridProps {
  handle: string;
  className?: string;
}

export const LifestyleGrid = ({ handle, className = '' }: LifestyleGridProps) => {
  const [videos, setVideos] = useState<LifestyleVideo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserVideos();
  }, [handle]);

  const fetchUserVideos = async () => {
    try {
      setLoading(true);
      
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        // Handle as empty state for unauthorized users
        setVideos([]);
        return;
      }
      
      const response = await fetch(`https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/lifestyle-api/user/${handle}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 401) {
        // Handle unauthorized as empty state
        setVideos([]);
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setVideos(data || []);
    } catch (error) {
      console.error('Failed to fetch user videos:', error);
      setVideos([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className={`grid grid-cols-3 gap-2 ${className}`}>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="aspect-[9/16] bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className={`text-center py-8 ${className}`}>
        <p className="text-muted-foreground">No lifestyle videos yet</p>
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-3 gap-2 ${className}`}>
      {videos.map((video) => (
        <div
          key={video.id}
          className="aspect-[9/16] relative rounded-lg overflow-hidden cursor-pointer group"
          onClick={() => {
            // Navigate to video in lifestyle feed
            window.location.href = `/lifestyle?video=${video.id}`;
          }}
        >
          {video.thumbnail_url ? (
            <img
              src={video.thumbnail_url}
              alt="Video thumbnail"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-muted flex items-center justify-center">
              <Play className="h-8 w-8 text-muted-foreground" />
            </div>
          )}
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors">
            <div className="absolute bottom-2 left-2 right-2">
              <div className="flex items-center justify-between text-white text-xs">
                <span>{video.like_count} likes</span>
                <span>{video.comment_count} comments</span>
              </div>
            </div>
          </div>
          
          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-12 h-12 bg-black/50 rounded-full flex items-center justify-center">
              <Play className="h-6 w-6 text-white ml-1" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};