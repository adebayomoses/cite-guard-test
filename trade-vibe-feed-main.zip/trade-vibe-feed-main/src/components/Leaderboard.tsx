import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Trophy, Medal, Award, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { LeaderboardEntry } from "@/hooks/useLeaderboard";

interface LeaderboardProps {
  traders: LeaderboardEntry[];
}

export const Leaderboard = ({ traders }: LeaderboardProps) => {
  const navigate = useNavigate();

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 2: return <Medal className="h-5 w-5 text-gray-400" />;
      case 3: return <Award className="h-5 w-5 text-orange-500" />;
      default: return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return "bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 border-yellow-500/30";
      case 2: return "bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-400/30";
      case 3: return "bg-gradient-to-r from-orange-500/20 to-orange-600/20 border-orange-500/30";
      default: return "bg-gradient-card border-border";
    }
  };

  return (
    <div className="space-y-4 p-4">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">Top Traders</h2>
        <p className="text-muted-foreground">Ranked by reputation score</p>
      </div>

      <div className="space-y-3">
        {traders.map((trader) => (
          <Card 
            key={trader.id} 
            className={`${getRankBg(trader.rank)} shadow-card hover:shadow-trading transition-all duration-300 p-4 cursor-pointer`}
            onClick={() => navigate(`/profile/${trader.handle}`)}
          >
            <div className="flex items-center gap-4">
              {/* Rank */}
              <div className="flex items-center justify-center w-12 h-12 rounded-full bg-muted/50">
                {getRankIcon(trader.rank)}
              </div>

              {/* Avatar */}
              <Avatar className="h-12 w-12 ring-2 ring-primary/20">
                <AvatarImage src={trader.avatarUrl || undefined} />
                <AvatarFallback className="bg-secondary text-secondary-foreground">
                  {trader.handle.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground truncate">
                    {trader.displayName || `@${trader.handle}`}
                  </h3>
                  {trader.verified && (
                    <Badge variant="secondary" className="text-xs bg-profit text-profit-foreground">
                      ✓
                    </Badge>
                  )}
                </div>
                
                {trader.badges.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {trader.badges.slice(0, 2).map((badge) => (
                      <Badge key={badge} variant="outline" className="text-xs border-primary/50 text-primary">
                        {badge}
                      </Badge>
                    ))}
                    {trader.badges.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{trader.badges.length - 2}
                      </Badge>
                    )}
                  </div>
                )}

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>{trader.totalVotes} votes</span>
                </div>
              </div>

              {/* Reputation */}
              <div className="text-right">
                <div className="flex items-center gap-1 mb-1">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <span className="text-lg font-bold text-primary">{trader.reputation}</span>
                </div>
                <span className="text-xs text-muted-foreground">reputation</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
