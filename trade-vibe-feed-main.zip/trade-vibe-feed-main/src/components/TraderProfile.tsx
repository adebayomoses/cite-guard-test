import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TrendingUp, Award, Shield, Target, Bookmark } from "lucide-react";
import { useSavedPosts } from "@/hooks/useSavedPosts";
import { TradingPost } from "@/components/TradingPost";

interface TraderProfileProps {
  trader: {
    username: string;
    avatar?: string;
    bio: string;
    verified: "unverified" | "manual" | "broker";
    reputation: number;
    stats: {
      posts: number;
      followers: number;
      following: number;
      totalVotes: number;
    };
    markets: string[];
    strategies: string[];
    badges: string[];
  };
}

export const TraderProfile = ({ trader }: TraderProfileProps) => {
  const { getSavedPosts } = useSavedPosts();
  const [savedPosts, setSavedPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Mock posts data to match saved post IDs
  const mockPosts = [
    {
      id: "550e8400-e29b-41d4-a716-446655440001",
      author: {
        username: "cryptowolf",
        avatar: "/placeholder.svg",
        verified: true,
        reputation: 87,
        isFollowed: true,
      },
      content: {
        text: "Massive breakout on $BTC! This pattern has been forming for weeks. Volume confirmation is strong. Looking for $48k next. Risk management is key here - tight stops below $42k support.",
        tickers: ["$BTC", "$ETH"],
        riskLevel: "medium" as const,
      },
      engagement: {
        useful: 142,
        notUseful: 8,
        userVote: 1 as const,
        isSaved: true,
      },
      tradeMeta: {
        timeframe: "4H",
        entry: "$43,200",
        stop: "$41,800",
        target: "$48,000",
      },
      timestamp: "2h ago",
    },
    {
      id: "550e8400-e29b-41d4-a716-446655440002",
      author: {
        username: "stockmaster",
        avatar: "/placeholder.svg",
        verified: false,
        reputation: 72,
        isFollowed: false,
      },
      content: {
        text: "$AAPL earnings play looking juicy. Historical data shows strong Q4 performance. iPhone 15 sales data suggests positive surprise. Conservative position size due to macro uncertainty.",
        tickers: ["$AAPL", "$MSFT"],
        riskLevel: "low" as const,
      },
      engagement: {
        useful: 89,
        notUseful: 12,
        userVote: null,
        isSaved: true,
      },
      tradeMeta: {
        timeframe: "Daily",
        entry: "$190.50",
        stop: "$185.00",
        target: "$205.00",
      },
      timestamp: "4h ago",
    },
    {
      id: "550e8400-e29b-41d4-a716-446655440003",
      author: {
        username: "forexking",
        avatar: "/placeholder.svg",
        verified: true,
        reputation: 94,
        isFollowed: true,
      },
      content: {
        text: "EUR/USD showing classic reversal pattern. DXY weakness + ECB hawkish signals = perfect storm. Multiple confirmations across different timeframes. High conviction trade.",
        tickers: ["$EURUSD", "$DXY"],
        riskLevel: "high" as const,
      },
      engagement: {
        useful: 203,
        notUseful: 5,
        userVote: null,
        isSaved: true,
      },
      tradeMeta: {
        timeframe: "1H",
        entry: "1.0850",
        stop: "1.0820",
        target: "1.0920",
      },
      timestamp: "6h ago",
    },
  ];

  useEffect(() => {
    const fetchSavedPosts = async () => {
      setLoading(true);
      try {
        const savedPostIds = await getSavedPosts();
        // Filter mock posts to show only saved ones
        const savedPostsData = mockPosts.filter(post => 
          savedPostIds.some(saved => saved.post_id === post.id)
        );
        setSavedPosts(savedPostsData);
      } catch (error) {
        console.error('Error fetching saved posts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSavedPosts();
  }, [getSavedPosts]);

  const getVerificationIcon = (status: string) => {
    switch (status) {
      case "broker": return <Shield className="h-4 w-4 text-profit" />;
      case "manual": return <Award className="h-4 w-4 text-primary" />;
      default: return null;
    }
  };

  const getVerificationLabel = (status: string) => {
    switch (status) {
      case "broker": return "Broker Verified";
      case "manual": return "Manually Verified";
      default: return "Unverified";
    }
  };

  return (
    <div className="space-y-6 p-4">
      {/* Profile Header */}
      <Card className="bg-gradient-card border-border shadow-card p-6">
        <div className="flex flex-col items-center text-center space-y-4">
          <Avatar className="h-24 w-24 ring-4 ring-primary/20">
            <AvatarImage src={trader.avatar} />
            <AvatarFallback className="bg-secondary text-secondary-foreground text-xl">
              {trader.username.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-foreground">@{trader.username}</h1>
            <div className="flex items-center justify-center gap-2">
              {getVerificationIcon(trader.verified)}
              <span className="text-sm text-muted-foreground">
                {getVerificationLabel(trader.verified)}
              </span>
            </div>
          </div>

          <p className="text-muted-foreground max-w-md">{trader.bio}</p>

          {/* Stats */}
          <div className="flex gap-6 pt-4">
            <div className="text-center">
              <div className="text-xl font-bold text-foreground">{trader.stats.posts}</div>
              <div className="text-xs text-muted-foreground">Posts</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-foreground">{trader.stats.followers}</div>
              <div className="text-xs text-muted-foreground">Followers</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-foreground">{trader.stats.following}</div>
              <div className="text-xs text-muted-foreground">Following</div>
            </div>
          </div>

          {/* Reputation */}
          <div className="flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="font-semibold text-primary">{trader.reputation}% Reputation</span>
          </div>

          <Button className="bg-gradient-primary hover:bg-gradient-primary/90 text-primary-foreground font-semibold px-8">
            Follow
          </Button>
        </div>
      </Card>

      {/* Markets */}
      <Card className="bg-gradient-card border-border shadow-card p-6">
        <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
          <Target className="h-4 w-4" />
          Markets Traded
        </h3>
        <div className="flex flex-wrap gap-2">
          {trader.markets.map((market) => (
            <Badge key={market} variant="secondary" className="bg-secondary/80">
              {market}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Strategies */}
      <Card className="bg-gradient-card border-border shadow-card p-6">
        <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
          <TrendingUp className="h-4 w-4" />
          Trading Strategies
        </h3>
        <div className="flex flex-wrap gap-2">
          {trader.strategies.map((strategy) => (
            <Badge key={strategy} variant="outline" className="border-primary/50 text-primary">
              {strategy}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Badges */}
      {trader.badges.length > 0 && (
        <Card className="bg-gradient-card border-border shadow-card p-6">
          <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <Award className="h-4 w-4" />
            Achievements
          </h3>
          <div className="flex flex-wrap gap-2">
            {trader.badges.map((badge) => (
              <Badge key={badge} variant="default" className="bg-profit text-profit-foreground">
                {badge}
              </Badge>
            ))}
          </div>
        </Card>
      )}

      {/* Profile Tabs */}
      <Card className="bg-gradient-card border-border shadow-card">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="journal" className="gap-2">
              <Bookmark className="h-4 w-4" />
              Journal
            </TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="p-6">
            <div className="text-center text-muted-foreground">
              Recent posts and activity will appear here.
            </div>
          </TabsContent>
          <TabsContent value="journal" className="p-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Saved Posts</h3>
              {loading ? (
                <div className="text-center text-muted-foreground py-8">
                  Loading saved posts...
                </div>
              ) : savedPosts.length > 0 ? (
                <div className="space-y-4">
                  {savedPosts.map((post) => (
                    <TradingPost 
                      key={post.id}
                      id={post.id}
                      author={post.author}
                      content={post.content}
                      engagement={post.engagement}
                      tradeMeta={post.tradeMeta}
                      timestamp={post.timestamp}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  No saved posts yet. Save posts to add them to your journal.
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
};