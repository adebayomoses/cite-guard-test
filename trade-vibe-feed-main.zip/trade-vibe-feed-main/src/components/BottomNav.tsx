import { Home, TrendingUp, Plus, User, Trophy, Target, Video, ChevronUp, Shield, UserCircle, Calendar, MessageCircle, BarChart3, GraduationCap, Star } from "lucide-react";
import { NavLink } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useState, useRef, useEffect } from "react";
import { useFeatureFlags } from "@/hooks/useFeatureFlags";

const navItems = [
  { to: "/", icon: Home, label: "Feed" },
  { to: "/lifestyle", icon: Video, label: "Lifestyle", featureFlag: "lifestyle_enabled" },
  { to: "/create", icon: Plus, label: "Post" },
  { to: "/chat", icon: MessageCircle, label: "Chat" },
];

const oimItems = [
  { to: "/status", icon: Star, label: "Status" },
  { to: "/market-watch", icon: BarChart3, label: "Market", featureFlag: "market_watch_enabled" },
  { to: "/leaderboard", icon: Trophy, label: "Leaders" },
  { to: "/mentorship", icon: GraduationCap, label: "Mentorship" },
  { to: "/challenges", icon: Target, label: "Challenges" },
  { to: "/events", icon: Calendar, label: "Events" },
  { to: "/verify", icon: Shield, label: "Verify" },
  { to: "/profile", icon: UserCircle, label: "Profile" },
];

export const BottomNav = () => {
  const [showOIMDropdown, setShowOIMDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { flags, loading } = useFeatureFlags();

  // Filter navigation items based on feature flags
  const visibleNavItems = navItems.filter(item => {
    if (!item.featureFlag) return true;
    return flags[item.featureFlag as keyof typeof flags] !== false;
  });

  // Filter OIM items based on feature flags
  const visibleOIMItems = oimItems.filter(item => {
    if (item.to === '/events') return flags.events_enabled !== false;
    if (item.featureFlag) return flags[item.featureFlag as keyof typeof flags] !== false;
    return true;
  });

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowOIMDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-t border-border h-16">
      <div className="flex items-center justify-around px-4 h-full max-w-2xl mx-auto relative">
        {visibleNavItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex flex-col items-center gap-1 p-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <Icon className={`h-5 w-5 ${isActive ? "text-primary" : ""}`} />
                <span className={`text-xs font-medium ${isActive ? "text-primary" : ""}`}>
                  {label}
                </span>
              </>
            )}
          </NavLink>
        ))}

        {/* OIM Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            onClick={() => setShowOIMDropdown(!showOIMDropdown)}
            className={`flex flex-col items-center gap-1 p-3 rounded-lg transition-all duration-200 ${
              showOIMDropdown
                ? "text-primary bg-primary/10"
                : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
            }`}
          >
            <User className={`h-5 w-5 ${showOIMDropdown ? "text-primary" : ""}`} />
            <span className={`text-xs font-medium ${showOIMDropdown ? "text-primary" : ""}`}>
              OIM
            </span>
            <ChevronUp className={`h-3 w-3 transition-transform duration-200 ${showOIMDropdown ? "rotate-180" : ""}`} />
          </button>

          {/* Dropdown Menu */}
          {showOIMDropdown && (
            <div className="absolute bottom-full mb-2 right-0 z-50 bg-background border border-border rounded-lg shadow-lg w-44 overflow-hidden">
              <div className="py-2">
                {visibleOIMItems.map(({ to, icon: Icon, label }) => (
                  <NavLink
                    key={to}
                    to={to}
                    onClick={() => setShowOIMDropdown(false)}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-4 py-3 transition-colors duration-200 ${
                        isActive
                          ? "bg-primary/10 text-primary font-medium"
                          : "text-foreground hover:bg-muted/50"
                      }`
                    }
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-sm">{label}</span>
                  </NavLink>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};