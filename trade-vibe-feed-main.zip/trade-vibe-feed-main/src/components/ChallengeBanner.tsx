import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Users, Clock, X } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

interface LiveChallenge {
  id: string;
  title: string;
  description: string;
  end_at: string;
  entry_count: number;
  isParticipating: boolean;
}

export const ChallengeBanner = () => {
  const [liveChallenge, setLiveChallenge] = useState<LiveChallenge | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const { session } = useAuth();

  useEffect(() => {
    const fetchLiveChallenge = async () => {
      try {
        const headers: Record<string, string> = {};
        if (session?.access_token) {
          headers.Authorization = `Bearer ${session.access_token}`;
        }

        const response = await fetch(
          `https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/challenges-api/list?status=live`,
          { headers }
        );
        
        if (response.ok) {
          const data = await response.json();
          const liveChallenges = data.challenges || [];
          if (liveChallenges.length > 0) {
            setLiveChallenge(liveChallenges[0]); // Show first live challenge
          }
        }
      } catch (error) {
        console.error('Error fetching live challenge:', error);
      }
    };

    fetchLiveChallenge();
  }, [session]);

  const getTimeLeft = (endDate: string) => {
    const end = new Date(endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();

    if (diff <= 0) return "Ended";

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

    if (days > 0) return `${days}d ${hours}h left`;
    return `${hours}h left`;
  };

  if (!liveChallenge || dismissed) return null;

  return (
    <Card className="bg-gradient-to-r from-primary/10 via-primary/5 to-background border-primary/20 mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Trophy className="h-6 w-6 text-primary animate-pulse" />
              <Badge className="bg-primary text-primary-foreground">LIVE CHALLENGE</Badge>
            </div>
            
            <div className="hidden md:block">
              <h3 className="font-semibold text-lg">{liveChallenge.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-1">
                {liveChallenge.description}
              </p>
            </div>

            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span>{liveChallenge.entry_count} joined</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>{getTimeLeft(liveChallenge.end_at)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link to={`/challenges/${liveChallenge.id}`}>
              <Button size="sm" variant="outline">
                View Challenge
              </Button>
            </Link>
            {!liveChallenge.isParticipating && (
              <Link to={`/challenges/${liveChallenge.id}`}>
                <Button size="sm">
                  Join Now
                </Button>
              </Link>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};