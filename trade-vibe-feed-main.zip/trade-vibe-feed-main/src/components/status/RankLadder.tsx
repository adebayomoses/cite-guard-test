import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RANKS, getRankByXP } from '@/hooks/useStatus';
import { Check, Lock } from 'lucide-react';

interface RankLadderProps {
  currentXP: number;
}

export const RankLadder = ({ currentXP }: RankLadderProps) => {
  const currentRank = getRankByXP(currentXP);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          ⭐ Rank Ladder
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {[...RANKS].reverse().map((rank, index) => {
          const isUnlocked = currentXP >= rank.minXP;
          const isCurrent = rank.key === currentRank.key;
          
          return (
            <div
              key={rank.key}
              className={`flex items-center justify-between p-3 rounded-lg transition-all ${
                isCurrent
                  ? 'bg-primary/15 border border-primary/30'
                  : isUnlocked
                  ? 'bg-muted/50'
                  : 'bg-muted/20 opacity-60'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{rank.icon}</span>
                <div>
                  <p className={`font-medium ${isCurrent ? 'text-primary' : ''}`}>
                    {rank.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {rank.minXP.toLocaleString()} XP
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {isCurrent && (
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full font-medium">
                    Current
                  </span>
                )}
                {isUnlocked ? (
                  <Check className="h-5 w-5 text-primary" />
                ) : (
                  <Lock className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};
