import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { RANKS, getRankByXP } from '@/hooks/useStatus';

interface RankBadgeProps {
  userId: string;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

export const RankBadge = ({ userId, size = 'sm', showLabel = false, className = '' }: RankBadgeProps) => {
  const { data: userXP } = useQuery({
    queryKey: ['user-xp-badge', userId],
    queryFn: async () => {
      if (!userId) return null;
      
      const { data, error } = await supabase
        .from('user_xp')
        .select('total_xp, current_rank')
        .eq('user_id', userId)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: !!userId,
    staleTime: 60000, // Cache for 1 minute
  });

  if (!userXP) return null;

  const rank = getRankByXP(userXP.total_xp || 0);
  
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-sm px-2 py-1',
    lg: 'text-base px-3 py-1.5',
  };

  const iconSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline" 
            className={`${sizeClasses[size]} ${rank.color} border-current/30 bg-current/10 cursor-help ${className}`}
          >
            <span className={iconSizes[size]}>{rank.icon}</span>
            {showLabel && <span className="ml-1">{rank.name}</span>}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-center">
            <p className="font-semibold">{rank.name} Rank</p>
            <p className="text-xs text-muted-foreground">{userXP.total_xp?.toLocaleString() || 0} XP</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

// Lightweight version that accepts rank data directly (no fetch)
export const RankBadgeStatic = ({ 
  rank, 
  xp, 
  size = 'sm', 
  showLabel = false,
  className = '' 
}: { 
  rank: string; 
  xp?: number; 
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}) => {
  const rankData = RANKS.find(r => r.key === rank) || RANKS[0];
  
  const sizeClasses = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-sm px-2 py-1',
    lg: 'text-base px-3 py-1.5',
  };

  const iconSizes = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline" 
            className={`${sizeClasses[size]} ${rankData.color} border-current/30 bg-current/10 cursor-help ${className}`}
          >
            <span className={iconSizes[size]}>{rankData.icon}</span>
            {showLabel && <span className="ml-1">{rankData.name}</span>}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-center">
            <p className="font-semibold">{rankData.name} Rank</p>
            {xp !== undefined && (
              <p className="text-xs text-muted-foreground">{xp.toLocaleString()} XP</p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
