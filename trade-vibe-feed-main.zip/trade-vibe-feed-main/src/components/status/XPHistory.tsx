import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { XPTransaction } from '@/hooks/useStatus';
import { formatDistanceToNow } from 'date-fns';
import { TrendingUp, TrendingDown, Zap, Trophy, ThumbsUp, Flame, FileText, Award } from 'lucide-react';

interface XPHistoryProps {
  transactions: XPTransaction[];
}

const getSourceIcon = (sourceType: string) => {
  switch (sourceType) {
    case 'signal_win': return <TrendingUp className="h-4 w-4 text-profit" />;
    case 'signal_loss': return <TrendingDown className="h-4 w-4 text-destructive" />;
    case 'useful_vote': return <ThumbsUp className="h-4 w-4 text-primary" />;
    case 'challenge_win': return <Trophy className="h-4 w-4 text-amber-500" />;
    case 'daily_streak': return <Flame className="h-4 w-4 text-orange-500" />;
    case 'post_created': return <FileText className="h-4 w-4 text-blue-500" />;
    case 'achievement_unlocked': return <Award className="h-4 w-4 text-purple-500" />;
    default: return <Zap className="h-4 w-4 text-primary" />;
  }
};

const getSourceLabel = (sourceType: string) => {
  switch (sourceType) {
    case 'signal_win': return 'Signal Win';
    case 'signal_loss': return 'Signal Loss';
    case 'useful_vote': return 'Useful Vote';
    case 'challenge_win': return 'Challenge Win';
    case 'daily_streak': return 'Daily Streak';
    case 'post_created': return 'Post Created';
    case 'achievement_unlocked': return 'Achievement';
    default: return sourceType.replace(/_/g, ' ');
  }
};

export const XPHistory = ({ transactions }: XPHistoryProps) => {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Recent XP
        </CardTitle>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <p className="text-center text-muted-foreground py-4">
            No XP earned yet. Start trading to earn XP!
          </p>
        ) : (
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/30 transition-colors"
              >
                <div className="p-2 rounded-full bg-muted/50">
                  {getSourceIcon(tx.source_type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{getSourceLabel(tx.source_type)}</p>
                  {tx.description && (
                    <p className="text-xs text-muted-foreground truncate">{tx.description}</p>
                  )}
                </div>
                <div className="text-right">
                  <p className={`font-bold ${tx.amount >= 0 ? 'text-profit' : 'text-destructive'}`}>
                    {tx.amount >= 0 ? '+' : ''}{tx.amount} XP
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(tx.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
