import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Achievement, UserAchievement } from '@/hooks/useStatus';
import { Lock } from 'lucide-react';
import { format } from 'date-fns';

interface AchievementsGridProps {
  achievements: Achievement[];
  userAchievements: UserAchievement[];
}

const rarityColors: Record<string, string> = {
  common: 'bg-muted text-muted-foreground',
  rare: 'bg-blue-500/20 text-blue-500 border-blue-500/30',
  epic: 'bg-purple-500/20 text-purple-500 border-purple-500/30',
  legendary: 'bg-amber-500/20 text-amber-500 border-amber-500/30',
};

const categoryLabels: Record<string, string> = {
  trading: 'Trading',
  community: 'Community',
  milestone: 'Milestone',
  special: 'Special',
};

export const AchievementsGrid = ({ achievements, userAchievements }: AchievementsGridProps) => {
  const unlockedIds = new Set(userAchievements.map(ua => ua.achievement_id));
  
  const groupedAchievements = achievements.reduce((acc, achievement) => {
    const category = achievement.category || 'general';
    if (!acc[category]) acc[category] = [];
    acc[category].push(achievement);
    return acc;
  }, {} as Record<string, Achievement[]>);

  const getUnlockDate = (achievementId: string) => {
    const ua = userAchievements.find(u => u.achievement_id === achievementId);
    return ua ? format(new Date(ua.unlocked_at), 'MMM d, yyyy') : null;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            🏅 Achievements
          </CardTitle>
          <Badge variant="secondary" className="text-xs">
            {userAchievements.length}/{achievements.length} Unlocked
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {Object.entries(groupedAchievements).map(([category, categoryAchievements]) => (
          <div key={category}>
            <h4 className="text-sm font-medium text-muted-foreground mb-3">
              {categoryLabels[category] || category}
            </h4>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {categoryAchievements.map((achievement) => {
                const isUnlocked = unlockedIds.has(achievement.id);
                const unlockDate = getUnlockDate(achievement.id);
                
                return (
                  <Tooltip key={achievement.id}>
                    <TooltipTrigger asChild>
                      <div
                        className={`relative aspect-square rounded-xl flex flex-col items-center justify-center p-2 transition-all cursor-pointer ${
                          isUnlocked
                            ? 'bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/30 hover:scale-105'
                            : 'bg-muted/30 border border-border opacity-50 grayscale'
                        }`}
                      >
                        <span className="text-2xl mb-1">{achievement.icon}</span>
                        <span className="text-[10px] font-medium text-center leading-tight line-clamp-2">
                          {achievement.name}
                        </span>
                        {!isUnlocked && (
                          <Lock className="absolute top-1 right-1 h-3 w-3 text-muted-foreground" />
                        )}
                        <Badge 
                          variant="outline" 
                          className={`absolute -bottom-1 text-[8px] px-1 py-0 ${rarityColors[achievement.rarity]}`}
                        >
                          {achievement.rarity}
                        </Badge>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="max-w-[200px]">
                      <div className="space-y-1">
                        <p className="font-medium">{achievement.name}</p>
                        <p className="text-xs text-muted-foreground">{achievement.description}</p>
                        <p className="text-xs text-primary">+{achievement.xp_reward} XP</p>
                        {unlockDate && (
                          <p className="text-xs text-muted-foreground">Unlocked: {unlockDate}</p>
                        )}
                      </div>
                    </TooltipContent>
                  </Tooltip>
                );
              })}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};
