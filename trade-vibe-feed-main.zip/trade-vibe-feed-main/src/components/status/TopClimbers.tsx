import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TopClimber, getRankByXP } from '@/hooks/useStatus';
import { TrendingUp, Crown, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface TopClimbersProps {
  weeklyClimbers: TopClimber[];
  allTimeLeaders: TopClimber[];
}

const getMedalIcon = (rank: number) => {
  switch (rank) {
    case 1: return '🥇';
    case 2: return '🥈';
    case 3: return '🥉';
    default: return null;
  }
};

export const TopClimbers = ({ weeklyClimbers, allTimeLeaders }: TopClimbersProps) => {
  const navigate = useNavigate();

  const renderLeaderboard = (climbers: TopClimber[], xpKey: 'weekly_xp' | 'total_xp') => (
    <div className="space-y-2">
      {climbers.length === 0 ? (
        <p className="text-center text-muted-foreground py-4">No data yet</p>
      ) : (
        climbers.map((climber, index) => {
          const rank = getRankByXP(climber.total_xp);
          const medal = getMedalIcon(index + 1);
          
          return (
            <div
              key={climber.user_id}
              onClick={() => navigate(`/profile/${climber.profile?.handle}`)}
              className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all hover:bg-muted/50 ${
                index < 3 ? 'bg-primary/5' : ''
              }`}
            >
              {/* Rank Number or Medal */}
              <div className="w-8 text-center">
                {medal ? (
                  <span className="text-xl">{medal}</span>
                ) : (
                  <span className="text-sm font-medium text-muted-foreground">#{index + 1}</span>
                )}
              </div>
              
              {/* Avatar */}
              <Avatar className="h-10 w-10 border-2 border-border">
                <AvatarImage src={climber.profile?.avatar_url || ''} />
                <AvatarFallback className="bg-muted text-muted-foreground">
                  {(climber.profile?.display_name || climber.profile?.handle || '?')[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              {/* Name and Rank */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium truncate">
                    {climber.profile?.display_name || climber.profile?.handle}
                  </span>
                  {climber.profile?.verified_status === 'manual' && (
                    <ShieldCheck className="h-4 w-4 text-primary flex-shrink-0" />
                  )}
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <span>{rank.icon}</span>
                  <span>{rank.name}</span>
                </div>
              </div>
              
              {/* XP */}
              <div className="text-right">
                <p className="font-bold text-primary">
                  {climber[xpKey].toLocaleString()}
                </p>
                <p className="text-xs text-muted-foreground">XP</p>
              </div>
            </div>
          );
        })
      )}
    </div>
  );

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="weekly" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="weekly" className="text-sm">
              🔥 This Week
            </TabsTrigger>
            <TabsTrigger value="alltime" className="text-sm">
              👑 All Time
            </TabsTrigger>
          </TabsList>
          <TabsContent value="weekly">
            {renderLeaderboard(weeklyClimbers, 'weekly_xp')}
          </TabsContent>
          <TabsContent value="alltime">
            {renderLeaderboard(allTimeLeaders, 'total_xp')}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
