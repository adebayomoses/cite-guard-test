import { useEffect, useState, useCallback } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RANKS } from '@/hooks/useStatus';
import { Sparkles, Star, Trophy, Crown } from 'lucide-react';

interface RankUpCelebrationProps {
  isOpen: boolean;
  onClose: () => void;
  newRank: string;
  oldRank: string;
}

interface Confetti {
  id: number;
  left: number;
  animationDelay: number;
  color: string;
}

const CONFETTI_COLORS = [
  'hsl(142, 76%, 36%)', // primary green
  'hsl(48, 96%, 53%)',  // gold
  'hsl(280, 87%, 65%)', // purple
  'hsl(199, 89%, 48%)', // blue
  'hsl(350, 89%, 60%)', // pink
];

export const RankUpCelebration = ({ isOpen, onClose, newRank, oldRank }: RankUpCelebrationProps) => {
  const [confetti, setConfetti] = useState<Confetti[]>([]);
  
  const rankInfo = RANKS.find(r => r.key === newRank);
  const oldRankInfo = RANKS.find(r => r.key === oldRank);

  const generateConfetti = useCallback(() => {
    const newConfetti: Confetti[] = [];
    for (let i = 0; i < 50; i++) {
      newConfetti.push({
        id: i,
        left: Math.random() * 100,
        animationDelay: Math.random() * 2,
        color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
      });
    }
    setConfetti(newConfetti);
  }, []);

  useEffect(() => {
    if (isOpen) {
      generateConfetti();
    }
  }, [isOpen, generateConfetti]);

  const getRankIcon = (rank: string) => {
    switch (rank) {
      case 'legend':
        return <Crown className="h-16 w-16 text-amber-400" />;
      case 'elite':
        return <Trophy className="h-16 w-16 text-yellow-500" />;
      case 'pro':
        return <Star className="h-16 w-16 text-yellow-500" />;
      case 'trader':
        return <Star className="h-16 w-16 text-yellow-500" />;
      default:
        return <Sparkles className="h-16 w-16 text-primary" />;
    }
  };

  if (!rankInfo) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md overflow-hidden border-none bg-gradient-to-b from-card to-background">
        {/* Confetti */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {confetti.map((c) => (
            <div
              key={c.id}
              className="absolute w-2 h-2 rounded-full animate-confetti"
              style={{
                left: `${c.left}%`,
                backgroundColor: c.color,
                animationDelay: `${c.animationDelay}s`,
              }}
            />
          ))}
        </div>

        <div className="relative z-10 flex flex-col items-center text-center py-6 space-y-6">
          {/* Glowing ring effect */}
          <div className="relative">
            <div className="absolute inset-0 animate-ping-slow rounded-full bg-primary/20" />
            <div className="relative p-6 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30">
              {getRankIcon(newRank)}
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <p className="text-lg text-muted-foreground">Congratulations!</p>
            <h2 className="text-3xl font-bold tracking-tight">
              You Ranked Up!
            </h2>
          </div>

          {/* Rank transition */}
          <div className="flex items-center gap-4">
            <div className="text-center">
              <p className="text-2xl">{oldRankInfo?.icon}</p>
              <p className="text-sm text-muted-foreground">{oldRankInfo?.name}</p>
            </div>
            <div className="text-2xl text-muted-foreground">→</div>
            <div className="text-center">
              <p className="text-3xl animate-bounce">{rankInfo.icon}</p>
              <p className="text-lg font-semibold text-primary">{rankInfo.name}</p>
            </div>
          </div>

          {/* Stars display */}
          <div className="flex gap-1">
            {Array.from({ length: rankInfo.stars }).map((_, i) => (
              <Star
                key={i}
                className="h-6 w-6 fill-yellow-500 text-yellow-500 animate-star-pop"
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>

          {/* XP milestone info */}
          <p className="text-sm text-muted-foreground">
            You've reached {rankInfo.minXP.toLocaleString()} XP!
          </p>

          {/* Close button */}
          <Button onClick={onClose} className="w-full">
            Continue Trading
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
