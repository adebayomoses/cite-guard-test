import { useState, useCallback } from 'react';
import { useXPNotifications } from '@/hooks/useXPNotifications';
import { RankUpCelebration } from './RankUpCelebration';

export const XPNotificationProvider = () => {
  const [celebrationOpen, setCelebrationOpen] = useState(false);
  const [rankTransition, setRankTransition] = useState<{ newRank: string; oldRank: string }>({
    newRank: '',
    oldRank: '',
  });

  const handleRankUp = useCallback((newRank: string, oldRank: string) => {
    setRankTransition({ newRank, oldRank });
    setCelebrationOpen(true);
  }, []);

  useXPNotifications(handleRankUp);

  return (
    <RankUpCelebration
      isOpen={celebrationOpen}
      onClose={() => setCelebrationOpen(false)}
      newRank={rankTransition.newRank}
      oldRank={rankTransition.oldRank}
    />
  );
};
