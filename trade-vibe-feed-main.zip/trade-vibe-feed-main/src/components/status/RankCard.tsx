import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { UserXP, RANKS, getRankByXP, getNextRank, getProgressToNextRank } from '@/hooks/useStatus';
import { Flame, Star, Zap } from 'lucide-react';

interface RankCardProps {
  userXP: UserXP | null;
}

export const RankCard = ({ userXP }: RankCardProps) => {
  const xp = userXP?.total_xp || 0;
  const currentRank = getRankByXP(xp);
  const nextRank = getNextRank(currentRank.key);
  const { progress, xpNeeded } = getProgressToNextRank(xp);
  const streak = userXP?.current_streak || 0;

  return (
    <Card className="bg-gradient-to-br from-primary/10 via-card to-primary/5 border-primary/20 overflow-hidden relative">
      {/* Decorative background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
      
      <CardContent className="relative p-6">
        {/* Rank Badge */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="text-5xl animate-pulse-subtle">
              {currentRank.icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">{currentRank.name}</h2>
              <p className="text-sm text-muted-foreground">Current Rank</p>
            </div>
          </div>
          
          {/* Streak Badge */}
          {streak > 0 && (
            <div className="flex items-center gap-2 bg-destructive/10 text-destructive px-3 py-2 rounded-full">
              <Flame className="h-5 w-5" />
              <span className="font-bold">{streak} day streak</span>
            </div>
          )}
        </div>

        {/* XP Display */}
        <div className="mb-4">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-4xl font-bold text-primary">{xp.toLocaleString()}</span>
            <span className="text-lg text-muted-foreground">XP</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Zap className="h-4 w-4 text-primary" />
            <span>+{userXP?.weekly_xp || 0} XP this week</span>
          </div>
        </div>

        {/* Progress to Next Rank */}
        {nextRank ? (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress to {nextRank.name}</span>
              <span className="font-medium text-primary">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-3 bg-muted" />
            <p className="text-xs text-muted-foreground text-center">
              {xpNeeded.toLocaleString()} XP needed for next rank
            </p>
          </div>
        ) : (
          <div className="text-center py-2">
            <p className="text-primary font-medium">🏆 Maximum Rank Achieved!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
