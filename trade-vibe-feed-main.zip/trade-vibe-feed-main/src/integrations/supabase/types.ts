export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          category: string
          created_at: string
          description: string
          icon: string
          id: string
          is_active: boolean | null
          key: string
          name: string
          rarity: string
          sort_order: number
          unlock_condition: Json
          xp_reward: number
        }
        Insert: {
          category?: string
          created_at?: string
          description: string
          icon: string
          id?: string
          is_active?: boolean | null
          key: string
          name: string
          rarity?: string
          sort_order?: number
          unlock_condition?: Json
          xp_reward?: number
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          icon?: string
          id?: string
          is_active?: boolean | null
          key?: string
          name?: string
          rarity?: string
          sort_order?: number
          unlock_condition?: Json
          xp_reward?: number
        }
        Relationships: []
      }
      admin_audit_log: {
        Row: {
          action: string
          admin_id: string | null
          created_at: string | null
          id: number
          metadata: Json | null
          subject_id: string | null
          subject_type: string
        }
        Insert: {
          action: string
          admin_id?: string | null
          created_at?: string | null
          id?: never
          metadata?: Json | null
          subject_id?: string | null
          subject_type: string
        }
        Update: {
          action?: string
          admin_id?: string | null
          created_at?: string | null
          id?: never
          metadata?: Json | null
          subject_id?: string | null
          subject_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_audit_log_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_audit_log_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "admin_audit_log_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "admin_audit_log_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      admin_notes: {
        Row: {
          author: string | null
          created_at: string | null
          id: string
          note: string
          subject_id: string
          subject_type: string
        }
        Insert: {
          author?: string | null
          created_at?: string | null
          id?: string
          note: string
          subject_id: string
          subject_type: string
        }
        Update: {
          author?: string | null
          created_at?: string | null
          id?: string
          note?: string
          subject_id?: string
          subject_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_notes_author_fkey"
            columns: ["author"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_notes_author_fkey"
            columns: ["author"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "admin_notes_author_fkey"
            columns: ["author"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "admin_notes_author_fkey"
            columns: ["author"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      challenge_collaborators: {
        Row: {
          added_at: string | null
          added_by: string | null
          challenge_id: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          added_at?: string | null
          added_by?: string | null
          challenge_id: string
          id?: string
          role?: string
          user_id: string
        }
        Update: {
          added_at?: string | null
          added_by?: string | null
          challenge_id?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_collaborators_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_collaborators_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_collaborators_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_collaborators_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_collaborators_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_collaborators_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges_with_status"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_collaborators_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_collaborators_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_collaborators_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_collaborators_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      challenge_discussions: {
        Row: {
          author_id: string
          challenge_id: string
          content: string
          created_at: string
          id: string
          updated_at: string
        }
        Insert: {
          author_id: string
          challenge_id: string
          content: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Update: {
          author_id?: string
          challenge_id?: string
          content?: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      challenge_entries: {
        Row: {
          challenge_id: string
          joined_at: string | null
          user_id: string
        }
        Insert: {
          challenge_id: string
          joined_at?: string | null
          user_id: string
        }
        Update: {
          challenge_id?: string
          joined_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_entries_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_entries_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges_with_status"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_entries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_entries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_entries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_entries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      challenge_scores: {
        Row: {
          challenge_id: string
          rank: number | null
          score: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          challenge_id: string
          rank?: number | null
          score?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          challenge_id?: string
          rank?: number | null
          score?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "challenge_scores_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges_with_status"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      challenge_signals: {
        Row: {
          author_id: string
          challenge_id: string
          content: string
          created_at: string
          entry_price: number | null
          id: string
          image_url: string | null
          market_type: string | null
          risk_level: string | null
          stop_loss: number | null
          target_price: number | null
          timeframe: string | null
          trade_direction: string | null
          updated_at: string
        }
        Insert: {
          author_id: string
          challenge_id: string
          content: string
          created_at?: string
          entry_price?: number | null
          id?: string
          image_url?: string | null
          market_type?: string | null
          risk_level?: string | null
          stop_loss?: number | null
          target_price?: number | null
          timeframe?: string | null
          trade_direction?: string | null
          updated_at?: string
        }
        Update: {
          author_id?: string
          challenge_id?: string
          content?: string
          created_at?: string
          entry_price?: number | null
          id?: string
          image_url?: string | null
          market_type?: string | null
          risk_level?: string | null
          stop_loss?: number | null
          target_price?: number | null
          timeframe?: string | null
          trade_direction?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      challenges: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          end_at: string
          id: string
          metric: string | null
          risk_management: string | null
          scope: string | null
          start_at: string
          title: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_at: string
          id?: string
          metric?: string | null
          risk_management?: string | null
          scope?: string | null
          start_at: string
          title: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_at?: string
          id?: string
          metric?: string | null
          risk_management?: string | null
          scope?: string | null
          start_at?: string
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      chat_requests: {
        Row: {
          created_at: string | null
          expires_at: string | null
          from_user_id: string
          id: string
          intro_message: string | null
          status: string | null
          to_user_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          from_user_id: string
          id?: string
          intro_message?: string | null
          status?: string | null
          to_user_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          from_user_id?: string
          id?: string
          intro_message?: string | null
          status?: string | null
          to_user_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_requests_from_user_id_fkey"
            columns: ["from_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_requests_from_user_id_fkey"
            columns: ["from_user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "chat_requests_from_user_id_fkey"
            columns: ["from_user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "chat_requests_from_user_id_fkey"
            columns: ["from_user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "chat_requests_to_user_id_fkey"
            columns: ["to_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_requests_to_user_id_fkey"
            columns: ["to_user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "chat_requests_to_user_id_fkey"
            columns: ["to_user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "chat_requests_to_user_id_fkey"
            columns: ["to_user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      comments: {
        Row: {
          author_id: string
          created_at: string | null
          id: string
          post_id: string
          text: string
          updated_at: string | null
        }
        Insert: {
          author_id: string
          created_at?: string | null
          id?: string
          post_id: string
          text: string
          updated_at?: string | null
        }
        Update: {
          author_id?: string
          created_at?: string | null
          id?: string
          post_id?: string
          text?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      conversation_participants: {
        Row: {
          conversation_id: string
          joined_at: string | null
          last_read_at: string | null
          user_id: string
        }
        Insert: {
          conversation_id: string
          joined_at?: string | null
          last_read_at?: string | null
          user_id: string
        }
        Update: {
          conversation_id?: string
          joined_at?: string | null
          last_read_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_participants_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "conversation_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "conversation_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string | null
          group_type: Database["public"]["Enums"]["group_type"] | null
          id: string
          is_group: boolean | null
          parent_server_id: string | null
        }
        Insert: {
          created_at?: string | null
          group_type?: Database["public"]["Enums"]["group_type"] | null
          id?: string
          is_group?: boolean | null
          parent_server_id?: string | null
        }
        Update: {
          created_at?: string | null
          group_type?: Database["public"]["Enums"]["group_type"] | null
          id?: string
          is_group?: boolean | null
          parent_server_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "conversations_parent_server_id_fkey"
            columns: ["parent_server_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string | null
          description: string | null
          end_at: string | null
          host_id: string | null
          id: string
          location: string | null
          start_at: string
          tags: string[] | null
          title: string
          updated_at: string | null
          url: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          end_at?: string | null
          host_id?: string | null
          id?: string
          location?: string | null
          start_at: string
          tags?: string[] | null
          title: string
          updated_at?: string | null
          url?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          end_at?: string | null
          host_id?: string | null
          id?: string
          location?: string | null
          start_at?: string
          tags?: string[] | null
          title?: string
          updated_at?: string | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "events_host_id_fkey"
            columns: ["host_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "events_host_id_fkey"
            columns: ["host_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "events_host_id_fkey"
            columns: ["host_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "events_host_id_fkey"
            columns: ["host_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      feature_flags: {
        Row: {
          enabled: boolean
          key: string
          updated_at: string | null
        }
        Insert: {
          enabled?: boolean
          key: string
          updated_at?: string | null
        }
        Update: {
          enabled?: boolean
          key?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string
          target_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          target_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          target_id?: string
          user_id?: string
        }
        Relationships: []
      }
      group_members: {
        Row: {
          added_by: string | null
          conversation_id: string
          joined_at: string | null
          role: string
          user_id: string
        }
        Insert: {
          added_by?: string | null
          conversation_id: string
          joined_at?: string | null
          role?: string
          user_id: string
        }
        Update: {
          added_by?: string | null
          conversation_id?: string
          joined_at?: string | null
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_members_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_members_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_members_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_members_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_members_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      group_settings: {
        Row: {
          allow_member_add: boolean | null
          allow_member_messages: boolean | null
          allow_public_join: boolean | null
          avatar_url: string | null
          conversation_id: string
          created_at: string | null
          created_by: string
          current_mentees: number | null
          default_channel_id: string | null
          description: string | null
          id: string
          is_mentorship_channel: boolean | null
          max_members: number | null
          max_mentees: number | null
          mentorship_billing_cycle: string | null
          mentorship_price: number | null
          mentorship_type: string | null
          name: string
          require_approval: boolean | null
          updated_at: string | null
        }
        Insert: {
          allow_member_add?: boolean | null
          allow_member_messages?: boolean | null
          allow_public_join?: boolean | null
          avatar_url?: string | null
          conversation_id: string
          created_at?: string | null
          created_by: string
          current_mentees?: number | null
          default_channel_id?: string | null
          description?: string | null
          id?: string
          is_mentorship_channel?: boolean | null
          max_members?: number | null
          max_mentees?: number | null
          mentorship_billing_cycle?: string | null
          mentorship_price?: number | null
          mentorship_type?: string | null
          name: string
          require_approval?: boolean | null
          updated_at?: string | null
        }
        Update: {
          allow_member_add?: boolean | null
          allow_member_messages?: boolean | null
          allow_public_join?: boolean | null
          avatar_url?: string | null
          conversation_id?: string
          created_at?: string | null
          created_by?: string
          current_mentees?: number | null
          default_channel_id?: string | null
          description?: string | null
          id?: string
          is_mentorship_channel?: boolean | null
          max_members?: number | null
          max_mentees?: number | null
          mentorship_billing_cycle?: string | null
          mentorship_price?: number | null
          mentorship_type?: string | null
          name?: string
          require_approval?: boolean | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "group_settings_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: true
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_settings_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_settings_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_settings_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_settings_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "group_settings_default_channel_id_fkey"
            columns: ["default_channel_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      journal_entries: {
        Row: {
          content: string
          created_at: string | null
          id: string
          is_published: boolean | null
          mood: string | null
          tags: string[] | null
          tickers_mentioned: string[] | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          is_published?: boolean | null
          mood?: string | null
          tags?: string[] | null
          tickers_mentioned?: string[] | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          is_published?: boolean | null
          mood?: string | null
          tags?: string[] | null
          tickers_mentioned?: string[] | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      lifestyle_comments: {
        Row: {
          author_id: string
          created_at: string | null
          id: string
          text: string
          updated_at: string | null
          video_id: string
        }
        Insert: {
          author_id: string
          created_at?: string | null
          id?: string
          text: string
          updated_at?: string | null
          video_id: string
        }
        Update: {
          author_id?: string
          created_at?: string | null
          id?: string
          text?: string
          updated_at?: string | null
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lifestyle_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lifestyle_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_comments_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "lifestyle_videos"
            referencedColumns: ["id"]
          },
        ]
      }
      lifestyle_likes: {
        Row: {
          created_at: string | null
          user_id: string
          video_id: string
        }
        Insert: {
          created_at?: string | null
          user_id: string
          video_id: string
        }
        Update: {
          created_at?: string | null
          user_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lifestyle_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lifestyle_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_likes_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "lifestyle_videos"
            referencedColumns: ["id"]
          },
        ]
      }
      lifestyle_videos: {
        Row: {
          author_id: string
          caption: string | null
          comment_count: number | null
          created_at: string | null
          duration_seconds: number | null
          hashtags: string[] | null
          id: string
          like_count: number | null
          thumbnail_url: string | null
          tickers: string[] | null
          updated_at: string | null
          video_url: string
          visibility: string | null
        }
        Insert: {
          author_id: string
          caption?: string | null
          comment_count?: number | null
          created_at?: string | null
          duration_seconds?: number | null
          hashtags?: string[] | null
          id?: string
          like_count?: number | null
          thumbnail_url?: string | null
          tickers?: string[] | null
          updated_at?: string | null
          video_url: string
          visibility?: string | null
        }
        Update: {
          author_id?: string
          caption?: string | null
          comment_count?: number | null
          created_at?: string | null
          duration_seconds?: number | null
          hashtags?: string[] | null
          id?: string
          like_count?: number | null
          thumbnail_url?: string | null
          tickers?: string[] | null
          updated_at?: string | null
          video_url?: string
          visibility?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lifestyle_videos_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lifestyle_videos_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_videos_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "lifestyle_videos_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      market_news: {
        Row: {
          category: string | null
          created_at: string | null
          id: string
          image_url: string | null
          published_at: string
          source: string | null
          summary: string | null
          title: string
          url: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          id?: string
          image_url?: string | null
          published_at: string
          source?: string | null
          summary?: string | null
          title: string
          url: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          id?: string
          image_url?: string | null
          published_at?: string
          source?: string | null
          summary?: string | null
          title?: string
          url?: string
        }
        Relationships: []
      }
      market_prices: {
        Row: {
          current_price: number
          id: string
          last_updated: string | null
          market_type: string
          name: string
          percent_change_24h: number | null
          price_change_24h: number | null
          symbol: string
        }
        Insert: {
          current_price: number
          id?: string
          last_updated?: string | null
          market_type: string
          name: string
          percent_change_24h?: number | null
          price_change_24h?: number | null
          symbol: string
        }
        Update: {
          current_price?: number
          id?: string
          last_updated?: string | null
          market_type?: string
          name?: string
          percent_change_24h?: number | null
          price_change_24h?: number | null
          symbol?: string
        }
        Relationships: []
      }
      mentorship_sessions: {
        Row: {
          created_at: string | null
          id: string
          mentee_id: string
          mentor_id: string
          price: number | null
          scheduled_at: string | null
          session_type: string
          status: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          mentee_id: string
          mentor_id: string
          price?: number | null
          scheduled_at?: string | null
          session_type: string
          status?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          mentee_id?: string
          mentor_id?: string
          price?: number | null
          scheduled_at?: string | null
          session_type?: string
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mentorship_sessions_mentee_id_fkey"
            columns: ["mentee_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentee_id_fkey"
            columns: ["mentee_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentee_id_fkey"
            columns: ["mentee_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentee_id_fkey"
            columns: ["mentee_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "mentorship_sessions_mentor_id_fkey"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      mentorship_subscriptions: {
        Row: {
          amount_paid: number | null
          created_at: string | null
          expires_at: string | null
          id: string
          last_payment_at: string | null
          next_payment_at: string | null
          server_id: string
          started_at: string
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount_paid?: number | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          last_payment_at?: string | null
          next_payment_at?: string | null
          server_id: string
          started_at?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount_paid?: number | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          last_payment_at?: string | null
          next_payment_at?: string | null
          server_id?: string
          started_at?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mentorship_subscriptions_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      message_reports: {
        Row: {
          created_at: string | null
          id: string
          message_id: string | null
          reason: string | null
          reporter: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          message_id?: string | null
          reason?: string | null
          reporter?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          message_id?: string | null
          reason?: string | null
          reporter?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "message_reports_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "message_reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "message_reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_path: string | null
          author_id: string | null
          body: string | null
          conversation_id: string | null
          created_at: string | null
          deleted_at: string | null
          edited_at: string | null
          id: string
          mime_type: string | null
        }
        Insert: {
          attachment_path?: string | null
          author_id?: string | null
          body?: string | null
          conversation_id?: string | null
          created_at?: string | null
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          mime_type?: string | null
        }
        Update: {
          attachment_path?: string | null
          author_id?: string | null
          body?: string | null
          conversation_id?: string | null
          created_at?: string | null
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          mime_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "messages_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "messages_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          link: string | null
          message: string
          metadata: Json | null
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          link?: string | null
          message: string
          metadata?: Json | null
          read?: boolean
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          link?: string | null
          message?: string
          metadata?: Json | null
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      post_scores: {
        Row: {
          net_score: number | null
          not_useful_count: number | null
          post_id: string
          updated_at: string | null
          useful_count: number | null
        }
        Insert: {
          net_score?: number | null
          not_useful_count?: number | null
          post_id: string
          updated_at?: string | null
          useful_count?: number | null
        }
        Update: {
          net_score?: number | null
          not_useful_count?: number | null
          post_id?: string
          updated_at?: string | null
          useful_count?: number | null
        }
        Relationships: []
      }
      posts: {
        Row: {
          author_id: string
          content: string
          created_at: string
          id: string
          image_url: string | null
          market_type: string | null
          risk_level: string | null
          tickers: string[] | null
          trade_direction: string | null
          trade_meta: Json | null
          updated_at: string
        }
        Insert: {
          author_id: string
          content: string
          created_at?: string
          id?: string
          image_url?: string | null
          market_type?: string | null
          risk_level?: string | null
          tickers?: string[] | null
          trade_direction?: string | null
          trade_meta?: Json | null
          updated_at?: string
        }
        Update: {
          author_id?: string
          content?: string
          created_at?: string
          id?: string
          image_url?: string | null
          market_type?: string | null
          risk_level?: string | null
          tickers?: string[] | null
          trade_direction?: string | null
          trade_meta?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      price_alerts: {
        Row: {
          condition: string
          created_at: string | null
          id: string
          market_type: string
          target_price: number
          ticker: string
          triggered: boolean | null
          triggered_at: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          condition: string
          created_at?: string | null
          id?: string
          market_type?: string
          target_price: number
          ticker: string
          triggered?: boolean | null
          triggered_at?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          condition?: string
          created_at?: string | null
          id?: string
          market_type?: string
          target_price?: number
          ticker?: string
          triggered?: boolean | null
          triggered_at?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "price_alerts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "price_alerts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "price_alerts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "price_alerts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      profile_privacy: {
        Row: {
          is_public: boolean | null
          show_stats: boolean | null
          user_id: string
        }
        Insert: {
          is_public?: boolean | null
          show_stats?: boolean | null
          user_id: string
        }
        Update: {
          is_public?: boolean | null
          show_stats?: boolean | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profile_privacy_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profile_privacy_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_privacy_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "profile_privacy_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string | null
          display_name: string | null
          experience_level: string | null
          handle: string
          id: string
          is_admin: boolean | null
          is_mentor: boolean | null
          links: Json | null
          markets: string[] | null
          mentor_available: boolean | null
          mentor_bio: string | null
          mentor_price: number | null
          mentor_type: string | null
          reputation_last30: number | null
          shadow_banned: boolean | null
          strategy_tags: string[] | null
          timezone: string | null
          updated_at: string | null
          verified_status: string | null
          watchlist: string[] | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          display_name?: string | null
          experience_level?: string | null
          handle: string
          id: string
          is_admin?: boolean | null
          is_mentor?: boolean | null
          links?: Json | null
          markets?: string[] | null
          mentor_available?: boolean | null
          mentor_bio?: string | null
          mentor_price?: number | null
          mentor_type?: string | null
          reputation_last30?: number | null
          shadow_banned?: boolean | null
          strategy_tags?: string[] | null
          timezone?: string | null
          updated_at?: string | null
          verified_status?: string | null
          watchlist?: string[] | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          display_name?: string | null
          experience_level?: string | null
          handle?: string
          id?: string
          is_admin?: boolean | null
          is_mentor?: boolean | null
          links?: Json | null
          markets?: string[] | null
          mentor_available?: boolean | null
          mentor_bio?: string | null
          mentor_price?: number | null
          mentor_type?: string | null
          reputation_last30?: number | null
          shadow_banned?: boolean | null
          strategy_tags?: string[] | null
          timezone?: string | null
          updated_at?: string | null
          verified_status?: string | null
          watchlist?: string[] | null
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string | null
          id: string
          reason: string | null
          reporter: string | null
          status: string | null
          target_id: string
          target_type: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          reason?: string | null
          reporter?: string | null
          status?: string | null
          target_id: string
          target_type: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          reason?: string | null
          reporter?: string | null
          status?: string | null
          target_id?: string
          target_type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "reports_reporter_fkey"
            columns: ["reporter"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      reputation_snapshots: {
        Row: {
          created_at: string
          id: string
          reputation: number
          snapshot_date: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          reputation?: number
          snapshot_date?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          reputation?: number
          snapshot_date?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reputation_snapshots_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reputation_snapshots_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "reputation_snapshots_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "reputation_snapshots_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      saved_posts: {
        Row: {
          created_at: string | null
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          post_id?: string
          user_id?: string
        }
        Relationships: []
      }
      server_channels: {
        Row: {
          channel_conversation_id: string
          channel_order: number | null
          created_at: string | null
          description: string | null
          id: string
          is_default: boolean | null
          name: string
          server_id: string
          updated_at: string | null
        }
        Insert: {
          channel_conversation_id: string
          channel_order?: number | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_default?: boolean | null
          name: string
          server_id: string
          updated_at?: string | null
        }
        Update: {
          channel_conversation_id?: string
          channel_order?: number | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_default?: boolean | null
          name?: string
          server_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "server_channels_channel_conversation_id_fkey"
            columns: ["channel_conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "server_channels_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      signal_tracking: {
        Row: {
          author_id: string
          closed_at: string | null
          created_at: string | null
          current_price: number | null
          entry_price: number
          expires_at: string | null
          id: string
          last_checked_at: string | null
          market_type: string
          pnl_percentage: number | null
          signal_id: string
          signal_type: string
          status: string
          stop_loss: number | null
          target_price: number | null
          ticker: string
          trade_direction: string
          updated_at: string | null
        }
        Insert: {
          author_id: string
          closed_at?: string | null
          created_at?: string | null
          current_price?: number | null
          entry_price: number
          expires_at?: string | null
          id?: string
          last_checked_at?: string | null
          market_type: string
          pnl_percentage?: number | null
          signal_id: string
          signal_type: string
          status?: string
          stop_loss?: number | null
          target_price?: number | null
          ticker: string
          trade_direction: string
          updated_at?: string | null
        }
        Update: {
          author_id?: string
          closed_at?: string | null
          created_at?: string | null
          current_price?: number | null
          entry_price?: number
          expires_at?: string | null
          id?: string
          last_checked_at?: string | null
          market_type?: string
          pnl_percentage?: number | null
          signal_id?: string
          signal_type?: string
          status?: string
          stop_loss?: number | null
          target_price?: number | null
          ticker?: string
          trade_direction?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "signal_tracking_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "signal_tracking_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "signal_tracking_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "signal_tracking_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      site_settings: {
        Row: {
          key: string
          updated_at: string | null
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string | null
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string | null
          value?: Json
        }
        Relationships: []
      }
      ticker_mappings: {
        Row: {
          api_symbol: string
          created_at: string | null
          display_name: string
          market_type: string
          ticker: string
        }
        Insert: {
          api_symbol: string
          created_at?: string | null
          display_name: string
          market_type: string
          ticker: string
        }
        Update: {
          api_symbol?: string
          created_at?: string | null
          display_name?: string
          market_type?: string
          ticker?: string
        }
        Relationships: []
      }
      trader_performance: {
        Row: {
          avg_loss_pnl: number | null
          avg_win_pnl: number | null
          best_trade_pnl: number | null
          last_30d_losses: number | null
          last_30d_win_rate: number | null
          last_30d_wins: number | null
          losses: number | null
          ongoing: number | null
          total_pnl: number | null
          total_signals: number | null
          updated_at: string | null
          user_id: string
          win_rate: number | null
          wins: number | null
          worst_trade_pnl: number | null
        }
        Insert: {
          avg_loss_pnl?: number | null
          avg_win_pnl?: number | null
          best_trade_pnl?: number | null
          last_30d_losses?: number | null
          last_30d_win_rate?: number | null
          last_30d_wins?: number | null
          losses?: number | null
          ongoing?: number | null
          total_pnl?: number | null
          total_signals?: number | null
          updated_at?: string | null
          user_id: string
          win_rate?: number | null
          wins?: number | null
          worst_trade_pnl?: number | null
        }
        Update: {
          avg_loss_pnl?: number | null
          avg_win_pnl?: number | null
          best_trade_pnl?: number | null
          last_30d_losses?: number | null
          last_30d_win_rate?: number | null
          last_30d_wins?: number | null
          losses?: number | null
          ongoing?: number | null
          total_pnl?: number | null
          total_signals?: number | null
          updated_at?: string | null
          user_id?: string
          win_rate?: number | null
          wins?: number | null
          worst_trade_pnl?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trader_performance_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trader_performance_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "trader_performance_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "trader_performance_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      trades: {
        Row: {
          created_at: string | null
          direction: string | null
          entry_date: string
          entry_price: number
          exit_date: string | null
          exit_price: number | null
          id: string
          image_url: string | null
          is_public: boolean | null
          market_type: string | null
          notes: string | null
          pnl_amount: number | null
          pnl_percent: number | null
          quantity: number
          status: string | null
          ticker: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          direction?: string | null
          entry_date: string
          entry_price: number
          exit_date?: string | null
          exit_price?: number | null
          id?: string
          image_url?: string | null
          is_public?: boolean | null
          market_type?: string | null
          notes?: string | null
          pnl_amount?: number | null
          pnl_percent?: number | null
          quantity: number
          status?: string | null
          ticker: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          direction?: string | null
          entry_date?: string
          entry_price?: number
          exit_date?: string | null
          exit_price?: number | null
          id?: string
          image_url?: string | null
          is_public?: boolean | null
          market_type?: string | null
          notes?: string | null
          pnl_amount?: number | null
          pnl_percent?: number | null
          quantity?: number
          status?: string | null
          ticker?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_achievements_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_achievements_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_achievements_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_achievements_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      user_blocks: {
        Row: {
          blocked: string
          blocker: string
          created_at: string | null
        }
        Insert: {
          blocked: string
          blocker: string
          created_at?: string | null
        }
        Update: {
          blocked?: string
          blocker?: string
          created_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_blocks_blocked_fkey"
            columns: ["blocked"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_blocks_blocked_fkey"
            columns: ["blocked"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_blocks_blocked_fkey"
            columns: ["blocked"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_blocks_blocked_fkey"
            columns: ["blocked"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_blocks_blocker_fkey"
            columns: ["blocker"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_blocks_blocker_fkey"
            columns: ["blocker"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_blocks_blocker_fkey"
            columns: ["blocker"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_blocks_blocker_fkey"
            columns: ["blocker"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_suspensions: {
        Row: {
          created_at: string | null
          created_by: string | null
          reason: string | null
          until: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          reason?: string | null
          until?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          reason?: string | null
          until?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_suspensions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_suspensions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_suspensions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_suspensions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_suspensions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_suspensions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_suspensions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_suspensions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      user_xp: {
        Row: {
          created_at: string
          current_rank: string
          current_streak: number
          last_activity_date: string | null
          longest_streak: number
          rank_updated_at: string | null
          total_xp: number
          updated_at: string
          user_id: string
          weekly_xp: number
        }
        Insert: {
          created_at?: string
          current_rank?: string
          current_streak?: number
          last_activity_date?: string | null
          longest_streak?: number
          rank_updated_at?: string | null
          total_xp?: number
          updated_at?: string
          user_id: string
          weekly_xp?: number
        }
        Update: {
          created_at?: string
          current_rank?: string
          current_streak?: number
          last_activity_date?: string | null
          longest_streak?: number
          rank_updated_at?: string | null
          total_xp?: number
          updated_at?: string
          user_id?: string
          weekly_xp?: number
        }
        Relationships: [
          {
            foreignKeyName: "user_xp_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_xp_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_xp_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "user_xp_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      verification_requests: {
        Row: {
          additional_notes: string | null
          admin_notes: string | null
          created_at: string | null
          id: string
          image_urls: string[] | null
          mt4_account_number: string | null
          mt4_investor_password: string | null
          mt4_server: string | null
          myfxbook_url: string | null
          proof_type: string
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          additional_notes?: string | null
          admin_notes?: string | null
          created_at?: string | null
          id?: string
          image_urls?: string[] | null
          mt4_account_number?: string | null
          mt4_investor_password?: string | null
          mt4_server?: string | null
          myfxbook_url?: string | null
          proof_type: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          additional_notes?: string | null
          admin_notes?: string | null
          created_at?: string | null
          id?: string
          image_urls?: string[] | null
          mt4_account_number?: string | null
          mt4_investor_password?: string | null
          mt4_server?: string | null
          myfxbook_url?: string | null
          proof_type?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      votes: {
        Row: {
          created_at: string | null
          post_id: string
          user_id: string
          value: number
        }
        Insert: {
          created_at?: string | null
          post_id: string
          user_id: string
          value: number
        }
        Update: {
          created_at?: string | null
          post_id?: string
          user_id?: string
          value?: number
        }
        Relationships: []
      }
      xp_transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          id: string
          source_id: string | null
          source_type: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          source_id?: string | null
          source_type: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          source_id?: string | null
          source_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "xp_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "xp_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "xp_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "xp_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
    }
    Views: {
      challenge_live_leaderboard: {
        Row: {
          avatar_url: string | null
          challenge_id: string | null
          display_name: string | null
          handle: string | null
          rank: number | null
          score: number | null
          user_id: string | null
          verified_status: string | null
        }
        Relationships: [
          {
            foreignKeyName: "challenge_scores_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "challenges_with_status"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenge_scores_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      challenges_with_status: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          end_at: string | null
          id: string | null
          metric: string | null
          scope: string | null
          start_at: string | null
          status: string | null
          title: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_at?: string | null
          id?: string | null
          metric?: string | null
          scope?: string | null
          start_at?: string | null
          status?: never
          title?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          end_at?: string | null
          id?: string | null
          metric?: string | null
          scope?: string | null
          start_at?: string | null
          status?: never
          title?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_follow_counts"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_metrics_30d"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "challenges_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "user_reputation_metrics"
            referencedColumns: ["user_id"]
          },
        ]
      }
      kpi_new_users_7d: {
        Row: {
          c: number | null
          d: string | null
        }
        Relationships: []
      }
      kpi_posts_7d: {
        Row: {
          c: number | null
          d: string | null
        }
        Relationships: []
      }
      kpi_videos_7d: {
        Row: {
          c: number | null
          d: string | null
        }
        Relationships: []
      }
      user_follow_counts: {
        Row: {
          followers: number | null
          following: number | null
          user_id: string | null
        }
        Relationships: []
      }
      user_metrics_30d: {
        Row: {
          not_useful_count_30d: number | null
          useful_count_30d: number | null
          useful_rate_30d: number | null
          user_id: string | null
        }
        Relationships: []
      }
      user_reputation_metrics: {
        Row: {
          challenge_entries: number | null
          comments_given_30d: number | null
          follower_count: number | null
          last_30d_signals: number | null
          last_30d_win_rate: number | null
          posts_30d: number | null
          saves_received: number | null
          total_pnl: number | null
          total_votes_30d: number | null
          useful_rate_30d: number | null
          user_id: string | null
          videos_30d: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      award_xp: {
        Args: {
          p_amount: number
          p_description?: string
          p_source_id?: string
          p_source_type: string
          p_user_id: string
        }
        Returns: undefined
      }
      backfill_historical_xp: { Args: never; Returns: undefined }
      can_create_premium_content: {
        Args: { _user_id: string }
        Returns: boolean
      }
      check_and_unlock_achievements: {
        Args: { p_user_id: string }
        Returns: undefined
      }
      get_challenge_status: {
        Args: { end_time: string; start_time: string }
        Returns: string
      }
      get_trending_tickers_24h: {
        Args: never
        Returns: {
          comment_count: number
          last_updated: string
          not_useful_votes: number
          post_count: number
          score: number
          ticker: string
          unique_authors: number
          useful_votes: number
        }[]
      }
      has_min_rank: {
        Args: { _min_xp: number; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { user_id?: string }; Returns: boolean }
      is_challenge_admin: {
        Args: { _challenge_id: string; _user_id: string }
        Returns: boolean
      }
      is_conversation_member: {
        Args: { _conversation_id: string; _user_id: string }
        Returns: boolean
      }
      reset_weekly_xp: { Args: never; Returns: Json }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      group_type: "single" | "branch_server"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      group_type: ["single", "branch_server"],
    },
  },
} as const
