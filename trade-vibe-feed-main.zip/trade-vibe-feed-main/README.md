# TradeSocial - Trading Community Platform

A full-featured social trading platform built with React, TypeScript, and Supabase. Connect with traders, share signals, join challenges, and level up your trading journey.

## 🚀 Technology Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, shadcn/ui components
- **Backend**: Supabase (PostgreSQL, Auth, Edge Functions, Storage)
- **State Management**: TanStack Query (React Query)
- **Routing**: React Router v6

## ✨ Core Features

### 📈 Trading Feed
- Create and share trading signals with ticker symbols
- Support for multiple market types (Stocks, Crypto, Forex, Commodities)
- Trade direction indicators (Long/Short)
- Risk level badges
- Entry price, target, and stop-loss tracking
- Image attachments for chart analysis
- Useful/Not Useful voting system
- Comments and discussions

### 🏆 Challenges
- Create trading challenges with custom rules
- Join public or invite-only challenges
- Real-time leaderboards with scoring
- Challenge discussions and signal sharing
- Collaborator management for challenge admins
- Automatic XP rewards for participation and wins

### 📅 Events
- Create trading-related events (webinars, meetups, live sessions)
- Location and URL support
- Tag-based categorization
- Host profiles and RSVPs

### 🎓 Mentorship System
- **Mentorship Channels**: Create paid mentorship groups
- Subscription management with Stripe integration
- Mentor profiles with pricing and availability
- 1-on-1 and group mentoring options
- Subscriber tracking and limits

### 💬 Chat System
- **Direct Messages**: Private 1-on-1 conversations
- **Group Chats**: Create groups with multiple members
- **Servers**: Discord-like servers with multiple channels
- Chat requests with approval workflow
- File attachments (images, documents)
- Real-time messaging with Supabase Realtime
- Typing indicators
- Message editing and deletion

### 📊 Market Watch
- Live price feeds for stocks, crypto, forex
- Personal watchlists
- Price alerts with customizable conditions
- Market news feed
- Trending tickers based on community activity

### 🎬 Lifestyle Section
- TikTok-style vertical video feed
- Video uploads with compression
- Likes and comments
- Hashtag and ticker tagging
- Author profiles

## 🏅 Status & Gamification System

### XP (Experience Points)
Users earn XP through various activities:

| Activity | XP Reward |
|----------|-----------|
| Create a post | +5 XP |
| Receive "Useful" vote | +2 XP |
| Receive "Not Useful" vote | -1 XP |
| Create a comment | +1 XP |
| Create a challenge | +20 XP |
| Join a challenge | +10 XP |
| Win a challenge | +100 XP |
| Top 3 in challenge | +50 XP |
| Create an event | +15 XP |
| Post lifestyle video | +10 XP |
| Signal hits target | +25 XP |
| Signal hits stop loss | -5 XP |
| Create mentorship channel | +50 XP |
| Gain mentorship subscriber | +10 XP |

### Ranks
Progress through ranks based on total XP:

| Rank | XP Required | Icon |
|------|-------------|------|
| Rookie | 0 | 🌱 |
| Trader | 100 | 📈 |
| Pro | 500 | ⭐ |
| Elite | 2,000 | 💎 |
| Legend | 5,000 | 👑 |

### Achievements
Unlock achievements for milestones:
- **Content**: First post, 5/25/100 posts
- **Helpful**: 10/50/200 useful votes received
- **XP Milestones**: 100/500/2000/5000 XP
- **Streaks**: 3/7/30 day activity streaks
- **Challenges**: Join first challenge, participate in 5

### Leaderboards
- Weekly XP climbers
- All-time leaders
- Challenge-specific leaderboards

## 👤 User Features

### Profiles
- Custom display name and handle
- Avatar upload
- Bio and trading strategy tags
- Experience level indicator
- Market preferences
- Social links (Twitter, Discord, YouTube, etc.)
- Timezone settings
- Verification status badges

### Privacy Settings
- Public/Private profile toggle
- Show/Hide trading stats

### Following System
- Follow other traders
- Followers/Following counts
- Activity feed from followed users

## 🔧 Admin Panel

Access at `/admin` (requires admin privileges)

### Dashboard Overview
- Total users, posts, challenges metrics
- Active users statistics
- Recent activity feed

### User Management
- View all users
- Search and filter
- Ban/Unban users
- Shadow ban functionality
- Admin notes

### Content Moderation
- Review reported content
- Delete inappropriate posts
- Manage comments

### Challenge Management
- Create official challenges
- Edit/Delete challenges
- View participation stats

### Event Management
- Approve/Reject events
- Featured events

### Verification Requests
- Review trader verification applications
- Approve/Deny with notes

### Status & Gamification Config
- **Rank Configuration**: Customize rank thresholds
- **XP Rewards**: Adjust XP values for all activities
- **Achievements**: Create/Edit achievements
- **User XP**: View and manually adjust user XP
- **Analytics**: XP distribution charts

### Site Configuration
- Logo upload
- Feature flags
- Site-wide settings

### Audit Log
- Track all admin actions
- Searchable history

## 🗄️ Database Schema

### Core Tables
- `profiles` - User profiles and settings
- `posts` - Trading signals and content
- `comments` - Post comments
- `votes` - Useful/Not Useful votes
- `follows` - User follow relationships
- `saved_posts` - Bookmarked posts

### Challenges
- `challenges` - Challenge definitions
- `challenge_entries` - User participation
- `challenge_scores` - Leaderboard scores
- `challenge_signals` - Signals within challenges
- `challenge_discussions` - Challenge comments
- `challenge_collaborators` - Challenge admins

### Chat
- `conversations` - Chat threads (DM, group, server)
- `messages` - Chat messages
- `conversation_participants` - Thread members
- `group_members` - Group/Server membership
- `group_settings` - Group configuration
- `server_channels` - Server text channels
- `chat_requests` - DM request workflow

### Mentorship
- `mentorship_sessions` - Scheduled sessions
- `mentorship_subscriptions` - Channel subscriptions

### Market
- `market_prices` - Cached price data
- `market_news` - News articles
- `price_alerts` - User price alerts

### Lifestyle
- `lifestyle_videos` - Video content
- `lifestyle_likes` - Video likes
- `lifestyle_comments` - Video comments

### Status System
- `user_xp` - User XP and rank data
- `xp_transactions` - XP history log
- `achievements` - Achievement definitions
- `user_achievements` - Unlocked achievements

### Admin
- `admin_audit_log` - Admin action history
- `admin_notes` - Notes on users/content
- `reports` - User reports
- `feature_flags` - Feature toggles
- `site_settings` - Configuration values

## ⚡ Edge Functions

| Function | Purpose |
|----------|---------|
| `posts-api` | Post CRUD operations |
| `chat-api` | Chat message handling |
| `challenges-api` | Challenge management |
| `events-api` | Event operations |
| `lifestyle-api` | Video management |
| `market-data-api` | Price data fetching |
| `check-price-alerts` | Alert monitoring cron |
| `trending` | Calculate trending tickers |
| `reputation-cron` | Update reputation scores |
| `signal-tracker` | Track signal outcomes |
| `challenge-leaderboard-cron` | Update leaderboards |
| `reset-weekly-xp` | Weekly XP reset cron |

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or bun
- Supabase account

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd <project-name>

# Install dependencies
npm install

# Start development server
npm run dev
```

### Environment Variables

The project uses Supabase for backend. Required secrets (configured in Supabase):
- `SUPABASE_URL` - Supabase project URL
- `SUPABASE_ANON_KEY` - Supabase anonymous key
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (for edge functions)
- `TWELVEDATA_API_KEY` - Market data API (optional)

## 📱 Pages & Routes

| Route | Description |
|-------|-------------|
| `/` | Landing page |
| `/feed` | Main trading feed |
| `/post/:id` | Single post view |
| `/create-post` | Create new signal |
| `/profile` | Current user profile |
| `/profile/:handle` | User profile by handle |
| `/search` | User/Content search |
| `/challenges` | Challenges list |
| `/challenges/:id` | Challenge detail |
| `/create-challenge` | Create challenge |
| `/events` | Events calendar |
| `/events/:id` | Event detail |
| `/create-event` | Create event |
| `/mentorship` | Mentorship channels |
| `/market` | Market watch |
| `/lifestyle` | Video feed |
| `/lifestyle/upload` | Upload video |
| `/leaderboard` | XP leaderboard |
| `/status` | User status/XP page |
| `/chat` | Chat list |
| `/chat/:id` | Chat thread |
| `/servers` | Server list |
| `/servers/:id` | Server detail |
| `/settings/profile` | Profile settings |
| `/settings/privacy` | Privacy settings |
| `/admin/*` | Admin panel |

## 🔐 Authentication

- Email/Password authentication
- Password reset flow
- Email verification
- Protected routes for authenticated users
- Admin-only routes

## 📦 Key Dependencies

- `@supabase/supabase-js` - Supabase client
- `@tanstack/react-query` - Data fetching
- `react-router-dom` - Routing
- `lucide-react` - Icons
- `recharts` - Charts
- `date-fns` - Date utilities
- `zod` - Schema validation
- `react-hook-form` - Form handling
- `sonner` - Toast notifications
- `vaul` - Drawer component
- `@ffmpeg/ffmpeg` - Video compression

## 🎨 Design System

The project uses a custom design system with:
- CSS variables for theming (light/dark mode)
- Semantic color tokens
- Consistent spacing and typography
- Responsive breakpoints
- shadcn/ui component library

## 📄 License

This project is private and proprietary.

---

Built with [Lovable](https://lovable.dev)
