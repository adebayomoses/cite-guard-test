-- Fix infinite recursion in conversation_participants policies
-- Drop the problematic INSERT policy
DROP POLICY IF EXISTS "Users can join conversations" ON public.conversation_participants;

-- Create a simpler INSERT policy that doesn't cause recursion
-- Users can insert themselves as participants
CREATE POLICY "Users can join conversations"
ON public.conversation_participants
FOR INSERT
WITH CHECK (
  user_id = auth.uid()
);