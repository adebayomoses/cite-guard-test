-- Fix the remaining 3 security definer views
-- Must drop in order due to dependencies

-- First, drop user_reputation_metrics (depends on user_follow_counts)
DROP VIEW IF EXISTS public.user_reputation_metrics;

-- Then drop user_metrics_30d
DROP VIEW IF EXISTS public.user_metrics_30d;

-- Then drop user_follow_counts
DROP VIEW IF EXISTS public.user_follow_counts;

-- Recreate user_follow_counts with security invoker
CREATE VIEW public.user_follow_counts
WITH (security_invoker = true)
AS
SELECT p.id AS user_id,
    COALESCE(followers.count, 0::bigint) AS followers,
    COALESCE(following.count, 0::bigint) AS following
FROM profiles p
LEFT JOIN (
    SELECT target_id, count(*) AS count
    FROM follows
    GROUP BY target_id
) followers ON p.id = followers.target_id
LEFT JOIN (
    SELECT user_id, count(*) AS count
    FROM follows
    GROUP BY user_id
) following ON p.id = following.user_id;

-- Recreate user_metrics_30d with security invoker
CREATE VIEW public.user_metrics_30d
WITH (security_invoker = true)
AS
SELECT p.id AS user_id,
    CASE
        WHEN (COALESCE(sum(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0::bigint) + 
              COALESCE(sum(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0::bigint)) = 0 
        THEN 0::numeric
        ELSE round(
            (COALESCE(sum(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0::bigint)::numeric / 
             NULLIF((COALESCE(sum(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0::bigint) + 
                     COALESCE(sum(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0::bigint)), 0)::numeric) * 100, 
            1
        )
    END AS useful_rate_30d,
    COALESCE(sum(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0::bigint) AS useful_count_30d,
    COALESCE(sum(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0::bigint) AS not_useful_count_30d
FROM profiles p
LEFT JOIN votes v ON p.id = v.user_id AND v.created_at >= now() - interval '30 days'
GROUP BY p.id;

-- Recreate user_reputation_metrics with security invoker
CREATE VIEW public.user_reputation_metrics
WITH (security_invoker = true)
AS
SELECT p.id AS user_id,
    (COALESCE(tp.last_30d_wins, 0) + COALESCE(tp.last_30d_losses, 0))::bigint AS last_30d_signals,
    COALESCE(tp.last_30d_win_rate, 0::numeric) AS last_30d_win_rate,
    COALESCE(tp.total_pnl, 0::numeric) AS total_pnl,
    COALESCE(ufc.followers, 0::bigint) AS follower_count,
    COALESCE(c30.comment_count, 0::bigint) AS comments_given_30d,
    COALESCE(v30.total_votes, 0::bigint) AS total_votes_30d,
    COALESCE(v30.useful_rate, 0::numeric) AS useful_rate_30d,
    COALESCE(sp.save_count, 0::bigint) AS saves_received,
    COALESCE(p30.post_count, 0::bigint) AS posts_30d,
    COALESCE(vid30.video_count, 0::bigint) AS videos_30d,
    COALESCE(ce.entry_count, 0::bigint) AS challenge_entries
FROM profiles p
LEFT JOIN trader_performance tp ON p.id = tp.user_id
LEFT JOIN user_follow_counts ufc ON p.id = ufc.user_id
LEFT JOIN (
    SELECT author_id, count(*) AS comment_count
    FROM comments
    WHERE created_at >= now() - interval '30 days'
    GROUP BY author_id
) c30 ON p.id = c30.author_id
LEFT JOIN (
    SELECT po.author_id,
        count(*) AS total_votes,
        CASE 
            WHEN count(*) = 0 THEN 0::numeric
            ELSE round(
                (count(*) FILTER (WHERE v.value = 1)::numeric / 
                 NULLIF(count(*), 0)::numeric) * 100, 
                1
            )
        END AS useful_rate
    FROM posts po
    LEFT JOIN votes v ON po.id = v.post_id
    WHERE po.created_at >= now() - interval '30 days'
    GROUP BY po.author_id
) v30 ON p.id = v30.author_id
LEFT JOIN (
    SELECT sp.post_id, count(*) AS save_count
    FROM saved_posts sp
    GROUP BY sp.post_id
) sp ON EXISTS (SELECT 1 FROM posts po WHERE po.id = sp.post_id AND po.author_id = p.id)
LEFT JOIN (
    SELECT author_id, count(*) AS post_count
    FROM posts
    WHERE created_at >= now() - interval '30 days'
    GROUP BY author_id
) p30 ON p.id = p30.author_id
LEFT JOIN (
    SELECT author_id, count(*) AS video_count
    FROM lifestyle_videos
    WHERE created_at >= now() - interval '30 days'
    GROUP BY author_id
) vid30 ON p.id = vid30.author_id
LEFT JOIN (
    SELECT user_id, count(*) AS entry_count
    FROM challenge_entries
    GROUP BY user_id
) ce ON p.id = ce.user_id;

-- Fix the remaining function without search_path
CREATE OR REPLACE FUNCTION public.update_chat_request_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;