-- Phase 1: Create proper role-based access control

-- Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create user_roles table
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role app_role NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles (bypasses RLS to prevent recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS policies for user_roles table
-- Only admins can view all roles
CREATE POLICY "Admins can view all roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Users can view their own roles
CREATE POLICY "Users can view own roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Only admins can insert roles
CREATE POLICY "Only admins can insert roles"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update roles
CREATE POLICY "Only admins can update roles"
ON public.user_roles
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete roles
CREATE POLICY "Only admins can delete roles"
ON public.user_roles
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Migrate existing admins from profiles.is_admin to user_roles
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role
FROM public.profiles
WHERE is_admin = true
ON CONFLICT (user_id, role) DO NOTHING;

-- Update is_admin() function to use new role system
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(user_id, 'admin')
$$;

-- Phase 3: Fix security definer views - recreate with security invoker

-- Drop and recreate kpi_new_users_7d view
DROP VIEW IF EXISTS public.kpi_new_users_7d;
CREATE VIEW public.kpi_new_users_7d
WITH (security_invoker = true)
AS
SELECT date_trunc('day', created_at) AS d, COUNT(*) AS c
FROM public.profiles
WHERE created_at >= now() - interval '7 days'
GROUP BY date_trunc('day', created_at);

-- Drop and recreate kpi_posts_7d view
DROP VIEW IF EXISTS public.kpi_posts_7d;
CREATE VIEW public.kpi_posts_7d
WITH (security_invoker = true)
AS
SELECT date_trunc('day', created_at) AS d, COUNT(*) AS c
FROM public.posts
WHERE created_at >= now() - interval '7 days'
GROUP BY date_trunc('day', created_at);

-- Drop and recreate kpi_videos_7d view
DROP VIEW IF EXISTS public.kpi_videos_7d;
CREATE VIEW public.kpi_videos_7d
WITH (security_invoker = true)
AS
SELECT date_trunc('day', created_at) AS d, COUNT(*) AS c
FROM public.lifestyle_videos
WHERE created_at >= now() - interval '7 days'
GROUP BY date_trunc('day', created_at);

-- Drop and recreate challenges_with_status view
DROP VIEW IF EXISTS public.challenges_with_status;
CREATE VIEW public.challenges_with_status
WITH (security_invoker = true)
AS
SELECT 
  c.id,
  c.title,
  c.description,
  c.start_at,
  c.end_at,
  c.created_by,
  c.created_at,
  c.updated_at,
  c.metric,
  c.scope,
  public.get_challenge_status(c.start_at, c.end_at) AS status
FROM public.challenges c;

-- Drop and recreate challenge_live_leaderboard view
DROP VIEW IF EXISTS public.challenge_live_leaderboard;
CREATE VIEW public.challenge_live_leaderboard
WITH (security_invoker = true)
AS
SELECT 
  cs.challenge_id,
  cs.user_id,
  cs.score,
  cs.rank,
  p.handle,
  p.display_name,
  p.avatar_url,
  p.verified_status
FROM public.challenge_scores cs
JOIN public.profiles p ON p.id = cs.user_id
ORDER BY cs.rank;

-- Phase 4: Fix function search paths

-- Fix update_updated_at_column
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix update_video_like_count
CREATE OR REPLACE FUNCTION public.update_video_like_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.lifestyle_videos 
    SET like_count = like_count + 1 
    WHERE id = NEW.video_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.lifestyle_videos 
    SET like_count = like_count - 1 
    WHERE id = OLD.video_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

-- Fix update_video_comment_count
CREATE OR REPLACE FUNCTION public.update_video_comment_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.lifestyle_videos 
    SET comment_count = comment_count + 1 
    WHERE id = NEW.video_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.lifestyle_videos 
    SET comment_count = comment_count - 1 
    WHERE id = OLD.video_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;