-- Create a database function to reset weekly XP (can be called by edge function or scheduled externally)
CREATE OR REPLACE FUNCTION public.reset_weekly_xp()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_rows_updated integer;
BEGIN
  -- Reset weekly XP for all users
  UPDATE user_xp SET weekly_xp = 0;
  GET DIAGNOSTICS v_rows_updated = ROW_COUNT;
  
  RETURN jsonb_build_object(
    'success', true,
    'rows_updated', v_rows_updated,
    'timestamp', now()
  );
END;
$$;