-- Create group_settings table
CREATE TABLE public.group_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id uuid NOT NULL UNIQUE REFERENCES public.conversations(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  avatar_url text,
  created_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  allow_member_messages boolean DEFAULT true,
  allow_member_add boolean DEFAULT false,
  max_members integer DEFAULT 100,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create group_members table
CREATE TABLE public.group_members (
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  joined_at timestamp with time zone DEFAULT now(),
  added_by uuid REFERENCES public.profiles(id),
  PRIMARY KEY (conversation_id, user_id)
);

-- Enable RLS
ALTER TABLE public.group_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;

-- RLS policies for group_settings
CREATE POLICY "Users can view group settings for their groups"
ON public.group_settings FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.conversation_participants cp
    WHERE cp.conversation_id = group_settings.conversation_id
    AND cp.user_id = auth.uid()
  )
);

CREATE POLICY "Group admins can update settings"
ON public.group_settings FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.group_members gm
    WHERE gm.conversation_id = group_settings.conversation_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
);

CREATE POLICY "Users can create group settings"
ON public.group_settings FOR INSERT
WITH CHECK (created_by = auth.uid());

-- RLS policies for group_members
CREATE POLICY "Users can view members of their groups"
ON public.group_members FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.conversation_participants cp
    WHERE cp.conversation_id = group_members.conversation_id
    AND cp.user_id = auth.uid()
  )
);

CREATE POLICY "Admins can add members"
ON public.group_members FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.group_members gm
    WHERE gm.conversation_id = group_members.conversation_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
  OR
  EXISTS (
    SELECT 1 FROM public.group_settings gs
    WHERE gs.conversation_id = group_members.conversation_id
    AND gs.allow_member_add = true
    AND EXISTS (
      SELECT 1 FROM public.conversation_participants cp
      WHERE cp.conversation_id = group_members.conversation_id
      AND cp.user_id = auth.uid()
    )
  )
);

CREATE POLICY "Admins can remove members or users can leave"
ON public.group_members FOR DELETE
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.group_members gm
    WHERE gm.conversation_id = group_members.conversation_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
);

CREATE POLICY "Admins can update member roles"
ON public.group_members FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.group_members gm
    WHERE gm.conversation_id = group_members.conversation_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
);

-- Create trigger for updated_at
CREATE TRIGGER update_group_settings_updated_at
BEFORE UPDATE ON public.group_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_group_members_conversation ON public.group_members(conversation_id);
CREATE INDEX idx_group_members_user ON public.group_members(user_id);
CREATE INDEX idx_group_settings_conversation ON public.group_settings(conversation_id);