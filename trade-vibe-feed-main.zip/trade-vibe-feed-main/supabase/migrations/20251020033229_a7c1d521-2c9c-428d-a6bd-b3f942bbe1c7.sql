-- Add mentorship-related columns to group_settings
ALTER TABLE public.group_settings
  ADD COLUMN is_mentorship_channel boolean DEFAULT false,
  ADD COLUMN mentorship_type text CHECK (mentorship_type IN ('free', 'paid')),
  ADD COLUMN mentorship_price numeric(10,2),
  ADD COLUMN mentorship_billing_cycle text DEFAULT 'monthly' CHECK (mentorship_billing_cycle IN ('one_time', 'monthly', 'quarterly', 'yearly')),
  ADD COLUMN max_mentees integer,
  ADD COLUMN current_mentees integer DEFAULT 0;

-- Create index for faster queries
CREATE INDEX idx_group_settings_mentorship ON public.group_settings(is_mentorship_channel, mentorship_type)
  WHERE is_mentorship_channel = true;

-- Create mentorship_subscriptions table
CREATE TABLE public.mentorship_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  server_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired', 'payment_failed')),
  started_at timestamp with time zone NOT NULL DEFAULT now(),
  expires_at timestamp with time zone,
  last_payment_at timestamp with time zone,
  next_payment_at timestamp with time zone,
  stripe_subscription_id text,
  stripe_customer_id text,
  amount_paid numeric(10,2),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, server_id)
);

-- Enable RLS
ALTER TABLE public.mentorship_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for mentorship_subscriptions
CREATE POLICY "Users can view their own subscriptions"
  ON public.mentorship_subscriptions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Mentors can view their server subscriptions"
  ON public.mentorship_subscriptions
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.group_settings gs
      WHERE gs.conversation_id = server_id
        AND gs.created_by = auth.uid()
        AND gs.is_mentorship_channel = true
    )
  );

CREATE POLICY "Users can insert their own subscriptions"
  ON public.mentorship_subscriptions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Trigger to update current_mentees count
CREATE OR REPLACE FUNCTION update_mentee_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'active' THEN
    UPDATE group_settings
    SET current_mentees = current_mentees + 1
    WHERE conversation_id = NEW.server_id;
  ELSIF TG_OP = 'UPDATE' THEN
    IF OLD.status = 'active' AND NEW.status != 'active' THEN
      UPDATE group_settings
      SET current_mentees = GREATEST(0, current_mentees - 1)
      WHERE conversation_id = NEW.server_id;
    ELSIF OLD.status != 'active' AND NEW.status = 'active' THEN
      UPDATE group_settings
      SET current_mentees = current_mentees + 1
      WHERE conversation_id = NEW.server_id;
    END IF;
  ELSIF TG_OP = 'DELETE' AND OLD.status = 'active' THEN
    UPDATE group_settings
    SET current_mentees = GREATEST(0, current_mentees - 1)
    WHERE conversation_id = OLD.server_id;
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER on_subscription_change
  AFTER INSERT OR UPDATE OR DELETE ON public.mentorship_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_mentee_count();

-- Add check constraint for mentor requirements
ALTER TABLE public.profiles
  ADD CONSTRAINT mentor_reputation_check 
  CHECK (
    NOT is_mentor OR 
    (is_mentor AND reputation_last30 >= 70)
  );