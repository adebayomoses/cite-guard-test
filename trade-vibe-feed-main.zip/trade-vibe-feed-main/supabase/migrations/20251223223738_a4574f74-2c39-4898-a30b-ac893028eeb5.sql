-- Create verification_requests table
CREATE TABLE public.verification_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  proof_type TEXT NOT NULL, -- 'screenshot', 'myfxbook', 'mt4_password', 'statement'
  
  -- Proof data (depending on type)
  image_urls TEXT[] DEFAULT '{}',
  myfxbook_url TEXT,
  mt4_investor_password TEXT,
  mt4_server TEXT,
  mt4_account_number TEXT,
  additional_notes TEXT,
  
  -- Review fields
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  admin_notes TEXT,
  rejection_reason TEXT,
  
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.verification_requests ENABLE ROW LEVEL SECURITY;

-- Users can view their own requests
CREATE POLICY "Users can view own verification requests"
  ON public.verification_requests
  FOR SELECT
  USING (auth.uid() = user_id);

-- Users can create their own requests
CREATE POLICY "Users can create verification requests"
  ON public.verification_requests
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Admins can view all requests
CREATE POLICY "Admins can view all verification requests"
  ON public.verification_requests
  FOR SELECT
  USING (is_admin());

-- Admins can update requests (approve/reject)
CREATE POLICY "Admins can update verification requests"
  ON public.verification_requests
  FOR UPDATE
  USING (is_admin());

-- Create storage bucket for verification documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('verification-docs', 'verification-docs', false);

-- Users can upload their own verification docs
CREATE POLICY "Users can upload verification docs"
  ON storage.objects
  FOR INSERT
  WITH CHECK (
    bucket_id = 'verification-docs' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Users can view their own verification docs
CREATE POLICY "Users can view own verification docs"
  ON storage.objects
  FOR SELECT
  USING (
    bucket_id = 'verification-docs' 
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Admins can view all verification docs
CREATE POLICY "Admins can view all verification docs"
  ON storage.objects
  FOR SELECT
  USING (
    bucket_id = 'verification-docs' 
    AND is_admin()
  );

-- Trigger to update updated_at
CREATE TRIGGER update_verification_requests_updated_at
  BEFORE UPDATE ON public.verification_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();