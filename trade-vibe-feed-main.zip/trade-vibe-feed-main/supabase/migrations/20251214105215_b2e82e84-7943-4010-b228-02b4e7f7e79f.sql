
-- Insert default reputation settings
INSERT INTO site_settings (key, value) VALUES 
  ('reputation_trading_weight', '50'),
  ('reputation_engagement_weight', '20'),
  ('reputation_quality_weight', '20'),
  ('reputation_activity_weight', '10'),
  ('reputation_min_signals', '5'),
  ('reputation_min_votes', '10'),
  ('reputation_follower_cap', '100'),
  ('reputation_comments_cap', '30'),
  ('reputation_content_cap', '10'),
  ('reputation_challenges_cap', '3')
ON CONFLICT (key) DO NOTHING;
