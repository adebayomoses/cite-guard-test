-- Add market type and trade direction fields to posts table
ALTER TABLE public.posts 
ADD COLUMN market_type TEXT DEFAULT 'stocks',
ADD COLUMN trade_direction TEXT DEFAULT 'long';

-- Add check constraints for valid values
ALTER TABLE public.posts 
ADD CONSTRAINT posts_market_type_check 
CHECK (market_type IN ('stocks', 'crypto', 'forex', 'options', 'futures'));

ALTER TABLE public.posts 
ADD CONSTRAINT posts_trade_direction_check 
CHECK (trade_direction IN ('long', 'short', 'buy', 'sell'));