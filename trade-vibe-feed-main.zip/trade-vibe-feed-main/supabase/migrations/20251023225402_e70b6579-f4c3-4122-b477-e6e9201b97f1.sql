-- Insert initial ticker mappings for signal tracking
INSERT INTO ticker_mappings (ticker, api_symbol, market_type, display_name) VALUES
  -- Crypto (using CoinGecko IDs)
  ('BTC', 'bitcoin', 'crypto', 'Bitcoin'),
  ('ETH', 'ethereum', 'crypto', 'Ethereum'),
  ('SOL', 'solana', 'crypto', 'Solana'),
  ('USDT', 'tether', 'crypto', 'Tether'),
  ('BNB', 'binancecoin', 'crypto', 'Binance Coin'),
  ('BONK', 'bonk', 'crypto', 'Bonk'),
  ('DOGE', 'dogecoin', 'crypto', 'Dogecoin'),
  ('XRP', 'ripple', 'crypto', 'XRP'),
  ('ADA', 'cardano', 'crypto', 'Cardano'),
  ('AVAX', 'avalanche-2', 'crypto', 'Avalanche'),
  
  -- Popular stocks (using ticker symbols)
  ('AAPL', 'AAPL', 'stocks', 'Apple Inc'),
  ('MSFT', 'MSFT', 'stocks', 'Microsoft'),
  ('GOOGL', 'GOOGL', 'stocks', 'Alphabet Inc'),
  ('AMZN', 'AMZN', 'stocks', 'Amazon'),
  ('TSLA', 'TSLA', 'stocks', 'Tesla'),
  ('NVDA', 'NVDA', 'stocks', 'NVIDIA'),
  ('META', 'META', 'stocks', 'Meta Platforms'),
  ('NFLX', 'NFLX', 'stocks', 'Netflix'),
  
  -- Forex pairs
  ('EURUSD', 'EUR/USD', 'forex', 'Euro vs US Dollar'),
  ('GBPUSD', 'GBP/USD', 'forex', 'British Pound vs US Dollar'),
  ('USDJPY', 'USD/JPY', 'forex', 'US Dollar vs Japanese Yen'),
  ('AUDUSD', 'AUD/USD', 'forex', 'Australian Dollar vs US Dollar'),
  ('USDCAD', 'USD/CAD', 'forex', 'US Dollar vs Canadian Dollar')
ON CONFLICT (ticker) DO NOTHING;