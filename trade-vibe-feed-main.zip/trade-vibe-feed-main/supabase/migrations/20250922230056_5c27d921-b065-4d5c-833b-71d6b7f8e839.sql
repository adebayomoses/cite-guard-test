-- Create challenge signals table (only creator can post)
CREATE TABLE public.challenge_signals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  challenge_id UUID NOT NULL,
  author_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create challenge discussions table (participants can post)
CREATE TABLE public.challenge_discussions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  challenge_id UUID NOT NULL,
  author_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add risk_management field to challenges table
ALTER TABLE public.challenges 
ADD COLUMN risk_management TEXT;

-- Enable RLS on challenge_signals
ALTER TABLE public.challenge_signals ENABLE ROW LEVEL SECURITY;

-- Enable RLS on challenge_discussions  
ALTER TABLE public.challenge_discussions ENABLE ROW LEVEL SECURITY;

-- Policies for challenge_signals (viewable by everyone, only creator can post)
CREATE POLICY "Challenge signals are viewable by everyone" 
ON public.challenge_signals 
FOR SELECT 
USING (true);

CREATE POLICY "Only challenge creators can create signals" 
ON public.challenge_signals 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM challenges 
    WHERE challenges.id = challenge_id 
    AND challenges.created_by = auth.uid()
  )
);

CREATE POLICY "Only challenge creators can update their signals" 
ON public.challenge_signals 
FOR UPDATE 
USING (auth.uid() = author_id);

CREATE POLICY "Only challenge creators can delete their signals" 
ON public.challenge_signals 
FOR DELETE 
USING (auth.uid() = author_id);

-- Policies for challenge_discussions (viewable by everyone, participants can post)
CREATE POLICY "Challenge discussions are viewable by everyone" 
ON public.challenge_discussions 
FOR SELECT 
USING (true);

CREATE POLICY "Challenge participants can create discussions" 
ON public.challenge_discussions 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM challenge_entries 
    WHERE challenge_entries.challenge_id = challenge_discussions.challenge_id 
    AND challenge_entries.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own discussions" 
ON public.challenge_discussions 
FOR UPDATE 
USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own discussions" 
ON public.challenge_discussions 
FOR DELETE 
USING (auth.uid() = author_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_challenge_signals_updated_at
BEFORE UPDATE ON public.challenge_signals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_challenge_discussions_updated_at
BEFORE UPDATE ON public.challenge_discussions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();