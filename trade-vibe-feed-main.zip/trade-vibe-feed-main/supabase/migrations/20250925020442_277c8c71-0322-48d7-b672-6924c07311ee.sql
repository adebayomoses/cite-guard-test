-- Chat system tables
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean default false,
  created_at timestamptz default now()
);

-- Participants in conversations
create table if not exists conversation_participants (
  conversation_id uuid references conversations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  last_read_at timestamptz default now(),
  joined_at timestamptz default now(),
  primary key (conversation_id, user_id)
);

-- Messages in conversations
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  author_id uuid references profiles(id) on delete cascade,
  body text,
  attachment_path text,
  mime_type text,
  created_at timestamptz default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);

-- User blocks for safety
create table if not exists user_blocks (
  blocker uuid references profiles(id) on delete cascade,
  blocked uuid references profiles(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (blocker, blocked)
);

-- Message reports for moderation
create table if not exists message_reports (
  id uuid primary key default gen_random_uuid(),
  reporter uuid references profiles(id) on delete set null,
  message_id uuid references messages(id) on delete cascade,
  reason text,
  created_at timestamptz default now()
);

-- Indexes for performance
create index if not exists idx_messages_conv_time on messages(conversation_id, created_at desc);
create index if not exists idx_participants_user on conversation_participants(user_id);
create index if not exists idx_conversations_created on conversations(created_at desc);

-- Enable RLS on all tables
alter table conversations enable row level security;
alter table conversation_participants enable row level security;
alter table messages enable row level security;
alter table user_blocks enable row level security;
alter table message_reports enable row level security;

-- RLS Policies for conversations
create policy "Users can view their conversations" on conversations
for select using (exists (
  select 1 from conversation_participants cp
  where cp.conversation_id = conversations.id and cp.user_id = auth.uid()
));

create policy "Users can create conversations" on conversations 
for insert with check (true);

-- RLS Policies for participants
create policy "Users can view conversation participants" on conversation_participants
for select using (
  user_id = auth.uid() or
  exists (select 1 from conversation_participants cp where cp.conversation_id = conversation_participants.conversation_id and cp.user_id = auth.uid())
);

create policy "Users can join conversations" on conversation_participants
for insert with check (
  user_id = auth.uid() or
  exists (select 1 from conversation_participants cp where cp.conversation_id = conversation_participants.conversation_id and cp.user_id = auth.uid())
);

create policy "Users can update their participation" on conversation_participants
for update using (user_id = auth.uid());

-- RLS Policies for messages
create policy "Users can view messages in their conversations" on messages
for select using (exists (
  select 1 from conversation_participants cp
  where cp.conversation_id = messages.conversation_id and cp.user_id = auth.uid()
));

create policy "Users can send messages to their conversations" on messages
for insert with check (
  exists (
    select 1 from conversation_participants cp
    where cp.conversation_id = messages.conversation_id and cp.user_id = auth.uid()
  ) and author_id = auth.uid()
);

create policy "Users can update their own messages" on messages
for update using (author_id = auth.uid());

create policy "Users can delete their own messages" on messages
for delete using (author_id = auth.uid());

-- RLS Policies for blocks
create policy "Users can manage their own blocks" on user_blocks
for all using (blocker = auth.uid()) with check (blocker = auth.uid());

-- RLS Policies for reports
create policy "Users can create message reports" on message_reports
for insert with check (reporter = auth.uid());

create policy "Users can view their own reports" on message_reports
for select using (reporter = auth.uid());

-- Create storage bucket for chat attachments
insert into storage.buckets (id, name, public) 
values ('chat-attachments', 'chat-attachments', false)
on conflict (id) do nothing;

-- Storage policies for chat attachments
create policy "Users can view their conversation attachments" on storage.objects
for select using (
  bucket_id = 'chat-attachments' and
  exists (
    select 1 from messages m
    join conversation_participants cp on m.conversation_id = cp.conversation_id
    where m.attachment_path = name and cp.user_id = auth.uid()
  )
);

create policy "Users can upload to chat attachments" on storage.objects
for insert with check (
  bucket_id = 'chat-attachments' and
  auth.uid()::text = (storage.foldername(name))[1]
);

create policy "Users can update their chat attachments" on storage.objects
for update using (
  bucket_id = 'chat-attachments' and
  auth.uid()::text = (storage.foldername(name))[1]
);

create policy "Users can delete their chat attachments" on storage.objects
for delete using (
  bucket_id = 'chat-attachments' and
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Enable realtime for messages table
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table conversation_participants;