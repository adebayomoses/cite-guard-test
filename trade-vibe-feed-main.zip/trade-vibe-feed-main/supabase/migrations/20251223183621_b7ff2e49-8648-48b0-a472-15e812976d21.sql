-- Add new XP configuration settings for challenges, events, mentorship, and content

-- Content Creation XP
INSERT INTO public.site_settings (key, value) VALUES ('xp_challenge_created', '20') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_event_created', '15') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_lifestyle_video_posted', '10') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_comment_created', '1') ON CONFLICT (key) DO NOTHING;

-- Mentorship XP
INSERT INTO public.site_settings (key, value) VALUES ('xp_mentorship_channel_created', '50') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_mentorship_subscriber_gained', '10') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_mentorship_session_completed', '25') ON CONFLICT (key) DO NOTHING;

-- Challenge Rewards XP
INSERT INTO public.site_settings (key, value) VALUES ('xp_challenge_won', '100') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.site_settings (key, value) VALUES ('xp_challenge_top3', '50') ON CONFLICT (key) DO NOTHING;

-- Create trigger function for challenge creation XP
CREATE OR REPLACE FUNCTION public.on_challenge_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
BEGIN
  -- Get XP amount from settings, default to 20
  SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_challenge_created'), 20)
  INTO v_xp_amount;
  
  PERFORM public.award_xp(NEW.created_by, v_xp_amount, 'challenge_created', NEW.id, 'Created a challenge: ' || NEW.title);
  RETURN NEW;
END;
$$;

-- Create trigger for challenges
DROP TRIGGER IF EXISTS trigger_challenge_created_xp ON public.challenges;
CREATE TRIGGER trigger_challenge_created_xp
AFTER INSERT ON public.challenges
FOR EACH ROW
WHEN (NEW.created_by IS NOT NULL)
EXECUTE FUNCTION public.on_challenge_created_award_xp();

-- Create trigger function for event creation XP
CREATE OR REPLACE FUNCTION public.on_event_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
BEGIN
  -- Get XP amount from settings, default to 15
  SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_event_created'), 15)
  INTO v_xp_amount;
  
  PERFORM public.award_xp(NEW.host_id, v_xp_amount, 'event_created', NEW.id, 'Created an event: ' || NEW.title);
  RETURN NEW;
END;
$$;

-- Create trigger for events
DROP TRIGGER IF EXISTS trigger_event_created_xp ON public.events;
CREATE TRIGGER trigger_event_created_xp
AFTER INSERT ON public.events
FOR EACH ROW
WHEN (NEW.host_id IS NOT NULL)
EXECUTE FUNCTION public.on_event_created_award_xp();

-- Create trigger function for lifestyle video XP
CREATE OR REPLACE FUNCTION public.on_lifestyle_video_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
BEGIN
  -- Get XP amount from settings, default to 10
  SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_lifestyle_video_posted'), 10)
  INTO v_xp_amount;
  
  PERFORM public.award_xp(NEW.author_id, v_xp_amount, 'lifestyle_video_posted', NEW.id, 'Posted a lifestyle video');
  RETURN NEW;
END;
$$;

-- Create trigger for lifestyle videos
DROP TRIGGER IF EXISTS trigger_lifestyle_video_created_xp ON public.lifestyle_videos;
CREATE TRIGGER trigger_lifestyle_video_created_xp
AFTER INSERT ON public.lifestyle_videos
FOR EACH ROW
EXECUTE FUNCTION public.on_lifestyle_video_created_award_xp();

-- Create trigger function for comment creation XP
CREATE OR REPLACE FUNCTION public.on_comment_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
BEGIN
  -- Get XP amount from settings, default to 1
  SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_comment_created'), 1)
  INTO v_xp_amount;
  
  PERFORM public.award_xp(NEW.author_id, v_xp_amount, 'comment_created', NEW.id, 'Posted a comment');
  RETURN NEW;
END;
$$;

-- Create trigger for comments
DROP TRIGGER IF EXISTS trigger_comment_created_xp ON public.comments;
CREATE TRIGGER trigger_comment_created_xp
AFTER INSERT ON public.comments
FOR EACH ROW
EXECUTE FUNCTION public.on_comment_created_award_xp();

-- Create trigger function for mentorship channel creation XP
CREATE OR REPLACE FUNCTION public.on_mentorship_channel_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
BEGIN
  -- Only award XP if this is a mentorship channel
  IF NEW.is_mentorship_channel = true THEN
    -- Get XP amount from settings, default to 50
    SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_mentorship_channel_created'), 50)
    INTO v_xp_amount;
    
    PERFORM public.award_xp(NEW.created_by, v_xp_amount, 'mentorship_channel_created', NEW.id, 'Created mentorship channel: ' || NEW.name);
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger for mentorship channel creation
DROP TRIGGER IF EXISTS trigger_mentorship_channel_created_xp ON public.group_settings;
CREATE TRIGGER trigger_mentorship_channel_created_xp
AFTER INSERT ON public.group_settings
FOR EACH ROW
WHEN (NEW.is_mentorship_channel = true)
EXECUTE FUNCTION public.on_mentorship_channel_created_award_xp();

-- Create trigger function for mentorship subscriber gained XP
CREATE OR REPLACE FUNCTION public.on_mentorship_subscriber_gained_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_xp_amount integer;
  v_mentor_id uuid;
BEGIN
  -- Only award XP for new active subscriptions
  IF NEW.status = 'active' THEN
    -- Get the mentor (creator) of the mentorship channel
    SELECT gs.created_by INTO v_mentor_id
    FROM group_settings gs
    WHERE gs.conversation_id = NEW.server_id AND gs.is_mentorship_channel = true;
    
    IF v_mentor_id IS NOT NULL AND v_mentor_id != NEW.user_id THEN
      -- Get XP amount from settings, default to 10
      SELECT COALESCE((SELECT value::integer FROM site_settings WHERE key = 'xp_mentorship_subscriber_gained'), 10)
      INTO v_xp_amount;
      
      PERFORM public.award_xp(v_mentor_id, v_xp_amount, 'mentorship_subscriber_gained', NEW.id, 'Gained a new mentorship subscriber');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger for mentorship subscriptions
DROP TRIGGER IF EXISTS trigger_mentorship_subscriber_xp ON public.mentorship_subscriptions;
CREATE TRIGGER trigger_mentorship_subscriber_xp
AFTER INSERT ON public.mentorship_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.on_mentorship_subscriber_gained_award_xp();