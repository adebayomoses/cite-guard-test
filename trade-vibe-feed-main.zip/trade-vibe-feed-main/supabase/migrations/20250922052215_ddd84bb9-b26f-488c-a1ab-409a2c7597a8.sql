-- Fix security warnings by removing the view and using a function instead

-- Drop the materialized view and create a function that returns trending data
DROP MATERIALIZED VIEW IF EXISTS public.trending_tickers_24h CASCADE;
DROP FUNCTION IF EXISTS refresh_trending_tickers();

-- Create a function to get trending tickers (replaces the materialized view)
CREATE OR REPLACE FUNCTION get_trending_tickers_24h()
RETURNS TABLE (
  ticker TEXT,
  post_count BIGINT,
  unique_authors BIGINT,
  useful_votes BIGINT,
  not_useful_votes BIGINT,
  comment_count BIGINT,
  score NUMERIC,
  last_updated TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  RETURN QUERY
  WITH post_stats AS (
    SELECT 
      unnest(p.tickers) as ticker,
      COUNT(*) as post_count,
      COUNT(DISTINCT p.author_id) as unique_authors
    FROM public.posts p
    WHERE p.created_at >= now() - interval '24 hours'
    GROUP BY ticker
  ),
  vote_stats AS (
    SELECT 
      unnest(p.tickers) as ticker,
      COUNT(CASE WHEN v.value = 1 THEN 1 END) as useful_votes,
      COUNT(CASE WHEN v.value = -1 THEN 1 END) as not_useful_votes
    FROM public.posts p
    LEFT JOIN public.votes v ON p.id = v.post_id
    WHERE p.created_at >= now() - interval '24 hours'
    GROUP BY ticker
  ),
  comment_stats AS (
    SELECT 
      unnest(p.tickers) as ticker,
      COUNT(c.id) as comment_count
    FROM public.posts p
    LEFT JOIN public.comments c ON p.id = c.post_id
    WHERE p.created_at >= now() - interval '24 hours'
    GROUP BY ticker
  )
  SELECT 
    COALESCE(ps.ticker, vs.ticker, cs.ticker) as ticker,
    COALESCE(ps.post_count, 0) as post_count,
    COALESCE(ps.unique_authors, 0) as unique_authors,
    COALESCE(vs.useful_votes, 0) as useful_votes,
    COALESCE(vs.not_useful_votes, 0) as not_useful_votes,
    COALESCE(cs.comment_count, 0) as comment_count,
    (COALESCE(ps.post_count, 0) * 2 + 
     COALESCE(ps.unique_authors, 0) * 3 + 
     COALESCE(vs.useful_votes, 0) - COALESCE(vs.not_useful_votes, 0) + 
     COALESCE(cs.comment_count, 0) * 1.5) as score,
    now() as last_updated
  FROM post_stats ps
  FULL OUTER JOIN vote_stats vs ON ps.ticker = vs.ticker
  FULL OUTER JOIN comment_stats cs ON COALESCE(ps.ticker, vs.ticker) = cs.ticker
  WHERE COALESCE(ps.ticker, vs.ticker, cs.ticker) IS NOT NULL
  ORDER BY score DESC
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;