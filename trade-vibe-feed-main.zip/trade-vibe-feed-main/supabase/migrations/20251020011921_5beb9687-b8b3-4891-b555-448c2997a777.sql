-- Add Market Watch feature flag
INSERT INTO feature_flags (key, enabled) 
VALUES ('market_watch_enabled', true)
ON CONFLICT (key) DO NOTHING;

-- Create market_news table for storing/caching news articles
CREATE TABLE IF NOT EXISTS public.market_news (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  summary TEXT,
  url TEXT NOT NULL,
  source TEXT,
  published_at TIMESTAMPTZ NOT NULL,
  image_url TEXT,
  category TEXT CHECK (category IN ('forex', 'crypto', 'stocks', 'economy', 'general')),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_market_news_published ON public.market_news(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_market_news_category ON public.market_news(category);

-- Enable RLS
ALTER TABLE public.market_news ENABLE ROW LEVEL SECURITY;

-- Allow everyone to view market news
CREATE POLICY "Anyone can view market news"
  ON public.market_news
  FOR SELECT
  USING (true);

-- Create market_prices table for caching price data
CREATE TABLE IF NOT EXISTS public.market_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  current_price DECIMAL(20, 8) NOT NULL,
  price_change_24h DECIMAL(20, 8),
  percent_change_24h DECIMAL(10, 4),
  market_type TEXT NOT NULL CHECK (market_type IN ('crypto', 'forex', 'stocks')),
  last_updated TIMESTAMPTZ DEFAULT now(),
  UNIQUE(symbol)
);

CREATE INDEX IF NOT EXISTS idx_market_prices_symbol ON public.market_prices(symbol);
CREATE INDEX IF NOT EXISTS idx_market_prices_type ON public.market_prices(market_type);

-- Enable RLS
ALTER TABLE public.market_prices ENABLE ROW LEVEL SECURITY;

-- Allow everyone to view market prices
CREATE POLICY "Anyone can view market prices"
  ON public.market_prices
  FOR SELECT
  USING (true);