-- Create votes table
CREATE TABLE public.votes (
  user_id UUID NOT NULL,
  post_id UUID NOT NULL,
  value SMALLINT NOT NULL CHECK (value IN (-1, 1)),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (user_id, post_id)
);

-- Enable RLS on votes
ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;

-- Create policies for votes
CREATE POLICY "Users can view all votes" ON public.votes FOR SELECT USING (true);
CREATE POLICY "Users can insert their own votes" ON public.votes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own votes" ON public.votes FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own votes" ON public.votes FOR DELETE USING (auth.uid() = user_id);

-- Create post_scores table for materialized counts
CREATE TABLE public.post_scores (
  post_id UUID PRIMARY KEY,
  useful_count INTEGER DEFAULT 0,
  not_useful_count INTEGER DEFAULT 0,
  net_score INTEGER DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on post_scores
ALTER TABLE public.post_scores ENABLE ROW LEVEL SECURITY;

-- Create policy for post_scores (readable by everyone)
CREATE POLICY "Post scores are viewable by everyone" ON public.post_scores FOR SELECT USING (true);

-- Create function to update post scores
CREATE OR REPLACE FUNCTION public.update_post_scores()
RETURNS TRIGGER AS $$
BEGIN
  -- Handle INSERT and UPDATE
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    INSERT INTO public.post_scores (post_id, useful_count, not_useful_count, net_score, updated_at)
    VALUES (
      COALESCE(NEW.post_id, OLD.post_id),
      (SELECT COUNT(*) FROM public.votes WHERE post_id = COALESCE(NEW.post_id, OLD.post_id) AND value = 1),
      (SELECT COUNT(*) FROM public.votes WHERE post_id = COALESCE(NEW.post_id, OLD.post_id) AND value = -1),
      (SELECT COUNT(*) FROM public.votes WHERE post_id = COALESCE(NEW.post_id, OLD.post_id) AND value = 1) - 
      (SELECT COUNT(*) FROM public.votes WHERE post_id = COALESCE(NEW.post_id, OLD.post_id) AND value = -1),
      NOW()
    )
    ON CONFLICT (post_id) DO UPDATE SET
      useful_count = EXCLUDED.useful_count,
      not_useful_count = EXCLUDED.not_useful_count,
      net_score = EXCLUDED.net_score,
      updated_at = NOW();
    
    RETURN COALESCE(NEW, OLD);
  END IF;

  -- Handle DELETE
  IF TG_OP = 'DELETE' THEN
    INSERT INTO public.post_scores (post_id, useful_count, not_useful_count, net_score, updated_at)
    VALUES (
      OLD.post_id,
      (SELECT COUNT(*) FROM public.votes WHERE post_id = OLD.post_id AND value = 1),
      (SELECT COUNT(*) FROM public.votes WHERE post_id = OLD.post_id AND value = -1),
      (SELECT COUNT(*) FROM public.votes WHERE post_id = OLD.post_id AND value = 1) - 
      (SELECT COUNT(*) FROM public.votes WHERE post_id = OLD.post_id AND value = -1),
      NOW()
    )
    ON CONFLICT (post_id) DO UPDATE SET
      useful_count = EXCLUDED.useful_count,
      not_useful_count = EXCLUDED.not_useful_count,
      net_score = EXCLUDED.net_score,
      updated_at = NOW();
    
    RETURN OLD;
  END IF;

  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for post scores
CREATE TRIGGER update_post_scores_trigger
  AFTER INSERT OR UPDATE OR DELETE ON public.votes
  FOR EACH ROW EXECUTE FUNCTION public.update_post_scores();

-- Create user metrics view for 30-day reputation
CREATE OR REPLACE VIEW public.user_metrics_30d AS
SELECT 
  p.id as user_id,
  CASE 
    WHEN COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) + COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0) = 0 
    THEN 0
    ELSE ROUND(
      (COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0)::numeric / 
       NULLIF(COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) + COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0), 0)) * 100, 
      1
    )
  END as useful_rate_30d,
  COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) as useful_count_30d,
  COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0) as not_useful_count_30d
FROM public.profiles p
LEFT JOIN public.votes v ON p.id = v.user_id AND v.created_at >= NOW() - INTERVAL '30 days'
GROUP BY p.id;

-- Create saved_posts table
CREATE TABLE public.saved_posts (
  user_id UUID NOT NULL,
  post_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  PRIMARY KEY (user_id, post_id)
);

-- Enable RLS on saved_posts
ALTER TABLE public.saved_posts ENABLE ROW LEVEL SECURITY;

-- Create policies for saved_posts
CREATE POLICY "Users can view their own saved posts" ON public.saved_posts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own saved posts" ON public.saved_posts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own saved posts" ON public.saved_posts FOR DELETE USING (auth.uid() = user_id);

-- Create comments table
CREATE TABLE public.comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID NOT NULL,
  author_id UUID NOT NULL,
  text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on comments
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- Create policies for comments
CREATE POLICY "Comments are viewable by everyone" ON public.comments FOR SELECT USING (true);
CREATE POLICY "Users can insert their own comments" ON public.comments FOR INSERT WITH CHECK (auth.uid() = author_id);
CREATE POLICY "Users can update their own comments" ON public.comments FOR UPDATE USING (auth.uid() = author_id);
CREATE POLICY "Users can delete their own comments" ON public.comments FOR DELETE USING (auth.uid() = author_id);

-- Add trigger for comments updated_at
CREATE TRIGGER update_comments_updated_at
  BEFORE UPDATE ON public.comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for comments
ALTER TABLE public.comments REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.comments;

-- Enable realtime for votes
ALTER TABLE public.votes REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.votes;