-- Create signal_tracking table
CREATE TABLE signal_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  signal_type text NOT NULL CHECK (signal_type IN ('post', 'challenge_signal')),
  signal_id uuid NOT NULL,
  author_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  ticker text NOT NULL,
  entry_price numeric NOT NULL,
  stop_loss numeric,
  target_price numeric,
  trade_direction text NOT NULL CHECK (trade_direction IN ('long', 'short')),
  market_type text NOT NULL,
  status text NOT NULL DEFAULT 'ongoing' CHECK (status IN ('ongoing', 'win', 'loss', 'expired')),
  current_price numeric,
  pnl_percentage numeric,
  closed_at timestamp with time zone,
  expires_at timestamp with time zone,
  last_checked_at timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Indexes for performance
CREATE INDEX idx_signal_tracking_status ON signal_tracking(status);
CREATE INDEX idx_signal_tracking_author ON signal_tracking(author_id);
CREATE INDEX idx_signal_tracking_signal ON signal_tracking(signal_type, signal_id);
CREATE INDEX idx_signal_tracking_ticker ON signal_tracking(ticker);

-- RLS Policies
ALTER TABLE signal_tracking ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Signal tracking is viewable by everyone"
  ON signal_tracking FOR SELECT
  USING (true);

-- Create trader_performance table
CREATE TABLE trader_performance (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  total_signals integer DEFAULT 0,
  wins integer DEFAULT 0,
  losses integer DEFAULT 0,
  ongoing integer DEFAULT 0,
  win_rate numeric DEFAULT 0,
  avg_win_pnl numeric DEFAULT 0,
  avg_loss_pnl numeric DEFAULT 0,
  best_trade_pnl numeric DEFAULT 0,
  worst_trade_pnl numeric DEFAULT 0,
  total_pnl numeric DEFAULT 0,
  last_30d_wins integer DEFAULT 0,
  last_30d_losses integer DEFAULT 0,
  last_30d_win_rate numeric DEFAULT 0,
  updated_at timestamp with time zone DEFAULT now()
);

-- RLS Policy
ALTER TABLE trader_performance ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Trader performance is viewable by everyone"
  ON trader_performance FOR SELECT
  USING (true);

-- Create ticker_mappings table for symbol conversion
CREATE TABLE ticker_mappings (
  ticker text PRIMARY KEY,
  api_symbol text NOT NULL,
  market_type text NOT NULL,
  display_name text NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

-- Insert common ticker mappings
INSERT INTO ticker_mappings (ticker, api_symbol, market_type, display_name) VALUES
  ('BTC', 'bitcoin', 'crypto', 'Bitcoin'),
  ('ETH', 'ethereum', 'crypto', 'Ethereum'),
  ('SOL', 'solana', 'crypto', 'Solana'),
  ('BNB', 'binancecoin', 'crypto', 'Binance Coin'),
  ('XRP', 'ripple', 'crypto', 'XRP'),
  ('ADA', 'cardano', 'crypto', 'Cardano'),
  ('DOGE', 'dogecoin', 'crypto', 'Dogecoin'),
  ('MATIC', 'matic-network', 'crypto', 'Polygon'),
  ('DOT', 'polkadot', 'crypto', 'Polkadot'),
  ('AVAX', 'avalanche-2', 'crypto', 'Avalanche');

-- RLS for ticker_mappings
ALTER TABLE ticker_mappings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Ticker mappings are viewable by everyone"
  ON ticker_mappings FOR SELECT
  USING (true);

-- Trigger to update updated_at
CREATE TRIGGER update_signal_tracking_updated_at
  BEFORE UPDATE ON signal_tracking
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trader_performance_updated_at
  BEFORE UPDATE ON trader_performance
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();