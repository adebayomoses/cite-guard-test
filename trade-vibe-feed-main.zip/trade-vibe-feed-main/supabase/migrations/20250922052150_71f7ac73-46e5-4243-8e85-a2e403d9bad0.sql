-- Fix security warnings by adding proper policies for materialized view

-- First, let's restrict access to the materialized view to authenticated users only
CREATE POLICY "Trending tickers are viewable by everyone" 
ON public.trending_tickers_24h 
FOR SELECT 
USING (true);

-- Update the refresh function to have proper security
DROP FUNCTION IF EXISTS refresh_trending_tickers();

CREATE OR REPLACE FUNCTION refresh_trending_tickers()
RETURNS void AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY public.trending_tickers_24h;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create a cron job to refresh trending data every 5 minutes
-- First enable pg_cron extension
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the refresh job
SELECT cron.schedule(
  'refresh-trending-tickers',
  '*/5 * * * *', -- every 5 minutes
  'SELECT refresh_trending_tickers();'
);