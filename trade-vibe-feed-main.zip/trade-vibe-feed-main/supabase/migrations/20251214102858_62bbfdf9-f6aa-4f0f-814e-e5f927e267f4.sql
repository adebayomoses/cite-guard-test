-- Create user_reputation_metrics view for multi-factor reputation calculation
CREATE OR REPLACE VIEW public.user_reputation_metrics AS
SELECT 
  p.id AS user_id,
  
  -- Trading Performance (from trader_performance table)
  COALESCE(tp.last_30d_wins, 0) + COALESCE(tp.last_30d_losses, 0) AS last_30d_signals,
  COALESCE(tp.last_30d_win_rate, 0) AS last_30d_win_rate,
  COALESCE(tp.total_pnl, 0) AS total_pnl,
  
  -- Community Engagement (followers from user_follow_counts view, comments given)
  COALESCE(ufc.followers, 0) AS follower_count,
  COALESCE(c30.comment_count, 0) AS comments_given_30d,
  
  -- Content Quality (votes received on user's posts in last 30 days)
  COALESCE(v30.total_votes, 0) AS total_votes_30d,
  COALESCE(v30.useful_rate, 0) AS useful_rate_30d,
  COALESCE(sp.save_count, 0) AS saves_received,
  
  -- Consistency & Activity
  COALESCE(p30.post_count, 0) AS posts_30d,
  COALESCE(vid30.video_count, 0) AS videos_30d,
  COALESCE(ce.entry_count, 0) AS challenge_entries

FROM public.profiles p

-- Trading performance
LEFT JOIN public.trader_performance tp ON p.id = tp.user_id

-- Follower count from existing view
LEFT JOIN public.user_follow_counts ufc ON p.id = ufc.user_id

-- Comments given in last 30 days
LEFT JOIN (
  SELECT author_id, COUNT(*) AS comment_count
  FROM public.comments
  WHERE created_at >= NOW() - INTERVAL '30 days'
  GROUP BY author_id
) c30 ON p.id = c30.author_id

-- Votes received on user's posts in last 30 days
LEFT JOIN (
  SELECT 
    po.author_id,
    COUNT(*) AS total_votes,
    CASE 
      WHEN COUNT(*) > 0 THEN (COUNT(*) FILTER (WHERE v.value = 1)::numeric / COUNT(*)::numeric) * 100
      ELSE 0 
    END AS useful_rate
  FROM public.posts po
  JOIN public.votes v ON po.id = v.post_id
  WHERE v.created_at >= NOW() - INTERVAL '30 days'
  GROUP BY po.author_id
) v30 ON p.id = v30.author_id

-- Saves received on user's posts
LEFT JOIN (
  SELECT po.author_id, COUNT(*) AS save_count
  FROM public.posts po
  JOIN public.saved_posts sp ON po.id = sp.post_id
  GROUP BY po.author_id
) sp ON p.id = sp.author_id

-- Posts in last 30 days
LEFT JOIN (
  SELECT author_id, COUNT(*) AS post_count
  FROM public.posts
  WHERE created_at >= NOW() - INTERVAL '30 days'
  GROUP BY author_id
) p30 ON p.id = p30.author_id

-- Videos in last 30 days
LEFT JOIN (
  SELECT author_id, COUNT(*) AS video_count
  FROM public.lifestyle_videos
  WHERE created_at >= NOW() - INTERVAL '30 days'
  GROUP BY author_id
) vid30 ON p.id = vid30.author_id

-- Challenge entries (total, not just 30 days)
LEFT JOIN (
  SELECT user_id, COUNT(*) AS entry_count
  FROM public.challenge_entries
  GROUP BY user_id
) ce ON p.id = ce.user_id;