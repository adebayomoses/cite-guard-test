-- Add professional trading fields to challenge_signals table
ALTER TABLE public.challenge_signals
ADD COLUMN image_url text,
ADD COLUMN market_type text DEFAULT 'stocks' CHECK (market_type IN ('stocks', 'crypto', 'forex', 'options', 'futures')),
ADD COLUMN trade_direction text DEFAULT 'long' CHECK (trade_direction IN ('long', 'short')),
ADD COLUMN risk_level text DEFAULT 'medium_risk' CHECK (risk_level IN ('low_risk', 'medium_risk', 'high_risk')),
ADD COLUMN timeframe text,
ADD COLUMN entry_price numeric,
ADD COLUMN stop_loss numeric,
ADD COLUMN target_price numeric;