-- Create follows table for user-to-user following relationships
CREATE TABLE IF NOT EXISTS public.follows (
  user_id UUID NOT NULL,
  target_id UUID NOT NULL, 
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, target_id)
);

-- Enable RLS on follows table
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

-- RLS policies for follows table
CREATE POLICY "Users can view all follows" 
ON public.follows 
FOR SELECT 
USING (true);

CREATE POLICY "Users can insert their own follows" 
ON public.follows 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own follows" 
ON public.follows 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create view for user follow counts
CREATE OR REPLACE VIEW public.user_follow_counts AS
SELECT 
  p.id as user_id,
  COALESCE(followers.count, 0) as followers,
  COALESCE(following.count, 0) as following
FROM public.profiles p
LEFT JOIN (
  SELECT target_id, COUNT(*) as count
  FROM public.follows
  GROUP BY target_id
) followers ON p.id = followers.target_id
LEFT JOIN (
  SELECT user_id, COUNT(*) as count  
  FROM public.follows
  GROUP BY user_id
) following ON p.id = following.user_id;

-- Update user_metrics_30d view to ensure it has all needed columns
CREATE OR REPLACE VIEW public.user_metrics_30d AS
SELECT 
  p.id as user_id,
  COALESCE(useful_votes.count, 0) as useful_count_30d,
  COALESCE(not_useful_votes.count, 0) as not_useful_count_30d,
  CASE 
    WHEN (COALESCE(useful_votes.count, 0) + COALESCE(not_useful_votes.count, 0)) = 0 THEN 0
    ELSE ROUND(
      (COALESCE(useful_votes.count, 0)::numeric / 
       (COALESCE(useful_votes.count, 0) + COALESCE(not_useful_votes.count, 0))::numeric) * 100,
      1
    )
  END as useful_rate_30d
FROM public.profiles p
LEFT JOIN (
  SELECT 
    v.user_id,
    COUNT(*) as count
  FROM public.votes v
  WHERE v.value = 1 
    AND v.created_at >= now() - interval '30 days'
  GROUP BY v.user_id
) useful_votes ON p.id = useful_votes.user_id
LEFT JOIN (
  SELECT 
    v.user_id,
    COUNT(*) as count
  FROM public.votes v  
  WHERE v.value = -1
    AND v.created_at >= now() - interval '30 days'
  GROUP BY v.user_id
) not_useful_votes ON p.id = not_useful_votes.user_id;