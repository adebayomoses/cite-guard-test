-- Insert default premium_content_min_rank setting if it doesn't exist
INSERT INTO site_settings (key, value, updated_at)
VALUES ('premium_content_min_rank', '"pro"', now())
ON CONFLICT (key) DO NOTHING;