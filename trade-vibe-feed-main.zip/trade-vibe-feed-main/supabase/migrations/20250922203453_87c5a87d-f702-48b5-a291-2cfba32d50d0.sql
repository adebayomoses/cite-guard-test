-- RBAC: mark admins
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_admin boolean DEFAULT false;

-- Feature flags & settings
CREATE TABLE IF NOT EXISTS feature_flags (
  key text PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

INSERT INTO feature_flags(key, enabled) VALUES
  ('lifestyle_enabled', true),
  ('trending_tab', true),
  ('events_enabled', true)
ON CONFLICT (key) DO NOTHING;

CREATE TABLE IF NOT EXISTS site_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

-- Insert default site settings
INSERT INTO site_settings(key, value) VALUES
  ('support_email', '"support@example.com"'),
  ('site_disclaimer', '"Trading involves risk. Always do your own research."'),
  ('brand_name', '"TradingHub"')
ON CONFLICT (key) DO NOTHING;

-- Reports system
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter uuid REFERENCES profiles(id) ON DELETE SET NULL,
  target_type text CHECK (target_type IN ('post','video','comment','profile')) NOT NULL,
  target_id uuid NOT NULL,
  reason text,
  status text CHECK (status IN ('open','dismissed','actioned')) DEFAULT 'open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Admin notes for users and content
CREATE TABLE IF NOT EXISTS admin_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type text CHECK (subject_type IN ('user','post','video','comment','challenge','event')) NOT NULL,
  subject_id uuid NOT NULL,
  author uuid REFERENCES profiles(id) ON DELETE SET NULL,
  note text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- User enforcement
CREATE TABLE IF NOT EXISTS user_suspensions (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  reason text,
  until timestamptz,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS shadow_banned boolean DEFAULT false;

-- Admin audit trail
CREATE TABLE IF NOT EXISTS admin_audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  admin_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  action text NOT NULL,
  subject_type text NOT NULL,
  subject_id uuid,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Views for KPIs
CREATE OR REPLACE VIEW kpi_new_users_7d AS
  SELECT date_trunc('day', created_at) AS d, count(*) AS c 
  FROM profiles
  WHERE created_at >= now() - interval '7 days' 
  GROUP BY 1 ORDER BY 1;

CREATE OR REPLACE VIEW kpi_posts_7d AS
  SELECT date_trunc('day', created_at) AS d, count(*) AS c 
  FROM posts
  WHERE created_at >= now() - interval '7 days' 
  GROUP BY 1 ORDER BY 1;

CREATE OR REPLACE VIEW kpi_videos_7d AS
  SELECT date_trunc('day', created_at) AS d, count(*) AS c 
  FROM lifestyle_videos
  WHERE created_at >= now() - interval '7 days' 
  GROUP BY 1 ORDER BY 1;

-- RLS policies
ALTER TABLE feature_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Anyone can view feature flags" ON feature_flags FOR SELECT USING (true);
CREATE POLICY IF NOT EXISTS "Only admins can modify feature flags" ON feature_flags 
  FOR ALL USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Anyone can view site settings" ON site_settings FOR SELECT USING (true);
CREATE POLICY IF NOT EXISTS "Only admins can modify site settings" ON site_settings 
  FOR ALL USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Only admins can view reports" ON reports 
  FOR SELECT USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));
CREATE POLICY IF NOT EXISTS "Only admins can manage reports" ON reports 
  FOR ALL USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

ALTER TABLE admin_notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Only admins can manage admin notes" ON admin_notes 
  FOR ALL USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

ALTER TABLE user_suspensions ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Only admins can manage user suspensions" ON user_suspensions 
  FOR ALL USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

ALTER TABLE admin_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Only admins can view audit log" ON admin_audit_log 
  FOR SELECT USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.is_admin = true));

-- Function to check if user is admin (for use in RLS)
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid DEFAULT auth.uid())
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM profiles WHERE id = user_id AND is_admin = true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- Triggers to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_feature_flags_updated_at
  BEFORE UPDATE ON feature_flags
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON site_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_reports_updated_at
  BEFORE UPDATE ON reports
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();