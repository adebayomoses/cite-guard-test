-- Insert sample challenges for testing
INSERT INTO public.challenges (title, description, scope, metric, start_at, end_at, created_by) VALUES
(
  'Q4 Crypto Trading Championship', 
  'Show off your cryptocurrency trading skills in this quarterly competition. Best useful rate wins!',
  'crypto',
  'useful_rate',
  now() - interval '1 day',
  now() + interval '6 days',
  (SELECT id FROM public.profiles LIMIT 1)
),
(
  'January Stock Picking Contest',
  'Pick the best stock trades for January. Net votes determine the winner.',
  'stocks', 
  'net_votes',
  now() + interval '2 days',
  now() + interval '32 days',
  (SELECT id FROM public.profiles LIMIT 1)
),
(
  'Forex Masters December',
  'Forex trading consistency challenge - show your discipline and accuracy.',
  'forex',
  'consistency', 
  now() - interval '10 days',
  now() - interval '1 day',
  (SELECT id FROM public.profiles LIMIT 1)
);

-- Insert sample events
INSERT INTO public.events (title, description, start_at, end_at, location, url, host_id, tags) VALUES
(
  'Weekly Market Outlook Webinar',
  'Join us for our weekly analysis of market trends and upcoming opportunities.',
  now() + interval '2 days',
  now() + interval '2 days' + interval '1 hour',
  'online',
  'https://zoom.us/j/example',
  (SELECT id FROM public.profiles LIMIT 1),
  ARRAY['webinar', 'market-analysis', 'weekly']
),
(
  'Options Trading Masterclass',
  'Deep dive into advanced options strategies with live examples.',
  now() + interval '5 days',
  now() + interval '5 days' + interval '2 hours',
  'online', 
  'https://meet.google.com/example',
  (SELECT id FROM public.profiles LIMIT 1),
  ARRAY['options', 'masterclass', 'education']
),
(
  'Crypto Technical Analysis Workshop',
  'Learn to read crypto charts like a pro with hands-on exercises.',
  now() + interval '7 days',
  now() + interval '7 days' + interval '90 minutes',
  'online',
  'https://discord.gg/example',
  (SELECT id FROM public.profiles LIMIT 1), 
  ARRAY['crypto', 'technical-analysis', 'workshop']
);