-- Set up cron job to update challenge leaderboards every 5 minutes
-- First, enable the pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the leaderboard update job to run every 5 minutes
SELECT cron.schedule(
  'update-challenge-leaderboards',
  '*/5 * * * *', -- Every 5 minutes
  $$
  select
    net.http_post(
        url:='https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/challenge-leaderboard-cron',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp5b25qeHZmanNoa2pkdGp3Y3FvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1MTI2NTYsImV4cCI6MjA3NDA4ODY1Nn0.jJLyCVuoDQUxr_lA3BPDGVza_zwAeVUFILAz0S1pR34"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);