-- Create reputation snapshots table for sparkline data
CREATE TABLE public.reputation_snapshots (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reputation numeric NOT NULL DEFAULT 0,
  snapshot_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id, snapshot_date)
);

-- Enable RLS
ALTER TABLE public.reputation_snapshots ENABLE ROW LEVEL SECURITY;

-- Anyone can view reputation snapshots (public data)
CREATE POLICY "Anyone can view reputation snapshots"
  ON public.reputation_snapshots
  FOR SELECT
  USING (true);

-- Create index for efficient queries
CREATE INDEX idx_reputation_snapshots_user_date 
  ON public.reputation_snapshots(user_id, snapshot_date DESC);