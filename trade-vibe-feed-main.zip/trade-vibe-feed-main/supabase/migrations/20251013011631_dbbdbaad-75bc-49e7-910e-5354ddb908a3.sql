-- Phase 1: Add group_type enum and update conversations table
CREATE TYPE group_type AS ENUM ('single', 'branch_server');

ALTER TABLE conversations 
ADD COLUMN group_type group_type DEFAULT 'single',
ADD COLUMN parent_server_id uuid REFERENCES conversations(id) ON DELETE CASCADE;

CREATE INDEX idx_conversations_parent_server ON conversations(parent_server_id);
CREATE INDEX idx_conversations_group_type ON conversations(group_type);

-- Phase 2: Create server_channels table
CREATE TABLE server_channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  channel_conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  channel_order integer DEFAULT 0,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(server_id, channel_conversation_id)
);

ALTER TABLE server_channels ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view channels in their servers"
ON server_channels FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM conversation_participants cp
    WHERE cp.conversation_id = server_channels.server_id
    AND cp.user_id = auth.uid()
  )
);

CREATE POLICY "Server admins can manage channels"
ON server_channels FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM group_members gm
    WHERE gm.conversation_id = server_channels.server_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM group_members gm
    WHERE gm.conversation_id = server_channels.server_id
    AND gm.user_id = auth.uid()
    AND gm.role = 'admin'
  )
);

CREATE INDEX idx_server_channels_server ON server_channels(server_id);
CREATE INDEX idx_server_channels_order ON server_channels(server_id, channel_order);

-- Phase 3: Update group_settings for server features
ALTER TABLE group_settings
ADD COLUMN allow_public_join boolean DEFAULT false,
ADD COLUMN require_approval boolean DEFAULT true,
ADD COLUMN default_channel_id uuid REFERENCES conversations(id);

-- Add trigger for updated_at on server_channels
CREATE TRIGGER update_server_channels_updated_at
BEFORE UPDATE ON server_channels
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();