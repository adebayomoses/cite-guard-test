-- Add mentorship fields to profiles table
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS is_mentor boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS mentor_type text CHECK (mentor_type IN ('free', 'paid', 'both')),
ADD COLUMN IF NOT EXISTS mentor_price numeric,
ADD COLUMN IF NOT EXISTS mentor_bio text,
ADD COLUMN IF NOT EXISTS mentor_available boolean DEFAULT true;

-- Create mentorship_sessions table for future use
CREATE TABLE IF NOT EXISTS public.mentorship_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  mentee_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  session_type text NOT NULL CHECK (session_type IN ('free', 'paid')),
  price numeric,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  scheduled_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on mentorship_sessions
ALTER TABLE public.mentorship_sessions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for mentorship_sessions
CREATE POLICY "Users can view their own mentorship sessions"
ON public.mentorship_sessions
FOR SELECT
USING (auth.uid() = mentor_id OR auth.uid() = mentee_id);

CREATE POLICY "Mentees can create session requests"
ON public.mentorship_sessions
FOR INSERT
WITH CHECK (auth.uid() = mentee_id);

CREATE POLICY "Mentors and mentees can update their sessions"
ON public.mentorship_sessions
FOR UPDATE
USING (auth.uid() = mentor_id OR auth.uid() = mentee_id);

-- Add trigger for updated_at
CREATE TRIGGER update_mentorship_sessions_updated_at
BEFORE UPDATE ON public.mentorship_sessions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();