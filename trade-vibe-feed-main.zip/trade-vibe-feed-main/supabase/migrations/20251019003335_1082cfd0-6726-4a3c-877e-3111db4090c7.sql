-- Create site-logos storage bucket
insert into storage.buckets (id, name, public)
values ('site-logos', 'site-logos', true);

-- RLS policy: Only admins can upload site logos
create policy "Only admins can upload site logos"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'site-logos' AND
  is_admin(auth.uid())
);

-- RLS policy: Only admins can update site logos
create policy "Only admins can update site logos"
on storage.objects for update
to authenticated
using (bucket_id = 'site-logos' AND is_admin(auth.uid()));

-- RLS policy: Only admins can delete site logos
create policy "Only admins can delete site logos"
on storage.objects for delete
to authenticated
using (bucket_id = 'site-logos' AND is_admin(auth.uid()));

-- RLS policy: Anyone can view site logos
create policy "Anyone can view site logos"
on storage.objects for select
to public
using (bucket_id = 'site-logos');

-- Insert default site branding settings
insert into site_settings (key, value)
values 
  ('site_name', '"UpTraView"'::jsonb),
  ('site_logo_url', 'null'::jsonb)
on conflict (key) do nothing;