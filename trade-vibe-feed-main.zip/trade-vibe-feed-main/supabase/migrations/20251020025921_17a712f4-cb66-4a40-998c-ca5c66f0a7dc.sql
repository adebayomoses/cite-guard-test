-- Create challenge_collaborators table
CREATE TABLE public.challenge_collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_id uuid NOT NULL REFERENCES public.challenges(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'collaborator' CHECK (role IN ('creator', 'collaborator')),
  added_by uuid REFERENCES public.profiles(id),
  added_at timestamp with time zone DEFAULT now(),
  UNIQUE(challenge_id, user_id)
);

-- Enable RLS
ALTER TABLE public.challenge_collaborators ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view challenge collaborators"
  ON public.challenge_collaborators FOR SELECT
  USING (true);

CREATE POLICY "Challenge creators can add collaborators"
  ON public.challenge_collaborators FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.challenges
      WHERE id = challenge_id AND created_by = auth.uid()
    )
  );

CREATE POLICY "Challenge creators can remove collaborators"
  ON public.challenge_collaborators FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.challenges
      WHERE id = challenge_id AND created_by = auth.uid()
    )
  );

-- Create helper function to check if user is challenge admin
CREATE OR REPLACE FUNCTION public.is_challenge_admin(
  _challenge_id uuid,
  _user_id uuid
)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM challenges
    WHERE id = _challenge_id AND created_by = _user_id
  ) OR EXISTS (
    SELECT 1 FROM challenge_collaborators
    WHERE challenge_id = _challenge_id AND user_id = _user_id
  )
$$;

-- Update RLS policies for challenge_signals table
DROP POLICY IF EXISTS "Only challenge creators can create signals" ON public.challenge_signals;

CREATE POLICY "Challenge admins can create signals"
  ON public.challenge_signals FOR INSERT
  WITH CHECK (
    public.is_challenge_admin(challenge_id, auth.uid())
  );