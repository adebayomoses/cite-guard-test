-- Create chat_requests table for the new request system
CREATE TABLE IF NOT EXISTS public.chat_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_user_id UUID NOT NULL,
  to_user_id UUID NOT NULL,
  intro_message TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'expired')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (now() + INTERVAL '7 days'),
  UNIQUE(from_user_id, to_user_id)
);

-- Enable RLS on chat_requests
ALTER TABLE public.chat_requests ENABLE ROW LEVEL SECURITY;

-- RLS policies for chat_requests
CREATE POLICY "Users can view requests involving them" ON public.chat_requests
FOR SELECT USING (from_user_id = auth.uid() OR to_user_id = auth.uid());

CREATE POLICY "Users can send chat requests" ON public.chat_requests
FOR INSERT WITH CHECK (from_user_id = auth.uid() AND from_user_id != to_user_id);

CREATE POLICY "Users can update requests they received" ON public.chat_requests
FOR UPDATE USING (to_user_id = auth.uid()) WITH CHECK (to_user_id = auth.uid());

-- Trigger to update updated_at on chat_requests
CREATE OR REPLACE FUNCTION update_chat_request_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_chat_requests_updated_at
  BEFORE UPDATE ON public.chat_requests
  FOR EACH ROW EXECUTE FUNCTION update_chat_request_updated_at();

-- Enable realtime for chat_requests
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_requests;