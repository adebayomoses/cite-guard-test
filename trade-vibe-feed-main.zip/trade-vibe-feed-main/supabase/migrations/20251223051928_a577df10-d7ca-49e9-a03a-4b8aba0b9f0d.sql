-- Create user_xp table to track each user's XP and rank
CREATE TABLE public.user_xp (
  user_id UUID NOT NULL PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  total_xp INTEGER NOT NULL DEFAULT 0,
  weekly_xp INTEGER NOT NULL DEFAULT 0,
  current_rank TEXT NOT NULL DEFAULT 'rookie',
  current_streak INTEGER NOT NULL DEFAULT 0,
  longest_streak INTEGER NOT NULL DEFAULT 0,
  last_activity_date DATE,
  rank_updated_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create xp_transactions table to log all XP gains/losses
CREATE TABLE public.xp_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  source_type TEXT NOT NULL, -- 'signal_win', 'signal_loss', 'useful_vote', 'challenge_win', 'daily_streak', 'post_created', 'achievement_unlocked'
  source_id UUID, -- Reference to the source (post_id, signal_id, challenge_id, etc.)
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create achievements table for badge definitions
CREATE TABLE public.achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  icon TEXT NOT NULL, -- emoji or icon name
  category TEXT NOT NULL DEFAULT 'general', -- 'trading', 'community', 'milestone', 'special'
  xp_reward INTEGER NOT NULL DEFAULT 0,
  unlock_condition JSONB NOT NULL DEFAULT '{}'::jsonb, -- { type: 'signal_wins', count: 5 }
  rarity TEXT NOT NULL DEFAULT 'common', -- 'common', 'rare', 'epic', 'legendary'
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_achievements junction table
CREATE TABLE public.user_achievements (
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  achievement_id UUID NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, achievement_id)
);

-- Enable RLS on all tables
ALTER TABLE public.user_xp ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.xp_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_xp
CREATE POLICY "Anyone can view user XP" ON public.user_xp
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own XP" ON public.user_xp
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS Policies for xp_transactions
CREATE POLICY "Users can view their own XP transactions" ON public.xp_transactions
  FOR SELECT USING (auth.uid() = user_id);

-- RLS Policies for achievements
CREATE POLICY "Anyone can view achievements" ON public.achievements
  FOR SELECT USING (true);

CREATE POLICY "Only admins can manage achievements" ON public.achievements
  FOR ALL USING (is_admin());

-- RLS Policies for user_achievements
CREATE POLICY "Anyone can view user achievements" ON public.user_achievements
  FOR SELECT USING (true);

-- Create indexes for performance
CREATE INDEX idx_user_xp_total ON public.user_xp(total_xp DESC);
CREATE INDEX idx_user_xp_weekly ON public.user_xp(weekly_xp DESC);
CREATE INDEX idx_user_xp_rank ON public.user_xp(current_rank);
CREATE INDEX idx_xp_transactions_user ON public.xp_transactions(user_id);
CREATE INDEX idx_xp_transactions_created ON public.xp_transactions(created_at DESC);
CREATE INDEX idx_user_achievements_user ON public.user_achievements(user_id);

-- Create trigger to update updated_at
CREATE TRIGGER update_user_xp_updated_at
  BEFORE UPDATE ON public.user_xp
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default achievements
INSERT INTO public.achievements (key, name, description, icon, category, xp_reward, unlock_condition, rarity, sort_order) VALUES
  ('first_post', 'First Steps', 'Create your first trading post', '📝', 'milestone', 10, '{"type": "posts_created", "count": 1}', 'common', 1),
  ('signal_starter', 'Signal Starter', 'Post 5 trading signals', '📊', 'trading', 25, '{"type": "signals_posted", "count": 5}', 'common', 2),
  ('hot_streak_3', 'On Fire', 'Win 3 signals in a row', '🔥', 'trading', 50, '{"type": "win_streak", "count": 3}', 'rare', 3),
  ('hot_streak_5', 'Blazing', 'Win 5 signals in a row', '💥', 'trading', 100, '{"type": "win_streak", "count": 5}', 'epic', 4),
  ('sharpshooter', 'Sharpshooter', 'Maintain 80%+ win rate (min 10 trades)', '🎯', 'trading', 150, '{"type": "win_rate", "percentage": 80, "min_trades": 10}', 'epic', 5),
  ('diamond_hands', 'Diamond Hands', 'Complete 10 successful signals', '💎', 'trading', 75, '{"type": "signal_wins", "count": 10}', 'rare', 6),
  ('community_star', 'Community Star', 'Receive 50 useful votes', '⭐', 'community', 50, '{"type": "useful_votes_received", "count": 50}', 'rare', 7),
  ('helpful_trader', 'Helpful Trader', 'Receive 100 useful votes', '🌟', 'community', 100, '{"type": "useful_votes_received", "count": 100}', 'epic', 8),
  ('rising_star', 'Rising Star', 'Reach Trader rank', '📈', 'milestone', 50, '{"type": "rank_reached", "rank": "trader"}', 'common', 9),
  ('going_pro', 'Going Pro', 'Reach Pro rank', '🚀', 'milestone', 100, '{"type": "rank_reached", "rank": "pro"}', 'rare', 10),
  ('elite_status', 'Elite Status', 'Reach Elite rank', '👑', 'milestone', 200, '{"type": "rank_reached", "rank": "elite"}', 'epic', 11),
  ('legendary', 'Legendary', 'Reach Legend rank', '🏆', 'milestone', 500, '{"type": "rank_reached", "rank": "legend"}', 'legendary', 12),
  ('challenge_champion', 'Challenge Champion', 'Win a trading challenge', '🏅', 'trading', 200, '{"type": "challenge_wins", "count": 1}', 'epic', 13),
  ('week_warrior', 'Week Warrior', 'Maintain a 7-day activity streak', '💪', 'milestone', 50, '{"type": "streak_days", "count": 7}', 'rare', 14),
  ('month_master', 'Month Master', 'Maintain a 30-day activity streak', '🔱', 'milestone', 150, '{"type": "streak_days", "count": 30}', 'legendary', 15);