-- Create challenges table
CREATE TABLE public.challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  scope TEXT CHECK (scope IN ('stocks','crypto','forex','options','futures','all')) DEFAULT 'all',
  metric TEXT CHECK (metric IN ('useful_rate','net_votes','pnl_self_report','consistency')) DEFAULT 'useful_rate',
  start_at TIMESTAMPTZ NOT NULL,
  end_at TIMESTAMPTZ NOT NULL,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  status TEXT GENERATED ALWAYS AS (
    CASE 
      WHEN now() < start_at THEN 'upcoming' 
      WHEN now() > end_at THEN 'ended' 
      ELSE 'live' 
    END
  ) STORED,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create challenge_entries table
CREATE TABLE public.challenge_entries (
  challenge_id UUID REFERENCES public.challenges(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (challenge_id, user_id)
);

-- Create challenge_scores table
CREATE TABLE public.challenge_scores (
  challenge_id UUID REFERENCES public.challenges(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  score NUMERIC DEFAULT 0,
  rank INTEGER,
  updated_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (challenge_id, user_id)
);

-- Create events table
CREATE TABLE public.events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  start_at TIMESTAMPTZ NOT NULL,
  end_at TIMESTAMPTZ,
  location TEXT DEFAULT 'online',
  url TEXT,
  host_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenge_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.challenge_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

-- RLS Policies for challenges
CREATE POLICY "Challenges are viewable by everyone" 
ON public.challenges FOR SELECT USING (true);

CREATE POLICY "Users can create challenges" 
ON public.challenges FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own challenges" 
ON public.challenges FOR UPDATE USING (auth.uid() = created_by);

CREATE POLICY "Users can delete their own challenges" 
ON public.challenges FOR DELETE USING (auth.uid() = created_by);

-- RLS Policies for challenge_entries
CREATE POLICY "Challenge entries are viewable by everyone" 
ON public.challenge_entries FOR SELECT USING (true);

CREATE POLICY "Users can join challenges" 
ON public.challenge_entries FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can leave challenges" 
ON public.challenge_entries FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for challenge_scores
CREATE POLICY "Challenge scores are viewable by everyone" 
ON public.challenge_scores FOR SELECT USING (true);

-- RLS Policies for events
CREATE POLICY "Events are viewable by everyone" 
ON public.events FOR SELECT USING (true);

CREATE POLICY "Users can create events" 
ON public.events FOR INSERT WITH CHECK (auth.uid() = host_id);

CREATE POLICY "Users can update their own events" 
ON public.events FOR UPDATE USING (auth.uid() = host_id);

CREATE POLICY "Users can delete their own events" 
ON public.events FOR DELETE USING (auth.uid() = host_id);

-- Create view for challenge leaderboard
CREATE OR REPLACE VIEW public.challenge_live_leaderboard AS
SELECT 
  cs.challenge_id,
  cs.user_id,
  cs.score,
  cs.rank,
  p.handle,
  p.display_name,
  p.avatar_url,
  p.verified_status
FROM public.challenge_scores cs
JOIN public.profiles p ON p.id = cs.user_id
ORDER BY cs.challenge_id, cs.rank;

-- Create triggers for updated_at timestamps
CREATE TRIGGER update_challenges_updated_at
BEFORE UPDATE ON public.challenges
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_challenge_scores_updated_at
BEFORE UPDATE ON public.challenge_scores
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_events_updated_at
BEFORE UPDATE ON public.events
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();