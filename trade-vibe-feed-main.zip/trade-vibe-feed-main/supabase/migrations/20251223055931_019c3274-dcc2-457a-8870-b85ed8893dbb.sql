-- Add is_active column to achievements table
ALTER TABLE achievements ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true;

-- Add site settings for rank configuration and XP rewards
INSERT INTO site_settings (key, value) VALUES 
  ('ranks_config', '[{"key":"rookie","name":"Rookie","minXP":0,"icon":"🌟","stars":0,"color":"text-muted-foreground"},{"key":"trader","name":"Trader","minXP":100,"icon":"⭐","stars":1,"color":"text-yellow-500"},{"key":"pro","name":"Pro","minXP":500,"icon":"⭐⭐","stars":2,"color":"text-yellow-500"},{"key":"elite","name":"Elite","minXP":2000,"icon":"⭐⭐⭐","stars":3,"color":"text-yellow-500"},{"key":"legend","name":"Legend","minXP":5000,"icon":"👑","stars":5,"color":"text-amber-400"}]'),
  ('xp_post_created', '5'),
  ('xp_vote_useful', '2'),
  ('xp_vote_not_useful', '-1'),
  ('xp_signal_won', '25'),
  ('xp_signal_lost', '-5'),
  ('xp_challenge_joined', '10'),
  ('xp_achievement_unlocked', '0'),
  ('xp_streak_bonus_enabled', 'true'),
  ('xp_streak_bonus_multiplier', '1.5')
ON CONFLICT (key) DO NOTHING;