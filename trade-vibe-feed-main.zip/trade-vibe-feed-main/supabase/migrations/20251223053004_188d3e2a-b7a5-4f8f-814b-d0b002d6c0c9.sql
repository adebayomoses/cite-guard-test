-- Function to initialize user_xp record
CREATE OR REPLACE FUNCTION public.initialize_user_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  INSERT INTO public.user_xp (user_id, total_xp, weekly_xp, current_rank, current_streak, longest_streak)
  VALUES (NEW.id, 0, 0, 'rookie', 0, 0)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Trigger to auto-create user_xp when profile is created
CREATE TRIGGER on_profile_created_init_xp
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.initialize_user_xp();

-- Initialize existing users who don't have user_xp records
INSERT INTO public.user_xp (user_id, total_xp, weekly_xp, current_rank, current_streak, longest_streak)
SELECT id, 0, 0, 'rookie', 0, 0
FROM public.profiles
WHERE id NOT IN (SELECT user_id FROM public.user_xp)
ON CONFLICT (user_id) DO NOTHING;

-- Function to award XP
CREATE OR REPLACE FUNCTION public.award_xp(
  p_user_id uuid,
  p_amount integer,
  p_source_type text,
  p_source_id uuid DEFAULT NULL,
  p_description text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_new_total integer;
  v_new_rank text;
BEGIN
  -- Insert XP transaction
  INSERT INTO public.xp_transactions (user_id, amount, source_type, source_id, description)
  VALUES (p_user_id, p_amount, p_source_type, p_source_id, p_description);
  
  -- Update user_xp totals
  UPDATE public.user_xp
  SET 
    total_xp = total_xp + p_amount,
    weekly_xp = weekly_xp + p_amount,
    last_activity_date = CURRENT_DATE
  WHERE user_id = p_user_id
  RETURNING total_xp INTO v_new_total;
  
  -- If no record exists, create one
  IF NOT FOUND THEN
    INSERT INTO public.user_xp (user_id, total_xp, weekly_xp, current_rank, last_activity_date)
    VALUES (p_user_id, GREATEST(p_amount, 0), GREATEST(p_amount, 0), 'rookie', CURRENT_DATE)
    RETURNING total_xp INTO v_new_total;
  END IF;
  
  -- Ensure total_xp doesn't go negative
  IF v_new_total < 0 THEN
    UPDATE public.user_xp SET total_xp = 0 WHERE user_id = p_user_id;
    v_new_total := 0;
  END IF;
  
  -- Calculate new rank based on XP thresholds
  v_new_rank := CASE
    WHEN v_new_total >= 5000 THEN 'legend'
    WHEN v_new_total >= 2000 THEN 'elite'
    WHEN v_new_total >= 500 THEN 'pro'
    WHEN v_new_total >= 100 THEN 'trader'
    ELSE 'rookie'
  END;
  
  -- Update rank if changed
  UPDATE public.user_xp
  SET current_rank = v_new_rank, rank_updated_at = now()
  WHERE user_id = p_user_id AND current_rank != v_new_rank;
END;
$$;

-- Trigger function for post creation XP (+5 XP)
CREATE OR REPLACE FUNCTION public.on_post_created_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.award_xp(NEW.author_id, 5, 'post_created', NEW.id, 'Created a new post');
  RETURN NEW;
END;
$$;

-- Trigger for post creation
CREATE TRIGGER on_post_created_xp
  AFTER INSERT ON public.posts
  FOR EACH ROW
  EXECUTE FUNCTION public.on_post_created_award_xp();

-- Trigger function for receiving useful votes (+2 XP per upvote, -1 XP per downvote)
CREATE OR REPLACE FUNCTION public.on_vote_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_post_author_id uuid;
BEGIN
  -- Get the post author
  SELECT author_id INTO v_post_author_id FROM public.posts WHERE id = NEW.post_id;
  
  IF v_post_author_id IS NOT NULL AND v_post_author_id != NEW.user_id THEN
    IF NEW.value = 1 THEN
      -- Upvote: award +2 XP to post author
      PERFORM public.award_xp(v_post_author_id, 2, 'useful_vote', NEW.post_id, 'Received a useful vote');
    ELSIF NEW.value = -1 THEN
      -- Downvote: deduct -1 XP from post author
      PERFORM public.award_xp(v_post_author_id, -1, 'not_useful_vote', NEW.post_id, 'Received a not useful vote');
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger for votes
CREATE TRIGGER on_vote_xp
  AFTER INSERT ON public.votes
  FOR EACH ROW
  EXECUTE FUNCTION public.on_vote_award_xp();

-- Trigger function for vote changes (handle vote updates)
CREATE OR REPLACE FUNCTION public.on_vote_updated_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_post_author_id uuid;
  v_xp_change integer;
BEGIN
  -- Get the post author
  SELECT author_id INTO v_post_author_id FROM public.posts WHERE id = NEW.post_id;
  
  IF v_post_author_id IS NOT NULL AND v_post_author_id != NEW.user_id THEN
    -- Calculate XP change based on vote change
    -- Old vote removed, new vote added
    v_xp_change := 0;
    
    -- Remove old vote effect
    IF OLD.value = 1 THEN
      v_xp_change := v_xp_change - 2;
    ELSIF OLD.value = -1 THEN
      v_xp_change := v_xp_change + 1;
    END IF;
    
    -- Add new vote effect
    IF NEW.value = 1 THEN
      v_xp_change := v_xp_change + 2;
    ELSIF NEW.value = -1 THEN
      v_xp_change := v_xp_change - 1;
    END IF;
    
    IF v_xp_change != 0 THEN
      PERFORM public.award_xp(v_post_author_id, v_xp_change, 'vote_changed', NEW.post_id, 'Vote changed');
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger for vote updates
CREATE TRIGGER on_vote_updated_xp
  AFTER UPDATE ON public.votes
  FOR EACH ROW
  WHEN (OLD.value IS DISTINCT FROM NEW.value)
  EXECUTE FUNCTION public.on_vote_updated_award_xp();

-- Trigger function for vote deletion (reverse XP)
CREATE OR REPLACE FUNCTION public.on_vote_deleted_reverse_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_post_author_id uuid;
BEGIN
  -- Get the post author
  SELECT author_id INTO v_post_author_id FROM public.posts WHERE id = OLD.post_id;
  
  IF v_post_author_id IS NOT NULL AND v_post_author_id != OLD.user_id THEN
    IF OLD.value = 1 THEN
      -- Reverse upvote: deduct 2 XP
      PERFORM public.award_xp(v_post_author_id, -2, 'vote_removed', OLD.post_id, 'Useful vote removed');
    ELSIF OLD.value = -1 THEN
      -- Reverse downvote: add back 1 XP
      PERFORM public.award_xp(v_post_author_id, 1, 'vote_removed', OLD.post_id, 'Not useful vote removed');
    END IF;
  END IF;
  
  RETURN OLD;
END;
$$;

-- Trigger for vote deletion
CREATE TRIGGER on_vote_deleted_xp
  AFTER DELETE ON public.votes
  FOR EACH ROW
  EXECUTE FUNCTION public.on_vote_deleted_reverse_xp();

-- Trigger function for signal wins/losses
CREATE OR REPLACE FUNCTION public.on_signal_status_change_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Only process when status changes to win or loss
  IF NEW.status = 'won' AND (OLD.status IS NULL OR OLD.status != 'won') THEN
    PERFORM public.award_xp(NEW.author_id, 25, 'signal_won', NEW.id, 'Signal hit target');
  ELSIF NEW.status = 'lost' AND (OLD.status IS NULL OR OLD.status != 'lost') THEN
    PERFORM public.award_xp(NEW.author_id, -5, 'signal_lost', NEW.id, 'Signal hit stop loss');
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger for signal tracking status changes
CREATE TRIGGER on_signal_status_xp
  AFTER UPDATE ON public.signal_tracking
  FOR EACH ROW
  WHEN (OLD.status IS DISTINCT FROM NEW.status)
  EXECUTE FUNCTION public.on_signal_status_change_award_xp();

-- Trigger function for challenge participation XP (+10 XP for joining)
CREATE OR REPLACE FUNCTION public.on_challenge_joined_award_xp()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.award_xp(NEW.user_id, 10, 'challenge_joined', NEW.challenge_id, 'Joined a challenge');
  RETURN NEW;
END;
$$;

-- Trigger for challenge entries
CREATE TRIGGER on_challenge_joined_xp
  AFTER INSERT ON public.challenge_entries
  FOR EACH ROW
  EXECUTE FUNCTION public.on_challenge_joined_award_xp();