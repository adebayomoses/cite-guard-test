-- Enable pg_cron and pg_net extensions if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Grant usage to postgres role
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- Schedule hourly reputation update
SELECT cron.schedule(
  'update-reputation-hourly',
  '0 * * * *',
  $$
  SELECT
    net.http_post(
      url := 'https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/reputation-cron',
      headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp5b25qeHZmanNoa2pkdGp3Y3FvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1MTI2NTYsImV4cCI6MjA3NDA4ODY1Nn0.jJLyCVuoDQUxr_lA3BPDGVza_zwAeVUFILAz0S1pR34"}'::jsonb,
      body := '{}'::jsonb
    ) AS request_id;
  $$
);