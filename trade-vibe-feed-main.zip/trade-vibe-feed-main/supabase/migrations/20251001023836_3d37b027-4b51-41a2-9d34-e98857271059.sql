-- Add foreign key constraints to chat_requests table
ALTER TABLE public.chat_requests
ADD CONSTRAINT chat_requests_from_user_id_fkey 
FOREIGN KEY (from_user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.chat_requests
ADD CONSTRAINT chat_requests_to_user_id_fkey 
FOREIGN KEY (to_user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;