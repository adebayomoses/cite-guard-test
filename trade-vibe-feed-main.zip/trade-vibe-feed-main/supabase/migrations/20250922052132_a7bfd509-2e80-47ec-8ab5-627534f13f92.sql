-- Create posts table to store trading posts
CREATE TABLE public.posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID NOT NULL,
  content TEXT NOT NULL,
  tickers TEXT[] DEFAULT '{}',
  risk_level TEXT CHECK (risk_level IN ('low', 'medium', 'high')),
  trade_meta JSONB DEFAULT '{}',
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

-- Create policies for posts
CREATE POLICY "Posts are viewable by everyone" 
ON public.posts 
FOR SELECT 
USING (true);

CREATE POLICY "Users can create their own posts" 
ON public.posts 
FOR INSERT 
WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own posts" 
ON public.posts 
FOR UPDATE 
USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own posts" 
ON public.posts 
FOR DELETE 
USING (auth.uid() = author_id);

-- Create materialized view for trending tickers
CREATE MATERIALIZED VIEW public.trending_tickers_24h AS
WITH post_stats AS (
  SELECT 
    unnest(tickers) as ticker,
    COUNT(*) as post_count,
    COUNT(DISTINCT author_id) as unique_authors
  FROM public.posts 
  WHERE created_at >= now() - interval '24 hours'
  GROUP BY ticker
),
vote_stats AS (
  SELECT 
    unnest(p.tickers) as ticker,
    COUNT(CASE WHEN v.value = 1 THEN 1 END) as useful_votes,
    COUNT(CASE WHEN v.value = -1 THEN 1 END) as not_useful_votes
  FROM public.posts p
  LEFT JOIN public.votes v ON p.id = v.post_id
  WHERE p.created_at >= now() - interval '24 hours'
  GROUP BY ticker
),
comment_stats AS (
  SELECT 
    unnest(p.tickers) as ticker,
    COUNT(c.id) as comment_count
  FROM public.posts p
  LEFT JOIN public.comments c ON p.id = c.post_id
  WHERE p.created_at >= now() - interval '24 hours'
  GROUP BY ticker
)
SELECT 
  COALESCE(ps.ticker, vs.ticker, cs.ticker) as ticker,
  COALESCE(ps.post_count, 0) as post_count,
  COALESCE(ps.unique_authors, 0) as unique_authors,
  COALESCE(vs.useful_votes, 0) as useful_votes,
  COALESCE(vs.not_useful_votes, 0) as not_useful_votes,
  COALESCE(cs.comment_count, 0) as comment_count,
  (COALESCE(ps.post_count, 0) * 2 + 
   COALESCE(ps.unique_authors, 0) * 3 + 
   COALESCE(vs.useful_votes, 0) - COALESCE(vs.not_useful_votes, 0) + 
   COALESCE(cs.comment_count, 0) * 1.5) as score,
  now() as last_updated
FROM post_stats ps
FULL OUTER JOIN vote_stats vs ON ps.ticker = vs.ticker
FULL OUTER JOIN comment_stats cs ON COALESCE(ps.ticker, vs.ticker) = cs.ticker
WHERE COALESCE(ps.ticker, vs.ticker, cs.ticker) IS NOT NULL
ORDER BY score DESC
LIMIT 50;

-- Create index for faster lookups
CREATE UNIQUE INDEX idx_trending_tickers_ticker ON public.trending_tickers_24h (ticker);

-- Create function to refresh trending tickers
CREATE OR REPLACE FUNCTION refresh_trending_tickers()
RETURNS void AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY public.trending_tickers_24h;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add trigger for automatic post timestamp updates
CREATE TRIGGER update_posts_updated_at
  BEFORE UPDATE ON public.posts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();