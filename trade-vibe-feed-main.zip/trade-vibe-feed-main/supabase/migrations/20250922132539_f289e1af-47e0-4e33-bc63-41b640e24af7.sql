-- Fix security issues from previous migration

-- Fix function search path for get_challenge_status
CREATE OR REPLACE FUNCTION public.get_challenge_status(start_time TIMESTAMPTZ, end_time TIMESTAMPTZ)
RETURNS TEXT 
LANGUAGE plpgsql 
IMMUTABLE 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF now() < start_time THEN
    RETURN 'upcoming';
  ELSIF now() > end_time THEN
    RETURN 'ended';
  ELSE
    RETURN 'live';
  END IF;
END;
$$;

-- Recreate views without SECURITY DEFINER (they default to SECURITY INVOKER)
DROP VIEW IF EXISTS public.challenges_with_status;
CREATE VIEW public.challenges_with_status AS
SELECT 
  id,
  title,
  description,
  scope,
  metric,
  start_at,
  end_at,
  created_by,
  created_at,
  updated_at,
  public.get_challenge_status(start_at, end_at) AS status
FROM public.challenges;

DROP VIEW IF EXISTS public.challenge_live_leaderboard;
CREATE VIEW public.challenge_live_leaderboard AS
SELECT 
  cs.challenge_id,
  cs.user_id,
  cs.score,
  cs.rank,
  p.handle,
  p.display_name,
  p.avatar_url,
  p.verified_status
FROM public.challenge_scores cs
JOIN public.profiles p ON p.id = cs.user_id
ORDER BY cs.challenge_id, cs.rank;