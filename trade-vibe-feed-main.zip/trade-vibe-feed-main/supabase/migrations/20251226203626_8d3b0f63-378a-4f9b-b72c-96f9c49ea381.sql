-- Create helper function to check if user has minimum XP threshold
CREATE OR REPLACE FUNCTION public.has_min_rank(_user_id uuid, _min_xp integer)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_xp
    WHERE user_id = _user_id AND total_xp >= _min_xp
  )
$$;

-- Convenience function to check if user can create premium content (Pro rank = 500+ XP OR admin)
CREATE OR REPLACE FUNCTION public.can_create_premium_content(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    public.has_role(_user_id, 'admin') OR 
    public.has_min_rank(_user_id, 500)
$$;