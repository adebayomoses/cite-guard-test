-- Create lifestyle videos table
CREATE TABLE public.lifestyle_videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  video_url TEXT NOT NULL,
  thumbnail_url TEXT,
  caption TEXT,
  hashtags TEXT[] DEFAULT '{}',
  tickers TEXT[] DEFAULT '{}',
  visibility TEXT DEFAULT 'public' CHECK (visibility IN ('public', 'followers')),
  like_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  duration_seconds INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create lifestyle likes table
CREATE TABLE public.lifestyle_likes (
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  video_id UUID NOT NULL REFERENCES public.lifestyle_videos(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  PRIMARY KEY (user_id, video_id)
);

-- Create lifestyle comments table
CREATE TABLE public.lifestyle_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES public.lifestyle_videos(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES 
  ('lifestyle-videos', 'lifestyle-videos', true),
  ('lifestyle-thumbs', 'lifestyle-thumbs', true);

-- Enable RLS
ALTER TABLE public.lifestyle_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lifestyle_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lifestyle_comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for lifestyle_videos
CREATE POLICY "Anyone can view public videos" ON public.lifestyle_videos
  FOR SELECT USING (
    visibility = 'public' OR 
    (visibility = 'followers' AND EXISTS (
      SELECT 1 FROM public.follows 
      WHERE target_id = author_id AND user_id = auth.uid()
    )) OR
    author_id = auth.uid()
  );

CREATE POLICY "Users can create their own videos" ON public.lifestyle_videos
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own videos" ON public.lifestyle_videos
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own videos" ON public.lifestyle_videos
  FOR DELETE USING (auth.uid() = author_id);

-- RLS Policies for lifestyle_likes
CREATE POLICY "Anyone can view likes" ON public.lifestyle_likes
  FOR SELECT USING (true);

CREATE POLICY "Users can manage their own likes" ON public.lifestyle_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own likes" ON public.lifestyle_likes
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for lifestyle_comments
CREATE POLICY "Anyone can view comments" ON public.lifestyle_comments
  FOR SELECT USING (true);

CREATE POLICY "Users can create comments" ON public.lifestyle_comments
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own comments" ON public.lifestyle_comments
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own comments" ON public.lifestyle_comments
  FOR DELETE USING (auth.uid() = author_id);

-- Storage policies for lifestyle-videos
CREATE POLICY "Anyone can view videos" ON storage.objects
  FOR SELECT USING (bucket_id = 'lifestyle-videos');

CREATE POLICY "Users can upload their own videos" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'lifestyle-videos' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can update their own videos" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'lifestyle-videos' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can delete their own videos" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'lifestyle-videos' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

-- Storage policies for lifestyle-thumbs
CREATE POLICY "Anyone can view thumbnails" ON storage.objects
  FOR SELECT USING (bucket_id = 'lifestyle-thumbs');

CREATE POLICY "Users can upload their own thumbnails" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'lifestyle-thumbs' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can update their own thumbnails" ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'lifestyle-thumbs' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can delete their own thumbnails" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'lifestyle-thumbs' AND 
    auth.uid()::text = (storage.foldername(name))[1]
  );

-- Triggers for updated_at
CREATE TRIGGER update_lifestyle_videos_updated_at
  BEFORE UPDATE ON public.lifestyle_videos
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_lifestyle_comments_updated_at
  BEFORE UPDATE ON public.lifestyle_comments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to update like counts
CREATE OR REPLACE FUNCTION public.update_video_like_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.lifestyle_videos 
    SET like_count = like_count + 1 
    WHERE id = NEW.video_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.lifestyle_videos 
    SET like_count = like_count - 1 
    WHERE id = OLD.video_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update comment counts
CREATE OR REPLACE FUNCTION public.update_video_comment_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.lifestyle_videos 
    SET comment_count = comment_count + 1 
    WHERE id = NEW.video_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.lifestyle_videos 
    SET comment_count = comment_count - 1 
    WHERE id = OLD.video_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Triggers for count updates
CREATE TRIGGER lifestyle_like_count_trigger
  AFTER INSERT OR DELETE ON public.lifestyle_likes
  FOR EACH ROW EXECUTE FUNCTION public.update_video_like_count();

CREATE TRIGGER lifestyle_comment_count_trigger
  AFTER INSERT OR DELETE ON public.lifestyle_comments
  FOR EACH ROW EXECUTE FUNCTION public.update_video_comment_count();