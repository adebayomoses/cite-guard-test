-- Backfill historical XP for existing data
-- This is a one-time operation to award XP for posts and votes that happened before the XP system

-- Create a function to run the backfill
CREATE OR REPLACE FUNCTION public.backfill_historical_xp()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_user RECORD;
  v_post_count integer;
  v_useful_votes_received integer;
  v_not_useful_votes_received integer;
  v_total_xp integer;
  v_new_rank text;
BEGIN
  -- Loop through all users with posts or who have received votes
  FOR v_user IN 
    SELECT DISTINCT p.author_id as user_id
    FROM posts p
    UNION
    SELECT DISTINCT p.author_id as user_id
    FROM posts p
    JOIN votes v ON v.post_id = p.id
  LOOP
    -- Count posts
    SELECT COUNT(*) INTO v_post_count 
    FROM posts 
    WHERE author_id = v_user.user_id;
    
    -- Count useful votes received
    SELECT COALESCE(SUM(ps.useful_count), 0) INTO v_useful_votes_received
    FROM post_scores ps
    JOIN posts p ON p.id = ps.post_id
    WHERE p.author_id = v_user.user_id;
    
    -- Count not useful votes received
    SELECT COALESCE(SUM(ps.not_useful_count), 0) INTO v_not_useful_votes_received
    FROM post_scores ps
    JOIN posts p ON p.id = ps.post_id
    WHERE p.author_id = v_user.user_id;
    
    -- Calculate total XP: 5 per post, 2 per useful vote, -1 per not useful vote
    v_total_xp := (v_post_count * 5) + (v_useful_votes_received * 2) - v_not_useful_votes_received;
    
    -- Ensure XP is not negative
    IF v_total_xp < 0 THEN
      v_total_xp := 0;
    END IF;
    
    -- Calculate rank
    v_new_rank := CASE
      WHEN v_total_xp >= 5000 THEN 'legend'
      WHEN v_total_xp >= 2000 THEN 'elite'
      WHEN v_total_xp >= 500 THEN 'pro'
      WHEN v_total_xp >= 100 THEN 'trader'
      ELSE 'rookie'
    END;
    
    -- Upsert into user_xp
    INSERT INTO user_xp (user_id, total_xp, weekly_xp, current_rank, current_streak, longest_streak)
    VALUES (v_user.user_id, v_total_xp, 0, v_new_rank, 0, 0)
    ON CONFLICT (user_id) DO UPDATE SET
      total_xp = GREATEST(user_xp.total_xp, EXCLUDED.total_xp),
      current_rank = CASE 
        WHEN GREATEST(user_xp.total_xp, EXCLUDED.total_xp) >= 5000 THEN 'legend'
        WHEN GREATEST(user_xp.total_xp, EXCLUDED.total_xp) >= 2000 THEN 'elite'
        WHEN GREATEST(user_xp.total_xp, EXCLUDED.total_xp) >= 500 THEN 'pro'
        WHEN GREATEST(user_xp.total_xp, EXCLUDED.total_xp) >= 100 THEN 'trader'
        ELSE 'rookie'
      END,
      rank_updated_at = now();
    
    -- Log the transaction for tracking
    INSERT INTO xp_transactions (user_id, amount, source_type, description)
    VALUES (v_user.user_id, v_total_xp, 'historical_backfill', 
      'Backfill: ' || v_post_count || ' posts, ' || v_useful_votes_received || ' useful votes, ' || v_not_useful_votes_received || ' not useful votes');
    
    -- Check and unlock any achievements they should have
    PERFORM public.check_and_unlock_achievements(v_user.user_id);
    
  END LOOP;
END;
$$;

-- Run the backfill
SELECT public.backfill_historical_xp();

-- Clean up - drop the function after use (optional, keep it for debugging)
-- DROP FUNCTION public.backfill_historical_xp();