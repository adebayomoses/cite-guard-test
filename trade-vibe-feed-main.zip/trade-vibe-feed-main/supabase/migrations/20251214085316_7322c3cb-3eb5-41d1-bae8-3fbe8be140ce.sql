-- Insert video_compression feature flag with default enabled (true)
INSERT INTO public.feature_flags (key, enabled, updated_at)
VALUES ('video_compression', true, now())
ON CONFLICT (key) DO NOTHING;