-- Function to check and unlock achievements for a user
CREATE OR REPLACE FUNCTION public.check_and_unlock_achievements(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_achievement RECORD;
  v_user_xp RECORD;
  v_post_count integer;
  v_useful_votes_received integer;
  v_challenge_count integer;
  v_streak integer;
BEGIN
  -- Get user XP data
  SELECT * INTO v_user_xp FROM user_xp WHERE user_id = p_user_id;
  
  -- Get post count
  SELECT COUNT(*) INTO v_post_count FROM posts WHERE author_id = p_user_id;
  
  -- Get useful votes received
  SELECT COALESCE(SUM(ps.useful_count), 0) INTO v_useful_votes_received 
  FROM post_scores ps 
  JOIN posts p ON p.id = ps.post_id 
  WHERE p.author_id = p_user_id;
  
  -- Get challenge participation count
  SELECT COUNT(*) INTO v_challenge_count FROM challenge_entries WHERE user_id = p_user_id;
  
  -- Get current streak
  v_streak := COALESCE(v_user_xp.current_streak, 0);
  
  -- Loop through all achievements and check conditions
  FOR v_achievement IN SELECT * FROM achievements LOOP
    -- Skip if already unlocked
    IF EXISTS (
      SELECT 1 FROM user_achievements 
      WHERE user_id = p_user_id AND achievement_id = v_achievement.id
    ) THEN
      CONTINUE;
    END IF;
    
    -- Check conditions based on achievement key
    IF v_achievement.key = 'first_post' AND v_post_count >= 1 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'post_5' AND v_post_count >= 5 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'post_25' AND v_post_count >= 25 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'post_100' AND v_post_count >= 100 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'helpful_10' AND v_useful_votes_received >= 10 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'helpful_50' AND v_useful_votes_received >= 50 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'helpful_200' AND v_useful_votes_received >= 200 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'xp_100' AND COALESCE(v_user_xp.total_xp, 0) >= 100 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'xp_500' AND COALESCE(v_user_xp.total_xp, 0) >= 500 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'xp_2000' AND COALESCE(v_user_xp.total_xp, 0) >= 2000 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'xp_5000' AND COALESCE(v_user_xp.total_xp, 0) >= 5000 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'streak_3' AND v_streak >= 3 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'streak_7' AND v_streak >= 7 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'streak_30' AND v_streak >= 30 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'challenge_join' AND v_challenge_count >= 1 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    ELSIF v_achievement.key = 'challenge_5' AND v_challenge_count >= 5 THEN
      INSERT INTO user_achievements (user_id, achievement_id)
      VALUES (p_user_id, v_achievement.id);
      PERFORM public.award_xp(p_user_id, v_achievement.xp_reward, 'achievement_unlocked', v_achievement.id, 'Unlocked: ' || v_achievement.name);
      
    END IF;
  END LOOP;
END;
$$;

-- Trigger function to check achievements after post creation
CREATE OR REPLACE FUNCTION public.on_post_check_achievements()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.check_and_unlock_achievements(NEW.author_id);
  RETURN NEW;
END;
$$;

-- Trigger function to check achievements after XP update
CREATE OR REPLACE FUNCTION public.on_xp_update_check_achievements()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.check_and_unlock_achievements(NEW.user_id);
  RETURN NEW;
END;
$$;

-- Trigger function to check achievements after vote
CREATE OR REPLACE FUNCTION public.on_vote_check_achievements()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_post_author_id uuid;
BEGIN
  SELECT author_id INTO v_post_author_id FROM posts WHERE id = NEW.post_id;
  IF v_post_author_id IS NOT NULL THEN
    PERFORM public.check_and_unlock_achievements(v_post_author_id);
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger function to check achievements after challenge join
CREATE OR REPLACE FUNCTION public.on_challenge_join_check_achievements()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM public.check_and_unlock_achievements(NEW.user_id);
  RETURN NEW;
END;
$$;

-- Create triggers
DROP TRIGGER IF EXISTS check_achievements_on_post ON posts;
CREATE TRIGGER check_achievements_on_post
  AFTER INSERT ON posts
  FOR EACH ROW
  EXECUTE FUNCTION on_post_check_achievements();

DROP TRIGGER IF EXISTS check_achievements_on_xp_update ON user_xp;
CREATE TRIGGER check_achievements_on_xp_update
  AFTER UPDATE ON user_xp
  FOR EACH ROW
  EXECUTE FUNCTION on_xp_update_check_achievements();

DROP TRIGGER IF EXISTS check_achievements_on_vote ON votes;
CREATE TRIGGER check_achievements_on_vote
  AFTER INSERT ON votes
  FOR EACH ROW
  EXECUTE FUNCTION on_vote_check_achievements();

DROP TRIGGER IF EXISTS check_achievements_on_challenge ON challenge_entries;
CREATE TRIGGER check_achievements_on_challenge
  AFTER INSERT ON challenge_entries
  FOR EACH ROW
  EXECUTE FUNCTION on_challenge_join_check_achievements();

-- Seed default achievements if they don't exist
INSERT INTO achievements (key, name, description, icon, category, xp_reward, rarity, sort_order, unlock_condition)
VALUES 
  ('first_post', 'First Steps', 'Create your first trading post', '📝', 'posts', 10, 'common', 1, '{"posts": 1}'),
  ('post_5', 'Getting Started', 'Create 5 trading posts', '✍️', 'posts', 25, 'common', 2, '{"posts": 5}'),
  ('post_25', 'Regular Contributor', 'Create 25 trading posts', '📊', 'posts', 50, 'uncommon', 3, '{"posts": 25}'),
  ('post_100', 'Trading Veteran', 'Create 100 trading posts', '🏆', 'posts', 100, 'rare', 4, '{"posts": 100}'),
  ('helpful_10', 'Helping Hand', 'Receive 10 useful votes', '👍', 'social', 15, 'common', 10, '{"useful_votes": 10}'),
  ('helpful_50', 'Community Helper', 'Receive 50 useful votes', '🤝', 'social', 40, 'uncommon', 11, '{"useful_votes": 50}'),
  ('helpful_200', 'Trading Guru', 'Receive 200 useful votes', '🌟', 'social', 100, 'rare', 12, '{"useful_votes": 200}'),
  ('xp_100', 'Rising Trader', 'Earn 100 XP', '⬆️', 'xp', 0, 'common', 20, '{"xp": 100}'),
  ('xp_500', 'Pro Status', 'Earn 500 XP and reach Pro rank', '⭐', 'xp', 0, 'uncommon', 21, '{"xp": 500}'),
  ('xp_2000', 'Elite Status', 'Earn 2000 XP and reach Elite rank', '🌟', 'xp', 0, 'rare', 22, '{"xp": 2000}'),
  ('xp_5000', 'Legend Status', 'Earn 5000 XP and reach Legend rank', '👑', 'xp', 0, 'legendary', 23, '{"xp": 5000}'),
  ('streak_3', 'Consistent', '3-day activity streak', '🔥', 'engagement', 10, 'common', 30, '{"streak": 3}'),
  ('streak_7', 'Dedicated', '7-day activity streak', '🔥🔥', 'engagement', 25, 'uncommon', 31, '{"streak": 7}'),
  ('streak_30', 'Unstoppable', '30-day activity streak', '🔥🔥🔥', 'engagement', 75, 'rare', 32, '{"streak": 30}'),
  ('challenge_join', 'Challenger', 'Join your first challenge', '🎯', 'challenges', 15, 'common', 40, '{"challenges": 1}'),
  ('challenge_5', 'Challenge Master', 'Participate in 5 challenges', '🏅', 'challenges', 50, 'uncommon', 41, '{"challenges": 5}')
ON CONFLICT (key) DO NOTHING;