-- Enable pg_cron extension for scheduled jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Enable pg_net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Schedule signal tracker to run every 5 minutes
SELECT cron.schedule(
  'signal-tracker-update',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url:='https://jyonjxvfjshkjdtjwcqo.supabase.co/functions/v1/signal-tracker',
    headers:='{"Content-Type": "application/json"}'::jsonb,
    body:=concat('{"time": "', now(), '"}')::jsonb
  ) as request_id;
  $$
);