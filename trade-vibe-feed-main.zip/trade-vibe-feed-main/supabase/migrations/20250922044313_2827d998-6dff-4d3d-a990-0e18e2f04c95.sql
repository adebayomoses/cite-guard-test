-- Create follows table for user-to-user following relationships
CREATE TABLE IF NOT EXISTS public.follows (
  user_id UUID NOT NULL,
  target_id UUID NOT NULL, 
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, target_id)
);

-- Enable RLS on follows table
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;

-- RLS policies for follows table
CREATE POLICY "Users can view all follows" 
ON public.follows 
FOR SELECT 
USING (true);

CREATE POLICY "Users can insert their own follows" 
ON public.follows 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own follows" 
ON public.follows 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create view for user follow counts
CREATE OR REPLACE VIEW public.user_follow_counts AS
SELECT 
  p.id as user_id,
  COALESCE(followers.count, 0) as followers,
  COALESCE(following.count, 0) as following
FROM public.profiles p
LEFT JOIN (
  SELECT target_id, COUNT(*) as count
  FROM public.follows
  GROUP BY target_id
) followers ON p.id = followers.target_id
LEFT JOIN (
  SELECT user_id, COUNT(*) as count  
  FROM public.follows
  GROUP BY user_id
) following ON p.id = following.user_id;