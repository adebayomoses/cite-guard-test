-- Fix the security definer view issue by recreating without SECURITY DEFINER
DROP VIEW IF EXISTS public.user_metrics_30d;

CREATE OR REPLACE VIEW public.user_metrics_30d AS
SELECT 
  p.id as user_id,
  CASE 
    WHEN COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) + COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0) = 0 
    THEN 0
    ELSE ROUND(
      (COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0)::numeric / 
       NULLIF(COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) + COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0), 0)) * 100, 
      1
    )
  END as useful_rate_30d,
  COALESCE(SUM(CASE WHEN v.value = 1 THEN 1 ELSE 0 END), 0) as useful_count_30d,
  COALESCE(SUM(CASE WHEN v.value = -1 THEN 1 ELSE 0 END), 0) as not_useful_count_30d
FROM public.profiles p
LEFT JOIN public.votes v ON p.id = v.user_id AND v.created_at >= NOW() - INTERVAL '30 days'
GROUP BY p.id;