import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Signal {
  id: string;
  signal_type: string;
  signal_id: string;
  author_id: string;
  ticker: string;
  entry_price: number;
  stop_loss: number | null;
  target_price: number | null;
  trade_direction: string;
  market_type: string;
  expires_at: string | null;
}

interface TickerMapping {
  ticker: string;
  api_symbol: string;
  market_type: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Starting signal tracking check...');

    // Fetch all ongoing signals
    const { data: signals, error: signalsError } = await supabaseClient
      .from('signal_tracking')
      .select('*')
      .eq('status', 'ongoing');

    if (signalsError) {
      console.error('Error fetching signals:', signalsError);
      throw signalsError;
    }

    if (!signals || signals.length === 0) {
      console.log('No ongoing signals to track');
      return new Response(
        JSON.stringify({ message: 'No ongoing signals', checked: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${signals.length} ongoing signals to check`);

    // Fetch ticker mappings
    const { data: tickerMappings, error: mappingsError } = await supabaseClient
      .from('ticker_mappings')
      .select('*');

    if (mappingsError) {
      console.error('Error fetching ticker mappings:', mappingsError);
    }

    const mappingsMap = new Map<string, TickerMapping>();
    tickerMappings?.forEach((mapping: TickerMapping) => {
      mappingsMap.set(mapping.ticker.toUpperCase(), mapping);
    });

    let checkedCount = 0;
    let updatedCount = 0;

    // Process each signal
    for (const signal of signals as Signal[]) {
      try {
        console.log(`Checking signal ${signal.id} for ticker ${signal.ticker}`);

        // Check if signal expired
        if (signal.expires_at && new Date(signal.expires_at) < new Date()) {
          console.log(`Signal ${signal.id} expired`);
          await supabaseClient
            .from('signal_tracking')
            .update({
              status: 'expired',
              closed_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            })
            .eq('id', signal.id);
          updatedCount++;
          continue;
        }

        // Get current price
        const currentPrice = await fetchCurrentPrice(signal.ticker, signal.market_type, mappingsMap);
        
        if (!currentPrice) {
          console.log(`Could not fetch price for ${signal.ticker}`);
          await supabaseClient
            .from('signal_tracking')
            .update({
              last_checked_at: new Date().toISOString()
            })
            .eq('id', signal.id);
          checkedCount++;
          continue;
        }

        console.log(`Current price for ${signal.ticker}: ${currentPrice}`);

        // Check if target or stop loss hit
        const result = checkSignalStatus(signal, currentPrice);

        if (result.status !== 'ongoing') {
          console.log(`Signal ${signal.id} status changed to ${result.status} with P&L: ${result.pnl}%`);
          
          // Update signal status
          await supabaseClient
            .from('signal_tracking')
            .update({
              status: result.status,
              current_price: currentPrice,
              pnl_percentage: result.pnl,
              closed_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            })
            .eq('id', signal.id);

          // Update trader performance
          await updateTraderPerformance(supabaseClient, signal.author_id);
          updatedCount++;
        } else {
          // Just update current price and last checked
          await supabaseClient
            .from('signal_tracking')
            .update({
              current_price: currentPrice,
              last_checked_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            })
            .eq('id', signal.id);
          checkedCount++;
        }
      } catch (error) {
        console.error(`Error processing signal ${signal.id}:`, error);
      }
    }

    console.log(`Signal tracking complete. Checked: ${checkedCount}, Updated: ${updatedCount}`);

    return new Response(
      JSON.stringify({
        message: 'Signal tracking complete',
        checked: checkedCount,
        updated: updatedCount,
        total: signals.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in signal tracker:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function checkSignalStatus(signal: Signal, currentPrice: number): { status: string; pnl: number | null } {
  const entry = signal.entry_price;
  const target = signal.target_price;
  const stop = signal.stop_loss;

  if (!target && !stop) {
    return { status: 'ongoing', pnl: null };
  }

  if (signal.trade_direction === 'long') {
    // LONG position
    if (target && currentPrice >= target) {
      const pnl = ((target - entry) / entry) * 100;
      return { status: 'win', pnl: parseFloat(pnl.toFixed(2)) };
    }
    if (stop && currentPrice <= stop) {
      const pnl = ((stop - entry) / entry) * 100;
      return { status: 'loss', pnl: parseFloat(pnl.toFixed(2)) };
    }
  } else {
    // SHORT position
    if (target && currentPrice <= target) {
      const pnl = ((entry - target) / entry) * 100;
      return { status: 'win', pnl: parseFloat(pnl.toFixed(2)) };
    }
    if (stop && currentPrice >= stop) {
      const pnl = ((entry - stop) / entry) * 100;
      return { status: 'loss', pnl: parseFloat(pnl.toFixed(2)) };
    }
  }

  return { status: 'ongoing', pnl: null };
}

async function fetchCurrentPrice(
  ticker: string,
  marketType: string,
  mappingsMap: Map<string, TickerMapping>
): Promise<number | null> {
  try {
    const tickerUpper = ticker.toUpperCase();
    const mapping = mappingsMap.get(tickerUpper);

    if (!mapping) {
      console.log(`No mapping found for ticker ${ticker}`);
      return null;
    }

    if (marketType === 'crypto') {
      // Use CoinGecko API
      const url = `https://api.coingecko.com/api/v3/simple/price?ids=${mapping.api_symbol}&vs_currencies=usd`;
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error(`CoinGecko API error: ${response.status}`);
        return null;
      }

      const data = await response.json();
      return data[mapping.api_symbol]?.usd || null;
    }

    // For forex and stocks, return null for now (can be extended later)
    console.log(`Market type ${marketType} not yet supported for live prices`);
    return null;
  } catch (error) {
    console.error(`Error fetching price for ${ticker}:`, error);
    return null;
  }
}

async function updateTraderPerformance(supabaseClient: any, authorId: string) {
  try {
    console.log(`Updating performance for trader ${authorId}`);

    // Fetch all signals for this trader
    const { data: allSignals, error } = await supabaseClient
      .from('signal_tracking')
      .select('status, pnl_percentage, created_at')
      .eq('author_id', authorId);

    if (error) {
      console.error('Error fetching trader signals:', error);
      return;
    }

    // Calculate stats
    const total = allSignals.length;
    const wins = allSignals.filter((s: any) => s.status === 'win').length;
    const losses = allSignals.filter((s: any) => s.status === 'loss').length;
    const ongoing = allSignals.filter((s: any) => s.status === 'ongoing').length;
    const winRate = wins + losses > 0 ? (wins / (wins + losses)) * 100 : 0;

    const winSignals = allSignals.filter((s: any) => s.status === 'win' && s.pnl_percentage !== null);
    const lossSignals = allSignals.filter((s: any) => s.status === 'loss' && s.pnl_percentage !== null);

    const avgWinPnl = winSignals.length > 0
      ? winSignals.reduce((sum: number, s: any) => sum + s.pnl_percentage, 0) / winSignals.length
      : 0;

    const avgLossPnl = lossSignals.length > 0
      ? lossSignals.reduce((sum: number, s: any) => sum + s.pnl_percentage, 0) / lossSignals.length
      : 0;

    const allPnls = [...winSignals, ...lossSignals].map((s: any) => s.pnl_percentage);
    const bestTradePnl = allPnls.length > 0 ? Math.max(...allPnls) : 0;
    const worstTradePnl = allPnls.length > 0 ? Math.min(...allPnls) : 0;
    const totalPnl = allPnls.reduce((sum: number, pnl: number) => sum + pnl, 0);

    // Calculate last 30 days stats
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const recentSignals = allSignals.filter((s: any) => new Date(s.created_at) >= thirtyDaysAgo);
    const last30dWins = recentSignals.filter((s: any) => s.status === 'win').length;
    const last30dLosses = recentSignals.filter((s: any) => s.status === 'loss').length;
    const last30dWinRate = last30dWins + last30dLosses > 0
      ? (last30dWins / (last30dWins + last30dLosses)) * 100
      : 0;

    // Upsert performance record
    const { error: upsertError } = await supabaseClient
      .from('trader_performance')
      .upsert({
        user_id: authorId,
        total_signals: total,
        wins,
        losses,
        ongoing,
        win_rate: parseFloat(winRate.toFixed(2)),
        avg_win_pnl: parseFloat(avgWinPnl.toFixed(2)),
        avg_loss_pnl: parseFloat(avgLossPnl.toFixed(2)),
        best_trade_pnl: parseFloat(bestTradePnl.toFixed(2)),
        worst_trade_pnl: parseFloat(worstTradePnl.toFixed(2)),
        total_pnl: parseFloat(totalPnl.toFixed(2)),
        last_30d_wins: last30dWins,
        last_30d_losses: last30dLosses,
        last_30d_win_rate: parseFloat(last30dWinRate.toFixed(2)),
        updated_at: new Date().toISOString()
      });

    if (upsertError) {
      console.error('Error upserting trader performance:', upsertError);
    } else {
      console.log('Trader performance updated successfully');
    }
  } catch (error) {
    console.error('Error in updateTraderPerformance:', error);
  }
}
