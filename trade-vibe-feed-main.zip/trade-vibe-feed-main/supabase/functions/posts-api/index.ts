import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user from JWT token
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (req.method === 'POST') {
      // Create new post
      const body = await req.json();
      const { content, tickers, risk_level, trading_info, image_url, market_type, trade_direction } = body;

      if (!content || !content.trim()) {
        return new Response(
          JSON.stringify({ error: 'Content is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Insert post
      const { data: post, error: insertError } = await supabase
        .from('posts')
        .insert({
          content: content.trim(),
          author_id: user.id,
          tickers: tickers || [],
          risk_level: risk_level || 'medium',
          market_type: market_type || 'stocks',
          trade_direction: trade_direction || 'long',
          trade_meta: trading_info || {},
          image_url: image_url || null,
        })
        .select()
        .single();

      if (insertError) {
        console.error('Insert error:', insertError);
        return new Response(
          JSON.stringify({ error: 'Failed to create post' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Auto-create signal tracking entry if trade details exist
      const ticker = tickers && tickers.length > 0 ? tickers[0] : null;
      
      if (!ticker && trading_info?.entry_price && trading_info?.target_price) {
        console.error('No ticker provided for signal tracking - skipping tracking entry');
      }
      
      if (post && trading_info?.entry_price && trading_info?.target_price && ticker) {
        const timeframeMap: Record<string, number> = {
          '1m': 5 * 60 * 1000,
          '5m': 30 * 60 * 1000,
          '15m': 2 * 60 * 60 * 1000,
          '1h': 8 * 60 * 60 * 1000,
          '4h': 24 * 60 * 60 * 1000,
          '1d': 7 * 24 * 60 * 60 * 1000,
          '1w': 30 * 24 * 60 * 60 * 1000,
        };

        const timeframe = trading_info.timeframe || '1d';
        const expirationMs = timeframeMap[timeframe] || timeframeMap['1d'];
        const expiresAt = new Date(Date.now() + expirationMs).toISOString();

        const { error: trackingError } = await supabase
          .from('signal_tracking')
          .insert({
            signal_type: 'post',
            signal_id: post.id,
            author_id: user.id,
            ticker: ticker,
            entry_price: trading_info.entry_price,
            stop_loss: trading_info.stop_loss || null,
            target_price: trading_info.target_price,
            trade_direction: trade_direction || 'long',
            market_type: market_type || 'stocks',
            status: 'ongoing',
            expires_at: expiresAt,
          });

        if (trackingError) {
          console.error('Failed to create signal tracking entry:', trackingError);
          // Don't fail the post creation, just log the error
        } else {
          console.log('Signal tracking entry created for post:', post.id);
        }
      }

      // Fetch the user profile separately
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('handle, display_name, avatar_url, verified_status, reputation_last30')
        .eq('id', user.id)
        .single();

      const postWithProfile = {
        ...post,
        profiles: profile || {
          handle: 'unknown',
          display_name: 'Unknown User',
          avatar_url: '/placeholder.svg',
          verified_status: 'unverified',
          reputation_last30: 0
        }
      };

      return new Response(
        JSON.stringify({ success: true, post: postWithProfile }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );

    } else if (req.method === 'GET') {
      // Fetch posts
      const url = new URL(req.url);
      const limit = parseInt(url.searchParams.get('limit') || '10');
      const offset = parseInt(url.searchParams.get('offset') || '0');

      const { data: posts, error: fetchError } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (fetchError) {
        console.error('Fetch error:', fetchError);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch posts' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Fetch related data separately
      const authorIds = [...new Set(posts.map(post => post.author_id))];
      const postIds = posts.map(post => post.id);

      const [profilesResult, scoresResult, votesResult, savedResult, trackingResult] = await Promise.all([
        supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url, verified_status, reputation_last30')
          .in('id', authorIds),
        supabase
          .from('post_scores')
          .select('post_id, useful_count, not_useful_count, net_score')
          .in('post_id', postIds),
        supabase
          .from('votes')
          .select('post_id, user_id, value')
          .in('post_id', postIds)
          .eq('user_id', user.id),
        supabase
          .from('saved_posts')
          .select('post_id, user_id')
          .in('post_id', postIds)
          .eq('user_id', user.id),
        supabase
          .from('signal_tracking')
          .select('*')
          .eq('signal_type', 'post')
          .in('signal_id', postIds)
      ]);

      const profiles = profilesResult.data || [];
      const scores = scoresResult.data || [];
      const votes = votesResult.data || [];
      const saved = savedResult.data || [];
      const tracking = trackingResult.data || [];

      // Transform posts to match frontend format
      const transformedPosts = posts.map(post => {
        const profile = profiles.find(p => p.id === post.author_id);
        const postScore = scores.find(s => s.post_id === post.id);
        const userVote = votes.find(v => v.post_id === post.id);
        const isSaved = saved.some(s => s.post_id === post.id);
        const signalTracking = tracking.find(t => t.signal_id === post.id);

        return {
          id: post.id,
          author: {
            username: profile?.display_name || profile?.handle || 'unknown',
            avatar: profile?.avatar_url || '/placeholder.svg',
            verified: profile?.verified_status === 'verified' || profile?.verified_status === 'manual',
            reputation: profile?.reputation_last30 || 0,
            isFollowed: false, // TODO: Check follow status
          },
          content: {
            text: post.content,
            image: post.image_url,
            tickers: post.tickers || [],
            riskLevel: post.risk_level || 'medium',
            marketType: post.market_type || 'stocks',
            tradeDirection: post.trade_direction || 'long',
          },
          engagement: {
            useful: postScore?.useful_count || 0,
            notUseful: postScore?.not_useful_count || 0,
            userVote: userVote?.value || null,
            isSaved: isSaved,
          },
          tradeMeta: post.trade_meta || {},
          signalTracking: signalTracking ? {
            id: signalTracking.id,
            signal_id: signalTracking.signal_id,
            signal_type: signalTracking.signal_type,
            ticker: signalTracking.ticker,
            entry_price: signalTracking.entry_price,
            target_price: signalTracking.target_price,
            stop_loss: signalTracking.stop_loss,
            current_price: signalTracking.current_price,
            pnl_percentage: signalTracking.pnl_percentage,
            status: signalTracking.status,
            trade_direction: signalTracking.trade_direction,
            market_type: signalTracking.market_type,
            created_at: signalTracking.created_at,
            updated_at: signalTracking.updated_at,
            last_checked_at: signalTracking.last_checked_at,
            closed_at: signalTracking.closed_at,
          } : undefined,
          timestamp: new Date(post.created_at).toLocaleString(),
        };
      });

      return new Response(
        JSON.stringify({ posts: transformedPosts }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in posts-api function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});