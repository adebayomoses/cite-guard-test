import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const CACHE_TTL_MINUTES = 5; // Cache freshness threshold

function parseEconomicCalendarXML(xmlText: string) {
  const events: any[] = [];
  
  const eventMatches = xmlText.matchAll(/<event>(.*?)<\/event>/gs);
  
  for (const match of eventMatches) {
    const eventXml = match[1];
    
    const getField = (field: string) => {
      const regex = new RegExp(`<${field}>(.*?)<\/${field}>`, 's');
      const match = eventXml.match(regex);
      return match ? match[1].trim() : '';
    };
    
    const title = getField('title');
    const country = getField('country');
    const date = getField('date');
    const impact = getField('impact');
    const forecast = getField('forecast');
    const previous = getField('previous');
    
    const categoryMap: Record<string, string> = {
      'High': 'economy',
      'Medium': 'economy', 
      'Low': 'general'
    };
    
    let summary = `${country} economic event`;
    if (forecast && previous) {
      summary = `Forecast: ${forecast}, Previous: ${previous}`;
    } else if (previous) {
      summary = `Previous: ${previous}`;
    }
    
    const countryImageMap: Record<string, string> = {
      'USD': 'https://images.unsplash.com/photo-1509023464722-18d996393ca8?w=400',
      'EUR': 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=400',
      'GBP': 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400',
      'JPY': 'https://images.unsplash.com/photo-1492571350019-22de08371fd3?w=400',
      'Default': 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400'
    };
    
    events.push({
      title: `${impact ? `[${impact}] ` : ''}${title}`,
      summary,
      url: 'https://www.myfxbook.com/forex-economic-calendar',
      source: `Myfxbook - ${country}`,
      published_at: date || new Date().toISOString(),
      image_url: countryImageMap[country] || countryImageMap['Default'],
      category: categoryMap[impact] || 'general'
    });
  }
  
  events.sort((a, b) => new Date(b.published_at).getTime() - new Date(a.published_at).getTime());
  
  return events;
}

// Helper to check if cached data is fresh
function isCacheFresh(lastUpdated: string | null): boolean {
  if (!lastUpdated) return false;
  const cacheAge = Date.now() - new Date(lastUpdated).getTime();
  return cacheAge < CACHE_TTL_MINUTES * 60 * 1000;
}

// Helper to fetch with batching and rate limit handling
async function fetchInBatches<T>(
  items: T[],
  fetchFn: (item: T) => Promise<any>,
  batchSize: number = 8,
  delayMs: number = 1000
): Promise<any[]> {
  const results: any[] = [];
  
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map(fetchFn));
    results.push(...batchResults);
    
    // Add delay between batches to respect rate limits
    if (i + batchSize < items.length) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
  
  return results;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const url = new URL(req.url);
    const pathParts = url.pathname.split('/').filter(Boolean);
    const endpoint = pathParts[pathParts.length - 1];

    console.log(`Market Data API request: ${req.method} ${endpoint}`);

    // POST /prices - Fetch live prices
    if (endpoint === 'prices' && req.method === 'POST') {
      const body = await req.json();
      const marketType = body.market || 'crypto';
      
      // CRYPTO PRICES (CoinGecko - free, no rate limit issues)
      if (marketType === 'crypto') {
        const cryptoIds = 'bitcoin,ethereum,binancecoin,solana,ripple,cardano,dogecoin,polygon,polkadot,litecoin';
        const response = await fetch(
          `https://api.coingecko.com/api/v3/simple/price?ids=${cryptoIds}&vs_currencies=usd&include_24hr_change=true`,
          { headers: { 'Accept': 'application/json' } }
        );
        
        if (!response.ok) {
          throw new Error(`CoinGecko API error: ${response.status}`);
        }

        const data = await response.json();
        
        const prices = Object.entries(data).map(([id, values]: [string, any]) => ({
          symbol: `${id.toUpperCase()}/USD`,
          name: id.charAt(0).toUpperCase() + id.slice(1),
          current_price: values.usd,
          percent_change_24h: values.usd_24h_change || 0,
          price_change_24h: (values.usd * (values.usd_24h_change || 0)) / 100,
          market_type: 'crypto',
          last_updated: new Date().toISOString()
        }));

        for (const price of prices) {
          await supabaseClient
            .from('market_prices')
            .upsert(price, { onConflict: 'symbol' });
        }

        // Trigger price alerts check after updating prices
        try {
          const alertCheckResponse = await fetch(
            `${Deno.env.get('SUPABASE_URL')}/functions/v1/check-price-alerts`,
            {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${Deno.env.get('SUPABASE_ANON_KEY')}`,
                'Content-Type': 'application/json'
              }
            }
          );
          const alertResult = await alertCheckResponse.json();
          console.log('Price alerts check result:', alertResult);
        } catch (alertErr) {
          console.error('Error checking price alerts:', alertErr);
        }

        return new Response(JSON.stringify(prices), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // FOREX PRICES (Twelve Data API with caching)
      if (marketType === 'forex') {
        const forexPairs = [
          { ticker: 'EUR/USD', symbol: 'EUR/USD', name: 'Euro / US Dollar' },
          { ticker: 'GBP/USD', symbol: 'GBP/USD', name: 'British Pound / US Dollar' },
          { ticker: 'USD/JPY', symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen' },
          { ticker: 'AUD/USD', symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar' },
          { ticker: 'USD/CAD', symbol: 'USD/CAD', name: 'US Dollar / Canadian Dollar' },
          { ticker: 'USD/CHF', symbol: 'USD/CHF', name: 'US Dollar / Swiss Franc' },
          { ticker: 'NZD/USD', symbol: 'NZD/USD', name: 'New Zealand Dollar / US Dollar' },
          { ticker: 'EUR/GBP', symbol: 'EUR/GBP', name: 'Euro / British Pound' },
          { ticker: 'EUR/JPY', symbol: 'EUR/JPY', name: 'Euro / Japanese Yen' },
          { ticker: 'GBP/JPY', symbol: 'GBP/JPY', name: 'British Pound / Japanese Yen' },
          { ticker: 'AUD/JPY', symbol: 'AUD/JPY', name: 'Australian Dollar / Japanese Yen' },
          { ticker: 'EUR/AUD', symbol: 'EUR/AUD', name: 'Euro / Australian Dollar' },
          { ticker: 'GBP/AUD', symbol: 'GBP/AUD', name: 'British Pound / Australian Dollar' },
          { ticker: 'EUR/CAD', symbol: 'EUR/CAD', name: 'Euro / Canadian Dollar' },
          { ticker: 'USD/SGD', symbol: 'USD/SGD', name: 'US Dollar / Singapore Dollar' },
          { ticker: 'USD/HKD', symbol: 'USD/HKD', name: 'US Dollar / Hong Kong Dollar' },
          { ticker: 'USD/ZAR', symbol: 'USD/ZAR', name: 'US Dollar / South African Rand' },
          { ticker: 'USD/MXN', symbol: 'USD/MXN', name: 'US Dollar / Mexican Peso' },
        ];

        // Step 1: Check cache first
        const { data: cachedData } = await supabaseClient
          .from('market_prices')
          .select('*')
          .eq('market_type', 'forex');

        const cachedPrices = cachedData || [];
        const freshCachedPrices = cachedPrices.filter(p => isCacheFresh(p.last_updated));
        
        // If we have fresh cached data for most pairs, return it immediately
        if (freshCachedPrices.length >= forexPairs.length * 0.8) {
          console.log('Returning fresh cached forex data');
          return new Response(JSON.stringify(freshCachedPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Step 2: Fetch fresh data in batches
        const API_KEY = Deno.env.get('TWELVEDATA_API_KEY');
        let rateLimited = false;
        
        const fetchForexPrice = async (pair: typeof forexPairs[0]) => {
          if (rateLimited) return null;
          
          try {
            const quoteResponse = await fetch(
              `https://api.twelvedata.com/quote?symbol=${pair.symbol}&apikey=${API_KEY}`
            );
            const quoteData = await quoteResponse.json();
            
            if (quoteData.code === 429) {
              console.log('Rate limit reached for forex');
              rateLimited = true;
              return null;
            }
            
            const price = parseFloat(quoteData.close || quoteData.price || 0);
            if (price === 0) return null;
            
            const change = parseFloat(quoteData.change || 0);
            const percentChange = parseFloat(quoteData.percent_change || 0);
            
            return {
              symbol: pair.ticker,
              name: pair.name,
              current_price: price,
              price_change_24h: change,
              percent_change_24h: percentChange,
              market_type: 'forex',
              last_updated: new Date().toISOString(),
            };
          } catch (err) {
            console.error(`Error fetching ${pair.symbol}:`, err);
            return null;
          }
        };

        // Fetch in batches of 8 with 1 second delay between batches
        const forexResults = await fetchInBatches(forexPairs, fetchForexPrice, 8, 1000);
        const newForexPrices = forexResults.filter(p => p !== null);
        
        // Step 3: Update cache with new data
        if (newForexPrices.length > 0) {
          for (const price of newForexPrices) {
            await supabaseClient
              .from('market_prices')
              .upsert(price, { onConflict: 'symbol' });
          }
        }

        // Step 4: Return best available data (new + cached fallback)
        if (newForexPrices.length > 0) {
          return new Response(JSON.stringify(newForexPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        
        // Fallback to any cached data if API failed
        if (cachedPrices.length > 0) {
          console.log('Returning stale cached forex data as fallback');
          return new Response(JSON.stringify(cachedPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        return new Response(JSON.stringify([]), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // STOCK PRICES (Twelve Data API with caching)
      if (marketType === 'stocks') {
        const stockSymbols = [
          { ticker: 'AAPL', name: 'Apple Inc.' },
          { ticker: 'GOOGL', name: 'Alphabet Inc.' },
          { ticker: 'MSFT', name: 'Microsoft Corporation' },
          { ticker: 'TSLA', name: 'Tesla Inc.' },
          { ticker: 'AMZN', name: 'Amazon.com Inc.' },
          { ticker: 'NVDA', name: 'NVIDIA Corporation' },
          { ticker: 'META', name: 'Meta Platforms Inc.' },
          { ticker: 'NFLX', name: 'Netflix Inc.' },
          { ticker: 'AMD', name: 'Advanced Micro Devices' },
          { ticker: 'INTC', name: 'Intel Corporation' },
          { ticker: 'CRM', name: 'Salesforce Inc.' },
          { ticker: 'ORCL', name: 'Oracle Corporation' },
          { ticker: 'ADBE', name: 'Adobe Inc.' },
          { ticker: 'PYPL', name: 'PayPal Holdings' },
          { ticker: 'DIS', name: 'Walt Disney Company' },
          { ticker: 'V', name: 'Visa Inc.' },
          { ticker: 'MA', name: 'Mastercard Inc.' },
          { ticker: 'JPM', name: 'JPMorgan Chase & Co.' },
          { ticker: 'BAC', name: 'Bank of America' },
          { ticker: 'WMT', name: 'Walmart Inc.' },
          { ticker: 'KO', name: 'Coca-Cola Company' },
          { ticker: 'PEP', name: 'PepsiCo Inc.' },
          { ticker: 'XOM', name: 'Exxon Mobil Corporation' },
          { ticker: 'CVX', name: 'Chevron Corporation' },
        ];

        // Step 1: Check cache first
        const { data: cachedData } = await supabaseClient
          .from('market_prices')
          .select('*')
          .eq('market_type', 'stocks');

        const cachedPrices = cachedData || [];
        const freshCachedPrices = cachedPrices.filter(p => isCacheFresh(p.last_updated));
        
        // If we have fresh cached data for most stocks, return it immediately
        if (freshCachedPrices.length >= stockSymbols.length * 0.8) {
          console.log('Returning fresh cached stock data');
          return new Response(JSON.stringify(freshCachedPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Step 2: Fetch fresh data in batches
        const API_KEY = Deno.env.get('TWELVEDATA_API_KEY');
        let rateLimited = false;
        
        const fetchStockPrice = async (stock: typeof stockSymbols[0]) => {
          if (rateLimited) return null;
          
          try {
            const quoteResponse = await fetch(
              `https://api.twelvedata.com/quote?symbol=${stock.ticker}&apikey=${API_KEY}`
            );
            const quoteData = await quoteResponse.json();
            
            if (quoteData.code === 429) {
              console.log('Rate limit reached for stocks');
              rateLimited = true;
              return null;
            }
            
            const price = parseFloat(quoteData.close || quoteData.price || 0);
            if (price === 0) return null;
            
            const change = parseFloat(quoteData.change || 0);
            const percentChange = parseFloat(quoteData.percent_change || 0);
            
            return {
              symbol: stock.ticker,
              name: stock.name,
              current_price: price,
              price_change_24h: change,
              percent_change_24h: percentChange,
              market_type: 'stocks',
              last_updated: new Date().toISOString(),
            };
          } catch (err) {
            console.error(`Error fetching ${stock.ticker}:`, err);
            return null;
          }
        };

        // Fetch in batches of 8 with 1 second delay between batches
        const stockResults = await fetchInBatches(stockSymbols, fetchStockPrice, 8, 1000);
        const newStockPrices = stockResults.filter(p => p !== null);
        
        // Step 3: Update cache with new data
        if (newStockPrices.length > 0) {
          for (const price of newStockPrices) {
            await supabaseClient
              .from('market_prices')
              .upsert(price, { onConflict: 'symbol' });
          }
        }

        // Step 4: Return best available data (new + cached fallback)
        if (newStockPrices.length > 0) {
          return new Response(JSON.stringify(newStockPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        
        // Fallback to any cached data if API failed
        if (cachedPrices.length > 0) {
          console.log('Returning stale cached stock data as fallback');
          return new Response(JSON.stringify(cachedPrices), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        return new Response(JSON.stringify([]), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify([]), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST /news - Fetch Myfxbook economic calendar
    if (endpoint === 'news' && req.method === 'POST') {
      const body = await req.json();
      const category = body.category || 'general';
      const limit = body.limit || 20;
      
      const now = new Date();
      const startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      const formatDate = (date: Date) => {
        return date.toISOString().slice(0, 16).replace('T', ' ');
      };
      
      const myfxbookUrl = `https://www.myfxbook.com/calendar_statement.xml?start=${formatDate(startDate)}&end=${formatDate(endDate)}&filter=2-3`;
      
      console.log('Fetching from Myfxbook:', myfxbookUrl);
      
      const response = await fetch(myfxbookUrl);
      
      if (!response.ok) {
        throw new Error(`Myfxbook API error: ${response.status}`);
      }
      
      const xmlText = await response.text();
      
      const events = parseEconomicCalendarXML(xmlText);
      
      const filteredEvents = category === 'general' 
        ? events 
        : events.filter(e => e.category === category);
      
      const limitedEvents = filteredEvents.slice(0, limit);
      
      for (const article of limitedEvents) {
        await supabaseClient
          .from('market_news')
          .upsert({
            title: article.title,
            summary: article.summary,
            url: article.url,
            source: article.source,
            published_at: article.published_at,
            image_url: article.image_url,
            category: article.category
          }, { onConflict: 'url' });
      }
      
      return new Response(JSON.stringify(limitedEvents), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(
      JSON.stringify({ error: 'Invalid endpoint' }), 
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in market-data-api:', error);
    return new Response(
      JSON.stringify({ error: error.message }), 
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
