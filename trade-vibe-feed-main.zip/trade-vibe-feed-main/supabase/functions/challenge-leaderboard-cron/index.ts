import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting leaderboard update cron job...');

    // Get all live challenges
    const { data: liveChallenges } = await supabase
      .from('challenges')
      .select('id, metric, start_at, end_at')
      .lte('start_at', new Date().toISOString())
      .gte('end_at', new Date().toISOString());

    if (!liveChallenges || liveChallenges.length === 0) {
      console.log('No live challenges found');
      return new Response(JSON.stringify({ message: 'No live challenges to update' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Found ${liveChallenges.length} live challenges`);

    // Process each challenge
    for (const challenge of liveChallenges) {
      console.log(`Processing challenge ${challenge.id} with metric ${challenge.metric}`);
      
      // Get all participants
      const { data: participants } = await supabase
        .from('challenge_entries')
        .select('user_id')
        .eq('challenge_id', challenge.id);

      if (!participants || participants.length === 0) {
        console.log(`No participants in challenge ${challenge.id}`);
        continue;
      }

      const userScores = [];

      // Calculate scores based on metric
      for (const participant of participants) {
        let score = 0;

        switch (challenge.metric) {
          case 'useful_rate': {
            // Get posts during challenge period
            const { data: posts } = await supabase
              .from('posts')
              .select(`
                id,
                votes:votes!inner(value)
              `)
              .eq('author_id', participant.user_id)
              .gte('created_at', challenge.start_at)
              .lte('created_at', challenge.end_at);

            if (posts && posts.length > 0) {
              let totalVotes = 0;
              let usefulVotes = 0;

              posts.forEach(post => {
                post.votes.forEach((vote: any) => {
                  totalVotes++;
                  if (vote.value === 1) usefulVotes++;
                });
              });

              score = totalVotes > 0 ? (usefulVotes / totalVotes) * 100 : 0;
            }
            break;
          }

          case 'net_votes': {
            // Get net score from post_scores for posts during challenge period
            const { data: postScores } = await supabase
              .from('posts')
              .select(`
                post_scores:post_scores!inner(net_score)
              `)
              .eq('author_id', participant.user_id)
              .gte('created_at', challenge.start_at)
              .lte('created_at', challenge.end_at);

            if (postScores) {
              score = postScores.reduce((sum, post) => {
                return sum + (post.post_scores[0]?.net_score || 0);
              }, 0);
            }
            break;
          }

          case 'consistency': {
            // Weighted combination: useful_rate (60%) + post_with_chart_ratio (40%)
            const { data: posts } = await supabase
              .from('posts')
              .select(`
                id,
                image_url,
                votes:votes!inner(value)
              `)
              .eq('author_id', participant.user_id)
              .gte('created_at', challenge.start_at)
              .lte('created_at', challenge.end_at);

            if (posts && posts.length > 0) {
              // Calculate useful rate
              let totalVotes = 0;
              let usefulVotes = 0;
              let postsWithCharts = 0;

              posts.forEach(post => {
                if (post.image_url) postsWithCharts++;
                
                post.votes.forEach((vote: any) => {
                  totalVotes++;
                  if (vote.value === 1) usefulVotes++;
                });
              });

              const usefulRate = totalVotes > 0 ? (usefulVotes / totalVotes) * 100 : 0;
              const chartRatio = (postsWithCharts / posts.length) * 100;
              
              score = (usefulRate * 0.6) + (chartRatio * 0.4);
            }
            break;
          }

          default:
            score = 0;
        }

        userScores.push({
          user_id: participant.user_id,
          score: score
        });
      }

      // Sort by score descending and assign ranks
      userScores.sort((a, b) => b.score - a.score);
      
      // Update challenge_scores table
      for (let i = 0; i < userScores.length; i++) {
        const userScore = userScores[i];
        
        await supabase
          .from('challenge_scores')
          .upsert({
            challenge_id: challenge.id,
            user_id: userScore.user_id,
            score: userScore.score,
            rank: i + 1,
            updated_at: new Date().toISOString()
          });
      }

      console.log(`Updated ${userScores.length} scores for challenge ${challenge.id}`);
    }

    return new Response(JSON.stringify({ 
      message: `Updated leaderboards for ${liveChallenges.length} challenges` 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Leaderboard update error:', error);
    return new Response(JSON.stringify({ error: 'Failed to update leaderboards' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});