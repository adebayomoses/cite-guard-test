import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface TrendingTicker {
  ticker: string;
  post_count: number;
  unique_authors: number;
  useful_votes: number;
  not_useful_votes: number;
  comment_count: number;
  score: number;
  last_updated: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Trending feed request received');

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Get trending tickers using the database function
    const { data: trendingTickers, error: trendingError } = await supabase
      .rpc('get_trending_tickers_24h')

    if (trendingError) {
      console.error('Error fetching trending tickers:', trendingError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch trending tickers' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${trendingTickers?.length || 0} trending tickers`);

    // If no trending tickers, return mock data for demo purposes
    if (!trendingTickers || trendingTickers.length === 0) {
      const mockData = {
        trendingTickers: [
          { ticker: '$BTC', score: 150, post_count: 12, unique_authors: 8 },
          { ticker: '$ETH', score: 120, post_count: 9, unique_authors: 6 },
          { ticker: '$AAPL', score: 95, post_count: 8, unique_authors: 5 },
        ],
        posts: []
      };
      
      return new Response(
        JSON.stringify(mockData),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract top ticker symbols
    const topTickers = trendingTickers.map((t: TrendingTicker) => t.ticker);
    console.log('Top tickers:', topTickers);

    // Get posts that contain these trending tickers
    const { data: posts, error: postsError } = await supabase
      .from('posts')
      .select(`
        id,
        content,
        tickers,
        risk_level,
        trade_meta,
        image_url,
        created_at,
        author_id,
        profiles:author_id (
          handle,
          display_name,
          avatar_url,
          verified_status
        )
      `)
      .overlaps('tickers', topTickers)
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
      .order('created_at', { ascending: false })
      .limit(20);

    if (postsError) {
      console.error('Error fetching posts:', postsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch posts' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${posts?.length || 0} trending posts`);

    // Get engagement data for posts
    const postIds = posts?.map(p => p.id) || [];
    
    const [votesResult, scoresResult] = await Promise.all([
      supabase
        .from('votes')
        .select('post_id, value')
        .in('post_id', postIds),
      supabase
        .from('post_scores')
        .select('post_id, useful_count, not_useful_count')
        .in('post_id', postIds)
    ]);

    // Process engagement data
    const votesByPost = new Map();
    votesResult.data?.forEach(vote => {
      if (!votesByPost.has(vote.post_id)) {
        votesByPost.set(vote.post_id, { useful: 0, notUseful: 0 });
      }
      if (vote.value === 1) {
        votesByPost.get(vote.post_id).useful++;
      } else if (vote.value === -1) {
        votesByPost.get(vote.post_id).notUseful++;
      }
    });

    const scoresByPost = new Map();
    scoresResult.data?.forEach(score => {
      scoresByPost.set(score.post_id, {
        useful: score.useful_count || 0,
        notUseful: score.not_useful_count || 0
      });
    });

    // Format posts with engagement data
    const formattedPosts = posts?.map(post => {
      const votes = votesByPost.get(post.id) || scoresByPost.get(post.id) || { useful: 0, notUseful: 0 };
      
      return {
        id: post.id,
        author: {
          username: post.profiles?.handle || 'anonymous',
          avatar: post.profiles?.avatar_url,
          verified: post.profiles?.verified_status !== 'unverified',
          reputation: 75 // Default reputation for demo
        },
        content: {
          text: post.content,
          tickers: post.tickers || [],
          riskLevel: post.risk_level || 'medium'
        },
        engagement: {
          useful: votes.useful,
          notUseful: votes.notUseful,
          userVote: null,
          isSaved: false
        },
        tradeMeta: post.trade_meta || {},
        timestamp: post.created_at
      };
    }) || [];

    // Calculate trending score for each ticker to include in response
    const formattedTickers = trendingTickers.map((ticker: TrendingTicker) => ({
      ticker: ticker.ticker,
      score: Number(ticker.score),
      post_count: ticker.post_count,
      unique_authors: ticker.unique_authors,
      change: Math.random() * 10 - 5 // Mock percentage change for demo
    }));

    const response = {
      trendingTickers: formattedTickers,
      posts: formattedPosts
    };

    console.log('Returning trending feed response');

    return new Response(
      JSON.stringify(response),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Unexpected error in trending function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});