import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.3";

type Json = Record<string, any>;
const json = (b: Json, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: {
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    },
  });

Deno.serve(async (req: Request) => {
  try {
    const url = new URL(req.url);
    const seg = url.pathname.split("/").filter(Boolean);
    // e.g. /functions/v1/lifestyle-api/feed -> ['functions','v1','lifestyle-api','feed']
    const last = seg[seg.length - 1];
    const prev = seg[seg.length - 2];

    if (req.method === "OPTIONS")
      return new Response("ok", {
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
          "Access-Control-Allow-Headers": "authorization, content-type",
        },
      });

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const db = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });

    // ---- Auth: read Bearer token and resolve user (if any) ----
    const authHeader = req.headers.get("authorization") ?? req.headers.get("Authorization");
    let userId: string | null = null;
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.replace("Bearer ", "").trim();
      const { data, error } = await db.auth.getUser(token);
      if (!error && data?.user) userId = data.user.id;
    }

    // ---- Handlers ----
    async function feed() {
      const mode = url.searchParams.get("mode") ?? "forYou"; // 'forYou' | 'following'
      const limit = parseInt(url.searchParams.get("limit") || "20");
      const offset = parseInt(url.searchParams.get("offset") || "0");
      
      // base query: public videos for now
      let q = db
        .from("lifestyle_videos")
        .select(
          `
            *,
            profiles:author_id (
              id, handle, display_name, avatar_url, verified_status
            )
          `
        )
        .order("created_at", { ascending: false })
        .range(offset, offset + limit - 1);

      if (mode === "following") {
        if (!userId) return json({ videos: [], mode }); // anon users see empty following
        const f = await db.from("follows").select("target_id").eq("user_id", userId);
        const ids = f.data?.map((r: any) => r.target_id) ?? [];
        if (ids.length === 0) return json({ videos: [], mode });
        q = q.in("author_id", ids);
      }

      const { data, error } = await q;
      if (error) {
        console.error("Feed error:", error);
        return json({ error: error.message }, 500);
      }

      // Get user's likes for these videos if authenticated
      let transformedData = data ?? [];
      if (userId && data) {
        const videoIds = data.map(video => video.id);
        const { data: userLikes } = await db
          .from("lifestyle_likes")
          .select("video_id")
          .eq("user_id", userId)
          .in("video_id", videoIds);

        const likedVideoIds = new Set(userLikes?.map(like => like.video_id) || []);
        transformedData = data.map(video => ({
          ...video,
          user_liked: likedVideoIds.has(video.id)
        }));
      }

      return json(transformedData);
    }

    async function upload() {
      if (!userId) return json({ error: "Unauthorized" }, 401);
      const body = await req.json().catch(() => ({}));
      const { caption, tickers = [], hashtags = [], visibility = 'public', video_url, thumbnail_url, duration_seconds } = body;
      
      const { data, error } = await db
        .from("lifestyle_videos")
        .insert({ 
          author_id: userId, 
          caption, 
          tickers, 
          hashtags, 
          visibility,
          video_url,
          thumbnail_url,
          duration_seconds
        })
        .select("*")
        .single();
      
      if (error) {
        console.error("Upload error:", error);
        return json({ error: error.message }, 500);
      }
      return json(data);
    }

    async function like(videoId: string) {
      if (!userId) return json({ error: "Unauthorized" }, 401);
      const existing = await db
        .from("lifestyle_likes")
        .select("*")
        .eq("user_id", userId)
        .eq("video_id", videoId)
        .maybeSingle();

      if (existing.data) {
        await db.from("lifestyle_likes").delete().eq("user_id", userId).eq("video_id", videoId);
      } else {
        await db.from("lifestyle_likes").insert({ user_id: userId, video_id: videoId });
      }

      const count = await db
        .from("lifestyle_likes")
        .select("video_id", { count: "exact", head: true })
        .eq("video_id", videoId);
      await db.from("lifestyle_videos").update({ like_count: count.count ?? 0 }).eq("id", videoId);

      return json({ liked: !existing.data, likeCount: count.count ?? 0 });
    }

    async function comments(videoId: string) {
      if (req.method === "GET") {
        const { data, error } = await db
          .from("lifestyle_comments")
          .select(
            `
              *,
              profiles:author_id ( id, handle, display_name, avatar_url, verified_status )
            `
          )
          .eq("video_id", videoId)
          .order("created_at", { ascending: true });
        if (error) {
          console.error("Get comments error:", error);
          return json({ error: error.message }, 500);
        }
        return json(data ?? []);
      }
      if (!userId) return json({ error: "Unauthorized" }, 401);
      const body = await req.json().catch(() => ({}));
      const { text } = body;
      if (!text || typeof text !== "string") return json({ error: "Invalid text" }, 400);
      const { data, error } = await db
        .from("lifestyle_comments")
        .insert({ video_id: videoId, author_id: userId, text })
        .select(`
          *,
          profiles:author_id ( id, handle, display_name, avatar_url, verified_status )
        `)
        .single();
      if (error) {
        console.error("Create comment error:", error);
        return json({ error: error.message }, 500);
      }
      return json(data);
    }

    async function userVideos(handle: string) {
      const prof = await db.from("profiles").select("id").eq("handle", handle).single();
      if (prof.error) {
        console.error("Profile not found:", prof.error);
        return json({ error: "User not found" }, 404);
      }
      const { data, error } = await db
        .from("lifestyle_videos")
        .select(`
          *,
          profiles:author_id ( id, handle, display_name, avatar_url, verified_status )
        `)
        .eq("author_id", prof.data.id)
        .order("created_at", { ascending: false });
      if (error) {
        console.error("User videos error:", error);
        return json({ error: error.message }, 500);
      }
      return json(data ?? []);
    }

    // ---- Routing ----
    console.log("Lifestyle API request:", req.method, last, prev, seg);
    
    if (req.method === "GET" && last === "feed") return await feed();
    if (req.method === "POST" && last === "upload") return await upload();
    if (req.method === "POST" && last === "like" && prev) return await like(prev);            // .../:id/like
    if (last === "comments" && prev) return await comments(prev);                             // GET/POST .../:id/comments
    if (prev === "user" && req.method === "GET") return await userVideos(last);               // .../user/:handle

    return json({ error: "Not found", seg }, 404);
  } catch (e) {
    console.error("[lifestyle-api] fatal", e);
    return json({ error: "Server error" }, 500);
  }
});