import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user from auth header
    const authHeader = req.headers.get('authorization');
    let userId: string | null = null;
    
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user } } = await supabase.auth.getUser(token);
      userId = user?.id || null;
    }

    const url = new URL(req.url);
    const segments = url.pathname.split('/').filter(Boolean);
    const method = req.method;

    console.log('Events API Request:', method, segments, 'Full URL:', req.url);

    // GET /events/list - List events with optional status filter
    if (method === 'GET' && segments[segments.length - 1] === 'list') {
      const status = url.searchParams.get('status') || 'all';
      const limit = parseInt(url.searchParams.get('limit') || '50');
      
      let query = supabase
        .from('events')
        .select(`
          *,
          host:profiles!events_host_id_fkey(handle, display_name, avatar_url)
        `);

      // Apply status filter
      if (status === 'upcoming') {
        query = query.gte('start_at', new Date().toISOString());
      } else if (status === 'past') {
        query = query.lt('start_at', new Date().toISOString());
      }

      // Apply ordering and limit
      query = query.order('start_at', { ascending: status === 'past' ? false : true }).limit(limit);

      const { data: events, error } = await query;

      if (error) {
        console.error('Error fetching events:', error);
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ events: events || [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // GET /events/:id/ics - Download ICS calendar file
    if (method === 'GET' && segments[segments.length - 1] === 'ics') {
      const eventId = segments[segments.length - 2];
      
      const { data: event, error } = await supabase
        .from('events')
        .select(`
          *,
          host:profiles!events_host_id_fkey(handle, display_name, avatar_url)
        `)
        .eq('id', eventId)
        .single();

      if (error) {
        return new Response(JSON.stringify({ error: 'Event not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Generate ICS content
      const startDate = new Date(event.start_at).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      const endDate = event.end_at 
        ? new Date(event.end_at).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'
        : new Date(new Date(event.start_at).getTime() + 60 * 60 * 1000).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';

      const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Trading Platform//Event//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
UID:${event.id}@tradingplatform.com
DTSTART:${startDate}
DTEND:${endDate}
SUMMARY:${event.title}
DESCRIPTION:${event.description || ''}
LOCATION:${event.location || 'Online'}
URL:${event.url || ''}
ORGANIZER:CN=${event.host?.display_name || 'Unknown'}
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

      return new Response(icsContent, {
        headers: {
          ...corsHeaders,
          'Content-Type': 'text/calendar',
          'Content-Disposition': `attachment; filename="${event.title.replace(/[^a-zA-Z0-9]/g, '_')}.ics"`,
        },
      });
    }

    // GET /events/:id - Get event details
    if (method === 'GET' && segments.length >= 3 && 
        segments[segments.length - 1] !== 'list' && 
        segments[segments.length - 1] !== 'ics') {
      const eventId = segments[segments.length - 1];
      
      console.log('Fetching event details for ID:', eventId);
      
      const { data: event, error } = await supabase
        .from('events')
        .select(`
          *,
          host:profiles!events_host_id_fkey(handle, display_name, avatar_url)
        `)
        .eq('id', eventId)
        .single();

      if (error) {
        return new Response(JSON.stringify({ error: 'Event not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ event }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST /events - Create new event
    if (method === 'POST' && segments[segments.length - 1] === 'events-api') {
      if (!userId) {
        return new Response(JSON.stringify({ error: 'Authentication required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if user can create premium content (Pro rank 500+ XP OR admin)
      const { data: canCreate } = await supabase.rpc('can_create_premium_content', { _user_id: userId });
      
      if (!canCreate) {
        return new Response(JSON.stringify({ 
          error: 'Pro Trader rank required',
          message: 'Creating events requires Pro Trader rank (500+ XP). Keep engaging to level up!'
        }), {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const body = await req.json();
      const { title, description, start_at, end_at, location, url, tags } = body;

      if (!title || !start_at) {
        return new Response(JSON.stringify({ error: 'Missing required fields' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: event, error } = await supabase
        .from('events')
        .insert({
          title,
          description,
          start_at,
          end_at,
          location: location || 'online',
          url,
          tags: tags || [],
          host_id: userId
        })
        .select()
        .single();

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ event }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Events API error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});