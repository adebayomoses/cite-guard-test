import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log("Starting multi-factor reputation calculation...");

    // Fetch reputation config from site_settings
    const { data: settings, error: settingsError } = await supabase
      .from("site_settings")
      .select("key, value")
      .like("key", "reputation_%");

    if (settingsError) {
      console.error("Error fetching settings:", settingsError);
    }

    // Parse settings with defaults
    const getSetting = (key: string, defaultValue: number): number => {
      const setting = settings?.find(s => s.key === key);
      if (setting?.value !== undefined) {
        const parsed = typeof setting.value === 'string' ? parseFloat(setting.value) : Number(setting.value);
        return isNaN(parsed) ? defaultValue : parsed;
      }
      return defaultValue;
    };

    const config = {
      tradingWeight: getSetting('reputation_trading_weight', 50) / 100,
      engagementWeight: getSetting('reputation_engagement_weight', 20) / 100,
      qualityWeight: getSetting('reputation_quality_weight', 20) / 100,
      activityWeight: getSetting('reputation_activity_weight', 10) / 100,
      minSignals: getSetting('reputation_min_signals', 5),
      minVotes: getSetting('reputation_min_votes', 10),
      followerCap: getSetting('reputation_follower_cap', 100),
      commentsCap: getSetting('reputation_comments_cap', 30),
      contentCap: getSetting('reputation_content_cap', 10),
      challengesCap: getSetting('reputation_challenges_cap', 3),
    };

    console.log("Using config:", config);

    // Get all users with their comprehensive metrics from the view
    const { data: metrics, error: metricsError } = await supabase
      .from("user_reputation_metrics")
      .select("*");

    if (metricsError) {
      console.error("Error fetching metrics:", metricsError);
      throw metricsError;
    }

    console.log(`Found ${metrics?.length || 0} users with metrics`);

    const today = new Date().toISOString().split("T")[0];
    let updatedCount = 0;
    let snapshotCount = 0;

    for (const m of metrics || []) {
      // TRADING PERFORMANCE - Min signals required
      let tradingScore = 0;
      if ((m.last_30d_signals || 0) >= config.minSignals) {
        const winRateComponent = (m.last_30d_win_rate || 0) * 0.7;
        const pnlComponent = Math.min((m.total_pnl || 0) / 100, 1) * 30;
        tradingScore = winRateComponent + pnlComponent;
      }

      // COMMUNITY ENGAGEMENT - Capped values
      const followerScore = Math.min((m.follower_count || 0) / config.followerCap, 1) * 50;
      const commentScore = Math.min((m.comments_given_30d || 0) / config.commentsCap, 1) * 50;
      const engagementScore = followerScore + commentScore;

      // CONTENT QUALITY - Min votes required
      let qualityScore = 0;
      if ((m.total_votes_30d || 0) >= config.minVotes) {
        const usefulRateComponent = (m.useful_rate_30d || 0) * 0.8;
        const savesComponent = Math.min((m.saves_received || 0) / 10, 1) * 20;
        qualityScore = usefulRateComponent + savesComponent;
      }

      // CONSISTENCY & ACTIVITY - Activity frequency
      const contentScore = Math.min(((m.posts_30d || 0) + (m.videos_30d || 0)) / config.contentCap, 1) * 50;
      const challengeScore = Math.min((m.challenge_entries || 0) / config.challengesCap, 1) * 50;
      const activityScore = contentScore + challengeScore;

      // FINAL WEIGHTED SCORE (0-100 scale)
      const reputation = Math.round(
        (tradingScore * config.tradingWeight) +
        (engagementScore * config.engagementWeight) +
        (qualityScore * config.qualityWeight) +
        (activityScore * config.activityWeight)
      );

      console.log(`User ${m.user_id}: trading=${tradingScore.toFixed(1)}, engagement=${engagementScore.toFixed(1)}, quality=${qualityScore.toFixed(1)}, activity=${activityScore.toFixed(1)} => rep=${reputation}`);

      // Update profiles.reputation_last30
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ reputation_last30: reputation })
        .eq("id", m.user_id);

      if (updateError) {
        console.error(`Error updating profile ${m.user_id}:`, updateError);
        continue;
      }
      updatedCount++;

      // Insert or update daily snapshot
      const { error: snapshotError } = await supabase
        .from("reputation_snapshots")
        .upsert(
          {
            user_id: m.user_id,
            reputation: reputation,
            snapshot_date: today,
          },
          { onConflict: "user_id,snapshot_date" }
        );

      if (snapshotError) {
        console.error(`Error creating snapshot for ${m.user_id}:`, snapshotError);
        continue;
      }
      snapshotCount++;
    }

    console.log(`Updated ${updatedCount} profiles, created ${snapshotCount} snapshots`);

    return new Response(
      JSON.stringify({
        success: true,
        updated: updatedCount,
        snapshots: snapshotCount,
        date: today,
        config: config,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Reputation cron error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
