import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Admin client: bypasses RLS, used for privileged operations
    const adminClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // User client: respects RLS, used for user-scoped operations
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Get current user
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const url = new URL(req.url);
    const segments = url.pathname.split('/').filter(Boolean);
    const method = req.method;

    console.log('Chat API Request:', method, segments);

    // POST /request - Send chat request
    if (method === 'POST' && segments[segments.length - 1] === 'request') {
      const { userId, introMessage } = await req.json();
      
      if (!userId || userId === user.id) {
        return new Response(
          JSON.stringify({ error: 'Invalid user ID' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if users have blocked each other
      const { data: blocks } = await supabaseClient
        .from('user_blocks')
        .select('*')
        .or(`and(blocker.eq.${user.id},blocked.eq.${userId}),and(blocker.eq.${userId},blocked.eq.${user.id})`);

      if (blocks && blocks.length > 0) {
        return new Response(
          JSON.stringify({ error: 'Unable to send request' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check for existing active request (pending or accepted only)
      const { data: existingRequest } = await supabaseClient
        .from('chat_requests')
        .select('*')
        .or(`and(from_user_id.eq.${user.id},to_user_id.eq.${userId}),and(from_user_id.eq.${userId},to_user_id.eq.${user.id})`)
        .in('status', ['pending', 'accepted'])
        .maybeSingle();

      if (existingRequest) {
        return new Response(
          JSON.stringify({ error: 'Request already exists' }),
          { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create new chat request
      const { data: request, error: requestError } = await supabaseClient
        .from('chat_requests')
        .insert({
          from_user_id: user.id,
          to_user_id: userId,
          intro_message: introMessage || null
        })
        .select('*')
        .single();

      if (requestError) {
        console.error('Error creating chat request:', requestError);
        return new Response(
          JSON.stringify({ error: 'Failed to send request' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, request }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // GET /requests/incoming - Get incoming chat requests
    if (method === 'GET' && segments.length >= 2 && 
        segments[segments.length - 2] === 'requests' && 
        segments[segments.length - 1] === 'incoming') {
      const { data: requests, error } = await supabaseClient
        .from('chat_requests')
        .select(`
          *,
          profiles:from_user_id (
            id,
            handle,
            display_name,
            avatar_url,
            verified_status
          )
        `)
        .eq('to_user_id', user.id)
        .eq('status', 'pending')
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching incoming requests:', error);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch requests' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ requests: requests || [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // GET /requests/outgoing - Get outgoing chat requests
    if (method === 'GET' && segments.length >= 2 && 
        segments[segments.length - 2] === 'requests' && 
        segments[segments.length - 1] === 'outgoing') {
      const { data: requests, error } = await supabaseClient
        .from('chat_requests')
        .select(`
          *,
          profiles:to_user_id (
            id,
            handle,
            display_name,
            avatar_url,
            verified_status
          )
        `)
        .eq('from_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching outgoing requests:', error);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch requests' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ requests: requests || [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /requests/:id/accept - Accept chat request
    if (method === 'POST' && segments.length >= 3 && 
        segments[segments.length - 3] === 'requests' && 
        segments[segments.length - 1] === 'accept') {
      const requestId = segments[segments.length - 2];
      
      // Get the request
      const { data: request, error: requestError } = await supabaseClient
        .from('chat_requests')
        .select('*')
        .eq('id', requestId)
        .eq('to_user_id', user.id)
        .eq('status', 'pending')
        .single();

      if (requestError || !request) {
        return new Response(
          JSON.stringify({ error: 'Request not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create conversation using admin client to bypass RLS
      const { data: newConversation, error: convError } = await adminClient
        .from('conversations')
        .insert({ is_group: false })
        .select('id')
        .single();

      if (convError) {
        console.error('Error creating conversation:', convError);
        return new Response(
          JSON.stringify({ error: 'Failed to create conversation' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add current user (accepter) with user client
      const { error: accepterError } = await supabaseClient
        .from('conversation_participants')
        .insert({ conversation_id: newConversation.id, user_id: user.id });

      if (accepterError) {
        console.error('Error adding accepter participant:', accepterError);
        // Cleanup: delete the conversation
        await adminClient.from('conversations').delete().eq('id', newConversation.id);
        return new Response(
          JSON.stringify({ error: 'Failed to add participants' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add requester with admin client (bypasses RLS)
      const { error: requesterError } = await adminClient
        .from('conversation_participants')
        .insert({ conversation_id: newConversation.id, user_id: request.from_user_id });

      if (requesterError) {
        console.error('Error adding requester participant:', requesterError);
        // Cleanup: delete the conversation
        await adminClient.from('conversations').delete().eq('id', newConversation.id);
        return new Response(
          JSON.stringify({ error: 'Failed to add participants' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update request status
      const { error: updateError } = await supabaseClient
        .from('chat_requests')
        .update({ status: 'accepted' })
        .eq('id', requestId);

      if (updateError) {
        console.error('Error updating request:', updateError);
      }

      return new Response(
        JSON.stringify({ success: true, conversationId: newConversation.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /requests/:id/decline - Decline chat request
    if (method === 'POST' && segments.length >= 3 && 
        segments[segments.length - 3] === 'requests' && 
        segments[segments.length - 1] === 'decline') {
      const requestId = segments[segments.length - 2];
      
      const { error } = await supabaseClient
        .from('chat_requests')
        .update({ status: 'declined' })
        .eq('id', requestId)
        .eq('to_user_id', user.id)
        .eq('status', 'pending');

      if (error) {
        console.error('Error declining request:', error);
        return new Response(
          JSON.stringify({ error: 'Failed to decline request' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /start - Start or get existing conversation (modified for request system)
    if (method === 'POST' && segments[segments.length - 1] === 'start') {
      const { userId } = await req.json();
      
      if (!userId) {
        return new Response(
          JSON.stringify({ error: 'User ID is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if there's an accepted request between these users
      const { data: acceptedRequest } = await supabaseClient
        .from('chat_requests')
        .select('*')
        .or(`and(from_user_id.eq.${user.id},to_user_id.eq.${userId}),and(from_user_id.eq.${userId},to_user_id.eq.${user.id})`)
        .eq('status', 'accepted')
        .maybeSingle();

      if (!acceptedRequest) {
        return new Response(
          JSON.stringify({ error: 'No accepted chat request found. Please send a chat request first.' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if either user has blocked the other
      const { data: blocks } = await supabaseClient
        .from('user_blocks')
        .select('*')
        .or(`and(blocker.eq.${user.id},blocked.eq.${userId}),and(blocker.eq.${userId},blocked.eq.${user.id})`);

      if (blocks && blocks.length > 0) {
        return new Response(
          JSON.stringify({ error: 'Cannot start conversation with blocked user' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Look for existing 1:1 conversation
      const { data: existingConversations } = await supabaseClient
        .from('conversations')
        .select(`
          id,
          conversation_participants!inner (user_id)
        `)
        .eq('is_group', false);

      let conversationId = null;
      
      // Check if there's a conversation with exactly these two users
      for (const conv of existingConversations || []) {
        const participants = conv.conversation_participants.map(p => p.user_id);
        if (participants.length === 2 && 
            participants.includes(user.id) && 
            participants.includes(userId)) {
          conversationId = conv.id;
          break;
        }
      }

      // Create new conversation if none exists
      if (!conversationId) {
        const { data: newConv, error: convError } = await adminClient
          .from('conversations')
          .insert({ is_group: false })
          .select()
          .single();

        if (convError) {
          return new Response(
            JSON.stringify({ error: 'Failed to create conversation' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        conversationId = newConv.id;

        // Add current user with user client
        const { error: currentUserError } = await supabaseClient
          .from('conversation_participants')
          .insert({ conversation_id: conversationId, user_id: user.id });

        if (currentUserError) {
          console.error('Error adding current user participant:', currentUserError);
          // Cleanup: delete the conversation
          await adminClient.from('conversations').delete().eq('id', conversationId);
          return new Response(
            JSON.stringify({ error: 'Failed to add participants' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Add other user with admin client (bypasses RLS)
        const { error: otherUserError } = await adminClient
          .from('conversation_participants')
          .insert({ conversation_id: conversationId, user_id: userId });

        if (otherUserError) {
          console.error('Error adding other user participant:', otherUserError);
          // Cleanup: delete the conversation
          await adminClient.from('conversations').delete().eq('id', conversationId);
          return new Response(
            JSON.stringify({ error: 'Failed to add participants' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }

      return new Response(
        JSON.stringify({ conversationId }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /group/create - Create group chat
    if (method === 'POST' && segments.length >= 2 && segments[segments.length - 2] === 'group' && segments[segments.length - 1] === 'create') {
      const { name, description, memberIds, settings } = await req.json();
      
      if (!name || !memberIds || memberIds.length === 0) {
        return new Response(
          JSON.stringify({ error: 'Group name and at least one member required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const maxMembers = settings?.maxMembers || 100;
      if (memberIds.length + 1 > maxMembers) {
        return new Response(
          JSON.stringify({ error: `Maximum ${maxMembers} members allowed` }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create conversation
      const { data: conversation, error: convError } = await adminClient
        .from('conversations')
        .insert({ is_group: true })
        .select()
        .single();

      if (convError) {
        return new Response(
          JSON.stringify({ error: 'Failed to create group' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create group settings
      const { error: settingsError } = await supabaseClient
        .from('group_settings')
        .insert({
          conversation_id: conversation.id,
          name,
          description: description || null,
          created_by: user.id,
          allow_member_messages: settings?.allowMemberMessages ?? true,
          allow_member_add: settings?.allowMemberAdd ?? false,
          max_members: maxMembers
        });

      if (settingsError) {
        await adminClient.from('conversations').delete().eq('id', conversation.id);
        return new Response(
          JSON.stringify({ error: 'Failed to create group settings' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add creator as admin
      await adminClient.from('group_members').insert({
        conversation_id: conversation.id,
        user_id: user.id,
        role: 'admin',
        added_by: user.id
      });

      await supabaseClient.from('conversation_participants').insert({
        conversation_id: conversation.id,
        user_id: user.id
      });

      // Add other members
      for (const memberId of memberIds) {
        if (memberId !== user.id) {
          await adminClient.from('group_members').insert({
            conversation_id: conversation.id,
            user_id: memberId,
            role: 'member',
            added_by: user.id
          });
          await adminClient.from('conversation_participants').insert({
            conversation_id: conversation.id,
            user_id: memberId
          });
        }
      }

      return new Response(
        JSON.stringify({ success: true, conversationId: conversation.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // GET /group/:conversationId/info - Get group info
    if (method === 'GET' && segments.length >= 3 && segments[segments.length - 3] === 'group' && segments[segments.length - 1] === 'info') {
      const groupConvId = segments[segments.length - 2];
      
      console.log('Getting group info for:', groupConvId);
      
      // First verify user is a participant
      const { data: participant } = await supabaseClient
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      if (!participant) {
        console.log('User not a participant of conversation:', groupConvId);
        return new Response(
          JSON.stringify({ error: 'Not a member of this group' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if this is a server channel
      const { data: conversation } = await adminClient
        .from('conversations')
        .select('parent_server_id')
        .eq('id', groupConvId)
        .single();

      console.log('Conversation parent_server_id:', conversation?.parent_server_id);

      // If it's a server channel, get channel info from server_channels
      if (conversation?.parent_server_id) {
        console.log('This is a server channel, fetching from server_channels');
        
        const { data: channelData, error: channelError } = await adminClient
          .from('server_channels')
          .select('name, description, created_at, updated_at')
          .eq('channel_conversation_id', groupConvId)
          .single();

        console.log('Channel data:', channelData, 'Error:', channelError);

        if (channelError || !channelData) {
          return new Response(
            JSON.stringify({ error: 'Channel not found' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Get parent server settings
        const { data: serverSettings } = await adminClient
          .from('group_settings')
          .select('created_by, max_members')
          .eq('conversation_id', conversation.parent_server_id)
          .single();

        // Get member count from parent server
        const { count: memberCount } = await adminClient
          .from('group_members')
          .select('*', { count: 'exact', head: true })
          .eq('conversation_id', conversation.parent_server_id);

        console.log('Returning channel info with member count:', memberCount);

        return new Response(
          JSON.stringify({
            id: groupConvId,
            conversation_id: groupConvId,
            name: channelData.name,
            description: channelData.description || null,
            avatar_url: null,
            created_by: serverSettings?.created_by || null,
            allow_member_messages: true,
            allow_member_add: false,
            max_members: serverSettings?.max_members || 100,
            memberCount: memberCount || 0,
            created_at: channelData.created_at,
            updated_at: channelData.updated_at,
            isServerChannel: true
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log('Regular group, fetching from group_settings');

      // Regular group - use existing logic
      const { data: groupSettings, error } = await adminClient
        .from('group_settings')
        .select('*')
        .eq('conversation_id', groupConvId)
        .single();

      if (error || !groupSettings) {
        console.log('Group not found:', error);
        return new Response(
          JSON.stringify({ error: 'Group not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { count: memberCount } = await adminClient
        .from('group_members')
        .select('*', { count: 'exact', head: true })
        .eq('conversation_id', groupConvId);

      return new Response(
        JSON.stringify({ ...groupSettings, memberCount: memberCount || 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /group/:conversationId/update - Update group
    if (method === 'POST' && segments.length >= 3 && segments[segments.length - 3] === 'group' && segments[segments.length - 1] === 'update') {
      const groupConvId = segments[segments.length - 2];
      const { name, description, avatarUrl, settings } = await req.json();

      // Check if this is a server channel
      const { data: conversation } = await adminClient
        .from('conversations')
        .select('parent_server_id')
        .eq('id', groupConvId)
        .single();

      // Handle server channels differently
      if (conversation?.parent_server_id) {
        console.log('Updating server channel, checking admin role in parent server');
        
        // Check if user is admin of the parent server
        const { data: member } = await supabaseClient
          .from('group_members')
          .select('role')
          .eq('conversation_id', conversation.parent_server_id)
          .eq('user_id', user.id)
          .single();

        if (!member || member.role !== 'admin') {
          return new Response(
            JSON.stringify({ error: 'Only server admins can update channels' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Update server_channels table
        const channelUpdates: any = {};
        if (name) channelUpdates.name = name;
        if (description !== undefined) channelUpdates.description = description;

        const { error } = await adminClient
          .from('server_channels')
          .update(channelUpdates)
          .eq('channel_conversation_id', groupConvId);

        if (error) {
          console.error('Failed to update channel:', error);
          return new Response(
            JSON.stringify({ error: 'Failed to update channel' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        return new Response(
          JSON.stringify({ success: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Handle regular groups (existing logic)
      // Check if user is admin
      const { data: member } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      if (!member || member.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only admins can update group' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const updates: any = {};
      if (name) updates.name = name;
      if (description !== undefined) updates.description = description;
      if (avatarUrl !== undefined) updates.avatar_url = avatarUrl;
      if (settings?.allowMemberMessages !== undefined) updates.allow_member_messages = settings.allowMemberMessages;
      if (settings?.allowMemberAdd !== undefined) updates.allow_member_add = settings.allowMemberAdd;
      if (settings?.maxMembers !== undefined) updates.max_members = settings.maxMembers;

      const { error } = await supabaseClient
        .from('group_settings')
        .update(updates)
        .eq('conversation_id', groupConvId);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to update group' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // GET /group/:conversationId/members - Get group members
    if (method === 'GET' && segments.length >= 3 && segments[segments.length - 3] === 'group' && segments[segments.length - 1] === 'members') {
      const groupConvId = segments[segments.length - 2];
      
      console.log('Getting members for conversation:', groupConvId);
      
      // First verify user is a participant
      const { data: participant } = await supabaseClient
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      if (!participant) {
        return new Response(
          JSON.stringify({ error: 'Not a member of this group' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if this is a server channel
      const { data: conversation } = await adminClient
        .from('conversations')
        .select('parent_server_id')
        .eq('id', groupConvId)
        .single();

      // Determine which conversation_id to use for querying members
      const memberConversationId = conversation?.parent_server_id || groupConvId;
      
      console.log('Querying members with conversation_id:', memberConversationId, 
        conversation?.parent_server_id ? '(parent server)' : '(direct group)');

      // Use adminClient to bypass RLS after verifying access
      // Step 1: Fetch raw members
      const { data: rawMembers, error: membersError } = await adminClient
        .from('group_members')
        .select('user_id, role, joined_at')
        .eq('conversation_id', memberConversationId)
        .order('joined_at', { ascending: true });

      if (membersError) {
        console.error('Failed to fetch group members:', membersError);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch members' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!rawMembers || rawMembers.length === 0) {
        return new Response(
          JSON.stringify({ members: [] }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Step 2: Fetch profiles for those user IDs
      const userIds = rawMembers.map(m => m.user_id);
      const { data: profiles, error: profilesError } = await adminClient
        .from('profiles')
        .select('id, handle, display_name, avatar_url, verified_status')
        .in('id', userIds);

      if (profilesError) {
        console.error('Failed to fetch profiles:', profilesError);
      }

      // Step 3: Merge members with their profiles
      const profileById = Object.fromEntries((profiles || []).map(p => [p.id, p]));
      const members = rawMembers.map(m => ({
        user_id: m.user_id,
        role: m.role,
        joined_at: m.joined_at,
        profiles: profileById[m.user_id] || {
          id: m.user_id,
          handle: 'unknown',
          display_name: 'Unknown',
          avatar_url: null,
          verified_status: null
        }
      }));

      return new Response(
        JSON.stringify({ members }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /group/:conversationId/members/add - Add members
    if (method === 'POST' && segments.length >= 4 && segments[segments.length - 4] === 'group' && segments[segments.length - 2] === 'members' && segments[segments.length - 1] === 'add') {
      const groupConvId = segments[segments.length - 3];
      const { userIds } = await req.json();

      if (!userIds || userIds.length === 0) {
        return new Response(
          JSON.stringify({ error: 'User IDs required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check permissions
      const { data: groupSettings } = await supabaseClient
        .from('group_settings')
        .select('allow_member_add, max_members, created_by')
        .eq('conversation_id', groupConvId)
        .single();

      const { data: userMember } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      const isAdmin = userMember?.role === 'admin';
      const canAdd = isAdmin || groupSettings?.allow_member_add;

      if (!canAdd) {
        return new Response(
          JSON.stringify({ error: 'You do not have permission to add members' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check max members
      const { count: currentCount } = await supabaseClient
        .from('group_members')
        .select('*', { count: 'exact', head: true })
        .eq('conversation_id', groupConvId);

      if ((currentCount || 0) + userIds.length > (groupSettings?.max_members || 100)) {
        return new Response(
          JSON.stringify({ error: 'Group is full' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add members
      for (const userId of userIds) {
        await adminClient.from('group_members').insert({
          conversation_id: groupConvId,
          user_id: userId,
          role: 'member',
          added_by: user.id
        });
        await adminClient.from('conversation_participants').insert({
          conversation_id: groupConvId,
          user_id: userId
        });
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // DELETE /group/:conversationId/members/:userId - Remove member
    if (method === 'DELETE' && segments.length >= 4 && segments[segments.length - 4] === 'group' && segments[segments.length - 2] === 'members') {
      const groupConvId = segments[segments.length - 3];
      const targetUserId = segments[segments.length - 1];

      // Get group info
      const { data: groupSettings } = await supabaseClient
        .from('group_settings')
        .select('created_by')
        .eq('conversation_id', groupConvId)
        .single();

      // Check if target is creator
      if (targetUserId === groupSettings?.created_by) {
        return new Response(
          JSON.stringify({ error: 'Cannot remove group creator' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check permissions
      const { data: userMember } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      const isAdmin = userMember?.role === 'admin';
      const isSelf = targetUserId === user.id;

      if (!isAdmin && !isSelf) {
        return new Response(
          JSON.stringify({ error: 'Only admins can remove members' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Remove member
      console.log(`Removing member ${targetUserId} from group ${groupConvId}`);

      const { error: memberError } = await adminClient
        .from('group_members')
        .delete()
        .eq('conversation_id', groupConvId)
        .eq('user_id', targetUserId);

      if (memberError) {
        console.error('Error removing group member:', memberError);
        return new Response(
          JSON.stringify({ error: 'Failed to remove member from group' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { error: participantError } = await adminClient
        .from('conversation_participants')
        .delete()
        .eq('conversation_id', groupConvId)
        .eq('user_id', targetUserId);

      if (participantError) {
        console.error('Error removing conversation participant:', participantError);
        return new Response(
          JSON.stringify({ error: 'Failed to remove member from conversation' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`Successfully removed member ${targetUserId} from group ${groupConvId}`);

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /group/:conversationId/members/:userId/promote - Promote to admin
    if (method === 'POST' && segments.length >= 5 && segments[segments.length - 5] === 'group' && segments[segments.length - 3] === 'members' && segments[segments.length - 1] === 'promote') {
      const groupConvId = segments[segments.length - 4];
      const targetUserId = segments[segments.length - 2];

      // Check if user is admin
      const { data: userMember } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      if (!userMember || userMember.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only admins can promote members' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { error } = await supabaseClient
        .from('group_members')
        .update({ role: 'admin' })
        .eq('conversation_id', groupConvId)
        .eq('user_id', targetUserId);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to promote member' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /group/:conversationId/members/:userId/demote - Demote to member
    if (method === 'POST' && segments.length >= 5 && segments[segments.length - 5] === 'group' && segments[segments.length - 3] === 'members' && segments[segments.length - 1] === 'demote') {
      const groupConvId = segments[segments.length - 4];
      const targetUserId = segments[segments.length - 2];

      // Check if target is creator
      const { data: groupSettings } = await supabaseClient
        .from('group_settings')
        .select('created_by')
        .eq('conversation_id', groupConvId)
        .single();

      if (targetUserId === groupSettings?.created_by) {
        return new Response(
          JSON.stringify({ error: 'Cannot demote group creator' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if user is admin
      const { data: userMember } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', groupConvId)
        .eq('user_id', user.id)
        .single();

      if (!userMember || userMember.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only admins can demote members' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { error } = await supabaseClient
        .from('group_members')
        .update({ role: 'member' })
        .eq('conversation_id', groupConvId)
        .eq('user_id', targetUserId);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to demote member' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // DELETE /group/:conversationId - Delete group, server, or channel
    if (method === 'DELETE' && segments.length >= 2 && segments[segments.length - 2] === 'group') {
      const groupConvId = segments[segments.length - 1];

      console.log('Attempting to delete group/server/channel:', groupConvId);

      // First check if this is a channel (has parent_server_id)
      const { data: conversation } = await adminClient
        .from('conversations')
        .select('parent_server_id')
        .eq('id', groupConvId)
        .single();

      // CHANNEL DELETION: If this is a channel (has parent_server_id)
      if (conversation?.parent_server_id) {
        const parentServerId = conversation.parent_server_id;
        console.log(`Deleting channel ${groupConvId} from parent server ${parentServerId}`);

        // Check if user is admin of the parent server
        const { data: adminMember } = await supabaseClient
          .from('group_members')
          .select('role')
          .eq('conversation_id', parentServerId)
          .eq('user_id', user.id)
          .single();

        if (adminMember?.role !== 'admin') {
          console.log('User admin check failed - not an admin of parent server');
          return new Response(
            JSON.stringify({ error: 'Only server admins can delete channels' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        console.log('User admin check passed');

        try {
          // Delete messages in this channel
          await adminClient
            .from('messages')
            .delete()
            .eq('conversation_id', groupConvId);
          
          // Delete participants from this channel
          await adminClient
            .from('conversation_participants')
            .delete()
            .eq('conversation_id', groupConvId);
          
          // Delete the server_channels entry
          await adminClient
            .from('server_channels')
            .delete()
            .eq('channel_conversation_id', groupConvId);
          
          // Delete the channel conversation
          const { error: deleteError } = await adminClient
            .from('conversations')
            .delete()
            .eq('id', groupConvId);
          
          if (deleteError) {
            console.error('Channel delete error:', deleteError);
            throw deleteError;
          }

          console.log('Channel deletion completed');
          
          return new Response(
            JSON.stringify({ success: true }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        } catch (error) {
          console.error('Error during channel deletion:', error);
          return new Response(
            JSON.stringify({ error: 'Failed to delete channel. Please try again.' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }

      // GROUP/SERVER DELETION: No parent_server_id, so it's a regular group or server
      console.log('Regular group or server delete');

      // Check if user is creator
      const { data: groupSettings } = await supabaseClient
        .from('group_settings')
        .select('created_by')
        .eq('conversation_id', groupConvId)
        .single();

      if (groupSettings?.created_by !== user.id) {
        return new Response(
          JSON.stringify({ error: 'Only group creator can delete group' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if this is a server (has channels)
      const { data: channels } = await adminClient
        .from('server_channels')
        .select('channel_conversation_id')
        .eq('server_id', groupConvId);

      const isServer = channels && channels.length > 0;

      try {
        if (isServer) {
          console.log(`Deleting server with ${channels.length} channels`);
          
          // Delete each channel and its data
          for (const channel of channels) {
            const channelConvId = channel.channel_conversation_id;
            
            // Delete messages in this channel
            await adminClient
              .from('messages')
              .delete()
              .eq('conversation_id', channelConvId);
            
            // Delete participants from this channel
            await adminClient
              .from('conversation_participants')
              .delete()
              .eq('conversation_id', channelConvId);
            
            // Delete the channel conversation
            await adminClient
              .from('conversations')
              .delete()
              .eq('id', channelConvId);
          }
          
          // Delete server_channels entries
          await adminClient
            .from('server_channels')
            .delete()
            .eq('server_id', groupConvId);
        }
        
        // Delete messages in the main group/server
        await adminClient
          .from('messages')
          .delete()
          .eq('conversation_id', groupConvId);
        
        // Delete conversation participants
        await adminClient
          .from('conversation_participants')
          .delete()
          .eq('conversation_id', groupConvId);
        
        // Delete group members
        await adminClient
          .from('group_members')
          .delete()
          .eq('conversation_id', groupConvId);
        
        // Delete group settings
        await adminClient
          .from('group_settings')
          .delete()
          .eq('conversation_id', groupConvId);
        
        // Finally delete the main conversation
        const { error: deleteError } = await adminClient
          .from('conversations')
          .delete()
          .eq('id', groupConvId);
        
        if (deleteError) {
          console.error('Error deleting conversation:', deleteError);
          throw deleteError;
        }

        console.log('Deletion completed');
        
        return new Response(
          JSON.stringify({ success: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (error) {
        console.error('Error during deletion:', error);
        return new Response(
          JSON.stringify({ error: 'Failed to delete group. Please try again.' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // GET /list - Get user's conversations
    if (method === 'GET' && segments[segments.length - 1] === 'list') {
      // First, get all conversation IDs where the user is a participant
      const { data: userConvs } = await supabaseClient
        .from('conversation_participants')
        .select('conversation_id')
        .eq('user_id', user.id);

      const conversationIds = userConvs?.map(c => c.conversation_id) || [];
      
      if (conversationIds.length === 0) {
        return new Response(
          JSON.stringify({ conversations: [] }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Now get the conversations with all participants
        const { data: conversations } = await supabaseClient
        .from('conversations')
        .select(`
          id,
          created_at,
          is_group,
          group_type,
          parent_server_id,
          conversation_participants (
            user_id,
            last_read_at,
            profiles (
              id,
              handle,
              display_name,
              avatar_url
            )
          )
        `)
        .in('id', conversationIds)
        .is('parent_server_id', null)
        .neq('group_type', 'branch_server');

      const conversationList = [];

      for (const conv of conversations || []) {
        // Get last message
        const { data: lastMessage } = await supabaseClient
          .from('messages')
          .select('body, created_at, author_id, attachment_path')
          .eq('conversation_id', conv.id)
          .order('created_at', { ascending: false })
          .limit(1);

        // Get unread count
        const myParticipation = conv.conversation_participants.find(p => p.user_id === user.id);
        const lastReadAt = myParticipation?.last_read_at;
        
        let unreadQuery = supabaseClient
          .from('messages')
          .select('id', { count: 'exact' })
          .eq('conversation_id', conv.id)
          .neq('author_id', user.id);

        if (lastReadAt) {
          unreadQuery = unreadQuery.gt('created_at', lastReadAt);
        }

        const { count: unreadCount } = await unreadQuery;

        if (conv.is_group) {
          // Get group info
          const { data: groupInfo } = await supabaseClient
            .from('group_settings')
            .select('name, description, avatar_url')
            .eq('conversation_id', conv.id)
            .single();

          const { count: memberCount } = await supabaseClient
            .from('group_members')
            .select('*', { count: 'exact', head: true })
            .eq('conversation_id', conv.id);

          conversationList.push({
            id: conv.id,
            isGroup: true,
            groupInfo: groupInfo || null,
            memberCount: memberCount || 0,
            lastMessage: lastMessage?.[0] || null,
            unreadCount: unreadCount || 0,
            updatedAt: lastMessage?.[0]?.created_at || conv.created_at
          });
        } else {
          // 1:1 chat
          const otherParticipant = conv.conversation_participants?.find(p => p.user_id !== user.id);
          if (!otherParticipant?.profiles) continue;

          conversationList.push({
            id: conv.id,
            isGroup: false,
            otherUser: otherParticipant.profiles,
            lastMessage: lastMessage?.[0] || null,
            unreadCount: unreadCount || 0,
            updatedAt: lastMessage?.[0]?.created_at || conv.created_at
          });
        }
      }

      // Sort by last activity
      conversationList.sort((a, b) => 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      );

      return new Response(
        JSON.stringify({ conversations: conversationList }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract conversation ID from URL for conversation-specific endpoints
    const conversationId = segments[segments.length - 2];
    
    // GET /:conversationId/messages - Get messages with pagination
    if (method === 'GET' && segments[segments.length - 1] === 'messages') {
      const before = url.searchParams.get('before');
      const limit = parseInt(url.searchParams.get('limit') || '50');

      let query = supabaseClient
        .from('messages')
        .select(`
          id,
          body,
          attachment_path,
          mime_type,
          created_at,
          author_id,
          profiles (
            id,
            handle,
            display_name,
            avatar_url
          )
        `)
        .eq('conversation_id', conversationId)
        .is('deleted_at', null)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (before) {
        query = query.lt('created_at', before);
      }

      const { data: messages, error } = await query;

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to fetch messages' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ messages: messages?.reverse() || [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /:conversationId/send - Send message
    if (method === 'POST' && segments[segments.length - 1] === 'send') {
      const { body, attachmentPath, mimeType } = await req.json();

      if (!body && !attachmentPath) {
        return new Response(
          JSON.stringify({ error: 'Message body or attachment is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if it's a group and verify permissions
      const { data: conversation } = await supabaseClient
        .from('conversations')
        .select('is_group, parent_server_id')
        .eq('id', conversationId)
        .single();

      if (conversation?.is_group) {
        // If it's a server channel, check server membership
        if (conversation.parent_server_id) {
          const { data: serverMember } = await supabaseClient
            .from('group_members')
            .select('role')
            .eq('conversation_id', conversation.parent_server_id)
            .eq('user_id', user.id)
            .single();

          if (!serverMember) {
            return new Response(
              JSON.stringify({ error: 'You are not a member of this server' }),
              { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
          }
          // Server members can send messages to channels
        } else {
          // Regular group - check group_settings
          const { data: groupSettings } = await supabaseClient
            .from('group_settings')
            .select('allow_member_messages')
            .eq('conversation_id', conversationId)
            .single();

          if (!groupSettings?.allow_member_messages) {
            // Check if user is admin
            const { data: member } = await supabaseClient
              .from('group_members')
              .select('role')
              .eq('conversation_id', conversationId)
              .eq('user_id', user.id)
              .single();

            if (!member || member.role !== 'admin') {
              return new Response(
                JSON.stringify({ error: 'Only admins can send messages in this group' }),
                { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
              );
            }
          }
        }
      }

      // Insert message
      const { data: message, error: messageError } = await supabaseClient
        .from('messages')
        .insert({
          conversation_id: conversationId,
          author_id: user.id,
          body: body || null,
          attachment_path: attachmentPath || null,
          mime_type: mimeType || null
        })
        .select(`
          id,
          body,
          attachment_path,
          mime_type,
          created_at,
          author_id,
          profiles (
            id,
            handle,
            display_name,
            avatar_url
          )
        `)
        .single();

      if (messageError) {
        return new Response(
          JSON.stringify({ error: 'Failed to send message' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update sender's last_read_at
      await supabaseClient
        .from('conversation_participants')
        .update({ last_read_at: new Date().toISOString() })
        .eq('conversation_id', conversationId)
        .eq('user_id', user.id);

      return new Response(
        JSON.stringify({ message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /:conversationId/read - Mark as read
    if (method === 'POST' && segments[segments.length - 1] === 'read') {
      const { error } = await supabaseClient
        .from('conversation_participants')
        .update({ last_read_at: new Date().toISOString() })
        .eq('conversation_id', conversationId)
        .eq('user_id', user.id);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to mark as read' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /block - Block/unblock user
    if (method === 'POST' && segments[segments.length - 1] === 'block') {
      const { blockedUserId } = await req.json();

      if (!blockedUserId) {
        return new Response(
          JSON.stringify({ error: 'Blocked user ID is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if already blocked
      const { data: existingBlock } = await supabaseClient
        .from('user_blocks')
        .select('*')
        .eq('blocker', user.id)
        .eq('blocked', blockedUserId)
        .single();

      if (existingBlock) {
        // Unblock
        const { error } = await supabaseClient
          .from('user_blocks')
          .delete()
          .eq('blocker', user.id)
          .eq('blocked', blockedUserId);

        if (error) {
          return new Response(
            JSON.stringify({ error: 'Failed to unblock user' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        return new Response(
          JSON.stringify({ blocked: false }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } else {
        // Block
        const { error } = await supabaseClient
          .from('user_blocks')
          .insert({
            blocker: user.id,
            blocked: blockedUserId
          });

        if (error) {
          return new Response(
            JSON.stringify({ error: 'Failed to block user' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        return new Response(
          JSON.stringify({ blocked: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // POST /report - Report message
    if (method === 'POST' && segments[segments.length - 1] === 'report') {
      const { messageId, reason } = await req.json();

      if (!messageId || !reason) {
        return new Response(
          JSON.stringify({ error: 'Message ID and reason are required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { error } = await supabaseClient
        .from('message_reports')
        .insert({
          reporter: user.id,
          message_id: messageId,
          reason
        });

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to report message' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /server/create - Create branch server
    if (method === 'POST' && segments[segments.length - 2] === 'server' && segments[segments.length - 1] === 'create') {
      const { name, description, avatarUrl, defaultChannels = ['general', 'announcements'] } = await req.json();

      if (!name) {
        return new Response(
          JSON.stringify({ error: 'Server name is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create server conversation
      const { data: serverConv, error: serverError } = await adminClient
        .from('conversations')
        .insert({
          is_group: true,
          group_type: 'branch_server'
        })
        .select()
        .single();

      if (serverError || !serverConv) {
        console.error('Error creating server:', serverError);
        return new Response(
          JSON.stringify({ error: 'Failed to create server' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create group settings
      const { error: settingsError } = await adminClient
        .from('group_settings')
        .insert({
          conversation_id: serverConv.id,
          created_by: user.id,
          name: name,
          description: description || null,
          avatar_url: avatarUrl || null
        });

      if (settingsError) {
        console.error('Error creating server settings:', settingsError);
        return new Response(
          JSON.stringify({ error: 'Failed to create server settings' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add creator as admin
      await adminClient.from('conversation_participants').insert({ conversation_id: serverConv.id, user_id: user.id });
      await adminClient.from('group_members').insert({ conversation_id: serverConv.id, user_id: user.id, role: 'admin' });

      // Create default channels
      for (let i = 0; i < defaultChannels.length; i++) {
        const channelName = defaultChannels[i];
        
        // Create channel conversation
        const { data: channelConv, error: channelError } = await adminClient
          .from('conversations')
          .insert({
            is_group: true,
            group_type: 'single',
            parent_server_id: serverConv.id
          })
          .select()
          .single();

        if (!channelError && channelConv) {
          // Link channel to server
          await adminClient
            .from('server_channels')
            .insert({
              server_id: serverConv.id,
              channel_conversation_id: channelConv.id,
              name: channelName,
              channel_order: i,
              is_default: i === 0
            });

          // Add creator to channel
          await adminClient.from('conversation_participants').insert({ conversation_id: channelConv.id, user_id: user.id });
        }
      }

      return new Response(
        JSON.stringify({ serverId: serverConv.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /server/:id - Get single server details
    if (method === 'POST' && segments.length === 3 && segments[1] === 'server') {
      const serverId = segments[2];

      // Step 1: Verify the conversation exists and is a branch_server
      const { data: serverConv, error: convError } = await supabaseClient
        .from('conversations')
        .select('id, created_at, group_type')
        .eq('id', serverId)
        .eq('group_type', 'branch_server')
        .maybeSingle();

      if (convError) {
        console.error('Error loading server conversation:', convError);
        return new Response(
          JSON.stringify({ error: 'Failed to load server' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (!serverConv) {
        return new Response(
          JSON.stringify({ error: 'Server not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Step 2: Verify user is a member
      const { data: membership, error: membershipError } = await supabaseClient
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', serverId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (membershipError || !membership) {
        return new Response(
          JSON.stringify({ error: 'Not a member of this server' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Step 3: Get group settings
      const { data: groupSettings, error: settingsError } = await supabaseClient
        .from('group_settings')
        .select('name, description, avatar_url')
        .eq('conversation_id', serverId)
        .maybeSingle();

      if (settingsError) {
        console.error('Error loading group settings:', settingsError);
        return new Response(
          JSON.stringify({ error: 'Failed to load server settings' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Step 4: Get channels
      const { data: channels, error: channelsError } = await supabaseClient
        .from('server_channels')
        .select('id, name, description, channel_order, is_default, channel_conversation_id')
        .eq('server_id', serverId)
        .order('channel_order', { ascending: true });

      if (channelsError) {
        console.error('Error loading channels:', channelsError);
        return new Response(
          JSON.stringify({ error: 'Failed to load channels' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Step 5: Get user's role
      const { data: groupMember, error: roleError } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', serverId)
        .eq('user_id', user.id)
        .maybeSingle();

      const userRole = groupMember?.role || 'member';

      // Step 6: Count members
      const { count: memberCount, error: countError } = await supabaseClient
        .from('conversation_participants')
        .select('*', { count: 'exact', head: true })
        .eq('conversation_id', serverId);

      const server = {
        id: serverConv.id,
        groupInfo: groupSettings || { name: 'Unnamed Server' },
        memberCount: memberCount || 0,
        channels: (channels || []).map(ch => ({
          id: ch.channel_conversation_id,
          name: ch.name,
          description: ch.description,
          order: ch.channel_order,
          isDefault: ch.is_default
        })),
        userRole,
        unreadCount: 0,
        updatedAt: serverConv.created_at
      };

      return new Response(
        JSON.stringify({ server }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /server/:id/channels - Create a new channel
    if (method === 'POST' && segments.length === 4 && segments[1] === 'server' && segments[3] === 'channels') {
      const serverId = segments[2];
      const { name, description } = await req.json();

      if (!name || typeof name !== 'string' || name.trim() === '') {
        return new Response(
          JSON.stringify({ error: 'Channel name is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Verify user is an admin of the server
      const { data: memberRole, error: roleError } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', serverId)
        .eq('user_id', user.id)
        .single();

      if (roleError || !memberRole || memberRole.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only server admins can create channels' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get the highest channel order to place the new channel at the end
      const { data: existingChannels } = await adminClient
        .from('server_channels')
        .select('channel_order')
        .eq('server_id', serverId)
        .order('channel_order', { ascending: false })
        .limit(1);

      const nextOrder = existingChannels && existingChannels.length > 0 
        ? (existingChannels[0].channel_order || 0) + 1 
        : 0;

      // Create a new conversation for the channel
      const { data: newConversation, error: convError } = await adminClient
        .from('conversations')
        .insert({
          is_group: true,
          group_type: 'single',
          parent_server_id: serverId
        })
        .select('id')
        .single();

      if (convError || !newConversation) {
        console.error('Error creating channel conversation:', convError);
        return new Response(
          JSON.stringify({ error: 'Failed to create channel' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add the channel to server_channels
      const { data: newChannel, error: channelError } = await adminClient
        .from('server_channels')
        .insert({
          server_id: serverId,
          channel_conversation_id: newConversation.id,
          name: name.trim(),
          description: description?.trim() || null,
          channel_order: nextOrder,
          is_default: false
        })
        .select('*')
        .single();

      if (channelError) {
        console.error('Error creating channel record:', channelError);
        // Cleanup: delete the conversation we just created
        await adminClient.from('conversations').delete().eq('id', newConversation.id);
        return new Response(
          JSON.stringify({ error: 'Failed to create channel' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add all server members as participants to the new channel
      const { data: serverMembers } = await adminClient
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', serverId);

      if (serverMembers && serverMembers.length > 0) {
        const participants = serverMembers.map(member => ({
          conversation_id: newConversation.id,
          user_id: member.user_id
        }));

        await adminClient
          .from('conversation_participants')
          .insert(participants);
      }

      console.log('Channel created:', newChannel);

      return new Response(
        JSON.stringify({ channelId: newConversation.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // PUT /server/:id/channels/:channelId - Update channel details
    if (method === 'PUT' && segments.length === 5 && segments[1] === 'server' && segments[3] === 'channels') {
      const serverId = segments[2];
      const channelId = segments[4];
      const updates = await req.json();

      // Verify user is an admin of the server
      const { data: memberRole, error: roleError } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', serverId)
        .eq('user_id', user.id)
        .single();

      if (roleError || !memberRole || memberRole.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only server admins can update channels' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Verify the channel belongs to this server
      const { data: channel, error: channelCheckError } = await adminClient
        .from('server_channels')
        .select('*')
        .eq('server_id', serverId)
        .eq('channel_conversation_id', channelId)
        .single();

      if (channelCheckError || !channel) {
        return new Response(
          JSON.stringify({ error: 'Channel not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Build update object
      const updateData: any = {};
      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.order !== undefined) updateData.channel_order = updates.order;

      if (Object.keys(updateData).length === 0) {
        return new Response(
          JSON.stringify({ error: 'No valid updates provided' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update the channel
      const { error: updateError } = await adminClient
        .from('server_channels')
        .update(updateData)
        .eq('server_id', serverId)
        .eq('channel_conversation_id', channelId);

      if (updateError) {
        console.error('Error updating channel:', updateError);
        return new Response(
          JSON.stringify({ error: 'Failed to update channel' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // DELETE /server/:id/channels/:channelId - Delete a channel
    if (method === 'DELETE' && segments.length === 5 && segments[1] === 'server' && segments[3] === 'channels') {
      const serverId = segments[2];
      const channelId = segments[4];

      // Verify user is an admin of the server
      const { data: memberRole, error: roleError } = await supabaseClient
        .from('group_members')
        .select('role')
        .eq('conversation_id', serverId)
        .eq('user_id', user.id)
        .single();

      if (roleError || !memberRole || memberRole.role !== 'admin') {
        return new Response(
          JSON.stringify({ error: 'Only server admins can delete channels' }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Verify the channel belongs to this server and is not default
      const { data: channel, error: channelCheckError } = await adminClient
        .from('server_channels')
        .select('*')
        .eq('server_id', serverId)
        .eq('channel_conversation_id', channelId)
        .single();

      if (channelCheckError || !channel) {
        return new Response(
          JSON.stringify({ error: 'Channel not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (channel.is_default) {
        return new Response(
          JSON.stringify({ error: 'Cannot delete default channel' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Delete the channel
      const { error: deleteError } = await adminClient
        .from('server_channels')
        .delete()
        .eq('server_id', serverId)
        .eq('channel_conversation_id', channelId);

      if (deleteError) {
        console.error('Error deleting channel:', deleteError);
        return new Response(
          JSON.stringify({ error: 'Failed to delete channel' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /servers - List all servers
    if (method === 'POST' && segments[segments.length - 1] === 'servers') {
      // Step 1: Fetch server conversations
      const { data: serverConvs, error: convsError } = await supabaseClient
        .from('conversations')
        .select(`
          id,
          created_at,
          conversation_participants (
            user_id
          )
        `)
        .eq('group_type', 'branch_server')
        .order('created_at', { ascending: false });

      if (convsError) {
        console.error('Error loading server conversations:', convsError);
        return new Response(
          JSON.stringify({ error: 'Failed to load servers' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`Found ${serverConvs?.length || 0} server conversations`);

      // Step 2: Fetch group settings separately to avoid ambiguous foreign key
      const conversationIds = (serverConvs || []).map(conv => conv.id);
      const { data: groupSettings, error: settingsError } = conversationIds.length > 0
        ? await supabaseClient
            .from('group_settings')
            .select('conversation_id, name, description, avatar_url')
            .in('conversation_id', conversationIds)
        : { data: [], error: null };

      if (settingsError) {
        console.error('Error loading group settings:', settingsError);
        return new Response(
          JSON.stringify({ error: 'Failed to load servers' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log(`Found ${groupSettings?.length || 0} group settings`);

      // Step 3: Count channels for each server
      console.log(`Counting channels for ${conversationIds.length} servers:`, conversationIds);
      
      const { data: channelCounts, error: channelCountError } = conversationIds.length > 0
        ? await supabaseClient
            .from('server_channels')
            .select('id, server_id')
            .in('server_id', conversationIds)
        : { data: [], error: null };

      console.log(`Found ${channelCounts?.length || 0} total channel records`);
      
      if (channelCountError) {
        console.error('Error loading channel counts:', channelCountError);
      }

      // Build channel count map
      const channelCountMap = new Map();
      (channelCounts || []).forEach(channel => {
        const count = channelCountMap.get(channel.server_id) || 0;
        channelCountMap.set(channel.server_id, count + 1);
      });
      
      console.log('Channel counts per server:', Object.fromEntries(channelCountMap));

      // Step 4: Build settings map and compose response
      const settingsMap = new Map();
      (groupSettings || []).forEach(setting => {
        settingsMap.set(setting.conversation_id, {
          name: setting.name,
          description: setting.description,
          avatar_url: setting.avatar_url
        });
      });

      const servers = (serverConvs || []).map(conv => ({
        id: conv.id,
        groupInfo: settingsMap.get(conv.id) || { name: 'Unnamed Server' },
        memberCount: conv.conversation_participants?.length || 0,
        channelCount: channelCountMap.get(conv.id) || 0,
        unreadCount: 0,
        updatedAt: conv.created_at
      }));

      console.log(`Returning ${servers.length} servers`);

      return new Response(
        JSON.stringify({ servers }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /mentorship/create - Create mentorship channel
    if (method === 'POST' && segments.includes('mentorship') && segments[segments.length - 1] === 'create') {
      const { name, description, avatarUrl, mentorshipType, price, billingCycle = 'monthly', maxMentees, defaultChannels = ['general', 'announcements', 'resources'] } = await req.json();

      // Check if user can create premium content (Pro rank 500+ XP OR admin)
      const { data: canCreate } = await adminClient.rpc('can_create_premium_content', { _user_id: user.id });
      
      if (!canCreate) {
        return new Response(
          JSON.stringify({ 
            error: 'Pro Trader rank required',
            message: 'Creating mentorship channels requires Pro Trader rank (500+ XP). Keep engaging to level up!'
          }),
          { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (mentorshipType === 'paid' && (!price || price <= 0)) {
        return new Response(
          JSON.stringify({ error: 'Price is required for paid mentorship' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create server conversation
      const { data: serverConv, error: serverError } = await adminClient
        .from('conversations')
        .insert({ is_group: true, group_type: 'branch_server' })
        .select()
        .single();

      if (serverError || !serverConv) {
        console.error('Failed to create server conversation:', serverError);
        return new Response(
          JSON.stringify({ 
            error: 'Failed to create server',
            message: 'We couldn\'t initialize the mentorship channel. Please try again in a moment.'
          }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create group settings with mentorship fields
      const { error: settingsError } = await supabaseClient
        .from('group_settings')
        .insert({
          conversation_id: serverConv.id,
          name,
          description: description || null,
          avatar_url: avatarUrl || null,
          created_by: user.id,
          allow_member_messages: true,
          allow_member_add: false,
          max_members: maxMentees || 100,
          is_mentorship_channel: true,
          mentorship_type: mentorshipType,
          mentorship_price: mentorshipType === 'paid' ? price : null,
          mentorship_billing_cycle: billingCycle,
          max_mentees: maxMentees || 100,
          current_mentees: 0
        });

      if (settingsError) {
        console.error('Failed to create group settings:', settingsError);
        await adminClient.from('conversations').delete().eq('id', serverConv.id);
        return new Response(
          JSON.stringify({ 
            error: 'Failed to create settings',
            message: 'We couldn\'t configure the mentorship channel. Please try again.'
          }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Add creator as admin
      await adminClient.from('group_members').insert({
        conversation_id: serverConv.id,
        user_id: user.id,
        role: 'admin',
        added_by: user.id
      });

      await supabaseClient.from('conversation_participants').insert({
        conversation_id: serverConv.id,
        user_id: user.id
      });

      // Create default channels
      for (let i = 0; i < defaultChannels.length; i++) {
        const channelName = defaultChannels[i];
        const { data: channelConv } = await adminClient
          .from('conversations')
          .insert({ is_group: true, group_type: 'single', parent_server_id: serverConv.id })
          .select()
          .single();

        if (channelConv) {
          await adminClient.from('server_channels').insert({
            server_id: serverConv.id,
            channel_conversation_id: channelConv.id,
            name: channelName,
            channel_order: i,
            is_default: i === 0
          });
        }
      }

      return new Response(
        JSON.stringify({ serverId: serverConv.id, message: 'Mentorship channel created' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // GET/POST /mentorship/list - List mentorship channels
    if ((method === 'GET' || method === 'POST') && segments.includes('mentorship') && segments[segments.length - 1] === 'list') {
      const url = new URL(req.url);
      const type = url.searchParams.get('type');

      let query = supabaseClient
        .from('group_settings')
        .select(`
          *,
          conversations!group_settings_conversation_id_fkey!inner(id, is_group, group_type),
          profiles!created_by(
            id, handle, display_name, avatar_url, 
            verified_status, reputation_last30, markets
          )
        `)
        .eq('is_mentorship_channel', true);

      if (type === 'free') {
        query = query.eq('mentorship_type', 'free');
      } else if (type === 'paid') {
        query = query.eq('mentorship_type', 'paid');
      }

      query = query.order('created_at', { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching mentorship channels:', error);
        return new Response(
          JSON.stringify({ error: 'Failed to fetch channels' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const channels = await Promise.all((data || []).map(async (channel) => {
        const { count } = await supabaseClient
          .from('conversation_participants')
          .select('*', { count: 'exact', head: true })
          .eq('conversation_id', channel.conversation_id);

        const { data: membership } = await supabaseClient
          .from('conversation_participants')
          .select('user_id')
          .eq('conversation_id', channel.conversation_id)
          .eq('user_id', user.id)
          .maybeSingle();

        const isFull = channel.max_mentees && count >= channel.max_mentees;
        const isUserMember = !!membership;

        return {
          ...channel,
          memberCount: count || 0,
          isFull,
          isUserMember,
          mentor: channel.profiles
        };
      }));

      return new Response(
        JSON.stringify({ channels }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // POST /mentorship/:channelId/join - Join mentorship channel
    if (method === 'POST' && segments.includes('mentorship') && segments[segments.length - 1] === 'join') {
      const channelId = segments[segments.indexOf('mentorship') + 1];

      const { data: channel } = await supabaseClient
        .from('group_settings')
        .select('*, conversations(*)')
        .eq('conversation_id', channelId)
        .eq('is_mentorship_channel', true)
        .single();

      if (!channel) {
        return new Response(
          JSON.stringify({ error: 'Mentorship channel not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if full
      const { count } = await supabaseClient
        .from('conversation_participants')
        .select('*', { count: 'exact', head: true })
        .eq('conversation_id', channelId);

      if (channel.max_mentees && count >= channel.max_mentees) {
        return new Response(
          JSON.stringify({ error: 'This mentorship channel is full' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if already a member
      const { data: existingMember } = await supabaseClient
        .from('conversation_participants')
        .select('user_id')
        .eq('conversation_id', channelId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (existingMember) {
        return new Response(
          JSON.stringify({ error: 'Already a member' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // If paid, check for active subscription
      if (channel.mentorship_type === 'paid') {
        const { data: subscription } = await supabaseClient
          .from('mentorship_subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .eq('server_id', channelId)
          .eq('status', 'active')
          .maybeSingle();

        if (!subscription) {
          return new Response(
            JSON.stringify({ 
              error: 'Payment required',
              requiresPayment: true,
              price: channel.mentorship_price,
              billingCycle: channel.mentorship_billing_cycle
            }),
            { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      } else {
        // Free channel - create subscription record
        await supabaseClient
          .from('mentorship_subscriptions')
          .insert({
            user_id: user.id,
            server_id: channelId,
            status: 'active',
            amount_paid: 0
          });
      }

      // Add user to conversation
      await adminClient
        .from('conversation_participants')
        .insert({
          conversation_id: channelId,
          user_id: user.id
        });

      // Add as group member
      await adminClient
        .from('group_members')
        .insert({
          conversation_id: channelId,
          user_id: user.id,
          role: 'member',
          added_by: channel.created_by
        });

      return new Response(
        JSON.stringify({ success: true, message: 'Joined mentorship channel' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Not found' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Chat API Error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});