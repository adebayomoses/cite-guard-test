import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const url = new URL(req.url);
    const segments = url.pathname.split('/').filter(Boolean);
    const method = req.method;

    console.log('Request:', method, segments);

    // Get user from auth
    const authHeader = req.headers.get('Authorization');
    let userId = null;
    if (authHeader) {
      const { data: { user } } = await supabaseClient.auth.getUser(
        authHeader.replace('Bearer ', '')
      );
      userId = user?.id;
    }

    // GET /challenges-api/list - Get challenges list with filters
    if (method === 'GET' && segments.length === 2 && segments[1] === 'list') {
      const status = url.searchParams.get('status');
      
      let query = supabaseClient
        .from('challenges_with_status')
        .select(`
          *,
          entry_count:challenge_entries(count),
          created_by_profile:profiles!challenges_created_by_fkey(handle, display_name, avatar_url)
        `);

      if (status) {
        query = query.eq('status', status);
      }

      const { data: challenges, error } = await query.order('created_at', { ascending: false });

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Add user participation status
      const challengesWithParticipation = await Promise.all(
        challenges.map(async (challenge) => {
          let isParticipating = false;
          if (userId) {
            const { data: entry } = await supabaseClient
              .from('challenge_entries')
              .select('*')
              .eq('challenge_id', challenge.id)
              .eq('user_id', userId)
              .single();
            isParticipating = !!entry;
          }
          
          return {
            ...challenge,
            isParticipating,
            entry_count: challenge.entry_count?.[0]?.count || 0
          };
        })
      );

      return new Response(JSON.stringify({ challenges: challengesWithParticipation }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // GET /challenges-api/:id - Get challenge details with leaderboard
    if (method === 'GET' && segments.length === 2 && segments[1] !== 'list') {
      const challengeId = segments[1];
      
      const { data: challenge, error: challengeError } = await supabaseClient
        .from('challenges_with_status')
        .select(`
          *,
          entry_count:challenge_entries(count),
          created_by_profile:profiles!challenges_created_by_fkey(handle, display_name, avatar_url)
        `)
        .eq('id', challengeId)
        .single();

      if (challengeError) {
        return new Response(JSON.stringify({ error: 'Challenge not found' }), {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get leaderboard
      const { data: leaderboard } = await supabaseClient
        .from('challenge_live_leaderboard')
        .select('*')
        .eq('challenge_id', challengeId)
        .order('rank', { ascending: true })
        .limit(100);

      // Check if user is participating
      let isParticipating = false;
      let userRank = null;
      if (userId) {
        const { data: entry } = await supabaseClient
          .from('challenge_entries')
          .select('*')
          .eq('challenge_id', challengeId)
          .eq('user_id', userId)
          .single();
        isParticipating = !!entry;

        if (isParticipating) {
          const { data: userScore } = await supabaseClient
            .from('challenge_scores')
            .select('rank, score')
            .eq('challenge_id', challengeId)
            .eq('user_id', userId)
            .single();
          userRank = userScore?.rank || null;
        }
      }

      return new Response(JSON.stringify({
        challenge: {
          ...challenge,
          entry_count: challenge.entry_count?.[0]?.count || 0,
          isParticipating,
          userRank
        },
        leaderboard: leaderboard || []
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST /challenges-api/:id/join - Join/leave challenge
    if (method === 'POST' && segments.length === 3 && segments[2] === 'join') {
      if (!userId) {
        return new Response(JSON.stringify({ error: 'Authentication required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const challengeId = segments[1];

      // Check if already participating
      const { data: existingEntry } = await supabaseClient
        .from('challenge_entries')
        .select('*')
        .eq('challenge_id', challengeId)
        .eq('user_id', userId)
        .single();

      if (existingEntry) {
        // Leave challenge
        await supabaseClient
          .from('challenge_entries')
          .delete()
          .eq('challenge_id', challengeId)
          .eq('user_id', userId);

        // Remove from scores
        await supabaseClient
          .from('challenge_scores')
          .delete()
          .eq('challenge_id', challengeId)
          .eq('user_id', userId);

        return new Response(JSON.stringify({ joined: false }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } else {
        // Join challenge
        await supabaseClient
          .from('challenge_entries')
          .insert({ challenge_id: challengeId, user_id: userId });

        // Initialize score
        await supabaseClient
          .from('challenge_scores')
          .insert({ challenge_id: challengeId, user_id: userId, score: 0 });

        return new Response(JSON.stringify({ joined: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // GET /challenges-api/:id/signals - Get challenge signals
    if (method === 'GET' && segments.length === 3 && segments[2] === 'signals') {
      const challengeId = segments[1];
      
      try {
        const { data: signals, error } = await supabaseClient
          .from('challenge_signals')
          .select('*')
          .eq('challenge_id', challengeId)
          .order('created_at', { ascending: false });

        if (error) throw error;

        // Fetch profile data for each signal
        const signalsWithProfiles = await Promise.all(
          (signals || []).map(async (signal) => {
            const { data: profile } = await supabaseClient
              .from('profiles')
              .select('handle, display_name, avatar_url')
              .eq('id', signal.author_id)
              .single();

            return {
              ...signal,
              profiles: profile || { handle: '', display_name: '', avatar_url: '' }
            };
          })
        );

        return new Response(JSON.stringify(signalsWithProfiles), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        console.error('Error fetching signals:', error);
        return new Response(JSON.stringify({ error: 'Failed to fetch signals' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // POST /challenges-api/:id/signals - Create challenge signal
    if (method === 'POST' && segments.length === 3 && segments[2] === 'signals') {
      if (!userId) {
        return new Response(JSON.stringify({ error: 'Authentication required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const challengeId = segments[1];
    const body = await req.json();
    const { 
      content,
      ticker,
      image_url, 
      market_type, 
      trade_direction, 
      risk_level, 
      timeframe, 
      entry_price, 
      stop_loss, 
      target_price 
    } = body;

    if (!content || !content.trim()) {
      return new Response(JSON.stringify({ error: 'Content is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (entry_price && target_price && !ticker) {
      return new Response(JSON.stringify({ error: 'Ticker is required for trade signals' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

      try {
        // Check if user is the challenge creator
        const { data: challenge } = await supabaseClient
          .from('challenges')
          .select('created_by')
          .eq('id', challengeId)
          .single();

        if (!challenge || challenge.created_by !== userId) {
          return new Response(JSON.stringify({ error: 'Only challenge creators can post signals' }), {
            status: 403,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        const { data: signal, error } = await supabaseClient
          .from('challenge_signals')
          .insert({
            challenge_id: challengeId,
            author_id: userId,
            content: content.trim(),
            image_url,
            market_type,
            trade_direction,
            risk_level,
            timeframe,
            entry_price,
            stop_loss,
            target_price
          })
          .select('*')
          .single();

        if (error) throw error;

        // Auto-create signal tracking entry if trade details exist
        if (signal && entry_price && target_price && ticker) {
          const timeframeMap: Record<string, number> = {
            '1m': 5 * 60 * 1000,
            '5m': 30 * 60 * 1000,
            '15m': 2 * 60 * 60 * 1000,
            '1h': 8 * 60 * 60 * 1000,
            '4h': 24 * 60 * 60 * 1000,
            '1d': 7 * 24 * 60 * 60 * 1000,
            '1w': 30 * 24 * 60 * 60 * 1000,
          };

          const expirationMs = timeframeMap[timeframe || '1d'] || timeframeMap['1d'];
          const expiresAt = new Date(Date.now() + expirationMs).toISOString();

          const { error: trackingError } = await supabaseClient
            .from('signal_tracking')
            .insert({
              signal_type: 'challenge_signal',
              signal_id: signal.id,
              author_id: userId,
              ticker: ticker,
              entry_price: entry_price,
              stop_loss: stop_loss || null,
              target_price: target_price,
              trade_direction: trade_direction || 'long',
              market_type: market_type || 'stocks',
              status: 'ongoing',
              expires_at: expiresAt,
            });

          if (trackingError) {
            console.error('Failed to create signal tracking entry:', trackingError);
            // Don't fail the signal creation, just log the error
          } else {
            console.log('Signal tracking entry created for challenge signal:', signal.id);
          }
        }

        // Fetch profile data
        const { data: profile } = await supabaseClient
          .from('profiles')
          .select('handle, display_name, avatar_url')
          .eq('id', signal.author_id)
          .single();

        const signalWithProfile = {
          ...signal,
          profiles: profile || { handle: '', display_name: '', avatar_url: '' }
        };

        return new Response(JSON.stringify(signalWithProfile), {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        console.error('Error creating signal:', error);
        return new Response(JSON.stringify({ error: 'Failed to create signal' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // GET /challenges-api/:id/discussions - Get challenge discussions
    if (method === 'GET' && segments.length === 3 && segments[2] === 'discussions') {
      const challengeId = segments[1];
      
      try {
        const { data: discussions, error } = await supabaseClient
          .from('challenge_discussions')
          .select('*')
          .eq('challenge_id', challengeId)
          .order('created_at', { ascending: false });

        if (error) throw error;

        // Fetch profile data for each discussion
        const discussionsWithProfiles = await Promise.all(
          (discussions || []).map(async (discussion) => {
            const { data: profile } = await supabaseClient
              .from('profiles')
              .select('handle, display_name, avatar_url')
              .eq('id', discussion.author_id)
              .single();

            return {
              ...discussion,
              profiles: profile || { handle: '', display_name: '', avatar_url: '' }
            };
          })
        );

        return new Response(JSON.stringify(discussionsWithProfiles), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        console.error('Error fetching discussions:', error);
        return new Response(JSON.stringify({ error: 'Failed to fetch discussions' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // POST /challenges-api/:id/discussions - Create challenge discussion
    if (method === 'POST' && segments.length === 3 && segments[2] === 'discussions') {
      if (!userId) {
        return new Response(JSON.stringify({ error: 'Authentication required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const challengeId = segments[1];
      const body = await req.json();
      const { content } = body;

      if (!content || !content.trim()) {
        return new Response(JSON.stringify({ error: 'Content is required' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      try {
        // Check if user is participating in the challenge
        const { data: entry } = await supabaseClient
          .from('challenge_entries')
          .select('*')
          .eq('challenge_id', challengeId)
          .eq('user_id', userId)
          .single();

        if (!entry) {
          return new Response(JSON.stringify({ error: 'Only challenge participants can post discussions' }), {
            status: 403,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        const { data: discussion, error } = await supabaseClient
          .from('challenge_discussions')
          .insert({
            challenge_id: challengeId,
            author_id: userId,
            content: content.trim()
          })
          .select('*')
          .single();

        if (error) throw error;

        // Fetch profile data  
        const { data: profile } = await supabaseClient
          .from('profiles')
          .select('handle, display_name, avatar_url')
          .eq('id', discussion.author_id)
          .single();

        const discussionWithProfile = {
          ...discussion,
          profiles: profile || { handle: '', display_name: '', avatar_url: '' }
        };

        return new Response(JSON.stringify(discussionWithProfile), {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        console.error('Error creating discussion:', error);
        return new Response(JSON.stringify({ error: 'Failed to create discussion' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // POST /challenges-api - Create new challenge
    if (method === 'POST' && segments.length === 1) {
      if (!userId) {
        return new Response(JSON.stringify({ error: 'Authentication required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check if user can create premium content (Pro rank 500+ XP OR admin)
      // Use service role client for RPC call
      const adminClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      );
      const { data: canCreate } = await adminClient.rpc('can_create_premium_content', { _user_id: userId });
      
      if (!canCreate) {
        return new Response(JSON.stringify({ 
          error: 'Pro Trader rank required',
          message: 'Creating challenges requires Pro Trader rank (500+ XP). Keep engaging to level up!'
        }), {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const body = await req.json();
      const { title, description, scope, metric, start_at, end_at, risk_management, collaborator_ids } = body;

      if (!title || !start_at || !end_at) {
        return new Response(JSON.stringify({ error: 'Missing required fields' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: challenge, error } = await supabaseClient
        .from('challenges')
        .insert({
          title,
          description,
          scope: scope || 'all',
          metric: metric || 'useful_rate',
          start_at,
          end_at,
          risk_management,
          created_by: userId
        })
        .select()
        .single();

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Add creator as collaborator with 'creator' role
      await supabaseClient
        .from('challenge_collaborators')
        .insert({
          challenge_id: challenge.id,
          user_id: userId,
          role: 'creator',
          added_by: userId
        });

      // Add collaborators if any
      if (collaborator_ids && Array.isArray(collaborator_ids) && collaborator_ids.length > 0) {
        const collaboratorInserts = collaborator_ids.map((id: string) => ({
          challenge_id: challenge.id,
          user_id: id,
          role: 'collaborator',
          added_by: userId
        }));

        await supabaseClient
          .from('challenge_collaborators')
          .insert(collaboratorInserts);
      }

      return new Response(JSON.stringify({ challenge }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Function error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});