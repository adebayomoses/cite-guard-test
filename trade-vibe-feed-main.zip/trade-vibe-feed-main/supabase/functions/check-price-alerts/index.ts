import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Checking price alerts...');

    // Get all active alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('triggered', false);

    if (alertsError) {
      console.error('Error fetching alerts:', alertsError);
      throw alertsError;
    }

    if (!alerts || alerts.length === 0) {
      console.log('No active alerts to check');
      return new Response(
        JSON.stringify({ message: 'No alerts to check', checked: 0 }), 
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${alerts.length} active alerts`);

    // Get current prices for all tickers
    const tickers = [...new Set(alerts.map(a => a.ticker))];
    const { data: prices, error: pricesError } = await supabase
      .from('market_prices')
      .select('*')
      .in('symbol', tickers);

    if (pricesError) {
      console.error('Error fetching prices:', pricesError);
      throw pricesError;
    }

    const priceMap = new Map(prices?.map(p => [p.symbol, p.current_price]) || []);
    let triggeredCount = 0;
    const triggeredAlerts: any[] = [];

    // Check each alert
    for (const alert of alerts) {
      const currentPrice = priceMap.get(alert.ticker);
      if (!currentPrice) {
        console.log(`No price data for ${alert.ticker}`);
        continue;
      }

      let triggered = false;
      if (alert.condition === 'above' && currentPrice >= alert.target_price) {
        triggered = true;
      } else if (alert.condition === 'below' && currentPrice <= alert.target_price) {
        triggered = true;
      }

      if (triggered) {
        // Mark as triggered
        const { error: updateError } = await supabase
          .from('price_alerts')
          .update({ 
            triggered: true, 
            triggered_at: new Date().toISOString() 
          })
          .eq('id', alert.id);

        if (updateError) {
          console.error(`Error updating alert ${alert.id}:`, updateError);
          continue;
        }

        triggeredCount++;
        triggeredAlerts.push({
          ...alert,
          current_price: currentPrice
        });

        console.log(
          `✓ Alert triggered: ${alert.ticker} ${alert.condition} $${alert.target_price} (current: $${currentPrice})`
        );

        // Create in-app notification for the user
        const notificationTitle = `Price Alert: ${alert.ticker}`;
        const notificationMessage = `${alert.ticker} is now ${alert.condition === 'above' ? 'above' : 'below'} $${alert.target_price}. Current price: $${currentPrice.toFixed(2)}`;

        const { error: notificationError } = await supabase
          .from('notifications')
          .insert({
            user_id: alert.user_id,
            type: 'price_alert',
            title: notificationTitle,
            message: notificationMessage,
            link: '/market-watch',
            metadata: {
              alert_id: alert.id,
              ticker: alert.ticker,
              condition: alert.condition,
              target_price: alert.target_price,
              current_price: currentPrice
            }
          });

        if (notificationError) {
          console.error(`Error creating notification for alert ${alert.id}:`, notificationError);
        } else {
          console.log(`✓ Notification created for user ${alert.user_id}`);
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        checked: alerts.length,
        triggered: triggeredCount,
        triggeredAlerts,
        message: `Checked ${alerts.length} alerts, triggered ${triggeredCount}` 
      }), 
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in check-price-alerts:', error);
    return new Response(
      JSON.stringify({ error: error.message }), 
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
