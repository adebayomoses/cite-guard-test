# Export project as static HTML/CSS/JS ZIP

## Goal
Generate a self-contained static export of the Inwebtify site (the same format previously used for the WordPress plugin) and deliver it as a downloadable ZIP file.

## Steps
1. **Build and export**
   - Run `bun run export:static` to produce the production build and crawl it into `./static-export/`.
   - This script already localises remote assets into `static-export/media/` and rewrites URLs, so the output is fully self-contained.

2. **Verify the export**
   - Confirm `./static-export/` contains the expected pages: `/`, `/about`, `/portfolio`, `/blog`, `/contact`, `/service-request`, `/careers`, `/esipher`, `/esipher/pricing`, plus `assets/` and `media/`.
   - Spot-check `index.html` to ensure the Esipher logo, Inwebtify logo, and localised media references are present and correct.

3. **Package into ZIP**
   - Create `inwebtify-static-export.zip` from `./static-export/` and place it in `/mnt/documents/` so it is persistent and user-visible.

4. **Deliver**
   - Present the ZIP as a chat artifact for download.

## Outcome
A single downloadable ZIP containing plain HTML, CSS, JS, images, and fonts that can be dropped into any host or WordPress setup.
