#!/usr/bin/env node
/**
 * Static site export.
 *
 * Runs the production SSR bundle in-process, renders every page to a plain
 * .html file, and copies the client assets alongside them. The result in
 * ./static-export is a flat, framework-free HTML + CSS + JS + images site —
 * the shape an "HTML to WordPress" converter expects.
 *
 * Usage:  bun run export:static      (build + export)
 */
import { cp, mkdir, rm, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";

const root = process.cwd();
const serverEntry = path.join(root, "dist/server/index.mjs");
const clientDir = path.join(root, "dist/client");
const target = path.join(root, "static-export");

// Safety valve so a large crawl can never blow up the output.
const MAX_PAGES = Number(process.env["MAX_PRERENDER_PAGES"] ?? 500);

// Entry points for the crawl. Every internal link found on these pages is
// followed, so detail pages (portfolio/blog) are picked up automatically.
const START_ROUTES = ["/", "/about", "/portfolio", "/blog", "/contact", "/service-request", "/careers"];

if (!existsSync(serverEntry) || !existsSync(clientDir)) {
  console.error("Build output missing. Run `bun run build` first.");
  process.exit(1);
}

const mod = await import(serverEntry);
const handler = mod.default ?? mod;
const ctx = { waitUntil() {}, passThroughOnException() {} };

async function render(route) {
  const response = await handler.fetch(new Request(`http://localhost${route}`), {}, ctx);
  return { status: response.status, html: await response.text() };
}

function internalLinks(html) {
  const found = new Set();
  for (const match of html.matchAll(/href="(\/[^"#?]*)"/g)) {
    const href = match[1];
    if (!href) continue;
    if (/\.[a-z0-9]{2,5}$/i.test(href)) continue; // assets
    if (href.startsWith("/__") || href.startsWith("/api/")) continue;
    found.add(href.length > 1 ? href.replace(/\/$/, "") : "/");
  }
  return found;
}

await rm(target, { recursive: true, force: true });
await mkdir(target, { recursive: true });
await cp(clientDir, target, { recursive: true });

const queue = [...START_ROUTES];
const seen = new Set(queue);
const written = [];
const failed = [];

while (queue.length > 0 && written.length < MAX_PAGES) {
  const route = queue.shift();
  const { status, html } = await render(route);
  if (status >= 400) {
    failed.push(`${route} (${status})`);
    continue;
  }

  const file = route === "/" ? "index.html" : `${route.replace(/^\//, "")}/index.html`;
  const dest = path.join(target, file);
  await mkdir(path.dirname(dest), { recursive: true });
  await writeFile(dest, html, "utf8");
  written.push(file);

  for (const link of internalLinks(html)) {
    if (!seen.has(link)) {
      seen.add(link);
      queue.push(link);
    }
  }
}

// ---------------------------------------------------------------------------
// Localise CDN-hosted assets (logo, project screenshots) so the export is
// fully self-contained: download every /__l5e/... reference into ./media and
// rewrite the URL in every HTML/CSS/JS file.
// ---------------------------------------------------------------------------
const ASSET_ORIGIN = process.env["ASSET_ORIGIN"] ?? "http://localhost:8080";
const CDN_RE = /\/__l5e\/[A-Za-z0-9._~\-/]+/g;

const textFiles = [];
async function collectText(dir) {
  const { readdir } = await import("node:fs/promises");
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await collectText(full);
    else if (/\.(html|css|js|json|txt|xml)$/i.test(entry.name)) textFiles.push(full);
  }
}
await collectText(target);

const { readFile } = await import("node:fs/promises");
const urlMap = new Map();
const contents = new Map();

for (const file of textFiles) {
  const text = await readFile(file, "utf8");
  contents.set(file, text);
  for (const match of text.match(CDN_RE) ?? []) urlMap.set(match, null);
}

await mkdir(path.join(target, "media"), { recursive: true });
const assetFailures = [];
for (const url of [...urlMap.keys()]) {
  const name = url.split("/").pop();
  try {
    const res = await fetch(`${ASSET_ORIGIN}${url}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    await writeFile(path.join(target, "media", name), Buffer.from(await res.arrayBuffer()));
    urlMap.set(url, `/media/${name}`);
  } catch (error) {
    assetFailures.push(`${url} (${error.message})`);
    urlMap.delete(url);
  }
}

for (const [file, text] of contents) {
  const next = text.replace(CDN_RE, (m) => urlMap.get(m) ?? m);
  if (next !== text) await writeFile(file, next, "utf8");
}

console.log(`\nStatic export → ./static-export (${written.length} pages)`);
for (const file of written.sort()) console.log(`  ${file}`);
console.log(`\nLocalised ${urlMap.size} CDN assets → ./static-export/media`);
if (assetFailures.length > 0) console.warn(`Asset download failed: ${assetFailures.join(", ")}`);
if (failed.length > 0) console.warn(`\nSkipped: ${failed.join(", ")}`);

