import { Link } from "@tanstack/react-router";

import logoAsset from "@/assets/inwebtify-logo.png.asset.json";
import { contact } from "@/data/site";

export function SiteFooter() {
  return (
    <footer className="border-t border-foreground/5 bg-background px-6 pt-24 pb-12">
      <div className="mx-auto max-w-7xl">
        <div className="mb-20 grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <div className="mb-8 flex items-center gap-3 text-3xl font-extrabold tracking-tighter">
              <img src={logoAsset.url} alt="Inwebtify logo" className="h-11 w-auto" />
              INWEBTIFY<span className="-ml-1 text-accent">.</span>
            </div>
            <p className="max-w-sm text-muted-foreground">
              Building the next generation of digital experiences. Secure, modern, and tailored to
              elevate your business.
            </p>
          </div>
          <div>
            <h5 className="mb-6 text-xs font-bold uppercase tracking-widest">Explore</h5>
            <ul className="space-y-4 text-muted-foreground">
              <li>
                <Link to="/portfolio" className="transition-colors hover:text-accent">
                  Work
                </Link>
              </li>
              <li>
                <Link to="/about" className="transition-colors hover:text-accent">
                  About us
                </Link>
              </li>
              <li>
                <Link to="/blog" className="transition-colors hover:text-accent">
                  Insights
                </Link>
              </li>
              <li>
                <Link to="/careers" className="transition-colors hover:text-accent">
                  Job openings
                </Link>
              </li>
              <li>
                <Link to="/service-request" className="transition-colors hover:text-accent">
                  Service request
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h5 className="mb-6 text-xs font-bold uppercase tracking-widest">Contact</h5>
            <a
              href={`mailto:${contact.email}`}
              className="mb-2 block text-muted-foreground transition-colors hover:text-accent"
            >
              {contact.email}
            </a>
            {contact.phones.map((p) => (
              <a
                key={p}
                href={`tel:${p.replace(/\s/g, "")}`}
                className="block text-muted-foreground transition-colors hover:text-accent"
              >
                {p}
              </a>
            ))}
          </div>
        </div>
        <div className="flex flex-col items-center justify-between gap-4 border-t border-foreground/5 pt-8 md:flex-row">
          <p className="text-xs uppercase tracking-widest text-muted-foreground/60">
            &copy; {new Date().getFullYear()} Inwebtify Digital. All Rights Reserved.
          </p>
          <div className="flex gap-8 text-xs font-medium uppercase tracking-widest text-muted-foreground/60">
            <span>Ibadan, Nigeria</span>
            <span>{contact.hours}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
