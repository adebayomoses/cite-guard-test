import type { ReactNode } from "react";

import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export function PageShell({
  eyebrow,
  title,
  lead,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  lead?: string;
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-accent selection:text-accent-foreground">
      <SiteHeader />
      <header className="px-6 pt-40 pb-16">
        <div className="mx-auto max-w-7xl">
          <span className="mb-6 block text-xs font-bold uppercase tracking-widest text-accent">
            {eyebrow}
          </span>
          <h1 className="max-w-4xl text-balance text-5xl font-extrabold leading-[0.95] tracking-tight md:text-7xl">
            {title}
          </h1>
          {lead && (
            <p className="mt-8 max-w-2xl text-xl leading-relaxed text-muted-foreground">{lead}</p>
          )}
        </div>
      </header>
      <main>{children}</main>
      <SiteFooter />
    </div>
  );
}

export function Field({
  label,
  name,
  type = "text",
  required,
  options,
  textarea,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  options?: string[];
  textarea?: boolean;
}) {
  const base =
    "w-full rounded-xl border border-foreground/10 bg-card px-4 py-3 text-base outline-none transition-colors focus:border-accent";
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-bold uppercase tracking-widest text-muted-foreground">
        {label}
        {required && <span className="text-accent"> *</span>}
      </span>
      {options ? (
        <select name={name} required={required} className={base}>
          {options.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      ) : textarea ? (
        <textarea name={name} required={required} rows={5} className={base} />
      ) : (
        <input name={name} type={type} required={required} className={base} />
      )}
    </label>
  );
}
