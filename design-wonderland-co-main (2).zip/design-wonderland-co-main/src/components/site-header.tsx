import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

import logoAsset from "@/assets/inwebtify-logo.png.asset.json";

const links = [
  { to: "/portfolio", label: "Work" },
  
  { to: "/about", label: "About" },
  { to: "/blog", label: "Insights" },
  { to: "/careers", label: "Careers" },
  { to: "/contact", label: "Contact" },
] as const;


export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 z-50 w-full border-b border-foreground/5 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-3 text-2xl font-extrabold tracking-tighter">
          <img src={logoAsset.url} alt="Inwebtify logo" className="h-9 w-auto" />
          INWEBTIFY<span className="-ml-1 text-accent">.</span>
        </Link>

        <div className="hidden items-center gap-9 text-sm font-medium uppercase tracking-wide md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="transition-colors hover:text-accent"
              activeProps={{ className: "text-accent" }}
            >
              {l.label}
            </Link>
          ))}
          <Link
            to="/service-request"
            className="rounded-full bg-foreground px-6 py-3 text-background transition-all hover:bg-accent"
          >
            Start Project
          </Link>
        </div>

        <button
          type="button"
          aria-label="Toggle menu"
          onClick={() => setOpen((v) => !v)}
          className="md:hidden"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-foreground/5 bg-background px-6 py-6 md:hidden">
          <div className="flex flex-col gap-5 text-sm font-medium uppercase tracking-wide">
            {links.map((l) => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
            <Link
              to="/service-request"
              onClick={() => setOpen(false)}
              className="rounded-full bg-foreground px-6 py-3 text-center text-background"
            >
              Start Project
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
