import { createFileRoute } from "@tanstack/react-router";

import { Field, PageShell } from "@/components/page-shell";
import { contact } from "@/data/site";

export const Route = createFileRoute("/service-request")({
  component: ServiceRequestPage,
  head: () => ({
    meta: [
      { title: "Service Request — Inwebtify" },
      {
        name: "description",
        content:
          "Request a website, mobile app, software product or optimisation service from Inwebtify. Tell us your scope, timeline and budget.",
      },
      { property: "og:title", content: "Service Request — Inwebtify" },
      {
        property: "og:description",
        content: "Request a website, app, software product or optimisation service from Inwebtify.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function ServiceRequestPage() {
  return (
    <PageShell
      eyebrow="Service request"
      title={
        <>
          Tell us what you want{" "}
          <span className="font-light italic text-muted-foreground/40">built</span>.
        </>
      }
      lead="Share the details of your project and our team will come back with scope, timeline and next steps."
    >
      <section className="px-6 pb-32">
        <form
          action={`mailto:${contact.email}`}
          method="post"
          encType="text/plain"
          className="mx-auto max-w-3xl space-y-6 rounded-2xl border border-foreground/10 bg-card p-8 md:p-12"
        >
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="Full name" name="name" required />
            <Field label="Company / organisation" name="company" />
            <Field label="Email address" name="email" type="email" required />
            <Field label="Phone" name="phone" type="tel" />
          </div>
          <Field
            label="Service needed"
            name="service"
            options={[
              "Website Development",
              "Software Development",
              "Mobile App Development",
              "Web & App Optimization",
              "Brand Strategy & Design",
              "Other",
            ]}
          />
          <Field
            label="Estimated budget"
            name="budget"
            options={["Under $1,000", "$1,000 – $5,000", "$5,000 – $15,000", "$15,000+", "Not sure yet"]}
          />
          <Field
            label="Timeline"
            name="timeline"
            options={["As soon as possible", "1 – 3 months", "3 – 6 months", "Flexible"]}
          />
          <Field label="Project details" name="details" textarea required />
          <button
            type="submit"
            className="w-full rounded-full bg-foreground px-8 py-4 text-sm font-bold uppercase tracking-widest text-background transition-colors hover:bg-accent"
          >
            Submit request
          </button>
        </form>
      </section>
    </PageShell>
  );
}
