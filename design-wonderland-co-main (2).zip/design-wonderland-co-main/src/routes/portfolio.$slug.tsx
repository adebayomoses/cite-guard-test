import { createFileRoute, Link, notFound } from "@tanstack/react-router";

import { PageShell } from "@/components/page-shell";
import { projects } from "@/data/site";

export const Route = createFileRoute("/portfolio/$slug")({
  loader: ({ params }) => {
    const project = projects.find((p) => p.slug === params.slug);
    if (!project) throw notFound();
    return { project };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Project not found — Inwebtify" }, { name: "robots", content: "noindex" }] };
    }
    const { project } = loaderData;
    const title = `${project.title} — Inwebtify Portfolio`;
    return {
      meta: [
        { title },
        { name: "description", content: project.summary },
        { property: "og:title", content: title },
        { property: "og:description", content: project.summary },
        { property: "og:type", content: "article" },
        { property: "og:image", content: project.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: project.image },
      ],
    };
  },
  component: ProjectPage,
});

function ProjectPage() {
  const { project } = Route.useLoaderData();
  const others = projects.filter((p) => p.slug !== project.slug).slice(0, 3);

  return (
    <PageShell eyebrow={project.category} title={project.title} lead={project.summary}>
      <section className="px-6 pb-16">
        <div className="mx-auto max-w-7xl overflow-hidden rounded-2xl border border-foreground/10 bg-card">
          <img
            src={project.image}
            alt={`${project.title} website designed and built by Inwebtify`}
            className="w-full object-cover object-top"
          />
        </div>
        {project.url && (
          <div className="mx-auto mt-10 flex max-w-7xl items-center gap-4">
            <a
              href={project.url}
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-sm font-bold uppercase tracking-widest text-primary-foreground transition-colors hover:bg-primary/90"
            >
              View live website
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" x2="21" y1="14" y2="3" />
              </svg>
            </a>
            <span className="text-sm text-muted-foreground">{project.url.replace(/^https?:\/\//, "").replace(/\/$/, "")}</span>
          </div>
        )}
      </section>

      <section className="border-t border-foreground/5 px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-12 text-3xl font-bold tracking-tight">More work</h2>
          <div className="grid gap-10 sm:grid-cols-3">
            {others.map((p) => (
              <Link key={p.slug} to="/portfolio/$slug" params={{ slug: p.slug }} className="group">
                <div className="overflow-hidden rounded-xl border border-foreground/10 bg-card">
                  <img
                    src={p.image}
                    alt={p.title}
                    loading="lazy"
                    className="aspect-[4/3] w-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.03]"
                  />
                </div>
                <h3 className="mt-4 text-lg font-bold">{p.title}</h3>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
