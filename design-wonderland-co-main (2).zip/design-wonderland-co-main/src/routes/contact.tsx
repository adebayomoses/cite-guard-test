import { createFileRoute } from "@tanstack/react-router";

import { Field, PageShell } from "@/components/page-shell";
import { contact } from "@/data/site";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact Inwebtify — Let's Talk About Your Project" },
      {
        name: "description",
        content:
          "Reach the Inwebtify team by phone or email, or send a message about your website or software project.",
      },
      { property: "og:title", content: "Contact Inwebtify — Let's Talk About Your Project" },
      {
        property: "og:description",
        content: "Reach the Inwebtify team by phone, email, or send us a message.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function ContactPage() {
  return (
    <PageShell
      eyebrow="Contact us"
      title={
        <>
          Start a <span className="font-light italic text-muted-foreground/40">conversation</span>.
        </>
      }
      lead="Tell us about your project and we'll get back to you. Our support team is available around the clock."
    >
      <section className="px-6 pb-32">
        <div className="mx-auto grid max-w-7xl gap-16 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-10">
            {[
              ["Phone", contact.phones.join(" · ")],
              ["Email", contact.email],
              ["Hours", contact.hours],
            ].map(([label, value]) => (
              <div key={label} className="border-t border-foreground/10 pt-5">
                <span className="text-xs font-bold uppercase tracking-widest text-accent">
                  {label}
                </span>
                <p className="mt-2 text-xl font-medium">{value}</p>
              </div>
            ))}
          </div>

          <form
            action={`mailto:${contact.email}`}
            method="post"
            encType="text/plain"
            className="space-y-6 rounded-2xl border border-foreground/10 bg-card p-8 md:p-12"
          >
            <Field label="Your name" name="name" required />
            <Field label="Email address" name="email" type="email" required />
            <Field label="Phone" name="phone" type="tel" />
            <Field label="Subject" name="subject" />
            <Field label="Message" name="message" textarea required />
            <button
              type="submit"
              className="w-full rounded-full bg-foreground px-8 py-4 text-sm font-bold uppercase tracking-widest text-background transition-colors hover:bg-accent"
            >
              Send message
            </button>
          </form>
        </div>
      </section>
    </PageShell>
  );
}
