import { createFileRoute } from "@tanstack/react-router";

import { Field, PageShell } from "@/components/page-shell";
import { contact } from "@/data/site";

export const Route = createFileRoute("/careers")({
  component: CareersPage,
  head: () => ({
    meta: [
      { title: "Job Openings — Careers at Inwebtify" },
      {
        name: "description",
        content:
          "Join Inwebtify. We hire designers, developers and strategists who care about building practical technology that serves people.",
      },
      { property: "og:title", content: "Job Openings — Careers at Inwebtify" },
      {
        property: "og:description",
        content: "We hire designers, developers and strategists who build practical technology.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const roles = [
  ["Full Stack Developer", "Remote / Ibadan", "End-to-end product work across front and back end."],
  ["Front End Developer", "Remote / Ibadan", "React, TypeScript, modern CSS."],
  ["Back End Developer", "Remote / Ibadan", "APIs, databases, cloud infrastructure."],
  ["Mobile App Developer", "Remote", "Cross-platform mobile products."],
  ["Software Engineer", "Remote / Ibadan", "Secure, scalable systems engineering."],
];


function CareersPage() {
  return (
    <PageShell
      eyebrow="Job openings"
      title={
        <>
          Build things that{" "}
          <span className="font-light italic text-muted-foreground/40">matter</span> with us.
        </>
      }
      lead="We're always interested in people who care about craft, clarity and real-world impact."
    >
      <section className="px-6 pb-24">
        <div className="mx-auto max-w-7xl divide-y divide-foreground/10 border-y border-foreground/10">
          {roles.map(([title, location, detail]) => (
            <div key={title} className="grid gap-2 py-8 md:grid-cols-[1fr_auto] md:items-center">
              <div>
                <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
                <p className="mt-1 text-muted-foreground">{detail}</p>
              </div>
              <span className="text-xs font-bold uppercase tracking-widest text-accent">
                {location}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section className="px-6 pb-32">
        <form
          action={`mailto:${contact.email}`}
          method="post"
          encType="text/plain"
          className="mx-auto max-w-3xl space-y-6 rounded-2xl border border-foreground/10 bg-card p-8 md:p-12"
        >
          <h2 className="text-3xl font-bold tracking-tight">Apply</h2>
          <div className="grid gap-6 sm:grid-cols-2">
            <Field label="Full name" name="name" required />
            <Field label="Email address" name="email" type="email" required />
            <Field label="Phone" name="phone" type="tel" />
            <Field label="Role applying for" name="role" options={roles.map((r) => r[0] as string)} />
          </div>
          <Field label="Portfolio or LinkedIn URL" name="portfolio" />
          <Field label="Why you'd be a great fit" name="message" textarea required />
          <p className="text-sm text-muted-foreground">
            Prefer to send a CV? Email it to {contact.email}.
          </p>
          <button
            type="submit"
            className="w-full rounded-full bg-foreground px-8 py-4 text-sm font-bold uppercase tracking-widest text-background transition-colors hover:bg-accent"
          >
            Submit application
          </button>
        </form>
      </section>
    </PageShell>
  );
}
