import { createFileRoute, Link } from "@tanstack/react-router";

import esipherLogo from "@/assets/esipher-logo.png";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/esipher/")({
  component: EsipherPage,
  head: () => ({
    meta: [
      { title: "Esipher by Inwebtify — AI Designs to WordPress" },
      {
        name: "description",
        content:
          "Esipher is a WordPress plugin by Inwebtify that converts AI-built websites and apps from Lovable, Figma and others into fully working WordPress sites.",
      },
      { property: "og:title", content: "Esipher by Inwebtify — AI Designs to WordPress" },
      {
        property: "og:description",
        content:
          "Easy site transfer: turn AI-generated websites and apps into real WordPress sites in minutes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const steps = [
  {
    title: "Connect your build",
    body: "Point Esipher at your AI-generated site — a Lovable project, a Figma export, or a static HTML build.",
  },
  {
    title: "Convert the structure",
    body: "Pages, sections, styles and media are mapped into clean WordPress templates and reusable blocks.",
  },
  {
    title: "Publish on WordPress",
    body: "Everything lands in your WordPress install, editable in the block editor and ready to go live.",
  },
];

const features = [
  {
    title: "Multi-source imports",
    body: "Lovable, Figma, and generic HTML/CSS/JS exports are all supported sources.",
  },
  {
    title: "Media localisation",
    body: "Images, fonts and icons are downloaded into your media library — no broken CDN links.",
  },
  {
    title: "Editable output",
    body: "Converted pages remain fully editable in WordPress, not locked behind an iframe.",
  },
  {
    title: "Theme friendly",
    body: "Works alongside your existing theme or generates a standalone one for the imported design.",
  },
  {
    title: "Responsive preserved",
    body: "Breakpoints and layout behaviour carry over so mobile stays exactly as designed.",
  },
  {
    title: "Apps too",
    body: "Interactive app screens are converted into WordPress-hosted pages with their scripts intact.",
  },
];

function EsipherPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-accent selection:text-accent-foreground">
      <SiteHeader />

      <section className="px-6 pt-40 pb-20">
        <div className="mx-auto grid max-w-7xl items-center gap-16 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <span className="mb-6 block text-xs font-bold uppercase tracking-widest text-accent">
              A product by Inwebtify
            </span>
            <div className="mb-8 flex items-center gap-4">
              <img
                src={esipherLogo}
                alt="Esipher logo"
                width={816}
                height={816}
                className="h-16 w-16"
              />
              <span className="text-5xl font-extrabold tracking-tighter md:text-6xl">
                Esipher<span className="text-accent">.</span>
              </span>
            </div>
            <h1 className="text-balance text-4xl font-extrabold leading-[0.95] tracking-tight md:text-6xl">
              Easy site transfer —{" "}
              <span className="font-light italic text-muted-foreground/40">
                AI designs into WordPress
              </span>
            </h1>
            <p className="mt-8 max-w-xl text-xl leading-relaxed text-muted-foreground">
              Esipher is a WordPress plugin that converts AI-built websites and apps — from Lovable,
              Figma and other design tools — into real, editable WordPress sites.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/contact"
                className="rounded-full bg-accent px-8 py-4 text-sm font-bold uppercase tracking-widest text-accent-foreground transition-opacity hover:opacity-90"
              >
                Request early access
              </Link>
              <Link
                to="/esipher/pricing"
                className="rounded-full border border-foreground/15 px-8 py-4 text-sm font-bold uppercase tracking-widest transition-colors hover:border-accent hover:text-accent"
              >
                Free vs Pro
              </Link>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-3xl border border-foreground/10 bg-card p-8">
              <div className="space-y-4">
                <div className="rounded-2xl border border-foreground/10 p-5">
                  <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                    Source
                  </div>
                  <div className="mt-2 font-bold">AI-generated design</div>
                </div>
                <div className="flex justify-center">
                  <img
                    src={esipherLogo}
                    alt=""
                    aria-hidden="true"
                    loading="lazy"
                    width={816}
                    height={816}
                    className="h-10 w-10 rotate-90"
                  />
                </div>
                <div className="rounded-2xl border border-accent/40 bg-accent/5 p-5">
                  <div className="text-xs font-bold uppercase tracking-widest text-accent">
                    Output
                  </div>
                  <div className="mt-2 font-bold">Editable WordPress site</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-foreground px-6 py-24 text-background">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-16 text-4xl font-bold tracking-tight md:text-5xl">How it works</h2>
          <div className="grid gap-px overflow-hidden rounded-2xl border border-background/15 bg-background/15 md:grid-cols-3">
            {steps.map((step, i) => (
              <div key={step.title} className="bg-foreground p-12">
                <div className="mb-6 text-xs font-bold uppercase tracking-widest text-accent">
                  Step 0{i + 1}
                </div>
                <h3 className="mb-4 text-2xl font-bold">{step.title}</h3>
                <p className="leading-relaxed text-background/60">{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-16">
            <h2 className="mb-4 text-4xl font-bold tracking-tight md:text-5xl">What you get</h2>
            <div className="h-1 w-24 bg-accent" />
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="rounded-2xl border border-foreground/10 p-8">
                <h3 className="mb-3 text-xl font-bold">{f.title}</h3>
                <p className="leading-relaxed text-muted-foreground">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-steel-100 px-6 py-24">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 md:flex-row md:items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
              Be first to build with Esipher.
            </h2>
            <p className="mt-3 max-w-xl text-muted-foreground">
              We are onboarding early users ahead of launch. Tell us about your stack and we will get
              you in.
            </p>
          </div>
          <Link
            to="/esipher/pricing"
            className="rounded-full bg-foreground px-8 py-4 text-sm font-bold uppercase tracking-widest text-background transition-colors hover:bg-accent"
          >
            See Free vs Pro
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
