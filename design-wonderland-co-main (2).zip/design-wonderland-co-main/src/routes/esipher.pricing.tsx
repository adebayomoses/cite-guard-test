import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Minus } from "lucide-react";

import esipherLogo from "@/assets/esipher-logo.png";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/esipher/pricing")({
  component: EsipherPricingPage,
  head: () => ({
    meta: [
      { title: "Esipher Free vs Pro — AI Designs to WordPress" },
      {
        name: "description",
        content:
          "Compare Esipher Free and Pro: convert AI-built websites from Lovable and Figma into editable WordPress sites. See features, limits and support.",
      },
      { property: "og:title", content: "Esipher Free vs Pro — AI Designs to WordPress" },
      {
        property: "og:description",
        content:
          "Compare Esipher Free and Pro: convert AI-built websites from Lovable and Figma into editable WordPress sites.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

type Cell = boolean | string;

const comparison: { label: string; free: Cell; pro: Cell }[] = [
  { label: "Bring in your design from Lovable, Figma or HTML", free: true, pro: true },
  { label: "Edit everything in the normal WordPress editor", free: true, pro: true },
  { label: "Looks exactly right on phones, tablets and desktop", free: true, pro: true },
  { label: "Pages per website", free: "Up to 4", pro: "Unlimited" },
  { label: "Websites you can convert", free: "1", pro: "Unlimited" },
  { label: "Images and fonts saved to your site", free: "Standard", pro: "Priority + auto-optimised for faster loading" },
  { label: "Convert interactive apps and dashboards", free: false, pro: true },
  { label: "Get your own custom WordPress theme from your design", free: false, pro: true },
  { label: "Remove Esipher branding from your site", free: false, pro: true },
  { label: "One-click re-import when you update your design", free: false, pro: true },
  { label: "Email support from a real person", free: "Community", pro: "Priority replies" },
];

function Mark({ value }: { value: Cell }) {
  if (value === true) return <Check className="mx-auto h-5 w-5 text-accent" aria-label="Included" />;
  if (value === false)
    return <Minus className="mx-auto h-5 w-5 text-muted-foreground/40" aria-label="Not included" />;
  return <span className="text-sm font-semibold">{value}</span>;
}

function EsipherPricingPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground selection:bg-accent selection:text-accent-foreground">
      <SiteHeader />

      <header className="px-6 pt-40 pb-16">
        <div className="mx-auto max-w-7xl">
          <Link
            to="/esipher"
            className="mb-6 inline-flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-accent hover:opacity-80"
          >
            <img src={esipherLogo} alt="" className="h-6 w-6" /> Esipher
          </Link>
          <h1 className="max-w-4xl text-balance text-5xl font-extrabold leading-[0.95] tracking-tight md:text-7xl">
            Free vs Pro
          </h1>
          <p className="mt-8 max-w-2xl text-xl leading-relaxed text-muted-foreground">
            Start free and move your first AI-built site to WordPress today. Upgrade to Pro when you
            outgrow 4 pages, want your own theme, or need a real person on email when you're stuck.
          </p>
        </div>
      </header>

      <main>
        <section className="px-6 pb-24">
          <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-2">
            <div className="rounded-3xl border border-foreground/10 bg-card p-10">
              <h2 className="text-2xl font-bold">Free</h2>
              <p className="mt-2 text-muted-foreground">
                Perfect for trying it out — one small site, up to 4 pages.
              </p>
              <div className="mt-6 text-5xl font-extrabold tracking-tight">
                $0<span className="text-base font-medium text-muted-foreground"> forever</span>
              </div>
              <ul className="mt-8 space-y-3">
                {comparison.slice(0, 6).map((row) => (
                  <li key={row.label} className="flex items-start gap-3 text-sm">
                    {row.free === true ? (
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    ) : row.free === false ? (
                      <Minus className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground/40" />
                    ) : (
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    )}
                    <span>
                      {row.label}
                      {typeof row.free === "string" && (
                        <span className="font-semibold"> — {row.free}</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
              <Link
                to="/contact"
                className="mt-10 block rounded-full border border-foreground/15 px-8 py-4 text-center text-sm font-bold uppercase tracking-widest transition-colors hover:border-accent hover:text-accent"
              >
                Get started free
              </Link>
            </div>

            <div className="relative rounded-3xl border-2 border-accent bg-foreground p-10 text-background">
              <span className="absolute -top-4 left-10 rounded-full bg-accent px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-accent-foreground">
                Recommended
              </span>
              <h2 className="text-2xl font-bold">Pro</h2>
              <p className="mt-2 text-background/60">
                For anyone running a real site — no page limits, your own theme, and no Esipher
                branding.
              </p>
              <div className="mt-6 text-5xl font-extrabold tracking-tight">
                $99<span className="text-base font-medium text-background/60"> / year</span>
              </div>
              <ul className="mt-8 space-y-3 text-sm">
                <li className="flex items-start gap-3">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                  <span>Everything in Free, plus:</span>
                </li>
                {comparison.slice(3).map((row) => (
                  <li key={row.label} className="flex items-start gap-3">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
                    <span>
                      {row.label}
                      {typeof row.pro === "string" && (
                        <span className="font-semibold"> — {row.pro}</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
              <Link
                to="/contact"
                className="mt-10 block rounded-full bg-accent px-8 py-4 text-center text-sm font-bold uppercase tracking-widest text-accent-foreground transition-opacity hover:opacity-90"
              >
                Get Pro
              </Link>
            </div>
          </div>
        </section>

        <section className="px-6 pb-24">
          <div className="mx-auto max-w-5xl overflow-hidden rounded-3xl border border-foreground/10">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-foreground/10 bg-steel-100">
                  <th className="px-6 py-4 font-bold">Feature</th>
                  <th className="px-6 py-4 text-center font-bold">Free</th>
                  <th className="px-6 py-4 text-center font-bold text-accent">Pro</th>
                </tr>
              </thead>
              <tbody>
                {comparison.map((row, i) => (
                  <tr
                    key={row.label}
                    className={i % 2 === 0 ? "bg-card" : "bg-background"}
                  >
                    <td className="px-6 py-4">{row.label}</td>
                    <td className="px-6 py-4 text-center">
                      <Mark value={row.free} />
                    </td>
                    <td className="px-6 py-4 text-center">
                      <Mark value={row.pro} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="bg-foreground px-6 py-24 text-background">
          <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 md:flex-row md:items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
                Not sure which fits?
              </h2>
              <p className="mt-3 max-w-xl text-background/60">
                Start with Free — everything you've converted carries over when you upgrade to Pro,
                so nothing is ever lost.
              </p>
            </div>
            <Link
              to="/contact"
              className="rounded-full bg-accent px-8 py-4 text-sm font-bold uppercase tracking-widest text-accent-foreground transition-opacity hover:opacity-90"
            >
              Talk to us
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
