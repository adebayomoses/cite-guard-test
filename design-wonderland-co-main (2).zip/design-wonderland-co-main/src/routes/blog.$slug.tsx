import { createFileRoute, Link, notFound } from "@tanstack/react-router";

import { PageShell } from "@/components/page-shell";
import { posts } from "@/data/site";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = posts.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return { post };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Post not found — Inwebtify" }, { name: "robots", content: "noindex" }] };
    }
    const { post } = loaderData;
    const title = `${post.title} — Inwebtify Blog`;
    return {
      meta: [
        { title },
        { name: "description", content: post.excerpt },
        { property: "og:title", content: title },
        { property: "og:description", content: post.excerpt },
        { property: "og:type", content: "article" },
        { property: "og:image", content: post.image },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: post.image },
      ],
    };
  },
  component: PostPage,
});

function PostPage() {
  const { post } = Route.useLoaderData();

  return (
    <PageShell eyebrow={`${post.category} · ${post.date}`} title={post.title}>
      <article className="px-6 pb-32">
        <div className="mx-auto max-w-4xl overflow-hidden rounded-2xl border border-foreground/10 bg-card">
          <img src={post.image} alt={post.title} className="w-full object-cover" />
        </div>
        <div className="mx-auto mt-12 max-w-3xl space-y-6">
          {post.body.map((paragraph) => (
            <p key={paragraph.slice(0, 40)} className="text-lg leading-relaxed text-muted-foreground">
              {paragraph}
            </p>
          ))}
        </div>
        <div className="mx-auto mt-16 max-w-3xl border-t border-foreground/10 pt-8">
          <Link to="/blog" className="text-sm font-bold uppercase tracking-widest text-accent">
            ← All posts
          </Link>
        </div>
      </article>
    </PageShell>
  );
}
