import { createFileRoute, Link } from "@tanstack/react-router";

import { PageShell } from "@/components/page-shell";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: "About Inwebtify — Digital Innovation Studio" },
      {
        name: "description",
        content:
          "Inwebtify is a digital innovation studio building websites and software products that help businesses, institutions, and communities grow.",
      },
      { property: "og:title", content: "About Inwebtify — Digital Innovation Studio" },
      {
        property: "og:description",
        content:
          "We design and develop reliable, user-centred digital products that help organisations operate smarter and scale faster.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const values = [
  "Purpose-Driven Innovation",
  "User-First Thinking",
  "Excellence & Integrity",
  "Collaboration",
  "Continuous Growth",
];

function AboutPage() {
  return (
    <PageShell
      eyebrow="About us"
      title={
        <>
          Technology that <span className="font-light italic text-muted-foreground/40">works</span>{" "}
          in the real world.
        </>
      }
      lead="Inwebtify is a digital innovation studio focused on building technology that solves real-world problems. We design and develop websites and software products that help businesses, institutions, and communities grow, operate efficiently, and create measurable impact."
    >
      <section className="px-6 pb-24">
        <div className="mx-auto grid max-w-7xl gap-px overflow-hidden rounded-2xl border border-foreground/10 bg-foreground/10 md:grid-cols-2">
          <div className="bg-background p-12">
            <h2 className="mb-4 text-3xl font-bold tracking-tight">Our Vision</h2>
            <p className="leading-relaxed text-muted-foreground">
              To identify Nigeria's most pressing challenges and solve them with practical digital
              technology — building solutions that empower communities, strengthen businesses, and
              create lasting progress across the country.
            </p>
          </div>
          <div className="bg-background p-12">
            <h2 className="mb-4 text-3xl font-bold tracking-tight">Our Mission</h2>
            <p className="leading-relaxed text-muted-foreground">
              To design and develop reliable, user-centred digital products that turn complex local
              problems into simple, scalable solutions — helping organisations and individuals in
              Nigeria operate smarter, grow faster, and make real-world impact through technology.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-foreground px-6 py-24 text-background">
        <div className="mx-auto max-w-7xl">
          <h2 className="mb-16 text-4xl font-bold tracking-tight md:text-6xl">Our Values</h2>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {values.map((v, i) => (
              <div key={v} className="border-t border-background/20 pt-6">
                <span className="text-xs font-bold uppercase tracking-widest text-accent">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-3 text-2xl font-bold">{v}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-y border-foreground/5 bg-card px-6 py-16">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 sm:grid-cols-3">
          {[
            ["115", "Projects Completed"],
            ["98", "Happy Clients"],
            ["76", "Businesses Served"],
          ].map(([n, l]) => (
            <div key={l} className="text-center sm:text-left">
              <div className="font-display text-5xl font-bold">{n}</div>
              <div className="mt-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">
                {l}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="px-6 py-24">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-4xl font-bold tracking-tight">Let's build something that works.</h2>
          <p className="mt-4 text-muted-foreground">
            Founded on the belief that technology should be practical, accessible, and purpose
            driven, Inwebtify bridges the gap between ideas and execution.
          </p>
          <Link
            to="/contact"
            className="mt-8 inline-flex rounded-full bg-foreground px-8 py-4 text-sm font-bold uppercase tracking-widest text-background transition-colors hover:bg-accent"
          >
            Contact us
          </Link>
        </div>
      </section>
    </PageShell>
  );
}
