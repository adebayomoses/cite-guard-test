import { createFileRoute, Link } from "@tanstack/react-router";

import { PageShell } from "@/components/page-shell";
import { posts } from "@/data/site";

export const Route = createFileRoute("/blog/")({
  component: BlogPage,
  head: () => ({
    meta: [
      { title: "Blog — Insights from Inwebtify" },
      {
        name: "description",
        content:
          "Announcements, community work and product thinking from the Inwebtify team on building digital tools that solve real problems.",
      },
      { property: "og:title", content: "Blog — Insights from Inwebtify" },
      {
        property: "og:description",
        content: "Announcements, community work and product thinking from the Inwebtify team.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function BlogPage() {
  return (
    <PageShell
      eyebrow="Blog"
      title={
        <>
          Notes on building{" "}
          <span className="font-light italic text-muted-foreground/40">useful</span> technology.
        </>
      }
      lead="Announcements, community work and product thinking from the Inwebtify team."
    >
      <section className="px-6 pb-32">
        <div className="mx-auto max-w-7xl divide-y divide-foreground/10 border-t border-foreground/10">
          {posts.map((post) => (
            <Link
              key={post.slug}
              to="/blog/$slug"
              params={{ slug: post.slug }}
              className="group grid gap-8 py-12 md:grid-cols-[320px_1fr]"
            >
              <div className="overflow-hidden rounded-xl border border-foreground/10 bg-card">
                <img
                  src={post.image}
                  alt={post.title}
                  loading="lazy"
                  className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-accent">
                  {post.category} · {post.date}
                </span>
                <h2 className="mt-3 text-3xl font-bold tracking-tight">{post.title}</h2>
                <p className="mt-3 max-w-2xl leading-relaxed text-muted-foreground">
                  {post.excerpt}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
