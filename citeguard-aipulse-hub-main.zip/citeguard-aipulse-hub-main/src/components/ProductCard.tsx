import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download } from "lucide-react";

interface ProductCardProps {
  name: string;
  description: string;
  features: string[];
  imageSrc: string;
  imageAlt: string;
  primaryColor?: "primary" | "secondary";
}

const ProductCard = ({
  name,
  description,
  features,
  imageSrc,
  imageAlt,
  primaryColor = "primary",
}: ProductCardProps) => {
  return (
    <Card className="overflow-hidden border-border/50 shadow-[var(--shadow-card)] bg-gradient-to-br from-card to-card/80 hover:shadow-[var(--shadow-elegant)] transition-all duration-500">
      <div className="grid md:grid-cols-2 gap-8 p-8 items-center">
        <div className="space-y-6">
          <div>
            <h2 className="text-4xl font-bold mb-3 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              {name}
            </h2>
            <p className="text-muted-foreground text-lg">{description}</p>
          </div>
          
          <ul className="space-y-3">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                <span className="text-foreground/90">{feature}</span>
              </li>
            ))}
          </ul>

          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button 
              size="lg" 
              className={`group ${primaryColor === "primary" ? "bg-primary hover:bg-primary/90" : "bg-secondary hover:bg-secondary/90"} text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300`}
            >
              <Download className="mr-2 h-5 w-5 group-hover:animate-bounce" />
              Download for Windows
            </Button>
            {/* <Button 
              size="lg" 
              variant="outline"
              className="border-border hover:bg-accent/10 transition-all duration-300"
            >
              <Apple className="mr-2 h-5 w-5" />
              Download for Mac
            </Button> */}
          </div>
        </div>

        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl blur-2xl group-hover:blur-3xl transition-all duration-500" />
          <img
            src={imageSrc}
            alt={imageAlt}
            className="relative rounded-2xl w-full max-w-xs mx-auto h-auto object-contain shadow-2xl transform group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      </div>
    </Card>
  );
};

export default ProductCard;
