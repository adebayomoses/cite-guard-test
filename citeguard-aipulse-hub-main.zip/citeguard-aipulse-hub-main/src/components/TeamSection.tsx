import { Card } from "@/components/ui/card";

interface TeamMember {
  name: string;
  title: string;
  description: string;
  avatarColor: string;
  initial: string;
}

const teamMembers: TeamMember[] = [
  {
    name: "James Duru",
    title: "Tax & Research Analyst",
    description: "Seasoned professional specializing in individual and business tax computation, with broader expertise in tax strategy and scholarly research.",
    avatarColor: "bg-primary",
    initial: "A"
  },
  {
    name: "Sunday Damilare Ogunleye",
    title: "MSc Management and Data Analytics",
    description: "A Senior Financial Analyst with Indiana University Foundation.",
    avatarColor: "bg-emerald-500",
    initial: "B"
  },
  {
    name: "Moses Adebayo",
    title: "Software Developer",
    description: "",
    avatarColor: "bg-secondary",
    initial: "C"
  }
];

const TeamSection = () => {
  return (
    <section className="container mx-auto px-4 py-20">
      <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
        Our Team
      </h2>
      
      <div className="grid md:grid-cols-3 gap-8">
        {teamMembers.map((member, index) => (
          <Card 
            key={index}
            className="p-8 bg-gradient-to-br from-card to-card/80 border-border/50 shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-elegant)] transition-all duration-500 hover:-translate-y-1"
          >
            <div className="flex flex-col items-start space-y-4">
              <div className={`w-14 h-14 rounded-full ${member.avatarColor} flex items-center justify-center text-white text-xl font-bold shadow-lg`}>
                {member.initial}
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-foreground">
                  {member.name}
                </h3>
                <p className="text-muted-foreground font-medium">
                  {member.title}
                </p>
              </div>
              
              <p className="text-foreground/80 leading-relaxed">
                {member.description}
              </p>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default TeamSection;
