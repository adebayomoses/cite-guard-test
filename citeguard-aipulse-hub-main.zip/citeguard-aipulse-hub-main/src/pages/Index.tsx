import { Shield } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import TeamSection from "@/components/TeamSection";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[var(--gradient-hero)] opacity-10" />
        <div className="container mx-auto px-4 py-24 relative">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-secondary shadow-[var(--shadow-elegant)] mb-6">
              <Shield className="w-10 h-10 text-primary-foreground" />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent leading-tight">
              AI & Cite Guard
            </h1>
            
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Advanced protection solutions for your digital and academic work. 
              Download our powerful guard applications and secure your content today.
            </p>
            
            <div className="flex flex-wrap justify-center gap-4 pt-6">
              <div className="px-6 py-3 rounded-full bg-card border border-border shadow-md">
                <span className="text-sm font-medium text-foreground">🛡️ Enterprise-Grade Security</span>
              </div>
              <div className="px-6 py-3 rounded-full bg-card border border-border shadow-md">
                <span className="text-sm font-medium text-foreground">⚡ Lightning Fast</span>
              </div>
              <div className="px-6 py-3 rounded-full bg-card border border-border shadow-md">
                <span className="text-sm font-medium text-foreground">🎯 Easy to Use</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="container mx-auto px-4 py-20 space-y-16">
        <ProductCard
          name="Cite Guard"
          description="File Content Viewer helps you quickly extract, view, and lightly edit text from PDF and Word (.docx) files. It also includes a citation checker and the built-in Cite Guard Assistant to help format and validate your references."
          features={[
            "Quick text extraction from PDF and Word (.docx) files",
            "View and lightly edit document content",
            "Built-in citation checker for accuracy",
            "Cite Guard Assistant for formatting references",
            "Validate citations across multiple formats"
          ]}
          imageSrc="/logo.ico"
          imageAlt="Cite Guard logo"
          primaryColor="secondary"
        />

        <ProductCard
          name="AI Guard"
          description="This application allows you to open and view .docx files, edit content within a text field, convert text to images, and save text as a .docx file. Output from the app makes it difficult for AI to answer questions from the app output, making it ideal for institutions to set questions for students. Developed by The AI Guard TEAM."
          features={[
            "Open and view .docx files",
            "Edit the content within a text field",
            "Convert text to images",
            "Save text as a .docx file",
            "Simple and intuitive interface",
            "Output from the app makes it difficult for AI to answer questions from the app output",
            "Institutions can use it to set questions for students"
          ]}
          imageSrc="/logo.ico"
          imageAlt="AI Guard logo"
          primaryColor="primary"
        />
      </section>

      {/* Team Section */}
      <TeamSection />

      {/* Footer */}
      <footer className="border-t border-border mt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2 text-2xl font-bold">
              <Shield className="w-6 h-6 text-primary" />
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                AI & Cite Guard
              </span>
            </div>
            <p className="text-muted-foreground">
              Professional protection solutions for the modern digital world
            </p>
            <p className="text-sm text-muted-foreground/70">
              © 2025 AI & Cite Guard. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
