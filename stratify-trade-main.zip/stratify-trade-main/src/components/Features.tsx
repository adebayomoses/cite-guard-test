import { 
  TrendingUp, 
  Target, 
  Bell, 
  Building2, 
  Newspaper, 
  BookOpen, 
  Headphones, 
  BarChart3 
} from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: TrendingUp,
    title: "Track Everything",
    description: "Monitor all your trades across Forex, Crypto, Indices, Stocks, and Options in one unified dashboard.",
    color: "text-primary"
  },
  {
    icon: Target,
    title: "Trade Setups",
    description: "Create, share, and execute professional trade setups with advanced risk management tools.",
    color: "text-success"
  },
  {
    icon: Bell,
    title: "Price Alerts",
    description: "Never miss an opportunity with intelligent price alerts and market movement notifications.",
    color: "text-warning"
  },
  {
    icon: Building2,
    title: "Prop Firms",
    description: "Connect with top proprietary trading firms and access funding opportunities for skilled traders.",
    color: "text-primary"
  },
  {
    icon: Newspaper,
    title: "Market News",
    description: "Stay informed with real-time market news, economic calendar, and market-moving events.",
    color: "text-success"
  },
  {
    icon: BookOpen,
    title: "Trade Resources",
    description: "Access comprehensive educational materials, strategies, and trading guides for all skill levels.",
    color: "text-warning"
  },
  {
    icon: Headphones,
    title: "Professional Support",
    description: "Get expert guidance from professional traders and dedicated customer support 24/7.",
    color: "text-primary"
  },
  {
    icon: BarChart3,
    title: "Advanced Analytics",
    description: "Deep insights into your trading performance with detailed analytics and reporting tools.",
    color: "text-success"
  }
];

const Features = () => {
  return (
    <section id="features" className="py-20 bg-gradient-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Everything You Need to <span className="text-primary">Excel</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive platform provides all the tools and resources you need to become a successful trader, 
            whether you're just starting out or you're a seasoned professional.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-6 shadow-soft hover:shadow-medium transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="mb-4">
                <feature.icon className={`h-12 w-12 ${feature.color}`} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <Button size="lg" variant="hero">
            Explore All Features
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Features;