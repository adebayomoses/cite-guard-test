import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CTA = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/auth');
  };

  return (
    <section className="py-20 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Ready to Transform Your Trading?
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto leading-relaxed">
            Join thousands of successful traders who trust TradeHelper to manage their portfolios 
            and maximize their profits across all markets.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 text-left">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-6 w-6 text-accent flex-shrink-0" />
              <span className="text-lg">Free 14-day trial</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-6 w-6 text-accent flex-shrink-0" />
              <span className="text-lg">No credit card required</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-6 w-6 text-accent flex-shrink-0" />
              <span className="text-lg">Cancel anytime</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" variant="hero" className="text-lg px-12 py-6 bg-white text-primary hover:bg-white/90" onClick={handleGetStarted}>
              Start Free Trial
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-12 py-6 bg-white/10 border-white/30 text-white hover:bg-white/20">
              Schedule Demo
            </Button>
          </div>

          <p className="text-white/70 mt-6">
            Trusted by 50,000+ traders worldwide
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA;