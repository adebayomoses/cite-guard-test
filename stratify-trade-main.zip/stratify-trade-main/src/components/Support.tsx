import { Button } from "@/components/ui/button";
import { MessageCircle, Users, BookOpen, Phone } from "lucide-react";

const Support = () => {
  return (
    <section id="support" className="py-20 bg-gradient-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Professional <span className="text-primary">Support</span> When You Need It
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Get expert guidance from professional traders, access educational resources, 
            and join a community of successful traders committed to your growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white rounded-xl p-6 text-center shadow-soft hover:shadow-medium transition-all duration-300">
            <div className="bg-primary/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <MessageCircle className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-3">24/7 Live Chat</h3>
            <p className="text-muted-foreground mb-4">
              Instant support from our team of trading experts and technical specialists.
            </p>
            <Button variant="outline" className="w-full">Start Chat</Button>
          </div>

          <div className="bg-white rounded-xl p-6 text-center shadow-soft hover:shadow-medium transition-all duration-300">
            <div className="bg-success/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Users className="h-8 w-8 text-success" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-3">Trading Community</h3>
            <p className="text-muted-foreground mb-4">
              Connect with thousands of traders, share strategies, and learn from the best.
            </p>
            <Button variant="outline" className="w-full">Join Community</Button>
          </div>

          <div className="bg-white rounded-xl p-6 text-center shadow-soft hover:shadow-medium transition-all duration-300">
            <div className="bg-warning/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <BookOpen className="h-8 w-8 text-warning" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-3">Educational Hub</h3>
            <p className="text-muted-foreground mb-4">
              Comprehensive courses, webinars, and resources for all trading levels.
            </p>
            <Button variant="outline" className="w-full">Access Resources</Button>
          </div>

          <div className="bg-white rounded-xl p-6 text-center shadow-soft hover:shadow-medium transition-all duration-300">
            <div className="bg-primary/10 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Phone className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-3">One-on-One Coaching</h3>
            <p className="text-muted-foreground mb-4">
              Personal mentorship from professional traders to accelerate your growth.
            </p>
            <Button variant="outline" className="w-full">Book Session</Button>
          </div>
        </div>

        <div className="text-center mt-16">
          <Button size="lg" variant="hero">
            Get Support Now
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Support;