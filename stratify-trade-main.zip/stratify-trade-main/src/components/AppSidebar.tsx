import { 
  TrendingUp, 
  Bell, 
  Newspaper, 
  BookOpen, 
  Star, 
  Headphones 
} from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';

const menuItems = [
  { title: 'Trade Setups', url: '/dashboard/trade-setups', icon: TrendingUp },
  { title: 'Price Alerts', url: '/dashboard/price-alerts', icon: Bell },
  { title: 'News', url: '/dashboard/news', icon: Newspaper },
  { title: 'Trade Resources', url: '/dashboard/trade-resources', icon: BookOpen },
  { title: 'Prop Firms Rating', url: '/dashboard/prop-firms', icon: Star },
  { title: 'Professional Support', url: '/dashboard/support', icon: Headphones },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (path: string) => currentPath === path;
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? 'bg-primary/10 text-primary border-r-2 border-primary' : 'hover:bg-muted/50';

  return (
    <Sidebar
      className={state === 'collapsed' ? 'w-14' : 'w-64'}
      collapsible="icon"
    >
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-primary font-semibold">
            Trading Tools
          </SidebarGroupLabel>
          
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      end 
                      className={getNavCls}
                    >
                      <item.icon className="h-4 w-4" />
                      {state !== 'collapsed' && <span className="ml-2">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}