import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp, Target, DollarSign } from "lucide-react";

const Analytics = () => {
  return (
    <section id="analytics" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              <span className="text-primary">Analytics</span> That Drive Results
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Make data-driven decisions with our advanced analytics suite. Track your performance, 
              identify profitable patterns, and optimize your trading strategy with precision insights.
            </p>

            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="bg-primary/10 p-3 rounded-lg">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">Performance Tracking</h3>
                  <p className="text-muted-foreground">Real-time P&L tracking, win rates, and risk metrics across all your trades.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-success/10 p-3 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-success" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">Market Analysis</h3>
                  <p className="text-muted-foreground">Advanced charting tools with technical indicators and market sentiment analysis.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-warning/10 p-3 rounded-lg">
                  <Target className="h-6 w-6 text-warning" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">Risk Management</h3>
                  <p className="text-muted-foreground">Portfolio risk assessment and position sizing recommendations.</p>
                </div>
              </div>
            </div>

            <Button size="lg" variant="hero">
              View Analytics Demo
            </Button>
          </div>

          <div className="bg-gradient-card rounded-xl p-8 shadow-medium">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold text-foreground">Trading Dashboard</h3>
                <div className="text-success text-sm font-semibold">+23.4% This Month</div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-4 shadow-soft">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="h-5 w-5 text-success" />
                    <span className="text-sm text-muted-foreground">Total P&L</span>
                  </div>
                  <div className="text-2xl font-bold text-success">$12,450</div>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-soft">
                  <div className="flex items-center space-x-2">
                    <Target className="h-5 w-5 text-primary" />
                    <span className="text-sm text-muted-foreground">Win Rate</span>
                  </div>
                  <div className="text-2xl font-bold text-primary">78%</div>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-soft">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-warning" />
                    <span className="text-sm text-muted-foreground">Avg Return</span>
                  </div>
                  <div className="text-2xl font-bold text-warning">2.3%</div>
                </div>

                <div className="bg-white rounded-lg p-4 shadow-soft">
                  <div className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    <span className="text-sm text-muted-foreground">Active Trades</span>
                  </div>
                  <div className="text-2xl font-bold text-primary">12</div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4 shadow-soft">
                <h4 className="font-semibold text-foreground mb-3">Recent Performance</h4>
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Week {i}</span>
                      <div className={`text-sm font-semibold ${i % 2 ? 'text-success' : 'text-primary'}`}>
                        {i % 2 ? '+' : ''}${(Math.random() * 1000).toFixed(0)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Analytics;