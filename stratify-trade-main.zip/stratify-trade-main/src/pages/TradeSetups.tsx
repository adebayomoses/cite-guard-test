import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { SidebarProvider, SidebarTrigger, SidebarInset } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { ExternalLink, TrendingUp, Clock, User, LogOut, RefreshCw, Calendar } from 'lucide-react';

interface TradingIdea {
  id: string;
  trader_username: string;
  trader_display_name: string;
  title: string;
  description?: string;
  symbol?: string;
  timeframe?: string;
  chart_image_url?: string;
  analysis_text?: string;
  published_date?: string;
  tradingview_url: string;
  scraped_at: string;
}

// Fallback to prevent runtime errors if old code paths reference this
const tradingViewUsers: any[] = [];

const TradeSetups = () => {
  const { user, signOut, loading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [tradingIdeas, setTradingIdeas] = useState<TradingIdea[]>([]);
  const [isLoadingIdeas, setIsLoadingIdeas] = useState(true);
  const [isScrapingInProgress, setIsScrapingInProgress] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      fetchTradingIdeas();
    }
  }, [user]);

  const fetchTradingIdeas = async () => {
    try {
      setIsLoadingIdeas(true);
      const { data, error } = await supabase
        .from('trading_ideas')
        .select('*')
        .eq('is_active', true)
        .order('scraped_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setTradingIdeas(data || []);
    } catch (error) {
      console.error('Error fetching trading ideas:', error);
      toast({
        title: "Error",
        description: "Failed to load trading ideas",
        variant: "destructive",
      });
    } finally {
      setIsLoadingIdeas(false);
    }
  };

  const handleRefreshIdeas = async () => {
    try {
      setIsScrapingInProgress(true);
      toast({
        title: "Refreshing",
        description: "Fetching latest trading ideas...",
      });

      const { data, error } = await supabase.functions.invoke('scrape-tradingview');
      
      if (error) throw error;

      toast({
        title: "Success",
        description: "Trading ideas updated successfully",
      });
      
      // Refresh the ideas list
      await fetchTradingIdeas();
    } catch (error) {
      console.error('Error refreshing ideas:', error);
      toast({
        title: "Error",
        description: "Failed to refresh trading ideas",
        variant: "destructive",
      });
    } finally {
      setIsScrapingInProgress(false);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    toast({
      title: "Signed out",
      description: "You have been successfully signed out.",
    });
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <TrendingUp className="h-12 w-12 text-primary mx-auto animate-pulse mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        
        <SidebarInset className="flex-1">
          {/* Header */}
          <header className="border-b bg-card shadow-soft">
            <div className="container mx-auto px-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <SidebarTrigger className="lg:hidden" />
                  <TrendingUp className="h-8 w-8 text-primary" />
                  <div>
                    <h1 className="text-2xl font-bold">TradeHelper Plus</h1>
                    <p className="text-sm text-muted-foreground">Trading Dashboard</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">
                      {user.user_metadata?.full_name || user.email}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleSignOut}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <main className="container mx-auto px-4 py-8">
            <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <TrendingUp className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold">Trade Setups</h1>
          <p className="text-muted-foreground">Professional trading setups from expert traders</p>
        </div>
      </div>

      {/* Info Banner */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <div className="bg-primary/10 p-2 rounded-full">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-primary">Live Trading Setups</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Access professional trading setups and chart analysis from verified TradingView experts. 
                Click on any trader's profile to view their latest ideas and setups.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Badge variant="outline">{tradingIdeas.length} Ideas</Badge>
          <Badge variant="secondary">
            Last updated: {tradingIdeas.length > 0 ? new Date(tradingIdeas[0]?.scraped_at).toLocaleTimeString() : 'Never'}
          </Badge>
        </div>
        <Button 
          onClick={handleRefreshIdeas}
          disabled={isScrapingInProgress}
          variant="outline"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isScrapingInProgress ? 'animate-spin' : ''}`} />
          {isScrapingInProgress ? 'Refreshing...' : 'Refresh Ideas'}
        </Button>
      </div>

      {/* Trading Ideas Grid */}
      {isLoadingIdeas ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="shadow-soft">
              <CardHeader>
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="animate-pulse">
                  <div className="h-32 bg-muted rounded mb-4"></div>
                  <div className="h-3 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : tradingIdeas.length === 0 ? (
        <Card className="shadow-soft">
          <CardContent className="py-12">
            <div className="text-center">
              <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Trading Ideas Yet</h3>
              <p className="text-muted-foreground mb-4">
                Click "Refresh Ideas" to fetch the latest trading setups from our expert traders.
              </p>
              <Button onClick={handleRefreshIdeas} disabled={isScrapingInProgress}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isScrapingInProgress ? 'animate-spin' : ''}`} />
                {isScrapingInProgress ? 'Fetching Ideas...' : 'Fetch Ideas'}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tradingIdeas.map((idea) => (
            <Card key={idea.id} className="shadow-soft hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{idea.trader_display_name}</CardTitle>
                      <p className="text-sm text-muted-foreground">@{idea.trader_username}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end space-y-1">
                    {idea.symbol && (
                      <Badge variant="secondary" className="bg-success/10 text-success">
                        {idea.symbol}
                      </Badge>
                    )}
                    {idea.timeframe && (
                      <Badge variant="outline" className="text-xs">
                        {idea.timeframe}
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2">{idea.title}</h4>
                  {idea.description && (
                    <p className="text-sm text-muted-foreground mb-3">{idea.description}</p>
                  )}
                </div>
                
                {idea.chart_image_url && (
                  <div className="rounded-lg overflow-hidden bg-muted">
                    <img 
                      src={idea.chart_image_url} 
                      alt="Trading Chart"
                      className="w-full h-48 object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                      }}
                    />
                  </div>
                )}
                
                {idea.analysis_text && (
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {idea.analysis_text}
                  </p>
                )}
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>
                      {idea.published_date 
                        ? new Date(idea.published_date).toLocaleDateString()
                        : 'Recent'
                      }
                    </span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="h-6 text-xs"
                    onClick={() => window.open(idea.tradingview_url, '_blank')}
                  >
                    <ExternalLink className="h-3 w-3 mr-1" />
                    View on TradingView
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* TradingView Widget Section */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Market Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-muted/30 rounded-lg p-8 text-center">
            <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Live Market Data</h3>
            <p className="text-muted-foreground mb-4">
              Integrate with TradingView for real-time market data and advanced charting tools.
            </p>
            <Button 
              variant="outline"
              onClick={() => window.open('https://www.tradingview.com/', '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open TradingView
            </Button>
          </div>
        </CardContent>
      </Card>
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default TradeSetups;