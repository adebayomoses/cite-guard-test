import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface TradingIdea {
  trader_username: string;
  trader_display_name: string;
  title: string;
  description?: string;
  symbol?: string;
  timeframe?: string;
  chart_image_url?: string;
  analysis_text?: string;
  published_date?: string;
  tradingview_url: string;
}

const tradingViewUsers = [
  { username: 'Cryptobees_buzz', displayName: 'Cryptobees Buzz' },
  { username: 'AnupZiddi', displayName: 'Anup Ziddi' },
  { username: 'Lukegforex', displayName: 'Luke G Forex' },
  { username: 'behdark', displayName: 'Behdark' },
  { username: 'ALBERTGOLDHUNTER', displayName: 'Albert Gold Hunter' },
  { username: 'WalterMoon', displayName: 'Walter Moon' },
  { username: 'TheCryptoGoon', displayName: 'The Crypto Goon' },
];

// Helper to safely parse __NEXT_DATA__ and collect chart links
function collectChartLinksFromNextData(jsonText: string): string[] {
  try {
    const root = JSON.parse(jsonText);
    const out = new Set<string>();
    const walk = (val: unknown) => {
      if (val == null) return;
      if (typeof val === 'string') {
        const m = val.match(/^\/chart\/[^\/]+\/[a-zA-Z0-9]{6,}(?:-[^\/"]+)?\/?/);
        if (m) {
          const u = `https://www.tradingview.com${m[0]}`.split('?')[0].replace(/\/+$/, '/');
          out.add(u);
        }
      } else if (Array.isArray(val)) {
        for (const v of val) walk(v);
      } else if (typeof val === 'object') {
        for (const v of Object.values(val as Record<string, unknown>)) walk(v);
      }
    };
    walk(root);
    return Array.from(out);
  } catch {
    return [];
  }
}

async function extractIdeaLinksFromSearch(username: string): Promise<string[]> {
  const searchUrl = `https://www.tradingview.com/ideas/?search=${encodeURIComponent(username)}`;
  console.log(`Fetching ideas search page: ${searchUrl}`);
  try {
    const response = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Referer': 'https://www.tradingview.com/',
      }
    });

    if (!response.ok) {
      console.error(`Failed to fetch ideas search page for ${username}: ${response.status}`);
      return [];
    }

    const html = await response.text();

    // Grab potential idea links from search page
    const allIdeaLinks = new Set<string>();
    // Pattern A: direct chart hrefs
    const chartHrefMatches = Array.from(html.matchAll(/href="(\/chart\/[^\/"]{1,20}\/[a-zA-Z0-9]{6,}[^\"]*)"/gi));
    for (const m of chartHrefMatches) {
      const url = `https://www.tradingview.com${m[1]}`.split('?')[0];
      allIdeaLinks.add(url);
    }
    // Pattern B: tv-widget-idea title anchors
    const titleHrefMatches = Array.from(html.matchAll(/<a[^>]*class="[^"]*tv-widget-idea__title[^"]*"[^>]*href="([^"]+)"[^>]*>/gi));
    for (const m of titleHrefMatches) {
      const href = m[1];
      const url = href.startsWith('http') ? href : `https://www.tradingview.com${href}`;
      if (url.includes('/chart/')) allIdeaLinks.add(url.split('?')[0]);
    }

    // Filter by author by checking proximity of author link in the same snippet
    const filtered: string[] = [];
    for (const url of allIdeaLinks) {
      const idx = html.indexOf(url.replace('https://www.tradingview.com', ''));
      if (idx === -1) continue;
      const snippet = html.slice(Math.max(0, idx - 1500), Math.min(html.length, idx + 1500));
      const authorOk = new RegExp(`href=\"/u/${username}/\"`, 'i').test(snippet);
      if (authorOk) filtered.push(url);
    }

    // Return up to 5 links
    const finalLinks = filtered.filter((u, i, self) => self.indexOf(u) === i).slice(0, 5);
    console.log(`Found ${finalLinks.length} ideas via search for ${username}:`, finalLinks);
    return finalLinks;
  } catch (e) {
    console.error('Error extracting ideas from search page', e);
    return [];
  }
}

async function extractIdeaLinksFromProfile(username: string): Promise<string[]> {
  const profileUrl = `https://www.tradingview.com/u/${username}/`;
  console.log(`Fetching profile: ${profileUrl}`);
  
  try {
    const response = await fetch(profileUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Referer': 'https://www.tradingview.com/',
      }
    });
    
    if (!response.ok) {
      console.error(`Failed to fetch ${username}'s profile: ${response.status}`);
      return [];
    }
    
    const html = await response.text();
    console.log(`Fetched profile HTML for ${username}, length: ${html.length}`);
    
    // Extract idea URLs from profile - try multiple aggressive patterns
    const ideaUrls: string[] = [];
    
    // Pattern 1: Direct href links to charts
    const hrefMatches = Array.from(html.matchAll(/<a[^>]*href="(\/chart\/[^\/"]{1,20}\/[a-zA-Z0-9]{6,}[^\"]*)"[^>]*>/gi));
    for (const match of hrefMatches) {
      const url = `https://www.tradingview.com${match[1]}`.split('?')[0];
      if (!ideaUrls.includes(url)) ideaUrls.push(url);
    }
    
    // Pattern 1b: tv-widget-idea title anchors
    const titleLinkMatches = Array.from(html.matchAll(/<a[^>]*class="[^\"]*tv-widget-idea__title[^\"]*"[^>]*href="([^\"]+)"[^>]*>/gi));
    for (const m of titleLinkMatches) {
      const href = m[1];
      const url = href.startsWith('http') ? href : `https://www.tradingview.com${href}`;
      if (url.includes('/chart/')) {
        const clean = url.split('?')[0];
        if (!ideaUrls.includes(clean)) ideaUrls.push(clean);
      }
    }
    
    // Pattern 2: JSON-LD structured data
    const jsonLdMatches = Array.from(html.matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi));
    for (const jsonMatch of jsonLdMatches) {
      try {
        const data = JSON.parse(jsonMatch[1]);
        if (data.url && data.url.includes('/chart/')) {
          const url = data.url.startsWith('http') ? data.url : `https://www.tradingview.com${data.url}`;
          if (!ideaUrls.includes(url)) ideaUrls.push(url);
        }
      } catch (e) {
        // Ignore JSON parse errors
      }
    }
    
    // Pattern 3: Script variables and data
    const scriptDataMatches = Array.from(html.matchAll(/["']url["']:\s*["'](\/chart\/[^\/"]{1,20}\/[a-zA-Z0-9]{6,}[^"']*?)["']/gi));
    for (const match of scriptDataMatches) {
      const url = `https://www.tradingview.com${match[1]}`.split('?')[0];
      if (!ideaUrls.includes(url)) ideaUrls.push(url);
    }
    
    // Pattern 4: Data attributes
    const dataMatches = Array.from(html.matchAll(/data-[^=]*=["'](\/chart\/[^\/"]{1,20}\/[a-zA-Z0-9]{6,}[^"']*?)["']/gi));
    for (const match of dataMatches) {
      const url = `https://www.tradingview.com${match[1]}`.split('?')[0];
      if (!ideaUrls.includes(url)) ideaUrls.push(url);
    }
    
    // Clean and deduplicate URLs
    const cleanUrls = ideaUrls
      .filter(url => url.includes('/chart/') && url.match(/\/chart\/[^\/"]{1,20}\/[a-zA-Z0-9]{6,}/))
      .map(url => url.split('?')[0]) // Remove query parameters
      .filter((url, index, self) => self.indexOf(url) === index) // Remove duplicates
      .slice(0, 5); // Limit to 5 most recent ideas
    
    console.log(`Found ${cleanUrls.length} idea URLs for ${username}:`, cleanUrls);

    // Try extracting from __NEXT_DATA__ JSON if not enough URLs
    if (cleanUrls.length < 3) {
      const nextDataMatch = html.match(/<script id="__NEXT_DATA__" type="application\/json">([\s\S]+?)<\/script>/i);
      if (nextDataMatch) {
        const more = collectChartLinksFromNextData(nextDataMatch[1]);
        for (const u of more) {
          if (!cleanUrls.includes(u)) cleanUrls.push(u);
          if (cleanUrls.length >= 5) break;
        }
      }
    }

    // Final fallback: try the "published-ideas" tab page
    if (cleanUrls.length < 3) {
      const altUrl = `https://www.tradingview.com/u/${username}/published-ideas/`;
      console.log(`Fetching alternate ideas page: ${altUrl}`);
      try {
        const resp2 = await fetch(altUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Referer': 'https://www.tradingview.com/',
          }
        });
        if (resp2.ok) {
          const html2 = await resp2.text();
          // Direct chart hrefs
          const matches2 = Array.from(html2.matchAll(/<a[^>]*href="(\/chart\/[^\/"]+\/[a-zA-Z0-9]{6,}[^\"]*)"[^>]*>/gi));
          for (const m of matches2) {
            const u = `https://www.tradingview.com${m[1]}`.split('?')[0];
            if (!cleanUrls.includes(u)) cleanUrls.push(u);
            if (cleanUrls.length >= 5) break;
          }
          // tv-widget-idea title anchors
          if (cleanUrls.length < 5) {
            const titleLinks2 = Array.from(html2.matchAll(/<a[^>]*class="[^\"]*tv-widget-idea__title[^\"]*"[^>]*href="([^\"]+)"[^>]*>/gi));
            for (const m of titleLinks2) {
              const href = m[1];
              const u = (href.startsWith('http') ? href : `https://www.tradingview.com${href}`).split('?')[0];
              if (u.includes('/chart/') && !cleanUrls.includes(u)) cleanUrls.push(u);
              if (cleanUrls.length >= 5) break;
            }
          }
        }
      } catch (e) {
        console.log('Error fetching alternate ideas page', e);
      }
    }

    console.log(`Total idea URLs for ${username}: ${cleanUrls.length}`);
    return cleanUrls;
    
  } catch (error) {
    console.error(`Error fetching profile for ${username}:`, error);
    return [];
  }
}

async function parseIdeaFromUrl(ideaUrl: string, username: string, displayName: string): Promise<TradingIdea | null> {
  try {
    console.log(`Parsing idea: ${ideaUrl}`);
    
    const response = await fetch(ideaUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache',
        'Referer': 'https://www.tradingview.com/',
      }
    });
    
    if (!response.ok) {
      console.error(`Failed to fetch idea page: ${response.status}`);
      return null;
    }
    
    const html = await response.text();
console.log(`Fetched idea HTML, length: ${html.length}`);
    
    // Validate author to ensure the idea belongs to the expected profile
    const authorOk = new RegExp(`href="/u/${username}/"`, 'i').test(html)
      || new RegExp(`"author"\s*:\s*"(?:${displayName}|${username})"`, 'i').test(html)
      || (() => {
        const m = html.match(/<meta[^>]*name="author"[^>]*content="([^"]+)"/i);
        return !!(m && new RegExp(`${displayName}|${username}`, 'i').test(m[1]));
      })();
    if (!authorOk) {
      console.log(`Author mismatch for ${ideaUrl} (expected ${username}). Skipping.`);
      return null;
    }
    
    // Extract metadata from the page
    let title = '';
    let description = '';
    let symbol = '';
    let timeframe = '';
    let imageUrl = '';
    let publishedDate = '';
    
    // Extract title from meta tag or page title with better patterns
    let titleMatch = html.match(/<meta[^>]*property="og:title"[^>]*content="([^"]+)"/i);
    if (!titleMatch) {
      titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    }
    if (!titleMatch) {
      // Try to find title in page headers
      titleMatch = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
    }
    if (titleMatch) {
      title = titleMatch[1].trim()
        .replace(/\s+by\s+.*$/i, '') // Remove "by username" suffix
        .replace(/\s*—\s*TradingView.*$/i, '') // Remove TradingView suffix
        .replace(/\s*\|\s*TradingView.*$/i, ''); // Remove pipe TradingView suffix
    }
    
    // Extract description from meta tag with multiple fallbacks
    let descMatch = html.match(/<meta[^>]*property="og:description"[^>]*content="([^"]+)"/i);
    if (!descMatch) {
      descMatch = html.match(/<meta[^>]*name="description"[^>]*content="([^"]+)"/i);
    }
    if (!descMatch) {
      descMatch = html.match(/<meta[^>]*name="twitter:description"[^>]*content="([^"]+)"/i);
    }
    if (descMatch) {
      description = descMatch[1].trim();
    }
    
    // Extract image from multiple sources with enhanced patterns
    let imageMatch = html.match(/<meta[^>]*property="og:image"[^>]*content="([^"]+)"/i);
    
    if (!imageMatch) {
      // Try alternative meta tag patterns
      imageMatch = html.match(/<meta[^>]*name="twitter:image"[^>]*content="([^"]+)"/i) ||
                   html.match(/<meta[^>]*property="twitter:image"[^>]*content="([^"]+)"/i) ||
                   html.match(/<meta[^>]*name="image"[^>]*content="([^"]+)"/i);
    }
    
    if (!imageMatch) {
      // Try to find chart images in the page content with expanded patterns
      const chartImagePatterns = [
        // TradingView chart snapshot URLs - more comprehensive
        /https:\/\/[^"'\s]*\.tradingview\.com[^"'\s]*\.png/gi,
        /https:\/\/[^"'\s]*tradingview[^"'\s]*snapshot[^"'\s]*\.png/gi,
        /https:\/\/[^"'\s]*snapshot[^"'\s]*\.tradingview[^"'\s]*\.png/gi,
        /https:\/\/[^"'\s]*charts?[^"'\s]*\.tradingview[^"'\s]*\.png/gi,
        // Chart image from script/JSON data
        /"(?:chart|image)Url":\s*"([^"]+\.(?:png|jpg|jpeg))"/gi,
        /"(?:snapshot|preview)Url":\s*"([^"]+\.(?:png|jpg|jpeg))"/gi,
        // Image URLs in various attributes
        /(?:src|data-src|data-original)="([^"]*(?:chart|snapshot|tradingview)[^"]*\.(?:png|jpg|jpeg))"/gi,
        // General TradingView image patterns
        /https:\/\/[^"'\s]*\.tradingview-widget\.com[^"'\s]*\.(?:png|jpg|jpeg)/gi,
        // Fallback broader patterns
        /https:\/\/[^"'\s]*\.(?:png|jpg|jpeg)/gi
      ];
      
      for (const pattern of chartImagePatterns) {
        const matches = Array.from(html.matchAll(pattern));
        if (matches.length > 0) {
          const first = matches[0];
          const candidate = (first[1] || first[0]) as string;
          // Filter for likely chart images
          if (candidate.includes('tradingview') || candidate.includes('chart') || candidate.includes('snapshot')) {
            imageMatch = [candidate, candidate];
            break;
          }
        }
      }
    }
    
    if (imageMatch) {
      imageUrl = (imageMatch[1] || (imageMatch as unknown as string[])[0]) as string;
      // Normalize TradingView image URLs
      if (imageUrl.startsWith('//')) {
        imageUrl = 'https:' + imageUrl;
      } else if (imageUrl.startsWith('/')) {
        imageUrl = 'https://www.tradingview.com' + imageUrl;
      }
      // Some images are protocol-less or resized params; strip size params
      imageUrl = imageUrl.split('?')[0];
      
      // Log the found image URL for debugging
      console.log(`Found chart image for ${title}: ${imageUrl}`);
    } else {
      // Fallback: construct snapshot URL from idea id in path
      const idMatch = ideaUrl.match(/\/chart\/[^\/]+\/([a-zA-Z0-9]{6,})/);
      if (idMatch) {
        const code = idMatch[1];
        const folder = code[0].toLowerCase();
        imageUrl = `https://s3.tradingview.com/${folder}/${code}_mid.png`;
        console.log(`Fallback chart image constructed: ${imageUrl}`);
      } else {
        console.log(`No chart image found for ${title}`);
      }
    }
    
    // Extract symbol from URL or page content with better patterns
    let symbolFromUrl = ideaUrl.match(/\/chart\/([^\/]+)\//);
    if (symbolFromUrl) {
      symbol = symbolFromUrl[1].toUpperCase().replace(/USD$|USDT$/, ''); // Clean common suffixes
    }
    
    // Try to extract symbol from page content if URL didn't work
    if (!symbol || symbol === 'CHART') {
      const symbolMatches = [
        html.match(/"symbol":\s*"([^"]+)"/i),
        html.match(/<meta[^>]*name="symbol"[^>]*content="([^"]+)"/i),
        html.match(/symbol[=:]\s*["']([A-Z]{2,10})["']/i),
        html.match(/\b([A-Z]{3,8}(?:USD|USDT|BTC|ETH))\b/i)
      ];
      for (const match of symbolMatches) {
        if (match && match[1]) {
          symbol = match[1].toUpperCase();
          break;
        }
      }
    }
    
    // Extract timeframe from URL or content with enhanced patterns
    let timeframeMatch = ideaUrl.match(/\/([1-9][0-9]*[mhDWM])\//i);
    if (!timeframeMatch) {
      const timeframeMatches = [
        html.match(/timeframe[^>]*['":]([1-9][0-9]*[mhDWM])['"\s]/i),
        html.match(/"interval":\s*"([^"]+)"/i),
        html.match(/interval[=:]\s*["']([^"']+)["']/i)
      ];
      for (const match of timeframeMatches) {
        if (match && match[1]) {
          timeframeMatch = match;
          break;
        }
      }
    }
    if (timeframeMatch) {
      timeframe = timeframeMatch[1];
    } else {
      timeframe = '4H'; // Default timeframe
    }
    
    // Extract published date from JSON-LD or meta tags
    const dateMatch = html.match(/"datePublished":\s*"([^"]+)"/i) ||
                     html.match(/<meta[^>]*property="article:published_time"[^>]*content="([^"]+)"/i);
    if (dateMatch) {
      publishedDate = dateMatch[1];
    }
    
    // Fallback data if extraction failed
    if (!title) title = `${displayName}'s ${symbol || 'Market'} Analysis`;
    if (!description) description = `Trading analysis by ${displayName}`;
    if (!symbol) symbol = 'BTCUSD';
    if (!publishedDate) publishedDate = new Date().toISOString();
    
    const idea: TradingIdea = {
      trader_username: username,
      trader_display_name: displayName,
      title,
      description,
      symbol,
      timeframe,
      chart_image_url: imageUrl || undefined,
      analysis_text: description,
      published_date: publishedDate,
      tradingview_url: ideaUrl,
    };
    
    console.log(`Parsed idea: ${title} (${symbol})`);
    return idea;
    
  } catch (error) {
    console.error(`Error parsing idea from ${ideaUrl}:`, error);
    return null;
  }
}

// Extract ideas directly from the profile or published-ideas page using TV CSS classes
async function extractIdeasFromProfilePage(username: string, displayName: string): Promise<TradingIdea[]> {
  const candidates = [
    `https://www.tradingview.com/u/${username}/published-ideas/`,
    `https://www.tradingview.com/u/${username}/`
  ];
  for (const url of candidates) {
    try {
      const resp = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Cache-Control': 'no-cache',
          'Referer': 'https://www.tradingview.com/',
        }
      });
      if (!resp.ok) continue;
      const html = await resp.text();

      // Find idea title anchors
      const titleAnchors = Array.from(html.matchAll(/<a[^>]*class="[^\"]*tv-widget-idea__title[^\"]*"[^>]*href="([^\"]+)"[^>]*>([\s\S]*?)<\/a>/gi));
      // Find cover images
      const coverImgs = Array.from(html.matchAll(/<img[^>]*class="[^\"]*tv-widget-idea__cover[^\"]*"[^>]*src="([^\"]+)"[^>]*>/gi));
      const coverStyles = Array.from(html.matchAll(/class="[^\"]*tv-widget-idea__cover[^\"]*"[^>]*style="[^"]*background-image:\s*url\(([^\)]+)\)/gi));

      if (titleAnchors.length === 0) continue;

      const ideas: TradingIdea[] = [];
      for (let i = 0; i < Math.min(titleAnchors.length, 5); i++) {
        const href = titleAnchors[i][1];
        const rawTitle = titleAnchors[i][2] || '';
        const title = rawTitle.replace(/<[^>]+>/g, '').trim();
        const link = href.startsWith('http') ? href : `https://www.tradingview.com${href}`;

        let imageUrl = '';
        if (coverImgs[i] && coverImgs[i][1]) {
          imageUrl = coverImgs[i][1];
        } else if (coverStyles[i] && coverStyles[i][1]) {
          imageUrl = coverStyles[i][1].replace(/^['\"]|['\"]$/g, '');
        }
        if (imageUrl.startsWith('//')) imageUrl = 'https:' + imageUrl;
        if (imageUrl.startsWith('/')) imageUrl = 'https://www.tradingview.com' + imageUrl;
        imageUrl = imageUrl.split('?')[0];

        // Symbol from URL if possible
        let symbol = '';
        const symMatch = link.match(/\/chart\/([^\/]+)\//i);
        if (symMatch) symbol = symMatch[1].toUpperCase();

        ideas.push({
          trader_username: username,
          trader_display_name: displayName,
          title: title || `${displayName}'s Idea`,
          description: `Idea by ${displayName}`,
          symbol: symbol || undefined,
          timeframe: undefined,
          chart_image_url: imageUrl || undefined,
          analysis_text: `Idea scraped from ${displayName}'s profile`,
          published_date: new Date().toISOString(),
          tradingview_url: link,
        });
      }

      if (ideas.length) {
        console.log(`Extracted ${ideas.length} ideas from profile page for ${username}`);
        return ideas;
      }
    } catch (e) {
      console.log('Error extracting ideas from profile page', e);
    }
  }
  return [];
}

async function scrapeTradingViewProfile(username: string, displayName: string): Promise<TradingIdea[]> {
  console.log(`Scraping profile: ${username}`);
  
  try {
    // First, get idea links from the profile
const fromSearch = await extractIdeaLinksFromSearch(username);
    const ideaUrls = fromSearch.length ? fromSearch : await extractIdeaLinksFromProfile(username);
    
    if (ideaUrls.length === 0) {
      console.log(`No idea URLs found for ${username}, trying to extract cards directly from profile pages`);
      const ideasFromPage = await extractIdeasFromProfilePage(username, displayName);
      if (ideasFromPage.length) {
        return ideasFromPage;
      }
      console.log(`No idea URLs or cards found for ${username}, creating fallback`);
      return [{
        trader_username: username,
        trader_display_name: displayName,
        title: `${displayName}'s Market Analysis`,
        description: `Latest trading insights from ${displayName}`,
        symbol: 'BTCUSD',
        timeframe: '4H',
        analysis_text: `Professional trading analysis by ${displayName}. Visit their TradingView profile for the latest ideas and charts.`,
        published_date: new Date().toISOString(),
        tradingview_url: `https://www.tradingview.com/u/${username}/`,
      }];
    }
    
    // Parse each idea URL to get detailed information
    const tradingIdeas: TradingIdea[] = [];
    
    for (const ideaUrl of ideaUrls) {
      const idea = await parseIdeaFromUrl(ideaUrl, username, displayName);
      if (idea) {
        tradingIdeas.push(idea);
      }
      
      // Add delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // If we couldn't parse any ideas (e.g., idea pages blocked), return a single fallback
    if (tradingIdeas.length === 0) {
      console.log(`No parsable ideas for ${username}, returning fallback`);
      return [{
        trader_username: username,
        trader_display_name: displayName,
        title: `${displayName}'s Market Analysis`,
        description: `Latest trading insights from ${displayName}`,
        symbol: 'BTCUSD',
        timeframe: '4H',
        analysis_text: `Professional trading analysis by ${displayName}. Visit their TradingView profile for the latest ideas and charts.`,
        published_date: new Date().toISOString(),
        tradingview_url: `https://www.tradingview.com/u/${username}/`,
      }];
    }
    
    console.log(`Extracted ${tradingIdeas.length} ideas for ${username}`);
    return tradingIdeas;
    
  } catch (error) {
    console.error(`Error scraping ${username}:`, error);
    // Return fallback data on error
    return [{
      trader_username: username,
      trader_display_name: displayName,
      title: `${displayName}'s Trading Analysis`,
      description: `Market analysis from ${displayName}`,
      symbol: 'BTCUSD',
      timeframe: '4H',
      analysis_text: `Trading analysis by ${displayName}. Check TradingView for latest updates.`,
      published_date: new Date().toISOString(),
      tradingview_url: `https://www.tradingview.com/u/${username}/`,
    }];
  }
}

async function storeTradingIdeas(ideas: TradingIdea[]) {
  console.log(`Storing ${ideas.length} trading ideas`);
  
  for (const idea of ideas) {
    // Check if idea already exists by TradingView URL (more reliable deduplication)
    const { data: existing } = await supabase
      .from('trading_ideas')
      .select('id')
      .eq('tradingview_url', idea.tradingview_url)
      .single();
    
    if (!existing) {
      const { error } = await supabase
        .from('trading_ideas')
        .insert(idea);
      
      if (error) {
        console.error('Error inserting trading idea:', error);
      } else {
        console.log(`Stored idea: ${idea.title}`);
      }
    } else {
      console.log(`Idea already exists: ${idea.title}`);
    }
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting TradingView scraping...');
    
    const allIdeas: TradingIdea[] = [];
    
    // Scrape all traders
    for (const trader of tradingViewUsers) {
      const ideas = await scrapeTradingViewProfile(trader.username, trader.displayName);
      allIdeas.push(...ideas);
      
      // Add delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    // Store all ideas in database
    await storeTradingIdeas(allIdeas);
    
    console.log(`Scraping complete. Processed ${allIdeas.length} ideas`);
    
    return new Response(
      JSON.stringify({
        success: true,
        message: `Scraped and stored ${allIdeas.length} trading ideas`,
        ideas_count: allIdeas.length,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error in scrape-tradingview function:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});