-- Create trading_ideas table for storing scraped TradingView data
CREATE TABLE public.trading_ideas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  trader_username TEXT NOT NULL,
  trader_display_name TEXT,
  title TEXT NOT NULL,
  description TEXT,
  symbol TEXT,
  timeframe TEXT,
  chart_image_url TEXT,
  analysis_text TEXT,
  published_date TIMESTAMP WITH TIME ZONE,
  tradingview_url TEXT,
  scraped_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.trading_ideas ENABLE ROW LEVEL SECURITY;

-- Create policies for trading ideas (public read access since these are public trading ideas)
CREATE POLICY "Anyone can view trading ideas" 
ON public.trading_ideas 
FOR SELECT 
USING (true);

-- Only authenticated users can insert/update (for admin functions)
CREATE POLICY "Authenticated users can insert trading ideas" 
ON public.trading_ideas 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update trading ideas" 
ON public.trading_ideas 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_trading_ideas_updated_at
BEFORE UPDATE ON public.trading_ideas
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for better performance
CREATE INDEX idx_trading_ideas_trader_username ON public.trading_ideas(trader_username);
CREATE INDEX idx_trading_ideas_scraped_at ON public.trading_ideas(scraped_at DESC);
CREATE INDEX idx_trading_ideas_is_active ON public.trading_ideas(is_active);